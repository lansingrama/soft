<?php //JFM 24_03_14
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$POST=cleanArray($_POST);

$reviewProfile=$POST['review_profile'];
$ca=$POST['ca'];

$query='SELECT DISTINCT rch.criterion_user_id, rch.criterion_name, rch.criterion_description, rch.criterion_moc, rch.criterion_showstopper, 
						rgh.review_group_description,
						rc.review_criterion_id,
						ra.ca,
						cs.criteria_status,
						rch.criterion_showstopper,
						rt.review_type,
						ca.ca AS ca_name,
						p.program,
						coe.coe,
						msn.msn,
						YEARWEEK(cs.criteria_planned,1) AS week_number_planned,
						GROUP_CONCAT(DISTINCT cs.criteria_status_id,\'---\',ra.ca SEPARATOR \', \') AS criteria_status_id,
						GROUP_CONCAT(DISTINCT ca.ca,\'---\',ra.ca SEPARATOR \', \') AS ca_evidence_info,
						GROUP_CONCAT(DISTINCT vl2.action_taken_on,\'---\',ra.ca SEPARATOR \', \') AS supplied,
						GROUP_CONCAT(DISTINCT g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS grams_id,
						GROUP_CONCAT(DISTINCT " ",u.name," ",u.surname,\'---\',ra.ca SEPARATOR \', \') AS provider,
						GROUP_CONCAT(DISTINCT ce.file_link,\'---\',ra.ca SEPARATOR \', \') AS file_link,
						GROUP_CONCAT(DISTINCT " ",u2.name," ",u2.surname,\'---\',ra.ca SEPARATOR \', \') AS validator,
						YEARWEEK(vl.action_taken_on,1) AS week_number
			FROM dr_review_criterion_history 				AS rch
			INNER JOIN dr_review_criterion 					AS rc 		ON  rc.review_criterion_id=rch.criterion
			INNER JOIN dr_review_configuration 				AS rconf 	ON  rconf.criterion=rc.review_criterion_id
			INNER JOIN dr_review_group 						AS gro 		ON 	gro.group_id=rc.review_group
			INNER JOIN dr_review_group_history				AS rgh 		ON  rgh.review_group=gro.group_id
			INNER JOIN dr_review_type 						AS rt 		ON 	rt.review_type_id=gro.review_type
			INNER JOIN dr_review_profile 					AS rp 		ON 	rp.review_type=rt.review_type_id
			INNER JOIN dr_review 							AS r 		ON 	r.review_profile=rp.review_profile_id
																		AND r.review_id=rconf.review
			INNER JOIN dr_review_applicability 				AS ra 		ON 	ra.review=r.review_id
			INNER JOIN c_ca 								AS ca 		ON  ca.ca_id=ra.ca
			INNER JOIN c_program 							AS p 		ON 	p.program_id=rp.program
			INNER JOIN c_coe 								AS coe 		ON 	coe.coe_id=rp.coe
			INNER JOIN c_msn 								AS msn 		ON 	msn.msn_id=r.msn
			LEFT  JOIN dr_criteria_status 					AS cs 		ON 	cs.ca=ra.ca
																		AND cs.review_criteria=rc.review_criterion_id
																		AND cs.msn=r.msn
			LEFT  JOIN dr_criteria_status_evidence 			AS cse 		ON  cse.criteria_status=cs.criteria_status_id
			LEFT  JOIN dr_criteria_evidence 				AS ce 		ON 	ce.criteria_evidence_id=cse.criteria_evidence
			LEFT  JOIN dr_criteria_status_provider 			AS csp 		ON 	csp.criteria_status=cs.criteria_status_id
			LEFT  JOIN c_user 								AS u 		ON 	u.user_id=csp.provider
			LEFT  JOIN dr_validation_loop					AS vl 		ON  vl.applicability=cs.criteria_status_id
																		AND vl.object='.$SESSION['object']['criteria_status_id'].'
																		AND vl.action_taken='.$SESSION['user_action']['validated'].'
																		AND vl.action_taken_on!="0000-00-00 00:00:00"
			LEFT  JOIN c_user 								AS u2 		ON 	u2.user_id=vl.validator
			LEFT  JOIN dr_validation_loop					AS vl2 		ON  vl2.applicability=cs.criteria_status_id
																		AND vl2.object='.$SESSION['object']['criteria_status_id'].'
																		AND vl2.action_taken='.$SESSION['user_action']['originated'].'
			LEFT  JOIN dr_review_criterion_applicability	AS rca		ON	rc.review_criterion_id=rca.criterion
			LEFT  JOIN c_grams								AS g		ON	rca.applicability=g.grams_id
																		AND	rca.object='.$SESSION['object']['grams_id'].'
																		AND (rca.review_criterion_applicability_valid_to="0000-00-00 00:00:00" OR rca.review_criterion_applicability_valid_to="0000-00-00 00:00:01")
			WHERE rp.review_profile_id='.$reviewProfile.'
			AND ra.ca IN ('.$ca.')
			AND rch.criterion_valid_from <= r.validation_date
			AND rch.criterion_valid_from != "0000-00-00 00:00:00"
			AND r.msn='.getFilter('msn','filter',0,$SESSION).'
			GROUP BY cs.criteria_status_id ORDER BY rgh.review_group_position ASC, cs.criteria_status DESC';

$rawData=SqlLi($query);

$graphStackedBar		=array();
$graphBurnDown			=array();
$graphPie				=array();
$graphClusteredBar		=array();

$biggestBarStackedBar	=0;
$biggestBarBurnDown		=count($rawData);
$biggestBarClusteredBar	=0;

$reviewTypeName			='';
$caName					=array();
$program				='';
$coe					='';
$msn					='';

if(!empty($rawData))
{
	foreach($rawData as $q=>$z)
	{
		//For stacked bar
		$name=explode(' ', $z['review_group_description']);
		$graphStackedBar[$name[0]]['name']=$name[0];
		if($z['criteria_status']==0 && $z['criterion_showstopper']==1 ) $z['criteria_status']=4;
		$graphStackedBar[$name[0]]['criteria_status'][$z['criteria_status']]++;
		if(array_sum($graphStackedBar[$name[0]]['criteria_status']) > $biggestBarStackedBar) $biggestBarStackedBar=array_sum($graphStackedBar[$name[0]]['criteria_status']);

		//For burn down
		if(!empty($z['week_number']) && $z['criteria_status']==3) 
		{
			$graphBurnDown[$z['week_number']]['week_number']=$z['week_number'];
			$graphBurnDown[$z['week_number']]['total_validated']++;
		}
		if(!empty($z['week_number_planned'])) 
		{
			$graphBurnDown[$z['week_number_planned']]['week_number']=$z['week_number_planned'];
			$graphBurnDown[$z['week_number_planned']]['total_planned']++;
		}

		//For pie charts
		$graphPie[$z['criteria_status']]++;

		//For clustered bar
		$graphClusteredBar[$name[0]]['total_number']++;
		if($graphClusteredBar[$name[0]]['total_number'] > $biggestBarClusteredBar) $biggestBarClusteredBar=$graphClusteredBar[$name[0]]['total_number'];
		if(!empty($z['week_number_planned'])) $graphClusteredBar[$name[0]]['week_number_planned']++;
		if($z['criteria_status']==2 || $z['criteria_status']==3) $graphClusteredBar[$name[0]]['evidence_supplied']++;
		if($z['criteria_status']==3) $graphClusteredBar[$name[0]]['evidence_validated']++;


		//For everything
		$reviewTypeName=$z['review_type'];
		if(!in_array($z['ca_name'],$caName)) array_push($caName, $z['ca_name']);
		$program=$z['program'];
		$coe=$z['coe'];
		$msn=$z['msn'];

	}
}

//The burn down information can come in any order, so we need to sort it by week ASC.
ksort($graphBurnDown);

//The following code adds the missing week numbers.
//Remember that the primary array key is the week number, setup above.

//Reset the internal pointer to the first element in a correctly sorted array.
reset($graphBurnDown);
//Store the key in a variable (so the first week number)
$firstKey=key($graphBurnDown);
//Set internal pointer to the last element of the array.
end($graphBurnDown);
//Store it in another variable.
$lastKey=key($graphBurnDown);

//We can now do a for loop with our new variables.
for ($i=$firstKey; $i < $lastKey; $i++) 
{
	//Check that $i is not going to a week number than doesn't exist.
	//This is for burn downs which go between years.
	//i.e Nov 2014 - Feb 2015, the week numbers will switch from CW 52 to CW 01.
	if(substr($i, -2)==53) $i+=48;

	//If the week number doesn't exists, add it with 0 values.
	if(empty($graphBurnDown[$i])) 
	{
		$graphBurnDown[$i]['week_number']=$i;
		$graphBurnDown[$i]['total_validated']=0;
		$graphBurnDown[$i]['total_planned']=0;
	}
}

//Sort the array asc again just in case the for loop screwed something up.
ksort($graphBurnDown);

$totalValidated=0;
$totalPlanned=0;

//We have the raw values for each week, we now need to add all of the previous weeks together.
//This is hard to explain in words but trust me it works. 
foreach ($graphBurnDown as $week => $details) 
{
	if(date('YW') >= $week)
	{
		$totalValidated+=$graphBurnDown[$week]['total_validated'];
		$graphBurnDown[$week]['total_validated_in_order']=count($rawData)-$totalValidated;
	}
	else $graphBurnDown[$week]['total_validated_in_order']=0;

	$totalPlanned+=$graphBurnDown[$week]['total_planned'];
	$graphBurnDown[$week]['total_planned_in_order']=count($rawData)-$totalPlanned;
}

//This is so the burn down XLSX download works correctly.
$burnDownWeeks=array();
$burnDownActual=array();
$burnDownPredicted=array();

foreach ($graphBurnDown as $week => $details) 
{
	array_push($burnDownWeeks, substr($details['week_number'], -2));
	array_push($burnDownActual, $details['total_validated_in_order']);
	array_push($burnDownPredicted, $details['total_planned_in_order']);
}

//This is so the stack bar XLSX download works correctly.
$stackedGroups	=array();
$stackedPurple	=array();
$stackedRed		=array();
$stackedAmber	=array();
$stackedGreen	=array();
$stackedBlue	=array();

foreach ($graphStackedBar as $group => $details) 
{
	if(empty($details['criteria_status'][4])) $details['criteria_status'][4]=0;
	if(empty($details['criteria_status'][0])) $details['criteria_status'][0]=0;
	if(empty($details['criteria_status'][1])) $details['criteria_status'][1]=0;
	if(empty($details['criteria_status'][2])) $details['criteria_status'][2]=0;
	if(empty($details['criteria_status'][3])) $details['criteria_status'][3]=0;

	array_push($stackedGroups, $details['name']);
	array_push($stackedPurple, $details['criteria_status'][4]);
	array_push($stackedRed, $details['criteria_status'][0]);
	array_push($stackedAmber, $details['criteria_status'][1]);
	array_push($stackedGreen, $details['criteria_status'][2]);
	array_push($stackedBlue, $details['criteria_status'][3]);
}

//For pie chart display
$graphPie=Array($program.' - '.$coe.' - '.$msn.' - '.$reviewTypeName.'\n'.implode(',', $caName).' - CW '.date('W').' Criteria Status Pie',($graphPie[0]+$graphPie[1]+$graphPie[2]+$graphPie[3]),$graphPie[0],$graphPie[1],$graphPie[2],$graphPie[3]);

//For clustered bar display
foreach ($graphClusteredBar as $group => $details) 
{
	if(empty($details['total_number'])) $graphClusteredBar[$group]['total_number']=0;
	if(empty($details['week_number_planned'])) $graphClusteredBar[$group]['week_number_planned']=0;
	if(empty($details['criteria_status'])) $graphClusteredBar[$group]['criteria_status']=0;
	if(empty($details['evidence_validated'])) $graphClusteredBar[$group]['evidence_validated']=0;
}

$title=implode(',', $caName);
if(strlen($title)>30) $title=substr($title, 0,30).'...';

?>OK|||<?php

?><div id="editActionContainer"style="text-align:center;width:960px;"><?php
	?><div class="formHeader"><?php
		?><div class="formHeaderInfo">Review Graphs <?=$program?> - <?=$coe?> - <?=$msn?> - <?=$reviewTypeName?> - <?=$title?> - CW <?=date('W')?></div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="sp"></div><?php

	?><div class="formStdContainer" style="text-align:left;"><?php

		?><input class="stdBtn" style="width:145px" onClick='graphOnClickCa=<?=$ca?>; graphOnClickReviewProfile=<?=$reviewProfile?>; graphThis("poop", <?php echo json_encode($graphBurnDown); ?>, "burnDown", <?=$biggestBarBurnDown?>, <?=count($graphBurnDown)?>);' type="button" value="Burn Down &#9658;"/> <?php
		?><form id="test" style="display: inline;" action="support/graphsDownloadBurndown.php" encType="multipart/form-data" method="post"><?php
			?><input name="title" id="title" type="hidden" value="<?=$program?> - <?=$coe?> - <?=$msn?> - <?=$reviewTypeName?> - <?=$caName?> - CW <?=date('W')?> Burn Down"/><?php
			?><input name="cw" id="cw" type="hidden" value="<?=implode(',', $burnDownWeeks)?>"/><?php
			?><input name="actual" id="actual" type="hidden" value="<?=implode(',', $burnDownActual)?>"/><?php
			?><input name="predicted" id="predicted" type="hidden" value="<?=implode(',', $burnDownPredicted)?>"/><?php
			?><input class="stdBtn" type="submit" style="width:145px" value="Save As Excel (.xlsx) &#9658;"/><?php
		?></form><?php
		if(count($caName)>1) //JFM 11_08_14
		{
			?><form id="test" style="display: inline;" action="support/graphsDownloadBurndownZip.php" encType="multipart/form-data" method="post"><?php
				?><input name="review_profile" id="review_profile" type="hidden" value="<?=$reviewProfile?>"/><?php
				?><input name="ca" id="ca" type="hidden" value="<?=$ca?>"/><?php
				?><input class="stdBtn" type="submit" value="Download individual graphs in ZIP &#9658;"/><?php
			?></form><?php
		}
		?><br /><br /><?php
		?><input class="stdBtn" style="width:145px" onClick='graphOnClickCa=<?=$ca?>; graphOnClickReviewProfile=<?=$reviewProfile?>; graphThis("poop2", <?php echo json_encode($graphStackedBar); ?>, "stackedBar", <?=$biggestBarStackedBar?>, <?=count($graphStackedBar)?>);' type="button" value="Stacked Bar &#9658;"/> <?php
		?><form id="test" style="display: inline;" action="support/graphsDownloadStacked.php" encType="multipart/form-data" method="post"><?php
			?><input name="title" id="title" type="hidden" value="<?=$program?> - <?=$coe?> - <?=$msn?> - <?=$reviewTypeName?> - <?=implode(',', $caName)?> - CW <?=date('W')?> Stacked Bar"/><?php
			?><input name="group" id="group" type="hidden" value="<?=implode(',', $stackedGroups)?>"/><?php
			?><input name="purple" id="purple" type="hidden" value="<?=implode(',', $stackedPurple)?>"/><?php
			?><input name="red" id="red" type="hidden" value="<?=implode(',', $stackedRed)?>"/><?php
			?><input name="amber" id="amber" type="hidden" value="<?=implode(',', $stackedAmber)?>"/><?php
			?><input name="green" id="green" type="hidden" value="<?=implode(',', $stackedGreen)?>"/><?php
			?><input name="blue" id="blue" type="hidden" value="<?=implode(',', $stackedBlue)?>"/><?php
			?><input class="stdBtn" type="submit" style="width:145px" value="Save As Excel (.xlsx) &#9658;"/><?php
		?></form><?php
		if(count($caName)>1) //JFM 11_08_14
		{
			?><form id="test" style="display: inline;" action="support/graphsDownloadStackedZip.php" encType="multipart/form-data" method="post"><?php
				?><input name="review_profile" id="review_profile" type="hidden" value="<?=$reviewProfile?>"/><?php
				?><input name="ca" id="ca" type="hidden" value="<?=$ca?>"/><?php
				?><input class="stdBtn" type="submit" value="Download individual graphs in ZIP &#9658;"/><?php
			?></form><?php
		}
		?><br /><br /><?php
		?><input class="stdBtn" style="width:145px" onClick='graphOnClickCa=<?=$ca?>; graphOnClickReviewProfile=<?=$reviewProfile?>; graphThis("poop3", <?php echo json_encode($graphPie); ?>, "pie", "no");' type="button" value="Pie Chart &#9658;"/> <?php
		?><form id="test" style="display: inline;" action="support/graphsDownload.php" encType="multipart/form-data" method="post"><?php
			?><input name="title" id="title" type="hidden" value="<?=$program?> - <?=$coe?> - <?=$msn?> - <?=$reviewTypeName?> - <?=$caName?> - CW <?=date('W')?> Criteria Status Pie"/><?php
			?><input name="red" id="red" type="hidden" value="<?=$graphPie[2]?>"/><?php
			?><input name="yellow" id="yellow" type="hidden" value="<?=$graphPie[3]?>"/><?php
			?><input name="green" id="green" type="hidden" value="<?=$graphPie[4]?>"/><?php
			?><input name="blue" id="blue" type="hidden" value="<?=$graphPie[5]?>"/><?php
			?><input class="stdBtn" type="submit" style="width:145px" value="Save As Excel (.xlsx) &#9658;"/><br /><?php
		?></form><?php
		/*?><br /><?php
		?><input class="stdBtn" style="width:145px" onClick='graphOnClickCa=<?=$ca?>; graphOnClickReviewProfile=<?=$reviewProfile?>; graphThis("poop4", <?php echo json_encode($graphClusteredBar); ?>, "clusteredBar", <?=$biggestBarClusteredBar?>, <?=count($graphClusteredBar)?>);' type="button" value="Clustered Bar"/> <?php*/
		?><br /><br /><?php
	?></div><?php
	?><div id="graphHolder" name="graphHolder" width="75%"></div><?php
	?><div id="downloadGraphHolder" name="downloadGraphHolder" width="75%"></div><?php
?></div><?php

storeSession($SESSION);
?>