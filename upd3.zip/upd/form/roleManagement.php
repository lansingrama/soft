<?php 
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
$included=1;

/*
* Fetch area_id, area from 'c_area' table
* return array values
*/
$roleNames=SqlLi('SELECT DISTINCT role.responsible_role_id,responsible_role FROM dr_responsible_role As role LEFT JOIN dr_role_assigned_area As roa ON role.responsible_role_id = roa.responsible_role_id ORDER BY responsible_role_id ASC');


?>OK|||<div id="roleContainer" class="sideContainer"><?php

?><div class="formHeader"><?php
?><div class="formHeaderInfo">
<div class="popUpMenu"></div>&nbsp;Role Management</div><?php
?><div class="xDiv" onclick="closeLastForm();">◄ Back</div><?php
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer">
		
		<?php
			?><table class="criteriaTable" style="width:100%;" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup"><?php
			?><td style="width:5%;"><input class="popUpBtnBlue"onClick="popUpOpt('role',['new'],'roleElement');"type="button"value="&#8801;"><div class="popUpMenu"id="popUpRoleDiv_new"></div></td><?php
					?><td style="width:20%;">Role Name</td><?php
					?><td style="width:75%;">Assigned Area</td><?php
				?></tr><?php
				foreach($roleNames as $role){
				?><tr class="" style="margin-bottom:1px solid #ccc"><?php
				?><td style="width:5%;" class="paramDef"><?php
					?><input class="popUpBtn"onClick="popUpOpt('role',['<?=$role['responsible_role_id'];?>','<?=$role['responsible_role'];?>','roleElement']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpRoleDiv_<?=$role['responsible_role_id']?>"></div><?php								
					?><td style="width:25%;"><?php echo $role['responsible_role']; ?></td><?php// }
					?><td style="width:70%;"><?php
					$areaNames = SqlLi('SELECT area.area FROM c_area As area JOIN dr_role_assigned_area As roa ON area.area_id = roa.area WHERE roa.responsible_role_id ='.$role['responsible_role_id']);
					$areas = array();
					foreach ($areaNames as $area) {

						$areas[] = $area['area'];;  // get area value;
					}
            $totArea = implode(',', $areas);echo $totArea; ?></td><?php
			?></tr> <?php }	
			?>  <?php
			?></table><?php
		?></div><?php
			?><div class="sideDetailsContainer"id="sideRoleManagementContainer"><?php
		?><div class="sideContainerEmpty">Select an Element from the list.</div><?php
	?></div><?php
?></div><?php
?></div><?php
storeSession($SESSION);
?>