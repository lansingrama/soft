<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

?>OK|||<?php

?><div id="help_faq" style="padding-right:10px; padding-left:10px;"><?php
	?><div class="formHeader"><?php
		?><div class="formHeaderInfo">DMU QG Tempaltes</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="sp"></div><?php

	?><div style="font-size:14px;" align="left"><?php

		?><div id="help_0"><?php
			?><table class="criteriaTable" style="text-align:center; border:0; width:50%;" align="left" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="100">Download Documents</td><?php
				?></tr><?php

				?><tr><?php
					?><td style="width=20%" class="paramDef"><a href="\\sfs.corp\PROJECTS\A350\DMU_QG_REVIEW_ARCHIVE_A350\DMU_QG_REVIEW_ARCHIVE_A350\Templates\A350_MSNxx_DMU1.1_QGate_CWyy.pptx" target="_blank">				<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width=20%" class="paramDef"><a href="\\sfs.corp\PROJECTS\A350\DMU_QG_REVIEW_ARCHIVE_A350\DMU_QG_REVIEW_ARCHIVE_A350\Templates\A350_MSNxx_DMU2_QGate_CWyy.pptx" target="_blank">					<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width=20%" class="paramDef"><a href="\\sfs.corp\PROJECTS\A350\DMU_QG_REVIEW_ARCHIVE_A350\DMU_QG_REVIEW_ARCHIVE_A350\Templates\A350_MSNxx_DMU3_FAL_Cabin_QG_xxCWxx_V2.pptx" target="_blank">		<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width=20%" class="paramDef"><a href="\\sfs.corp\PROJECTS\A350\DMU_QG_REVIEW_ARCHIVE_A350\DMU_QG_REVIEW_ARCHIVE_A350\Templates\A350_MSNxx_DMU5_Cabin_QG_xxCWxx.pptx" target="_blank">			<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width=20%" class="paramDef"><a href="\\sfs.corp\PROJECTS\A350\DMU_QG_REVIEW_ARCHIVE_A350\DMU_QG_REVIEW_ARCHIVE_A350\Templates\A350_MSNxx_DMU6_QGate_CWyy.pptx" target="_blank">					<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width=20%" class="paramDef"><a href="\\sfs.corp\PROJECTS\A350\DMU_QG_REVIEW_ARCHIVE_A350\DMU_QG_REVIEW_ARCHIVE_A350\Templates\A350_MSNxx_DMU9_QGate_CWyy.pptx" target="_blank">					<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
				?></tr><?php

				?><tr><?php
					?><td>A350 DMU QG 1 / 1.1</td><?php
					?><td>A350 DMU QG 2</td><?php
					?><td>A350 DMU QG 3 FAL Cabin</td><?php
					?><td>A350 DMU QG 5</td><?php
					?><td>A350 DMU QG 6</td><?php
					?><td>A350 DMU QG 9</td><?php
				?></tr><?php
			?></table><?php
		?></div><?php

		
		?><div class="sp"></div><?php

	?></div><?php

?></div><?php
storeSession($SESSION);

?>