<?php
require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
session_start();
$SESSION=$_SESSION;
foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
$included=1;

$revType=SqlAsArr('SELECT rt.review_type_id,rt.review_type
					FROM dr_review_type AS rt
					WHERE review_type_id NOT IN(
						SELECT rt.review_type
						FROM dr_review_profile AS rt
						WHERE program="'.$GET['program'].'"
							AND coe="'.$GET['coe'].'"
					)','review_type_id','review_type');
$revType['new']='New...';

$review=key($revType);

if($review!='new'){
	include('../ajax/validReviewProfile.php');
	/*$program=SqlAsArr('SELECT p.program_id,p.program 
						FROM c_program AS p
							INNER JOIN dr_review_profile AS r ON p.program_id=r.program
						WHERE r.review_type="'.$review.'"
						','program_id','program');*/
	
}

?>OK|||<div id="chooseRevTypeContainer"style="text-align:center;"style="width:380px;"><?php
	?><div class="formStdContainer"style="width:380px;"><?php
		?><div class="xDiv"><img alt="Close this Window" onClick="closeLastForm();"src="../common/img/x.png"style="cursor:pointer;"></div><?php
		?><div class="formHeaderInfo">New Review</div><?php
	?></div><?php
	?><div class="sp"></div><?php
	?><form action="#"enctype="multipart/form-data"id="reviewTypeFrm"method="post"style="display:inline;"><?php
		?><input id="program"name="program"type="hidden"value="<?=$GET['program']?>"><?php
		?><input id="coe"name="coe"type="hidden"value="<?=$GET['coe']?>"><?php
		?><div class="prompt"><?php
			?><table class="criteriaTable" style="width:380px;"><?php
				?><tr class="tableGroup prmRow"><?php
					?><td></td><td>Review Name</td><?php
				?></tr><?php
				drawStdField('New','newReviewType','',46,'','',0,'validateReviewType();',$disabledInput);
			?></table><?php
		?></div><?php
		?><div class="save"><?php
			?><div class="save"><span class="saveResponse"id="reviewType_saveResponse"style="color:#FF0000;">The Review Type already exists</span><?php
			?><input class="stdBtn"<?php if(count($revType)==1)echo'disabled ';?>id="btnNewReviewType"onClick="sendAjaxForm('reviewTypeFrm','ajax/saveReviewType.php','newReviewType','reviewType_saveResponse');"type="button"value="Ok"> <?php
			?><input class="stdBtn"onClick="closeLastForm();"type="button"value="Cancel"><?php
		?></div><?php
	?></form><?php
?></div>