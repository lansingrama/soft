<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');

$GET=cleanArray($_GET);

//$title=($GET['change']=='new')?'New':'Edit';

if($GET['change']!='new' && $GET['change']!=''){
	$change=SqlQ('SELECT change_status,change_type,change_description FROM dr_change WHERE change_id="'.$GET['change'].'"');
}else{
	$change['change_type']=$GET['change_type'];
}

if($GET['change']=='new'){
	$title=($change['change_type']==1)?'Report a new Bug':'Add an Improvement proposal';
}else{
	$title=($change['change_type']==1)?'Edit Bug':'Edit Proposal';
}

?>OK|||<div id="changeContainer"style="float:left;text-align:left;width:800px;"><?php
	formTitle('',$title,'changeContainer','',$popUpParameter='');
	/*?><div class="sp"></div><?php*/
	?><div class="formStdContainer"><?php
		?><form action="#"enctype="multipart/form-data"id="changeFrm"method="post"style="display:inline;"><?php
			?><input id="change_id"name="change_id"type="hidden"value="<?=$GET['change']?>"><?php
			?><input id="change_type"name="change_type"type="hidden"value="<?=$change['change_type']?>"><?php
			?><input id="removeTableCache"name="removeTableCache"type="hidden"value="<?=$GET['removeTableCache']?>"><?php
			?><div class="leftInfoBox"style="margin-top:50px;width:800px;"><?php
				?><table class="criteriaTable"style="width:800px;"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2"><?=($change['change_type']==1)?'Bug':'Improvement'?> Description</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Description</td><?php
						?><td><textarea class="formInput"cols="135"id="change_description"name="change_description"onMouseOver="setInputFocus(this);"rows="7"style="overflow-x:hidden;"><?=$change['change_description']?></textarea></td><?php
					?></tr><?php
				?></table><?php
				?><div class="save"><?php
					$ajaxHandler=($GET['change']=='new')?'showTable':'updateData';
					?><input class="stdBtn"onClick="sendAjaxForm('changeFrm','ajax/saveChange.php','<?=$ajaxHandler?>','');closeLastForm();"type="button"value="Save and Close"><?php
				?></div><?php
			?></div><?php
		?></form><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>