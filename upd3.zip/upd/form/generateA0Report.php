<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);
$GET['a0_report_target']='wp';
$GET['a0_report_group']='zip';
$included=1;

?>OK|||<div id="userManagementContainer"style="text-align:center;width:960px;"><?php
	
	$reviews=allowedReviews($SESSION,'view','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION));
	
	foreach($reviews as $reviewId=>$reviewTypeId){
		$ddReview[$reviewId]=$SESSION['review_type'][$reviewId];
	}
	
	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo">Generate Review Report</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	
	?><form action="support/a0XdpV07.php"enctype="multipart/form-data"id="generateA0ReportFrm"method="post"style="display:inline;"><?php
		?><div class="userOptions"><?php
			?><div style="float:right;position:relative;"><?php
				?><input class="stdBtn"type="submit"value="Generate &#9658;"><?php
			?></div><?php
		?></div><?php
	
		?><input id="a0_report_ca"name="a0_report_ca"type="hidden"value="<?=$GET['a0_report_ca']?>"><?php
		/*?><input id="wp"name="wp"type="hidden"value="<?=implode(',',array_keys($wp))?>"><?php*/
		?><div class="locationSideContainer" style="margin-top:30px;"><?php
			?><div style="float:left;">Review</div><?php
			?><div style="float:right;"><?php
				drawddList('a0_report_review_profile',$ddReview,$GET['a0_report_review_profile'],150,'updateA0ReportPreview()',1);
			?></div><?php
			?><div class="ddSpace"></div><?php
			?><div style="float:left;">Target (<span onMouseOut="nd();"onMouseOver="<?php
				?>overlib('Select <?=$SESSION['table']['review_planning']['ca']['ca']['title']?> if you want to create the Reports per <?=$SESSION['table']['review_planning']['ca']['ca']['title']?>.<br>Select <?=$SESSION['table']['review_planning']['ca']['wp']['title']?> if you want to create them by <?=$SESSION['table']['review_planning']['ca']['wp']['title']?>.');<?php
			?>" style="cursor:pointer;">?</span>)</div><?php
			?><div style="float:right;"><?php
				?><input name="a0_report_target"onClick="updateA0ReportPreview()"type="radio"value="ca"> <?=$SESSION['table']['review_planning']['ca']['ca']['title']?><?php
				?><input checked name="a0_report_target"onClick="updateA0ReportPreview()"type="radio"value="wp"> <?=$SESSION['table']['review_planning']['ca']['wp']['title']?><?php
			?></div><?php
			?><div class="ddSpace"></div><?php
			?><div style="float:left;">Multiple Docs (<span onMouseOut="nd();"onMouseOver="<?php
				?>overlib('This option will be available when the selection applies to a more than one <?=$SESSION['table']['review_planning']['ca']['wp']['title']?> or when the group of <?=$SESSION['table']['review_planning']['ca']['ca']['title']?>s is not the whole <?=$SESSION['table']['review_planning']['ca']['wp']['title']?>.<br><?php
				?>When selecting Group, all selected <?=$SESSION['table']['review_planning']['ca']['ca']['title']?>s will be in the same Review Report. When selecting ZIP, the CAs will be splitted into different Reports and sent in a ZIP file.');<?php
			?>" style="cursor:pointer;">?</span>)</div><?php
			?><div style="float:right;"><?php
				?><input checked name="a0_report_group"onClick="updateA0ReportPreview()"type="radio"value="zip"> ZIP<?php
				?><input name="a0_report_group"onClick="updateA0ReportPreview()"type="radio"value="group"> Group<?php
			?></div><?php
			//JFM 28_10_15
			?><div class="ddSpace"></div><?php
			?><div style="float:left;">Read / Write</div><?php
			?><div style="float:right; text-align:right;"><?php
				?>Read 				<input checked 	name="a0_report_read_write" type="radio" value="read" 		onclick="$('generateA0ReportFrm').action='support/a0XdpV07.php';"><br /><?php
				?>Read Condensed	<input 			name="a0_report_read_write" type="radio" value="condense"	onclick="$('generateA0ReportFrm').action='support/a0XdpV07.php';"><br /><?php
				?>Write 			<input 			name="a0_report_read_write" type="radio" value="write" 		onclick="$('generateA0ReportFrm').action='support/a0Xdp.php';"><?php
			?></div><?php
		?></div><?php
	
		?><div class="sideList"id="reviewList"style="margin-top:200px;"><?php
		?></div><?php
	
		?><div class="sideDetailsContainer"id="a0ReportContentContainer"><?php
			include('../ajax/a0ReportPreview.php');
		?></div><?php
	?></form><?php
?></div><?php
storeSession($SESSION);
?>

