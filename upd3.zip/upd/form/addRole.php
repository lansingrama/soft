<?php 
error_reporting(0);
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
$included=1;

/*
* Fetch area_id, area from 'c_area' table
* return array values
*/
$POST=cleanArray($_GET);
$roleAssigedArea = $POST['role_assigned_area'];
if(is_numeric($POST['responsible_role_id'])){
$selected_roles = sqlLi("SELECT DISTINCT role.responsible_role_id,responsible_role FROM dr_responsible_role As role LEFT JOIN dr_role_assigned_area As roa ON role.responsible_role_id = roa.responsible_role_id WHERE role.responsible_role_id=".$POST['responsible_role_id']);
}
$totalArea = array();
$totalAreaIds = array();
$listAreas=SqlLi('SELECT area,area_id FROM c_area ORDER BY area_id ASC');
foreach($listAreas as $areaVal){
	$totalArea[] = $areaVal['area'];
	$totalAreaIds[] = $areaVal['area_id'];
	
}

$roleQry=SqlAsLi('SELECT count(responsible_role) FROM dr_responsible_role WHERE responsible_role_id ="testRole"');

$roleNames=SqlLi('SELECT DISTINCT role.responsible_role_id,responsible_role FROM dr_responsible_role As role JOIN dr_role_assigned_area As roa ON role.responsible_role_id = roa.responsible_role_id');


?>OK||| <?php

?><div id="edit_roleContainer"><?php

 	?><div class="formHeader"><?php 
		?><div class="formHeaderInfo">Role Management</div><?php
		?><div class="xDiv" onclick="closeLastForm();openForm('roleManagement','',false,'GET')">&#9668; Back</div><?php
	?></div>
	
	<div class="locationSideContainer"><?php
	?><div class="prompt"><?php	
	?><form action="#" enctype="multipart/form-data" id="roleInfoForm" name="roleInfoForm" method="post" style="display:inline;" onsubmit="return false";><?php
				?><div class="save" ><?php
				if(is_numeric($POST['responsible_role_id']))
				{
				?>
				<span class="saveResponse"id="role_saveResponse">Changes were applied</span>
				<input class="stdBtn" id="applyRoleChanges" onClick="sendAjaxForm('roleInfoForm','ajax/saveRoleInfo.php','saveRole','');closeLastForm();openForm('roleManagement','',false,'GET');closeLastForm();openForm('roleManagement','',false,'GET');" type="button" value="Apply Changes &#9658;"><?php
				}
				else {
				?>
				<span class="saveResponse"id="role_saveResponse">Role added successfully!</span>
				<input class="stdBtn" id="applyRoleChanges" onClick="sendAjaxForm('roleInfoForm','ajax/saveRoleInfo.php','saveRole','');closeLastForm();openForm('roleManagement','',false,'GET');closeLastForm();openForm('roleManagement','',false,'GET');" type="button" value="Add Role &#9658;"><?php
				}
				?><input class="stdBtn"onClick="closeLastForm();openForm('roleManagement','',false,'GET');"type="button"value="Cancel &#9658;"><br/><br/><?php
			?><table class="criteriaTable" style="width:380px;" cellspacing="0" cellpadding="5"><?php
			?><tbody><?php
			?><tr class="tableGroup prmRow"><td></td><td>Role Details</td></tr><?php
			?><tr class="infoRow"><?php
			?><td class="paramDef">Role Name</td><?php

			foreach($selected_roles as $role_area){
			}
			?><td><input type="hidden" name="responsible_role_id" id="responsible_role_id" value="<?php echo $POST['responsible_role_id']?>"><?php
			?><input class="textareaWhite" onKeyUp="chkExistingRoleName(roleName);" id="roleName"name="roleName" size="28"type="text" value="<?=$role_area['responsible_role']?>"><?php
			?></td></tr><?php
			?></tbody>
			</table>
			<br/><br/>
	
	
		
	<?php
	if(is_numeric($POST['responsible_role_id']))
	{
	?>
	<table id="dataTable" class="criteriaTable" style="width:380px;">
	<tbody>
	<tr class="tableGroup prmRow">

	<td class="paramDef">
		Assigend Area
	</td>
		<td class="paramDef">
	Remove
	</td>
	</tr>
	<?php 
	if($selected_roles){
	foreach($selected_roles as $key => $role){ 
			$areas = array(); 	// get Area Name
			$areas_id = array();
				$areaNames = SqlLi('SELECT area.area,area.area_id FROM c_area As area JOIN dr_role_assigned_area As roa ON area.area_id = roa.area WHERE roa.responsible_role_id ='.$role['responsible_role_id']);  /// get Area name
					//exit;					
						foreach ($areaNames as $area) {
							
							$areas[] = $area['area'];
							$areas_id[] = $area['area_id'];
						   
          
			?>
		<tr class="infoRow">
					
			<td class="paramDef"><input style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;padding: 5px;background: no-repeat;border: none;" type="text" name="multiple_areas" id="multiple_areas<?php echo $area['area_id']; ?>" value="<?php echo $area['area']; ?>"/></td>
			<td style="padding:5px;background-color:#e7e7e8;" class="paramDef"><input style="margin-left:8px;" value="<?php echo $area['area_id']; ?>-<?php echo $area['area']; ?>" type="checkbox" name="chk" class="removeAreaIds" id="chk" onclick="deleteRow(this)" /></td>
		</tr>
		
	
	<?php   }
							
				$areaIds = SqlLi('SELECT area FROM dr_role_assigned_area WHERE responsible_role_id ='.$role['responsible_role_id']);  /// get Area ID
				$getAreaIds = array(); // get Area Id
			
				foreach ($areaIds as $areIds){
					$getAreaIds[] = $areIds['area'];
				}
					
					$displayIds =implode(',',$getAreaIds);	

					$unmappedAreaName = array_diff($totalArea,$areas);
					$unmappedAreaId = array_diff($totalAreaIds,$areas_id);
					///var_dump($unmappedAreaId);
		} 
	}?>
			<tr class="infoRow">
					
			<td style="display:none"><input style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;padding: 5px;background: no-repeat;border: none;" type="text" name="multiple_areas" id="multiple_areas<?php echo $area['area_id']; ?>" value="<?php echo $area['area']; ?>"/></td>
			<td style="display:none;padding:5px;background-color:#e7e7e8;" ><input style="margin-left:8px;" value="<?php echo $area['area_id']; ?>" type="checkbox" name="chk" id="chk" class="removeAreaIds" onclick="deleteRow(this)" /></td>
		</tr>
		<input id="screen_value" type="hidden" name="screen_value" value="<?php echo $displayIds ?>">

	<input id="screen" type="hidden" name="screen" value="">
		</tbody>
	</table>
		<br/><br/>
	<div class="assigned_areas" style="text-align:left">
		<label style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;">Area :&nbsp;&nbsp;</label>
	<select id="assigned_area" name="assigned_area" style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;">
	<?php foreach($unmappedAreaId as $index => $area)
							{
								
								?><option id="<?php echo $area?>" value="<?php echo $area?>"><?php echo $unmappedAreaName[$index]?></option><?php
							}
	?>
	
	</select>
	
		<INPUT class="stdBtn" type="button" value="Add Area &#9658;" onclick="addRow('dataTable')" />
		</div>
	<?php }
	
	else { ?>
	<input id="screen" type="hidden" name="screen" value="">
	
	<table id="dataTable" class="criteriaTable" style="width:380px;" >
	<tbody>
	<tr class="tableGroup prmRow">
	<td class="paramDef">Assigned Area</td>
	<td class="paramDef">Remove</td>
	</tr>
		<tr class="infoRow">
					
			<td style="display:none"><input style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;padding: 5px;background: no-repeat;border: none;" type="text" name="multiple_areas" id="multiple_areas<?php echo $area['area_id']; ?>" value="<?php echo $area['area']; ?>"/></td>
			<td style="display:none;padding:5px;background-color:#e7e7e8;" ><input style="margin-left:8px;" value="<?php echo $area['area_id']; ?>" type="checkbox" name="chk" id="chk" class="removeAreaIds" onclick="deleteRow(this)" /></td>
		</tr>
		</tbody>
	</table>
		<br/><br/>
	<div class="assigned_areas" style="text-align:left">
		<label style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;">Area :&nbsp;&nbsp;</label>
	<select id="assigned_area" name="assigned_area" style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;">
	<?php foreach($listAreas as $area)
							{
								
								?><option id="<?=$area['area_id']?>" value="<?=$area['area_id']?>"><?=$area['area']?></option><?php
							}
	?>
	
	</select>
	
		<input class="stdBtn" type="button" value="Add Area &#9658;" onclick="addRow('dataTable')" />
		</div>
		<br/>
	<?php } 
	?><span id="addRole_saveResponse" style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;color:#FF0000;display:none;text-align:left;padding-top:10px;">WARNING! - Role name already exists.</span><?php
	
	?>

</form><?php
			?></div><?php
		?></div><?php
?></div>


<?php
storeSession($SESSION);

?>