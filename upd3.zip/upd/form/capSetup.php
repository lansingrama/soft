<?php
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');
$GET=cleanArray($_GET);

//print_r($GET);

$reviewProfile=$GET['review_profile'];

if(isset($GET['msn'])) $msn=$GET['msn'];
else $msn=getFilter('msn','filter',0,$SESSION);

//JFM 16_09_13				
$reviewID=SqlLi('SELECT review_id, validation_date, continuous_assessment
					FROM dr_review AS r
						INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
						INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
					WHERE rp.review_profile_id='.$reviewProfile.'
					AND ra.ca IN ('.$GET['ca'].')
					AND r.msn='.$msn);
				
//JFM 09_04_14	
$criteria=SqlAsLi('SELECT DISTINCT rgh.review_group,rgh.review_group_description,rgh.review_group_position,
									rconf.disabled, rconf.position AS criterion_position,
									rc.review_criterion_id, rch.criterion_name, rch.criterion_description, rch.criterion_user_id, rch.criterion_showstopper, rch.criterion_moc, rch.criterion_valid_from,
									GROUP_CONCAT(g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS criterion_reference
					FROM dr_review_criterion_history AS rch 
						INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
						INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
						INNER JOIN 
									(
										SELECT review_group,review_group_description,review_group_position,review_group_valid_from 
												FROM dr_review_group_history 
												WHERE review_group_valid_from <= "'.$reviewID[0]['validation_date'].'" 
												ORDER BY review_group_valid_from DESC
									) AS rgh ON rgh.review_group=rg.group_id 
						INNER JOIN dr_review_configuration	AS rconf	ON rc.review_criterion_id = rconf.criterion
						INNER JOIN dr_review				AS r		ON r.review_id=rconf.review
						INNER JOIN dr_review_applicability	AS ra		ON r.review_id=ra.review
						INNER JOIN dr_review_profile		AS rp 		ON rp.review_profile_id=r.review_profile
						LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
						LEFT  JOIN c_grams					AS g		ON	rca.applicability=g.grams_id
																		AND	rca.object='.$SESSION['object']['grams_id'].'
																		AND rca.review_criterion_applicability_valid_from <= "'.$reviewID[0]['validation_date'].'"
					WHERE rp.review_profile_id='.$reviewProfile.'
					AND ra.ca IN ('.$GET['ca'].')
					AND r.msn='.$msn.'
					AND rch.criterion_valid_from <= "'.$reviewID[0]['validation_date'].'"
					AND rch.criterion_valid_from != "0000-00-00 00:00:00"
					GROUP BY rch.criterion_validity_id
					ORDER BY rgh.review_group_position ASC, rconf.position ASC','review_criterion_id'); //DEFAULT - GOOD! JFM 04_03_14 - 11_03_14
				   

function item10($item) { return $item['review_id']; }
$reviewIdsMap=array_map('item10', $reviewID);
$allCas=SqlSLi('SELECT ca FROM dr_review_applicability WHERE review IN ('.implode(',',$reviewIdsMap).')','ca');

$criteriaStatusQry=mysql_query('SELECT DISTINCT s.review_criteria,s.ca,s.criteria_status_id,s.criteria_status,s.criteria_focal_point,s.criteria_comments, s.criteria_planned, GROUP_CONCAT(DISTINCT csp.provider) AS provider, GROUP_CONCAT(DISTINCT vl.validator) AS stakeholder
								FROM c_ca AS ca
									LEFT JOIN dr_criteria_status AS s ON ca.ca_id=s.ca
									LEFT JOIN dr_criteria_status_provider AS csp ON csp.criteria_status=s.criteria_status_id
									LEFT JOIN dr_validation_loop_structure AS vl ON vl.applicability=s.criteria_status_id
																				AND vl.object='.$SESSION['object']['criteria_status_id'].'
									INNER JOIN dr_review_configuration AS c ON s.review_criteria=c.criterion
									INNER JOIN dr_review AS g ON c.review=g.review_id
								WHERE s.msn="'.$msn.'"
								AND ca.ca_id IN('.implode(',',$allCas).')
								AND g.review_profile="'.$reviewProfile.'"
								GROUP BY review_criteria',$p12) or die(mysql_error());

while($c=mysql_fetch_assoc($criteriaStatusQry))
{
	foreach($c as $k=>$v)
	{
		$criteriaStatus[$c['review_criteria']][$GET['ca']][$k]=$v;
	}
}

$allCriteriaStatusIds=array();
	
if(is_array($criteriaStatus))
{
	foreach($criteriaStatus as $k=>&$v)
	{
		$criteria[$k]['criteria_status_id']=combinedResult($v,'criteria_status_id','id',$SESSION);
		$criteria[$k]['criteria_status']=combinedResult($v,'criteria_status','status',$SESSION);
		$criteria[$k]['criteria_focal_point']=combinedResult($v,'criteria_focal_point','text',$SESSION);
		$criteria[$k]['criteria_comments']=combinedResult($v,'criteria_comments','text',$SESSION);
		$criteria[$k]['criteria_planned']=(combinedResult($v,'criteria_planned','text',$SESSION)=='0000-00-00')?'':combinedResult($v,'criteria_planned','text',$SESSION);
		$criteria[$k]['provider']=combinedResult($v,'provider','text',$SESSION);
		$criteria[$k]['stakeholder']=combinedResult($v,'stakeholder','text',$SESSION);

		array_push($allCriteriaStatusIds, $criteria[$k]['criteria_status_id']);
	}
}

if(!empty($allCriteriaStatusIds))
{
	$overridersQry=SqlLi('SELECT DISTINCT CONCAT(u.surname,\', \',u.name) AS overrider_full_name, user_id
										FROM c_user as u 
											INNER JOIN dr_validation_loop_override AS vlo ON u.user_id=vlo.user
										WHERE vlo.applicability IN ('.implode(',', $allCriteriaStatusIds).')
										AND vlo.object='.$SESSION['object']['criteria_status_id']);
}

?>OK|||<?php
?><div class="formHeader"><?php
	?><div class="formHeaderInfo">Continous Assessment Process Setup</div><?php
	?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
?></div><?php

?><div class="formStdContainer" style="margin-top:70px;"><?php
	?><form action="#"enctype="multipart/form-data"id="criteriaStatusFrm"method="post"style="display:inline;"><?php
		?><input id="ca"name="ca"type="hidden"value="<?=$GET['ca']?>"><?php
		?><input id="criteriaCriteriaTable0"name="criteriaCriteriaTable0"type="hidden"value="<?=$GET['review_criteria_id']?>"><?php
		?><input id="criteria_status"name="criteria_status"type="hidden" value="<?=$status[$criteria['criteria_status']]?>"><?php
		?><input id="review_profile"name="review_profile"type="hidden" value="<?=$GET['review_profile']?>"><?php
		?><input id="continuous_assessment"name="continuous_assessment"type="hidden" value="<?=$GET['continuous_assessment']?>"><?php
		?><input id="all_criteria_status_ids" name="all_criteria_status_ids" type="hidden" value="<?=implode(',', $allCriteriaStatusIds)?>"><?php


		?><table class="criteriaTable" align="left" cellspacing="0" cellpadding="5" width="400px;"><?php
			?><tr class="tableGroup"><?php
				?><td colspan="2">Continous Assessment</td><?php
			?></tr><?php
			?><tr class="infoRow"><?php
				?><td class="paramDef">Active</td><?php
				?><td><input id="continuousassessment_<?=$reviewID[0]['review_id']?>" onclick="if(confirm('Are you sure?')){checkChange(this,'cont');}" type="checkbox" value="1" <?php if($reviewID[0]['continuous_assessment']==1) echo' checked="checked"'; if(checkPermission('continuous_assessment','create',0,'check',$SESSION)!=1) echo 'disabled="disabled"';?>/></td><?php
			?></tr><?php
		?></table><?php

		?><div style="height:10px; clear:both;"></div><?php

		?><table class="criteriaTable" align="left" cellspacing="0" cellpadding="5" width="400px;"><?php
			?><tr class="tableGroup"><?php
				?><td colspan="2">Validation Overriders</td><?php
			?></tr><?php
			?><tr><?php
				?><td colspan="2">Setting a validation overrider will effect every single criteria in this review, regardless of which items are checked in the criteria table below.</td><?php
			?></tr><?php
		?></table><?php

		//
		// Overrider List
		//
		?><table class="criteriaTable" id="criteriaoverridersTable" align="left" cellspacing="0" cellpadding="5" width="400px;"><?php
			?><tr class="infoRow"><?php
				?><td class="paramDef" rowspan="100" width="15%">Overriders<div id="overriderResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
			?></tr><?php
			
			$i=0;
			if(!empty($overridersQry))
			{
				foreach($overridersQry as $overrider)
				{
					?><tr id="rowoverridersinputID<?=$i?>"><?php
						?><td width="35%" valign="top"><?php
							?><div class="suggestion"id="overridersdivID<?=$i?>"style="width:159px;"></div><?php
							?><input class="textareaWhite" id="overridersinputID<?=$i?>"name="overridersinputID<?=$i?>" value="<?=utf8_encode($overrider['overrider_full_name'])?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaoverridersTable','overridersdivID','overridersinputID','overriderssuggestionID');" onFocus="loadUserSuggestion(this,'overridersdivID<?=$i?>','overridersinputID<?=$i?>','','overriderssuggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
							?><input class="xRemove" onClick="deleteRowByInputID('overridersinputID<?=$i?>','criteriaoverridersTable');" type="button" value="&#10008;"/><?php
						?></td><?php
					?></tr><?php
					$i++;
				}
			}
		
			?><tr id="rowoverridersinputID<?=$i?>"><?php
				?><td width="35%" valign="top"><?php
					?><div class="suggestion"id="overridersdivID<?=$i?>"style="width:159px;"></div><?php
					?><input class="textareaWhite" id="overridersinputID<?=$i?>"name="overridersinputID<?=$i?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaoverridersTable','overridersdivID','overridersinputID','overriderssuggestionID');" onFocus="loadUserSuggestion(this,'overridersdivID<?=$i?>','overridersinputID<?=$i?>','','overriderssuggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
					?><input class="xRemove" onClick="deleteRowByInputID('overridersinputID<?=$i?>','criteriaoverridersTable');" type="button" value="&#10008;"/><?php
				?></td><?php
			?></tr><?php
		?></table><?php

		?><div style="height:10px; clear:both;"></div><?php

		?><table class="criteriaTable" align="left" cellspacing="0" cellpadding="5" width="400px;"><?php
			?><tr class="tableGroup"><?php
				?><td colspan="2">Batch Names to Change</td><?php
			?></tr><?php
			?><tr><?php
				?><td colspan="2">If inputs are left blank, the current providers / stakeholders which have already been set will not be changed.</td><?php
			?></tr><?php
		?></table><?php

		//
		// Provider List
		//
		?><table class="criteriaTable" id="criteriaprovidersTable" align="left" cellspacing="0" cellpadding="5" width="400px;"><?php
			?><tr class="infoRow"><?php
				?><td class="paramDef" rowspan="100" width="15%">Providers<div id="providerResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
			?></tr><?php
			
			?><tr id="rowprovidersinputID0"><?php
				?><td width="35%" valign="top"><?php
					?><div class="suggestion"id="providersdivID0"style="width:159px;"></div><?php
					?><input class="textareaWhite" id="providersinputID0"name="providersinputID0" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaprovidersTable','providersdivID','providersinputID','providerssuggestionID');" onFocus="loadUserSuggestion(this,'providersdivID0','providersinputID0','','providerssuggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
					?><input class="xRemove" onClick="deleteRowByInputID('providersinputID0','criteriaprovidersTable');" type="button" value="&#10008;"/><?php
				?></td><?php
			?></tr><?php
		?></table><?php

		//
		// Validation List
		//
		
		?><table class="criteriaTable" id="criteriaValidatorsTable" align="left" cellspacing="0" cellpadding="5" width="400px;"><?php
			?><tr class="infoRow" width="55px;"><?php
				?><td class="paramDef" rowspan="100" width="15%">Stakeholders<div id="inputIDResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
			?></tr><?php	
			?><tr id="rowelephantTigerBeehiveinputID0"><?php
				?><td width="35%" valign="top"><?php
					?><div class="suggestion"id="divID0"style="width:159px;"></div><?php
					?><input class="textareaWhite" id="elephantTigerBeehiveinputID0"name="elephantTigerBeehiveinputID0" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaValidatorsTable','divID','elephantTigerBeehiveinputID','suggestionID');" onFocus="loadUserSuggestion(this,'divID0','elephantTigerBeehiveinputID0','','suggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
					?><input class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehiveinputID0','criteriaValidatorsTable');" type="button" value="&#10008;"/><?php
				?></td><?php
			?></tr><?php
		?></table><?php

		?><div class="save" style="float:left;"><input class="stdBtn" style="display:inline;" onClick="if(confirm('WARNING!\n\nThis will effect all of the criteria selected for batch change names and EVERY criteria in validation overriders.\n\nAre you sure you wish to continue?')){sendAjaxForm('criteriaStatusFrm','ajax/saveCapSetup.php','updateData','criteriaStatus_saveResponse'); }"type="button"value="Apply Changes &#9658;" /></div><?php
		
		?><div class="sp"></div><?php 

		?><table class="criteriaTable"id="criteriaTable" cellspacing="0"><?php

			?><tr class="tableGroup"><?php
				?><td width="5%">Check</td><?php
				?><td width="5%">ID</td><?php
				?><td width="30%">Name</td><?php
				?><td width="30%">MoC</td><?php
				?><td width="0%">Desc.</td><?php
			?></tr><?php

			foreach($criteria as $q=>$c)
			{
				if($c['criteria_status']>1) continue;

				?><tr class="infoRow" id="criteriaRow-<?=$c['review_group']?>-<?=$c['review_criterion_id']?>" style="background-color:<?=$revConfigColor[$rowColor]?>;"><?php
					?><td id="???"><input type="checkbox" id="checkbox_<?=$c['criteria_status_id']?>" name="checkbox_<?=$c['criteria_status_id']?>" /><?=$c['criteria_status_id']?></td><?php
					?><td id="criteria_user_id_<?=$c['review_criterion_id']?>"><?=$c['criterion_user_id']?></td><?php
					?><td id="criteria_name_<?=$c['review_criterion_id']?>"><?=$c['criterion_name']?></td><?php
					?><td id="criteria_moc_<?=$c['review_criterion_id']?>"><?=$c['criterion_moc']?></td><?php
					?><td id="criteria_description_<?=$c['review_criterion_id']?>"><?=$c['criterion_description']?></td><?php
				?></tr><?php
			}
		?></table><?php
	?></form><?php
?></div><?php

storeSession($SESSION);?>