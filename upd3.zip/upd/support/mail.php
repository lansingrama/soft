<?php

function checkSendInvitation($userId,&$SESSION){
	if($SESSION['edit_user']['active_permission']==1 && $SESSION['edit_user']['user_invited']==0){

		$user=SqlQ('SELECT user_key,login,name,surname,email FROM c_user WHERE user_id="'.$userId.'"');
		
		$emptyFieldFound=0;
		if(is_array($user)){
			foreach($user as $u){
				if($u==''){
					$emptyFieldFound=1;
				}
			}
		}else{
			$emptyFieldFound=1;
		}
		
		if($emptyFieldFound==0){ //JFM 16_01_15
			$title='Welcome to the Airbus Review Tool';
			$message='<strong>Dear '.$user['name'].' '.$user['surname'].',</strong><br>
						<p>
						You have been granted access to the Airbus Review Tool.<br><br>
						Your login is <strong>'.$user['login'].'</strong>,
						</p>
						To login to the tool, please click the link below:<br>
						<a href="http://art-int.eu.airbus.corp/1V55">
						http://art-int.eu.airbus.corp/1V55</a><br><br>
						Please, do not reply to this message.<br>
						<br><br><br>
						Best Regards,<br><br>
						Airbus Review Tool Team.';
			
			mail($user['email'],'Welcome to the Airbus Review Tool',mailMessageBox($title,'',$message),mailHeader());
			
			$viewAsUserId=($SESSION['user']['view_as']=='')?$SESSION['user']['user_id']:$SESSION['user']['view_as'];
			SqlLQ('INSERT INTO c_user_invitation (user,invited_by) VALUES ("'.$userId.'","'.$viewAsUserId.'")');
			
			$SESSION['edit_user']['user_invited']=1;
			
			return 1;
		}
	}
}

function mailHeader($cc='',$bcc=''){
	return "MIME-Version: 1.0\r\n".
			"Content-type: text/html; charset=iso-8859-1\r\n".
			"From: Airbus No Reply <noreply@airbus.com>\r\n".
			"Reply-To: noreply@airbus.com\r\n".
			"Return-path: noreply@airbus.com\r\n".
			"Cc: $cc\r\n".
			"Bcc: $bcc\r\n";
}

function mailMessageBox($title='',$title2='',$message=''){
	return '<html>
			<head>
				<title>'.$title.'</title>
			</head>
			<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
				<div style="width:700px; height: 300px; cellSpacing=1; cellPadding=0; border=0;">
				<table align="center">
				  <tr>
					<td width="700"style="background-color:#C3CDDC;color:#565C6A;font-family:Verdana, Arial, Helvetica, sans-serif;font-size:11px;font-weight:bold;padding-left:10px;">'.$title2.'</td>
				</tr>
				<tr>
					<td width="700"heigth="300"style="border-style:solid;border-color:#CCCCCC;border-width:1px;font-family:Verdana, Arial, Helvetica, sans-serif;font-size:11px;padding-left:10px;">'.$message.'</td>
				  </tr>
				</table>
			</div>
			</body>
			</html>';
}
function parseText($txt){
	return str_replace(array("'",'"',chr(13)),array('&#39;','&#34;','<br>'),stripslashes($txt));
}

function sendErrorReportToAdmin($rt, $rq, $viewAsUserId) //JFM 15_09_15 - JFM 12_01_16
{
	$title='ART User Error - Automatic Email.';
	$message='<strong>User: </strong>'.$viewAsUserId.'<br><br>
				<strong>From AJAX: </strong>'.$rq.'<br><br>
				<strong>Error Message: </strong>'.$rt.'<br>';
	
	mail('sivakumar.ganesan.external@airbus.com','ART User Error - Automatic Email.',mailMessageBox($title,'',$message),mailHeader());
}


function sendThemMailings($object, $whatDone, $message, $doSomething, $subject, $email, $firstname, $lastname) //JFM 28_10_15
{
	if(!empty($object) && !empty($whatDone) && !empty($message) && !empty($doSomething) && !empty($subject) && !empty($email))
	{
		$headers="MIME-Version: 1.0\r\n";
		$headers.="Content-type: text/html; charset=utf-8\r\n";
		$headers.="From: Airbus No Reply <noreply@airbus.com>\r\n"; 
		$headers.="Reply-To: noreply@airbus.com\r\n"; 
		$headers.="Return-path: noreply@airbus.com\r\n";
		$headers.="Cc: \r\n";
		$headers.="Bcc: \r\n";

		$mailBody='<html>
						<head>
							<title>'.$object.' '.$whatDone.'</title>
						</head>
						<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
							<div style="width: 100%; height: 300px; cellSpacing=0; cellPadding=5; border=0;">
							<table align="center">
							  <tr>
								<td style="background-color:#6f95ab;color:#FFFFFF;font-family:Verdana,Arial,Helvetica,sans-serif;font-size:11px;font-weight:normal;padding-left:10px;">
									'.$object.' '.$whatDone.'
								</td>	
							</tr>
							<tr>
								<td style="border-width:0px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; padding-left:10px;">
									<strong>Dear '.$firstname.' '.$lastname.',</strong><br>
									<p>
									'.$message.' 
									</p>
									Click the link below to login and '.$doSomething.':<br>
									<a href="http://art-int.eu.airbus.corp/1V55">
									http://art-int.eu.airbus.corp/1V55</a><br><br>
									Please do not reply to this message.<br>
									<br><br><br>
									Best Regards,<br><br>
									Airbus Review Tool Team.
								</td>
							  </tr>
							</table>
						</div>
						</body>
					</html>';

		//TEST
		/*$fp=fopen('../output/email_test_'.date('Y_m_d_h_i_s_u').'.html','w');
		fwrite($fp,'HEADERS: '.$headers.'<br><br>');
		fwrite($fp,'EMAIL TO: '.$email.'<br><br>');
		fwrite($fp,'SUBJECT: '.$subject.'<br><br>');
		fwrite($fp,$mailBody);
		fclose($fp);
*/
		mail($email,$subject,$mailBody,$headers);
	}	
}

?>