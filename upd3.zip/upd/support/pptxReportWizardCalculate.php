<?php

require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../../common/php/zip.lib.php');
require_once('localSupport.php');
require_once('form.php');

function formatValueForXML($string)
{
	return utf8_encode(str_replace("&#8230;", "",str_replace(">", "&gt;",str_replace("<", "&lt;",str_replace("&", "&amp;", $string)))));
}

$POST = cleanArray($_POST);

//SETUP IDS
//---------------------------------------------------
$program=implode(',', $POST['program']);
$coe=implode(',', $POST['coe']);
$msn=implode(',', $POST['msn']);
$reviewType=implode(',', $POST['review_type']);
$ca=implode(',', $POST['ca']);
$msn=implode(',', $POST['msn']);

$statusColourMap = array(0 => 'ef343f', 1 => 'f8d707', 2 => '81c341', 3 => '008cf');
$wingdingsMap = array(0 => ' ', 1 => 'i', 2 => 'm', 3 => 'g', 4 => 'k', 5 => 'h');
$progressColourMap = array(0 => '000000', 1 => 'ef343f', 2 => 'ef343f', 3 => 'f8d707', 4 => '008cf', 5 => '008cf');


$caNames=SqlSLi('SELECT ca FROM c_ca WHERE ca_id IN ('.$ca.')','ca');
$allCaNames=formatValueForXML(implode(',', $caNames));

$reviewProfileQry=SqlSLi('SELECT review_profile_id FROM dr_review_profile 
					WHERE program IN ('.$program.')
					AND coe IN ('.$coe.')
					AND review_type IN ('.$reviewType.')', 'review_profile_id');

$reviewProfile=implode(',', $reviewProfileQry);

//CALCULATE REVIEW
//---------------------------------------------------
$reviewID=SqlLi('SELECT r.review_id, r.review_done, r.validation_date, r.continuous_assessment, r.review_status, 
						msn.msn, 
						coe.coe, 
						pro.program, 
						rt.review_type, 
						ca.ca, 
						per.perimeter,
						act.action_id, act.action_status, act.action_code, act.action_description, act.action_remark, act.action_completion, act.action_holder_name, act.action_validator_name,
						CONCAT(u1.name," ",u1.surname) AS action_holder_txt, CONCAT(u2.name," ",u2.surname) AS action_validator_txt,
						rsk.risk_id, rsk.risk_status, rsk.risk_code, rsk.risk_description, rsk.risk_action, rsk.risk_remarks, rsk.risk_holder_name, rsk.severity, rsk.occurrence, rsk.detection,
						CONCAT(u3.name," ",u3.surname) AS risk_holder_txt,
						cas.odd, cas.id, cas.progress_trend
						FROM dr_review AS r
							INNER JOIN dr_review_applicability 		AS ra 	ON 	r.review_id=ra.review
							INNER JOIN c_ca 						AS ca 	ON 	ca.ca_id=ra.ca
							INNER JOIN c_perimeter 					AS per 	ON 	per.perimeter_id=ca.perimeter
							INNER JOIN dr_review_profile 			AS rp 	ON 	r.review_profile=rp.review_profile_id
							INNER JOIN c_coe 						AS coe 	ON 	coe.coe_id=rp.coe
							INNER JOIN c_program 					AS pro 	ON 	pro.program_id=rp.program
							INNER JOIN c_msn 						AS msn 	ON 	msn.msn_id=r.msn
							INNER JOIN dr_review_type 				AS rt 	ON 	rt.review_type_id=rp.review_type
							LEFT JOIN dr_action_applicability 		AS aa 	ON 	aa.ca=ca.ca_id
							LEFT JOIN dr_action 					AS act 	ON  (act.review = r.review_id OR act.action_id = aa.action)
																			AND act.msn = msn.msn_id
																			AND act.action_id=aa.action
							LEFT JOIN c_user 						AS u1 	ON 	u1.user_id=act.action_holder
							LEFT JOIN c_user 						AS u2 	ON  u2.user_id=act.action_validator
							LEFT JOIN dr_risk 						AS rsk 	ON  rsk.ca=ca.ca_id
							LEFT JOIN c_user 						AS u3 	ON  u3.user_id=rsk.risk_holder
							LEFT JOIN dr_ca_status 					AS cas 	ON 	cas.ca=ca.ca_id

						WHERE rp.review_profile_id IN ('.$reviewProfile.')
						AND ra.ca IN ('.$ca.')
						AND r.msn IN ('.$msn.')
						AND r.validation_complete = 2
						and r.review_done = 1
						ORDER BY rp.review_profile_order, pro.program, coe.coe, msn.msn, ca.ca, act.action_code');
//94.87%
//73.58%

/*echo 'SELECT r.review_id, r.review_done, r.validation_date, r.continuous_assessment, r.review_status, 
						msn.msn, 
						coe.coe, 
						pro.program, 
						rt.review_type, 
						ca.ca, 
						per.perimeter,
						cs.criteria_status,
						rch.criterion_moc,
						act.action_id, act.action_status, act.action_code, act.action_description, act.action_remark, act.action_completion, act.action_holder_name, act.action_validator_name,
						CONCAT(u1.name," ",u1.surname) AS action_holder_txt, CONCAT(u2.name," ",u2.surname) AS action_validator_txt,
						rsk.risk_id, rsk.risk_status, rsk.risk_code, rsk.risk_description, rsk.risk_action, rsk.risk_remarks, rsk.risk_holder_name, rsk.severity, rsk.occurrence, rsk.detection,
						CONCAT(u3.name," ",u3.surname) AS risk_holder_txt,
						cas.odd, cas.id, cas.progress_trend
						FROM dr_review AS r
							INNER JOIN dr_review_applicability 		AS ra 	ON 	r.review_id=ra.review
							INNER JOIN c_ca 						AS ca 	ON 	ca.ca_id=ra.ca
							INNER JOIN c_perimeter 					AS per 	ON 	per.perimeter_id=ca.perimeter
							INNER JOIN dr_review_profile 			AS rp 	ON 	r.review_profile=rp.review_profile_id
							INNER JOIN c_coe 						AS coe 	ON 	coe.coe_id=rp.coe
							INNER JOIN c_program 					AS pro 	ON 	pro.program_id=rp.program
							INNER JOIN c_msn 						AS msn 	ON 	msn.msn_id=r.msn
							INNER JOIN dr_review_type 				AS rt 	ON 	rt.review_type_id=rp.review_type
							LEFT JOIN dr_criteria_status 			AS cs 	ON 	cs.ca = ca.ca_id
																			AND cs.msn = msn.msn_id
							INNER JOIN dr_review_configuration 		AS rc 	ON 	rc.review=r.review_id
																			AND rc.criterion=cs.review_criteria
							INNER JOIN dr_review_criterion_history	AS rch 	ON 	rch.criterion=rc.criterion
																			AND rch.criterion_valid_from <= r.validation_date
																			AND rch.criterion_valid_from != "0000-00-00 00:00:00"
																			AND rch.criterion_valid_to <= r.validation_date
							LEFT JOIN dr_action_applicability 		AS aa 	ON 	aa.ca=ca.ca_id
							LEFT JOIN dr_action 					AS act 	ON  (act.review = r.review_id OR act.criteria = rc.criterion)
																			AND act.msn = msn.msn_id
																			AND act.action_id=aa.action
							LEFT JOIN c_user 						AS u1 	ON 	u1.user_id=act.action_holder
							LEFT JOIN c_user 						AS u2 	ON  u2.user_id=act.action_validator
							LEFT JOIN dr_risk 						AS rsk 	ON  rsk.ca=ca.ca_id
							LEFT JOIN c_user 						AS u3 	ON  u3.user_id=rsk.risk_holder
							LEFT JOIN dr_ca_status 					AS cas 	ON 	cas.ca=ca.ca_id

						WHERE rp.review_profile_id IN ('.$reviewProfile.')
						AND ra.ca IN ('.$ca.')
						AND r.msn IN ('.$msn.')
						AND r.validation_complete = 2
						and r.review_done = 1
						ORDER BY rp.review_profile_order, pro.program, coe.coe, msn.msn, ca.ca, act.action_code';*/


$graphPie = array();
$reviewTypeNames = array();
$reviewBetterFormatted = array();
$alreadyAddedActions = array();
$alreadyAddedRisks = array();

$priorityMap=array('Low' => 1, 'Medium' => 2, 'High' => 3);

if(!empty($reviewID))
{
	foreach($reviewID as $q=>$z)
	{
		if($z['odd']=="0000-00-00") 
			$z['odd'] = 'Not Set';
		if($z['id']=="0000-00-00") 
			$z['id'] = 'Not Set';

		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['odd']['odd'] = $z['odd'];
		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['id']['id'] = $z['id'];
		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend'] = $z['progress_trend'];

		$reviewTypeNames[$z['review_type']]++;

		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['status']=$z['review_status'];
		//$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']][$z['criteria_status']]++;
		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['total']+=$priorityMap[$z['criterion_moc']];

		if($z['criteria_status'] != '' && isset($z['criteria_status']) && $z['criteria_status']>0 && $z['criteria_status']<4)
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['assessment']+=$priorityMap[$z['criterion_moc']];

		if($z['action_status'] != '' && isset($z['action_status']) && !in_array($z['action_id'], $alreadyAddedActions))
		{
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total']['action_total']++;
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total']++;

			if($z['action_status'] < 2)
			{
				$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total_ongoing']['action_total_ongoing']++;
				$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total_ongoing']++;
			}

			if(isset($z['action_holder_txt']))
				$actionHolder = $z['action_holder_txt'];
			else
				$actionHolder = $z['action_holder_name'];

			if(isset($z['action_validator_txt']))
				$actionValidator = $z['action_validator_txt'];
			else
				$actionValidator = $z['action_validator_name'];

			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_'.$z['action_status']].=$z['action_code'].'---'.$z['action_description'].'---'.$z['action_remark'].'---'.$z['action_completion'].'---'.$actionHolder.'---'.$actionValidator.'-!-';
			$alreadyAddedActions[] = $z['action_id'];
		}

		if($z['risk_status'] != '' && isset($z['risk_status']) && !in_array($z['risk_id'], $alreadyAddedRisks))
		{
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total']++;

			if($z['risk_status'] < 2)
				$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing']++;

			if(isset($z['risk_holder_txt']))
				$riskHolder = $z['risk_holder_txt'];
			else
				$riskHolder = $z['risk_holder_name'];

			$rpn = $z['severity'] * $z['occurrence'] * $z['detection'];

			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_'.$z['risk_status']].=$z['risk_code'].'---'.$z['risk_description'].'---'.$z['risk_action'].'---'.$z['risk_remarks'].'---'.$rpn.'---'.$riskHolder.'-!-';
		
			$alreadyAddedRisks[] = $z['risk_id'];
		}
	}
}


//END REVIEW
//---------------------------------------------------


include_once 'pptxReportWizardHeader.php';

use PhpOffice\PhpPresentation\PhpPresentation;
use PhpOffice\PhpPresentation\DocumentLayout;
use PhpOffice\PhpPresentation\Shape\Chart\Type\Bar3D;
use PhpOffice\PhpPresentation\Shape\Chart\Type\Line;
use PhpOffice\PhpPresentation\Shape\Chart\Type\Pie3D;
use PhpOffice\PhpPresentation\Shape\Chart\Type\Scatter;
use PhpOffice\PhpPresentation\Shape\Chart\Series;
use PhpOffice\PhpPresentation\Style\Alignment;
use PhpOffice\PhpPresentation\Style\Bullet;
use PhpOffice\PhpPresentation\Style\Color;
use PhpOffice\PhpPresentation\Style\Border;
use PhpOffice\PhpPresentation\Style\Fill;
use PhpOffice\PhpPresentation\Style\Outline;


$objPHPPresentation = new PhpPresentation();
//$objPHPPresentation->getLayout()->setDocumentLayout(DocumentLayout::LAYOUT_SCREEN_16X9);
$objPHPPresentation->getLayout()->setDocumentLayout(DocumentLayout::LAYOUT_A3);

$currentSlide = $objPHPPresentation->getActiveSlide();

//
//Table
//
$table = $currentSlide->createTableShape(9+count($reviewTypeNames));
$table->setHeight(200);
$table->setWidth(1590);
$table->setOffsetX(0);
$table->setOffsetY(0);


$row = $table->createRow();
$row->setHeight(20);
$row->getFill()->setFillType(Fill::FILL_SOLID)
			   ->setStartColor(new Color('BBBCBC'))
               ->setEndColor(new Color('BBBCBC'));

$cell = $row->nextCell();
$cell->createTextRun('Programme')->getFont()->setBold(true)->setSize(12);
$cell = $row->nextCell();
$cell->createTextRun('CoE')->getFont()->setBold(true)->setSize(12);
$cell = $row->nextCell();
$cell->createTextRun('HoV')->getFont()->setBold(true)->setSize(12);
$cell = $row->nextCell();
$cell->createTextRun('Product')->getFont()->setBold(true)->setSize(12);
$cell = $row->nextCell();
$cell->createTextRun('Supplier')->getFont()->setBold(true)->setSize(12);
$cell = $row->nextCell();
$cell->createTextRun('Sourcing')->getFont()->setBold(true)->setSize(12);
$cell = $row->nextCell();
$cell->createTextRun('ODD')->getFont()->setBold(true)->setSize(12);
$cell = $row->nextCell();
$cell->createTextRun('ID')->getFont()->setBold(true)->setSize(12);
$cell = $row->nextCell();
$cell->createTextRun('Overall Status')->getFont()->setBold(true)->setSize(12);

foreach ($reviewTypeNames as $reviewTypeSingle => $value) 
{
	$cell = $row->nextCell();
	$cell->createTextRun($reviewTypeSingle)->getFont()->setBold(true)->setSize(12);
}

$alreadyAdded = array();

if(!empty($reviewID))
{
	foreach($reviewID as $q=>$z)
	{
		if(empty($alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]))
		{
			$alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]=1;

			$row = $table->createRow();
			$row->setHeight(20);
			$row->getFill()->setFillType(Fill::FILL_SOLID)
						   ->setStartColor(new Color('FFFFFF'))
			               ->setEndColor(new Color('FFFFFF'));

			$cell = $row->nextCell();
			$cell->createTextRun($z['program'])->getFont()->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun($z['coe'])->getFont()->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun($z['msn'])->getFont()->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun($z['ca'])->getFont()->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun($z['perimeter'])->getFont()->setSize(12);
			$cell = $row->nextCell();
			//$cell->createTextRun('null')->getFont()->setSize(12);
			$cell = $row->nextCell();
			if(isset($z['odd']))
				$cell->createTextRun($z['odd'])->getFont()->setSize(12);
			$cell = $row->nextCell();
			if(isset($z['id']))
				$cell->createTextRun($z['id'])->getFont()->setSize(12);
			$cell = $row->nextCell();
			if(isset($z['progress_trend']))
				$cell->createTextRun($wingdingsMap[$z['progress_trend']])->getFont()
																		->setSize(20)
																		->setName('Wingdings 3')
																		->setColor(new Color($progressColourMap[$z['progress_trend']]));

			//print_r($reviewBetterFormatted);
			//print_r($reviewTypeNames);

			foreach ($reviewTypeNames as $reviewTypeSingle => $value) 
			{
				$cell = $row->nextCell();
				$reviewStatus = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle]['status'];
				$criteriaStatusTotal = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];
				if(isset($reviewStatus))
				{
					$cell->getFill()->setFillType(Fill::FILL_SOLID)
								   ->setStartColor(new Color($statusColourMap[$reviewStatus]))
					               ->setEndColor(new Color($statusColourMap[$reviewStatus]));
				}
				if(isset($criteriaStatusTotal['total']) && isset($criteriaStatusTotal['assessment']))
				{
					if($criteriaStatusTotal['total'] != 0)
					{
						$overallTotalPercentage = number_format((float)(($criteriaStatusTotal['assessment']/$criteriaStatusTotal['total'])*100), 2, '.', '');
						$cell->createTextRun($overallTotalPercentage.'%')->getFont()->setSize(12);
					}
				}
			}
		}
	}
}





















$alreadyAdded=array();

if(!empty($reviewID))
{
	foreach($reviewID as $q=>$z)
	{
		if(empty($alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]))
		{
			$alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]=1;

			//
			//Slide
			//
			$newSlide = $objPHPPresentation->createSlide();

			//
			//Table
			//
			$table = $newSlide->createTableShape(6);
			$table->setHeight(200);
			$table->setWidth(1590);
			$table->setOffsetX(0);
			$table->setOffsetY(0);

			//
			//First Row
			//
			$row = $table->createRow();
			$row->setHeight(20);
			$cell = $row->nextCell();
			$cell->setColSpan(7);
			$cell->createTextRun($z['program'].' - '.$z['coe'].' - '.$z['msn'].' - '.$z['perimeter'].' - '.$z['ca'])->getFont()->setBold(true)->setSize(20);
			$cell->getBorders()->getTop()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getRight()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getLeft()->setLineStyle(Border::LINE_NONE);

			//
			//General Row
			//
			$row = $table->createRow();
			$row->setHeight(20);
			$row->getFill()->setFillType(Fill::FILL_SOLID)
						   ->setStartColor(new Color('BBBCBC'))
			               ->setEndColor(new Color('BBBCBC'));
			$cell = $row->nextCell();
			$cell->setColSpan(5);
			$cell->createTextRun('General Information')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell = $row->nextCell();
			$cell = $row->nextCell();
			$cell = $row->nextCell();
			$cell = $row->nextCell();
			$cell->getBorders()->getBottom()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getTop()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getRight()->setLineStyle(Border::LINE_NONE);
			$cell->getFill()->setFillType(Fill::FILL_NONE);

			//
			//General Header Row
			//
			$row = $table->createRow();
			$row->setHeight(20);
			$row->getFill()->setFillType(Fill::FILL_SOLID)
						   ->setStartColor(new Color('BBBCBC'))
			               ->setEndColor(new Color('BBBCBC'));
			$cell = $row->nextCell();
			$cell->createTextRun('ODD')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun('ID')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun('Overall Status')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun('Number of Risks')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun('Open Risks')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell->getBorders()->getBottom()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getTop()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getRight()->setLineStyle(Border::LINE_NONE);
			$cell->getFill()->setFillType(Fill::FILL_NONE);


			//
			//General information
			//
			$row = $table->createRow();
			$row->setHeight(20);

			$cell = $row->nextCell();
			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['odd']['odd']))
				$cell->createTextRun($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['odd']['odd'])->getFont()->setSize(12);
			else
				$cell->createTextRun("Not Set")->getFont()->setSize(12);

			$cell = $row->nextCell();
			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['id']['id']))
				$cell->createTextRun($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['id']['id'])->getFont()->setSize(12);
			else
				$cell->createTextRun("Not Set")->getFont()->setSize(12);

			$cell = $row->nextCell();
			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend']))
				$cell->createTextRun($wingdingsMap[$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend']])->getFont()
																																												->setSize(20)
																																												->setName('Wingdings 3')
																																												->setColor(new Color($progressColourMap[$z['progress_trend']]));
			else
				$cell->createTextRun("Not Set")->getFont()->setSize(12);

			$cell = $row->nextCell();
			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total']))
				$cell->createTextRun($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total'])->getFont()->setSize(12);
			else
				$cell->createTextRun("0")->getFont()->setSize(12);

			$cell = $row->nextCell();
			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing']))
				$cell->createTextRun($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing'])->getFont()->setSize(12);
			else
				$cell->createTextRun("0")->getFont()->setSize(12);

			$cell = $row->nextCell();
			$cell->getBorders()->getBottom()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getTop()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getRight()->setLineStyle(Border::LINE_NONE);
			$cell->getFill()->setFillType(Fill::FILL_NONE);


			//
			//Spacer
			//
			$row = $table->createRow();
			$row->setHeight(20);
			$cell = $row->nextCell();
			$cell->setColSpan(7);
			$cell->getBorders()->getRight()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getLeft()->setLineStyle(Border::LINE_NONE);


			//
			//Review Information Row
			//
			$row = $table->createRow();
			$row->setHeight(20);
			$row->getFill()->setFillType(Fill::FILL_SOLID)
						   ->setStartColor(new Color('BBBCBC'))
			               ->setEndColor(new Color('BBBCBC'));
			$cell = $row->nextCell();
			$cell->setColSpan(4);
			$cell->createTextRun('Review Information')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell = $row->nextCell();
			$cell = $row->nextCell();
			$cell = $row->nextCell();
			$cell->setColSpan(2);
			$cell->getFill()->setFillType(Fill::FILL_SOLID)
						   ->setStartColor(new Color('FFFFFF'))
			               ->setEndColor(new Color('FFFFFF'));
			$cell->getBorders()->getBottom()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getTop()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getRight()->setLineStyle(Border::LINE_NONE);
			$cell->getFill()->setFillType(Fill::FILL_NONE);

			//
			//Review Information Header Row
			//
			$row = $table->createRow();
			$row->setHeight(20);
			$row->getFill()->setFillType(Fill::FILL_SOLID)
						   ->setStartColor(new Color('BBBCBC'))
			               ->setEndColor(new Color('BBBCBC'));
			$cell = $row->nextCell();
			$cell->createTextRun('Review Type')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun('Status & Degree of Fulfilment')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun('Number Of Actions')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell->createTextRun('Open Actions')->getFont()->setBold(true)->setSize(12);
			$cell = $row->nextCell();
			$cell->setColSpan(2);
			$cell->getBorders()->getBottom()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getTop()->setLineStyle(Border::LINE_NONE);
			$cell->getBorders()->getRight()->setLineStyle(Border::LINE_NONE);
			$cell->getFill()->setFillType(Fill::FILL_NONE);

			//
			//Review Information
			//
			foreach ($reviewTypeNames as $reviewTypeSingle => $value) 
			{
				$row = $table->createRow();
				$row->setHeight(20);

				$cell = $row->nextCell();
				$cell->createTextRun($reviewTypeSingle)->getFont()->setBold(true)->setSize(12);

				$cell = $row->nextCell();

				$reviewStatus = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle]['status'];
				$criteriaStatusTotal = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];
				if(isset($reviewStatus))
				{
					$cell->getFill()->setFillType(Fill::FILL_SOLID)
								   ->setStartColor(new Color($statusColourMap[$reviewStatus]))
					               ->setEndColor(new Color($statusColourMap[$reviewStatus]));
				}
				if(isset($criteriaStatusTotal['total']) && isset($criteriaStatusTotal['assessment']))
				{
					if($criteriaStatusTotal['total'] != 0)
					{
						$overallTotalPercentage = number_format((float)(($criteriaStatusTotal['assessment']/$criteriaStatusTotal['total'])*100), 2, '.', '');
						$cell->createTextRun($overallTotalPercentage.'%')->getFont()->setSize(12);
					}
				}
				else if (!isset($reviewStatus))
					$cell->createTextRun("Not performed")->getFont()->setSize(12);


				$cell = $row->nextCell();
				if(isset($criteriaStatusTotal['action_total']))
					$cell->createTextRun($criteriaStatusTotal['action_total'])->getFont()->setSize(12);
				else
					$cell->createTextRun("0")->getFont()->setSize(12);

				$cell = $row->nextCell();
				if(isset($criteriaStatusTotal['action_total_ongoing']))
					$cell->createTextRun($criteriaStatusTotal['action_total_ongoing'])->getFont()->setSize(12);
				else
					$cell->createTextRun("0")->getFont()->setSize(12);

				$cell = $row->nextCell();
				$cell->setColSpan(2);
				$cell->getBorders()->getBottom()->setLineStyle(Border::LINE_NONE);
				$cell->getBorders()->getTop()->setLineStyle(Border::LINE_NONE);
				$cell->getBorders()->getRight()->setLineStyle(Border::LINE_NONE);
				$cell->getFill()->setFillType(Fill::FILL_NONE);
			}

			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing']))
			{
				//
				//Spacer
				//
				$row = $table->createRow();
				$row->setHeight(20);
				$cell = $row->nextCell();
				$cell->setColSpan(7);

				//
				//Risk Header
				//
				$row = $table->createRow();
				$row->setHeight(20);
				$row->getFill()->setFillType(Fill::FILL_SOLID)
							   ->setStartColor(new Color('BBBCBC'))
				               ->setEndColor(new Color('BBBCBC'));
				$cell = $row->nextCell();
				$cell->setColSpan(7);
				$cell->createTextRun('Open Risks')->getFont()->setBold(true)->setSize(12);

				//
				//Risk Header Description Row
				//
				$row = $table->createRow();
				$row->setHeight(20);
				$row->getFill()->setFillType(Fill::FILL_SOLID)
							   ->setStartColor(new Color('BBBCBC'))
				               ->setEndColor(new Color('BBBCBC'));
				$cell = $row->nextCell();
				$cell->createTextRun('Status & Code')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('Description')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('Action')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('Remark')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('RPN')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('Holder')->getFont()->setBold(true)->setSize(12);

				//
				//Risks
				//
				foreach ($statusColourMap as $statusNumber => $colour) 
				{
					if($statusNumber < 2)
					{
						if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']))
						{
							foreach ($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks'] as $riskStatusKey => $value) 
							{
								if($riskStatusKey == 'risk_'.$statusNumber)
								{
									$splitRisks = split('-!-',$value);

									for ($i=0; $i < count($splitRisks); $i++) 
									{
										if($splitRisks[$i] != '' && isset($splitRisks[$i]))
										{
											$row = $table->createRow();
											$row->setHeight(20);

											$splitRisksColumns = split('---', $splitRisks[$i]);

											for ($j=0; $j < count($splitRisksColumns); $j++) 
											{ 
												$cell = $row->nextCell();
												if($splitRisksColumns[$j] != '' && isset($splitRisksColumns[$j]))
												{
													if($j==0)
													{
														$cell->getFill()->setFillType(Fill::FILL_SOLID)
															->setStartColor(new Color($colour))
															->setEndColor(new Color($colour));
													}

													$cell->createTextRun($splitRisksColumns[$j])->getFont()->setSize(12);
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total_ongoing']['action_total_ongoing']))
			{
				//
				//Spacer
				//
				$row = $table->createRow();
				$row->setHeight(20);
				$cell = $row->nextCell();
				$cell->setColSpan(7);

				//
				//Action Header Row
				//
				$row = $table->createRow();
				$row->setHeight(20);
				$row->getFill()->setFillType(Fill::FILL_SOLID)
							   ->setStartColor(new Color('BBBCBC'))
				               ->setEndColor(new Color('BBBCBC'));
				$cell = $row->nextCell();
				$cell->setColSpan(7);
				$cell->createTextRun('Open Actions')->getFont()->setBold(true)->setSize(12);

				//
				//Action Header Description Row
				//
				$row = $table->createRow();
				$row->setHeight(20);
				$row->getFill()->setFillType(Fill::FILL_SOLID)
							   ->setStartColor(new Color('BBBCBC'))
				               ->setEndColor(new Color('BBBCBC'));
				$cell = $row->nextCell();
				$cell->createTextRun('Status & Code')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('Description')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('Remark')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('Complete By')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('Holder')->getFont()->setBold(true)->setSize(12);
				$cell = $row->nextCell();
				$cell->createTextRun('Validator')->getFont()->setBold(true)->setSize(12);

				//
				//Actions
				//
				foreach ($statusColourMap as $statusNumber => $colour) 
				{
					if($statusNumber < 2)
					{
						foreach ($reviewTypeNames as $reviewTypeSingle => $value) 
						{
							$actionTotalsShort = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];

							if(isset($actionTotalsShort['action_'.$statusNumber]))
							{
								$splitActions = split('-!-', $actionTotalsShort['action_'.$statusNumber]);

								for ($i=0; $i < count($splitActions); $i++) 
								{
									if($splitActions[$i] != '' && isset($splitActions[$i]))
									{
										$row = $table->createRow();
										$row->setHeight(20);

										$splitActionColumns = split('---', $splitActions[$i]);

										for ($j=0; $j < count($splitActionColumns); $j++) 
										{ 
											$cell = $row->nextCell();
											if($splitActionColumns[$j] != '' && isset($splitActionColumns[$j]))
											{
												if($j==0)
												{
													$cell->getFill()->setFillType(Fill::FILL_SOLID)
														->setStartColor(new Color($colour))
														->setEndColor(new Color($colour));
												}

												$cell->createTextRun($splitActionColumns[$j])->getFont()->setSize(12);
											}
										}
									}
								}
							}
						}
					}
				}
			}

			//
			//Graph
			//

			/*$seriesData = array(
				'ITCM' => 2,
				'PDR' => 2,
				'CDR' => 1,
				'FPDR' => 0,
				'FAI' => 1,
				'ODD' => 2
			);

			$lineChart = new Line();
			$series = new Series('Program Performance', $seriesData);
			$series->setShowSeriesName(false);
			$series->setShowValue(false);
			$outline = new Outline();
			$outline->getFill()->setFillType(Fill::FILL_SOLID)
								->setStartColor(new Color('FFE06B20'));
			$outline->setWidth(5);
			$series->setOutline($outline);
			$lineChart->addSeries($series);

			$shape = $newSlide->createChartShape();
			$shape->setName('Program Performance')->setResizeProportional(false)->setHeight(100)->setWidth(960)->setOffsetX(0)->setOffsetY(170);
			$shape->getFill()->setFillType(Fill::FILL_GRADIENT_LINEAR)
							 ->setRotation(90)
			               ->setStartColor(new Color('FFFFFFFF'))
			               ->setEndColor(new Color('FFFFFFFF'));
			$shape->getBorder()->setLineStyle(Border::LINE_SINGLE);
			$shape->getPlotArea()->setType($lineChart);
			$shape->getLegend()->setVisible(false);
			$shape->getTitle()->setVisible(false);*/
		}
	}
}



$filename="art_overview_export_".date('Y_m_d_H_m_s');

write($objPHPPresentation, $filename, $writers);


echo 'OK|||'.$filename;

/*header('Content-type: application/octet-stream');
header("Content-Disposition: attachment; filename=test.pptx");
header("Content-Description: Files of an applicant");
header("Cache-Control: private");
header("Pragma: private");
echo $zip->file();*/

//print_r($POST);

?>