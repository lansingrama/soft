<?php
function addMissingResults($array,$maxLength=0){
	if(is_array($array)){
		$length=count($array);
		if($maxLength!=0 && $maxLength>$length){
			$missingResults=$maxLength-$length;
			for($i=0;$i<$missingResults;$i++){
				$array[]=array();
			}
		}
		return $array;
	}else{
		return array();
	}
}
function combinedResult($array,$field,$fieldType,$SESSION){
	$different=0;
	$firstRow=1;
	if(is_array($array)){
		foreach($array as $a){
			if($firstRow==1){
				$lastResult=$a[$field];
				$firstRow=0;
			}else{
				if($lastResult!=$a[$field]){
					$different=1;
				}
			}
		}
		if($different==0){
			return $lastResult;
		}else{
			return $SESSION['mixed_value'][$fieldType];
		}
	}else return '';
}
function drawBooleanValue($value){ //JFM 11_11_13
	switch($value){
		case '1':
			?><span class="g boolean">Yes</span><?php
		break;
		
		case '-1':
			?><span>N/A</span><?php
		break;
		
		default:
			?><span class="r boolean">No</span><?php
		break;
	}
}
function drawDate($inputName,$divName,$value,$different,$editable=0){
	if($value=='0000-00-00')$value='';
	$calendarValue=($value=='****-**-**')?'':$value;
	?><input class="formInput"id="<?=$inputName?>"name="<?=$inputName?>"readonly size="10"style="border:#FFF;"type="text"value="<?=($different)?'****-**-**':$value?>"><?php
	$dateArray=getMonthYear($calendarValue);
	if($editable==1){
		?><img onClick="getCal('calTable','<?=$divName?>','<?=$inputName?>','','<?=$dateArray['m']?>','<?=$dateArray['y']?>','','put',true,true);"src="../common/img/calendar.jpg"style="cursor:pointer"><?php
		?><span class="xRemove" onClick="$('<?=$inputName?>').value=''">&#10008;</span><?php
		?><div class="calendar"id="<?=$divName?>"></div><?php
	}
}
function drawddList($id,$array,$field='',$w1,$onChange='',$allowedEmpty=0,$disabled='', $allowedEmptyDisabled=0,$class='')
{ //JFM 12_01_16           
	if($field!='')$selected[$field]=' selected';
	?><select<?php
		if($class){?> class="<?=$class?>" <?php }
		if($id){?> id="<?=$id?>"name="<?=$id?>"<?php }
		if($disabled==1){?>disabled <?php }
		if($onChange){?> onChange="<?=$onChange?>"<?php }
		?> style="width:<?=$w1?>px;"><?php
		if($allowedEmpty){?><option <?=($allowedEmptyDisabled)?'disabled="disabled" selected="selected"':''?> value=""><?=($allowedEmptyDisabled)?'Select a value':''?></option><?php }
		if(is_array($array)){
			foreach($array as $k=>$v){
				?><option<?=$selected[$k]?> value="<?=$k?>"><?=$v?></option><?php                                
			}
		}
	?></select><?php
}
function drawDdListBox($title,$id,$field,$array,$w1,$w2='',$w3='',$onChange='',$allowedEmpty=0,$disabled=''){
	?><tr class="infoRow"><?php
		?><td class="paramDef"<?php if($w2){?>style="width:<?=$w2?>px;"<?php }?>><?=$title?></td><?php
		?><td <?php if($w3){?>style="width:<?=$w3?>px;"<?php }?>><?php
			drawddList($id,$array,$field,$w1,$onChange,$allowedEmpty,$disabled);
		?></td><?php
	?></tr><?php
}
function drawHelpText($helpText){
	?> (<span onMouseOut="nd();"onMouseOver="overlib('<?=$helpText?>');"style="cursor:pointer;">?</span>)<?php
}
//function drawInteractiveCheck($object,$action,$applicability,$array,$type,$inverted,$reviewclick,$disabled='',$onClick=''){
function drawInteractiveCheck($object,$action,$applicability,$array,$type,$inverted,$reviewclick='',$disabled='',$onClick=''){
	$active=$array[$object][$action][$applicability];
        //Start of bug 11 for adding the class name for the check box
        $row_name = 'cbrow-'.$applicability;
	?><input<?php
		if(($active==1 && $inverted==0)||($active==0 && $inverted==1)){
			?> checked<?php
		}
		if($disabled==1){
			?> disabled<?php
		}		
                ?> class="<?=$row_name?> ReviewRowName" id="<?=$type,'-',$object,'-',$action,'-',$applicability?>"onClick="<?=$onClick?>checkChange(this,'<?=$type?>','<?=$reviewclick?>');"type="checkbox" value="1"><?php
}
function drawPermissions($title,$object,$applicability,$view,$edit,$create,$delete,$export,$upload,$right,$SESSION,$user=0,$hidden=0,$rowId=0){
	$userAction=array('view','edit','create','delete','export','upload');
	/*if($SESSION['edit_user']['user_invited']==0){
		$onClick='if($(\'name\').value!=\'New\' && $(\'surname\').value!=\'User\')reloadSideElementNeeded=1;';
	}*/
	?><tr class="infoRow" id="<?=$rowId?>" style="display:<?=($hidden)?'none':''?>"><?php
		?><td class="paramDef"><?php
			if($user!=0){
				?><input checked onClick="<?=$onClick?>checkGroup('prm',this,1,[<?=$user?>,<?=$SESSION['object'][$object]?>,<?=$applicability?>],0)"type="checkbox"><?php
				?><input onClick="<?=$onClick?>checkGroup('prm',this,0,[<?=$user?>,<?=$SESSION['object'][$object]?>,<?=$applicability?>],0)"type="checkbox"><?php 
			}
			echo $title;
		?></td><?php
		foreach($userAction as $action){
			?><td class="chk"><?php
				if($$action==1 && checkPermission($object,$action,$applicability,'check',$SESSION)==1){
					drawInteractiveCheck($SESSION['object'][$object],$SESSION['user_action'][$action],$applicability,$right,'prm',0,'',$onClick);
				}else{?><input disabled type="checkbox"><?php }
			?></td><?php
		}
	?></tr><?php
}
function drawRadio($rName,$cR,$editable=0){
	?><span style="cursor:pointer;"title="Yes"><input<?php if($cR==1)echo' checked';if($editable==0)echo' disabled'?> name="<?=$rName?>" id="<?=$rName?>" type="radio"value="1">Y</span> <?php //JFM 19_07_16
	?><span style="cursor:pointer;"title="No"><input<?php if($cR==0)echo' checked';if($editable==0)echo' disabled'?> name="<?=$rName?>" id="<?=$rName?>" type="radio"value="0">N</span> <?php //JFM 19_07_16
	if($cR=='m'){?><span style="cursor:pointer;"title="Mixed"><input checked<?php if($editable==0)echo' disabled'?> name="<?=$rName?>" id="<?=$rName?>" type="radio"value="m">M</span><?php } //JFM 19_07_16
}
function drawSimpleCheck($object,$action,$applicability,$array,$type,$inverted,$title,$w1=''){
	?><tr class="infoRow"><?php
		?><td class="paramDef"<?php if($w1!=''){?>style="width:<?=$w1?>px;"<?php }?>><?=$title?></td><?php
		?><td class="chk"><?php
			drawInteractiveCheck($object,$action,$applicability,$array,$type,$inverted);
		?></td><?php
	?></tr><?php
}
	/*
	* Fix for : US#019 Change workflow for creating a design review
	* Added for displaying general information page above checklist
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
function drawStatus($object,$id,$status,$editable,$SESSION,$defineReviewChklist)
{
	$activeStatus=pictureStatus($status);
	if($defineReviewChklist){
            if($SESSION['disabled_statues'][$SESSION['object'][$object]][0] != 1)
            {
		?><img <?php if($editable==1){?>id="<?=$id?>_r"onMouseOver="setStatusFocus(this,'<?=$object?>')"style="cursor:pointer;"<?php } ?>src="../common/img/r30<?=$activeStatus[0]?>.png"><span style="cursor:default;padding-right:10px;"></span><?php
            }
            if($SESSION['disabled_statues'][$SESSION['object'][$object]][1] != 1)
            {
		?><img <?php if($editable==1){?>id="<?=$id?>_a"onMouseOver="setStatusFocus(this,'<?=$object?>')"style="cursor:pointer;"<?php } ?>src="../common/img/a30<?=$activeStatus[1]?>.png"><span style="cursor:default;padding-right:10px;"></span><?php
            }
            if($SESSION['disabled_statues'][$SESSION['object'][$object]][2] != 1)
            {
		?><img <?php if($editable==1){?>id="<?=$id?>_g"onMouseOver="setStatusFocus(this,'<?=$object?>')"style="cursor:pointer;"<?php } ?>src="../common/img/g30<?=$activeStatus[2]?>.png"><span style="cursor:default;padding-right:10px;"></span><?php
            }
            if($SESSION['disabled_statues'][$SESSION['object'][$object]][3] != 1)
            {
		?><img <?php if($editable==1){?>id="<?=$id?>_x"onMouseOver="setStatusFocus(this,'<?=$object?>')"style="cursor:pointer;"<?php } ?>src="../common/img/x30<?=$activeStatus[3]?>.png"><?php //JFM 27_03_14
            }
	}
	else {
            if($SESSION['disabled_statues'][$SESSION['object'][$object]][0] != 1)
            {
		?><img <?php if($editable==1){?>id="<?=$id?>_r"onMouseOver="setStatusFocus(this,'<?=$object?>')"style="cursor:pointer;"<?php } ?>src="../common/img/r30<?=$activeStatus[0]?>.png"><span style="cursor:default;padding-right:10px;"></span><?php
            }
            if($SESSION['disabled_statues'][$SESSION['object'][$object]][1] != 1)
            {
		?><img <?php if($editable==1){?>id="<?=$id?>_a"onMouseOver="setStatusFocus(this,'<?=$object?>')"style="cursor:pointer;"<?php } ?>src="../common/img/a30<?=$activeStatus[1]?>.png"><span style="cursor:default;padding-right:10px;"></span><?php
            }
            if($SESSION['disabled_statues'][$SESSION['object'][$object]][2] != 1)
            {
		?><img <?php if($editable==1){?>id="<?=$id?>_g"onMouseOver="setStatusFocus(this,'<?=$object?>')"style="cursor:pointer;"<?php } ?>src="../common/img/g30<?=$activeStatus[2]?>.png"><span style="cursor:default;padding-right:10px;"></span><?php
            }
            if($SESSION['disabled_statues'][$SESSION['object'][$object]][3] != 1)
            {
		?><img <?php if($editable==1){?>id="<?=$id?>_x"onMouseOver="setStatusFocus(this,'<?=$object?>')"style="cursor:pointer;"<?php } ?>src="../common/img/x30<?=$activeStatus[3]?>.png"><?php //JFM 27_03_14
            }
            if($status=='4')
            {
		?><span style="cursor:default;padding-right:10px;"></span><img id="<?=$id?>_m"onMouseOver="setStatusFocus(this,'<?=$object?>')"src="../common/img/m30<?=$activeStatus[4]?>.png"style="cursor:pointer;"><?php
            } 
	}
}
/* End US#019 Change workflow for creating a design review */
function drawStdCheck($title,$id,$active,$stdValue,$w1='',$inverted=0,$disabled=0,$checkDetails=''){
	?><tr class="infoRow"><?php
		?><td class="paramDef"<?php if($w1!=''){?>style="width:<?=$w1?>px;"<?php }?>><?=$title?></td><?php
		?><td <?php if ($checkDetails==''){?>class="chk"<?php }?>><?php
			?><input<?php
				if(($active==1 && $inverted==0)||($active==0 && $inverted==1)){
					echo ' checked';
				}
				if($disabled==1){
					echo ' disabled';
				}
				?> id="<?=$id?>"name="<?=$id?>"type="checkbox"value="<?=$stdValue?>"><?php
			if($checkDetails!=''){
				echo ' ',$checkDetails;
			}
		?></td><?php
	?></tr><?php
}
function drawStdField($title,$id,$field,$size,$w1='',$w2='',$maxLength=0,$onKeyUp='',$disabled='',$helpText=''){
	?><tr class="infoRow"><?php
		?><td class="paramDef"<?php if($w1){?>style="width:<?=$w1?>px;"<?php }?>><?php
			echo $title;
			if($helpText!=''){
				drawHelpText($helpText);
			}
		?></td><?php
		?><td <?php if($w2){?>style="width:<?=$w2?>px;"<?php }?>><?php
                ?><input class="textareaWhite"<?php if($disabled==1){?>disabled <?php }?> id="<?=$id?>"<?php if($maxLength!=0){?>maxlength="<?=$maxLength?>"<?php }?>name="<?=$id?>"<?php if($onKeyUp!=''){?>onKeyUp="<?=$onKeyUp?>"<?php }?>size="<?=$size?>"type="text"value="<?=$field?>"><?php
		?></td><?php
	?></tr><?php
}

function drawStdImg($dSt){
	?><td style="text-align:center"><img alt="The status of all selected CA/WP is Red"src="../common/img/r20.png"></td><?php
	?><td style="text-align:center"><img alt="The status of all selected CA/WP is Amber"src="../common/img/a20.png"></td><?php
	?><td style="text-align:center"><img alt="The status of all selected CA/WP is Green"src="../common/img/g20.png"></td><?php
	?><td style="text-align:center"><img alt="The status of all selected CA/WP is Blue"src="../common/img/x20.png"></td><?php //JFM 27_03_14
	?><td style="text-align:center"><?php if($dSt){?><img alt="The status of all selected CA/WP is mixed" src="../common/img/m20.png"><?php }?></td><?php
}
function drawStdRadio($cName,$cCS,$cCD,$dC){
	?><td style="text-align:center"><input<?php if(($cCS==0 || $cCD=='0000-00-00')&&!$dC)echo' checked'?> name="<?=$cName?>"type="radio"value="0"></td><?php
	?><td style="text-align:center"><input<?php if($cCS==1 && !$dC)echo' checked'?> name="<?=$cName?>"type="radio"value="1"></td><?php
	?><td style="text-align:center"><input<?php if(($cCS==2 && $cCD!='0000-00-00')&&!$dC)echo' checked'?> name="<?=$cName?>"type="radio"value="2"></td><?php
	?><td style="text-align:center"><?php if($dC){?><input checked name="<?=$cName?>"type="radio"value="3"><?php }?></td><?php
}
function drawTableHeader($tableStructure,$table,$SESSION,$filterRow=0,$tableCacheId='',$includeEmptyCell=1){	
	?><tr class="tableGroup"><?php
		if($includeEmptyCell==1){?><td rowspan=2 ></td><?php }
		foreach($tableStructure as $columnName=>$columnDetails){
			if(getFilter($columnName,'hide',0,$SESSION)!=1){
				?><td nowrap <?=(!empty($tableStructure[$columnName]['extras']))?'rowspan=1 colspan='.count($tableStructure[$columnName]['extras']):'rowspan=2'?>><?=$columnDetails['title']?></td><?php //JFM 16_09_13
			}
		}
	?></tr><?php
	
	?><tr class="tableGroup"><?php //JFM 16_09_13
		foreach($tableStructure as $columnName=>$columnDetails){
			if(getFilter($columnName,'hide',0,$SESSION)!=1){
				if(!empty($tableStructure[$columnName]['extras']))
				{
					foreach($tableStructure[$columnName]['extras'] as $z)
					{
						if(is_array($z))
						{
							?><td nowrap ><?=$z['title']?></td><?php
						}
						else
						{
							?><td nowrap ><?=$z?></td><?php
						}
					}
				}
			}
		}
	?></tr><?php

	if($filterRow==1){
		?><tr><?php
			if($includeEmptyCell==1){?><td class="flt"></td><?php }
			foreach($tableStructure as $k=>&$v){
				if(getFilter($k,'hide',0,$SESSION)!=1){
					//drawFilterIcon(0,$k,$v['type'],$v['filter'],$table,$SESSION,$tableCacheId);
					if(!empty($tableStructure[$k]['extras'])) //JFM 16_09_13
					{
						foreach($tableStructure[$k]['extras'] as $z)
						{
							drawFilterIcon($table,$table,$k,$z,$SESSION,$tableCacheId,'',$z);
						}
					}
					else drawFilterIcon($table,$table,$k,0,$SESSION,$tableCacheId);
				}
			}
		?></tr><?php
	}
}
function drawUserField($divId,$inputId,$idInputId,$userTxt,$userName='',$editable=0){
	$fieldValue=($userTxt)?$userTxt:$userName;
	?><td><?php
		?><div class="suggestion"id="<?=$divId?>"style="width:159px;"></div><?php
		?><input class="textareaWhite"id="<?=$inputId?>"name="<?=$inputId?>"<?php
			if($editable==1){ //this - what you entered into the box
				?>onFocus="loadUserSuggestion(this,'<?=$divId?>','<?=$inputId?>','','<?=$idInputId?>');"onKeyPress="return avoidSendForm(event,'user');"<?php
			}else{
				?>readonly <?php
			}
		?>size="28"type="text"value="<?=$fieldValue?>"><?php
	?></td><?php
}

function formTitle($width,$title,$formContainer,$tableCache='',$popUpParameter='',$activeTable=''){
	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo"><?php
			if(is_array($popUpParameter)){
				?><input class="popUpBtnBlue"onClick="<?php if($activeTable!='')echo'activeTable=\''.$activeTable.'\';';?>popUpOpt('ttl',['<?=implode("','",$popUpParameter)?>','<?=$tableCache?>']);"type="button"value="&#8801;"><?php
				?><div class="popUpMenu"id="popUpTtlDiv_<?=$popUpParameter[0]?>"></div>&nbsp;<?php
			}
			echo $title;
		?></div><?php
		?><div class="xDiv" onclick="<?php if($tableCache!=''){?>removeTableCache('<?=$tableCache?>');<?php }?>closeLastForm();">&#9668; Back</div><?php
	?></div><?php
}
/*
 * US#21.1 - Siglum/Company Name
 * Added new fucntion to refresh the User Management
 * Version: 4.3
 * Added by: Infosys Limited
 */
function formUerMan($width,$title,$formContainer,$tableCache='',$popUpParameter='',$activeTable=''){
	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo"><?php
			if(is_array($popUpParameter)){
				?><input class="popUpBtnBlue"onClick="<?php if($activeTable!='')echo'activeTable=\''.$activeTable.'\';';?>popUpOpt('ttl',['<?=implode("','",$popUpParameter)?>','<?=$tableCache?>']);"type="button"value="&#8801;"><?php
				?><div class="popUpMenu"id="popUpTtlDiv_<?=$popUpParameter[0]?>"></div>&nbsp;<?php
			}
			echo $title;
		?></div><?php
		?><div class="xDiv" onclick="refreshUserMan();">&#9668; Back</div><?php
	?></div><?php
}
function formToQuery($input,$possibleFields,$SESSION){
	$status=array('r'=>0,'a'=>1,'g'=>2,'x'=>3,0=>0,1=>1,2=>2,3=>3); //JFM 27_03_14
	foreach($possibleFields as $columnName=>$columnDetails){
		if(isset($input[$columnName])){
			if($input[$columnName]!==$SESSION['mixed_value'][$columnDetails['type']]){
				switch($columnDetails['type']){
					case'boolean':
					$qry[$columnName]=($input[$columnName]==1)?1:0;
					break;
					case'date':
						includeDate($input[$columnName],$columnName,$qry);
					break;
					case'link':
						$qry[$columnName]=$input[$columnName];
					break;
					case'status':
						$qry[$columnName]=$status[$input[$columnName]];
					break;
					case'text':
					case'trend': //JFM 08_06_16
						$qry[$columnName]=$input[$columnName];
					break;
					case'user':
						if($input[$columnName]!='' && $input[$columnName]!=0){
							$qry[$columnName]=$input[$columnName];
						}else{
							$qry[$columnName]=0;
						}
					break;
				}
			}
		}
		if(isset($input[$columnDetails['done']])){
			includeDone($input[$columnDetails['done']],$columnDetails['done'],$qry);
		}
	}
	return $qry;
}
function generateSaveResponse(&$answer,&$firstItem,$table,$POST,$dbResult,$addLocation='',$avoidedField=''){
	if($avoidedField=='')$avoidedField=array();
	foreach($table as $k=>$v){
		if(isset($POST[$k]) && !in_array($k,$avoidedField)){
			if($firstItem!=0){
				$answer.='&&&';
			}else{
				$firstItem=1;
			}
			$answer.=$k.$addLocation.'%%%'.$v['type'].'%%%'.$dbResult[$k];
			if($v['done']!=''){
				$answer.='###'.$dbResult[$v['done']];
			}
		}
	}
}
function generateSimpleResponse(&$answer,&$firstItem,$array){
	foreach($array as $k=>&$v){
		if($firstItem!=0)$answer.='&&&';
		else $firstItem=1;
		$answer.=$k.'%%%'.$v;
	}
}
function getFormUpdate($qry,$actualDb,$table,$tableSection,$logApplicability,$SESSION,$avoidedField='',$specialType=''){
	$updateArray=array();
	if($avoidedField=='')$avoidedField=array();
	if($specialType=='')$specialType=array();
	foreach($qry as $k=>$v){
		$mixedField=($specialType[$k]!='')?$SESSION['mixed_value'][$specialType[$k]]:$SESSION['mixed_value'][$SESSION['table'][$table][$tableSection][$k]['type']];
		//JFM 07_04_14
		if($v!=$actualDb[$k] && $v!==$mixedField && !in_array($k,$avoidedField) && $k!=''){
			createLog('dr_log',$k,'edit',$logApplicability,$actualDb[$k],$v,$SESSION);
			$updateArray[]=$k.'="'.$v.'"';
		}
	}
	return $updateArray;
}
function getMonthYear($date){
	if($date!='' && $date!='0000-00-00'){
		$dateSplitted=split('-',$date);
		$dateArray['y']=$dateSplitted[0];
		$dateArray['m']=$dateSplitted[1];
	}else{
		date_default_timezone_set('Europe/Berlin');
		$dateArray['y']=date('Y',time());
		$dateArray['m']=date('m',time());
	}
	return $dateArray;
}
function includeDate(&$date,$field,&$qry){
	if($date==''){
		$date='0000-00-00';
	}
	if($date!='****-**-**'){
		$qry[$field]=$date;
	}
}
function includeDone(&$done,$field,&$qry){
	if($done!='m' && $field!=''){
		$qry[$field]=$done;
	}
}

/*
 * US#021 - Starts
 * Function to draw the textboxes in user management
 * @param String $title
 * @param String $id
 * @param String $active
 * @param String $stdValue
 * @param String $w1
 * @param Int $inverted
 * @param Int $disabled
 * @param String $checkDetails
 */
function drawStdCheckUsr($title,$id,$active,$stdValue,$w1='',$inverted=0,$disabled=0,$checkDetails=''){
	?><tr class="infoRow"><?php
		?><td class="paramDef"<?php if($w1!=''){?>style="width:<?=$w1?>px;"<?php }?>><?=$title?></td><?php
		?><td <?php if ($checkDetails==''){?>class="chk"<?php }?>><?php
			?><input<?php
				if(($active==1 && $inverted==0)||($active==0 && $inverted==1)){
					echo ' checked';
				}
				if($disabled==1){
					echo ' disabled';
				}
                                ?> id="<?=$id?>"name="<?=$id?>"type="checkbox"value="<?=$stdValue?>" onchange="externalCheck()"><?php
			if($checkDetails!=''){
				echo ' ',$checkDetails;
			}
		?></td><?php
	?></tr><?php
}

/*
 * #US021 - Siglum/Company Name
 * Fuction to define the Supplier Field in User Management
 * @param String $title
 * @param String $id
 * @param String $field
 * @param Int $size
 * @param Int $type
 */
function drawSupplierField($title,$id,$field,$size,$type){
        ?><tr class="infoRow"><?php
		?><td class="paramDef"><?php
			echo $title;
		?></td><?php
                    ?><td width="35%" valign="top"><?php
                        ?><div class="suggestion"id="supdivID"style="width:175px;"></div><?php
                        if($type == 1) {
                            ?><input class="textareaWhite" id="<?=$id?>Id" name="<?=$id?>Name" size="<?=$size?>" type="text" onFocus="supplierSuggestion(this,'supdivID','supplierId','','supsuggestionID','supplierId','skip');" onKeyPress="return avoidSendFormSup(event,'supplier');"value="<?=$field?>"><?php
                        } else {
                            ?><input class="textareaWhite" disabled="disabled" id="<?=$id?>Id" name="<?=$id?>Name" size="<?=$size?>" type="text" onFocus="supplierSuggestion(this,'supdivID','supplierId','','supsuggestionID','supplierId','skip');" onKeyPress="return avoidSendFormSup(event,'supplier');"value="<?=$field?>"><?php
                        }
                        ?><input type="text" hidden="true" disabled="disabled" id="skipLoadUser" ><?php
                    ?></td><?php                    
	?></tr><?php
}

/*
 * Fuction to define the Text fields in User management
 * #US021 - Siglum/Company Name
 */
function drawUserFormField($title,$id,$field,$size,$w1='',$w2='',$maxLength=0,$onKeyUp='',$disabled='',$helpText=''){
	?><tr class="infoRow"><?php
		?><td class="paramDef"<?php if($w1){?>style="width:<?=$w1?>px;"<?php }?>><?php
			echo $title;
			if($helpText!=''){
				drawHelpText($helpText);
			}
		?></td><?php
		?><td <?php if($w2){?>style="width:<?=$w2?>px;"<?php }?>><?php
                ?><input class="textareaWhite"<?php if($disabled==1){?>disabled <?php }?> id="<?=$id?>"<?php if($maxLength!=0){?>maxlength="<?=$maxLength?>"<?php }?>name="<?=$id?>"<?php if($onKeyUp!=''){?>onKeyUp="<?=$onKeyUp?>"<?php }?>size="<?=$size?>"type="text"value="<?=$field?>"onfocus="skipLoadUserList('check');"><?php
		?></td><?php
	?></tr><?php
}

/*
 * Function for creating the User Supplier details on Perimeter page - US#21.1
 * Added By: Infosys Limited
 * @param String $perimeter
 */
function drawPrmListBox($perimeter){
    if(!$perimeter) $perimeter = 'new';
    $totalSups = array();
    $totalSupIds = array();
    $allSups = SqlLi('SELECT supplier_id, supplier FROM c_supplier');
    
    foreach($allSups as $sup) {
        $totalSupIds[] = $sup['supplier_id'];
        $totalSups[] = $sup['supplier'];
    }
    
    ?><td><input type="hidden" name="prm_id" id="prm_id" value="<?php echo $perimeter; ?>"><?php
    
    if(is_numeric($perimeter)) {
        ?><table id="dataTable" class="criteriaTable" style="width:380px;">
            <tbody>
                <tr class="tableGroup prmRow">
                    <td class="paramDef">Assigend User Supplier</td>
                    <td class="paramDef">Remove</td>
                </tr><?php

                $supArr = array();
                $sup_id = array();
                $supplierNames = SqlLi('SELECT cs.supplier,cs.supplier_id FROM dr_perimeter_supplier_map AS dp  JOIN c_supplier AS cs ON dp.supplier = cs.supplier_id WHERE dp.perimeter='.$perimeter);
                foreach ($supplierNames as $supplier) {
                    $supArr[] = $supplier['supplier'];
                    $sup_id[] = $supplier['supplier_id'];
                    
                    ?><tr class="infoRow">					
                        <td class="paramDef"><input style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;padding: 5px;background: no-repeat;border: none;" type="text" name="multiple_sups" id="multiple_sups<?php echo $supplier['supplier_id']; ?>" value="<?php echo $supplier['supplier']; ?>"/></td>
                        <td style="padding:5px;background-color:#e7e7e8;" class="paramDef"><input style="margin-left:8px;" value="<?php echo $supplier['supplier_id']; ?>-<?php echo $supplier['supplier']; ?>" type="checkbox" name="chk" class="removeSupIds" id="chk" onclick="deleteSupRow(this)" /></td>
                    </tr><?php	
                }    
                $supIds = SqlLi('SELECT supplier FROM dr_perimeter_supplier_map WHERE perimeter='.$perimeter);
                $getSupIds = array(); // get supplier Id

                foreach ($supIds as $supId){
                    $getSupIds[] = $supId['supplier'];
                }

                $displayIds =implode(',',$getSupIds);	

                $unmappedSupName = array_diff($totalSups,$supArr);
                $unmappedSupId = array_diff($totalSupIds,$sup_id);
    
                ?><tr class="infoRow">					
                    <td style="display:none"><input style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;padding: 5px;background: no-repeat;border: none;" type="text" name="multiple_sups" id="multiple_sups<?php echo $supplier['supplier_id']; ?>" value="<?php echo $supplier['supplier']; ?>"/></td>
                    <td style="display:none;padding:5px;background-color:#e7e7e8;" ><input style="margin-left:8px;" value="<?php echo $supplier['supplier_id']; ?>" type="checkbox" name="chk" id="chk" class="removeSupIds" onclick="deleteSupRow(this)" /></td>
                </tr><?php
            
                ?><input id="screen_value" type="hidden" name="screen_value" value="<?php echo $displayIds ?>">
                <input id="screen" type="hidden" name="screen" value="">
            
            </tbody>
        </table>
        <br/><br/><?php
    
        ?><div class="assigned_sups" style="text-align:left">
            <label style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;">User Supplier :&nbsp;&nbsp;</label>
            
            <select id="assigned_sup" name="assigned_sup" style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;"><?php
                foreach($unmappedSupId as $index => $sup)
                {
                    ?><option id="<?php echo $sup?>" value="<?php echo $sup?>"><?php echo $unmappedSupName[$index]?></option><?php
                }	
            ?></select>
            <input class="stdBtn" type="button" value="Add User Supplier &#9658;" onclick="addSupRow('dataTable')" />
        </div><?php
        
    }  else {
        ?><input id="screen" type="hidden" name="screen" value="">
        <table id="dataTable" class="criteriaTable" style="width:380px;" >
            <tbody>
                <tr class="tableGroup prmRow">
                    <td class="paramDef">Assigned User Supplier</td>
                    <td class="paramDef">Remove</td>
                </tr>
		<tr class="infoRow">					
                    <td style="display:none"><input style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;padding: 5px;background: no-repeat;border: none;" type="text" name="multiple_sups" id="multiple_sups<?php echo $supplier['supplier_id']; ?>" value="<?php echo $supplier['supplier']; ?>"/></td>
                    <td style="display:none;padding:5px;background-color:#e7e7e8;" ><input style="margin-left:8px;" value="<?php echo $supplier['supplier_id']; ?>" type="checkbox" name="chk" id="chk" class="removeSupIds" onclick="deleteSupRow(this)" /></td>
		</tr>
            </tbody>
	</table>
        <br/><br/>
        <div class="assigned_sups" style="text-align:left">
            <label style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;">User Supplier :&nbsp;&nbsp;</label>
            <select id="assigned_sup" name="assigned_sup" style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 10px;"><?php
                foreach($allSups as $suppliers)
                {								
                    ?><option id="<?=$suppliers['supplier_id']?>" value="<?=$suppliers['supplier_id']?>"><?=$suppliers['supplier']?></option><?php
                }
            ?></select>
            
            <input class="stdBtn" type="button" value="Add User Supplier &#9658;" onclick="addSupRow('dataTable')" />
        </div><?php
    }         
}

?>