<?php
if($pathLevel=='')$pathLevel=2;
$pathDeep='';
for($i=0;$i<$pathLevel;$i++)$pathDeep.='../';
require_once($pathDeep.'support.php');
require_once($pathDeep.'common/php/common.php');

function allowedMsn($SESSION,$program='',$all=0,$sort=''){
	$allowedMsnList=array();
	if($program==''){
		$program=getFilter('program','filter',0,$SESSION);
	}
	if($sort!=''){
		$sortString.=' ORDER BY msn '.$sort;
	}
	$allMsn=sqlLi('SELECT m.msn_id,m.msn,r.review_profile_id
					FROM c_program AS p 
						INNER JOIN c_msn 				AS m  ON p.program_id=m.program 
						LEFT JOIN dr_review_profile		AS r  ON p.program_id=r.program
					WHERE m.program="'.$program.'" AND m.msn_hidden=0'.$sortString);       
	if(is_array($allMsn)){
		foreach($allMsn as &$a){
			if($all==1 || checkPermission('review_profile_id','view',$a['review_profile_id'],'check',$SESSION,0)==1 || checkPermission('dr_review_profile_general','view',0,'check',$SESSION)==1)
				$allowedMsnList[$a['msn_id']]=$a['msn'];
		}
	}
	return $allowedMsnList;
}
function allowedReviews($SESSION,$action='view',$whereClause=''){
		if($whereClause!=''){
			$qryString.=' WHERE '.$whereClause;
		}
		if(checkPermission('dr_review_profile_general',$action,0,'check',$SESSION)==1){
			return SqlAsArr('SELECT review_profile_id,review_type FROM dr_review_profile'.$qryString.' ORDER BY review_profile_order ASC','review_profile_id','review_type'); //JFM 15_09_15
		}else{
			return allowedSimpleObject('review_profile','review_type',$SESSION,'dr_',$whereClause,$action,'','ORDER BY review_profile_order ASC'); //JFM 15_09_15
		}
}
function allowedSimpleObject($object,$column,$SESSION,$tableType='c_',$whereClause='',$action='view',$sort='',$customSort='') //JFM 15_09_15
{
	$qryString='SELECT '.$object.'_id,'.$column.' FROM '.$tableType.$object;
	$addConditions=array();
	if($whereClause!='')
	{
		$qryString.=' WHERE '.$whereClause;
	}
	if($sort!='')
	{
		$qryString.=' ORDER BY '.$object.' '.$sort;
	}
	else if ($customSort!='') //JFM 15_09_15
	{
		$qryString.=' '.$customSort;
	}
	$itemsList=SqlAsArr($qryString,$object.'_id',$column);
	if(is_array($itemsList))
	{
		foreach($itemsList as $k=>$v)
		{
			//JFM 12_01_16 if(checkPermission($object.'_id',$action,$k,'check',$SESSION,0)==1 || checkPermission($tableType.$object.'_general',$action,0,'check',$SESSION,0)==1){
			if(checkPermission($object.'_id',$action,$k,'check',$SESSION,0)==1 || 
				checkPermission($tableType.$object.'_general',$action,0,'check',$SESSION,0)==1)
			{
				$allowedItemsList[$k]=$v;
			 }
			 else if($object == 'msn') //JFM 08_06_16
			 {
			 	$allowedItemsList[$k]=$v;
			 }
		}
		return $allowedItemsList;
	}else return'';
}
function checkEditableCa($ca,$SESSION)
{
	$editablePerimeter=1;
	$perimeter=SqlSLi('SELECT DISTINCT perimeter FROM c_ca WHERE ca_id IN ('.$ca.')','perimeter');
	if(is_array($perimeter))
	{
		foreach($perimeter as $p)
		{
			if(checkPermission('perimeter_id','edit',$p,'check',$SESSION)!=1)
			{
				$editablePerimeter=0;
			}
		}
	}
	
	if(checkPermission('program_id','edit',getFilter('program','filter',0,$SESSION),'check',$SESSION)==1 &&
				checkPermission('coe_id','edit',getFilter('coe','filter',0,$SESSION),'check',$SESSION)==1 &&
				$editablePerimeter==1)
	{
		return 1;
	}
	else if (checkPermission('c_ca_general','edit',0,'check',$SESSION)==1) //JFM 19_07_16
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
function convertToDate($date){
	$dateSplitted=explode('-',$date);
	return mktime(0,0,0,$dateSplitted[1],$dateSplitted[2],$dateSplitted[0]);
}
function defineReviewCa($element,$target,$SESSION){
	if($target=='' || $target=='ca'){
		$enabledCa=SqlSli('SELECT ca
							FROM c_cawp
							WHERE ca IN('.$element.')
								AND msn='.getFilter('msn','filter',0,$SESSION).'
								AND cawp_disabled=0','ca');
		return implode(',',$enabledCa);
	}else{
		$caInWp=SqlSLi('SELECT ca
							FROM c_cawp
							WHERE wp IN('.$element.')
								AND msn='.getFilter('msn','filter',0,$SESSION).'
								AND cawp_disabled=0','ca');
		}
		return implode(',',$caInWp);
}
function download($type,$file,$name){
	header('Cache-Control: max-age=60');
	switch($type){
		case 'xml':
			header('Content-type: application/xml; charset=UTF-8');
		break;
		default:
			header('Content-type: application/octet-stream');
		break;
	}
	header('Content-Disposition: attachment; filename='.urldecode($name));
	header("Cache-Control: private");
	header("Pragma: private");
	if($type=='zip'){
		echo $file->file();
	}else{
		readfile($file);
	}
}
function fai($kodd){
	if($kodd!='0000-00-00' && $kodd!=''){
		$FAIDate=strtotime($kodd." -2 week");
		$dWeek=date("w",$FAIDate);
		if($dWeek==0)$dWeek=7;
		if($dWeek>4)$FAIDate=$FAIDate-(($dWeek-4)*24*60*60);
		return date("Y-m-d",$FAIDate);
	}else return '';
}
function getFilter($object,$action,$applicability,$SESSION){
	return $SESSION['filter'][$SESSION['object'][$object]][$SESSION['user_action'][$action]][$applicability];
}
function getResponsibles($reviewId,$SESSION)
{
	/*$responsibleConfigurationExists=SqlQ('SELECT responsible_configuration_id
										FROM dr_responsible_configuration
										WHERE program="'.$programId.'"
										LIMIT 1');
	if(!$responsibleConfigurationExists){
		importResponsibleConfiguration($programId);
	}
	
	if($server==''){
		global $p12;
		$server=$p12;
	}
	if($onlyA0==1)$a0Qry=' AND g.a0_display="1"';

	if($ca!=''){
		$respPeopleQry=mysql_query('SELECT ca,responsible_id,responsible,responsible_configuration 
			FROM dr_responsible 
			WHERE ca IN('.$ca.')',$server) or die(mysql_error());
		
		while($r=mysql_fetch_assoc($respPeopleQry)){
			$respPeople[$r['responsible_configuration']][$r['ca']]['responsible_id']=$r['responsible_id'];
			$respPeople[$r['responsible_configuration']][$r['ca']]['responsible']=$r['responsible'];
			$respPeople[$r['responsible_configuration']][$r['ca']]['responsible_configuration']=$r['responsible_configuration'];
		}
		
		if(is_array($respPeople)){
			foreach($respPeople as $k=>&$v){
				$respIdMlt=combinedResult($v,'responsible_id','text',$SESSION);
				$respMlt=combinedResult($v,'responsible','text',$SESSION);
				$respId[$k]=$respIdMlt;
				$respName[$k]=$respMlt;
			}
		}
	}
	
	$respQry=mysql_query('SELECT c.responsible_configuration_id,c.group_position,c.role_position,g.responsible_group_id,g.responsible_group,g.a0_display,rl.responsible_role 
		FROM dr_responsible_configuration AS c 
			INNER JOIN dr_responsible_group AS g ON c.responsible_group=g.responsible_group_id
			INNER JOIN dr_responsible_role AS rl ON c.responsible_role=rl.responsible_role_id
		WHERE c.program="'.$programId.'"'.$a0Qry,$server) or die(mysql_error());
	
	while($resp=mysql_fetch_assoc($respQry)){
		if($returnAll==1 || ($returnAll==0 && getFilter('dr_responsible_configuration_general','hide',$resp['responsible_configuration_id'],$SESSION)!=1)){
			$responsible['group'][$resp['group_position']]=$resp['responsible_group'];
			$responsible['role'][$resp['group_position']][$resp['role_position']]=$resp['responsible_role'];
			$responsible['config'][$resp['group_position']][$resp['role_position']]=$resp['responsible_configuration_id'];
			$responsible['group_id'][$resp['group_position']]=$resp['responsible_group_id'];
			$responsible['group_count'][$resp['group_position']]++;
			if($ca!='' && is_array($respPeople)){
				$responsible['id'][$resp['group_position']][$resp['role_position']]=$respId[$resp['responsible_configuration_id']];
				$responsible['name'][$resp['group_position']][$resp['role_position']]=$respName[$resp['responsible_configuration_id']];
			}
		}
	}*/
	$responsible=SqlLi('SELECT r.*, rr.*
							FROM dr_responsible AS r
							INNER JOIN dr_responsible_role AS rr ON rr.responsible_role_id=r.role
							WHERE r.review='.$reviewId.'
							ORDER BY position ASC');

	return $responsible;
}
function hideAllResponsible($hide,&$SESSION,$programId=''){
	/*if($programId=='')$programId=getFilter('program','filter',0,$SESSION);
	$responsible=getResponsibles($programId,$SESSION,1);
	if(is_array($responsible)){
		foreach($responsible['group'] as $groupPosition=>$group){
			foreach($responsible['role'][$groupPosition] as $rolePosition=>&$role){
				modifyFilter('dr_responsible_configuration_general','hide',$responsible['config'][$groupPosition][$rolePosition],$hide,$SESSION,1);
				$modifiedField[]=$SESSION['object']['dr_responsible_configuration_general'].'-'.$SESSION['user_action']['hide'].'-'.$responsible['config'][$groupPosition][$rolePosition];
			}
		}
	}
	return $modifiedField;*/
}
function hideAllReviewColumns($review,$hide,&$SESSION){
	$allreviews=explode(',',$review);
	foreach($SESSION['table']['review_planning']['review'] as $fieldName=>&$fieldDetails){
		if($hide==1 || ($hide==0 && $fieldName!='criteria_status')){
			foreach($allreviews as $k=>$v)
			{
				modifyFilter($fieldName,'hide',$v,$hide,$SESSION,1);
				$modifiedField[]=$SESSION['object'][$fieldName].'-'.$SESSION['user_action']['hide'].'-'.$v;
			}
		}
	}
	return $modifiedField;
}
function importResponsibleConfiguration($to,$from=0){
	if($from==0){
		$firstValidProgram=SqlQ('SELECT r.program
									FROM dr_responsible_configuration AS r
										INNER JOIN c_program AS p ON r.program=p.program_id
									LIMIT 1');
		$from=$firstValidProgram['program'];
	}
	
	SqlLQ('INSERT INTO dr_responsible_configuration
				(program,responsible_group,responsible_role,group_position,role_position)
				SELECT "'.$to.'",responsible_group,responsible_role,group_position,role_position
				FROM dr_responsible_configuration
				WHERE program="'.$from.'"');
}
function modifyFilter($object,$action,$applicability,$value,&$SESSION,$sql){
	if(getFilter($object,$action,$applicability,$SESSION)!=$value){
		if($sql==1){
			$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
			$filterId=SqlQ('SELECT user_filter_id FROM dr_user_filter WHERE user="'.$viewAsUserId.'" AND object="'.$SESSION['object'][$object].'" AND action="'.$SESSION['user_action'][$action].'" AND applicability="'.$applicability.'"');
			if($filterId)SqlLQ('UPDATE dr_user_filter SET filter_value="'.$value.'" WHERE user_filter_id="'.$filterId['user_filter_id'].'"');
			else SqlLQ('INSERT INTO dr_user_filter (user,object,action,applicability,filter_value) VALUES ("'.$viewAsUserId.'","'.$SESSION['object'][$object].'","'.$SESSION['user_action'][$action].'","'.$applicability.'","'.$value.'")');
		}
		$SESSION['filter'][$SESSION['object'][$object]][$SESSION['user_action'][$action]][$applicability]=$value;
	}
}
/**
 * Start of bug 11
 * For Saving the clicked check box ids into the database
 * @param type $object
 * @param type $action
 * @param type $applicability
 * @param type $value
 * @param type $SESSION
 * @param type $sql
 * 
 */
function applyChange($object,$action,$applicability,$value,&$SESSION,$sql){
	if(getFilter($object,$action,$applicability,$SESSION)!=$value){

		if($sql==1){
                    $viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
                    $filterId=SqlQ('SELECT user_filter_id FROM dr_user_filter WHERE user="'.$viewAsUserId.'" AND object="'.$SESSION['object'][$object].'" AND action="'.$SESSION['user_action'][$action].'" AND applicability="'.$applicability.'"');
          
                    if($filterId)SqlLQ('UPDATE dr_user_filter SET filter_value="'.$value.'" WHERE user_filter_id="'.$filterId['user_filter_id'].'"');
                    else SqlLQ('INSERT INTO dr_user_filter (user,object,action,applicability,filter_value) VALUES ("'.$viewAsUserId.'","'.$SESSION['object'][$object].'","'.$SESSION['user_action'][$action].'","'.$applicability.'","'.$value.'")');
                    
		}

		$SESSION['filter'][$SESSION['object'][$object]][$SESSION['user_action'][$action]][$applicability]=$value;
	}

}
//End of bug 11
function nextResultButton($resultCount,$tableCacheId,$ajaxFile,$listName,$displayedResults,$SESSION,$ajaxMode='',$extraParameter=''){
	if($resultCount!=0){
		$maxResults=getFilter('max_results','view',0,$SESSION);
		$displayedResults=($resultCount>$maxResults)?$maxResults:$resultCount;
		?><input class="btnNextResult"id="requestNextResult_<?=$tableCacheId?>"onClick="nextResult('<?=$ajaxFile?>','<?=$listName?>','<?=$tableCacheId?>',<?=$maxResults?>,'<?=$ajaxMode?>','<?=$extraParameter?>');"type="button"value="&#9660; &#9660; Show next <?=number_format($displayedResults,0,'','.')?> Results out of <?=number_format($resultCount,0,'','.')?> left (<?=number_format($SESSION['table_result_count'][$tableCacheId],0,'','.')?> in total) &#9660; &#9660;"><?php
	}
}
function newCode($wp,$criteria,$SESSION,$type, $getFrom=''){
	$msnQry=SqlQ('SELECT msn FROM c_msn WHERE msn_id="'.getFilter('msn','filter',0,$SESSION).'"');
	$stdMsn=substr('000',0,4-strlen($msnQry['msn'])).$msnQry['msn'];
				
	if($getFrom == '')
	{						
		$reviewCode=SqlQ('SELECT rt.review_type_code
							FROM dr_review_type AS rt
								INNER JOIN dr_review_profile	AS rp ON rt.review_type_id=rp.review_type
								INNER JOIN dr_review_group		AS rg ON rt.review_type_id=rg.review_type
								INNER JOIN dr_review_criterion	AS rc ON rg.group_id=rc.review_group
							WHERE rc.review_criterion_id="'.$criteria.'"');
	}

	else if($getFrom == 'review') //JFM 09_04_14 - JFM 21_07_15
	{
		$reviewCode=SqlQ('SELECT rt.review_type_code
							FROM dr_review_type AS rt
								INNER JOIN dr_review_profile	AS rp ON rt.review_type_id=rp.review_type
								INNER JOIN dr_review			AS r  ON r.review_profile=rp.review_profile_id
							WHERE r.review_id="'.$criteria.'"');
	}

	else if($getFrom == 'risk') //JFM 08_06_16
	{
		$reviewCode=SqlQ('SELECT ca AS review_type_code FROM c_ca WHERE ca_id="'.$criteria.'"');
	}
	
	$programCode=SqlQ('SELECT program_code FROM c_program WHERE program_id="'.getFilter('program','filter',0,$SESSION).'"');
	$wpTxt=SqlQ('SELECT wp FROM c_wp WHERE wp_id="'.$wp.'"');
	
	$codeRoot=$programCode['program_code'].'-'.$reviewCode['review_type_code'].'-'.$stdMsn.'-'.$wpTxt['wp'];
	if($type=='rid') $codeRoot='RID-'.$codeRoot;
	if($type=='risk') $codeRoot='RISK-'.$codeRoot; //JFM 08_06_16
	
	$maxIdQry=SqlQ('SELECT MAX(RIGHT('.$type.'_code,3)) AS max_id FROM dr_'.$type.' WHERE LEFT('.$type.'_code,(LENGTH('.$type.'_code)-4))="'.$codeRoot.'"');
	$id=$maxIdQry['max_id']+1;
	
	return $codeRoot.'-'.str_pad($id,3,'0',STR_PAD_LEFT);
}
function newFileName($path,$extension,$fileNameLength){
	do{
		$fileName=$path.randomString($fileNameLength).'.'.$extension;
	}while(file_exists($fileName));
	return $fileName;
}
function newTableCacheId($SESSION){
	$tableCacheId=randomString(16);
	while($SESSION['table_result_count'][$tableCacheId]){
		$tableCacheId=randomString(16);
	}
	return $tableCacheId;
}
function perimeterPermission($SESSION,$action,$program='',$coe='')
{
	if($program=='')
	{
		$program=getFilter('program','filter',0,$SESSION);
	}
	if($coe=='')
	{
		$coe=getFilter('coe','filter',0,$SESSION);
	}
	/*
	* US #054
	* Version :2.0
	* Fixed by : Infosys Limited 
	* pie chart condittion
	*/
	if (!empty($program)) {
		$perimeter=SqlSLi('SELECT perimeter_id FROM c_perimeter WHERE program='.$program,'perimeter_id');
	}
	if(is_array($perimeter))
	{
		if(checkPermission('program_id',$action,$program,'check',$SESSION)==1 || checkPermission('c_program_general',$action,0,'check',$SESSION)==1) //JFM 12_01_16
		{
			if(checkPermission('coe_id',$action,$coe,'check',$SESSION)==1 || checkPermission('c_program_general',$action,0,'check',$SESSION)==1) //JFM 12_01_16
			{
				foreach($perimeter as &$perimeterId)
				{
					if(checkPermission('perimeter_id',$action,$perimeterId,'check',$SESSION)==1 || checkPermission('c_perimeter_general',$action,0,'check',$SESSION)==1)
					{
						$allowedPerimeter[$perimeterId]=1;
					}
				}
			}
		}			
	}
	return $allowedPerimeter;
}
function pictureStatus(&$status){
	if($status=='')$status=0;
	$activeStatus=array('off','off','off','off','off');
	$activeStatus[$status]='';
	return $activeStatus;
}
function repairReviewPosition($reviewProfile=''){ 
	if($reviewProfile!=''){
		//JFM 02_09_13$profileQry=' WHERE g.review_profile="'.$reviewProfile.'"';
		$profileQry=' WHERE rp.review_profile_id="'.$reviewProfile.'"';
	}
							
	//JFM 02_09_13	
	$profileId=SqlLi('SELECT DISTINCT rg.group_id,rp.review_profile_id
					  FROM dr_review_group 			 AS rg
						INNER JOIN dr_review_profile AS rp ON rp.review_type=rg.review_type'.$profileQry);
	
	if(is_array($profileId)){
		foreach($profileId as $p){
		
			//JFM 02_09_13
			$criteriaId=SqlAsArr('SELECT rch.criterion,rch.criterion_position
								  FROM dr_review_criterion_history AS rch
									INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
									INNER JOIN dr_review_group 	   AS rg ON rg.group_id=rc.review_group
									INNER JOIN dr_review_profile   AS rp ON rp.review_type=rg.review_type
								  WHERE rp.review_profile_id="'.$p['review_profile_id'].'" 
								  AND rg.group_id="'.$p['group_id'].'" 
								  ORDER BY rch.criterion_position ASC','criterion','criterion_position');
									
			$i=1;
		}
	}
	
	if($reviewProfile!='')$groupProfileId[0]['review_profile_id']=$reviewProfile;
	//JFM 02_09_13 else $groupProfileId=SqlLi('SELECT DISTINCT review_profile FROM dr_review_group');
	else $groupProfileId=SqlLi('SELECT DISTINCT rp.review_profile_id 
								FROM dr_review_profile 		   AS rp
									INNER JOIN dr_review_group AS rg ON rp.review_type=rg.review_type');
									
	if(is_array($groupProfileId)){
		foreach($groupProfileId as $g){
			//JFM 02_09_13 $groupId=SqlAsArr('SELECT review_group_id,group_position FROM dr_review_group WHERE review_profile="'.$g['review_profile'].'" ORDER BY group_position ASC','review_group_id','group_position');
			$groupId=SqlAsArr('SELECT rgh.review_group_history_id,rgh.review_group_position 
							   FROM dr_review_group_history  AS rgh
								INNER JOIN dr_review_group 	 AS rg ON rg.group_id=rgh.review_group
								INNER JOIN dr_review_profile AS rp ON rp.review_type=rg.review_type
							   WHERE rp.review_profile_id="'.$g['review_profile_id'].'" 
							   AND review_group_valid_to="0000-00-00 00:00:00"
							   ORDER BY review_group_position ASC, review_group_valid_from DESC','review_group_history_id','review_group_position');
			$i=1;
			if(is_array($groupId)){
				foreach($groupId as $k=>$v){
					if($v!=$i){
						SqlLQ('UPDATE dr_review_group_history SET review_group_position="'.$i.'" WHERE review_group_history_id="'.$k.'"');
					}
					$i++;
				}
			}
		}
	}
}
function saveResponsible($ca,$configuration,$newResponsibleName,$answerNeeded=0,&$answer='',&$firstItem=''){
	$existingResponsible=SqlAsArr('SELECT responsible_id,ca FROM dr_responsible WHERE ca IN ('.$ca.') AND responsible_configuration="'.$configuration.'"','ca','responsible_id');
	$caArray=explode(',',$ca);
	foreach($caArray as &$c){
		if($existingResponsible[$c]!=''){
			SqlLQ('UPDATE dr_responsible SET responsible="'.$newResponsibleName.'" WHERE responsible_id="'.$existingResponsible[$c].'"');
		}else{
			if($newResponsibleName!=''){
				SqlLQ('INSERT INTO dr_responsible (ca,responsible_configuration,responsible) VALUES ("'.$c.'","'.$configuration.'","'.$newResponsibleName.'")');
			}
		}
		if($answerNeeded==1){
			if($firstItem!=0)$answer.='&&&';
			else $firstItem=1;
			$answer.='dr_responsible_configuration_general_'.$c.'_'.$configuration.'%%%text%%%'.$newResponsibleName;
		}
	}
}
function setStandardValue($object,$action,$applicability,$stdValue,$SESSION,$sql){
	if(getFilter($object,$action,$applicability,$SESSION)=='')modifyFilter($object,$action,$applicability,$stdValue,$SESSION,$sql);
}
function similarName($name,$SESSION){
	$nameDistance=array();
	$nameLowerCase=strtolower($name);
	foreach($SESSION['user_list'] as $userId=>$userName)$nameDistance[$userId]=similar_text($nameLowerCase,strtolower($userName));
	arsort($nameDistance);
	foreach($nameDistance as $userId=>$distance){
		$sortedUser[$userId]=$SESSION['user_list'][$userId];
	}
	return $sortedUser;
}
function tabIt($v){
	if($v==''){?><font color="#999"size="-3">N/A</font><?php }
	else echo $v;
}
function txtBox($v,$id='',$cols=32,$rows=5){
	if($v){?><textarea class="listTextArea"cols="<?=$cols?>"<?php if($id){?>id="<?=$id?>"<?php }?>readonly rows="<?=$rows?>"style="border:0px;"><?=$v?></textarea><?php }
	else{?><font color="#999"size="-3">N/A</font><?php }
}
function updateActionApplicability($applicableCa,$actionId,$applicability){
	$actualApplicability=SqlBool('SELECT ca FROM dr_action_applicability WHERE action="'.$actionId.'"','ca');
	if(!is_array($actualApplicability)){
		$actualApplicability=array();
	}
	$totalApplicability=array_merge($applicability,$actualApplicability);
	
	$totalApplicability=$actualApplicability;
	
	foreach($applicability as $k=>$v){
		$totalApplicability[$k]=$v;
	}
	
	if(is_array($totalApplicability)){
		foreach($totalApplicability as $k=>$v){
			if($applicability[$k]==1){
				if($actualApplicability[$k]!=1){
					$caToInclude[]=$k;
				}
				
			}else{
				if($actualApplicability[$k]==1){
					$caToRemove[]=$k;
				}

			}
		}
	}
	
	if(is_array($caToInclude)){
		foreach($caToInclude as $c){
			SqlLQ('INSERT INTO dr_action_applicability (action,ca) VALUES ("'.$actionId.'","'.$c.'")');
		}
	}
	if(is_array($caToRemove)){
		SqlLQ('DELETE FROM dr_action_applicability WHERE action="'.$actionId.'" AND ca IN ("'.implode('","',$caToRemove).'")');
	}
}
function utf8enc($a,$ignoreSlashes=0){
	if(is_array($a)){
		foreach($a as $k=>$v){
			if(is_array($v)){
				$a[$k]=utf8enc($v);
			}else{
				if($ignoreSlashes==1){
					$a[$k]=utf8_encode($v);
				}else{
					$a[$k]=utf8_encode(stripslashes($v));
				}
			}
		}
	}
	return $a;
}

function date_parse_from_format_for_php_5_2_9($format, $date) 
{    
	$i=0;
	$pos=0;    
	$output=array();    
	while ($i< strlen($format)) 
	{      
		$pat = substr($format, $i, 1);      
		$i++;      

		switch ($pat) 
		{        
			case 'd': //    Day of the month, 2 digits with leading zeros    01 to 31          
				$output['day'] = substr($date, $pos, 2);          
				$pos+=2;       
			break;  

			case 'D': // A textual representation of a day: three letters    Mon through Sun          //TODO    
				$pos+=3;    
			break;  

			case 'j': //    Day of the month without leading zeros    1 to 31          
				$output['day'] = substr($date, $pos, 2);  

				if (!is_numeric($output['day']) || ($output['day']>31)) 
				{            
					$output['day'] = substr($date, $pos, 1);            
					$pos--;          
				}          

				$pos+=2;        
			break;

			case 'M': //    A short textual representation of a month: three letters    Jan through Dec
				$month_arr = array (
								    "Jan" => 1,
								    "Feb" => 2,
								    "Mar" => 3,
								    "Apr" => 4,
								    "May" => 5,
								    "Jun" => 6,
								    "Jul" => 7,
								    "Aug" => 8,
								    "Sep" => 9,
								    "Oct" => 10,
								    "Nov" => 11,
								    "Dec" => 12
								);

				$output['month'] = (int)$month_arr[substr($date, $pos, 3)];

				$pos+=3;

			break;

			case 'm': //    Numeric representation of a month: with leading zeros    01 through 12
				$output['month'] = (int)substr($date, $pos, 2);
				$pos+=2;
			break;

			case 'n': //    Numeric representation of a month: without leading zeros    1 through 12
				$output['month'] = substr($date, $pos, 2);

				if (!is_numeric($output['month']) || ($output['month']>12)) 
				{
					$output['month'] = substr($date, $pos, 1);
					$pos--;
				}

				$pos+=2;
			break;

			case 'Y': //    A full numeric representation of a year: 4 digits    Examples: 1999 or 2003
				$output['year'] = (int)substr($date, $pos, 4);
				$pos+=4;
			break;

			case 'y': //    A two digit representation of a year    Examples: 99 or 03
				$output['year'] = (int)substr($date, $pos, 2);
				$pos+=2;
			break;

			case 'g': //    12-hour format of an hour without leading zeros    1 through 12
				$output['hour'] = substr($date, $pos, 2);
				
				if (!is_numeric($output['day']) || ($output['hour']>12)) 
				{
					$output['hour'] = substr($date, $pos, 1);
					$pos--;
				}

				$pos+=2;
			break;

			case 'G': //    24-hour format of an hour without leading zeros    0 through 23
				$output['hour'] = substr($date, $pos, 2);

				if (!is_numeric($output['day']) || ($output['hour']>23)) 
				{
					$output['hour'] = substr($date, $pos, 1);
					$pos--;
				}

				$pos+=2;
			break;

			case 'h': //    12-hour format of an hour with leading zeros    01 through 12
				$output['hour'] = (int)substr($date, $pos, 2);
				$pos+=2;
			break;

			case 'H': //    24-hour format of an hour with leading zeros    00 through 23
				$output['hour'] = (int)substr($date, $pos, 2);
				$pos+=2;
			break;

			case 'i': //    Minutes with leading zeros    00 to 59
				$output['minute'] = (int)substr($date, $pos, 2);
				$pos+=2;
			break;

			case 's': //    Seconds: with leading zeros    00 through 59
				$output['second'] = (int)substr($date, $pos, 2);
				$pos+=2;
			break;
			case 'l': // (lowercase 'L')    A full textual representation of the day of the week    Sunday through Saturday
			case 'N': //    ISO-8601 numeric representation of the day of the week (added in PHP 5.1.0)    1 (for Monday) through 7 (for Sunday)
			case 'S': //    English ordinal suffix for the day of the month: 2 characters    st: nd: rd or th. Works well with j
			case 'w': //    Numeric representation of the day of the week    0 (for Sunday) through 6 (for Saturday)
			case 'z': //    The day of the year (starting from 0)    0 through 365
			case 'W': //    ISO-8601 week number of year: weeks starting on Monday (added in PHP 4.1.0)    Example: 42 (the 42nd week in the year)
			case 'F': //    A full textual representation of a month: such as January or March    January through December
			case 'u': //    Microseconds (added in PHP 5.2.2)    Example: 654321
			case 't': //    Number of days in the given month    28 through 31
			case 'L': //    Whether it's a leap year    1 if it is a leap year: 0 otherwise.
			case 'o': //    ISO-8601 year number. This has the same value as Y: except that if the ISO week number (W) belongs to the previous or next year: that year is used instead. (added in PHP 5.1.0)    Examples: 1999 or 2003
			case 'e': //    Timezone identifier (added in PHP 5.1.0)    Examples: UTC: GMT: Atlantic/Azores
			case 'I': // (capital i)    Whether or not the date is in daylight saving time    1 if Daylight Saving Time: 0 otherwise.
			case 'O': //    Difference to Greenwich time (GMT) in hours    Example: +0200
			case 'P': //    Difference to Greenwich time (GMT) with colon between hours and minutes (added in PHP 5.1.3)    Example: +02:00
			case 'T': //    Timezone abbreviation    Examples: EST: MDT ...
			case 'Z': //    Timezone offset in seconds. The offset for timezones west of UTC is always negative: and for those east of UTC is always positive.    -43200 through 50400
			case 'a': //    Lowercase Ante meridiem and Post meridiem    am or pm
			case 'A': //    Uppercase Ante meridiem and Post meridiem    AM or PM
			case 'B': //    Swatch Internet time    000 through 999
			default:
				$pos++;
		}
	}

	return  $output;  
}
function checkExternal($SESSION){
if(isset($SESSION['user']['view_as']))
{	//echo "<script> alert('in if'); </script>";
    $SESSION['externalUsr']=  SqlQ('SELECT type from c_user WHERE user_id="'.$SESSION['user']['view_as'].'"');

}
else
{	//echo "<script> alert('in if'); </script>";
    $SESSION['externalUsr']=  SqlQ('SELECT type from c_user WHERE user_id="'.$SESSION['user']['user_id'].'"');
	}
	storeSession($SESSION);
return $SESSION['externalUsr']['type'];
}

/**
 * Function to update the Database with Master CSV values
 * @param Object $SESSION
 * @param String $criterion_user_id
 * @param String $criterion_name
 * @param String $criterion_description
 * @param Interger $criterion_showstopper
 * @param String $criterion_moc
 * @param String $review_group_description
 * @param String $grams_reference
 * @param String $criterion_validity_id
 * @param String $criterion_id
 * @param String $review_group
 * @param Array $validatorSplit
 */
function updateDatabase($SESSION, $criterion_user_id, $criterion_name, $criterion_description, $criterion_showstopper, $criterion_moc, $review_group_description, $review_group_position, $grams_reference, $criterion_validity_id, $criterion_id, $review_group, $validatorSplit=array()) {

    $criterion = SqlQ('SELECT rca.review_criterion_applicability_valid_from, rch.criterion_position  
                    FROM dr_review_criterion_applicability AS rca
                    INNER JOIN 	dr_review_criterion_history AS rch ON rch.criterion=rca.criterion
                    WHERE rch.criterion_validity_id =' .$criterion_validity_id);
    
    SqlLQ('INSERT INTO dr_review_criterion_history (criterion,criterion_user_id,criterion_name,criterion_description,criterion_position,criterion_showstopper,criterion_moc,criterion_valid_from) 
        VALUES ("' . $criterion_id . '","' . $criterion_user_id . '","' . $criterion_name . '","' . $criterion_description . '","' . $criterion['criterion_position'] . '","' . $criterion_showstopper . '","' . $criterion_moc . '","0000-00-00 00:00:00")');

    $criterionHistoryID=SqlQ('SELECT LAST_INSERT_ID() AS criterionHistoryID');
    
    // To create new Group when the group name entered by the user is not present in database
    $reviewGroupID = SqlQ('SELECT rg.group_id
            FROM dr_review_group_history AS rgh
                INNER JOIN dr_review_group 	AS rg ON rgh.review_group=rg.group_id
                INNER JOIN dr_review_profile AS rp ON rg.review_type=rp.review_type
            WHERE rp.review_profile_id="'.$SESSION['list_cat']['review_profile'].'"
            AND rgh.review_group_description = "' . $review_group_description . '" AND rgh.review_group_valid_to="0000-00-00 00:00:00"');
    
    if(!$reviewGroupID) {   
        $review_type = SqlQ('SELECT review_type FROM dr_review_profile WHERE review_profile_id='. $SESSION['list_cat']['review_profile']);

        SqlLQ('INSERT INTO dr_review_group (review_type) VALUES ("'.$review_type['review_type'].'")');
        $reviewGroupID = SqlQ('SELECT LAST_INSERT_ID() AS group_id');
        
        SqlLQ('INSERT INTO dr_review_group_history (review_group, review_group_description, review_group_position, review_group_valid_from) VALUES ("'.$reviewGroupID['group_id'].'","'.$review_group_description.'","'.($review_group_position+1).'",SYSDATE())');
        
        SqlLQ('UPDATE dr_review_criterion
               SET review_group="'.$reviewGroupID['group_id'].'"
               WHERE review_criterion_id='.$criterion_id);
    } else {
        // To Update the Group information when the group name has been modified/renamed
        SqlLQ('UPDATE dr_review_criterion
               SET review_group="'.$reviewGroupID['group_id'].'"
               WHERE review_criterion_id='.$criterion_id);
    }

    if ($grams_reference != '') {
        $grams_array = explode(', ', $grams_reference);
        
        SqlQ('DELETE FROM dr_review_criterion_applicability
                WHERE criterion=' . $criterion_id . ' 
                AND object=(SELECT object_id FROM c_object WHERE object="grams_id")');
        
        for($i=0; $i<count($grams_array); $i++) {
            // To select the Grams ID based on the grams reference
            $gramsId = SqlQ('SELECT grams_id FROM c_grams WHERE grams_reference="' . $grams_array[$i] . '" ORDER BY grams_id DESC LIMIT 1');

            if ($gramsId) {
                // Updte the Reference with new value
                SqlQ('UPDATE dr_review_criterion_applicability 
                        SET review_criterion_applicability_valid_to="0000-00-00 00:00:01" 
                        WHERE criterion=' . $criterion_id . ' 
                        AND applicability=' . $gramsId['grams_id'] . ' 
                        AND object=(SELECT object_id FROM c_object WHERE object="grams_id")');                
            }
            
            SqlQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
                VALUES ('.$criterion_id.','.$gramsId['grams_id'].',(SELECT object_id FROM c_object WHERE object="grams_id"))'); 
        }
         
    }

    forceValidateCriteria($SESSION, $criterionHistoryID['criterionHistoryID'], $criterion_id);
    // To update the Validator details
    $chID = $criterion_validity_id;

    SqlLQ('SELECT user_id FROM c_user WHERE name="' . $validatorSplit[1] . '" AND surname="' . $validatorSplit[0] . '"');
    SqlLQ('UPDATE dr_validation_loop
    SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="modified"),
    action_taken_on=SYSDATE()
    WHERE object=(SELECT object_id FROM c_object WHERE object="criterion_validity_id")
    AND applicability="' . $chID . '"
    AND validator=' . $SESSION['user']['user_id'] . '
    AND action_taken=0');

    // To update the validation_loop_structure_step to 1 when the criteria is modified
    SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
    VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"' . $chID . '",(SELECT user_id FROM c_user WHERE name="' . $validatorSplit[1] . '" AND surname="' . $validatorSplit[0] . '"),' . 1 . ')');

    SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
            VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"' . $chID . '",(SELECT user_id FROM c_user WHERE name="' . $validatorSplit[1] . '" AND surname="' . $validatorSplit[0] . '"),' . 1 . ',SYSDATE())');        
}

/*
 * Function to force validate the criteria when modified/added from CSV file
 * @param Object $SESSION
 * @param String $criterion_validity_id
 * @param String $criterion_id
 */
function forceValidateCriteria($SESSION, $criterion_validity_id, $criterion_id) {
    
    SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
        VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$criterion_validity_id.'",'.$SESSION['user']['user_id'].',0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="validated"),SYSDATE())');

    SqlLQ('UPDATE dr_review_criterion_history  
        SET criterion_valid_from=SYSDATE() 
        WHERE criterion_validity_id='.$criterion_validity_id);

    SqlLQ('UPDATE dr_review_criterion_applicability 
        SET review_criterion_applicability_valid_from=SYSDATE()
        WHERE criterion='.$criterion_id.'
        AND review_criterion_applicability_valid_from="0000-00-00 00:00:00"');
}

/*
 * Function validate the values entered in CSV
 * @param String $criterion_user_id
 * @param String $criterion_moc
 * @param Integer $criterion_showstopper
 * @param Integer $review_group_position
 * @param String $grams_reference
 * @return Array $invalidRefArray
 */
function columnValidation($action, $criterion_user_id, $criterion_moc, $criterion_showstopper, $review_group_position, $grams_reference) {
    
    $invalidRefArray = array();
    
    //To validate the Action
    if($action != 'modify' && $action != 'add' && $action != 'delete') {
        $invalidRefArray[$criterion_user_id]['Action'] = $action;
    }
    
    // To validate Priority
    if($criterion_moc != 'Low' && $criterion_moc != 'Medium' && $criterion_moc != 'High' && $criterion_moc != '') {
        $invalidRefArray[$criterion_user_id]['Priority'] = $criterion_moc;
    }

    // To validate Show stopper
    if($criterion_showstopper != 0 && $criterion_showstopper != 1) {
        $invalidRefArray[$criterion_user_id]['Show stopper'] = $criterion_showstopper;
    }

    // To validate Group position
    if(!preg_match('/^[1-9]*[0-9]*$/', $review_group_position)) {
        $invalidRefArray[$criterion_user_id]['Group position'] = $review_group_position;
    }

    // To validate Grams reference
    if($grams_reference != '') {
        $grams_array = explode(', ', $grams_reference);
        
        for($i=0; $i<count($grams_array); $i++) {
            $gramsId = SqlQ('SELECT grams_id FROM c_grams WHERE grams_reference="' . $grams_array[$i] . '" ORDER BY grams_id DESC LIMIT 1');
            if(!$gramsId) {
                $invalidRefArray[$criterion_user_id]['Grams reference'] = $grams_array[$i];
            }
        }
        
    }
    return $invalidRefArray;
}

/**
 * Function to select the criteria list that has to be exported to CSV
 * @param object $SESSION
 * @param String $reviewProfile
 * @param String $reviewID
 * @param String $reviewMa
 * @return Object $rawData
 */
function criteriaList($SESSION, $reviewProfile, $reviewID, $reviewMa='') {
    
    if($reviewProfile == '') {
        $reviewProfile = $SESSION['list_cat']['review_profile'];
    }
    $query = 'SELECT rch.criterion_validity_id,rch.criterion,rgh.review_group,rch.criterion_user_id,rch.criterion_name,rch.criterion_description,rch.criterion_showstopper,rch.criterion_moc,
        rgh.review_group_description,rgh.review_group_position,
        GROUP_CONCAT(g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS grams_reference,
        rch.criterion_valid_from ';

    if ($reviewMa)
        $query .= ',rm.review_master_id AS criterion_included ';

    $query .= 'FROM  dr_review_criterion_history as rch 
        INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion 
        INNER JOIN dr_review_group AS rg ON rg.group_id=rc.review_group
        INNER JOIN dr_review_group_history AS rgh ON rgh.review_group=rg.group_id 
        INNER JOIN dr_review_profile AS rp ON rg.review_type=rp.review_type
        LEFT JOIN dr_review_criterion_applicability AS rca ON rc.review_criterion_id=rca.criterion 
        LEFT JOIN c_grams AS g ON rca.applicability=g.grams_id AND rca.object=' . $SESSION['object']['grams_id'] . '    
            AND (rca.review_criterion_applicability_valid_to="0000-00-00 00:00:00" OR rca.review_criterion_applicability_valid_to="0000-00-00 00:00:01")
        LEFT JOIN c_program AS pro ON pro.program_id=rp.program ';

    if ($reviewMa) {
        $query .= 'LEFT JOIN (SELECT * FROM dr_review_master AS rm INNER JOIN dr_review_master_history AS rmh ON rm.review_master_id=rmh.review_master AND rmh.review_master_valid_to="0000-00-00 00:00:00" )
            AS rm ON rm.review_type=rp.review_type AND rm.criterion=rc.review_criterion_id ';
    }
    $query .= 'WHERE rch.criterion_valid_to="0000-00-00 00:00:00" AND review_profile_id=' . $reviewProfile . ' AND rgh.review_group_valid_to="0000-00-00 00:00:00" AND rch.criterion_hidden=0
        GROUP BY rch.criterion_validity_id ORDER BY rch.criterion_user_id ASC';

    $rawData = SqlLi($query);

    foreach ($rawData as $q => $z) {
        
        //Is validated?
        $rawData[$q]['criterion_valid'] = ($z['criterion_valid_from'] == "0000-00-00 00:00:00") ? 'No' : 'Yes';

        // Is included?
        if ($reviewID || $reviewMa) {
            $rawData[$q]['criterion_included'] = ($z['criterion_included'] != "" && $z['criterion_valid_from'] != "0000-00-00 00:00:00") ? 'Yes' : 'No';
        } else {
            $rawData[$q]['criterion_included'] = '-1';
        }
        
        // To fetch the Grams reference with comma seperated when criteria have multiple references
        $columns=array('grams_reference');
					
        foreach($columns as $column)
        {
            $array1=explode(", ",$z[$column]);

            $rawData[$q][$column]='';

            foreach($array1 as $a1)
            {
                $array2=explode("---",$a1);

                if($column=="grams_reference")
                {
                        if(empty($rawData[$q]['grams_reference'])) $rawData[$q]['grams_reference']=$array2[0];
                        else $rawData[$q]['grams_reference']=$rawData[$q]['grams_reference'].', '.$array2[0];
                }
            }
        }
    }
    return $rawData;
}

?>