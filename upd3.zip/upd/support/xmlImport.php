<?php
require_once('header.php');
require_once('localSupport.php');
require_once('form.php');
session_start();
$SESSION=$_SESSION;

function actionCheckerLauncher($actionLocation,&$a0Config,$SESSION){
	if($actionLocation['act_reference']){
		checkAction($actionLocation,$a0Config,$SESSION);
	}elseif($actionLocation){
		foreach($actionLocation as &$action)
			checkAction($action,$a0Config,$SESSION);
	}	
}

function arrayNormalized($oldArray){
	foreach($oldArray as $field=>&$value){
		if(is_array($value))$newArray[$field]=($value['body']['p']['span'] && is_array($value['body']['p']['span']))?$value['body']['p']['span']['_value']:$value['body']['p']['_value'];
		else $newArray[$field]=$value;
	}
	if($newArray['actionholder']!=''){
		$newArray['actionholder']=str_replace(array('\r\n','\n\r','\n','\r','
'),'',$newArray['actionholder']);
	}
	return $newArray;
}

function checkAction($actionRaw,&$a0Config,$SESSION){
	print_r($actionRaw);
	if(!is_array($action['actiondescription'])){
		$action=arrayNormalized($actionRaw);
		
		if(!is_array($action['WPCAApp'])){
			$actionApplicability[]=$action['WPCAApp'];
		}elseif(is_array($action['WPCAApp']['value'])){
			foreach($action['WPCAApp']['value'] as &$a){
				$actionApplicability[]=$a;
			}
		}
		
		if(is_array($actionApplicability)){
			$actionHolderName=($action['actionholderid']=='' || $action['actionholderid']==0)?$action['actionholder']:'';
			
			$actionId=existingId($action['action_id'],$a0Config['action_a0_id'][$action['action_a0_id']]);
			
			$newAction=0;
			if($actionId!=''){
				$newAction=1;
				$actionQry=SqlQ('INSERT INTO dr_action
										(msn,criteria,action_code,action_description,action_creation,action_completion,action_status,action_holder,action_holder_name,action_a0_id)
									VALUES
										("'.$a0Config['msn'].'","'.$a0Config['criteria_id'].'","'.newCode($a0Config['wp'],$a0Config['criteria_id'],$SESSION,'action').'","'.$action['actiondescription'].'","'.$action['actioncreationdate'].'","'.$action['actionduedate'].'","'.$a0Config['a0_status_translation'][$action['act_status']].'","'.$action['actionholderid'].'","'.$actionHolderName.'","'.$action['action_a0_id'].'",);
								SELECT LAST_INSERT_ID() AS action_id');
				$actionId=$actionQry['action_id'];
				$appToAdd=$actionApplicability;
				$a0Config['action_a0_id'][$action['action_a0_id']]=$actionId;
			}else{
				SqlLQ('UPDATE dr_action
						SET action_description="'.$action['actiondescription'].'",action_creation="'.$action['actioncreationdate'].'",action_completion="'.$action['actionduedate'].'",action_status="'.$a0Config['a0_status_translation'][$action['act_status']].'",action_holder="'.$action['actionholderid'].'",action_holder_name="'.$actionHolderName.'",action_a0_id="'.$action['action_a0_id'].'"
						WHERE action_id="'.$actionId.'"');
				
				$oldActionApplicability=SqlSLi('SELECT ca FROM dr_action_applicability WHERE action="'.$actionId.'"','ca');
				
				if(is_array($actionApplicability)){
					foreach($actionApplicability as &$a){
						if(!in_array($a,$oldActionApplicability))$appToAdd[]=$a;
					}
				}
				
				if(is_array($oldActionApplicability)){
					foreach($oldActionApplicability as &$o){
						if(!in_array($o,$actionApplicability))$appToRemove[]=$o;
					}
				}
			}
			
			if(is_array($appToAdd)){
				foreach($appToAdd as &$a){
					SqlLQ('INSERT INTO dr_action_applicability (action,ca) VALUES ("'.$actionId.'","'.$a.'")');
				}
			}
			
			if(is_array($appToRemove)){
				foreach($appToRemove as &$a){
					SqlLQ('DELETE FROM dr_action_applicability WHERE action="'.$actionId.'" AND ca="'.$a.'"');
				}
			}
		
			if(!is_array($rid['ridtitle']) && !is_array($rid['rid_creation_date']) && !is_array($rid['ridholder']) && !is_array($rid['rid_completion_date'])){
				$ridId=existingId($action['ridid'],$a0Config['rid_a0_id'][$action['rid_a0_id']]);
				$ridHolderName=($action['ridholderid']=='' || $action['ridholderid']==0)?$action['ridholder']:'';
				$newRid=0;
				if($ridId==''){
					SqlLQ('INSERT INTO dr_rid
								(criteria,rid_code,rid_title,rid_status,rid_holder,rid_holder_name,rid_creation,rid_completion,rid_a0_id)
							VALUES
								("'.$a0Config['criteria_id'].'","'.newCode($a0Config['wp'],$a0Config['criteria_id'],$SESSION,'rid').'","'.$action['ridtitle'].'","'.$a0Config['a0_status_translation'][$action['ridstatus']].'","'.$action['ridholderid'].'","'.$ridHolderName.'","'.$action['rid_creation_date'].'","'.$action['rid_completion_date'].'","'.$action['rid_a0_id'].'");
							SELECT LAST_INSERT_ID() AS rid_id');
					$ridId=$actionQry['rid_id'];
					$a0Config['rid_inserted'][$ridId]=1;
					$newRid=1;
				}
				SqlLQ('UPDATE dr_action SET rid="'.$ridId.'" WHERE action_id="'.$actionId.'"');
				if($newRid==0 && $a0Config['rid_inserted'][$ridId]!=1){
					SqlLQ('UPDATE dr_rid
							SET rid_title="'.$action['ridtitle'].'",rid_status="'.$a0Config['a0_status_translation'][$action['ridstatus']].'",rid_holder="'.$action['ridholderid'].'",rid_holder_name="'.$ridHolderName.'",rid_creation="'.$action['rid_creation_date'].'",rid_completion="'.$action['rid_completion_date'].'",rid_a0_id="'.$action['rid_a0_id'].'"
							WHERE rid_id="'.$ridId.'"');
					$a0Config['rid_inserted'][$ridId]=1;
				}
				$a0Config['rid_a0_id'][$action['rid_a0_id']]=$ridId;
			}
		}
	}
}

function checkCriteria($criteriaRaw,&$a0Config,$SESSION){
	$criteria=arrayNormalized($criteriaRaw);
	
	if(is_array($a0Config['db_criteria_status'][$a0Config['ca']])){
		SqlLQ('UPDATE dr_criteria_status SET criteria_status="'.$criteria['status'].'",criteria_focal_point="'.$criteria['action_by'].'",criteria_comments="'.$criteria['comment'].'"
					WHERE msn="'.$a0Config['msn'].'" AND ca="'.$a0Config['ca'].'" AND review_criteria="'.$criteria['criteria_id'].'"');
	}else{
		SqlLQ('INSERT INTO dr_criteria_status (msn,ca,review_criteria,criteria_status,criteria_focal_point,criteria_comments)
					VALUES ("'.$a0Config['msn'].'","'.$a0Config['ca'].'","'.$criteria['criteria_id'].'","'.$criteria['status'].'","'.$criteria['action_by'].'","'.$criteria['comment'].'")');
	}
	if($a0Config['actions_inserted']==0){
		$rid=$criteria['rid'];
		$a0Config['criteria_id']=$criteria['criteria_id'];
		if($rid['ridcode'] || is_array($rid['ridcode'])){
			actionCheckerLauncher($rid['action'],$a0Config,$SESSION);
		}elseif($rid[0]['ridcode'] || is_array($rid[0]['ridcode'])){
			foreach($criteria['rid'] as &$r){
				actionCheckerLauncher($r['action'],$a0Config,$SESSION);
			}
		}else{
			$emptyRid=array();
			actionCheckerLauncher($criteria['action'],$a0Config,$SESSION);
		}
	}
}

function xmlError($errorCase){
	echo 'Error Case: ',$errorCase;
	/*header('Location: ../home.php?xml_error='.$errorCase);*/
	exit();
}

function dom_to_array($root){
	$result=array();
	if ($root->hasAttributes()){
		$attrs=$root->attributes;
		foreach($attrs as $i=>$attr){
			$result[$attr->name]=utf8_decode(addslashes(trim($attr->value)));
		}
	}
	$children=$root->childNodes;
	if ($children->length==1){
		$child=$children->item(0);
		if ($child->nodeType==XML_TEXT_NODE){
			$result['_value']=$child->nodeValue;
			if(count($result)==1)return utf8_decode(addslashes(trim($result['_value'])));
			else return utf8_decode(addslashes(trim($result)));
		}
	}
	$group=array();
	for($i=0;$i<$children->length;$i++){
		$child=$children->item($i);
		if (!isset($result[$child->nodeName])){
			$result[$child->nodeName]=dom_to_array($child);
		}else{
			if(!isset($group[$child->nodeName])){
				$tmp=$result[$child->nodeName];
				$result[$child->nodeName]=array($tmp);
				$group[$child->nodeName]=1;
			}
			$result[$child->nodeName][]=dom_to_array($child);
		}
	}
	return $result;
}

function existingId($id,$a0Id){
	if($id!='')return $id;
	elseif($a0Id!='')return $a0Id;
	else return '';
}

$file=$_FILES['uploadedFile'];
//echo $file['error'],'###',end(explode(".", $file['name']));
if($file['error']==UPLOAD_ERR_OK && end(explode(".", $file['name']))=='xml'){
	$root=new DOMDocument();
	$root->load($file['tmp_name']);
	$fileArray=dom_to_array($root);
	
	//print_r($fileArray);
	
	$mainInfo=$fileArray['A0Report']['part'];
	
	//print_r($mainInfo);
	
	$a0Version=$mainInfo['a0_version'];
	$xmlKey=$mainInfo['key'];
	
	$a0Config=array(
		'program'=>$mainInfo['program_id'],
		'coe'=>$mainInfo['coe_id'],
		'msn'=>$mainInfo['msn_id'],
		'wp'=>$mainInfo['wp_id'],
		'review_profile'=>$mainInfo['review_profile_id'],
		'a0_status_translation'=>array(0,2,1)
	);
	
	$caString=$mainInfo['ca_id'];
	$caArray=explode(',',$caString);
	
	$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
	
	$validKey=sqlAsLi('SELECT a0_report_id,ca,a0_report_upload_done
						FROM dr_a0_report
						WHERE msn='.$a0Config['msn'].'
							AND review_profile='.$a0Config['review_profile'].'
							AND xml_lock="'.$mainInfo['key'].'"
							AND user='.$viewAsUserId.'
						ORDER BY a0_report_creation DESC
						LIMIT 1','ca');
	
	if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==0){
		if(is_array($validKey)){
			$invalidKeyFound=0;
			foreach($validKey as $v){
				if($v['a0_report_upload_done']==1){
					$invalidKeyFound=1;
				}
				if($invalidKeyFound==1){
					xmlError('no_rights');
				}
			}
		}else{
			$invalidKeyFound=1;
			xmlError('no_rights');
		}
	}
	
	
	/*if(($validKey=='' || $validKey['a0_report_upload_done']==1) && checkPermission('superadmin','superadmin',0,'check',$SESSION)==0){
		xmlError('no_rights');
	}*/
	
	//if($invalidKeyFound!=1){
		createLog('dr_log','a0_report_id','upload',$validKey['dr_a0_report_id'],'','',$SESSION);
	//}
		//JFM TODO
	$review=SqlAsLi('SELECT review_id,ca,review_done,review_status FROM dr_review WHERE ca IN('.$caString.') AND msn='.$a0Config['msn'].' AND review_profile='.$a0Config['review_profile'],'ca');
	
	$a0Config['db_criteria_status']=SqlBDAsLi('SELECT ca,review_criteria,criteria_status,criteria_focal_point,criteria_comments FROM dr_criteria_status WHERE msn='.$a0Config['msn'].' AND ca IN('.$caString.')','ca','review_criteria',0,0);

	$ridActionQry=mysql_query('SELECT ac.action_id,ac.action_a0_id,rd.rid_id,rd.rid_a0_id
									FROM 			dr_action				AS ac
										INNER JOIN	dr_action_applicability	AS ap ON ac.action_id=		ap.action
										INNER JOIN	dr_review_criteria		AS cr ON ac.criteria=		cr.review_criteria_id
										INNER JOIN	dr_review_group			AS gr ON cr.review_group=	gr.review_group_id
										LEFT  JOIN	dr_rid					AS rd ON ac.rid=			rd.rid_id
									WHERE gr.review_profile='.$a0Config['review_profile'].'
										AND ac.msn='.$a0Config['msn'].'
										AND ap.ca IN('.$caString.')
										AND (
											ac.action_a0_id<>""
											OR rd.rid_a0_id<>""
										)
									GROUP BY ac.action_id',$p12) or die(mysql_error());
	
	while($r=mysql_fetch_assoc($ridActionQry)){
		if($r['action_a0_id']!=''){
			$a0Config['action_a0_id'][$r['action_a0_id']]=$r['action_id'];
		}
		if($r['rid_a0_id']!=''){
			$a0Config['rid_a0_id'][$r['rid_a0_id']]=$r['rid_id'];
		}
	}
	
	$a0Config['actions_inserted']=0;
	
	if(is_array($caArray)){
		foreach($caArray as $ca){
			
			$a0Config['ca']=$ca;
			
			if($review[$ca]['review_done']!=1 || $review[$ca]['review_status']!=$mainInfo['ovStat']){				//JFM TODO
				if($review[$ca]['review_id']==''){
					SqlLQ('INSERT INTO dr_review (ca,msn,review_profile,review_done,review_status) VALUES ('.$ca.','.$msn.','.$mainInfo['review_profile_id'].',1,'.$mainInfo['ovStat'].')');
				}else{
					SqlLQ('UPDATE dr_review SET review_done=1,review_status='.$mainInfo['ovStat'].' WHERE review_id='.$review[$ca]['review_id']);
				}
			}
		
			//if($validKey!=''){
				SqlLQ('UPDATE dr_a0_report SET a0_report_upload=NOW(),a0_report_upload_done=1,user=0 WHERE a0_report_id="'.$validKey['a0_report_id'].'"');
			//}
			
			$responsible=getResponsibles($a0Config['program'],$SESSION,1,$a0Config['ca'],'',1);
			foreach($responsible['config'] as $respGroup=>$r){
				foreach($r as $respRole=>$configId){
					$respPosition='responsible_'.$respGroup.'_'.$respRole;
					if($mainInfo[$respPosition]!=$responsible['name'][$respGroup][$respRole]){
						saveResponsible($a0Config['ca'],$responsible['config'][$respGroup][$respRole],$mainInfo[$respPosition],0);
					}
				}
			}
			
			$a0Topic=$fileArray['A0Report']['topic-list']['topic'];
			
			if($a0Topic['name']!=''){
				if($a0Topic['case']['crId']!=''){
					checkCriteria($a0Topic['case'],$a0Config,$SESSION);
				}else{
					foreach($a0Topic['case'] as $criteria){
						checkCriteria($criteria,$a0Config,$SESSION);
					}
				}
			}else foreach($a0Topic as $crGroup){
				if($crGroup['case']['crId']!=''){
					checkCriteria($crGroup['case'],$a0Config,$SESSION);
				}else{
					foreach($crGroup['case'] as $criteria){
						checkCriteria($criteria,$a0Config,$SESSION);
					}
				}
			}
			
			$a0Config['actions_inserted']=1;
		}
	}
	//header("Location: home.php");
}else xmlError('incorrect_file');?>