<?php
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('localSupport.php');
require_once('form.php');
require_once('zipfile.php');
$POST=cleanArray($_POST);

function generateXdpFile($reviewProfile,$ca,$target,$raiseIssue,$SESSION,$readWrite){
	$caArray=explode(',',$ca);
	$a0Status=array(0,2,1,3);
	$a0Ids=array();
	
	do{
		$xmlKey=randomString(32);
	}while(SqlQ('SELECT a0_report_id FROM dr_a0_report WHERE xml_lock="'.$xmlKey.'"'));
	
	$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];

	$actualIssueQry=SqlMAsArr('SELECT ca,a0_report_issue FROM dr_a0_report WHERE msn='.getFilter('msn','filter',0,$SESSION).' AND ca IN('.$ca.') AND review_profile='.$reviewProfile,'ca','a0_report_issue');
	
	foreach($caArray as $c){
		$actualMaxIssue[$c]=(is_array($actualIssueQry[$c]))?max($actualIssueQry[$c]):0;
		
		SqlLQ('INSERT INTO dr_a0_report (msn,ca,review_profile,a0_report_issue,a0_report_creation,xml_lock,user)
			VALUES ('.getFilter('msn','filter',0,$SESSION).','.$c.','.$reviewProfile.','.($actualMaxIssue[$c]+$raiseIssue).',NOW(),"'.$xmlKey.'",'.$viewAsUserId.')');

		$a0Id=SqlQ('SELECT LAST_INSERT_ID()'); //JFM 07_04_14
		array_push($a0Ids,$a0Id['LAST_INSERT_ID()']); //JFM 07_04_14
	}
	
	$programTxt=SqlQ('SELECT program FROM c_program WHERE program_id='.getFilter('program','filter',0,$SESSION));
	$coeTxt=SqlQ('SELECT coe FROM c_coe WHERE coe_id='.getFilter('coe','filter',0,$SESSION));
	
	$caName=SqlAsLi('SELECT ca_id,ca,ca_description FROM c_ca WHERE ca_id IN ('.$ca.')','ca_id');
	foreach($caName as $caId=>$caDetails){
		$caNameStringArray[]=$caDetails['ca'];
		$caDescriptionArray[]=$caDetails['ca_description'];
	}
	$caNameString=implode(', ',$caNameStringArray);
	$caDescription=implode(', ',$caDescriptionArray);
	
	$wpQry=SqlLi('SELECT w.wp_id,w.wp,w.wp_description,
							cw.ca
						FROM c_wp AS w
							INNER JOIN c_cawp AS cw ON w.wp_id=cw.wp
						WHERE cw.ca IN ('.$ca.') AND cw.msn='.getFilter('msn','filter',0,$SESSION));
	
	if(is_array($wpQry)){
		foreach($wpQry as $w){
			$wpA[]=$w['wp_id'];
			$wpNameA[$w['wp_id']]=$w['wp'];
			$caInWp[$w['wp_id']][]=$w['ca'];
			if($w['wp_description']==''){
				$w['wp_description']='N/A';
			}
			$wpDescriptionArray[$w['wp_id']]=$w['wp_description'];
		}
	}
	
	$wp=implode(',',$wpA);
	$wpName=implode(', ',$wpNameA);
	$wpDescription=implode(', ',$wpDescriptionArray);
	
	$imageFile=SqlQ('SELECT '.$target.'_image_file FROM c_'.$target.' WHERE '.$target.'_id IN ('.$$target.')');
	
	$caWpDescription=($target=='ca')?$caDescription:$wpDescription;
	
	$reviewName=$SESSION['review_type'][$reviewProfile];
	
	//JFM 14_11_13 - START
	$overallStatus=SqlQ('SELECT r.review_status
						FROM dr_review AS r
							INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
						WHERE ra.ca IN('.$ca.')
							AND r.msn='.getFilter('msn','filter',0,$SESSION).'
							AND r.review_profile='.$reviewProfile);
							
	$msnName=SqlQ('SELECT msn FROM c_msn WHERE msn_id='.getFilter('msn','filter',0,$SESSION));

	$perimeterName=SqlQ('SELECT per.perimeter 
							FROM c_perimeter  AS per
							INNER JOIN c_program AS pro ON pro.program_id=per.program
							INNER JOIN c_ca AS ca ON ca.perimeter=per.perimeter_id
						WHERE ca.ca_id IN('.$ca.')
						AND pro.program_id='.getFilter('program','filter',0,$SESSION));

	$reviewID=SqlLi('SELECT r.*
						FROM dr_review AS r
							INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
							INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
						WHERE rp.review_profile_id='.$reviewProfile.'
						AND ra.ca IN ('.$ca.')
						AND r.msn='.getFilter('msn','filter',0,$SESSION));

	$responsibles=getResponsibles($reviewID[0]['review_id'],$SESSION);

	$attendees=SqlLi('SELECT *
				FROM dr_responsible_attendee AS ra
				WHERE review='.$reviewID[0]['review_id']);

	//19_07_16
	$reviewLinks = SqlLi('SELECT *
							FROM dr_review_links
							WHERE review='.$reviewID[0]['review_id'].'
							ORDER BY link_id ASC LIMIT 1');
	
	//JFM 09_04_14
	$group=SqlLi('SELECT DISTINCT rg.group_id, rgh.review_group_description, rgh.review_group_position
					FROM dr_review_group AS rg
						INNER JOIN 
									(
										SELECT review_group,review_group_description,review_group_position,review_group_valid_from 
												FROM dr_review_group_history 
												WHERE review_group_valid_from <= "'.$reviewID[0]['validation_date'].'" 
												ORDER BY review_group_valid_from DESC
									) AS rgh ON rgh.review_group=rg.group_id 
						INNER JOIN dr_review_profile AS rp ON rg.review_type=rp.review_type
						INNER JOIN dr_review_criterion AS rc ON rc.review_group=rg.group_id
					WHERE rp.review_profile_id='.$reviewProfile.'
					GROUP BY rgh.review_group
					ORDER BY review_group_position ASC');
						
	//JFM 09_04_14
	$criteria=SqlBDAsArr('SELECT DISTINCT rgh.review_group,rgh.review_group_description,rgh.review_group_position,
											rconf.disabled, rconf.position AS criterion_position,
											rc.review_criterion_id, rch.criterion_name, rch.criterion_description, rch.criterion_user_id, rch.criterion_showstopper, rch.criterion_moc, rch.criterion_valid_from,
											GROUP_CONCAT(g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS criterion_reference
							FROM dr_review_criterion_history AS rch 
								INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
								INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
								INNER JOIN 
											(
												SELECT review_group,review_group_description,review_group_position,review_group_valid_from 
														FROM dr_review_group_history 
														WHERE review_group_valid_from <= "'.$reviewID[0]['validation_date'].'" 
														ORDER BY review_group_valid_from DESC
											) AS rgh ON rgh.review_group=rg.group_id 
								INNER JOIN dr_review_configuration	AS rconf	ON rc.review_criterion_id = rconf.criterion
								INNER JOIN dr_review				AS r		ON r.review_id=rconf.review
								INNER JOIN dr_review_applicability	AS ra		ON r.review_id=ra.review
								INNER JOIN dr_review_profile		AS rp 		ON rp.review_profile_id=r.review_profile
								LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
								LEFT  JOIN c_grams					AS g		ON	rca.applicability=g.grams_id
																				AND	rca.object='.$SESSION['object']['grams_id'].'
																				AND rca.review_criterion_applicability_valid_from <= "'.$reviewID[0]['validation_date'].'"
							WHERE rp.review_profile_id='.$reviewProfile.'
							AND ra.ca IN ('.$ca.')
							AND r.msn='.getFilter('msn','filter',0,$SESSION).'
							AND rch.criterion_valid_from <= "'.$reviewID[0]['validation_date'].'"
							AND rch.criterion_valid_from != "0000-00-00 00:00:00"
							GROUP BY rch.criterion_validity_id
							ORDER BY rgh.review_group_position ASC, rconf.position ASC',
							'review_group','review_criterion_id');
	
	foreach($criteria as $reviewGroup=>$reviewCriteron)
	{
		foreach($reviewCriteron as $q=>$c)
		{				
			$array1=explode(", ",$c['criterion_reference']);

			$array1=array_unique($array1); //JFM 02_04_14
					
			$criteria[$reviewGroup][$q]['criterion_reference']='';
		
			foreach($array1 as $a1)
			{
				$array2=explode("---",$a1);
	
				if($array2[1]=='0000-00-00 00:00:01' && $criteria[$reviewGroup][$q]['criterion_valid_from']=="0000-00-00 00:00:00") continue;
				if($array2[2]=='0000-00-00 00:00:00' && $criteria[$reviewGroup][$q]['criterion_valid_from']!="0000-00-00 00:00:00") continue;
				if($reviewID[0]['validation_date']=="9999-12-31 00:00:00" && $array2[1]!='0000-00-00 00:00:00'  && $array2[1]!='0000-00-00 00:00:01') continue;
				else 
				{
					if(empty($criteria[$reviewGroup][$q]['criterion_reference'])) $criteria[$reviewGroup][$q]['criterion_reference']=$array2[0];
					else $criteria[$reviewGroup][$q]['criterion_reference']=$criteria[$reviewGroup][$q]['criterion_reference'].', '.$array2[0];
				}
			}
		}
	}

	$criteriaStatus=SqlAsLi('SELECT review_criteria,criteria_status_id,criteria_status,criteria_focal_point,criteria_comments
								FROM dr_criteria_status
								WHERE ca IN('.$ca.')
									AND msn='.getFilter('msn','filter',0,$SESSION),
								'review_criteria');
	
	$action1=SqlLi('SELECT DISTINCT ac.action_id,ac.criteria,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_closure,ac.action_status,ac.action_holder,ac.action_holder_name,ac.action_validator,ac.action_validator_name,
									rd.rid_id,rd.rid_code,rd.rid_title,rd.rid_status,rd.rid_holder,rd.rid_holder_name,rd.rid_creation,rd.rid_completion,rd.rid_closure,rd.rid_showstopper,rd.rid_action_plan,
									rch.criterion_user_id,
									GROUP_CONCAT(ca.ca_id SEPARATOR ",") AS action_applicability_id,
									CONCAT(u1.surname,", ",u1.name) AS action_holder_txt,
									CONCAT(u2.surname,", ",u2.name) AS action_validator_txt,
									CONCAT(u3.surname,", ",u3.name) AS rid_holder_txt
								FROM dr_action							AS ac
									INNER JOIN	dr_action_applicability	AS ap ON ac.action_id			=ap.action
									INNER JOIN	c_ca					AS ca ON ap.ca					=ca.ca_id
									INNER JOIN	dr_review_criterion		AS cr ON ac.criteria			=cr.review_criterion_id
									INNER JOIN  dr_review_criterion_history AS rch ON rch.criterion=cr.review_criterion_id
									INNER JOIN	dr_review_group			AS gr ON cr.review_group		=gr.group_id
									INNER JOIN	dr_review_profile		AS rp ON gr.review_type			=rp.review_type
									LEFT JOIN	dr_rid					AS rd ON ac.rid					=rd.rid_id
									LEFT JOIN	c_user					AS u1 ON ac.action_holder		=u1.user_id
									LEFT JOIN	c_user					AS u2 ON ac.action_validator	=u2.user_id
									LEFT JOIN	c_user					AS u3 ON rd.rid_holder			=u3.user_id
								WHERE ap.ca IN('.$ca.')
									AND ac.msn='.getFilter('msn','filter',0,$SESSION).'
									AND rp.review_profile_id='.$reviewProfile.'
									AND rp.program='.getFilter('program','filter',0,$SESSION).'
								GROUP BY ac.action_id
								ORDER BY ac.action_id ASC');


	$action2=SqlLi('SELECT DISTINCT ac.action_id,ac.criteria,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_closure,ac.action_status,ac.action_holder,ac.action_holder_name,ac.action_validator,ac.action_validator_name,
									rd.rid_code,
									GROUP_CONCAT(ca.ca_id SEPARATOR ",") AS action_applicability_id,
									CONCAT(u1.surname,", ",u1.name) AS action_holder_txt,
									CONCAT(u2.surname,", ",u2.name) AS action_validator_txt
								FROM dr_action							AS ac
									INNER JOIN c_msn					AS cmn 	ON 	cmn.msn_id=ac.msn
									INNER JOIN dr_action_applicability	AS app 	ON 	ac.action_id=app.action
									INNER JOIN c_ca 					AS ca  	ON 	app.ca=ca.ca_id
									INNER JOIN c_coe 					AS coe 	ON 	ca.coe=coe.coe_id
									INNER JOIN dr_review 				AS r 	ON 	ac.review=r.review_id
									INNER JOIN dr_review_profile		AS rp   ON 	rp.program=cmn.program
																				AND rp.coe=coe.coe_id
																				AND r.review_profile=rp.review_profile_id
									INNER JOIN dr_review_type 			AS rt 	ON 	rp.review_type=rt.review_type_id

									INNER JOIN c_cawp					AS cw	ON 	ca.ca_id=cw.ca
																				AND cmn.msn_id=cw.msn
									LEFT JOIN	dr_rid					AS rd ON ac.rid					=rd.rid_id
									LEFT JOIN	c_user					AS u1 ON ac.action_holder		=u1.user_id
									LEFT JOIN	c_user					AS u2 ON ac.action_validator	=u2.user_id
								WHERE app.ca IN('.$ca.')
									AND ac.msn='.getFilter('msn','filter',0,$SESSION).'
									AND rp.review_profile_id='.$reviewProfile.'
									AND rp.program='.getFilter('program','filter',0,$SESSION).'
								GROUP BY ac.action_id
								ORDER BY ac.action_id');

	$action=array();

	if(!empty($action1) && !empty($action2)) $action=array_merge($action1, $action2);
	else if (!empty($action1)) $action=$action1;
	else if (!empty($action2)) $action=$action2;

	sort($action);

	$totalActionsAndRids=array();
	$ridIdUsed=array();

	$totalActionsAndRids['action_red']=0;
	$totalActionsAndRids['action_amber']=0;
	$totalActionsAndRids['action_green']=0;
	$totalActionsAndRids['action_blue']=0;

	$totalActionsAndRids['rid_red']=0;
	$totalActionsAndRids['rid_amber']=0;
	$totalActionsAndRids['rid_green']=0;
	$totalActionsAndRids['rid_blue']=0;

	foreach ($action as $actualActionKey => $actualActionValue) 
	{
		switch ($actualActionValue['action_status'])
		{
			case '0':
				$totalActionsAndRids['action_red']++;
			break;

			case '1':
				$totalActionsAndRids['action_amber']++;
			break;

			case '2':
				$totalActionsAndRids['action_green']++;
			break;

			case '3':
				$totalActionsAndRids['action_blue']++;
			break;
		}

		if(!in_array($actualActionValue['rid_id'], $ridIdUsed))
		{
			switch ($actualActionValue['rid_status'])
			{
				case '0':
					$totalActionsAndRids['rid_red']++;
					array_push($ridIdUsed, $actualActionValue['rid_id']);
				break;

				case '1':
					$totalActionsAndRids['rid_amber']++;
					array_push($ridIdUsed, $actualActionValue['rid_id']);
				break;

				case '2':
					$totalActionsAndRids['rid_green']++;
					array_push($ridIdUsed, $actualActionValue['rid_id']);
				break;

				case '3':
					$totalActionsAndRids['rid_blue']++;
					array_push($ridIdUsed, $actualActionValue['rid_id']);
				break;
			}
		}
	}
	
									
	//JFM 14_11_13 - END
	
	
	if($imagePath=='' && $imageFile[$target.'_image_file']!='' && file_exists('../img/'.$target.'/'.$imageFile[$target.'_image_file'])){
		$imagePath='../img/'.$target.'/'.$imageFile[$target.'_image_file'];
	}else $imagePath='../../common/img/mainLogo.png';

	$fileHandle=fopen($imagePath,'rb');
	$imageContent=fread($fileHandle,filesize($imagePath)); 
	fclose($fileHandle); 
	$imageEncoded=chunk_split(base64_encode($imageContent));
		
	@date_default_timezone_set("GMT"); 
	$writer = new XMLWriter();
	$tempFileName=newFileName('../output/','xml',16);
	
	touch($tempFileName);
	$tempFileName=realpath($tempFileName);
	
	$writer->openURI($tempFileName); 
	$writer->setIndent(4);  
	$writer->startElement("A0Report");
		$writer->startElement("part");
			
			$writer->writeElement('ca_id',$ca);
			$writer->writeElement('ca',$caNameString);
			
			$writer->writeElement('wp_id',$wp);
			$writer->writeElement('wp',$wpName);
			
			$writer->writeElement('name',$caWpDescription);
			$writer->writeElement('ca_description',$caDescription);
			$writer->writeElement('wp_description',$wpDescription);

			$writer->startElement("draft");
				$writer->writeAttribute('xmlns:xf','http://www.w3.org/2002/xforms');
				$writer->writeAttribute('xf:base64Binary',$imageEncoded);
			$writer->endElement();
			
			$writer->writeElement('clash','');
			
			$writer->writeElement('issue',chr($a0Report['a0_report_issue']+65));
			
			$writer->writeElement('issue_nb','00');
			$writer->writeElement('issuedate',date("d.m.Y"));
			$writer->writeElement('program_id',getFilter('program','filter',0,$SESSION));
			$writer->writeElement('program',$programTxt['program']);
			$writer->writeElement('coe_id',getFilter('coe','filter',0,$SESSION));
			$writer->writeElement('coe',$coeTxt['coe']);
			$writer->writeElement('type_id',$reviewName);
			$writer->writeElement('type',$reviewName);
			$writer->writeElement('review_profile_id',$reviewProfile);
			$writer->writeElement('msn_id',getFilter('msn','filter',0,$SESSION));
			$writer->writeElement('MSN',$msnName['msn']);
			$writer->writeElement('perimeter',$perimeterName['perimeter']);
			$writer->writeElement('offRef',$reviewLinks[0]['reference']); //JFM 07_04_14 - JFM 19_07_16

			//If copying minutes directly from MS Office, the "color=" perimeter in "<font></font>" does not come through correctly.
			//I.E. <FONT color="#000000">Blah</FONT> - Okay!
			//     <FONT color=#000000>Blah</FONT> - What MS Office does which destroys the well formed XML.
			//This code fixes that problem. 
			//JFM 15_09_15
			$betterFormattedRemarks=str_replace("&amp;", "and", str_replace("<br>", "<br />", str_replace("\n", "<br />", str_replace("&nbsp;", " ", str_replace("<BR>", "<br />",$reviewID[0]['remark'])))));
			$needle = "color=";
			$lastPos = 0;
			$positions = array();

			while (($lastPos = strpos($betterFormattedRemarks, $needle, $lastPos))!== false)
			{
				$positions[] = $lastPos;
				$lastPos = $lastPos + strlen($needle);
			}

			foreach ($positions as $value) 
			{
				$betterFormattedRemarks=substr_replace($betterFormattedRemarks, '             ', $value, 13);
			}


			$writer->writeElement('remarks', html_entity_decode($betterFormattedRemarks)); //JFM 11_03_14
			
			$writer->writeElement('key', $xmlKey);
			$writer->writeElement('ovStat',$overallStatus['review_status']);

			$writer->writeElement('total_action_red',$totalActionsAndRids['action_red']);
			$writer->writeElement('total_action_amber',$totalActionsAndRids['action_amber']);
			$writer->writeElement('total_action_green',$totalActionsAndRids['action_green']);
			$writer->writeElement('total_action_blue',$totalActionsAndRids['action_blue']);
			$writer->writeElement('total_rid_red',$totalActionsAndRids['rid_red']);
			$writer->writeElement('total_rid_amber',$totalActionsAndRids['rid_amber']);
			$writer->writeElement('total_rid_green',$totalActionsAndRids['rid_green']);
			$writer->writeElement('total_rid_blue',$totalActionsAndRids['rid_blue']);

			if($reviewID[0]['planned']!='0000-00-00') $writer->writeElement('review_planned_date',$reviewID[0]['planned']);
			if($reviewID[0]['review_date']!='0000-00-00') $writer->writeElement('review_actual_date',$reviewID[0]['review_date']);
			if($reviewID[0]['delta']!='0000-00-00') $writer->writeElement('review_delta_date',$reviewID[0]['delta']);

			//PANEL MEMBERS LIST
			$writer->startElement('responsible-list');
				if(!empty($responsibles))
				{
					foreach($responsibles as $responsible)
					{
						$writer->startElement('responsible');
							$writer->writeElement('role',$responsible['responsible_role']);
							$writer->writeElement('name',$responsible['responsible']);
						$writer->endElement();
					}
				}
			$writer->endElement();

			//ATTENDEE LIST
			$writer->startElement("attendee-list");

				if(is_array($attendees))
				{
					$count=1;

					$writer->startElement("attendee");
						foreach($attendees as $a)
						{
							$writer->writeElement('attendeename'.$count,$a['responsible_attendee']);
							$count++;

							if($count > 6)
							{
								$writer->endElement();
								$writer->startElement("attendee");
								$count=1;
							}
						}
					$writer->endElement();
				}

			$writer->endElement();

		$writer->endElement(); //end part

		$writer->startElement('sign');
			$writer->startElement('person');
				$writer->writeElement('name','');
				$writer->writeElement('depart','');
				$writer->writeElement('signdate','');
			$writer->endElement();
			$writer->startElement('person');
				$writer->writeElement('name','');
				$writer->writeElement('depart','');
				$writer->writeElement('signdate','');
			$writer->endElement();
		$writer->endElement();
		
		$writer->startElement('ddList');
			$writer->startElement('ddEl');
				$writer->writeElement('ddName','All CA');
				$writer->writeElement('ddVal',$ca);
			$writer->endElement();

			foreach($wpNameA as $wpId=>$wpNameTxt){
				if(is_array($caInWp[$wpId])){
					$writer->startElement('ddEl');
						$writer->writeElement('ddName','WP: '.$wpNameTxt);
						$writer->writeElement('ddVal',implode(',',$caInWp[$wpId]));
					$writer->endElement();
				}
			}
			
			foreach($caName as $caId=>$caDetails){
				$writer->startElement('ddEl');
					$writer->writeElement('ddName','CA: '.$caDetails['ca']);
					$writer->writeElement('ddVal',$caId);
				$writer->endElement();
			}
		$writer->endElement();

		$criteriaSpecificActions=array();
		$ridAssociatedActions=array();
		$colour=array('ef343f','81c341','f8d707','0088cf');

		//ACTION_LIST
		$writer->startElement("action-list");
		if(is_array($action))
		{
			foreach($action as $a)
			{
				$writer->startElement("action");
					$writer->writeAttribute('act_status',$a0Status[$a['action_status']]);
					$writer->writeAttribute('act_reference',substr($a['action_code'],0,-3).'<b>'.substr($a['action_code'],-3).'</b>');
					$writer->writeElement('action_id',$a['action_id']);
					$writer->startElement('WPCAApp');
						$actionApplicability=explode(',',$a['action_applicability_id']);
						foreach($actionApplicability as $aa)$writer->writeElement('value',$aa);
					$writer->endElement();
					$writer->writeElement('actiondescription',$a['action_description']);
					$writer->writeElement('actionremark',$a['action_remark']);
					$writer->writeElement('actioncreationdate',$a['action_creation']);
					if($a['action_completion']!='0000-00-00') $writer->writeElement('actionduedate',$a['action_completion']);
					if($a['action_closure']!='0000-00-00') $writer->writeElement('actionclosuredate',$a['action_closure']);
					$writer->writeElement('actionholder',($a['action_holder_txt'])?$a['action_holder_txt']:$a['action_holder_name']);
					$writer->writeElement('actionholderid',$a['action_holder']);
					$writer->writeElement('actionvalidator',($a['action_validator_txt'])?$a['action_validator_txt']:$a['action_validator_name']);
					$writer->writeElement('actionvalidatorid',$a['action_validator']);
					$writer->writeElement('criterionuserid',$a['criterion_user_id']);
				$writer->endElement();


				if (!is_array($criteriaSpecificActions[$a['criterion_user_id']])) $criteriaSpecificActions[$a['criterion_user_id']]=array();
				array_push($criteriaSpecificActions[$a['criterion_user_id']],'<span style="color:#'.$colour[$a0Status[$a['action_status']]].'">'.substr($a['action_code'],-3).'</span>');
			
				if (!is_array($ridAssociatedActions[$a['rid_id']])) $ridAssociatedActions[$a['rid_id']]=array();
				array_push($ridAssociatedActions[$a['rid_id']],'<span style="color:#'.$colour[$a0Status[$a['action_status']]].'">'.$a['action_code'].'</span>');
			}
		}

		$writer->endElement();

		$alreadyAddedRIDs=array();

		//RID_LIST
		$writer->startElement("rid-list");
		if(is_array($action))
		{
			foreach($action as $a)
			{
				if(!empty($a['rid_id']) && !in_array($a['rid_id'], $alreadyAddedRIDs))
				{
					$writer->startElement("rid");
						$writer->writeAttribute('ridstatus_test',$a['rid_status']);
						$writer->writeAttribute('ridreference_test',$a['rid_code']);
						$writer->writeElement('ridid',$a['rid_id']);
						$writer->writeElement('ridtitle',$a['rid_title']);
						$writer->writeElement('ridstatus',$a['rid_status']);
						$writer->writeElement('ridcode',$a['rid_code']);
						$writer->writeElement('ridholder',$a['rid_holder']);
						$writer->writeElement('ridholdername',$a['rid_holder_name']);
						if($a['rid_completion']!='0000-00-00') $writer->writeElement('ridcompletion',$a['rid_completion']);
						if($a['rid_closure']!='0000-00-00') $writer->writeElement('ridclosure',$a['rid_closure']);
						$writer->writeElement('ridshowstopper',$a['rid_showstopper']);
						$writer->writeElement('ridactionplan',$a['rid_action_plan']);
						if(!empty($ridAssociatedActions[$a['rid_id']])) $writer->writeElement('ridassociatedactions',implode("\n", $ridAssociatedActions[$a['rid_id']]));
					$writer->endElement();

					array_push($alreadyAddedRIDs, $a['rid_id']);
				}
			}
		}

		$writer->endElement();

		//JFM 08_06_16
		$lastGroup=0;
		$totalGroups = 2;
		$calculationArrayTotalsForEC=array();
		$calculationArrayGroupsForEC=array();
		$priorityMap=array('Low' => 1, 'Medium' => 2, 'High' => 3);

		$calculationArrayTotalsAll=array('review_total' => 0, 0 => 0, 1 => 0, 2 => 0, 3 => 0);
		$calculationArrayGroupsAll=array();
	
		//CRITERIA LIST
		$writer->startElement("topic-list");

		foreach($group as $g)
		{
			$visibleCriteria=1; //JFM 14_11_13
			if($visibleCriteria==1){
				if(!$criteria[$g['group_id']]) continue; // JFM 18_11_13 - JFM 06_01_14
				$writer->startElement("topic");
					foreach($criteria[$g['group_id']] as $c)
					{
						//JFM 08_06_16
						$calculationArrayTotalsAll['review_total']++;

						if($c['disabled']==1)
						{
							$criteriaStatus[$c['review_criterion_id']]['criteria_status']=1;
							$criteriaStatus[$c['review_criterion_id']]['criteria_comments']='NOT APPLICABLE';
						}
						else
						{
							$criteriaStatus[$c['review_criterion_id']]['criteria_status']=$a0Status[$criteriaStatus[$c['review_criterion_id']]['criteria_status']];
						}

						//JFM 08_06_16
						if($criteriaStatus[$c['review_criterion_id']]['criteria_status'] != '' && isset($criteriaStatus[$c['review_criterion_id']]['criteria_status']) && $criteriaStatus[$c['review_criterion_id']]['criteria_status']<4)
						{
							$calculationArrayTotalsAll[$criteriaStatus[$c['review_criterion_id']]['criteria_status']]++;
						}

						$calculationArrayTotalsForEC['review_total'] += $priorityMap[$c['criterion_moc']];

						if($criteriaStatus[$c['review_criterion_id']]['criteria_status'] != '' && isset($criteriaStatus[$c['review_criterion_id']]['criteria_status']) && $criteriaStatus[$c['review_criterion_id']]['criteria_status']>0 && $criteriaStatus[$c['review_criterion_id']]['criteria_status']<4)
							$calculationArrayTotalsForEC['assessment_total'] += $priorityMap[$c['criterion_moc']];
						



						$writer->startElement("case");
							$writer->writeAttribute('name',$g['review_group_description']);
							$writer->writeAttribute('status',$criteriaStatus[$c['review_criterion_id']]['criteria_status']);
							$writer->writeAttribute('number',$c['criterion_user_id']); //JFM 11_03_14
							$writer->writeElement('criteria_id',$c['review_criterion_id']);
							$writer->writeElement('description',$c['criterion_name']); // JFM 18_11_13
							$writer->writeElement('description_2',$c['criterion_description']); // JFM 18_11_13
							$writer->writeElement('moc',$c['criterion_moc']); // JFM 18_11_13
							$writer->writeElement('document','outstanding');
							$writer->writeElement('action_by',$criteriaStatus[$c['review_criterion_id']]['criteria_focal_point']);
							$writer->writeElement('comment',$criteriaStatus[$c['review_criterion_id']]['criteria_comments']);
							$writer->writeElement('reference',$c['criterion_reference']);
							$writer->writeElement('criterion_showstopper',$c['criterion_showstopper']);
							if(!empty($criteriaSpecificActions[$c['criterion_user_id']])) $writer->writeElement('actions_applicable',implode("\n", $criteriaSpecificActions[$c['criterion_user_id']]));
							
						$writer->endElement();
					}
				$writer->endElement();
			}
		}

		//JFM 08_06_16
		if(getFilter('area','filter',0,$SESSION)==8)
		{
			if($calculationArrayTotalsForEC['review_total'] != 0)
				$overallTotalPercentage = number_format((float)(($calculationArrayTotalsForEC['assessment_total']/$calculationArrayTotalsForEC['review_total'])*100), 2, '.', '');
			
			$writer->startElement("ecInfo");
				$writer->writeElement('name',$reviewID[0]["cabin_ve_name"]);
				$writer->writeElement('status',$reviewID[0]["cabin_ve_status"]);
				$writer->writeElement('remarks',$reviewID[0]["cabin_ve_remarks"]);
				$writer->writeElement('fulfilment',$overallTotalPercentage.'%');
			$writer->endElement();
		}
		else
		{
			$writer->startElement("ecInfo");
				$writer->writeElement('name',"DONOTWRITE");
				$writer->writeElement('status',"DONOTWRITE");
				$writer->writeElement('remarks',"DONOTWRITE");
				$writer->writeElement('fulfilment',"DONOTWRITE");
			$writer->endElement();
		}
	
	$writer->endElement();
	$writer->endDocument(); 
	$writer->flush();
	
	foreach($a0Ids as $a0Id) //JFM 07_04_14
	{
		createLog('dr_log','a0_report_id','create',$a0Id,'','',$SESSION);
	}
	
	$xdpStart="<?xml version='1.0' encoding='UTF-8'?>
	<?xfa generator='AdobeDesigner_V7.0' APIVersion='2.2.4333.0'?>
	<xdp:xdp xmlns:xdp='http://ns.adobe.com/xdp/'>
		<xfa:datasets xmlns:xfa='http://www.xfa.org/schema/xfa-data/1.0/'><xfa:data>";
	
	$xdpMid.='</xfa:data></xfa:datasets>
    <pdf xmlns="http://ns.adobe.com/xdp/pdf/"><document><chunk>';
	if($readWrite=='condense') $pdfFilePath='../archive/a0report_review_template_v10-3.pdf';
	else $pdfFilePath='../archive/a0report_review_template_v8-2.pdf';

	$pdfH=fopen($pdfFilePath,'rb');
	$pdfC=fread($pdfH,filesize($pdfFilePath));
	fclose($pdfH);
	$xdpPdf=chunk_split(base64_encode($pdfC));
	
	$xdpEnd.='</chunk></document></pdf></xdp:xdp>';
	
	$xdpFileName=newFileName('../output/','xdp',16);
	$fp=fopen($xdpFileName,'w');
	fwrite($fp,$xdpStart);
	fwrite($fp,utf8_encode(file_get_contents($tempFileName)));
	fwrite($fp,$xdpMid);
	fwrite($fp,$xdpPdf);
	fwrite($fp,$xdpEnd);
	fclose($fp);
	
	return $xdpFileName;
}
$xdpFile=array();

for($reportId=1;$reportId<=$POST['a0_report_count'];$reportId++){
	$xdpFile[$reportId]=generateXdpFile($POST['a0_report_review_profile'],$POST['a0_report_ca_'.$reportId],$POST['a0_report_target'],$POST['a0_report_raise_issue_'.$reportId],$SESSION,$POST['a0_report_read_write']);
}

$msnName=SqlQ('SELECT msn FROM c_msn WHERE msn_id='.getFilter('msn','filter',0,$SESSION));
$fileNameStart=str_replace(array(' ','/'),'_',$SESSION['review_type'][$POST['a0_report_review_profile']]).'_review_MSN_'.$msnName['msn'].'_'.date("Y-m-d");

if($POST['a0_report_count']==0) header("Location: ../home.php"); //JFM 06_01_14
else if($POST['a0_report_count']==1){
	download('xdp',$xdpFile[1],$fileNameStart.'_'.$POST['a0_report_ca_txt_1'].'.xdp');
}else{
	$xdpZipFile=new zipfile();
	foreach($xdpFile as $reportId=>$filePath){
		$xdpZipFile->add_file(implode("",file($filePath)),$fileNameStart.'_'.$POST['a0_report_ca_txt_'.$reportId].'.xdp'); 
	}
	download('zip',$xdpZipFile,$fileNameStart.'.zip');
}
storeSession($SESSION);
?>