<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);

$object=$SESSION['table'][$GET['table']][$GET['table_section']][$GET['object']];

if($GET['table_section']=='responsible'){
	$object['type']='text';
}

if($object['type']=='user')require_once('../support/form.php');

$sfTxt=($GET['sfTxt'])?$GET['sfTxt']:$object['filter'];

$hide=$SESSION['user_action']['hide'];

$filterId='sf-'.$GET['app'].'-'.$GET['object'];

$srt=getFilter($GET['object'],'sort',$GET['app'],$SESSION);
$srtTxt=($srt=='')?array('NO'=>'checked'):array($srt=>'checked');

?>OK|||<form id="<?=$filterId?>-form" method="post" name="<?=$filterId?>-form" onSubmit="filterFilter('<?=$object['type']?>','<?=$filterId?>');return false;"><?php
	?><table class="fltTable"><?php
		?><tr><td colspan="6" style="text-align:right;"><img alt="Close this Window" onClick="filterCancel('<?=$filterId?>');"src="../common/img/x.png"style="cursor:pointer;"></td></tr><?php
		if($GET['object']!='ca' && $GET['object']!='wp'){?><tr><td colspan="6" align="center"><input class="stdBtn" onClick="filterHide('<?=$object['type']?>','<?=$filterId?>','cfc-<?=$SESSION['object'][$GET['object']],'-',$hide,'-',$GET['app']?>');"type="button"value="Hide Column &#9658;"></td></tr><?php }
	
		?><tr><td colspan="6"><strong>Sort <?=$sfTxt?>:</strong></td></tr><?php
		?><tr><td colspan="6" nowrap><?php
			?><input <?=$srtTxt['ASC']?> id="<?=$filterId?>-sort-a"name="<?=$filterId?>-sort"type="radio"value="ASC">Asc<?php
			?><input <?=$srtTxt['DESC']?> id="<?=$filterId?>-sort-d"name="<?=$filterId?>-sort"type="radio"value="DESC">Desc<?php
			?><input <?=$srtTxt['NO']?> id="<?=$filterId?>-sort-n"name="<?=$filterId?>-sort"type="radio"value="">None<?php
		?></td></tr><?php
		?><tr><td colspan="6">&nbsp;</td></tr><?php
		switch($object['type']){
			case 'action':
				?><tr><td><?php
				?><input <?php if(getFilter($GET['object'],'show_with_actions',$GET['app'],$SESSION)==1)echo'checked'?> name="<?=$filterId?>-show_with_actions"type="checkbox"><b> Show only &gt; 0</b><?php
				?></td></tr><?php
			break;
			case 'date':
				$adArr=array();
				$bdArr=array();
				$afterDate=getFilter($GET['object'],'show_after',$GET['app'],$SESSION);
				$beforeDate=getFilter($GET['object'],'show_before',$GET['app'],$SESSION);
				$adArr=explode('-',$afterDate);
				$bdArr=explode('-',$beforeDate);
				if($SESSION['filter'][$GET['object']]['ev'])$disDate='disabled ';
				?><tr><td><strong>View after than:</strong></td></tr><?php
				?><tr><td><?php
					?><input class="thinBorders"<?=$disDate?>id="<?=$filterId?>-show_afterY"maxlength="4"size="4"type="text"value="<?=$adArr[0]?>"> - <?php
					?><input class="thinBorders"<?=$disDate?>id="<?=$filterId?>-show_afterM"maxlength="2"size="2"type="text"value="<?=$adArr[1]?>"> - <?php
					?><input class="thinBorders"<?=$disDate?>id="<?=$filterId?>-show_afterD"maxlength="2"size="2"type="text"value="<?=$adArr[2]?>"><?php
					?><input id="<?=$filterId?>-show_after" name="<?=$filterId?>-show_after" type="hidden" value="<?=$afterDate?>"> <?php
					?><img onClick="getCal('calTable','<?=$filterId?>_AdCal','<?=$filterId?>-show_after','<?=$filterId?>-show_before','<?=date('m',time())?>','<?=date('Y',time())?>','','put',true,true);"src="../common/img/calendar.jpg"style="cursor:pointer"><div class="calendar"id="<?=$filterId?>_AdCal"style="position:relative"></div><?php
				?></td></tr><?php
				?><tr><td><strong>View before than:</strong></td></tr><?php
				?><tr><td><?php
					?><input class="thinBorders"<?=$disDate?>id="<?=$filterId?>-show_beforeY"maxlength="4"size="4"type="text"value="<?=$bdArr[0]?>"> - <?php
					?><input class="thinBorders"<?=$disDate?>id="<?=$filterId?>-show_beforeM"maxlength="2"size="2"type="text"value="<?=$bdArr[1]?>"> - <?php
					?><input class="thinBorders"<?=$disDate?>id="<?=$filterId?>-show_beforeD"maxlength="2"size="2"type="text"value="<?=$bdArr[2]?>"><?php
					?><input id="<?=$filterId?>-show_before" name="<?=$filterId?>-show_before" type="hidden" value="<?=$beforeDate?>"> <?php
					?><img onClick="getCal('calTable','<?=$filterId?>_BdCal','<?=$filterId?>-show_before','<?=$filterId?>-show_after','<?=date('m',time())?>','<?=date('Y',time())?>','<?=$filterId?>-show_after','put',true,true);"src="../common/img/calendar.jpg"style="cursor:pointer"><div class="calendar"id="<?=$filterId?>_BdCal"style="position:relative"></div><?php
				?></td></tr><?php
				?><tr><td>&nbsp;</td></tr><?php
				?><tr><td><input <?php if(getFilter($GET['object'],'show_only_empty',$GET['app'],$SESSION)!='')echo'checked'?> name="<?=$filterId?>-show_only_empty"onClick="evDis('<?=$filterId?>',this.checked);"type="checkbox"><b> Only empty values</b></td></tr><?php
				?><tr><td><input <?php if(getFilter($GET['object'],'show_only_not_done',$GET['app'],$SESSION)!='')echo'checked'?> name="<?=$filterId?>-show_only_not_done"type="checkbox"><b> Only review not done</b></td></tr><?php //JFM 19_07_16
			break;
			case 'status':
				?><tr><td><strong>Filter by status:</strong></td></tr><?php
				?><tr><td nowrap><?php
					?><input <?php if(getFilter($GET['object'],'hide_red',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_red"name="<?=$filterId?>-hide_red"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"><img src="../common/img/r20.png">&nbsp;<?php
					?><input <?php if(getFilter($GET['object'],'hide_amber',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_amber"name="<?=$filterId?>-hide_amber"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"><img src="../common/img/a20.png">&nbsp;<?php
					?><input <?php if(getFilter($GET['object'],'hide_green',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_green"name="<?=$filterId?>-hide_green"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"><img src="../common/img/g20.png">&nbsp;<?php
					?><input <?php if(getFilter($GET['object'],'hide_blue',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_blue"name="<?=$filterId?>-hide_blue"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"><img src="../common/img/x20.png">&nbsp;<?php		 //JFM 27_03_14			
					if($object['no_status_allowed']==1){
						?><input <?php if(getFilter($GET['object'],'hide_no_status',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_no_status"name="<?=$filterId?>-hide_no_status"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"><img src="../common/img/b20.png">&nbsp;<?php
					}
				?></td></tr><?php
			break;
			case 'link':
			case 'text':
				?><tr><td><strong>Must Contain:</strong></td></tr><?php
				?><tr><td><input class="thinBorders" id="<?=$GET['object']?>-filter"name="<?=$filterId?>-filter"type="text" value="<?=getFilter($GET['object'],'filter',$GET['app'],$SESSION)?>"></td></tr><?php
			break;
			case 'user':
				$userId=getFilter($GET['object'],'filter',$GET['app'],$SESSION);
				if($userId!='' && $userId!=0){
					$userQry=SqlQ('SELECT CONCAT(name," ",surname) AS user_txt FROM c_user WHERE user_id="'.$userId.'"');
					$userTxt=$userQry['user_txt'];
				}
				?><tr><td><?php
					?><input name="<?=$filterId?>-filter"type="hidden"value="<?=$userId?>"><?php
					?><strong>Only the user:</strong><?php
				?></td></tr><?php
				?><tr><?php
					drawUserField('suggestion-'.$GET['object'].'-filter-txt',$GET['object'].'-filter-txt',$filterId.'-filter',$userTxt,'',1);
				?></tr><?php
				/*?><tr><td><input class="thinBorders" id="<?=$GET['object']?>-filter"name="<?=$filterId?>-filter"type="text" value="<?=getFilter($GET['object'],'filter',$GET['app'],$SESSION)?>"></td></tr><?php*/
			break;
			case 'boolean': //JFM 16_09_13
			?><tr><td><strong>Filter by boolean:</strong></td></tr><?php
			?><tr><td nowrap><?php
				?><input <?php if(getFilter($GET['object'],'hide_yes',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_yes"name="<?=$filterId?>-hide_yes"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox">Yes&nbsp;<?php
				?><input <?php if(getFilter($GET['object'],'hide_no',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_no"name="<?=$filterId?>-hide_no"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox">No&nbsp;<?php
			?></td></tr><?php
			break;
			case 'trend': //JFM 08_06_16
				?><tr><td colspan="7"><strong>Filter by status:</strong></td></tr><?php
				?><tr><?php
					?><td></td><?php
					?><td><img src="../common/img/t201.png"></td><?php
					?><td><img src="../common/img/t202.png"></td><?php
					?><td><img src="../common/img/t203.png"></td><?php
					?><td><img src="../common/img/t204.png"></td><?php
					?><td><img src="../common/img/t205.png"></td><?php
				?></tr><?php
				?><tr><?php
					?><td><input <?php if(getFilter($GET['object'],'hide_trend_0',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_trend_0"name="<?=$filterId?>-hide_trend_0"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"></td><?php
					?><td><input <?php if(getFilter($GET['object'],'hide_trend_1',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_trend_1"name="<?=$filterId?>-hide_trend_1"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"></td><?php
					?><td><input <?php if(getFilter($GET['object'],'hide_trend_2',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_trend_2"name="<?=$filterId?>-hide_trend_2"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"></td><?php
					?><td><input <?php if(getFilter($GET['object'],'hide_trend_3',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_trend_3"name="<?=$filterId?>-hide_trend_3"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"></td><?php
					?><td><input <?php if(getFilter($GET['object'],'hide_trend_4',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_trend_4"name="<?=$filterId?>-hide_trend_4"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"></td><?php
					?><td><input <?php if(getFilter($GET['object'],'hide_trend_5',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_trend_5"name="<?=$filterId?>-hide_trend_5"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"></td><?php
				?></tr><?php
			break;
		}
		?><tr><td colspan="6" id="waitTd" style="text-align:right;">&nbsp;</td></tr><?php
		?><tr><td colspan="6" align="right" nowrap style="text-align:right;"><?php
			?><input class="stdBtn"onClick="filterFilter('<?=$object['type']?>','<?=$filterId?>');"type="button"value="Filter &#9658;"><?php
			?><input class="stdBtn"onClick="filterReset('<?=$object['type']?>','<?=$filterId?>');"type="button"value="Reset &#9658;"><?php
			?><input class="stdBtn"onClick="filterCancel('<?=$filterId?>');"type="button"value="Cancel &#9658;"><?php
		?></td></tr><?php
	?></table><?php
?></form><?php
storeSession($SESSION);
?>