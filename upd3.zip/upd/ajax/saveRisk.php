<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');
require_once('../support/mail.php');

$statusNumber=array('r'=>0,'a'=>1,'g'=>2,'x'=>3,0=>0,1=>1,2=>2,3=>3);
$POST=cleanArray($_POST);

$newRiskFlag = false;

$POST['risk_status']=$statusNumber[$POST['risk_status']];

$riskQry=formToQuery($POST,$SESSION['table']['risk']['risk'],$SESSION);

if($POST['risk_id']!='new') $risk=SqlQ('SELECT * FROM dr_risk WHERE risk_id="'.$POST['risk_id'].'"');

if(!$risk['risk_id'])
{
	$newRiskFlag = true;

	$POST['risk_code']=newCode($POST['wp'],$POST['ca'],$SESSION,'risk','risk');
	SqlLQ('INSERT INTO dr_risk (ca,risk_code,date_opened) VALUES ("'.$POST['ca'].'","'.$POST['risk_code'].'",SYSDATE())');
	
	$risk=SqlQ('SELECT * FROM dr_risk WHERE risk_code="'.$POST['risk_code'].'"');
	createLog('dr_log','risk_id','create',$risk['risk_id'],'','',$SESSION);
}

$riskUpdateString=getFormUpdate($riskQry,$risk,'risk','risk',$risk['risk_id'],$SESSION,array('risk_code','ca'));

if($POST['risk_holder']=='undefined' && $POST['risk_holder_name']!='') 
{
	$riskUpdateString[]='risk_holder=0';
	$riskUpdateString[]='risk_holder_name="'.$POST['risk_holder_name'].'"';
}

if(!empty($riskUpdateString))
{
	if($riskQry['risk_status']==2 || $riskQry['risk_status']==3)
	{
		$riskUpdateString[]='date_closed=SYSDATE()';
		$POST['date_closed']=date("y-m-d");
	}
	else
	{
		$riskUpdateString[]='date_closed=0000-00-00';
		$POST['date_closed']=date("y-m-d");
	}

	SqlLQ('UPDATE dr_risk SET '.implode(',',$riskUpdateString).' WHERE risk_id="'.$risk['risk_id'].'"');

/*	if($POST['action_holder']!='undefined' && $newRiskFlag)
	{
		$user=SqlQ('SELECT name, surname, email FROM c_user WHERE user_id='.$POST['action_holder']);

		if(!empty($user))
		{
			$object='Action';
			$whatDone='Assigned to You';
			$message='This is an automatic email to inform you that you are the holder for a new action.<br><br>
							The action code is: <strong>'.$POST['action_code'].'</strong><br><br>
							The action description is: <strong>'.$POST['action_description'].'.</strong><br><br>
							This action must be completed by: <strong>'.((!empty($POST['action_completion']))?$POST['action_completion'] : 'No Date Set').'</strong>';

			$doSomething='view your action';
			$subject='New Action Assigned to You - Airbus Review Tool';
			sendThemMailings($object, $whatDone, $message, $doSomething, $subject, $user['email'], $user['name'], $user['surname']);
		}
	}*/

}

$ridCount=array();

$riskQry=mysql_query('SELECT rsk.risk_id, rsk.risk_status, rsk.ca 
						FROM dr_risk AS rsk
						INNER JOIN c_ca AS ca ON ca.ca_id = rsk.ca
						WHERE ca.program='.getFilter('program','filter',0,$SESSION).'
						AND ca.coe='.getFilter('coe','filter',0,$SESSION),$p12) or die(mysql_error());

while($r=mysql_fetch_assoc($riskQry))
{
	$actionCount[$r['ca']][$r['risk_status']]++;
}

$answer='';
$firstItem=0;

if($risk)
{
	$riskLocation='_'.$risk['risk_id'];

	$risk=SqlQ('SELECT rsk.* FROM dr_risk AS rsk WHERE rsk.risk_id="'.$risk['risk_id'].'"');
	generateSaveResponse($answer,$firstItem,$SESSION['table']['risk']['risk'],$POST,$risk,$riskLocation,array('ca,wp'));
	$answer.='&&&risk_holder_'.$risk['risk_id'].'%%%text%%%'.$POST['risk_holder_name'];
}


if(is_array($actionCount))
{
	foreach($actionCount as $caId=>$actionDetails)
	{
		if($firstItem!=0)$answer.='&&&';
		else $firstItem=1;
		$answer.='risk_red_'.$caId.'%%%action%%%'.$actionDetails[0];
		$answer.='&&&risk_amber_'.$caId.'%%%action%%%'.$actionDetails[1];
		$answer.='&&&risk_green_'.$caId.'%%%action%%%'.$actionDetails[2];
		$answer.='&&&risk_blue_'.$caId.'%%%action%%%'.$actionDetails[3]; //JFM 27_03_14
	}
}

$answer.='&&&risk_id%%%user%%%'.$risk['risk_id'].
			'&&&risk_code%%%user%%%'.$POST['risk_code'].
			'&&&formRiskTitle%%%text%%%Edit Risk '.$POST['risk_code'];

echo 'OK|||'.$answer;
storeSession($SESSION);
?>