<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$allItemsInValidationLoop=SqlLi('SELECT DISTINCT vl1.* FROM dr_validation_loop AS vl1
											LEFT JOIN dr_criteria_status_provider AS csp 
												ON vl1.applicability=csp.criteria_status
											WHERE 
											(
												vl1.validator='.$SESSION['user']['user_id'].' 
												OR 
												(
													vl1.validator=0
													AND csp.provider='.$SESSION['user']['user_id'].'
												)
											) 
											AND action_taken_on ="0000-00-00 00:00:00"');
$count=count($allItemsInValidationLoop);
if($count>9) $size="16";
else if ($count>99) $size="13";
else $size="19";

$answer=$size;
if($count>0) $answer.='&&&'.$count.'&&&validOn';
else $answer.='&&&&&&validOff';

echo 'OK|||'.$answer;

	/*?><div style="position:fixed; margin-top:19px; margin-left:<?=$size?>px; color:white; font-family:Sans-Serif; font-weight:bold;"><?=($count>0)?$count:''?></div><img alt="Validation" id="validImg"onClick="showMenu('valid','header');"onMouseOut="setHideTimer();"onMouseOver="showMenu('valid','header'); closeMenu(oldCol);"src="../common/img/<?=($count>0)?'tick_with_circle':'tick_no_circle'?>.png"><?php*/


$SESSION['validation_count']['old']=$count;

storeSession($SESSION);
?>