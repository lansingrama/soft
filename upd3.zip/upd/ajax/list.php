<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/revMan.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

if (!$POST)
    $POST = cleanArray($_POST);
if (!$POST)
    $POST = cleanArray($GET);
if (!$POST)
    $POST = cleanArray($_GET);

$maxResults = getFilter('max_results', 'view', 0, $SESSION);

switch ($POST['list_name']) {
    case 'action':
        $tableStructure = $SESSION['table']['action']['action'];
        break;
    case 'change':
        $tableStructure = $SESSION['table']['change']['change'];
        break;
    case 'rid':
        $tableStructure = $SESSION['table']['rid']['rid'];
        break;
    case 'cat': //JFM 21_08_13
        $tableStructure = $SESSION['table']['cat']['cat'];
        checkApplicabilityNeeded($tableStructure); //JFM 16_09_13
        break;
    case 'evd': //JFM 28_04_14
        $tableStructure = $SESSION['table']['evd']['evd'];

        if (empty($POST['review_profile'])) {
            $reviewProfile = $SESSION['list_evd']['review_profile'];
            $ca = $SESSION['list_evd']['ca'];
        } else {
            $reviewProfile = $POST['review_profile'];
            $ca = $POST['ca'];

            $SESSION['list_evd']['review_profile'] = $reviewProfile;
            $SESSION['list_evd']['ca'] = $ca;
        }

        $allCAsArray = explode(',', $ca);

        foreach ($allCAsArray as $oneCA) {
            $tableStructure['ca_evidence_info_' . $oneCA] = array('table' => 'none', 'table_short_name' => 'n', 'type' => 'text', 'title' => $oneCA, 'filter' => 'evidence_ca_table_header', 'applicability_needed' => 1);

            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['criteria_status_' . $oneCA] = $tableStructure['criteria_status'];
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['provider_' . $oneCA] = $tableStructure['provider'];
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['stakeholder_' . $oneCA] = $tableStructure['stakeholder'];
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['planned_evd_' . $oneCA] = $tableStructure['planned_evd'];
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['supplied_' . $oneCA] = $tableStructure['supplied'];
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['file_link_' . $oneCA] = $tableStructure['file_link'];
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['action_taken_on_' . $oneCA] = $tableStructure['action_taken_on'];
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['validator_' . $oneCA] = $tableStructure['validator'];

            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['criteria_status_' . $oneCA]['fakeColumnHeader'] = 'criteria_status_' . $oneCA;
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['provider_' . $oneCA]['fakeColumnHeader'] = 'provider_' . $oneCA;
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['stakeholder_' . $oneCA]['fakeColumnHeader'] = 'stakeholder_' . $oneCA;
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['planned_evd_' . $oneCA]['fakeColumnHeader'] = 'planned_evd_' . $oneCA;
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['supplied_' . $oneCA]['fakeColumnHeader'] = 'supplied_' . $oneCA;
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['file_link_' . $oneCA]['fakeColumnHeader'] = 'file_link_' . $oneCA;
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['action_taken_on_' . $oneCA]['fakeColumnHeader'] = 'action_taken_on_' . $oneCA;
            $tableStructure['ca_evidence_info_' . $oneCA]['extras']['validator_' . $oneCA]['fakeColumnHeader'] = 'validator_' . $oneCA;
        }


        unset($tableStructure['provider']);
        unset($tableStructure['stakeholder']);
        unset($tableStructure['planned_evd']);
        unset($tableStructure['supplied']);
        unset($tableStructure['file_link']);
        unset($tableStructure['action_taken_on']);
        unset($tableStructure['validator']);
        if (count($allCAsArray) <= 1)
            unset($tableStructure['criteria_status']);
        else
            $tableStructure['criteria_status']['title'] = 'Overall';
        break;
    case 'usr':
        $tableStructure = $SESSION['table']['usr']['usr']; //JFM 16_01_15
        break;
    case 'risk': //JFM 08_06_16
        $tableStructure = $SESSION['table']['risk']['risk'];
        break;
}

fltUpd($POST, $SESSION, 0);

function drawBasicList($element,$maxResults,$tableCacheId,$tableStructure,$listName,$SESSION,$first)
{
	$status=array('r','a','g','x'); //JFM 27_03_14
	$popUpId=array('action'=>'act','rid'=>'rid','change'=>'Chg', 'cat'=>'cat', 'evd'=>'evd', 'risk'=>'risk'); //JFM 21_08_13 - JFM 28_04_14
	$arrayId=array('action'=>'action_id','rid'=>'rid_id','change'=>'change_id', 'cat'=>'criterion_validity_id', 'evd'=>'criterion_validity_id', 'risk'=>'risk_id'); //JFM 21_08_13 - JFM 28_04_14
	$i=0;
	$b=false;
	date_default_timezone_set('Europe/Berlin');
	$today=date("Y-m-d");
	if($first==1){
		$includeEmptyCell=($listName=='action' || $listName=='rid' || $listName=='change' || $listName=='cat' || $listName=='usr' || $listName=='risk')?1:0; //JFM 21_08_13 - JFM 16_01_15 - JFM 19_07_16
		drawTableHeader($tableStructure,$listName,$SESSION,1,$tableCacheId,$includeEmptyCell);
	}else{
		?><table><?php
	}
	
	if(is_array($element))
	{
		foreach($element as $k=>$e)
		{
			if($e['criterion_group_reference']=="Click to Contract" || $e['criterion_group_reference']=="^<br />|<br />|<br />") $bgColor='B5C6DD';	//FFE069 - Sort of orangey-ish - too bright.87A3C9
			else $bgColor='FFFFFF';
			//$bgColor='FFFFFF';
			//$bgColor=($e['criterion_valid_from']=='0000-00-00 00:00:00')?'77C2FF':$bgColor; //JFM 26_09_13
			$criteriaCa=($element[$k]['criteria_ca'])?',\''.$element[$k]['criteria_ca'].'\'':'';
			$elementId=$e[$arrayId[$listName]];
			if($i<$maxResults){
				?><tr bgcolor="#<?=$bgColor?>"><?php
					$e=utf8enc($e,1);
					switch($listName){
						case 'action':
						/*
						#012-Action Tracking
						Added critera Id parameter
						Fixed By - Infosys Limited
						Version: V 4.4
						*/
							?><td><input class="popUpBtn"onClick="popUpOpt('<?=$popUpId[$listName]?>',[<?=$e['review_profile']?>,<?=$elementId,$criteriaCa?>,<?= $e['ca_id']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpActDiv_<?=$elementId?>"></div></td><?php
						break;
						// End for #012
						case 'rid':
							?><td><input class="popUpBtn"onClick="popUpOpt('<?=$popUpId[$listName]?>',[<?=$e['review_profile']?>,<?=$elementId,$criteriaCa?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpRidDiv_<?=$elementId?>"></div></td><?php
						break;

                                case 'change':
                                    ?><td><?php
                                        if ($e['change_status'] != 2 || checkPermission('superadmin', 'superadmin', 0, 'check', $SESSION) == 1) {
                                            ?><input class="popUpBtn"onClick="popUpOpt('std', ['<?= $popUpId[$listName] ?>', '<?= $elementId ?>']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpChgDiv_<?= $elementId ?>"></div><?php
                                    }
                                    ?></td><?php
                                break;

                            case 'cat': //JFM 21_08_13
                                ?><td><?php
                                ?><input class="popUpBtn"onClick="popUpOpt('<?= $popUpId[$listName] ?>', [<?= $elementId ?>,<?= $e['criterion'] ?>,<?= $e['criterion_validity_id'] ?>,<?= $e['review_profile_id'] ?>, '<?= $e['review_id'] ?>',<?= $e['criterion_valid'] ?>, '<?= $tableCacheId ?>']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCatDiv_<?= $elementId ?>"></div><?php //JFM 11_09_13
                                ?></td><?php
                                break;

                            case 'usr': //JFM 16_01_15
                                $userName = utf8_encode($e['name'] . ' ' . $e['surname']);
                                ?><td><?php
                                ?><input class="popUpBtn"onClick="popUpOpt('usr', ['<?= $e['user_id'] ?>', '<?= $userName ?>']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpUsrDiv_<?= $e['user_id'] ?>"></div><?php
                                ?><img class="xRemove" style="cursor:pointer;" alt="Open Contact Card" onclick="showOOUI('<?= $e['email'] ?>');" onmouseout="hideOOUI();" src="../common/img/info.png"><?php
                                ?></td><?php
                                break;

                            case 'risk':
                                ?><td><input class="popUpBtn" onClick="popUpOpt('<?= $popUpId[$listName] ?>', [<?= $elementId ?>]);" type="button"value="&#8801;"><div class="popUpMenu"id="popUpRiskDiv_<?= $elementId ?>"></div></td><?php
                                    break;
                            }
                            foreach ($tableStructure as $columnName => $columnDetails) {
                                if (getFilter($columnName, 'hide', 0, $SESSION) != 1) {
                                    if (!empty($tableStructure[$columnName]['extras'])) { //JFM 16_09_13
                                        foreach ($tableStructure[$columnName]['extras'] as $z) {
                                            if (is_array($z))
                                                drawReviewElement($e, $elementId, $z['fakeColumnHeader'], $z, 0, $i, $SESSION, $today, $status, '');
                                            else
                                                drawReviewElement($e, $elementId, $z, $columnDetails, 0, $i, $SESSION, $today, $status, '');
                                        }
                                    } else
                                        drawReviewElement($e, $elementId, $columnName, $columnDetails, 0, $i, $SESSION, $today, $status, '');
                                }
                            }
                            $i++;
                            $b = ($b) ? false : true;
                            ?></tr><?php
                        }
                    }
                }else {
                    ?><td class="emptyTable" colspan="<?= count($tableStructure) ?>">No available Elements for the selected parameters</td><?php
            }
            if ($first == 0) {
                ?></table><?php
            }
        }

        if ($POST['removeTableCache'] != '') {
            removeCache($POST['removeTableCache']);
            unset($SESSION['table_result_count'][$POST['removeTableCache']]);
            $tableCacheId = $POST['removeTableCache'];
            //JFM 02_12_13
            if ($POST['list_name'] != 'cat')
                echo 'OK|||';
            else if (empty($POST['review_profile']))
                echo 'OK|||';
        }

        if ($POST['table_cache_id'] == '' || !cacheExists($POST['table_cache_id'])) {
            $first = 1;
            switch ($POST['list_name']) {
                case 'action':
                    $validFilter = array('ca' => 'ap.ca', 'review_criteria_id' => 'ac.criteria', 'action_status' => 'ac.action_status', 'review_profile' => 'rp.review_profile_id'); //JFM 11_03_14
                    break;
                case 'rid':
                    $validFilter = array('ca' => 'ap.ca', 'review_criteria_id' => 'ac.criteria', 'rid_status' => 'rd.rid_status', 'review_profile' => 'rp.review_profile_id'); //JFM 11_03_14
                    break;
                case 'cat':  //JFM 14_11_13	- JFM 02_12_13
                    if (!empty($POST['table_cache_id']))
                        $tableCacheId = $POST['table_cache_id'];
                    break;
            }

            $specificFilter = array();
            $reviewProfileIncluded = 0;

            // JFM 02_10_14
            // This is here so filters work properly. This allows filters to work with the minimum amount of code changes. No other files are effected.
            // 		- 	This ensures that if any $POST requests are lost while filtering, they are restored through the already set $SESSION variable.
            // 		-	The same thing could be achieved by passing $POST to where the filters are set but that would have evolved modifying about a billion
            // 			files. Doing this neat little hack means we only effect 1 file to achieve the same results. Probably quicker as well as were are not
            // 			throwing $POST variables around all over the place by doing it this way.
            //-------------------------------------------------------------------------------------

            if ($POST['list_name'] != 'cat') {
                /*
                 * US #054
                 * Version :2.0
                 * Fixed by : Infosys Limited 
                 * pie chart condittion
                 */
                $checkItemFiltersArray = array('review_profile', 'ca', 'action_status', 'userId', 'review_criteria_id', 'msn', 'coe', 'program', 'iNeedThisSoItWorks', 'piediagram');

                foreach ($checkItemFiltersArray as $itemFilter) {
                    if (!empty($POST[$itemFilter]))
                        $SESSION['list_action'][$itemFilter] = $POST[$itemFilter];
                    else if (!empty($POST['m'])) {
                        if (!empty($SESSION['list_action'][$itemFilter]))
                            $POST[$itemFilter] = $SESSION['list_action'][$itemFilter];
                    } else
                        unset($SESSION['list_action'][$itemFilter]);
                }
            }

            //-------------------------------------------------------------------------------------

            if (is_array($validFilter)) {
                foreach ($validFilter as $k => &$v) {
                    if (isset($POST[$k])) {
                        $specificFilter[] = $v . ' IN(' . $POST[$k] . ')';
                        if ($v == 'rp.review_profile_id') {
                            $reviewProfileIncluded = 1;
                        }
                    }
                }
            }

	if($POST['list_name']=='action' || $POST['list_name']=='rid')
	{
		if($reviewProfileIncluded==0)
		{
			/*
			* US #054
			* Version :2.0
			* Fixed by : Infosys Limited 
			* pie chart condittion
			*/
			if (!isset($POST['piediagram']) || empty($POST['piediagram'])) {
				$validReviewProfile=allowedSimpleObject('review_profile','review_type',$SESSION,'dr_','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION));
				if(is_array($validReviewProfile)){
					$invertedReviewProfile=array();
					foreach($validReviewProfile as $k=>$v){
						$invertedReviewProfile[]=$k;
					}
				//JFM 28_03_13 $specificFilter[]='gr.review_profile IN('.implode(',',$invertedReviewProfile).')';
				$specificFilter[]='rp.review_profile_id IN('.implode(',',$invertedReviewProfile).')';
				}
			}  
		}
		if(!empty($POST['userId']))
		{
			$specificFilter[]='(ac.action_holder='.$POST['userId'].' OR ac.action_validator='.$POST['userId'].')';
		}
		if(!in_array('program',$POST))
		{
			$specificFilter[]='ca.program='.getFilter('program','filter',0,$SESSION);
		}
		if(!in_array('coe',$POST))
		{
			$specificFilter[]='ca.coe='.getFilter('coe','filter',0,$SESSION);
		}
		else if (is_numeric($POST['coe'])) //JFM 11_03_13
		{
			$specificFilter[]='ca.coe='.$POST['coe'];
		}
		if(checkPermission('c_perimeter_general','view',0,'check',$SESSION)!=1){
			$validPerimeter=perimeterPermission($SESSION,'view');
			
			if(is_array($validPerimeter)){
				foreach($validPerimeter as $k=>$v){
					$perimeter[]=$k;
				}
			}else{
				$perimeter=array();
			}
			// Pie count bug
			if (!empty($perimeter)) {
			   $specificFilter[]='ca.perimeter IN('.implode(',',$perimeter).')';	
			}
		}
	}
	
	if(count($specificFilter)>0){
		$qryFilter='WHERE rp.rp_hidden=0 AND '.implode(' AND ',$specificFilter);
		//$qryFilter='WHERE '.implode(' AND ',$specificFilter);
	}
 // End of US #110 - Possibility to delete a review type in Structure Management and remove Lvl 1, Lvl2 and Lvl3 
	switch($POST['list_name']){
		case 'action':
			if($POST['ca']!=''){
				$caRestrictionTable='	INNER JOIN dr_action_applicability	AS ap2	ON ap2.action=ac.action_id
										INNER JOIN c_ca						AS ca	ON ap2.ca=ca.ca_id ';
				$groupBy=' GROUP BY ac.action_code,ap2.ca';
			}else{
				$caRestrictionTable='	INNER JOIN c_ca						AS ca	ON ap.ca=ca.ca_id ';
				$groupBy='';
			}
			
			$srchStart=microtime(true);	
			/*
				#012-Action Tracking
				Added critera Id parameter
				Fixed By - Infosys Limited
				Version: V 4.4
			*/
			$actionRawData1=SqlLi('SELECT DISTINCT ac.action_id,ca.ca_id,ac.msn,ac.criteria,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_closure,ac.action_status,ac.action_holder,ac.action_holder_name,ac.action_validator,ac.action_validator_name,
									ca.ca,
									prm.perimeter,
									m.msn AS msn_txt,
									m.msn_id,
									wp.wp,
									rd.rid_code AS rid,
									crh.criterion_name AS criteria_position,
									gr.review_group_description AS group_position,
									rp.review_profile_id
								FROM dr_action								AS ac
									INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
									' . $caRestrictionTable . '
									INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
									INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
									INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND ac.msn=m.msn_id)
									INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
									INNER JOIN dr_review_criterion 			AS cr 	ON ac.criteria=cr.review_criterion_id 
									INNER JOIN dr_review_criterion_history 	AS crh 	ON cr.review_criterion_id=crh.criterion
									INNER JOIN dr_review_group				AS rg 	ON cr.review_group=rg.group_id
									INNER JOIN dr_review_group_history 		AS gr 	ON rg.group_id=gr.review_group 
									INNER JOIN dr_review_type 				AS rt 	ON rg.review_type=rt.review_type_id
									INNER JOIN dr_review_profile			AS rp 	ON rt.review_type_id=rp.review_type
									LEFT JOIN  dr_rid 						AS rd 	ON ac.rid=rd.rid_id 
								'.$qryFilter.$groupBy);
			/*
				#012-Action Tracking
				Added critera Id parameter
				Fixed By - Infosys Limited
				Version: V 4.4
			*/
			$actionRawData2=SqlLi('SELECT DISTINCT ac.action_id,ca.ca_id,ac.msn,ac.criteria,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_closure,ac.action_status,ac.action_holder,ac.action_holder_name,ac.action_validator,ac.action_validator_name,
									ca.ca,
									prm.perimeter,
									m.msn AS msn_txt,
									m.msn_id,
									wp.wp,
									rd.rid_code AS rid,
									rp.review_profile_id
								FROM dr_action								AS ac
									INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
									' . $caRestrictionTable . '
									INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
									INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
									INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND ac.msn=m.msn_id)
									INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
									INNER JOIN dr_review 					AS r 	ON ac.review=r.review_id
									INNER JOIN dr_review_profile			AS rp   ON r.review_profile=rp.review_profile_id
									INNER JOIN dr_review_type 				AS rt 	ON rp.review_type=rt.review_type_id
									LEFT JOIN  dr_rid 						AS rd 	ON ac.rid=rd.rid_id 
								' . $qryFilter . $groupBy);

                    if (!empty($actionRawData1) && !empty($actionRawData2))
                        $actionRawData = array_merge($actionRawData1, $actionRawData2);
                    else if (!empty($actionRawData1))
                        $actionRawData = $actionRawData1;
                    else if (!empty($actionRawData2))
                        $actionRawData = $actionRawData2;

                    if (is_array($actionRawData)) {
                        foreach ($actionRawData as $action) {
                            foreach ($action as $actionField => $actionDetails) {
                                if ($actionField == 'ca') {
                                    if ($rawData[$action['action_id']]['action_applicability'] == '') {
                                        $rawData[$action['action_id']]['action_applicability'] = $actionDetails;
                                    } else {
                                        $rawData[$action['action_id']]['action_applicability'] = $rawData[$action['action_id']]['action_applicability'] . ', ' . $actionDetails;
                                    }
                                } else {
                                    if ($actionField == 'action_holder') {
                                        $rawData[$action['action_id']]['action_holder_txt'] = $SESSION['user_list'][$actionDetails];
                                        $rawData[$action['action_id']]['action_holder_txt_email'] = $SESSION['user_email'][$actionDetails]; //JFM 02_10_14
                                    } elseif ($actionField == 'action_validator') {
                                        $rawData[$action['action_id']]['action_validator_txt'] = $SESSION['user_list'][$actionDetails];
                                        $rawData[$action['action_id']]['action_validator_txt_email'] = $SESSION['user_email'][$actionDetails]; //JFM 02_10_14
                                    }
                                    $rawData[$action['action_id']][$actionField] = $actionDetails;
                                }
                                if ($POST['ca'] != '') {
                                    $rawData[$action['action_id']]['criteria_ca'] = $POST['ca'];
                                }
                            }
                        }
                    }
                    break;
                case 'change':
                    $rawData = SqlAsLi('SELECT chg.change_id,chg.change_status,chg.change_description,chg.change_creation,chg.change_completion,chg.change_created_by,
								clt.change_log_type_in AS change_type
							FROM dr_change AS chg
								INNER JOIN c_change_log_type AS clt ON chg.change_type=clt.change_log_type_id
							' . $qryFilter . '
							ORDER BY change_id DESC', 'change_id', 'p12', 1);

                    if (is_array($rawData)) {
                        foreach ($rawData as $changeId => $changeDetails) {
                            $rawData[$changeId]['change_created_by_txt'] = $SESSION['user_list'][$changeDetails['change_created_by']];
                        }
                    }

                    $screenshotQry = mysql_query('SELECT chs.change FROM dr_change_screenshot AS chs', $p12) or die(mysql_error());
                    while ($s = mysql_fetch_assoc($screenshotQry)) {
                        $rawData[$s['change']]['change_screenshot'] ++;
                    }
                    $remarkQry = mysql_query('SELECT chr.change,chr.change_remark_by,chr.change_remark_date,chr.change_remark
				FROM dr_change_remark AS chr
				ORDER BY chr.change_remark_date DESC', $p12) or die(mysql_error());
                    while ($r = mysql_fetch_assoc($remarkQry)) {
                        $rawData[$r['change']]['change_remark'][] = array('user' => $SESSION['user_list'][$r['change_remark_by']], 'user_id' => $r['change_remark_by'], 'date' => $r['change_remark_date'], 'text' => $r['change_remark']);
                    }
                    break;
                case 'rid':
                    //JFM 02_09_13 - JFM 11_03_14
                    $rawData = SqlAsLi('SELECT rd.rid_id,rd.rid_code,rd.rid_title,rd.rid_status,rd.rid_holder_name,rd.rid_validator_name,rd.rid_holder,rd.rid_validator,rd.rid_creation,rd.rid_completion,rd.rid_closure, rd.rid_showstopper,rd.rid_action_plan, rd.rid_change_note,
								ac.action_id,
								CONCAT(u1.surname,", ",u1.name) AS rid_holder_txt, CONCAT(u2.surname,", ",u2.name) AS rid_validator_txt,
								rp.review_profile_id
							FROM dr_rid AS rd
								LEFT JOIN dr_action 					AS ac	ON rd.rid_id=ac.rid
								LEFT JOIN c_user 						AS u1	ON rd.rid_holder=u1.user_id
								LEFT JOIN c_user 						AS u2	ON rd.rid_validator=u2.user_id
								INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
								INNER JOIN c_ca							AS ca	ON ap.ca=ca.ca_id
								INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
								INNER JOIN c_msn						AS m	ON cw.msn=m.msn_id
								INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
								INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
								INNER JOIN dr_review_criterion 			AS cr 	ON ac.criteria=cr.review_criterion_id 
								INNER JOIN dr_review_criterion_history 	AS crh 	ON cr.review_criterion_id=crh.criterion
								INNER JOIN dr_review_group				AS rg 	ON cr.review_group=rg.group_id
								INNER JOIN dr_review_group_history 		AS gr 	ON rg.group_id=gr.review_group 
								INNER JOIN dr_review_type 				AS rt 	ON rg.review_type=rt.review_type_id
								INNER JOIN dr_review_profile			AS rp 	ON rt.review_type_id=rp.review_type
							' . $qryFilter . '
							GROUP BY rd.rid_id', 'rid_id', 'p12', 1);

                    if (is_array($rawData)) {
                        $actionsInRid = SqlMAsArr('SELECT rid,action_code FROM dr_action WHERE rid IN(' . implode(',', array_keys($rawData)) . ')', 'rid', 'action_code');

                        foreach ($rawData as $ridId => $ridDetails) {
                            $rawData[$ridId]['action_code'] = implode(chr(13), $actionsInRid[$ridId]);

                            if ($ridDetails['rid_holder'] != '')
                                $rawData[$ridId]['rid_holder_txt_email'] = $SESSION['user_email'][$ridDetails['rid_holder']]; //JFM 30_10_14
                            else if ($ridDetails['rid_validator'] != '')
                                $rawData[$ridId]['rid_validator_txt_email'] = $SESSION['user_email'][$ridDetails['rid_validator']]; //JFM 30_10_14
                        }
                    }

                    break;

                case 'cat': //JFM 21_08_13 - JFM 09_09_13 - JFM 11_09_13 - JFM 23_09_13 - JFM 28_10_13 - JFM 02_12_13
                    // This is here so filters work properly. If there is no review profile in $POST, this case MUST have been called from the filter code.
                    // Therefore we get it's previous $SESSION value. This allows filters to work with the minimum amount of code changes. No other files are effected.
                    //-------------------------------------------------------------------------------------

                    if (empty($POST['review_profile'])) {
                        $reviewProfile = $SESSION['list_cat']['review_profile'];
                        $groupID = $SESSION['list_cat']['groupID'];
                        $reviewID = $SESSION['list_cat']['reviewID'];
                    } else {
                        $reviewProfile = $POST['review_profile'];
                        $groupID = $POST['groupID'];
                        $reviewID = $POST['reviewID'];

                        $SESSION['list_cat']['review_profile'] = $reviewProfile;
                        $SESSION['list_cat']['groupID'] = $groupID;
                        $SESSION['list_cat']['reviewID'] = $reviewID;
                    }

                    if ($reviewID == 'M') {
                        $reviewID = '';
                        $reviewMa = 1;
                    }


                    if ($reviewID)
                        $validationDate = SqlLi('SELECT validation_date FROM dr_review WHERE review_id=' . $reviewID);

                    // This is too complicated to explain in a comment. Needless to say it is very important.
                    //-------------------------------------------------------------------------------------
                    $query = 'SELECT rch.criterion_validity_id, rch.criterion, rch.criterion_user_id, rch.criterion_name, rch.criterion_description, rch.criterion_showstopper, rch.criterion_moc, rch.criterion_valid_from,
							rp.review_profile_id, 
							rc.criterion_group,
							GROUP_CONCAT(g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \')		AS grams_id, 
							GROUP_CONCAT(apl.application_level,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \')	AS application_level,
							GROUP_CONCAT(dis.discipline,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \')			AS discipline,
							GROUP_CONCAT(pro.program SEPARATOR \', \')																														AS program';

                    if ($reviewID)
                        $query .= ',rco.review_configuration_id AS criterion_included';
                    if ($reviewMa)
                        $query .= ',rm.review_master_id AS criterion_included';

                    $query .= ' FROM dr_review_criterion_history AS rch
							INNER JOIN dr_review_criterion 					AS rc	ON	rc.review_criterion_id=rch.criterion
							INNER JOIN dr_review_group 						AS rg	ON	rg.group_id=rc.review_group
							INNER JOIN dr_review_profile					AS rp	ON	rp.review_type=rg.review_type
							LEFT  JOIN dr_criterion_group 					AS cg	ON	rc.criterion_group=cg.criterion_group_id
							LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
							LEFT  JOIN c_grams								AS g	ON	rca.applicability=g.grams_id
																					AND	rca.object=' . $SESSION['object']['grams_id'] . '
																					AND (rca.review_criterion_applicability_valid_to="0000-00-00 00:00:00" OR rca.review_criterion_applicability_valid_to="0000-00-00 00:00:01")
							LEFT  JOIN c_application_level					AS apl	ON	rca.applicability=apl.application_level_id
																					AND	rca.object=' . $SESSION['object']['application_level'] . '
																					AND (rca.review_criterion_applicability_valid_to="0000-00-00 00:00:00" OR rca.review_criterion_applicability_valid_to="0000-00-00 00:00:01")
							LEFT  JOIN c_discipline							AS dis	ON	rca.applicability=dis.discipline_id
																					AND	rca.object=' . $SESSION['object']['discipline'] . '
																					AND (rca.review_criterion_applicability_valid_to="0000-00-00 00:00:00" OR rca.review_criterion_applicability_valid_to="0000-00-00 00:00:01")
							LEFT  JOIN c_program							AS pro	ON	pro.program_id=rp.program';

                    if ($reviewID)
                        $query .= ' LEFT  JOIN dr_review_configuration		AS rco	ON	rco.criterion=rc.review_criterion_id
																					AND rco.review=' . $reviewID . '
																					AND rch.criterion_valid_from <= "' . $validationDate[0]['validation_date'] . '"';

                    if ($reviewMa)
                        $query .= ' LEFT  JOIN 								(
																				SELECT * 	
																				FROM dr_review_master AS rm 
																					INNER JOIN dr_review_master_history AS rmh 	ON rm.review_master_id=rmh.review_master
																																AND rmh.review_master_valid_to="0000-00-00 00:00:00"
																			)
																			AS rm	ON	rm.review_type=rp.review_type
																					AND rm.criterion=rc.review_criterion_id';

                    $query .= ' WHERE rch.criterion_valid_to="0000-00-00 00:00:00" AND rch.criterion_hidden=0';

                    if (!empty($reviewProfile)) {
                        /**
                         * Fix for : Bug-7
                         * Version :4.2
                         * Fixed by : Infosys Limited 
                         * Criteria group and criteria id  in Master list management display in lexicon sorted
                         */
                        if (!empty($groupID))
                            $query .= ' AND review_profile_id=' . $reviewProfile . ' AND group_id=' . $groupID . ' GROUP BY rch.criterion_validity_id ORDER BY rch.criterion_user_id ASC';
                        else
                            $query .= ' AND review_profile_id=' . $reviewProfile . ' GROUP BY rch.criterion_validity_id ORDER BY rch.criterion_user_id ASC';
                    }
                    else {
                        $query = $query . ' GROUP BY rch.criterion_validity_id ORDER BY rch.criterion_user_id ASC';
                    }
                    $rawData = SqlLi($query);
                    if (is_array($rawData)) {
                        foreach ($rawData as $q => $z) {
                            // Is the criteria valid?
                            //-------------------------------------------------------------------------------------
                            if ($z['criterion_valid_from'] == "0000-00-00 00:00:00") {
                                $rawData[$q]['criterion_valid'] = 0;
                                /*
                                 * US#113 - Managing of new criteria in different criteria lists
                                 * Version: V 4.4
                                 * To display the validation date in master list mangement page
                                 * Fixed by: Infosys Limited
                                 */

                                $rawData[$q]['criterion_validation_date'] = $z['criterion_valid_from'];
                                //End of Add for #113
                            } else {
                                $rawData[$q]['criterion_valid'] = 1;
                                /*
                                 * US#113 - Managing of new criteria in different criteria lists
                                 * Added for version V 4.4
                                 * To display the validation date in master list mangement page
                                 * Fixed by: Infosys Limited
                                 */
                                $rawData[$q]['criterion_validation_date'] = $z['criterion_valid_from'];
                                //End of Add for #113
                            }
                            // Is it included?
                            //-------------------------------------------------------------------------------------
                            if ($reviewID || $reviewMa) {
                                if ($z['criterion_included'] != "" && $z['criterion_valid_from'] != "0000-00-00 00:00:00")
                                    $rawData[$q]['criterion_included'] = 1;
                                else
                                    $rawData[$q]['criterion_included'] = 0;
                            }
                            else {
                                $rawData[$q]['criterion_included'] = '-1';
                            }

                            // GRAMS, Application Level, Discipline & Program
                            //-------------------------------------------------------------------------------------		
                            $columns = array('grams_id', 'application_level', 'discipline', 'program');

                            foreach ($columns as $column) {
                                $array1 = explode(", ", $z[$column]);

                                $rawData[$q][$column] = '';

                                foreach ($array1 as $a1) {
                                    $array2 = explode("---", $a1);

                                    if ($array2[1] == '0000-00-00 00:00:01' && $rawData[$q]['criterion_valid_from'] == "0000-00-00 00:00:00")
                                        continue;
                                    if ($array2[2] == '0000-00-00 00:00:00' && $rawData[$q]['criterion_valid_from'] != "0000-00-00 00:00:00")
                                        continue;
                                    else {
                                        if ($column == "grams_id") {
                                            if (empty($rawData[$q]['grams_id']))
                                                $rawData[$q]['grams_id'] = $array2[0];
                                            else
                                                $rawData[$q]['grams_id'] = $rawData[$q]['grams_id'] . ', ' . $array2[0];
                                        }
                                        else {
                                            $rawData[$q][$array2[0]] = 1;
                                        }
                                    }
                                }
                            }

                            // Add this not visible column so I can pass the review ID to popUpOptions.php via function drawBasicList
                            //-------------------------------------------------------------------------------------
                            if ($reviewID)
                                $rawData[$q]['review_id'] = $reviewID;
                            if ($reviewMa)
                                $rawData[$q]['review_id'] = 'M';

                            $rawData[$q]['group_id'] = $groupID;
                            $rawData[$q]['table_cache_id'] = $POST['table_cache_id'];
                        }
                    }

                    break;

                case 'evd': //JFM 28_04_14			

                    $query = 'SELECT DISTINCT rch.criterion_user_id, rch.criterion_name, rch.criterion_description, rch.criterion_moc, rch.criterion_showstopper, 
									rgh.review_group_description,
									rc.review_criterion_id,
									ra.ca,
									GROUP_CONCAT(DISTINCT cs.criteria_status,\'---\',ra.ca SEPARATOR \', \') AS criteria_status,
									GROUP_CONCAT(DISTINCT cs.criteria_planned,\'---\',ra.ca SEPARATOR \', \') AS planned_evd,
									GROUP_CONCAT(DISTINCT cs.criteria_status_id,\'---\',ra.ca SEPARATOR \', \') AS criteria_status_id,
									GROUP_CONCAT(DISTINCT ca.ca,\'---\',ra.ca SEPARATOR \', \') AS ca_evidence_info,
									GROUP_CONCAT(DISTINCT vl2.action_taken_on,\'---\',ra.ca SEPARATOR \', \') AS supplied,
									GROUP_CONCAT(DISTINCT g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS grams_id,
									GROUP_CONCAT(DISTINCT " ",u.name," ",u.surname,\'---\',ra.ca SEPARATOR \', \') AS provider,
									GROUP_CONCAT(DISTINCT ce.file_link,\'---\',ra.ca SEPARATOR \', \') AS file_link,
									GROUP_CONCAT(DISTINCT " ",u2.name," ",u2.surname,\'---\',ra.ca SEPARATOR \', \') AS validator,
									GROUP_CONCAT(DISTINCT vl.action_taken_on,\'---\',ra.ca SEPARATOR \', \') AS action_taken_on,
									GROUP_CONCAT(DISTINCT " ",u3.name," ",u3.surname,\'---\',ra.ca SEPARATOR \', \') AS stakeholder
						FROM dr_review_criterion_history 				AS rch
						INNER JOIN dr_review_criterion 					AS rc 		ON  rc.review_criterion_id=rch.criterion
						INNER JOIN dr_review_configuration 				AS rconf 	ON  rconf.criterion=rc.review_criterion_id
						INNER JOIN dr_review_group 						AS gro 		ON 	gro.group_id=rc.review_group
						INNER JOIN dr_review_group_history				AS rgh 		ON  rgh.review_group=gro.group_id
						INNER JOIN dr_review_type 						AS rt 		ON 	rt.review_type_id=gro.review_type
						INNER JOIN dr_review_profile 					AS rp 		ON 	rp.review_type=rt.review_type_id
						INNER JOIN dr_review 							AS r 		ON 	r.review_profile=rp.review_profile_id
																					AND r.review_id=rconf.review
						INNER JOIN dr_review_applicability 				AS ra 		ON 	ra.review=r.review_id
						INNER JOIN c_ca 								AS ca 		ON  ca.ca_id=ra.ca
						LEFT  JOIN dr_criteria_status 					AS cs 		ON 	cs.ca=ra.ca
																					AND cs.review_criteria=rc.review_criterion_id
																					AND cs.msn=r.msn
						LEFT  JOIN dr_criteria_status_evidence 			AS cse 		ON  cse.criteria_status=cs.criteria_status_id
						LEFT  JOIN dr_criteria_evidence 				AS ce 		ON 	ce.criteria_evidence_id=cse.criteria_evidence
						LEFT  JOIN dr_criteria_status_provider 			AS csp 		ON 	csp.criteria_status=cs.criteria_status_id
						LEFT  JOIN c_user 								AS u 		ON 	u.user_id=csp.provider
						LEFT  JOIN dr_validation_loop					AS vl 		ON  vl.applicability=cs.criteria_status_id
																					AND vl.object=' . $SESSION['object']['criteria_status_id'] . '
																					AND vl.action_taken=' . $SESSION['user_action']['validated'] . '
																					AND vl.action_taken_on!="0000-00-00 00:00:00"
						LEFT  JOIN c_user 								AS u2 		ON 	u2.user_id=vl.validator
						LEFT  JOIN dr_validation_loop					AS vl2 		ON  vl2.applicability=cs.criteria_status_id
																					AND vl2.object=' . $SESSION['object']['criteria_status_id'] . '
																					AND vl2.action_taken=' . $SESSION['user_action']['originated'] . '
						LEFT  JOIN dr_validation_loop_structure 		AS vls 		ON 	vls.object=' . $SESSION['object']['criteria_status_id'] . '
																					AND vls.applicability=cs.criteria_status_id
						LEFT  JOIN c_user 								AS u3 		ON  u3.user_id=vls.validator
						LEFT  JOIN dr_review_criterion_applicability	AS rca		ON	rc.review_criterion_id=rca.criterion
						LEFT  JOIN c_grams								AS g		ON	rca.applicability=g.grams_id
																					AND	rca.object=' . $SESSION['object']['grams_id'] . '
																					AND (rca.review_criterion_applicability_valid_to="0000-00-00 00:00:00" OR rca.review_criterion_applicability_valid_to="0000-00-00 00:00:01")
						WHERE rp.review_profile_id=' . $reviewProfile . '
						AND ra.ca IN (' . $ca . ')
						AND rch.criterion_valid_from <= r.validation_date
						AND rch.criterion_valid_from != "0000-00-00 00:00:00"
						AND r.msn=' . getFilter('msn', 'filter', 0, $SESSION) . '
						GROUP BY rch.criterion_validity_id ORDER BY rgh.review_group_position ASC';

                    SqlLQ('SET SESSION group_concat_max_len=1000000');

                    $rawData = SqlLi($query);

                    SqlLQ('SET SESSION group_concat_max_len=1024');

                    foreach ($rawData as $q => $z) {
                        $columns = array('grams_id', 'provider', 'stakeholder', 'file_link', 'validator', 'action_taken_on', 'planned_evd', 'supplied', 'criteria_status', 'criteria_status_id', 'ca_evidence_info');

                        foreach ($columns as $column) {
                            $array1 = explode(", ", $z[$column]);

                            $rawData[$q][$column] = '';

                            foreach ($array1 as $a1) {
                                $array2 = explode("---", $a1);

                                if ($column == 'grams_id') {
                                    if ($array2[1] == '0000-00-00 00:00:01' && $rawData[$q]['criterion_valid_from'] == "0000-00-00 00:00:00")
                                        continue;
                                    if ($array2[2] == '0000-00-00 00:00:00' && $rawData[$q]['criterion_valid_from'] != "0000-00-00 00:00:00")
                                        continue;
                                    if (empty($rawData[$q]['grams_id']))
                                        $rawData[$q]['grams_id'] = $array2[0];
                                    else
                                        $rawData[$q]['grams_id'] = $rawData[$q]['grams_id'] . ', ' . $array2[0];
                                }
                                else if ($column == 'ca_evidence_info') {
                                    $tableStructure['ca_evidence_info_' . $array2[1]]['title'] = $array2[0];
                                    if (empty($rawData[$q][$column . '_' . $array2[1]]))
                                        $rawData[$q][$column . '_' . $array2[1]] = $array2[0];
                                    else
                                        $rawData[$q][$column . '_' . $array2[1]] = $rawData[$q][$column . '_' . $array2[1]] . ', ' . $array2[0];
                                }
                                else {
                                    if (empty($rawData[$q][$column . '_' . $array2[1]]))
                                        $rawData[$q][$column . '_' . $array2[1]] = $array2[0];
                                    else
                                        $rawData[$q][$column . '_' . $array2[1]] = $rawData[$q][$column . '_' . $array2[1]] . ', ' . $array2[0];
                                }
                                if ($column == 'criteria_status') {
                                    if (strlen($rawData[$q]['criteria_status']) > 1)
                                        $rawData[$q]['criteria_status'] = '';
                                    if (empty($rawData[$q]['criteria_status']))
                                        $rawData[$q]['criteria_status'] = $array2[0];
                                    else if ($array2[0] < $rawData[$q]['criteria_status'])
                                        $rawData[$q]['criteria_status'] = $array2[0];
                                }
                            }
                        }
                    }

                    break;

                case 'usr':  //JFM 16_01_15
                    /**
                      US #033, #021, #048
                      Supplier admin should be allowed to view users who are linked to the same supplier
                      Added siglum and supplier column in User management page
                      Fixed By - Infosys Limited
                      Version - 4.2
                     */
                    $supplierAdmin = SqlLi('SELECT supplier,type FROM c_user WHERE user_id=' . $SESSION['user']['user_id']);
                    $userSupplier = $supplierAdmin[0]['supplier'];
                    if ($supplierAdmin[0]['type'] == 1 && $userSupplier != 'AIRBUS') {
                        $query = 'SELECT u.user_id, u.login, u.name, u.surname, u.email, u.supplier FROM c_user as u LEFT JOIN c_department as d ON u.department = d.department_id WHERE u.supplier="' . $userSupplier . '"';
                        $rawData = SqlLi($query);
                    } elseif ($supplierAdmin[0]['type'] == 0 && $userSupplier == 'AIRBUS') {
                        $query = "SELECT u.user_id, u.login, u.name, u.surname, u.email, d.siglum, u.supplier FROM c_user as u LEFT JOIN c_department as d ON u.department = d.department_id";
                        $rawData = SqlLi($query);
                    } else {
                        $query = "SELECT u.user_id, u.login, u.name, u.surname, u.email, d.siglum, u.supplier FROM c_user as u LEFT JOIN c_department as d ON u.department = d.department_id";
                        $rawData = SqlLi($query);
                    }
                    // End for US #033, #048
                    break;

                case 'risk':

                    $query = 'SELECT rsk.*
					FROM dr_risk AS rsk
					INNER JOIN c_ca AS ca ON ca.ca_id = rsk.ca
					WHERE rsk.ca=' . $POST['ca'] . '
					AND risk_status=' . $POST['risk_status'];

                    $rawData = SqlLi($query);

                    foreach ($rawData as $q => $z) {
                        $rawData[$q]['rpn'] = $z['severity'] * $z['occurrence'] * $z['detection'];

                        if ($z['risk_holder'] != 0) {
                            $rawData[$q]['risk_holder_txt'] = $SESSION['user_list'][$z['risk_holder']];
                            $rawData[$q]['risk_holder_txt_email'] = $SESSION['user_email'][$z['risk_holder']];
                        } else
                            $rawData[$q]['risk_holder_txt'] = $z['risk_holder_name'];
                    }

                    break;
            }

            checkActiveFilter($filterActive, $tableStructure, 0, $SESSION, '', 1, $POST['skipFilter']); //JFM 13_02_14

            $data = filterRow($filterActive, $rawData);

            if ($POST['list_name'] == 'cat')
                $data = subVersion($data, $POST['expand']); //JFM 03_12_13

            sortBasicTable($data, $tableStructure, 0, $SESSION);

            storeCache('csv', $tableCacheId, $data);
            ?><div id="<?= $POST['list_name'] ?>-tableContainer"><?php
        //$startTime=microtime(true);
        ?><div><?php
        if ($POST['list_name'] == 'cat') { //JFM 11_11_13
            ?><div class="tableTitle" style="width:500px;"><?php
            if ($POST['groupID']) {
                $groupDescription = SqlQ('SELECT review_group_description FROM dr_review_group_history WHERE review_group=' . $POST['groupID'] . ' AND review_group_valid_to="0000-00-00 00:00:00"');
                ?><input class="popUpBtn"onClick="popUpOpt('ttl', ['group', '<?= $POST['review_profile'] ?>', '<?= $POST['reviewID'] ?>', '<?= $POST['groupID'] ?>']);"type="button"value="&#8801;"><?php
                ?><div class="popUpMenu"id="popUpTtlDiv_group"></div>&nbsp;<?php
            } else {
                $groupDescription['review_group_description'] = 'All Groups';
            }
            ?>&nbsp;<?= $groupDescription['review_group_description'] ?>:<?php
            ?></div><?php
        }
        ?><table class="criteriaTable"id="table_<?= $tableCacheId ?>" style="text-align:center;" cellspacing="=" cellpadding="5"><?php
        drawBasicList($data, $maxResults, $tableCacheId, $tableStructure, $POST['list_name'], $SESSION, 1);
        ?></table><?php
        ?><div><?php
            //echo microtime(true)-$startTime;
        } else {

            $first = 0;
            $tableCacheId = $POST['table_cache_id'];
            $data = loadCache('html', $tableCacheId);
            echo 'OK|||';
            drawBasicList($data, $maxResults, $tableCacheId, $tableStructure, $POST['list_name'], $SESSION, 0);
        }

        if (is_array($data)) {
            $i = 0;
            foreach ($data as $k => &$v) {
                if ($i < $maxResults) {
                    unset($data[$k]);
                }
                $i++;
            }
            storeCache('html', $tableCacheId, $data);
        }

        if ($first == 1) {
            $resultCount = count($data);
            $SESSION['table_result_count'][$tableCacheId] = $resultCount + $maxResults;

            nextResultButton($resultCount, $tableCacheId, 'list', $POST['list_name'], $displayedResults, $SESSION);
            ?></div><?php
            }

            storeSession($SESSION);
            ?>