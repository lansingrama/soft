<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

if(checkPermission('c_user_general','view',0,'check',$SESSION)==1 || checkPermission('c_user_general','edit',0,'check',$SESSION)==1){
	$SESSION['edit_user']['user_invited']=0;
	if(checkSendInvitation($GET['user_id'],$SESSION)==1){
		?>OK|||1<?php
	}else{
		?>OK|||error|||Invitation could not be sent<?php
	}
}else{
	?>OK|||no_rights<?php
}
storeSession($SESSION);
?>