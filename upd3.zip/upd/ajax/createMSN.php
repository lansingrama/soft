<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$msn=$_GET['msn'];
if($SESSION['Level']!=2 && $SESSION['Level']!=3)header("Location: ../security/accExp.php");
$prog=$SESSION['filter']['prog']['n'];
$coe=$SESSION['filter']['coe']['n'];
SqlLQ("INSERT INTO dqrp_msn (prog,coe,msn)VALUES('$prog','$coe','$msn')");
$caArr=SqlLi("SELECT ca FROM cawp WHERE prog='$prog' AND coe='$coe'");
foreach($caArr as &$c)SqlLQ("INSERT INTO dqrp_rev (prog,coe,MSN,ca,appl)VALUES('$prog','$coe','$msn','$c[ca]','1')");
Create_Log('Program: '.$prog.', CoE: '.$coe.', MSN: '.$msn,'MSN Created','dqrp_log');
echo $msn;
storeSession($SESSION);
?>