<?php
error_reporting(0);
if($included!=1){
	require_once('../support/header.php');
	require_once('../security/checkExpiredSession.php');
	require_once('../../support.php');
	require_once('../../common/php/common.php');
	require_once('../support/localSupport.php');
	$GET=cleanArray($_GET);
}

$includedCAs=array();

function previewHeader($reportCounter,$differentReviewConfig){
	?><div style="position:relative;height:50px;"></div><?php
		?><div class="formHeaderInfo"id="userDetailsTitle"style="<?php if($differentReviewConfig==1){?>color:#FF0000;<?php }?>position:relative;">Report #<?=$reportCounter?></div><?php
	?><div style="position:relative;height:20px;"></div><?php
	?><div class="elementDetailsContainer"><?php
		?><table class="criteriaTable"style="width:703px;" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup prmRow"><?php
				?><td style="width:100px;">CA</td><?php
				?><td style="text-align:center;width:50px;">Status</td><?php
				?><td style="width:100px;">WP</td><?php
				?><td nowrap style="width:170px;">Last Issue Created</td><?php
				?><td nowrap>Created By</td><?php
				/*JFM 19_07_16 ?><td style="width:100px;">Raise Issue</td><?php*/
			?></tr><?php
}

function previewFoot(){
		?></table><?php
	?></div><?php
}

if($GET['a0_report_review_profile']==''){
	if($included!=1){
		?>OK|||<?php
	}
	?><div class="sideContainerEmpty"style="color:#000000;">Please select a Review</div><?php
}else{
	$statusColor=array('r','a','g','b');
	global $p12;
	
	$wpQry=SqlAsArr('SELECT DISTINCT w.wp_id,w.wp
					FROM c_wp AS w
						INNER JOIN c_cawp AS cw ON w.wp_id=cw.wp
					WHERE cw.ca IN ('.$GET['a0_report_ca'].')
						AND cw.msn='.getFilter('msn','filter',0,$SESSION),'wp_id','wp');
	
	$wpTxt=implode(',',array_keys($wpQry));
	
	if($GET['a0_report_target']=='wp'){
		$caQry=SqlSLi('SELECT ca FROM c_cawp WHERE wp IN('.$wpTxt.') AND msn='.getFilter('msn','filter',0,$SESSION),'ca');
		$GET['a0_report_ca']=implode(',',$caQry);
	}
	
	/* JFM 14_11_13
	$caPerWpQry=mysql_query('SELECT c.ca_id,c.ca,cw.wp,
								r.review_status,r.review_done,r.review_configuration_profile,
								a0r.a0_report_issue,a0r.a0_report_creation,a0r.a0_report_upload_done,
								CONCAT(u.name," ",u.surname) AS created_by
							FROM c_ca AS c
								INNER JOIN c_cawp AS cw ON c.ca_id=cw.ca
								LEFT JOIN dr_review AS r ON (
									c.ca_id=r.ca
									AND r.msn='.getFilter('msn','filter',0,$SESSION).'
									AND r.review_profile='.$GET['a0_report_review_profile'].'
								)
								LEFT JOIN dr_a0_report AS a0r ON(
									a0r.msn='.getFilter('msn','filter',0,$SESSION).'
									AND c.ca_id=a0r.ca
									AND a0r.review_profile='.$GET['a0_report_review_profile'].'
								)
								LEFT JOIN c_user AS u ON a0r.user=u.user_id
							WHERE c.ca_id IN('.$GET['a0_report_ca'].')
								AND cw.msn='.getFilter('msn','filter',0,$SESSION),$p12) or die(mysql_error());*/
								
	$caPerWpQry=mysql_query('SELECT c.ca_id,c.ca,cw.wp,
								r.review_status,r.review_done,r.review_configuration_profile, r.validation_complete,
								a0r.a0_report_issue,a0r.a0_report_creation,a0r.a0_report_upload_done,
								CONCAT(u.name," ",u.surname) AS created_by
							FROM c_ca AS c
								INNER JOIN c_cawp AS cw ON c.ca_id=cw.ca
								LEFT JOIN dr_review_applicability AS ra ON c.ca_id=ra.ca
								LEFT JOIN dr_review AS r ON (
									r.review_id=ra.review
									AND r.msn='.getFilter('msn','filter',0,$SESSION).'
									AND r.review_profile='.$GET['a0_report_review_profile'].'
								)
								LEFT JOIN dr_a0_report AS a0r ON(
									a0r.msn='.getFilter('msn','filter',0,$SESSION).'
									AND c.ca_id=a0r.ca
									AND a0r.review_profile='.$GET['a0_report_review_profile'].'
								)
								LEFT JOIN c_user AS u ON a0r.user=u.user_id
							WHERE c.ca_id IN('.$GET['a0_report_ca'].')
								AND cw.msn='.getFilter('msn','filter',0,$SESSION),$p12) or die(mysql_error());
	
	while($r=mysql_fetch_assoc($caPerWpQry)){
		$caPerWp[$r['wp']][$r['ca_id']]['ca']=$r['ca'];
		$caPerWp[$r['wp']][$r['ca_id']]['ca_id']=$r['ca_id'];
		$caPerWp[$r['wp']][$r['ca_id']]['review_status']=$r['review_status'];
		$caPerWp[$r['wp']][$r['ca_id']]['review_done']=$r['review_done'];
		$caPerWp[$r['wp']][$r['ca_id']]['validation_complete']=$r['validation_complete'];
		$caPerWp[$r['wp']][$r['ca_id']]['a0_report_issue']=$r['a0_report_issue'];
		$caPerWp[$r['wp']][$r['ca_id']]['a0_report_creation']=$r['a0_report_creation'];
		$caPerWp[$r['wp']][$r['ca_id']]['created_by']=$r['created_by'];
		$caPerWp[$r['wp']][$r['ca_id']]['a0_report_upload_done']=$r['a0_report_upload_done'];
		$caPerWp[$r['wp']][$r['ca_id']]['review_configuration_profile']=$r['review_configuration_profile'];
	}
	
	$caPerWp=utf8enc($caPerWp);
	
	if($GET['a0_report_group']=='group'){
		foreach($wpQry as $wpId=>$wp){
			$caTotalCount+=count($caPerWp[$wpId]);
		}
	}

	if($included!=1){
		?>OK|||<?php
	}
	
	?><div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;">Reports Output</div><?php
	
	$reportCounter=0;
	$fakeReportCounter=0; //JFM 06_01_14
	$firstCa=1;
	$wpCount=count($wpQry);
	$background='FFFFFF';
	foreach($wpQry as $wpId=>$wp){
		$caCounter=0;
		foreach($caPerWp[$wpId] as $caId=>$caDetails){
			$caCounter++;

			//$generate=0;

			$generate=1;

			//if(!empty($caDetails['validation_complete']) && $caDetails['validation_complete']!=0 && $caDetails['validation_complete']!=1) $generate=1;

			if($GET['a0_report_target']=='ca' && $GET['a0_report_group']=='zip'){
				$caCounter=1;
				if($generate) $reportCounter++;
				$fakeReportCounter++;
				$caCount=1;
			}elseif($caCounter==1){
				if($GET['a0_report_group']=='zip' || $reportCounter==0){
					if($generate) $reportCounter++; //JFM 06_01_14
					$fakeReportCounter++; //JFM 06_01_14
				}
				$caCount=count($caPerWp[$wpId]);
			}
			if($generate) $caPerReport[$reportCounter][]=$caDetails['ca_id']; //JFM 06_01_14
			if($GET['a0_report_target']=='ca'){
				if($generate) $caWpTxtPerReport[$reportCounter][]=$caDetails['ca']; //JFM 06_01_14
			}else{
				if($caCounter==1){
					if($generate) $caWpTxtPerReport[$reportCounter][]=$wp; //JFM 06_01_14
				}
			}

			if(($GET['a0_report_group']=='zip' && $caCounter==1) || ($GET['a0_report_group']=='group' && $firstCa==1) ){
				previewHeader($fakeReportCounter,$differentReviewConfig[$reportCounter]);
			}
			$caStatus=($caDetails['review_done']==0)?3:$caDetails['review_status'];
			?><tr class="infoRow"><?php
				?><td style="background-color:#<?=$background?>"><?=$caDetails['ca']?></td><?php

				if($generate) //JFM 06_01_14
				{
					?><td style="background-color:#<?=$background?>;text-align:center;"><img height="20"src="../common/img/<?=$statusColor[$caStatus]?>20.png"width="20"></td><?php
					if($caCounter==1){
						?><td rowspan="<?=$caCount?>"style="background-color:#<?=$background?>"><?=$wp?></td><?php
					}
					$releaseDate=($caDetails['a0_report_issue']!='')?chr($caDetails['a0_report_issue']+65).' ('.$caDetails['a0_report_creation'].')':'N/A';
					?><td style="background-color:#<?=$background?>;<?php if($releaseDate=='N/A'){?>color:#999999;text-align:center<?php }?>"><?=$releaseDate?></td><?php
					if($caDetails['created_by']==''){
						$caDetails['created_by']='N/A';
					}
					?><td nowrap <?php if($caDetails['created_by']=='N/A'){?> style="color:#999999;text-align:center;"<?php }?>><?=$caDetails['created_by']?></td><?php
					
					/* JFM 19_07_16 if(($GET['a0_report_group']=='zip' && $caCounter==1) || ($GET['a0_report_group']=='group' && $firstCa==1) ){
						$raiseIssueRowSpan=($GET['a0_report_group']=='zip')?$caCount:$caTotalCount;
						?><td rowspan="<?=$raiseIssueRowSpan?>"style="background-color:#<?=$background?>"><input name="a0_report_raise_issue_<?=$reportCounter?>"type="radio"value="1">Yes <input checked name="raise_<?=$reportCounter?>"type="radio"value="0">No</td><?php
					}*/
				}
				else //JFM 06_01_14
				{
					?><td style="background-color:#<?=$background?>;text-align:center;" colspan="5"><b>Cannot Generate Review Report for this CA - Not Defined.</b></td><?php
				}

			?></tr><?php
			if($caCounter==$caCount && $GET['a0_report_group']=='zip' && ($reportCounter!=$wpCount || ($GET['a0_report_target']=='ca' && $GET['a0_report_group']=='zip'))){
				previewFoot();
			}
			$firstCa=0;
		}
		if($GET['a0_report_group']=='group'){
			$background=($background=='FFFFFF')?'E5E5E5':'FFFFFF';
		}
	}
	previewFoot();
	?><input name="a0_report_count"type="hidden"value="<?=$reportCounter?>"><?php
	if(is_array($caPerReport)){
		foreach($caPerReport as $reportId=>$c){
			?><input name="a0_report_ca_<?=$reportId?>"type="hidden"value="<?=implode(',',$caPerReport[$reportId])?>"><?php
			?><input name="a0_report_ca_txt_<?=$reportId?>"type="hidden"value="<?=implode('-',$caWpTxtPerReport[$reportId])?>"><?php
		}
	}
	?><div style="position:relative;height:50px;"></div><?php
}
storeSession($SESSION);
?>