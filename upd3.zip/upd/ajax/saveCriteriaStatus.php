<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST); //JFM 24_03_14
$criteria=array();
$existingCa=array();
$applicableCriteriaArray=array();
$doneFirstCriteria=false;
$submittingAcrossMultipuleCAs=false;
$answer='';
$msn;
$fullName='';
$email='';
$onlyOneCriteriaInValidationLoop=0;
if(!empty($POST['msn'])) $msn=$POST['msn'];
else $msn=getFilter('msn','filter',0,$SESSION);

$caArr=explode(',',$POST['ca']);

foreach ($POST as $arrayName=>$arrayValue)
{
	$foundProvider=strpos($arrayName,"criteriaCriteriaUsedInTheSameWpTable");
	if($foundProvider===0 && $arrayValue!='') 
	{
		$submittingAcrossMultipuleCAs=true;
		array_push($caArr,$arrayValue);
	}
}
	
$reviewIDs=SqlSLi('SELECT review_id FROM dr_review AS r
						INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
					WHERE ca IN ('.implode(',',$caArr).') AND msn="'.$msn.'"
					AND review_profile='.$POST['review_profile'],'review_id');
					
$allCas=SqlSLi('SELECT ca FROM dr_review_applicability WHERE review IN ('.implode(',',$reviewIDs).')','ca');
	
$caArr=$allCas;

$qry=formToQuery($POST,$SESSION['table']['review_planning']['criteria'],$SESSION);
								
foreach ($POST as $arrayName=>$arrayValue)
{
	$foundProvider=strpos($arrayName,"criteriaCriteriaTable");
	if($foundProvider===0 && $arrayValue!='') array_push($applicableCriteriaArray,$arrayValue);
}

foreach($applicableCriteriaArray as $applicableCriteria)
{
	$POST['review_criteria_id']=$applicableCriteria;

	$criteriaMlt=SqlAsLi('SELECT *
						FROM dr_criteria_status AS s
							INNER JOIN dr_review_criterion AS c ON s.review_criteria=c.review_criterion_id
						WHERE s.msn="'.$msn.'"
							AND s.ca IN('.implode(',',$caArr).')
							AND c.review_criterion_id="'.$POST['review_criteria_id'].'"','ca');

	if(!empty($criteriaMlt)){
		foreach($criteriaMlt as $criteriaCa=>$criteriaDetails){
			$existingCa[]=$criteriaCa;
		}
	}

	foreach($caArr as $c)
	{
		if(!in_array($c,$existingCa))
		{
			SqlLQ('INSERT INTO dr_criteria_status (msn,ca,review_criteria) VALUES ("'.$msn.'","'.$c.'","'.$POST['review_criteria_id'].'")');
			$lastCaStatusId=SqlQ('SELECT LAST_INSERT_ID()');
			$criteria=SqlQ('SELECT * FROM dr_criteria_status WHERE criteria_status_id='.$lastCaStatusId['LAST_INSERT_ID()']);
		}
		else
		{
			$criteria['criteria_status_id']=$criteriaMlt[$c]['criteria_status_id'];
		}

		$updateArray=getFormUpdate($qry,$criteriaMlt[$c],'review_planning','criteria',$criteria['criteria_status_id'],$SESSION);

		if(!empty($updateArray)) SqlLQ('UPDATE dr_criteria_status SET '.implode(',',$updateArray).' WHERE msn="'.$msn.'" AND ca="'.$c.'" AND review_criteria="'.$POST['review_criteria_id'].'"');

		if ($POST['statusRed']) SqlLQ('UPDATE dr_criteria_status SET criteria_status=0 WHERE msn="'.$msn.'" AND ca="'.$c.'" AND review_criteria="'.$POST['review_criteria_id'].'"');

		if($POST['continuous_assessment']) //JFM 09_04_14 - Everything in this if statement as well.
		{
			if(!$doneFirstCriteria || $submittingAcrossMultipuleCAs) SqlLQ('UPDATE dr_criteria_status SET criteria_planned="'.$POST['criteriaPlanned'].'" WHERE msn="'.$msn.'" AND ca="'.$c.'" AND review_criteria="'.$POST['review_criteria_id'].'"');

			if($POST['startValidationLoop']) 											SqlLQ('UPDATE dr_criteria_status SET criteria_status=2 WHERE msn="'.$msn.'" AND ca="'.$c.'" AND review_criteria="'.$POST['review_criteria_id'].'"');
			else if ($POST['statusRed']) 												SqlLQ('UPDATE dr_criteria_status SET criteria_status=0 WHERE msn="'.$msn.'" AND ca="'.$c.'" AND review_criteria="'.$POST['review_criteria_id'].'"');
			else if ($POST['criteria_status']!='g' || $POST['criteria_status']!='x')	SqlLQ('UPDATE dr_criteria_status SET criteria_status=1 WHERE msn="'.$msn.'" AND ca="'.$c.'" AND review_criteria="'.$POST['review_criteria_id'].'"');

			if($onlyOneCriteriaInValidationLoop==0 || $submittingAcrossMultipuleCAs)
			{
				//
				// Add all providers.
				// -------------------------------------------------------------------------------------------------------------------------------------------------------

				if(!$doneFirstCriteria || $submittingAcrossMultipuleCAs)
				{
					$providerArray=array();
					
					foreach ($POST as $arrayName=>$arrayValue)
					{
						$foundProvider=strpos($arrayName,"providersinputID");
						if($foundProvider===0 && $arrayValue!='') array_push($providerArray,$arrayValue);
					}

					$chID=$criteria['criteria_status_id'];
						
					SqlLQ('DELETE FROM dr_criteria_status_provider WHERE criteria_status="'.$chID.'"');

					if(!empty($providerArray))
					{			
						foreach($providerArray as $providerUsed)
						{
							$nameSplit=explode(", ",$providerUsed);

							SqlLQ('INSERT INTO dr_criteria_status_provider (criteria_status, provider) VALUES ("'.$chID.'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"))');				
						}
					}
				}
				

				//
				// Check if evidences has been changed and update accordingly.
				// -------------------------------------------------------------------------------------------------------------------------------------------------------
				
				$evidencesArray=array();
				
				foreach ($POST as $arrayName=>$arrayValue)
				{
					$foundevidences=strpos($arrayName,"evidencesinputID");
					if($foundevidences===0) array_push($evidencesArray,$arrayName);

				}

				$evidencesQry=SqlLi('SELECT ce.criteria_evidence_id, ce.file_link, cse.criteria_status_evidence_id
										FROM dr_criteria_evidence AS ce
										INNER JOIN dr_criteria_status_evidence as cse ON cse.criteria_evidence=ce.criteria_evidence_id
										WHERE cse.criteria_status='.$criteria['criteria_status_id']);
							

				//
				// Check if any evidences have been deleted and delete them.
				//
				
				if(!empty($evidencesQry))
				{
					foreach($evidencesQry as $evidence)
					{
						$found=false;

						if(!empty($evidencesArray))
						{
							foreach($evidencesArray as $evidencesFileLinkUsed)
							{
								if($evidence['file_link']==$POST[$evidencesFileLinkUsed])
								{
									$found=true;
									break;
								}
							}
						}
						
						if(!$found)	SqlLQ('DELETE FROM dr_criteria_status_evidence	WHERE criteria_status_evidence_id='.$evidence['criteria_status_evidence_id']);
					}
				}

				//
				// Check if any evidences have been added and insert them.
				//

				if(!empty($evidencesArray))
				{
					foreach($evidencesArray as $evidencesFileLinkUsed)
					{		
						if($POST[$evidencesFileLinkUsed]=='') continue;
						
						$found=false;
						
						if(!empty($evidencesQry))
						{
							foreach($evidencesQry as $evidence)
							{
								if($evidence['file_link']==$POST[$evidencesFileLinkUsed])
								{
									$found=true;
									break;
								}
							}
						}
						
						if(!$found) 
						{
							$linkAlreadyInDatabase=SqlQ('SELECT criteria_evidence_id FROM dr_criteria_evidence WHERE file_link="'.$POST[$evidencesFileLinkUsed].'"');

							if(!empty($linkAlreadyInDatabase)) SqlLQ('INSERT INTO dr_criteria_status_evidence (criteria_status, criteria_evidence) VALUES ('.$criteria['criteria_status_id'].','.$linkAlreadyInDatabase['criteria_evidence_id'].')');
							else
							{
								$checkFileLink=@fopen($POST[$evidencesFileLinkUsed],'r');
								if($checkFileLink) $checkedFileLinkData=stream_get_meta_data($checkFileLink);
								@fclose($checkFileLink);

								if(!empty($checkedFileLinkData['wrapper_data'][1])) $directFileInfo['download_content_length']=substr($checkedFileLinkData['wrapper_data'][1],16);
								else $directFileInfo['download_content_length'] = "-1";

								if(!empty($checkedFileLinkData['wrapper_data'][4])) 
								{
									$date = substr(substr($checkedFileLinkData['wrapper_data'][4],15),0,-4);
									$dateInfo = date_parse_from_format_for_php_5_2_9('D, d M Y H:i:s', $date);
									$directFileInfo['filetime']=$dateInfo['year'].'-'.$dateInfo['month'].'-'.$dateInfo['day'].' '.$dateInfo['hour'].':'.$dateInfo['minute'].':'.$dateInfo['second'];
								}
								else
								{
									$directFileInfo['filetime']="9999-12-31";
								}

							    $indirectFileInfo = pathinfo($POST[$evidencesFileLinkUsed]);

								SqlLQ('INSERT INTO dr_criteria_evidence (file_link, file_name, file_type, file_size, file_date_modified) VALUES ("'.$POST[$evidencesFileLinkUsed].'","'.$indirectFileInfo['filename'].'","'.$indirectFileInfo['extension'].'","'.$directFileInfo['download_content_length'].'","'.$directFileInfo['filetime'].'")');
								$lastEvidenceId=SqlQ('SELECT LAST_INSERT_ID()');
								SqlLQ('INSERT INTO dr_criteria_status_evidence (criteria_status, criteria_evidence) VALUES ('.$criteria['criteria_status_id'].','.$lastEvidenceId['LAST_INSERT_ID()'].') ');
							}
						}
					}
				}

				//
				// Add all entered names into the validation loop.
				// -------------------------------------------------------------------------------------------------------------------------------------------------------

				$validationArray=array();
				
				foreach ($POST as $arrayName=>$arrayValue)
				{
					$foundValidation=strpos($arrayName,"elephantTigerBeehiveinputID");
					if($foundValidation===0 && $arrayValue!='') array_push($validationArray,$arrayValue);
				}

				$chID=$criteria['criteria_status_id'];
					
				if(!$doneFirstCriteria || $submittingAcrossMultipuleCAs) SqlLQ('DELETE FROM dr_validation_loop_structure WHERE object="'.$SESSION['object']['criteria_status_id'].'" AND applicability="'.$chID.'"');

				if($POST['startValidationLoop'])
				{
					SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
							VALUES ("'.$SESSION['object']['criteria_status_id'].'","'.$chID.'","0",0)');

					if($POST['modifying']==1)
					{
						SqlLQ('UPDATE dr_validation_loop
								SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="modified"),
								action_taken_on=SYSDATE()
								WHERE object="'.$SESSION['object']['criteria_status_id'].'"
								AND applicability="'.$chID.'"
								AND validator=0
								AND action_taken=0');
					}
					else
					{				
						SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
								VALUES ("'.$SESSION['object']['criteria_status_id'].'","'.$chID.'","0",0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="originated"),SYSDATE())');
					}
				}
						
				
				$i=1;
					
				if(!empty($validationArray))
				{	
					foreach($validationArray as $validationUsed)
					{
						$nameSplit=explode(", ",$validationUsed);

						if(!$doneFirstCriteria || $submittingAcrossMultipuleCAs)
						{
							SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
									VALUES ("'.$SESSION['object']['criteria_status_id'].'","'.$chID.'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.')');
						}

						if($i==1)
						{
							if($POST['startValidationLoop'])
							{
								if($doneFirstCriteria)
								{
									$firstValidator=SqlQ('SELECT validator FROM dr_validation_loop_structure WHERE object='.$SESSION['object']['criteria_status_id'].' AND applicability='.$chID.' AND validation_loop_structure_step=1');

									if(!empty($firstValidator))
									{
										SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
												VALUES ("'.$SESSION['object']['criteria_status_id'].'","'.$chID.'","'.$firstValidator['validator'].'",'.$i.',SYSDATE())');

										$email=SqlQ('SELECT name, surname, email, allow_emails FROM c_user WHERE user_id='.$firstValidator['validator']);
										$fullName=$email['name'].' '.$email['surname'];
									}
								}
								else
								{
									SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
											VALUES ("'.$SESSION['object']['criteria_status_id'].'","'.$chID.'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.',SYSDATE())');
									
									$fullName=$nameSplit[1].' '.$nameSplit[0];
									$email=SqlQ('SELECT email, allow_emails FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"');
								}

								$evidenceInfo=SqlLi('SELECT DISTINCT rt.review_type, ca.ca, coe.coe, p.program, rch.criterion_user_id
														FROM dr_review_type AS rt
															INNER JOIN dr_review_profile			AS rp  ON rp.review_type=rt.review_type_id
															INNER JOIN dr_review					AS r   ON r.review_profile=rp.review_profile_id
															INNER JOIN dr_review_applicability		AS ra  ON ra.review=r.review_id
															INNER JOIN c_ca							AS ca  ON ca.ca_id=ra.ca
															INNER JOIN c_program					AS p   ON p.program_id=rp.program
															INNER JOIN c_coe						AS coe ON coe.coe_id=rp.coe
															INNER JOIN dr_review_group				AS rg  ON rg.review_type=rt.review_type_id
															INNER JOIN dr_review_criterion			AS rc  ON rc.review_group=rg.group_id
															INNER JOIN dr_review_criterion_history	AS rch ON rch.criterion=rc.review_criterion_id
															INNER JOIN dr_criteria_status			AS cs  ON cs.review_criteria=rc.review_criterion_id
														WHERE cs.review_criteria ='.$POST['review_criteria_id'].'
														AND   cs.ca='.$c.'
														AND   cs.msn='.$msn.'
														AND   rp.review_profile_id='.$POST['review_profile'].'
														AND   rch.criterion_valid_from <= r.validation_date');

								$caName=SqlQ('SELECT ca FROM c_ca WHERE ca_id='.$c);

								$headers="MIME-Version: 1.0\r\n";
								$headers.="Content-type: text/html; charset=utf-8\r\n";
								$headers.="From: Airbus No Reply <noreply@airbus.com>\r\n"; 
								$headers.="Reply-To: noreply@airbus.com\r\n"; 
								$headers.="Return-path: noreply@airbus.com\r\n";
								$headers.="Cc: \r\n";
								$headers.="Bcc: \r\n";

								$mailBody='
								<html>
								<head>
									<title>Evidence Validation</title>
								</head>
								<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
									<div style="width: 100%; height: 300px; cellSpacing=0; cellPadding=5; border=0;">
									<table align="center">
									  <tr>
										<td style="background-color:#6f95ab;color:#FFFFFF;font-family:Verdana,Arial,Helvetica,sans-serif;font-size:11px;font-weight:normal;padding-left:10px;">
											Evidence Validation
										</td>	
									</tr>
									<tr>
										<td style="border-width:0px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; padding-left:10px;">
											<strong>Dear '.$fullName.',</strong><br>
											<p>
											This is an automatic email to inform you a piece of evidence requires your validation.<br><br>
											This evidence is for <strong>'.$evidenceInfo[0]['program'].' - '.$evidenceInfo[0]['coe'].' - '.$evidenceInfo[0]['review_type'].' - '.$caName['ca'].' - Criteria '.$evidenceInfo[0]['criterion_user_id'].'</strong> 
											</p>
											Click the link below to login and validate the evidence:<br>
											<a href="http://art-int.eu.airbus.corp/1V55">
											http://art-int.eu.airbus.corp/1V55</a><br><br>
											Please, do not reply to this message.<br>
											<br><br><br>
											Best regards,<br><br>
											Design Reviews Team.
										</td>
									  </tr>
									</table>
								</div>
								</body>
								</html>';
								
								if($email['allow_emails']!=1) mail($email['email'],'Evidence Validation Required - Criteria '.$evidenceInfo[0]['criterion_user_id'].' - Airbus Review Tool',$mailBody,$headers);
							}
						}

						$i++;
					}
				}
				$onlyOneCriteriaInValidationLoop++;
			}
		}
	}
							
	$criteriaMlt=SqlAsLi('SELECT *
						FROM dr_criteria_status AS s
							INNER JOIN dr_review_criterion AS c ON s.review_criteria=c.review_criterion_id
						WHERE s.msn="'.$msn.'"
							AND s.ca IN('.implode(',',$caArr).')
							AND c.review_criterion_id="'.$POST['review_criteria_id'].'"','ca');

	if(is_array($criteriaMlt))
	{
		$firstItem=0;
		foreach($criteriaMlt as $criteriaCa=>$criteriaDetails){
			generateSaveResponse($answer,$firstItem,$SESSION['table']['review_planning']['criteria'],$POST,$criteriaDetails,'_'.$POST['review_criteria_id']);
		}
		$answer.='&&&bigCriteriaStatus%%%img%%%'.$POST['criteria_status'].'100.jpg&&&criteria_matrix_status_'.$POST['ca'].'_'.$POST['review_criteria_id'].'%%%img%%%'.$POST['criteria_status'].'20.jpg&&&';
		if(!$doneFirstCriteria) $answer.='criteria_planned_'.$POST['review_criteria_id'].'%%%date%%%'.$POST['criteriaPlanned'].'&&&'; //JFM 09_04_14
	}

	$onlyOneCriteriaInValidationLoop=0;
	$doneFirstCriteria=true;
}

//file_put_contents('../img/ca/data.txt', $answer); //JFM 31_10_14

echo 'OK|||'.$answer;
storeSession($SESSION);
?>