<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../../ldap.php'); //JFM 09_04_14

$POST=cleanArray($_POST);

$ldap_hostname = "ldap://acdslan-vip-i.res.airbus.corp:3890";
//$ldap_search_dn = "OU=Users,OU=1V55,OU=Apps,O=Airbus";
$ldap_search_dn = "OU=Persons,O=Airbus";

$userInfo=getfromldap($POST['login']);

if($userInfo['gn']=='')
{
	$ldap_hostname = "ldap://acdslan-vip-i.res.airbus.corp:3890";
//	$ldap_search_dn = "OU=Users,OU=1V55,OU=Apps,O=Airbus";
$ldap_search_dn = "OU=Persons,O=Airbus";

	$userInfo=getfromldap($POST['login']);
}

//$answer=$userInfo['gn'].'&&&'.$userInfo['sn'].'&&&'.$userInfo['mail'].'&&&'.str_replace('Subcontractor for ', '', $userInfo['department']); //JFM 19_07_16
//$answer=$userInfo['gn'].'&&&'.$userInfo['sn'].'&&&'.$userInfo['mail'].'&&&'.$userInfo['department']);
$answer=$userInfo['gn'].'&&&'.$userInfo['sn'].'&&&'.$userInfo['mail'].'&&&'.str_replace('Subcontractor for ', '', $userInfo['department']);

echo 'OK|||'.$answer;
storeSession($SESSION);
?>
