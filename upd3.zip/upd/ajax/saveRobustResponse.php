<?php
/*
* US#134 - New section inside the Design Review information, to manage robustness assessment.
* Version: V 4.7
* To save added questions for Robustness Assessment page
* Fixed by: Infosys Limited
*/ 

require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$POST=cleanArray($_POST);

if (isset($POST['question']) && !empty($POST['question'])) {
	SqlLQ('INSERT INTO dr_question_response(question_id,question_response,user_id) VALUES ("'.$POST['question'].'","'.$SESSION['user']['user_id'].'")');						
	}
echo 'OK|||';
?>
