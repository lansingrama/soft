<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');

$POST=cleanArray($_POST);

$columnIdArray=array();

$allCustomColumns=SqlSLi('SELECT column_ FROM dr_column_translation WHERE area = '.$POST['areaId'],'column_');
$currentDisabledStatuses=SqlLi('SELECT * FROM dr_allowed_status WHERE area = '.$POST['areaId']);

$currentDisabledStatusesFormatted=array();

if(!empty($currentDisabledStatuses))
{
	foreach ($currentDisabledStatuses as $uselessKey => $usefulValue) 
	{
		$currentDisabledStatusesFormatted[$usefulValue['object']][$usefulValue['status']] = $usefulValue['disabled'];
	}
}

$statuses=array('r','a','g','x');
$statusesObjects=array('r' => 0,'a' => 1,'g' => 2,'x' => 3);
$statusTypes=array('InitialReview', 'Review', 'Criteria', 'Action', 'RID', 'Risk');
$statusTypesObjects=array('InitialReview' => 'initial_review_status', 'Review' => 'review_status', 'Criteria' => 'criteria_status', 'Action' => 'action_status', 'RID' => 'rid_status', 'Risk' => 'risk_status');
$disabledEnabledArray=array('enabled' => 0, 'disabled' => 1);


foreach ($POST as $arrayName=>$arrayValue)
{
	$foundCustomName=strpos($arrayName,"areaCustomName");
	if($foundCustomName===0)
	{
		$foundCustomNameIdSplit=explode("_",$arrayName);
		array_push($columnIdArray,$foundCustomNameIdSplit[1]);
	}

	foreach ($statusTypes as $statusType) 
	{
		$foundCustomStatus=strpos($arrayName,"areaCustom".$statusType."Status");
		if($foundCustomStatus===0)
		{
			$foundCustomStatusSplit=explode("_",$arrayName);

			if(isset($currentDisabledStatusesFormatted[$SESSION['object'][$statusTypesObjects[$statusType]]][$statusesObjects[$foundCustomStatusSplit[1]]]))
			{
				SqlLQ('UPDATE dr_allowed_status SET disabled = '.$disabledEnabledArray[$arrayValue].' WHERE area = '.$POST['areaId'].' AND object = '.$SESSION['object'][$statusTypesObjects[$statusType]].' AND status = '.$statusesObjects[$foundCustomStatusSplit[1]]);
			}
			else
			{
				SqlLQ('INSERT INTO dr_allowed_status (area,object,status,disabled) VALUES ('.$POST['areaId'].','.$SESSION['object'][$statusTypesObjects[$statusType]].','.$statusesObjects[$foundCustomStatusSplit[1]].','.$disabledEnabledArray[$arrayValue].')');
			}
		}
	}

}

if(!empty($columnIdArray))
{
	foreach($columnIdArray as $columnId)
	{
		if(!in_array($columnId,$allCustomColumns))
		{
			SqlLQ('INSERT INTO dr_column_translation (column_,area,title,position) VALUES ('.$columnId.','.$POST['areaId'].',"'.$POST['areaCustomName_'.$columnId].'",'.$POST['areaCustomPosition_'.$columnId].')');
		}
		else
		{
			SqlLQ('UPDATE dr_column_translation SET title = "'.$POST['areaCustomName_'.$columnId].'", position = "'.$POST['areaCustomPosition_'.$columnId].'" WHERE column_ = '.$columnId.' AND area = '.$POST['areaId']);
		}
	}
}


echo 'OK|||';
storeSession($SESSION);
?>