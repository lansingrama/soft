<?php

//margin-right -100px for each step!
?><div class="timeline" id="timeline" style="margin-right:225px;"></div><?php

?><div style="position:absolute; top:0px; left:50%; margin-left:-225px; width:450px;z-index:999;"><?php
	?><img style="padding-right:50px;" src="../common/img/step_1_off.png"><?php
	?><img style="padding-right:50px;" src="../common/img/step_2_off.png"><?php
	?><img style="padding-right:50px;" src="../common/img/step_3_off.png"><?php
	?><img style="padding-right:50px;" src="../common/img/step_4_off.png"><?php
	?><img style="padding-right:00px;" src="../common/img/step_5_off.png"><?php
?></div><?php

?><div style="position:absolute; top:0px; left:50%; margin-left:-225px; width:450px;z-index:999;"><?php
	?><img class="wizardImage" id="wizard_step_0" style="padding-right:50px; display:none; opacity: 0;" src="../common/img/step_1_on.png"><?php
	?><img class="wizardImage" id="wizard_step_1" style="padding-right:50px; display:none; opacity: 0;" src="../common/img/step_2_on.png"><?php
	?><img class="wizardImage" id="wizard_step_2" style="padding-right:50px; display:none; opacity: 0;" src="../common/img/step_3_on.png"><?php
	?><img class="wizardImage" id="wizard_step_3" style="padding-right:50px; display:none; opacity: 0;" src="../common/img/step_4_on.png"><?php
	?><img class="wizardImage" id="wizard_step_4" style="padding-right:00px; display:none; opacity: 0;" src="../common/img/step_5_on.png"><?php
?></div><?php

//Box0
?><div class="box" id="box0" style="position:absolute; top:40%; left:50%; width:700px; margin-left:-350px; font-size:24px; text-align:center;"><?php 
	?>I would like to... <?php
	?><select class="wizardDropDownSelect" id="whatDo" name="whatDo" style="margin-right:30px;"><?php
		?><option value="nothing" disabled="disabled" selected="selected">Select a Value</option><?php
		?><option value="create">extract a...</option><?php
	?></select><?php

	?><select class="wizardDropDownSelect" id="doWhere" name="doWhere"><?php
		?><option value="nothing" disabled="disabled" selected="selected">Select a Value</option><?php
		?><option value="statistics">overview report.</option><?php
	?></select><?php
?></div><?php

?><form action="#" enctype="multipart/form-data" id="reportWizardForm" method="post" style="display:inline;"><?php

	//Box1
	?><div class="box" id="box1" style="position:absolute; top:15%; left:100%; width:960px; height:300px; margin-left:350px; font-size:24px; text-align:center; display:none; bottom:0; overflow:auto;"><?php 
		$programList=allowedSimpleObject('program','program',$SESSION,'c_','area='.getFilter('area','filter',0,$SESSION));
		$coeList=allowedSimpleObject('coe','coe',$SESSION,'c_','area='.getFilter('area','filter',0,$SESSION));
		$out='';
		foreach ($programList as $programId => $name) 
		{
			$out.=$programId.',';
		}

		?><div style="clear:both;padding-bottom:20px;">Hold down the Ctrl or Shift button to select multiple options.</div><?php

		?><div style="height:60%; display:inline; float:left; margin-right:50px; margin-top:20px;"><?php
			?><select id="program" name="program[]" style="height:100%; width:100%" multiple="multiple" onchange="reportWizardSelectChange('msn');"><?php
				foreach ($programList as $programId => $name) 
				{
					?><option value="<?=$programId?>"><?=$name?></option><?php
				}
			?></select><?php
			?><div style="clear:both;"><?php
				?><input class="stdBtn" type="button" onclick="selectAllFromSelectMultipule('program');" value="Select All"><?php
				?><input class="stdBtn" type="button" onclick="selectNoneFromSelectMultipule('program');" value="Select None"><?php
			?></div><?php
		?></div><?php

		?><div style="height:60%; display:inline; float:left; margin-right:50px; margin-top:20px;"><?php
			?><select id="coe" name="coe[]" style="height:100%; width:100%" multiple="multiple" onchange="reportWizardSelectChange('msn');"><?php
				foreach ($coeList as $coeId => $name) 
				{
					?><option value="<?=$coeId?>"><?=$name?></option><?php
				}
			?></select><?php
			?><div style="clear:both;"><?php
				?><input class="stdBtn" type="button" onclick="selectAllFromSelectMultipule('coe');" value="Select All"><?php
				?><input class="stdBtn" type="button" onclick="selectNoneFromSelectMultipule('coe');" value="Select None"><?php
			?></div><?php
		?></div><?php

		?><div style="height:60%; display:inline; float:left; margin-right:50px; margin-top:20px;"><?php
			?><select id="msn" name="msn[]" style="height:100%; width:100%" multiple="multiple" onchange="reportWizardSelectChange('perimeter');"><?php
				foreach ($msnList as $msnId => $name) 
				{
					?><option value="<?=$msnId?>"><?=$name?></option><?php
				}
			?></select><?php
			?><div style="clear:both;"><?php
				?><input class="stdBtn" type="button" onclick="selectAllFromSelectMultipule('msn');" value="Select All"><?php
				?><input class="stdBtn" type="button" onclick="selectNoneFromSelectMultipule('msn');" value="Select None"><?php
			?></div><?php
		?></div><?php

		?><div style="height:60%; display:inline; float:left; margin-right:50px; margin-top:20px;"><?php
			?><select id="perimeter" name="perimeter[]" style="height:100%; width:100%" multiple="multiple" onchange="reportWizardSelectChange('review');"><?php
				foreach ($perimeterList as $perimeterId => $name) 
				{
					?><option value="<?=$perimeterId?>"><?=$name?></option><?php
				}
			?></select><?php
			?><div style="clear:both;"><?php
				?><input class="stdBtn" type="button" onclick="selectAllFromSelectMultipule('perimeter');" value="Select All"><?php
				?><input class="stdBtn" type="button" onclick="selectNoneFromSelectMultipule('perimeter');" value="Select None"><?php
			?></div><?php
		?></div><?php

		?><div style="height:60%; display:inline; float:left; margin-right:50px; margin-top:20px;"><?php
			?><select id="review" name="review_type[]" style="height:100%; width:100%" multiple="multiple" onchange="reportWizardSelectChange('ca');"><?php
				foreach ($reviewList as $reviewId => $name) 
				{
					?><option value="<?=$reviewId?>"><?=$name?></option><?php
				}
			?></select><?php
			?><div style="clear:both;"><?php
				?><input class="stdBtn" type="button" onclick="selectAllFromSelectMultipule('review');" value="Select All"><?php
				?><input class="stdBtn" type="button" onclick="selectNoneFromSelectMultipule('review');" value="Select None"><?php
			?></div><?php
		?></div><?php

		?><div style="height:60%; display:inline; float:left; margin-right:50px; margin-top:20px;"><?php
			?><select id="ca" name="ca[]" style="height:100%; width:100%" multiple="multiple"><?php
				foreach ($caList as $groupKeys => $name) 
				{
					?><option value="<?=$groupKeys?>"><?=$name?></option><?php
				}
			?></select><?php
			?><div style="clear:both;"><?php
				?><input class="stdBtn" type="button" onclick="selectAllFromSelectMultipule('ca');" value="Select All"><?php
				?><input class="stdBtn" type="button" onclick="selectNoneFromSelectMultipule('ca');" value="Select None"><?php
			?></div><?php
		?></div><?php
		
	?></div><?php

	//Box2
	?><div class="box" id="box2" style="position:absolute; top:15%; left:100%; width:90%; margin-left:350px; font-size:24px; text-align:left; display:none; bottom:0;"><?php 
		?><div style="clear:both;padding-bottom:20px;">Hold down the Ctrl or Shift button to select multiple options.</div><?php
		?><div style="height:55%; display:inline; float:left; margin-right:50px; font-size:14px;"><?php
			?>Include Slides On:<?php
			?><select id="slides" name="slides" style="height:100%; width:100%" multiple="multiple"><?php
				?><option value="all">All</option><?php
				/*?><option value="review">Review Status</option><?php
				?><option value="criteria">Criteria Status</option><?php
				?><option value="action">Action Status</option><?php
				?><option value="plan">Project Timeline</option><?php
				?><option value="risk">Risk Status</option><?php
				?><option value="???">???</option><?php*/
			?></select><?php
			?><div style="clear:both;"><?php
				?><input class="stdBtn" type="button" onclick="selectAllFromSelectMultipule('slides');" value="Select All"><?php
				?><input class="stdBtn" type="button" onclick="selectNoneFromSelectMultipule('slides');" value="Select None"><?php
			?></div><?php
		?></div><?php
		?><div style="height:55%; display:inline; float:left; margin-right:50px; font-size:14px;"><?php
			?>In the format:<?php
			?><select id="type" name="type" style="height:100%; width:100%" multiple="multiple"><?php
				?><option value="powerpoint">Microsoft PowerPoint</option><?php
				/*?><option value="pdf">Adobe PDF</option><?php
				?><option value="csv">CSV</option><?php
				?><option value="???">???</option><?php*/
			?></select><?php
			?><div style="clear:both;"><?php
				?><input class="stdBtn" type="button" onclick="selectAllFromSelectMultipule('type');" value="Select All"><?php
				?><input class="stdBtn" type="button" onclick="selectNoneFromSelectMultipule('type');" value="Select None"><?php
			?></div><?php
		?></div><?php
		?><div style="height:55%; display:inline; float:left; margin-right:50px; font-size:14px;"><?php
			?>Between the following Review dates:<?php
			?><div style="font-size:10px"><?php
				?><ul><?php
					?><li>Review <?=$SESSION['table']['review_planning']['review']['review_date']['title']?> MUST be set for the review.</li><?php
					?><li>Review MUST be marked as complete.</li><?php
					?><li>Dates can be left blank.</li><?php
				?><ul><?php
			?><br /></div><?php
			?><table cellpadding="5" cellspacing="0"><?php
				?><tr><?php
					?><td>From:</td><?php
					?><td><?php
						drawDate('from','fromDateCal','',false,1);
					?></td><?php
				?></tr><?php
				?><tr><?php
					?><td>To:</td><?php
					?><td><?php
						drawDate('to','toDateCal','',false,1);
					?></td><?php
				?></tr><?php
			?></table><?php
		?></div><?php
	?></div><?php

?></form><?php

//Box3
?><div class="box" id="box3" style="position:absolute; top:15%; left:100%; width:700px; margin-left:350px; font-size:24px; text-align:center; display:none; height:300px; bottom:0; overflow:auto;"><?php 
	?>Box 3<?php
?></div><?php

//Box4
?><div class="box" id="box4" style="position:absolute; top:40%; left:100%; width:700px; margin-left:350px; font-size:24px; text-align:center; display:none;"><?php 
	?>Processing...<br /><br /><span style="font-size:12px;">This may take some time. Please wait.</span><?php
?></div><?php

//Box5
?><div class="box" id="box5" style="position:absolute; top:40%; left:100%; width:700px; margin-left:350px; font-size:24px; text-align:center; display:none;"><?php 
	?>Box 5<?php
?></div><?php

?><div id="buttonHolder" style="position:absolute; bottom:35px; left:50%; margin-left:-130px; width:260px;"><?php
	?><div onclick="reportWizardStepCalculate(0);" style="background-color:#6f95ab; width:120px; height:50px; text-align:center; color:#FFFFFF; font-size:16px; cursor:pointer; float:left;"><?php
		?><div id="backButton" style="margin-top:15px;">&#9668; Exit</div><?php
	?></div><?php

	?><div onclick="reportWizardStepCalculate(1);" style="background-color:#f47922; width:120px; height:50px; text-align:center; color:#FFFFFF; font-size:16px; cursor:pointer; float:right;"><?php
		?><div id="forwardButton" style="margin-top:15px;">Next &#9658;&#9658;</div><?php
	?></div><?php
?></div><?php

?><div class="wizardError" id="wizardError"><?php
	?><div id="wizardErrorDescription" style="text-align:center; font-size:16px; margin-top:5px;"><?php
		?>Problem<?php
	?></div><?php
?></div><?php

?>