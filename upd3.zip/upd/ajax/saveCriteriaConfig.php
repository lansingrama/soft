<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
foreach($_POST as $k=>&$v)$POST[$k]=addslashes(utf8_decode(str_replace(array('|||','&&&','%%%','###'),'_',str_replace('<amp>','&',$v))));

if($POST['review_criteria_id']==0){
	SqlLQ('UPDATE dr_review_group SET group_description="'.$POST['description'].'" WHERE review_group_id="'.$POST['review_group_id'].'"');
	$group=SqlQ('SELECT group_description FROM dr_review_group WHERE review_group_id="'.$POST['review_group_id'].'"');
	echo 'OK|||',$POST['review_group_id'],'&&&',$POST['review_criteria_id'],'&&&',$group['group_description'];
}else{
	SqlLQ('UPDATE dr_review_criteria SET criteria_description="'.$POST['description'].'",reference="'.$POST['reference'].'",criterion_showstopper="'.$POST['criterion_showstopper'].'" WHERE review_criteria_id="'.$POST['review_criteria_id'].'"');
	$criteria=SqlQ('SELECT criteria_description,reference,criterion_showstopper FROM dr_review_criteria WHERE review_criteria_id="'.$POST['review_criteria_id'].'"');
	echo 'OK|||',$POST['review_group_id'],'&&&',$POST['review_criteria_id'],'&&&',$criteria['criteria_description'],'&&&',$criteria['reference'],'&&&',$criteria['criterion_showstopper'];
}storeSession($SESSION);
?>