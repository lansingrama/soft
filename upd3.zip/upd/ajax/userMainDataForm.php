<?php

require_once('../support/header.php');

require_once('../security/checkExpiredSession.php');



$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];

			

$company=SqlAsArr('SELECT company_id,company FROM c_company','company_id','company');

$department=SqlAsArr('SELECT department_id,CONCAT(siglum,\' (\',description,\')\') AS department FROM c_department','department_id','department');



$generalInfo=SqlQ('SELECT user_id,login,name,surname,email,department,company,confirmed FROM c_user WHERE user_id=\''.$viewAsUserId.'\'');

foreach($generalInfo as $k=>&$v)$generalInfo[$k]=utf8_encode($v);

$confirmed=$generalInfo['confirmed'];



?><div class="elementInfo"onClick="validateUser();"onKeyUp="validateUser();"style="width:100%;"><?php

	?><div class="tableTitle"><?=($confirmed==0)?'Finish your account':'General Information'?>:</div><?php

	?><form action="#"enctype="multipart/form-data"id="userInfoFrm"method="post"style="display:inline;"><?php

		?><input id="permissionUserId"name="user"type="hidden"value="<?=$viewAsUserId?>"><?php

		?><input id="confirmed"name="confirmed"type="hidden"value="<?=$confirmed?>"><?php

		?><table class="criteriaTable"style="width:703px;"><?php

			?><tr class="tableGroup"><?php

				?><td style=" width:191px;">Personal</td><td style="width:483px;"></td><?php

			?></tr><?php

			drawStdField('Login','login',$generalInfo['login'],92);

			drawStdField('First Name','name',$generalInfo['name'],92);

			drawStdField('Second Name','surname',$generalInfo['surname'],92);

			drawStdField('Email','email',$generalInfo['email'],92);

			if(($generalInfo['user_id']==$viewAsUserId || $confirmed==0) && $generalInfo['name']!='New' && $generalInfo['name']!='User'){

				?><tr class="infoRow"><?php

					?><td class="paramDef">Password</td><?php

					?><td><?php

						?><input class="formInput"id="password"name="password"onMouseOver="setInputFocus(this);"size="42" type="password"><?php

					?></td><?php

				?></tr><?php

				?><tr class="infoRow"><?php

					?><td class="paramDef">Repeat Password</td><?php

					?><td><?php

						?><input class="formInput"id="rptPassword"name="rptPassword"onMouseOver="setInputFocus(this);"size="42"type="password"><?php

					?></td><?php

				?></tr><?php

			}

			?><tr class="tableGroup"><?php

				?><td>Position</td><td></td><?php

			?></tr><?php

			drawDdListBox('Department','department',$generalInfo['department'],$department,494,'','','',1);

			drawDdListBox('Company','company',$generalInfo['company'],$company,494,'','','',1);

			if($confirmed==0 && $generalInfo['name']!='New' && $generalInfo['name']!='User'){

				?><tr class="tableGroup"><?php

					?><td>Security</td><td></td><?php

				?></tr><?php

				?><tr class="infoRow"><?php

					?><td class="paramDef">Tracking</td><?php

					?><td><?php

						?><input id="allowTracking"name="allowTracking"type="checkbox"> I allow to track my actions for security reasons<?php

					?></td><?php

				?></tr><?php

			}

		?></table>

		<div class="save"><span class="saveResponse"id="user_saveResponse">Changes were applied</span><input class="stdBtn"<?php if($generalInfo['user_id']!=$viewAsUserId)echo'disabled'?> id="applyUserChanges"onClick="sendAjaxForm('userInfoFrm','<?php if($confirmed==0)echo'../'?>ajax/saveUserInfo.php','updateData','user_saveResponse');"type="button"value="Apply Changes"></div>

	</form>

</div><?php

?>