<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');


$GET=cleanArray($_GET); //JFM 25_11_13
//foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);

if(!empty($GET['object']) && $GET['object']!='All') //JFM 07_04_14
{
	$allValidationAssignedToUser=SqlLi('SELECT DISTINCT vl1.* 
											FROM dr_validation_loop AS vl1
											LEFT JOIN dr_criteria_status_provider AS csp 
														ON vl1.applicability=csp.criteria_status
													WHERE 
													(
														vl1.validator='.$SESSION['user']['user_id'].' 
														OR 
														(
															vl1.validator=0
															AND csp.provider='.$SESSION['user']['user_id'].'
														)
													)
											AND vl1.action_taken_on ="0000-00-00 00:00:00"
										 AND object='.$GET['object']);
										 
	$objectName=SqlLi('SELECT object 
						FROM c_object
						WHERE object_id='.$GET['object']);
										 
	if($objectName[0]['object']=='criterion_validity_id')
	{
		if(!empty($allValidationAssignedToUser))
		{
			foreach($allValidationAssignedToUser as $k=>$v)
			{
				//JFM 03_12_13
				$criterionID=SqlLi('SELECT rch.criterion, rch.criterion_user_id, rt.review_type
									FROM dr_review_criterion_history AS rch
										INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
										INNER JOIN dr_review_group AS rg ON rg.group_id=rc.review_group
										INNER JOIN dr_review_type AS rt ON rt.review_type_id=rg.review_type
									WHERE criterion_validity_id='.$v['applicability']);
									
				$allValidationAssignedToUser[$k]['criterionID']=$criterionID[0]['criterion'];
				$allValidationAssignedToUser[$k]['criterion_user_id']=$criterionID[0]['criterion_user_id'];
				$allValidationAssignedToUser[$k]['review_type']=$criterionID[0]['review_type'];
			}
		}
	}
}

if($included!=1)echo'OK|||';

if(!empty($allValidationAssignedToUser))
{
	function item5($item) { return $item['review_id']; }
	
	foreach($allValidationAssignedToUser as $k=>$v)
	{
		switch($v['object'])
		{
			case $SESSION['object']['criterion_validity_id']:
				?><div class="sideElement"id="validationElement_<?=$v['object']?>_<?=$v['applicability']?>"onClick="openSideElement('<?=$v['object']?>_<?=$v['applicability']?>','valid','empty&object=<?=$v['object']?>&applicability=<?=$v['applicability']?>&criterionID=<?=$v['criterionID']?>&criterion_user_id=<?=$v['criterion_user_id']?>&review_type=<?=$v['review_type']?>'); <?=($v['validation_loop_step']==0)?'getAllElementsOfFormAndStoreInString(\'criteriaForm\');':'disableAllFormElementsNeeded=1;'?>"><?=$v['criterion_user_id']?> for <?=$v['review_type']?></div><?php //JFM 14_10_13 - JFM 03_12_13
			break;
			
			case $SESSION['object']['review_id']:
				
				$reviewInfo=SqlLi('SELECT rt.review_type, ca.ca 
									FROM dr_review_type AS rt
										INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id
										INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
										INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
										INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
									WHERE review_id ='.$v['applicability']);

				$caString='';
				$caStringShort='';
				foreach($reviewInfo as $l=>$m) $caString=$caString.$m['ca'].',';
				$caString=rtrim($caString, ",");
				
				if(strlen($caString) > 25) $caStringShort = substr($caString,0,22).'...';
				else $caStringShort=$caString;
	
				?><div class="sideElement"id="validationElement_<?=$v['object']?>_<?=$v['applicability']?>"onClick="openSideElement('<?=$v['object']?>_<?=$v['applicability']?>','valid','empty&object=<?=$v['object']?>&applicability=<?=$v['applicability']?>&criterionID=<?=$v['applicability']?>');" <?php if(strlen($caString)>25){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($caString))?>');"<?php }?>><?=$reviewInfo[0]['review_type']?> for <?=$caStringShort?></div><?php //JFM 14_10_13
			break;
			case $SESSION['object']['criteria_status_id']: //JFM 09_04_14

				$reviewProfile=SqlLi('SELECT DISTINCT rp.review_profile_id, p.program, c.coe, m.msn, ca.ca, rt.review_type, r.review_id, rch.criterion_user_id
										FROM dr_review_profile AS rp
											INNER JOIN dr_review_group AS rg ON rg.review_type=rp.review_type
											INNER JOIN dr_review_criterion AS rc ON rc.review_group=rg.group_id
											INNER JOIN dr_review_criterion_history AS rch ON rch.criterion=rc.review_criterion_id
											INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
											INNER JOIN dr_criteria_status as cs ON cs.review_criteria=rc.review_criterion_id
											INNER JOIN dr_review_applicability AS ra ON ra.ca=cs.ca
																					AND ra.review=r.review_id
											INNER JOIN c_program AS p ON p.program_id=rp.program
											INNER JOIN c_coe AS c ON c.coe_id=rp.coe
											INNER JOIN c_msn AS m ON m.msn_id=r.msn
																AND cs.msn=r.msn
											INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
											INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
										WHERE cs.criteria_status_id='.$v['applicability']);

				$reviewIds=array_map('item5', $reviewProfile);

				$allCas=SqlSLi('SELECT ca.ca FROM dr_review_applicability AS ra INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca WHERE review IN ('.implode(',',$reviewIds).')','ca');

				$casAsString=implode(', ', $allCas);

				$caStringShort='';
				
				if(strlen($casAsString) > 25) $caStringShort = substr($casAsString,0,22).'...';
				else $caStringShort=$casAsString;

				?><div class="sideElement"id="validationElement_<?=$v['object']?>_<?=$v['applicability']?>"onClick="openSideElement('<?=$v['object']?>_<?=$v['applicability']?>','valid','empty&object=<?=$v['object']?>&applicability=<?=$v['applicability']?>&criterionID=<?=$v['applicability']?>');" <?php if(strlen($caString)>25){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($caString))?>');"<?php }?> ><?=$reviewProfile[0]['review_type']?> for <?=$reviewProfile[0]['criterion_user_id']?> in <?=$caStringShort?></div><?php
			break;

			case $SESSION['object']['action_id']: //JFM 30_10_14
				$actionInfo=SqlLi('SELECT DISTINCT act.action_code, rt.review_type, ca.ca
									FROM dr_action AS act
									INNER JOIN dr_action_applicability 	AS app ON app.action=act.action_id
									INNER JOIN c_ca 					AS ca  ON ca.ca_id=app.ca
									INNER JOIN dr_review_applicability 	AS rpp ON rpp.ca=ca.ca_id
									INNER JOIN dr_review 				AS r   ON r.review_id=rpp.review
									INNER JOIN dr_review_profile		AS rp  ON rp.review_profile_id=r.review_profile
									INNER JOIN dr_review_type 			AS rt  ON rt.review_type_id=rp.review_type
									WHERE act.action_id ='.$v['applicability']);

				?><div class="sideElement"id="validationElement_<?=$v['object']?>_<?=$v['applicability']?>"onClick="openSideElement('<?=$v['object']?>_<?=$v['applicability']?>','valid','empty&object=<?=$v['object']?>&applicability=<?=$v['applicability']?>&criterionID=<?=$v['applicability']?>');" <?php if(strlen($casAsString)>25){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($casAsString))?>');"<?php }?>>#<?=substr($actionInfo[0]['action_code'],-3)?> for <?=$actionInfo[0]['ca']?> <?=$actionInfo[0]['review_type']?></div><?php
			break;
		}
	}
}
else if($GET['object']=='All') //JFM 07_04_14
{
	$allThingsCurrentlyOngoing=SqlLi('SELECT DISTINCT vl1.object, vl1.applicability FROM dr_validation_loop AS vl1
											INNER JOIN dr_validation_loop AS vl2 
												ON vl1.object=vl2.object
												AND vl1.applicability=vl2.applicability
												AND vl2.action_taken=0
											LEFT JOIN dr_criteria_status_provider AS csp 
												ON vl1.applicability=csp.criteria_status
												AND vl1.object="'.$SESSION['object']['criteria_status_id'].'"
											WHERE 
											(
												vl1.validator='.$SESSION['user']['user_id'].' 
												OR 
												(
													vl1.validator=0
													AND csp.provider='.$SESSION['user']['user_id'].'
												)
											)
											AND vl1.validation_loop_step=0
											AND vl1.action_taken!=0');
	if(!empty($allThingsCurrentlyOngoing))
	{
		foreach($allThingsCurrentlyOngoing as $k=>$v)
		{
			switch($v['object'])
			{
				case $SESSION['object']['criterion_validity_id']:
					$criterionID=SqlLi('SELECT rch.criterion, rch.criterion_user_id, rt.review_type
											FROM dr_review_criterion_history AS rch
												INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
												INNER JOIN dr_review_group AS rg ON rg.group_id=rc.review_group
												INNER JOIN dr_review_type AS rt ON rt.review_type_id=rg.review_type
											WHERE criterion_validity_id='.$v['applicability']);

					?><div class="sideElement"id="validationElement_<?=$v['object']?>_<?=$v['applicability']?>"onClick="openSideElement('<?=$v['object']?>_<?=$v['applicability']?>','valid','empty&object=<?=$v['object']?>&applicability=<?=$v['applicability']?>&criterionID=<?=$criterionID[0]['criterion']?>&criterion_user_id=<?=$criterionID[0]['criterion_user_id']?>&review_type=<?=$criterionID[0]['review_type']?>&noDecision=1');disableAllFormElementsNeeded=1;" <?php if(strlen($caString)>25){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($caString))?>');"<?php }?>><i>CRITERIA: </i><?=$criterionID[0]['criterion_user_id']?> for <?=$criterionID[0]['review_type']?></div><?php //JFM 14_10_13
				break;

				case $SESSION['object']['review_id']:
					
					$reviewInfo=SqlLi('SELECT rt.review_type, ca.ca 
										FROM dr_review_type AS rt
											INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id
											INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
											INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
											INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
										WHERE review_id ='.$v['applicability']);

					$caString='';
					$caStringShort='';
					foreach($reviewInfo as $l=>$m) $caString=$caString.$m['ca'].',';
					$caString=rtrim($caString, ",");
					
					if(strlen($caString) > 25) $caStringShort = substr($caString,0,22).'...';
					else $caStringShort=$caString;
		
					?><div class="sideElement"id="validationElement_<?=$v['object']?>_<?=$v['applicability']?>"onClick="openSideElement('<?=$v['object']?>_<?=$v['applicability']?>','valid','empty&object=<?=$v['object']?>&applicability=<?=$v['applicability']?>&criterionID=<?=$v['applicability']?>&noDecision=1');" <?php if(strlen($caString)>25){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($caString))?>');"<?php }?>><i>REVIEW: </i><?=$reviewInfo[0]['review_type']?> for <?=$caStringShort?></div><?php //JFM 14_10_13
				break;

				case $SESSION['object']['criteria_status_id']: //JFM 09_04_14
					$reviewProfile=SqlLi('SELECT DISTINCT rp.review_profile_id, p.program, c.coe, m.msn, ca.ca, rt.review_type, r.review_id, rch.criterion_user_id
							FROM dr_review_profile AS rp
								INNER JOIN dr_review_group AS rg ON rg.review_type=rp.review_type
								INNER JOIN dr_review_criterion AS rc ON rc.review_group=rg.group_id
								INNER JOIN dr_review_criterion_history AS rch ON rch.criterion=rc.review_criterion_id
								INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
								INNER JOIN dr_criteria_status as cs ON cs.review_criteria=rc.review_criterion_id
								INNER JOIN dr_review_applicability AS ra ON ra.ca=cs.ca
																		AND ra.review=r.review_id
								INNER JOIN c_program AS p ON p.program_id=rp.program
								INNER JOIN c_coe AS c ON c.coe_id=rp.coe
								INNER JOIN c_msn AS m ON m.msn_id=r.msn
													AND cs.msn=r.msn
								INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
								INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
							WHERE cs.criteria_status_id='.$v['applicability']);

					$caString='';
					$caStringShort='';
					foreach($reviewProfile as $l=>$m) $caString=$caString.$m['ca'].',';
					$caString=rtrim($caString, ",");
					
					if(strlen($caString) > 25) $caStringShort = substr($caString,0,22).'...';
					else $caStringShort=$caString;

					?><div class="sideElement"id="validationElement_<?=$v['object']?>_<?=$v['applicability']?>"onClick="openSideElement('<?=$v['object']?>_<?=$v['applicability']?>','valid','empty&object=<?=$v['object']?>&applicability=<?=$v['applicability']?>&criterionID=<?=$v['applicability']?>&noDecision=1');" <?php if(strlen($caString)>25){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($caString))?>');"<?php }?> ><i>EVIDENCE: </i><?=$reviewProfile[0]['review_type']?> for <?=$reviewProfile[0]['criterion_user_id']?> IN <?=$caStringShort?></div><?php //JFM 14_10_13
				break;

				case $SESSION['object']['action_id']: //JFM 30_10_14
					$actionInfo=SqlLi('SELECT DISTINCT act.action_code, rt.review_type, ca.ca
										FROM dr_action AS act
										INNER JOIN dr_action_applicability 	AS app ON app.action=act.action_id
										INNER JOIN c_ca 					AS ca  ON ca.ca_id=app.ca
										INNER JOIN dr_review_applicability 	AS rpp ON rpp.ca=ca.ca_id
										INNER JOIN dr_review 				AS r   ON r.review_id=rpp.review
										INNER JOIN dr_review_profile		AS rp  ON rp.review_profile_id=r.review_profile
										INNER JOIN dr_review_type 			AS rt  ON rt.review_type_id=rp.review_type
										WHERE act.action_id ='.$v['applicability']);

					?><div class="sideElement"id="validationElement_<?=$v['object']?>_<?=$v['applicability']?>"onClick="openSideElement('<?=$v['object']?>_<?=$v['applicability']?>','valid','empty&object=<?=$v['object']?>&applicability=<?=$v['applicability']?>&criterionID=<?=$v['applicability']?>&noDecision=1');" <?php if(strlen($casAsString)>25){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($casAsString))?>');"<?php }?>><i>ACTION: </i>#<?=substr($actionInfo[0]['action_code'],-3)?> for <?=$actionInfo[0]['ca']?> <?=$actionInfo[0]['review_type']?></div><?php
				break;

			}
		}
	}
	else
	{
		?><center>No ongoing workflows.</center><?php
	}
}
else
{
	?><center>Nothing requires your validation.</center><?php
}

storeSession($SESSION);
?>