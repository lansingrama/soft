<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');
$GET=cleanArray($_GET);
//echo 'SELECT * FROM dr_review_freeze WHERE review = '.$GET['reviewId'].' AND ca_id = '.$GET['caId'];
if ($_GET['isfreeze'] == 'freeze') {
	$review = SqlLi('SELECT * FROM dr_review_freeze WHERE review = '.$GET['reviewId'].' AND ca_id = '.$GET['caId'].'');

	if (empty($review)) {
		SqlLQ('INSERT INTO dr_review_freeze (review, ca_id, user_id, is_freeze) VALUES ('.$GET['reviewId'].','.$GET['caId'].','.$GET['userId'].', 1)');
	}  	else {
		SqlLQ('UPDATE dr_review_freeze SET is_freeze = 1 WHERE review = '.$GET['reviewId'].' AND ca_id = '.$GET['caId'].'');
	}
} else if ($_GET['isfreeze'] == 'unfreeze') {
	SqlLQ('UPDATE dr_review_freeze SET is_freeze = 0 WHERE review = '.$GET['reviewId'].' AND ca_id = '.$GET['caId'].'');
} 

echo 'OK|||';
storeSession($SESSION);
?>
