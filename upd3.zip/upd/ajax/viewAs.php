<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

$ok=0;
if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 || 
	checkPermission('c_user_general','edit',0,'check',$SESSION)==1 || 
	($GET['user']=='' && $SESSION['user']['view_as']!='')
	)
	{
	if($GET['user']!='')
	{
		$userExists=SqlQ('SELECT user_id FROM c_user WHERE user_id="'.$GET['user'].'"');
	}
	if($GET['user']=='' || $userExists['user_id']!='')
	{
		$SESSION['user']['view_as']=$GET['user'];
		$ok=1;
	}
}
if($ok==1)
{
	echo 'OK|||1';
}
storeSession($SESSION);
?>