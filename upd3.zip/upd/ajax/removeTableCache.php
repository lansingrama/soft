<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');

$tableCacheId=$_GET['tableCacheId'];

if($tableCacheId=='all'){
	removeCache('all');
	unset($SESSION['table_result_count']);
}else{
	removeCache($tableCacheId);
	unset($SESSION['table_result_count'][$tableCacheId]);
}
if($included!=1)echo 'OK|||';
storeSession($SESSION);
?>