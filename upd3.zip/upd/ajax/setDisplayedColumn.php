<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
/**
 * Fix for: Bug-11
 * Get the check box id which are checked and send the values while click on apply changes
 * Version: 4.2
 * Fixed By: Infosys Limited
 */
$postValues = trim($_POST['location']);
$clickValues = trim($_POST['value']);
$element = trim($_POST['element']);
$modifieldField = array();

if ($element == 'review') {
    if ($postValues != "") {
        $postValuesArray = explode(",", $postValues);
        $clickValuesArray = explode(",", $clickValues);
        if ($postValuesArray) {
            foreach ($postValuesArray as $key => $value) {
                $location = split('-', $value);
                $modifieldField = $location[1] . '-' . $location[2] . '-' . $location[3];
                $val = $clickValuesArray[$key];
                applyChange(array_search($location[1], $SESSION['object']), array_search($location[2], $SESSION['user_action']), $location[3], $val, $SESSION, 1);
            }
            storeSession($SESSION);
        }
    }
    storeSession($SESSION);
    if ($GET['list_name'] != '') {
        $POST = array('list_name' => $GET['list_name'], 'removeTableCache' => $GET['removeTableCache']);
        include($GET['table_processor'] . '.php');
    } else {
        echo 'OK|||' . implode(",", $modifieldField);
    }
}

//End of bug 11
else {
    foreach ($_GET as $k => $v)
        $GET[$k] = addslashes($v);

    $location = split('-', $GET['location']);

    modifyFilter(array_search($location[1], $SESSION['object']), array_search($location[2], $SESSION['user_action']), $location[3], $GET['value'], $SESSION, 1);
    storeSession($SESSION);
    if ($GET['list_name'] != '') {
        $POST = array('list_name' => $GET['list_name'], 'removeTableCache' => $GET['removeTableCache']);
        include($GET['table_processor'] . '.php');
    } else {
        echo 'OK|||', $location[1], '-', $location[2], '-', $location[3];
    }
}
?>