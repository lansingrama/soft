<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');

$POST=cleanArray($_POST);
 /**
    US #19.1 - Change Workflow
	Bug fix for View/Edit responsible button should be enabled
    Fixed By - Infosys Limited
    Version - 4.3
*/
if(!empty($POST['reviewCa']) && !empty($POST['reviewProfile']) && $POST['reviewCa'] != "" && $POST['reviewProfile'] != "")
{
	if(!empty($POST['caInfoBox']) && $POST['caInfoBox'] != "")
{
	$everythingFromPrevious=SqlLi('SELECT * FROM dr_responsible WHERE review = '.$POST['caInfoBox']);
	if(!empty($everythingFromPrevious))
	{
		foreach ($everythingFromPrevious as $previous) 
		{
			SqlLQ('INSERT INTO responsible (review,ca, role, responsible, position) VALUES ('.$POST['reviewProfile'].','.$POST['reviewCa'].','.$previous['role'].',"'.$previous['responsible'].'", '.$previous['position'].')');
		}
	}

	$everythingFromPreviousAttendee=SqlLi('SELECT * FROM dr_responsible_attendee WHERE review = '.$POST['caInfoBox']);

	if(!empty($everythingFromPreviousAttendee))
	{			
		foreach($everythingFromPreviousAttendee as $attendee)
		{
			SqlLQ('INSERT INTO attendee (responsible_attendee, review,ca) VALUES ("'.$$attendee['responsible_attendee'].'",'.$POST['reviewProfile'].','.$POST['reviewCa'].')');
		}
	}

}
else 
{
	$roleArray=array();
	$responsibleArray=array();
				
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundrole=strpos($arrayName,"roleinputID");
		if($foundrole===0) array_push($roleArray,$arrayValue);
		$foundresponsible=strpos($arrayName,"responsibleinputID");
		if($foundresponsible===0) array_push($responsibleArray,$arrayValue);
	}

	$allRoles=SqlLi('SELECT * FROM dr_responsible_role');

	SqlLQ('DELETE FROM responsible WHERE review="'.$POST['reviewProfile'].'"');

	for ($i=0; $i < count($responsibleArray); $i++) 
	{ 
		$nameSplit=explode(", ",$responsibleArray[$i]);
		$fullName=$nameSplit[1].' '.$nameSplit[0];
		$fullName=trim($fullName);

		$foundRole=false;
		$foundRoleId;
		
		foreach ($allRoles as $roleAlreadyInDatabase) 
		{
			if($roleAlreadyInDatabase['responsible_role']==$roleArray[$i])
			{
				$foundRole=true;
				$foundRoleId=$roleAlreadyInDatabase['responsible_role_id'];
				break;
			}
		}

		if($foundRole) SqlLQ('INSERT INTO responsible (review,ca, role, responsible, position) VALUES ('.$POST['reviewProfile'].','.$POST['reviewCa'].', '.$foundRoleId.',"'.$fullName.'", '.($i+1).')');
	}

}
	//
	// Add all attendees.
	// -------------------------------------------------------------------------------------------------------------------------------------------------------

	$attendeeArray=array();

	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundAttendee=strpos($arrayName,"elephantTigerBeehiveinputID");
		if($foundAttendee===0 && $arrayValue!='') array_push($attendeeArray,$arrayValue);
	}
		
	SqlLQ('DELETE FROM attendee WHERE review='.$POST['reviewId']);

	if(!empty($attendeeArray))
	{			
		foreach($attendeeArray as $attendee)
		{
			SqlLQ('INSERT INTO attendee (responsible_attendee, review,ca) VALUES ("'.$attendee.'",'.$POST['reviewProfile'].','.$POST['reviewCa'].')');				
		}
	}
}

/// End of US #19.1

//JFM 19_07_16
else
{ 
if(!empty($POST['caInfoBox']) && $POST['caInfoBox'] != "")
{
	$everythingFromPrevious=SqlLi('SELECT * FROM dr_responsible WHERE review = '.$POST['caInfoBox']);
	if(!empty($everythingFromPrevious))
	{
		foreach ($everythingFromPrevious as $previous) 
		{
			SqlLQ('INSERT INTO dr_responsible (review, role, responsible, position) VALUES ('.$POST['reviewId'].', '.$previous['role'].',"'.$previous['responsible'].'", '.$previous['position'].')');
		}
	}

	$everythingFromPreviousAttendee=SqlLi('SELECT * FROM dr_responsible_attendee WHERE review = '.$POST['caInfoBox']);

	if(!empty($everythingFromPreviousAttendee))
	{			
		foreach($everythingFromPreviousAttendee as $attendee)
		{
			SqlLQ('INSERT INTO dr_responsible_attendee (responsible_attendee, review) VALUES ("'.$attendee['responsible_attendee'].'",'.$POST['reviewId'].')');				
		}
	}

}
else
{
	$roleArray=array();
	$responsibleArray=array();
				
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundrole=strpos($arrayName,"roleinputID");
		if($foundrole===0) array_push($roleArray,$arrayValue);
		$foundresponsible=strpos($arrayName,"responsibleinputID");
		if($foundresponsible===0) array_push($responsibleArray,$arrayValue);
	}

	$allRoles=SqlLi('SELECT * FROM dr_responsible_role');

	SqlLQ('DELETE FROM dr_responsible WHERE review="'.$POST['reviewId'].'"');

	for ($i=0; $i < count($responsibleArray); $i++) 
	{ 
		$nameSplit=explode(", ",$responsibleArray[$i]);
		$fullName=$nameSplit[1].' '.$nameSplit[0];
		$fullName=trim($fullName);

		$foundRole=false;
		$foundRoleId;
		
		foreach ($allRoles as $roleAlreadyInDatabase) 
		{
			if($roleAlreadyInDatabase['responsible_role']==$roleArray[$i])
			{
				$foundRole=true;
				$foundRoleId=$roleAlreadyInDatabase['responsible_role_id'];
				break;
			}
		}

		if($foundRole) SqlLQ('INSERT INTO dr_responsible (review, role, responsible, position) VALUES ('.$POST['reviewId'].', '.$foundRoleId.',"'.$fullName.'", '.($i+1).')');
		else
		{
			SqlLQ('INSERT INTO dr_responsible_role (responsible_role) VALUES ("'.$roleArray[$i].'")');
			$lastInsertId=SqlQ('SELECT LAST_INSERT_ID()');
			SqlLQ('INSERT INTO dr_responsible (review, role, responsible, position) VALUES ('.$POST['reviewId'].', '.$lastInsertId['LAST_INSERT_ID()'].',"'.$fullName.'", '.($i+1).')');
		}
	}

	//
	// Add all attendees.
	// -------------------------------------------------------------------------------------------------------------------------------------------------------

	$attendeeArray=array();

	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundAttendee=strpos($arrayName,"elephantTigerBeehiveinputID");
		if($foundAttendee===0 && $arrayValue!='') array_push($attendeeArray,$arrayValue);
	}
		
	SqlLQ('DELETE FROM dr_responsible_attendee WHERE review='.$POST['reviewId']);

	if(!empty($attendeeArray))
	{			
		foreach($attendeeArray as $attendee)
		{
			SqlLQ('INSERT INTO dr_responsible_attendee (responsible_attendee, review) VALUES ("'.$attendee.'",'.$POST['reviewId'].')');				
		}
	}
}
}
echo 'OK|||'.$answer;
storeSession($SESSION);
?>