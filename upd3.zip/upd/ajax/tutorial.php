<?php echo 'OK|||';
?><div class="tutorialUnclickable" id="tutorialUnclickable"></div><?php 
?><div class="tutorial_1" id="tutorial_1"></div><?php 
?><div class="tutorial_2" id="tutorial_2"></div><?php 
?><div class="tutorial_3" id="tutorial_3"></div><?php 
?><div id="tutorialMsgBoxHolder"><?php 
	?><div class="tutorialMsgBox_1" id="tutorialMsgBox_1"><?php
		?><div style="font-size:20px; text-align:center;"><br />Welcome to the Airbus Review Tool!<hr style="color:#565C6A" size="1" /></div><?php
		?><br />As this is the first time you have logged in or you have not logged in for over a month, you can take this quick tutorial so you know how to get around.<?php
		?><br /><br />To start - please click next.<?php
		?><br /><br />To skip this tutorial - click skip. (not recommended)<?php
		?><div style="text-align:center;"><br /><input class="stdBtn"onClick="runTutorial(1);"type="button"value="Skip &#9658;&#9658;"> <input class="stdBtn"onClick="runTutorial(2);"type="button"value="Next &#9658;"></div><?php
	?></div><?php
	?><div class="tutorialMsgBox_2" id="tutorialMsgBox_2"><?php
		?><div style="font-size:18px;">Sidebar<hr style="color:#565C6A" size="1" /></div><?php
		?><br />The left hand sidebar is your way of navigating through ART.<?php
		?><br /><br />Selecting an option in this list will expand the next level and so on until you reach the last level.<?php
		?><br /><br />It works similarly to the Windows 7 Explorer sidebar.<?php
		?><br /><br />This sidebar usually has 4 levels; <i>Area > Programme > CoE > MSN</i>. However this can vary depending on the area.<?php
		?><div style="text-align:center;"><br /><input class="stdBtn"onClick="runTutorial(3);"type="button"value="Next &#9658;"></div><?php
	?></div><?php 
	?><div class="tutorialMsgBox_3" id="tutorialMsgBox_3"><?php
		?><div style="font-size:18px;">Main Content<hr style="color:#565C6A" size="1" /></div><?php
		?><br />When you reach the last level of the sidebar, the main content panel will fill with information about what you have selected.<?php
		?><div style="text-align:center;"><br /><input class="stdBtn"onClick="runTutorial(4);"type="button"value="Next &#9658;"></div><?php
	?></div><?php 
	?><div class="tutorialMsgBox_4" id="tutorialMsgBox_4"><?php
		?><div style="font-size:18px;">Tabs<hr style="color:#565C6A" size="1" /></div><?php
		?><br />You can change the view of the information displayed in the main content panel by selecting different tabs:<?php
		?><br /><ul style="padding:0px; margin:10px;"><?php
			?><li>My Tasks<?php
				?><ul><?php
					?><li>Displays a number of items relating to tasks you own.</li><?php
					?><li>This includes actions, RIDs, upcoming reviews and so on.</li><?php
					?><li>It also displays a personal KPI pie chart of all of your action involvement.</li><?php
				?></ul><?php
			?></li><?php
			?><li>Main Table<?php
				?><ul><?php
					?><li>Displays a detailed list of all the review information you may need.</li><?php
					?><li>You can search through this information by using the search bar above.</li><?php
					?><li>It is possible to hide columns in the main table by going to <i>Personal Configuration</i> > <i>Configure Columns</i>.</li><?php
				?></ul><?php
			?></li><?php
			?><li>Dashboard<?php
				?><ul><?php
					?><li>Displays graphical information about the Actions and RIDs which have been raised.</li><?php
					?><li>These graphs can be customised by selecting the check boxes in the table at the bottom of the window.</li><?php
				?></ul><?php
			?></li><?php
			?><li>Schedule<?php
				?><ul><?php
					?><li>Displays a time-line of the reviews which have been done and those which are upcoming.</li><?php
					?><li>This time-line can be customised by selecting the check boxes in the table at the bottom of the window.</li><?php
				?></ul><?php
			?></li><?php
		?></ul><?php
		?><div style="text-align:center;"><br /><input class="stdBtn"onClick="runTutorial(5);"type="button"value="Next &#9658;"></div><?php
	?></div><?php 
	?><div class="tutorialMsgBox_5" id="tutorialMsgBox_5"><?php
		?><div style="font-size:18px;">Menu bar<hr style="color:#565C6A" size="1" /></div><?php
		?><br />The menu bar is static on every page of ART and provides a number of features when you hover your mouse over each icon:<?php
		?><br /><ul style="padding-left:10px; margin:15px;"><?php
			?><li style="list-style-image: url('../common/img/xvalidOff.png');"><?php
				?>Validation<?php
				?><ul><?php
					?><li style="list-style-image: url('');">Displays the validation menu which is used to validate new criteria, reviews and evidences.</li><?php
					?><li style="list-style-image: url('');">A number will be displayed below this icon if something requires your validation.</li><?php			
				?></ul><?php
			?></li><?php
			?><li style="list-style-image: url('../common/img/xadmin.png');"><?php
				?>Administration<?php
				?><ul><?php
					?><li style="list-style-image: url('');">Shows various options for administrators of ART such as adding new users, programs, work packages etc.</li><?php
				?></ul><?php
			?></li><?php
			?><li style="list-style-image: url('../common/img/xtools.png');"><?php
				?>Tools<?php
				?><ul><?php
					?><li style="list-style-image: url('');">Displays a list of useful options for all users such as Action & RID lists, CSV exporting and Review Report generation.</li><?php
				?></ul><?php
			?></li><?php
			?><li style="list-style-image: url('../common/img/xuserMan.png');"><?php
				?>Personal Configuration<?php
				?><ul><?php
					?><li style="list-style-image: url('');">Allows you to manage your account and customise the interface of ART to your personal needs.</li><?php
				?></ul><?php
			?></li><?php
			?><li style="list-style-image: url('../common/img/xhelp.png');"><?php
				?>Help, FAQs & About<?php
				?><ul><?php
					?><li style="list-style-image: url('');">If you need more information about an item in ART; the Help, FAQs & About section has user guides, video tutorials and a list of frequently asked questions which can help you out.</li><?php
				?></ul><?php
			?></li><?php
			?><li style="list-style-image: url('../common/img/xexit.png');"><?php
				?>Logout<?php
				?><ul><?php
					?><li style="list-style-image: url('');">Logs you out of ART and returns you to the login page.</li><?php
				?></ul><?php
			?></li><?php
		?></ul><?php
		?><div style="text-align:center;"><br /><input class="stdBtn"onClick="runTutorial(6);"type="button"value="Next &#9658;"></div><?php
	?></div><?php
	?><div class="tutorialMsgBox_6" id="tutorialMsgBox_6"><?php
		?><div style="font-size:20px; text-align:center;"><br />Finally...<hr style="color:#565C6A" size="1" /></div><?php
		?><br />Thank you for taking the time to go through this tutorial.<?php
		?><br /><br />If you require anymore information please check out the Help, FAQs & About section by clicking the question mark (?) icon on the menu bar.<?php
		?><br /><br />We are constantly trying to improve ART; so if you have any comments, improvement ideas or bugs to report please submit them by going to <i>Administration</i> > <i>Bugs / Improvements</i>.<?php
		?><br /><br />You can re-run this introductory tutorial at any time by going to <i>Help, FAQs & About</i> > <i>Re-Run Tutorial</i>.<?php
		?><div style="text-align:center;"><br /><input class="stdBtn"onClick="runTutorial(7);"type="button"value="Finish &#9658;&#9658;"></div><?php
	?></div><?php 
?></div>