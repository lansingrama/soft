<?php //JFM 31_10_14 - Code taken and heavily modified from https://github.com/panique/php-long-polling - server.php

set_time_limit(0);

$dataSource='../img/ca/data.txt';

while(true) 
{
    $lastCall=isset($_GET['timestamp'])?(int)$_GET['timestamp']:null;

    clearstatcache();

    $lastDataSourceChange=filemtime($dataSource);

    if ($lastCall==null || $lastDataSourceChange>$lastCall) 
    {
        $data=file_get_contents($dataSource);
        $result=array('fileString' => $data, 'fileTimeStamp' => $lastDataSourceChange);
        $json=json_encode($result);
        echo $json;
        break;

    } 
    else 
    {
        sleep(1);
        continue;
    }
}
