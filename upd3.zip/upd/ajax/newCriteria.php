<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);

//JFM TODO - CRIT
function newCriteriaElement($target,$position,$groupId,$criteriaId){
	if($criteriaId==0 && $target=='criteria'){
		if($position=='down'){
			$positionQry=SqlQ('SELECT criteria_position FROM dr_review_criteria WHERE review_group="'.$groupId.'" ORDER BY criteria_position DESC LIMIT 1');
			$elementPosition=$positionQry['criteria_position']+1;
		}else $elementPosition=1;
	}else{
		if($target=='group'){
			$addQry=',review_profile';
		}
		$positionQry=SqlQ('SELECT '.$target.'_position'.$addQry.' FROM dr_review_'.$target.' WHERE review_'.$target.'_id="'.${$target.Id}.'"');
		$elementPosition=($position=='up')?$positionQry[$target.'_position']:$positionQry[$target.'_position']+1;
	}
	
	if($target=='criteria'){
		$addPosQry=' review_group='.$groupId;
	}else{
		$addPosQry=' review_profile='.$positionQry['review_profile'];
	}
	
	SqlLQ('UPDATE dr_review_'.$target.' SET '.$target.'_position='.$target.'_position+1 WHERE '.$target.'_position>="'.$elementPosition.'" AND '.$addPosQry);
	
	if($target=='group'){
		SqlLQ('INSERT INTO dr_review_group (review_profile,group_description,group_position)VALUES("'.$positionQry['review_profile'].'","New Group","'.$elementPosition.'")');
		$groupId=SqlQ('SELECT LAST_INSERT_ID() AS group_id');
		return $groupId['group_id'];
	}else{
		SqlLQ('INSERT INTO dr_review_criteria (review_group,criteria_description,criteria_position)VALUES("'.$groupId.'","New Criteria","'.$elementPosition.'")');
	}
}

$newGroupId=newCriteriaElement($GET['target'],$GET['position'],$GET['review_group_id'],$GET['review_criteria_id']);
if($GET['target']=='group'){
	newCriteriaElement('criteria','up',$newGroupId,0);
}

$reviewId=SqlQ('SELECT review_profile FROM dr_review_group WHERE review_group_id="'.$GET['review_group_id'].'"');
$GET['review']=$reviewId['review_profile'];

$reviewPositionRepaired=1;

include('criteriaList.php');
storeSession($SESSION);
?>