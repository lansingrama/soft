<?php
/*
#012-Action Tracking
Generate Email functionality
Fixed By - Infosys Limited
Version: V 4.4
*/
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');
require_once('../support/mail.php');

$POST=cleanArray($_POST);
$status=array('Open','In progress','Closed','Fully Closed');
$userId = $SESSION['user']['user_id'];
$areaId = getFilter('area','filter',0,$SESSION);
$pId = getFilter('program','filter',0,$SESSION);
$coeId = getFilter('coe','filter',0,$SESSION);
$msnId = getFilter('msn','filter',0,$SESSION);
if (!empty($userId)) {
	$email=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$userId);
}
if (!empty($POST['actionId'])) {
	$action = SqlQ('SELECT action_code,criteria,action_description,action_remark,action_creation,action_completion,action_status
				FROM dr_action WHERE action_id='.$POST['actionId'].''); 
}
if (!empty($action['criteria'])) {
	$criteria = SqlQ('SELECT criterion_name, criterion_description FROM dr_review_criterion_history WHERE criterion = '.$action['criteria'].'');
}

if (!empty($areaId)) {
	$area = SqlQ('SELECT area FROM c_area WHERE area_id = '.$areaId.'');
}
if (!empty($pId)) {
	$program = SqlQ('SELECT program FROM c_program WHERE program_id = '.$pId.'');
}
if (!empty($coeId)) {
	$coe = SqlQ('SELECT coe FROM c_coe WHERE coe_id = '.$coeId.'');
}
if (!empty($msnId)) {
	$msn = SqlQ('SELECT msn FROM c_msn WHERE msn_id = '.$msnId.'');
}

if (!empty($POST['caId']) && $msnId) {
	$caMlt=SqlQ('SELECT c.ca_id,c.ca,c.ca_description,
					p.perimeter_id,p.perimeter,
					w.wp_id,w.wp,w.wp_description FROM c_ca AS c
					INNER JOIN	c_perimeter 	AS p 	ON c.perimeter=p.perimeter_id
					INNER JOIN	c_cawp 			AS cw	ON c.ca_id=cw.ca
					INNER JOIN	c_wp 			AS w 	ON cw.wp=w.wp_id
					WHERE c.ca_id IN ('.$POST['caId'].')
					AND cw.msn='.$msnId.'');

}
				
if (empty($POST['holderEmail'])) $POST['holderEmail'] = "N/A";
	$holder  = "Holder Email: ".$POST['holderEmail']."<br>";
 
if (!empty($POST['validatorEmail'])) $POST['validatorEmail'] = "N/A";
	$validator = 'Validator Email: '.$POST['validatorEmail']."<br>";

if (empty($action['action_description'])) $action['action_description'] = "N/A";
	$ades = 'Description: '.$action['action_description']."<br>";

if (empty($action['action_remark'])) $action['action_remark'] = "N/A";
	$arem = 'Remark: '.$action['action_remark']."<br>";

if (empty($action['action_creation'])) $action['action_creation'] = "N/A";
	$acre = 'Creation Date: '.$action['action_creation']."<br>";

if (empty($action['action_completion'])) $action['action_completion'] = "N/A";
	$acpm = 'Completion Date: '.$action['action_completion']."<br>";

$astatus = 'Status: '.$status[$action['action_status']]."<br>";
		
if (empty($criteria['criterion_name'])) $criteria['criterion_name'] = "N/A";
	$cname = "Criteria Name: ".$criteria['criterion_name']."<br>";

if (empty($criteria['criterion_description'])) $criteria['criterion_description'] = "N/A";
	$cdesc = "Criteria Description: ".$criteria['criterion_description']."<br>";

						
if (empty($area['area'])) $area['area'] = "N/A";
	$area = "Area: ".$area['area']."<br>";

if (empty($program['program'])) $program['program'] = "N/A";
	$l1 = "Level1: ".$program['program']."<br>";

if (empty($coe['coe'])) $coe['coe'] = "N/A";
	$l2 = "Level2: ".$coe['coe']."<br>";

if (empty($msn['msn'])) $msn['msn'] = "N/A";
	$l3 = "Level3: ".$msn['msn']."<br>";

if (empty($caMlt['perimeter'])) $caMlt['perimeter'] = "N/A";
	$sup = "Supplier: ".$caMlt['perimeter']."<br>";

if (empty($caMlt['wp'])) $caMlt['wp'] = "N/A";
	$group = "Group: ".$caMlt['wp']."<br>";

if (empty($caMlt['wp_description'])) $msn['wp_description'] = "N/A";
	$gdes = "Group Description: ".$msn['wp_description']."<br>";

if (empty($caMlt['ca'])) $caMlt['ca'] = "N/A";
	$prod = "Product: ".$caMlt['ca']."<br>";

if (empty($caMlt['ca_description'])) $caMlt['ca_description'] = "N/A";
	$pdes = "Product Description: ".$caMlt['ca_description']."<br>";

						
$headers="MIME-Version: 1.0\r";
$headers.="Content-type: text/html; charset=utf-8\r";
$headers.="From: Airbus No Reply <noreply@airbus.com>\r"; 
$headers.="Reply-To: noreply@airbus.com\r"; 
$headers.="Return-path: noreply@airbus.com\r";
$headers.="Cc: \r";
$headers.="Bcc: \r";
$mailBody='
					<html>
					<head>
						<title>Action Validation</title>
					</head>
					<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
						<div style="width: 100%; height: 300px; cellSpacing=0; cellPadding=5; border=0;">
						<table align="center">
						<tr>
							<td style="border-width:0px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; padding-left:10px;">
								<strong>Dear '.$email['name'].' '.$email['surname'].',</strong><br>
								<p>Action Details<br><br>
								 '.$holder.'
								 '.$validator.'
								 '.$ades.'
								 '.$arem.'
								 '.$acre.'
								 '.$acpm.'
								 '.$astatus.'
								 <br><br>Criteria Details<br><br>
								 '.$cname.'
								 '.$cdesc.'<br>
								 '.$area.'
								 '.$l1.'
								 '.$l2.'
								 '.$l3.'
								 '.$sup.'
								 '.$group.'
								 '.$gdes.'
								 '.$prod.'
								 '.$pdes.'
								</p>
								
								<br><br><br>
								Best regards,<br><br>
								'.$email['name'].' '.$email['surname'].'<br>
								'.$email['email'].'
							</td>
						  </tr>
						</table>
					</div>
					</body>
					</html>';
$subject = 'Action '.$action['action_code'];
if($email['allow_emails']!=1) mail($email['email'],$subject,$mailBody,$headers);										
echo 'OK|||';
storeSession($SESSION);
?>