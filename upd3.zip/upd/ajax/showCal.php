<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
?>OK|||<table id="calTable"cellpadding="0"cellspacing="0"style="display:none;"><?php
	?><tr class="tl"><?php
		?><td width="30"align="left"><span id="Link_Prev_Year"class="calendarHeader"style="cursor:pointer">|<</span></td><?php
		?><td width="30"align="left"><span id="Link_Prev_Month"class="calendarHeader"style="cursor:pointer"><</span></td><?php
		?><td id="Main_Date"align="center"nowrap></td><?php
		?><td width="30"align="right"><span id="Link_Next_Month"class="calendarHeader"style="cursor:pointer">></span></td><?php
		?><td width="30"align="right"><span id="Link_Next_Year"class="calendarHeader"style="cursor:pointer">>|&nbsp;&nbsp;</span></td><?php
		/*?><td style="margin:5px auto auto 5px;"><img alt="Close this Calendar"onClick="closeCalendar()"src="../common/img/x.png"style="cursor:pointer;"></td><?php*/
		?><td onClick="closeCalendar();" style="border-left:#FFFFFF 1px solid;"><span class="calendarHeader">X&nbsp;&nbsp;</span></td><?php
	?></tr><?php
	?><tr><?php
		?><td class="borderUserEntry" colspan="6"><?php
			?><table><?php
				?><tr><td width="25"align="center">M</td><td width="25"align="center">T</td><td width="25"align="center">W</td><td width="25"align="center">T</td><td width="25"align="center">F</td><td width="25"align="center">S</td><td width="25"align="center">S</td><td width="25" align="center" style="border-left:1px solid #999999;">CW</td></tr><?php
				for($i=0;$i<6;$i++)
				{
					?><tr><?php
						for($j=1;$j<9;$j++)
						{
							if($j>5)
							{
								if($j > 7)
								{
									?><td id="<?='CW',(($i*7)+$j)?>" align="center" style="border-left:1px solid #999999; color:#999999;">&nbsp;</td><?php
								}
								else
								{
									?><td id="<?='D',(($i*7)+$j)?>"align="center"style="color:#999999;">&nbsp;</td><?php
								}
							}
							else
							{
								?><td align="center"><div class="miniLinkThin"id="<?='D',(($i*7)+$j)?>">&nbsp;</div></td><?php
							}
						}
					?></tr><?php
				}
			?></table><?php
		?></td><?php
	?></tr><?php
?></table><?php

storeSession($SESSION);
?>