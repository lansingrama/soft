<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST); //JFM 25_11_13

if(!empty($POST['forceEditValidationLoopPersonRadio']))
{
	switch ($POST['forceEditValidationLoopPersonRadio']) 
	{
		case 'edit':
			if(!empty($POST['elephantTigerBeehiveinputID0']))
			{
				$alreadyInLoop=false;
				$nameSplit=explode(", ",$POST['elephantTigerBeehiveinputID0']);

				$newUserId=SqlLi('SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"');
				$currentStructureLoop=SqlLi('SELECT DISTINCT validator FROM dr_validation_loop_structure WHERE applicability='.$POST['applicability'].' AND object='.$POST['object']);

				if(!empty($currentStructureLoop))
				{
					foreach ($currentStructureLoop as $validator) 
					{
						if($validator['validator']==$newUserId[0]['user_id'])
						{
							$alreadyInLoop=true;
							break;
						}
					}
				}

				if(!$alreadyInLoop)
				{
					SqlLQ('UPDATE dr_validation_loop_structure SET validator=(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'") WHERE validation_loop_structure_id='.$POST['validation_loop_structure_id']);
					SqlLQ('UPDATE dr_validation_loop SET validator=(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'") WHERE applicability='.$POST['applicability'].' AND object='.$POST['object'].' AND validator='.$POST['validator'].' AND action_taken=0');
				}
			}
		break;
		case 'remove':
			//Not yet implemented
		break;
		case 'add':
			if(!empty($POST['elephantTigerBeehiveinputID0']))
			{
				$alreadyInLoop=false;
				$nameSplit=explode(", ",$POST['elephantTigerBeehiveinputID0']);

				$newUserId=SqlLi('SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"');
				$currentStructureLoop=SqlLi('SELECT DISTINCT validator FROM dr_validation_loop_structure WHERE applicability='.$POST['applicability'].' AND object='.$POST['object']);

				if(!empty($currentStructureLoop))
				{
					foreach ($currentStructureLoop as $validator) 
					{
						if($validator['validator']==$newUserId[0]['user_id'])
						{
							$alreadyInLoop=true;
							break;
						}
					}
				}

				if(!$alreadyInLoop)
				{
					$maxValidationLoopStructureStep=SqlLi('SELECT validation_loop_structure_step FROM dr_validation_loop_structure WHERE applicability='.$POST['applicability'].' AND object='.$POST['object'].' ORDER BY validation_loop_structure_id DESC LIMIT 1');
					$step=$maxValidationLoopStructureStep[0]['validation_loop_structure_step']+1;
				
					SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
									VALUES ("'.$POST['object'].'","'.$POST['applicability'].'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$step.')');
				}
			}
		break;
	}
}

echo 'OK|||';
storeSession($SESSION);
?>