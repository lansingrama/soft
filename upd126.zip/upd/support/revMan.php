<?php
function checkActiveFilter(&$filterActive,$table,$applicability,&$SESSION,$prefix,$includeColumnName=1,$optional=''){
	if(is_array($table)){
		foreach($table as $columnName=>$columnDetails){
			switch($columnDetails['type']){
				case 'action':
					checkSpecificFilter($filterActive,'action',$columnName,'show_with_actions',$applicability,$SESSION,$prefix,$includeColumnName);
				break;
				case 'date':
					checkSpecificFilter($filterActive,'date',$columnName,'show_only_empty',$applicability,$SESSION,$prefix,$includeColumnName);
					checkSpecificFilter($filterActive,'date',$columnName,'show_after',$applicability,$SESSION,$prefix,$includeColumnName);
					checkSpecificFilter($filterActive,'date',$columnName,'show_before',$applicability,$SESSION,$prefix,$includeColumnName);
					checkSpecificFilter($filterActive,'date',$columnName,'show_only_not_done',$applicability,$SESSION,$prefix,$includeColumnName); //JFM 19_07_16
				break;
				case 'status':
					$statusColumn=columnFilterName($applicability,$prefix,$includeColumnName,$table[$columnDetails['linked_date']]['done']);
					checkSpecificFilter($filterActive,'status',$columnName,'hide_no_status',$applicability,$SESSION,$prefix,$includeColumnName,$statusColumn);
					checkSpecificFilter($filterActive,'status',$columnName,'hide_red',$applicability,$SESSION,$prefix,$includeColumnName,$statusColumn);
					checkSpecificFilter($filterActive,'status',$columnName,'hide_amber',$applicability,$SESSION,$prefix,$includeColumnName,$statusColumn);
					checkSpecificFilter($filterActive,'status',$columnName,'hide_green',$applicability,$SESSION,$prefix,$includeColumnName,$statusColumn);
					checkSpecificFilter($filterActive,'status',$columnName,'hide_blue',$applicability,$SESSION,$prefix,$includeColumnName,$statusColumn); //JFM 27_03_14
				break;
				case 'link':
				case 'text':
					checkSpecificFilter($filterActive,'text',$columnName,'filter',$applicability,$SESSION,$prefix,$includeColumnName); //JFM 13_02_14 - JFM 11_03_14
				break;
				case 'user':
					checkSpecificFilter($filterActive,'user',$columnName,'filter',$applicability,$SESSION,$prefix,$includeColumnName);
				break;
				case 'boolean': //JFM 16_09_13
					if(!empty($table[$columnName]['extras'])) //JFM 16_09_13
					{
						foreach($table[$columnName]['extras'] as $z)
						{
							checkSpecificFilter($filterActive,'boolean',$columnName,'hide_yes',$z,$SESSION,$prefix,$includeColumnName,$z);
							checkSpecificFilter($filterActive,'boolean',$columnName,'hide_no',$z,$SESSION,$prefix,$includeColumnName,$z);
						}
					}
					else
					{
						checkSpecificFilter($filterActive,'boolean',$columnName,'hide_yes',$applicability,$SESSION,$prefix,$includeColumnName);
						checkSpecificFilter($filterActive,'boolean',$columnName,'hide_no',$applicability,$SESSION,$prefix,$includeColumnName);
					}
				break;
				case 'trend': //JFM 08_06_16
					checkSpecificFilter($filterActive,'trend',$columnName,'hide_trend_0',$applicability,$SESSION,$prefix,$includeColumnName);
					checkSpecificFilter($filterActive,'trend',$columnName,'hide_trend_1',$applicability,$SESSION,$prefix,$includeColumnName);
					checkSpecificFilter($filterActive,'trend',$columnName,'hide_trend_2',$applicability,$SESSION,$prefix,$includeColumnName);
					checkSpecificFilter($filterActive,'trend',$columnName,'hide_trend_3',$applicability,$SESSION,$prefix,$includeColumnName);
					checkSpecificFilter($filterActive,'trend',$columnName,'hide_trend_4',$applicability,$SESSION,$prefix,$includeColumnName);
					checkSpecificFilter($filterActive,'trend',$columnName,'hide_trend_5',$applicability,$SESSION,$prefix,$includeColumnName);
				break;
			}
		}
	}
}

function checkApplicabilityNeeded(&$tableStructure) //JFM 16_09_13
{
	foreach($tableStructure as $columnName=>$columnDetails)
	{
		if($columnDetails['applicability_needed']==1)
		{
			$qry=SqlSLi('SELECT '.$columnName.' FROM '.$columnDetails['table'],$columnName);
			$tableStructure[$columnName]['extras']=$qry;
		}
	}
}


function checkSpecificFilter(&$filterActive,$fType,$columnName,$action,&$applicability,&$SESSION,$prefix='',$includeColumnName=1,$optional=''){
	$filter=getFilter($columnName,$action,$applicability,$SESSION);
	// Siglum & Supplier Search added by Infosys
	$fieldName=columnFilterName($applicability,$prefix,$includeColumnName,$columnName);
	if (($fieldName == 'siglum' || $fieldName == 'supplier') && ($filter == 'n/a' || $filter == 'N/A')) {
		$fieldName=columnFilterName($applicability,$prefix,$includeColumnName,$columnName);
		$value=($fType=='date' && $action!='show_only_empty')?convertToDate($filter):$filter;
		$filterActive[]=array('type'=>$fType,'field'=>$fieldName,'action'=>$action,'value'=>$value,'optional'=>$optional);
		//print_r($filterActive);
	} 
	// End for Siglum & Supplier Search added by Infosys
        
	if($filter!=''){ //JFM 13_02_14 - JFM 11_03_14
		$fieldName=columnFilterName($applicability,$prefix,$includeColumnName,$columnName);
		$value=($fType=='date' && $action!='show_only_empty')?convertToDate($filter):$filter;
		$filterActive[]=array('type'=>$fType,'field'=>$fieldName,'action'=>$action,'value'=>$value,'optional'=>$optional);
		//print_r($filterActive);
	}
}
function columnFilterName($applicability,$prefix,$includeColumnName,$columnName){
	$fieldNameItem=array();
	if($prefix!=''){
		$fieldNameItem[]=$prefix;
	}
	if($applicability!=0){
		$fieldNameItem[]=$applicability;
	}
	if($includeColumnName==1){
		$fieldNameItem[]=$columnName;
	}
	return implode('_',$fieldNameItem);
}
function drawFilterIcon($table,$tableSection,$object,$applicability,$SESSION,$tableCacheId='',$colSpan='',$sfTxt=''){
	$filterType=($tableSection=='responsible')?'text':$SESSION['table'][$table][$tableSection][$object]['type'];
	$filterExists=0;
	switch($filterType){
		case 'action':
			$fltImg=(getFilter($object,'show_with_actions',$applicability,$SESSION)==1)?'On':'Off';
			$filterExists=1;
		break;
		case 'date':
			$fltImg=(
				getFilter($object,'show_only_not_done',$applicability,$SESSION)==1 || //JFM 19_07_16
				getFilter($object,'show_only_empty',$applicability,$SESSION)==1 ||
				getFilter($object,'show_after',$applicability,$SESSION)!='' ||
				getFilter($object,'show_before',$applicability,$SESSION)!='')?'On':'Off';
			$filterExists=1;
		break;
		case 'status':
			$fltImg=(
				getFilter($object,'hide_no_status',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_red',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_amber',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_green',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_blue',$applicability,$SESSION)==1)?'On':'Off';
			$filterExists=1;
		break;
		case 'link':
		case 'text':
		case 'user':
			$fltImg=(getFilter($object,'filter',$applicability,$SESSION)!='')?'On':'Off';
			$filterExists=1;
		break;
		case 'criteria':
			$fltImg='Off';
			$filterExists=1;
		break;
		case 'boolean': //JFM 16_09_13
			$fltImg=(
				getFilter($object,'hide_yes',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_no',$applicability,$SESSION)==1)?'On':'Off';
			$filterExists=1;
		break;
		case 'trend': //JFM 08_06_16
			$fltImg=(
				getFilter($object,'hide_trend_0',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_trend_1',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_trend_2',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_trend_3',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_trend_4',$applicability,$SESSION)==1 ||
				getFilter($object,'hide_trend_5',$applicability,$SESSION)==1)?'On':'Off';
			$filterExists=1;
		break;
		/**
		*Fix for : US#033.1 Bulk user upload (Suggested by ICT)
		* Added for Toggle All button in User Management Screen
		* Version: 4.3
        * Fixed By: Infosys Limited
		*/
		case 'checkbox':
		$filterExists=14;
		break;  
	}
	
	if($filterExists==1)
	{
		$srt=getFilter($object,'sort',$applicability,$SESSION);
		if($srt=='')$srtImg='Off';
		elseif($srt=='ASC')$srtImg='Up';
		elseif($srt=='DESC')$srtImg='Down';
		
		$specificFilterId=$applicability.'-'.$object;
	}

	?><td class="flt"<?php if($colSpan!=''){?>colspan="<?=$colSpan?>"<?php }?>nowrap><?php //JFM 03_06_14
		if($filterExists==1){
                        /**
                         * Fix for: Improvement-6
                         * Define Master review checklist (toggle include all criteria)
                         * Version: 4.2
                         * Fixed By: Infosys Limited
                         */ 
                        if($object == "criterion_included" && $SESSION['list_cat']['reviewID'] == 'M')
                        {                            
                            ?><div><input class="stdBtnNew" id="criterion_included_<?=$SESSION['list_cat']['review_profile']?>" name="Include" onclick="toggleIncluded('<?=$SESSION['list_cat']['review_profile']?>','<?=$SESSION['list_cat']['groupID']?>','M','toggle')" type="button" value="Toggle all ►" /></div><?php
                        } 
			?><img onClick="showColumnFilter('<?=$table?>','<?=$tableSection?>','<?=$object?>','<?=$applicability?>',this,'<?=$tableCacheId?>','<?=$sfTxt?>','<?=$extras?>');"src="../common/img/fil<?=$fltImg?>.png"style="cursor:pointer;"> <?php
			?><img onClick="showColumnFilter('<?=$table?>','<?=$tableSection?>','<?=$object?>','<?=$applicability?>',this,'<?=$tableCacheId?>','<?=$sfTxt?>','<?=$extras?>');"src="../common/img/srt<?=$srtImg?>.png"style="cursor:pointer;"> &nbsp;&nbsp;<?php                        
            ?><div class="filterMenu"id="sf-<?=$specificFilterId?>"></div>&nbsp;<?php
		}
		/**
		*Fix for : US#033.1 Bulk user upload (Suggested by ICT)
		* Defining Toggle All button in User Management Screen
		* Version: 4.3
        * Fixed By: Infosys Limited
		*/
        else if ($filterExists == 14) {
            ?><input class="stdBtnNew" id="toggleAll" name="toggleAll" onclick="checkAll(this)" type="button" value="Toggle all ►"><?php
        }
	?></td><?php
}
function drawReviewElement($v,$caId,$columnName,$columnDetails,$appl,$i,$SESSION,$today,$status,$criteriaStructure=''){
	//JFM 15_09_15 switch($columnName)
	//JFM 15_09_15 {
		/* JFM 15_09_15
		case'ca':
			?><td class="actRow"height="19"><?php
				if($v['element_disabled']==1){?><span class="d"><?=$v['ca']?></span><?php }
				else echo $v['ca'];
			?><div class="eDiv"id="e<?=$i?>"></div></td><?php
		break;*/

		//JFM 15_09_15 default:
			if($columnName=='dr_responsible_configuration_general')
			{
				$columnKey=$columnName.'_'.$appl;
				$columnId=$columnName.'_'.$caId.'_'.$appl;
			}
			else if($appl==0)
			{
				$columnKey=$columnName;
				$columnId=$columnName.'_'.$caId;
			}
			else
			{
				$columnKey='review_'.$appl.'_'.$columnName;
				$columnId=$columnName.'_'.$caId.'_'.$appl;
			}

			switch($columnName)
			{
				case 'link':
					//JFM 13_05_16
					?><td align="left"nowrap><?php
						if(is_array($v[$columnKey]))
						{
							$i=1;
							foreach ($v[$columnKey] as $linkKey => $linkValue) 
							{
								?><a href="<?=$linkValue['link']?>" id="link_<?=$caId?>_<?=$appl?>" onMouseOut="nd();" onMouseOver="overlib('<b>Click to access to <?=$linkValue['name']?>:</b> <?=str_replace('\\','/',$linkValue['link'])?>');" style="visibility:<?=($linkValue['link'] && $v[$columnKey]!='0000-00-00')?'visible':'hidden'?>;"target="_blank"><?=$i?></a> <?php
								$i++;
							}
						}
					?></td><?php
				break;
	
				case 'ca':
				case 'wp':
				case 'ca_description':
				case 'wp_description':
				case 'perimeter':
				$getTdClass=explode('_',$columnId);
				
				
				
				if(sizeof($getTdClass) > 2 && $getTdClass[0] == ca){
					$getTdClass[0] = "ca2";
					}
				
				if(sizeof($getTdClass) > 2 && $getTdClass[0] == wp){
					$getTdClass[0] = "wp2";
					}
		
					?>
					<td id="<?=$columnId?>" class="<?=$getTdClass[0]?>" style="<?=($v['element_disabled']==1)?'color:#e7e7e8;':''?>text-align:left; padding-left: 5px; padding-right: 5px; font-weight:normal;">
					<?php 
						if($v['element_disabled']==1) 
							echo "<strike>";
						echo $v[$columnKey];
						if($v['element_disabled']==1)
							echo "</strike>";
					?></td><?php
                                        
				break;

				default:
					if($columnDetails['type']=='trend')
					{
						?> <td  class="fix" onClick="openForm('../ajax/ca','element=<?=$caId?>',false,'GET');" style="cursor:pointer;" id="<?=$columnId?>" <?php 
					}
					else
					{
						?> <td  id="<?=$columnId?>" <?php 
					}

						if($columnDetails['no_wrap']==1 || $columnDetails['type']=='date')echo' nowrap';

						else if($columnDetails['type']=='action')
						{
							if($v['element_disabled']==0)
							{
								switch($columnName)
								{
									case'review_red_action':
									case'review_amber_action':
									case'review_green_action':
									case'review_blue_action': //JFM 27_03_14
										$statusStyle=array('review_red_action'=>'r','review_amber_action'=>'a','review_green_action'=>'g','review_blue_action'=>'x'); //JFM 27_03_14
										$statusId=array('review_red_action'=>0,'review_amber_action'=>1,'review_green_action'=>2,'review_blue_action'=>3); //JFM 27_03_14
										?> class="reviewAction <?=$statusStyle[$columnName]?>"onClick="openList(this,'list_name=action&ca=<?=$caId?>&review_profile=<?=$appl?>&action_status=<?=$statusId[$columnName]?>');"<?php
									break;
									case'review_red_rid':
									case'review_amber_rid':
									case'review_green_rid':
									case'review_blue_rid':  //JFM 27_03_14
										$statusStyle=array('review_red_rid'=>'r','review_amber_rid'=>'a','review_green_rid'=>'g','review_blue_rid'=>'x'); //JFM 27_03_14
										$statusId=array('review_red_rid'=>0,'review_amber_rid'=>1,'review_green_rid'=>2,'review_blue_rid'=>3); //JFM 27_03_14
										?> class="reviewAction <?=$statusStyle[$columnName]?>"onClick="openList(this,'list_name=rid&ca=<?=$caId?>&review_profile=<?=$appl?>&rid_status=<?=$statusId[$columnName]?>');"<?php
									break;
									//JFM 08_06_16
									case'risk_red':
									case'risk_amber':
									case'risk_green':
									case'risk_blue':
										$statusStyle=array('risk_red'=>'r','risk_amber'=>'a','risk_green'=>'g','risk_blue'=>'x');
										$statusId=array('risk_red'=>0,'risk_amber'=>1,'risk_green'=>2,'risk_blue'=>3);
										?> class="fix reviewAction <?=$statusStyle[$columnName]?>"onClick="openList(this,'list_name=risk&ca=<?=$caId?>&risk_status=<?=$statusId[$columnName]?>');"<?php
									break;
								}
							}
						}
					?>><?php
						switch($columnDetails['type'])
						{
							case'boolean':
								drawBooleanValue($v[$columnKey]);
							break;

							case'drop_down':
								if($v[$columnKey]=="Click to Expand")
								{
									//print_r($v);
									if(!$v['group_id'])
									{
										?><span class="dropDown" onClick="openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$v['review_profile_id']?>&reviewTypeName=<?=$POST['reviewTypeName']?>&reviewID=<?=$v['review_id']?>&expand=<?=$v['criterion_group']?>');">Click to Expand</span><?php
									}
									else
									{
										?><span class="dropDown" onClick="openSideElement('<?=$v['group_id']?>','cat','empty&list_name=cat&review_profile=<?=$v['review_profile_id']?>&reviewTypeName=<?=$POST['reviewTypeName']?>&groupID=<?=$v['group_id']?>&reviewID=<?=$v['review_id']?>&expand=<?=$v['criterion_group']?>');">Click to Expand</span><?php
									}
								}

								else if($v[$columnKey]=="Click to Contract")
								{
									if(!$v['group_id'])
									{
										?><span class="dropDown" onClick="openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$v['review_profile_id']?>&reviewTypeName=<?=$POST['reviewTypeName']?>&reviewID=<?=$v['review_id']?>');">Click to Contract</span><?php
									}
									else
									{
										?><span class="dropDown" onClick="openSideElement('<?=$v['group_id']?>','cat','empty&list_name=cat&review_profile=<?=$v['review_profile_id']?>&reviewTypeName=<?=$POST['reviewTypeName']?>&groupID=<?=$v['group_id']?>&reviewID=<?=$v['review_id']?>');">Click to Contract</span><?php
									}
								}

								else
								{
									echo $v[$columnKey];
								}
							break;

							case'history':
								if(is_array($v[$columnKey])){
									?><div class="historyWrap"><?php
										foreach($v[$columnKey] as $historyElement){
											?><div><?php
												?><span class="logLink"onClick="sendEmailUser('<?=$historyElement['user_id']?>');"><?=$historyElement['user']?></span> on <?=$historyElement['date']?>:<br><br><?=$historyElement['text']?><?php
											?></div><?php
										}
									?></div><?php
								}
							break;

							case'count':
								if($v[$columnKey]==''){
									echo 'N/A';
								}else{
									switch($columnName){
										case'change_screenshot':
											?><span class="screenshot"onClick="openForm('screenshot','change_id=<?=$caId?>',false,'GET');"onMouseOut="nd();"onMouseOver="overlib('Click to open a window with all the screenshots.');"><?php
										break;
										default:
											?><span><?php
										break;
									}
									$cellTitle=($v[$columnKey]>1)?$columnDetails['title']:substr($columnDetails['title'],0,-1);
									echo $v[$columnKey].' '.$cellTitle;
									?></span><?php
								}
							break;

							case'status':
								?><img height="20"id="<?=$columnId?>"src="../common/img/<?php
								if($v['element_disabled']==1){
									?>na<?php
								}elseif((isset($v['review_'.$appl.'_review_done']) && $v['review_'.$appl.'_review_done']=='0' && isset($v['review_'.$appl.'_delta_done']) && $v['review_'.$appl.'_delta_done']=='0') || $v[$columnKey]==''){ //JFM 12_01_16
									?>b<?php
								}else{
									echo $status[$v[$columnKey]];
								}
								?>20.png"width="20"<?php
								if(!empty($v['criteria_status_id_'.substr($columnKey, 16)]))
								{
									?>onClick="openForm('workflow','applicability=<?=$v['criteria_status_id_'.substr($columnKey, 16)]?>&object=<?=$SESSION['object']['criteria_status_id']?>',false,'GET');" style="cursor:pointer"<?php
								}
								else if($columnName=='review_status') //JFM 28_10_15
								{
									?>onClick="openReviewForm('<?=$appl?>','ca');openSideElement('<?=$v['ca_id']?>','rev');" style="cursor:pointer"<?php									
								}
								?>><?php
								/**
* Fix for : US#106 Improvement: Freeze Function for completed DR 
* Added for freeze/unfreeze function
* Version: 4.3
* Fixed By: Infosys Limited
*/	
								if (!empty($appl) && !empty($v['ca_id'])) 
								{
									$review_freeze = SqlLi('SELECT * FROM dr_review_freeze WHERE review = '.$appl.' AND ca_id = '.$v['ca_id'].'');
									if($review_freeze[0]['is_freeze'] == 1 && $columnName=='review_status'){
									?><span class="freeze" title="Frozen review" style="color: red;font-size: 11px;">&#x25cf;</span><?php
									} 
								}
// End for 	US#106 Improvement: Freeze Function for completed DR 					
							break;
							break;

							case'trend':
								if($v[$columnKey]!=0)
								{
									?><img height="20" id="<?=$columnId?>" src="../common/img/t20<?=$v[$columnKey]?>.png"><?php
								}
							break;

							case'user':
								if($v[$columnName.'_txt']!='')
								{
									if($v[$columnName.'_txt_email']!='') //JFM 02_10_14
									{
										?><span style="cursor:pointer;" onclick="showOOUI('<?=$v[$columnName.'_txt_email']?>');" onmouseout="hideOOUI();"><?=$v[$columnName.'_txt']?></span><?php
									}
									else echo $v[$columnName.'_txt'];
								}
								else{?><span class="r_name"><?=$v[$columnDetails['txt_format']]?></span><?php } //JFM 19_07_16
							break;

							case 'date': //JFM 13_05_16
								switch($v[$columnKey])
								{
									case'0000-00-00':break;
									case'0':break;
									default:
										if($columnDetails['done']!='')
										{
											$doneField=($appl==0)?$columnDetails['done']:'review_'.$appl.'_'.$columnDetails['done'];
											?><span<?php
												if($v[$doneField]==0 && $v[$columnKey]<$today && $v['element_disabled']==0)
												{
													?> class="rb"<?php
												}
												if(getFilter('dates_cw','filter',0,$SESSION)==1)
												{
													echo '>'.date("y\C\WW", strtotime($v[$columnKey]));
												}
												else
													echo '>'.$v[$columnKey];
											?></span><?php
										}
										else if(getFilter('dates_cw','filter',0,$SESSION)==1)
										{
											echo date("y\C\WW", strtotime($v[$columnKey]));
										}
										else
											echo $v[$columnKey];
									break;
								}
							break;

							default:
								switch($v[$columnKey])
								{
									case'0000-00-00':break;
									case'0':break;
									case'0000-00-00 00:00:00': //JFM 02_09_13
										?> <center>&infin;</center> <?php
									break;
									default:
									//echo implode(',',$v),'<br /><br />'.$columnKey;
									//print_r($columnDetails);
										if($columnDetails['title']=='Remarks') //JFM 04_03_14
										{
											$replaceString=array('\r','\n','\r\n',chr(10),chr(13));
											$v[$columnKey]=str_replace($replaceString,'<br>',str_replace('','"',$v[$columnKey]));
											?><span <?php if($v[$columnKey]){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($v[$columnKey]))?>', ABOVE);"<?php }?>style="cursor:pointer;"><?php if($v[$columnKey]){ ?><center>&raquo;</center><?php } ?></span><?php
										}
										else if($columnDetails['title']=='Link' || $columnDetails['title']=='Provider' || $columnDetails['title']=='Validated By' || $columnDetails['title']=='Validated Date') //JFM 28_04_14
										{
											if(!empty($v[$columnKey]))
											{
												$links=explode(',', $v[$columnKey]);
												?><ul style="list-style-type: none; text-align:left; margin:0px; padding:10px;"><?php
													$i=1;
													foreach ($links as $link) 
													{
														?><li><?php
															if($columnDetails['title']=='Link')
															{
																?><a href="<?=$link?>" target="_blank">Evidence <?=$i?></a><?php
																$i++;
															}
															else if($columnDetails['title']=='Provider') //02_10_14
															{
																$userId=array_search(trim($link), $SESSION['user_list']);
																?><span style="cursor:pointer;" onclick="showOOUI('<?=$SESSION['user_email'][$userId]?>');" onmouseout="hideOOUI();"><?=$link?></span><?php
															}
															else echo $link;
														?></li><?php
													}
												?></ul><?php
											}
										}
										else
										{
											if($v['element_disabled']==1)
											{
												?><span style="color:#e7e7e8;"><?php
											}

											if($columnDetails['done']!='')
											{
												$doneField=($appl==0)?$columnDetails['done']:'review_'.$appl.'_'.$columnDetails['done'];
												?><span<?php
													if($v[$doneField]==0 && $v[$columnKey]<$today && $v['element_disabled']==0)
													{
														?> class="rb"<?php
													}
												?>><?=$v[$columnKey]?></span><?php
											}
											else if($columnDetails['additional_info']!='')
											{
												?><span onMouseOut="nd();"onMouseOver="overlib('<?=str_replace('\'','\\\'',$v[$columnDetails['additional_info']])?>');" style="cursor:pointer;"><?=$v[$columnKey]?></span><?php
											}
											else if($columnDetails['column_size']!='')
											{
												txtBox($v[$columnKey],$columnKey,$columnDetails['column_size']);
											}
											else
											{
												if($columnDetails['type']=='id')
												{
													echo '#';
												}
                                            /*
                                            * Fix for: Improvement - Bulk User Upload (suggested by ICT)
                                            * Defined the checkboxes for Edit Multiple Users in User management
                                            */
												else if ($columnDetails['type'] == 'checkbox') {
                                                 						?><div class="checkedUser"><input name="individualCheckedUser" class="individualCheckedUser" id="<?=$v['user_id']?>" type="checkbox" value="<?php echo $v['user_id']; ?>" onclick ="individualChecked()" ></div><?php
                                                                                                
                                                }//End of addd
												echo $v[$columnKey];
											}
											if($v['element_disabled']==1)
											{
												?></span><?php
											}
										}
									break;
								}
							break;
						}
					?></td><?php
				break;
			}
		//JFM 15_09_15 break;
	//JFM 15_09_15 }
}

function filterRow($filterActive,$data){
	$i = 0;	// Siglum Search added by Infosys
	if(is_array($filterActive) && is_array($data)){
		//print_r($filterActive);
		//print_r($data);
		foreach($data as $k=>$v){
			$remove=0;
			foreach($filterActive as $f){
				// Siglum & Supplier Search added by Infosys
				if ($f['field'] == 'siglum' && ($f['value'] == 'n/a' || $f['value'] == 'N/A')) {
					if ($v[siglum] != '') {
						$remove=1;
					}
					break;
				}
				
                                if ($f['field'] == 'supplier' && ($f['value'] == 'n/a' || $f['value'] == 'N/A')) {
					if ($v[supplier] != '') {
						$remove=1;
					}
					break;
				}
                                // End for Siglum & Supplier Search added by Infosys
				switch($f['type']){
					case 'action':
						if($v[$f['field']]=='' || $v[$f['field']]==0){
							$remove=1;
						}
					break;
					case 'date':
						switch($f['action']){
							case 'show_only_empty':
								if($v[$f['field']]!=''){
									$remove=1;
								}								
							break;
							case 'show_after':
								if($v[$f['field']]==''){
									$remove=1;
								}else{
									$dateToCheck=convertToDate($v[$f['field']]);
									if($dateToCheck<$f['value']){
										$remove=1;
									}
								}			
							break;
							case 'show_before':
								if($v[$f['field']]==''){
									$remove=1;
								}else{
									$dateToCheck=convertToDate($v[$f['field']]);
									if($dateToCheck>$f['value']){
										$remove=1;
									}
								} 
							break;
							case 'show_only_not_done': //JFM 19_07_16
								if($v[$f['field']]=='' || $v[$f['field']]=='0000-00-00')
								{
									$remove=1;
								}
								else
								{
									$reviewDoneField = substr($f['field'], 0, count($f['field'])-5).'done';
									if($v[$reviewDoneField] == 1)
									{
										$remove=1;
									}
									else
									{
										$dateToCheck=convertToDate($v[$f['field']]);
										if($dateToCheck > convertToDate(date("Y-m-d")))
										{
											$remove=1;
										}
									}
								}
							break;

						}
					break;
					case 'status':
						switch($f['action'])
						{
							//JFM 19_07_16
							case 'hide_no_status':
								if($v[$f['optional']]==0 || $v[$f['field']]==4)
									$remove=1;
							break;
							case 'hide_red':
								if($v[$f['field']]==0)
									$remove=1;
							break;
							case 'hide_amber':
								if($v[$f['field']]==1)
									$remove=1;
							break;
							case 'hide_green':
								if($v[$f['field']]==2)
									$remove=1;
							break;
							case 'hide_blue': //JFM 27_03_14
								if($v[$f['field']]==3)
									$remove=1;
							break;
						}
					break;
					case 'link':
					case 'text':
						if(!stristr($v[$f['field']],$f['value'])){
							$remove=1;
						}
					break;
					case 'user':
						if($f['value']!=$v[$f['field']]){
							$remove=1;
						}
					break;
					case 'boolean': //JFM 16_09_13
						switch($f['action'])
						{
							case 'hide_yes':
								//echo '"'.$f['optional'].'"'.'---'.$f['field'].'---'.$v[$f['optional']].'---'.$v[$f['field']].'<br />';
								if($f['optional']!='')
								{
									if($v[$f['optional']]==1) $remove=1;
								}
								else if($v[$f['field']]==1) $remove=1;
							break;
							
							case 'hide_no':
								//echo '"'.$f['optional'].'"'.'---'.$f['field'].'---'.$v[$f['optional']].'---'.$v[$f['field']].'<br />';
								if($f['optional']!='')
								{
									if($v[$f['optional']]==0) $remove=1;
								}
								else if($v[$f['field']]==0) $remove=1;
							break;
						}
					
					break;
					case 'trend': //JFM 08_06_16
						switch($f['action'])
						{
							case 'hide_trend_0':
								if($v[$f['field']] == 0) $remove = 1;
							break;
							case 'hide_trend_1':
								if($v[$f['field']] == 1) $remove = 1;
							break;
							case 'hide_trend_2':
								if($v[$f['field']] == 2) $remove = 1;
							break;
							case 'hide_trend_3':
								if($v[$f['field']] == 3) $remove = 1;
							break;
							case 'hide_trend_4':
								if($v[$f['field']] == 4) $remove = 1;
							break;
							case 'hide_trend_5':
								if($v[$f['field']] == 5) $remove = 1;
							break;
						}
					break;
				}
			}
			if($remove==1){
				unset($data[$k]);
			}
		}
		//print_r($data);
		return $data;
	}else{
		return $data;
	}
}

function fltUpd($input,&$SESSION,$sql){
	$_a_=$SESSION['user_action'];
	$_o_=$SESSION['object'];
	$_u_=$SESSION['user'];
	$mainObject=array('program','coe','msn');
	$mainObjectId=array($_o_['program'],$_o_['coe'],$_o_['msn']);
	
	$idArr=explode('-',$input['o']);
	$appl=$idArr[1];
	$object=$idArr[2];
	
	switch($input['m']){
		case 'reset':
			switch($input['o']){
				case 'reset_all':
					if($sql==1){
						SqlLQ('UPDATE dr_user_filter SET filter_value="" 
							WHERE user="'.$_u_['user_id'].'" AND object NOT IN("'.$_o_['program'].'","'.$_o_['coe'].'","'.$_o_['msn'].'") AND action!="'.$_a_['hide'].'"');
					}
					foreach($SESSION['filter'] as $filterObject=>$o){
						if(is_array($o) && !in_array($filterObject,$mainObjectId)){
							foreach($o as $action=>$a){
								if($action!=$_a_['hide'] && !in_array($_o_[$filterObject],$mainObject)){
									$SESSION['filter'][$filterObject][$action]='';
								}
							}
						}
					}
				break;
				case 'reset_temp':
					foreach($SESSION['table'][$input['table']] as $table=>$section){
						foreach($section as $field=>$fieldDetails){
							unset($SESSION['filter'][$_o_[$field]]);
						}
					}
				break;
				default:
					if($sql==1)SqlLQ('UPDATE dr_user_filter SET filter_value="" WHERE user="'.$_u_['user_id'].'" AND object="'.$_o_[$object].'" AND applicability="'.$appl.'"');
					foreach($SESSION['filter'] as $filterObject=>$o){
						if($filterObject==$_o_[$object] && is_array($o)){
							foreach($o as $action=>$a){
								if(is_array($a)){
									foreach($a as $applicability=>$ap){
										if($applicability==$appl || $applicability===$appl) $SESSION['filter'][$filterObject][$action][$applicability]=''; //JFM 23_09_13 - JFM 02_12_13 
									}
								}
							}
						}
					}
				break;
			}
		break;
		case 'add':
			foreach($input as $k=>$v){
				$oArr=explode('-',$k);
				if($_o_[$object]!='' && $_a_[$oArr[3]]!='' && $object!='' && $oArr[3]!=''){
					modifyFilter($object,$oArr[3],$appl,$v,$SESSION,$sql);
				}
			}
		break;
		case 'show':
			
		break;
	}
}

function getRevData($status,&$caInfo,$reviewProfileList,$SESSION,$responsible,$validCriteriaStatus){
	global $p12;
  $check = checkExternal($SESSION);
	if(is_array($reviewProfileList)){
		foreach($reviewProfileList as $k=>&$v){
			$revPIdArr[]=$k;
		}
	}
	
	$ca=array();
	$statusField=array('red','amber','green','blue'); //JFM 27_03_14
	
	$validPerimeter=perimeterPermission($SESSION,'view');
	if(is_array($validPerimeter)){
		
		foreach($validPerimeter as $k=>$v){
			$perimeter[]=$k;
		}
		
		$caQryField=array('c.ca_id','prm.perimeter_id','cw.cawp_id','cw.cawp_disabled AS element_disabled','w.wp_id');
		$caQryTable=array('c_ca','c_perimeter','c_cawp','c_wp');
		$riskQryTable=array('dr_risk');
		
		foreach($SESSION['table']['review_planning']['ca'] as $columnName=>$columnDetails)
		{
			if(in_array($columnDetails['table'],$caQryTable))
			{
				if(getFilter($columnName,'hide',0,$SESSION)!=1)
				{
					$caQryField[]=$columnDetails['table_short_name'].'.'.$columnName;
				}
			}

			if(in_array($columnDetails['table'],$riskQryTable)) //JFM 08_06_16
			{
				if(getFilter($columnName,'hide',0,$SESSION)!=1)
				{
					$riskNeeded = 1;
				}
			}
		}
		
		$caQry=mysql_query('SELECT '.implode(',',$caQryField).'
			FROM c_ca 					AS c
				INNER JOIN c_perimeter 	AS prm	ON c.perimeter=prm.perimeter_id
				INNER JOIN c_cawp 		AS cw	ON c.ca_id=cw.ca
				INNER JOIN c_wp 		AS w	ON cw.wp=w.wp_id
			WHERE c.program='.getFilter('program','filter',0,$SESSION).'
				AND c.coe='.getFilter('coe','filter',0,$SESSION).'
				AND c.perimeter IN('.implode(',',$perimeter).')
				AND cw.msn='.getFilter('msn','filter',0,$SESSION),$p12) or die(mysql_error());
		while($c=mysql_fetch_assoc($caQry)){
			foreach($c as $k=>$v){
				if($ca[$c['ca_id']][$k]=='')$ca[$c['ca_id']][$k]=$v;
			}
		}
		unset($caQry);
		
		$caStatusNeeded=0;
		foreach($SESSION['table']['review_planning']['ca'] as $columnName=>$columnDetails)
		{
			if($columnDetails['table']=='dr_ca_status')
			{
				if(getFilter($columnName,'hide',0,$SESSION)!=1)
				{
					$caStatusNeeded=1;
					$caStatusQryField[]=$columnDetails['table_short_name'].'.'.$columnName;
					if($columnDetails['done']!='')
					{
						$caStatusQryField[]=$columnDetails['table_short_name'].'.'.$columnDetails['done'];
					}
				}
			}
		}
		
		if($caStatusNeeded==1)
		{
			$caStatusQryField[]='cas.ca';
			$faiHided=getFilter('fai','hide',0,$SESSION);
			$progressTrendHided=getFilter('progress_trend','hide',0,$SESSION);
			
			$caStatusQry=mysql_query('SELECT '.implode(',',$caStatusQryField).'
				FROM dr_ca_status AS cas
				WHERE cas.msn='.getFilter('msn','filter',0,$SESSION),$p12) or die(mysql_error());
			while($c=mysql_fetch_assoc($caStatusQry))
			{
				if($ca[$c['ca']]['ca_id']!='')
				{
					foreach($c as $k=>$v)
					{
						if($k!='ca')$ca[$c['ca']][$k]=$v;
					}
				}
				
				if($faiHided!=1 && $ca[$c['ca']]['fai']=='0000-00-00' && $c['kodd']!='0000-00-00')
				{
					$fai=fai($c['kodd']);
					SqlLQ('UPDATE dr_ca_status SET fai="'.$fai.'" WHERE ca="'.$c['ca'].'" AND msn='.getFilter('msn','filter',0,$SESSION));
					$ca[$c['ca']]['fai']=$fai;
				}
				
			}
			unset($caStatusQry);
		}



		if($riskNeeded==1) //JFM 08_06_16
		{
			$riskQry=mysql_query('SELECT rsk.risk_id, rsk.risk_status, rsk.ca FROM dr_risk AS rsk
									INNER JOIN c_ca AS ca ON ca.ca_id = rsk.ca
									WHERE ca.program='.getFilter('program','filter',0,$SESSION).'
									AND ca.coe='.getFilter('coe','filter',0,$SESSION),$p12) or die(mysql_error());
						
				
			while($r=mysql_fetch_assoc($riskQry))
			{
				if($ca[$r['ca']]['ca_id']!='')
				{
					$ca[$r['ca']]['risk_'.$statusField[$r['risk_status']]]++;
				}
			}
		}


		
		if(is_array($revPIdArr))
		{
			foreach($revPIdArr as $r)
			{
				foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
				{
					if(getFilter($columnName,'hide',$r,$SESSION)!=1 && $columnName!='criteria_status')
					{
						$visibleReviewStructure[$r][$columnName]=$columnDetails;
						if($columnDetails['type']=='action')
						{
							$actionProfileNeeded[$r]=1;
						}
						else if($columnName=='link') //JFM 13_05_16
						{
							$linkProfileNeeded[$r]=1;
						}
						else
						{
							$reviewProfileNeeded[$r]=1;
							$reviewFieldNeeded[$columnDetails['table_short_name'].'.'.$columnName]=1;
							if($columnDetails['done']!='')
							{
								$reviewFieldNeeded[$columnDetails['table_short_name'].'.'.$columnDetails['done']]=1;
							}
						}
					}
				}
				if(getFilter('criteria_status','hide',$r,$SESSION)!=1)
				{
					$actionProfileNeeded[$r]=1;
				}
			}
			
			if(is_array($reviewProfileNeeded))
			{
				$reviewQryField=array('ra.ca','r.review_profile','r.inherited');
				foreach($reviewFieldNeeded as $k=>$v)
				{
					$reviewQryField[]=$k;
				}
				foreach($reviewProfileNeeded as $k=>$v)
				{
					$reviewQryProfile[]=$k;
				}
				
				//JFM 18_03_14
				$reviewQry=mysql_query('SELECT '.implode(',',$reviewQryField).'
										FROM dr_review AS r
											INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
										WHERE r.msn='.getFilter('msn','filter',0,$SESSION).'
										AND r.validation_complete!=-1
										AND r.review_profile IN('.implode(',',$reviewQryProfile).')',$p12) or die(mysql_error());
				
				while($r=mysql_fetch_assoc($reviewQry))
				{
					foreach($r as $k=>&$v)
					{
						if($ca[$r['ca']]['ca_id']!='')
							$ca[$r['ca']]['review_'.$r['review_profile'].'_'.$k]=$v; //JFM 09_04_14
					}
				}
				unset($reviewQry);
			}



			//JFM 13_05_16
			if(is_array($linkProfileNeeded))
			{
				foreach($linkProfileNeeded as $k=>$v)
				{
					$linkQryProfile[]=$k;
				}

				$reviewLinkQry=mysql_query('SELECT DISTINCT ra.ca, r.review_id, r.review_profile, rl.link_id, rl.name, rl.reference, rl.link
										FROM dr_review AS r
											INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
											INNER JOIN dr_review_links AS rl ON rl.review=r.review_id
										WHERE r.msn='.getFilter('msn','filter',0,$SESSION).'
										AND r.validation_complete!=-1
										AND r.review_profile IN('.implode(',',$linkQryProfile).')',$p12) or die(mysql_error());
				$i=0;
				while($r=mysql_fetch_assoc($reviewLinkQry))
				{
					
					foreach($r as $k=>&$v)
					{
						if($ca[$r['ca']]['ca_id']!='')
						{
							$ca[$r['ca']]['review_'.$r['review_profile'].'_link'][$r['link_id']][$k]=$v;
							$i++;
						}
					}
				}
				unset($reviewLinkQry);
			}
			


			if(is_array($actionProfileNeeded))
			{
				$ridCount=array();
				foreach($actionProfileNeeded as $k=>$v)
				{
					$actionQryProfile[]=$k;
				}
						
				//JFM 04_09_13 - JFM 09_04_14
				$actionQry=mysql_query('SELECT 
						aap.ca,cat.ca_description,rp.review_profile_id AS review_profile,
						act.action_id,act.criteria,act.action_status,
						rid.rid_id,rid.rid_status
					FROM dr_action_applicability 		AS aap
						INNER JOIN dr_action 			AS act ON aap.action=act.action_id
						LEFT  JOIN dr_rid				AS rid ON act.rid=rid.rid_id
						LEFT  JOIN dr_review_criterion 	AS rc  ON act.criteria=rc.review_criterion_id
						LEFT  JOIN dr_review_group		AS rg  ON rc.review_group=rg.group_id
						LEFT  JOIN dr_review 			AS r   ON r.review_id=act.review
						INNER JOIN dr_review_profile	AS rp  ON rg.review_type=rp.review_type
															   OR rp.review_profile_id=r.review_profile
						INNER JOIN c_ca					as cat ON aap.ca=cat.ca_id
					WHERE act.msn='.getFilter('msn','filter',0,$SESSION).'
						AND rp.review_profile_id IN ('.implode(',',$actionQryProfile).')',$p12) or die(mysql_error());
						
				
				while($a=mysql_fetch_assoc($actionQry))
				{
					if($ca[$a['ca']]['ca_id']!='')//JFM 09_04_14
					{
						$ca[$a['ca']]['review_'.$a['review_profile'].'_review_'.$statusField[$a['action_status']].'_action']++;
						if($a['rid_status']!='')
						{
							$ridCount[$a['ca']][$a['review_profile']][$a['rid_status']][$a['rid_id']]=1;
						}
						$ca[$a['ca']]['criteria_status_'.$a['criteria']]=0;
					}
				}
				
				foreach($ridCount as $caId=>$review)
				{
					foreach($review as $reviewId=>$rid)
					{
						$ca[$caId]['review_'.$reviewId.'_review_red_rid']=count($rid[0]);
						$ca[$caId]['review_'.$reviewId.'_review_amber_rid']=count($rid[1]);
						$ca[$caId]['review_'.$reviewId.'_review_green_rid']=count($rid[2]);
						$ca[$caId]['review_'.$reviewId.'_review_blue_rid']=count($rid[3]); //JFM 27_03_14
					}
				}
			}
		}

/*		if($progressTrendHided != 1) //JFM 19_07_16
		{
			print_r(array_keys($ca));

			$anotherSlowDownQry=SqlLi('SELECT GROUP_CONCAT(r.review_date ORDER BY r.review_date DESC) AS review_date, GROUP_CONCAT(r.review_status ORDER BY r.review_date DESC) AS review_status, GROUP_CONCAT(rt.review_type ORDER BY r.review_date DESC) AS review_status, ra.ca
										FROM dr_review AS r
										INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
										INNER JOIN dr_review_profile AS rp ON rp.review_profile_id = r.review_profile
										INNER JOIN dr_review_type AS rt ON rt.review_type_id = rp.review_type
										WHERE ra.ca IN ('.implode(',', array_keys($ca)).')
										AND r.review_done = 1
										AND r.review_date != "0000-00-00"
										GROUP BY ra.ca
										ORDER BY ra.ca ASC, r.review_date DESC');

			print_r($anotherSlowDownQry);
			echo '<br />';

			foreach ($anotherSlowDownQry as $noKey => $values) 
			{
				echo $values['ca'].'---'.$values['review_date'].'---'.$values['review_status'].'<br />';
			}

		}*/

		
		if(is_array($validCriteriaStatus))
		{
		//
		// ONLY GOES HERE IF Configure Columns -> Reviews -> Crit. IS CHECKED!
		// CALLED FROM showTable.php's getRevData FUNCTION CALL!
		// It will never go here as it has now been disabled.
		//
					
			$criteriaQry=mysql_query('SELECT cs.criteria_status_id,cs.ca,cs.criteria_status,rc.review_criterion_id
				FROM dr_criteria_status 			AS cs
					INNER JOIN dr_review_criterion	AS rc ON cs.review_criteria=rc.review_criterion_id
					INNER JOIN dr_review_group 		AS rg ON rc.review_group=rg.group_id
					INNER JOIN dr_review_profile	AS rp ON rg.review_type=rp.review_type
				WHERE cs.msn='.getFilter('msn','filter',0,$SESSION).'
					AND rp.review_profile_id IN("'.implode('","',$validCriteriaStatus).'")',$p12) or die(mysql_error());
					
			while($c=mysql_fetch_assoc($criteriaQry))
			{
				if($ca[$c['ca']]['ca_id']!='')
				{
					$ca[$c['ca']]['criteria_status_'.$c['review_criterion_id']]=$c['criteria_status'];
					$ca[$c['ca']]['criteria_status_id_'.$c['review_criterion_id']]=$c['criteria_status_id'];
				}
			}
		}
	}

	checkActiveFilter($filterActive,$SESSION['table']['review_planning']['ca'],0,$SESSION,'',1);
	
	if(is_array($visibleReviewStructure))
	{
		foreach($visibleReviewStructure as $k=>$v)
		{
			checkActiveFilter($filterActive,$v,$k,$SESSION,'review',1);
		}
	}
	
	$caInfo=filterRow($filterActive,$ca);
	
	$mainFilter=getFilter('overall_search','filter',0,$SESSION);
	if($mainFilter!='')
	{
		foreach($caInfo as $caId=>$caDetails)
		{
			$exists=0;
			foreach($caDetails as $fieldName=>$fieldValue)
			{
				if($exists==0 && stristr($fieldValue,$mainFilter))
				{
					$exists=1;
				}
			}
			if($exists==0)
			{
				//JFM 02_09_13 unset($caInfo[$k]);
				unset($caInfo[$caId]); //JFM 02_09_13
			}
		}
	}
	
	sortBasicTable($caInfo,$SESSION['table']['review_planning']['ca'],0,$SESSION);
	
	if(is_array($revPIdArr))
	{
		foreach($revPIdArr as &$r)
		{
			$columnPrefix='review_'.$r.'_';
			sortBasicTable($caInfo,$SESSION['table']['review_planning']['review'],$r,$SESSION,$columnPrefix);
		}
	}
}

function sortArr($arr,$fld,$inv=false){
	if(is_array($arr)){
		$pos=array();
		$newRow=array();
		foreach($arr as $k=>$v){
			$pos[$k]=$v[$fld];
			$newRow[$k]=$v;
		}
		if($inv==true)arsort($pos);
		else asort($pos);
		$retArr=array();
		foreach($pos as $k=>$v)$retArr[]=$newRow[$k];
		return $retArr;
	}
}

function sortBasicTable(&$rawData,&$tableStructure,$applicability,&$SESSION,$columnPrefix=''){
	foreach($tableStructure as $columnName=>$columnDetails){
		$sort=getFilter($columnName,'sort',$applicability,$SESSION);
		switch($sort){
			case 'ASC':
				$rawData=sortArr($rawData,$columnPrefix.$columnName,false);
			break;
			case 'DESC':
				$rawData=sortArr($rawData,$columnPrefix.$columnName,true);
			break;
		}
	}
}

function subVersion($rawData,$expand) //JFM 03_12_13
{
	if($rawData)
	{
		$beenContracted=Array();
		$beenUnset=Array();
		foreach($rawData as $q=>$z)
		{
			if(	$expand && $rawData[$q]['criterion_group']==$expand ) 
			{
				if(!$beenContracted[$expand])
				{
					$rawData[$q]['criterion_group_reference']="Click to Contract";
					$beenContracted[$expand]=1;
				}
				else if(!$rawData[$q]['criterion_group_reference'])
				{
					$rawData[$q]['criterion_group_reference']="^<br />|<br />|<br />";
				}
				continue;
			}
		
			foreach($rawData as $p=>$y)
			{
				if(	$rawData[$q]['criterion_included']==1 &&
					$rawData[$q]['criterion_group']==$rawData[$p]['criterion_group'] && 
					$rawData[$q]['criterion_validity_id']!=$rawData[$p]['criterion_validity_id']
				  )
				{
					$rawData[$q]['criterion_group_reference']="Click to Expand";
					unset($rawData[$p]);
					$beenUnset[$rawData[$q]['criterion_group']]=1;
				}
			}
		}
		
		foreach($rawData as $q=>$z)
		{
			if(	$expand && $rawData[$q]['criterion_group']==$expand ) 
			{
				if(!$beenContracted[$expand])
				{
					$rawData[$q]['criterion_group_reference']="Click to Contract";
					$beenContracted[$expand]=1;
				}
				else if(!$rawData[$q]['criterion_group_reference'])
				{
					$rawData[$q]['criterion_group_reference']="^<br />|<br />|<br />";
				}
				continue;
			}
			
			if($beenUnset[$rawData[$q]['criterion_group']]) continue;
			
			else
			{
				foreach($rawData as $p=>$y)
				{
					if(	$rawData[$q]['criterion_group']==$rawData[$p]['criterion_group'] && 
						$rawData[$q]['criterion_validity_id']!=$rawData[$p]['criterion_validity_id']
					  )
					{
						$rawData[$q]['criterion_group_reference']="Click to Expand";
						unset($rawData[$p]);
					}
				}
			}
		}
		
		return $rawData;
	}
}
		
?>