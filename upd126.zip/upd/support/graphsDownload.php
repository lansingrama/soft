<?php
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('localSupport.php');
require_once('form.php');
require_once('zipfile.php');
$POST=cleanArray($_POST);

foreach($POST as $k => $l)
{
	if($l=='null') $POST[$k]=0;
}

if(is_file('../output/sharedStrings.xml')) unlink('../output/sharedStrings.xml');
if(is_file('../output/sheet1.xml')) unlink('../output/sheet1.xml');
if(is_file('../output/chart1.xml')) unlink('../output/chart1.xml');
if(is_file('../output/Book1.zip')) unlink('../output/Book1.zip');
if(is_file('../output/Book1.xlsx')) unlink('../output/Book1.xlsx');

$sharedStringsxml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="6" uniqueCount="6"><si><t>'.$POST['title'].'</t></si><si><t>Status</t></si><si><t>Red</t></si><si><t>Amber</t></si><si><t>Green</t></si><si><t>Blue</t></si></sst>';
$sheet1xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" mc:Ignorable="x14ac" xmlns:x14ac="http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac"><dimension ref="A1:B5"/><sheetViews><sheetView tabSelected="1" workbookViewId="0"><selection activeCell="O14" sqref="O14"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="14.25" x14ac:dyDescent="0.2"/><sheetData><row r="1" spans="1:2" x14ac:dyDescent="0.2"><c r="A1" t="s"><v>1</v></c><c r="B1" t="s"><v>0</v></c></row><row r="2" spans="1:2" x14ac:dyDescent="0.2"><c r="A2" t="s"><v>2</v></c><c r="B2"><v>'.$POST['red'].'</v></c></row><row r="3" spans="1:2" x14ac:dyDescent="0.2"><c r="A3" t="s"><v>3</v></c><c r="B3"><v>'.$POST['yellow'].'</v></c></row><row r="4" spans="1:2" x14ac:dyDescent="0.2"><c r="A4" t="s"><v>4</v></c><c r="B4"><v>'.$POST['green'].'</v></c></row><row r="5" spans="1:2" x14ac:dyDescent="0.2"><c r="A5" t="s"><v>5</v></c><c r="B5"><v>'.$POST['blue'].'</v></c></row></sheetData><pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/><drawing r:id="rId1"/></worksheet>';
$chart1xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><c:date1904 val="0"/><c:lang val="en-GB"/><c:roundedCorners val="0"/><mc:AlternateContent xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"><mc:Choice Requires="c14" xmlns:c14="http://schemas.microsoft.com/office/drawing/2007/8/2/chart"><c14:style val="102"/></mc:Choice><mc:Fallback><c:style val="2"/></mc:Fallback></mc:AlternateContent><c:chart><c:title><c:layout/><c:overlay val="0"/></c:title><c:autoTitleDeleted val="0"/><c:plotArea><c:layout/><c:pieChart><c:varyColors val="1"/><c:ser><c:idx val="0"/><c:order val="0"/><c:tx><c:strRef><c:f>Sheet1!$B$1</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>'.$POST['title'].'</c:v></c:pt></c:strCache></c:strRef></c:tx><c:dPt><c:idx val="0"/><c:bubble3D val="0"/><c:spPr><a:solidFill><a:schemeClr val="accent2"><a:lumMod val="75000"/></a:schemeClr></a:solidFill></c:spPr></c:dPt><c:dPt><c:idx val="1"/><c:bubble3D val="0"/><c:spPr><a:solidFill><a:srgbClr val="E5D509"/></a:solidFill></c:spPr></c:dPt><c:dPt><c:idx val="2"/><c:bubble3D val="0"/><c:spPr><a:solidFill><a:schemeClr val="accent3"><a:lumMod val="75000"/></a:schemeClr></a:solidFill></c:spPr></c:dPt><c:dPt><c:idx val="3"/><c:bubble3D val="0"/><c:spPr><a:solidFill><a:schemeClr val="accent1"><a:lumMod val="75000"/></a:schemeClr></a:solidFill></c:spPr></c:dPt><c:dLbls><c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr><a:solidFill><a:schemeClr val="bg1"/></a:solidFill></a:defRPr></a:pPr><a:endParaRPr lang="en-US"/></a:p></c:txPr><c:showLegendKey val="0"/><c:showVal val="0"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="1"/><c:showBubbleSize val="0"/><c:showLeaderLines val="1"/></c:dLbls><c:cat><c:strRef><c:f>Sheet1!$A$2:$A$5</c:f><c:strCache><c:ptCount val="4"/><c:pt idx="0"><c:v>Red</c:v></c:pt><c:pt idx="1"><c:v>Amber</c:v></c:pt><c:pt idx="2"><c:v>Green</c:v></c:pt><c:pt idx="3"><c:v>Blue</c:v></c:pt></c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$B$2:$B$5</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="4"/><c:pt idx="0"><c:v>9</c:v></c:pt><c:pt idx="1"><c:v>9</c:v></c:pt><c:pt idx="2"><c:v>9</c:v></c:pt><c:pt idx="3"><c:v>9</c:v></c:pt></c:numCache></c:numRef></c:val></c:ser><c:dLbls><c:showLegendKey val="0"/><c:showVal val="0"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="1"/><c:showBubbleSize val="0"/><c:showLeaderLines val="1"/></c:dLbls><c:firstSliceAng val="0"/></c:pieChart></c:plotArea><c:legend><c:legendPos val="r"/><c:layout/><c:overlay val="0"/></c:legend><c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/><c:showDLblsOverMax val="0"/></c:chart><c:printSettings><c:headerFooter/><c:pageMargins b="0.75" l="0.7" r="0.7" t="0.75" header="0.3" footer="0.3"/><c:pageSetup/></c:printSettings></c:chartSpace>';

$fp=fopen('../output/sharedStrings.xml','w');
fwrite($fp,$sharedStringsxml);
fclose($fp);

$fp=fopen('../output/sheet1.xml','w');
fwrite($fp,$sheet1xml);
fclose($fp);

$fp=fopen('../output/chart1.xml','w');
fwrite($fp,$chart1xml);
fclose($fp);


$zip = new ZipArchive();

$zip->open('../output/Book1.zip', ZipArchive::CREATE);

$source=str_replace('\\', '/', realpath('../archive/Book1/'));
$flag=basename($source).'/';

$files= new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source),RecursiveIteratorIterator::SELF_FIRST);

foreach($files as $file)
{
	$file=str_replace('\\', '/', realpath($file));
	
	if(is_dir($file)===true)
	{
		$zip->addEmptyDir(str_replace($source.'/', '', $file));
	}
	else if(is_file($file))
	{
		if(strpos($file, 'sharedStrings')  && !strpos($file, 'rels')) 
		{
			$fileNew='../output/sharedStrings.xml';
		}
		else if(strpos($file, 'sheet1') && !strpos($file, 'rels')) 
		{
			$fileNew='../output/sheet1.xml';
		}
		else if(strpos($file, 'chart1')  && !strpos($file, 'rels')) 
		{
			$fileNew='../output/chart1.xml';
		}
		else $fileNew=$file;

		$zip->addFromString(str_replace($source.'/', '', $file), file_get_contents($fileNew));
	}
}

$zip->close();

storeSession($SESSION);

rename("../output/Book1.zip", "../output/Book1.xlsx");

if(is_file('../output/sharedStrings.xml')) unlink('../output/sharedStrings.xml');
if(is_file('../output/sheet1.xml')) unlink('../output/sheet1.xml');
if(is_file('../output/chart1.xml')) unlink('../output/chart1.xml');

header('Content-type: application/octet-stream');
header('Content-Disposition: attachment; filename=Book1.xlsx');
header("Cache-Control: private");
header("Pragma: private"); //JFM 02_10_14
readfile('../output/Book1.xlsx')

?>