<?php
/**
 * Header file
*/

require_once('../../common/php/PhpPresentation/Autoloader.php');
Autoloader::register();

require_once('../../common/php/PhpOfficeCommon/Autoloader.php');
\PhpOffice\Common\Autoloader::register(); //JFM

use PhpOffice\PhpPresentation\Autoloader;
use PhpOffice\PhpPresentation\Settings;
use PhpOffice\PhpPresentation\IOFactory;
use PhpOffice\PhpPresentation\Slide;
use PhpOffice\PhpPresentation\PhpPresentation;
use PhpOffice\PhpPresentation\AbstractShape;
use PhpOffice\PhpPresentation\DocumentLayout;
use PhpOffice\PhpPresentation\Shape\Drawing;
use PhpOffice\PhpPresentation\Shape\MemoryDrawing;
use PhpOffice\PhpPresentation\Shape\RichText;
use PhpOffice\PhpPresentation\Shape\RichText\BreakElement;
use PhpOffice\PhpPresentation\Shape\RichText\TextElement;
use PhpOffice\PhpPresentation\Style\Alignment;
use PhpOffice\PhpPresentation\Style\Bullet;
use PhpOffice\PhpPresentation\Style\Color;


$writers = array('PowerPoint2007' => 'pptx');


function write($phpPresentation, $filename, $writers)
{
	$result = '';

	// Write documents
	foreach ($writers as $writer => $extension) 
	{
		$result .= date('H:i:s') . " Write to {$writer} format";
		if (!is_null($extension)) 
		{
			$xmlWriter = IOFactory::createWriter($phpPresentation, $writer);
			$xmlWriter->save("../output/{$filename}.{$extension}");
			//rename(__DIR__ . "/{$filename}.{$extension}", __DIR__ . "/results/{$filename}.{$extension}");
		} 
		else 
		{
			$result .= ' ... NOT DONE!';
		}
		//$result .= EOL;
	}

	//$result .= getEndingNotes($writers);

	return $result;
}

?>