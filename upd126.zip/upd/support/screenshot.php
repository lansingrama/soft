<?php
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('localSupport.php');
require_once('form.php');
require_once('zipfile.php');
$POST=cleanArray($_POST);



$cropArray=Array('x' => 100,'y' => 100,'width' => 100,'height' => 100);
$im=imagegrabscreen();
$imCrop=imagecrop($im,$cropArray);
imagepng($imCrop, '../output/test.png');
imagedestroy($im);
imagedestroy($imCrop);

echo 'OK|||';
storeSession($SESSION);

/*rename("../output/Book1.zip", "../output/Book1.xlsx");

if(is_file('../output/sharedStrings.xml')) unlink('../output/sharedStrings.xml');
if(is_file('../output/sheet1.xml')) unlink('../output/sheet1.xml');
if(is_file('../output/chart1.xml')) unlink('../output/chart1.xml');*/

header('Cache-Control: max-age=60');
header('Content-type: application/octet-stream');
header('Content-Disposition: attachment; filename=test.png');
readfile('../output/test.png')

?>