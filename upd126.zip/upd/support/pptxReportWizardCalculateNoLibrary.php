<?php

require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../../common/php/zip.lib.php');
require_once('localSupport.php');
require_once('form.php');

function formatValueForXML($string)
{
	return utf8_encode(str_replace("&#8230;", "",str_replace(">", "&gt;",str_replace("<", "&lt;",str_replace("&", "&amp;", $string)))));
}

//JFM 19_07_16
function calculateTableCell($text = ' ', $colour='FFFFFF', $font='Calibri', $fontColour='000000', $size='1200')
{
	$textArray = split("<w:br/>", $text);
	$textString = '';

	if(count($textArray) > 1)
	{
		for ($i=0; $i < count($textArray); $i++) 
		{ 
			if($i == (count($textArray)-1))
				$textString.=formatValueForXML($textArray[$i]);
			else
				$textString.=formatValueForXML($textArray[$i]).'</a:t></a:r></a:p><a:p><a:pPr marL="0" marR="0" lvl="0" indent="0" algn="l" fontAlgn="base"/><a:r><a:rPr lang="en-US" sz="'.$size.'" b="0" i="0" u="none" strike="noStrike"><a:solidFill><a:srgbClr val="'.$fontColour.'"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:latin typeface="'.$font.'"/></a:rPr><a:t>';
		}
	}
	else
	{
		$textString = formatValueForXML($text);
	}

	return '<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr marL="0" marR="0" lvl="0" indent="0" algn="l" fontAlgn="base"/><a:r><a:rPr lang="en-US" sz="'.$size.'" b="0" i="0" u="none" strike="noStrike"><a:solidFill><a:srgbClr val="'.$fontColour.'"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:latin typeface="'.$font.'"/></a:rPr><a:t>'.$textString.'</a:t></a:r></a:p></a:txBody><a:tcPr><a:lnL w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnL><a:lnR w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnR><a:lnT w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnT><a:lnB w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnB><a:lnTlToBr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnTlToBr><a:lnBlToTr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnBlToTr><a:solidFill><a:srgbClr val="'.$colour.'"><a:alpha val="100000"/></a:srgbClr></a:solidFill></a:tcPr></a:tc>';
}

$POST = cleanArray($_POST);

//SETUP IDS
//---------------------------------------------------
$area=SqlQ('SELECT area FROM c_area WHERE area_id='.getFilter('area','filter',0,$SESSION));
$program=implode(',', $POST['program']);
$coe=implode(',', $POST['coe']);
$msn=implode(',', $POST['msn']);
$reviewType=implode(',', $POST['review_type']);
$ca=implode(',', $POST['ca']);
$msn=implode(',', $POST['msn']);

$statusColourMap = array(0 => 'ef787f', 1 => 'f8e463', 2 => '92c362', 3 => '68accf');
$statusWordMap = array(0 => 'RED', 1 => 'AMBER', 2 => 'GREEN', 3 => 'BLUE'); //JFM 19_07_16
$wingdingsMap = array(0 => ' ', 1 => 'i', 2 => 'm', 3 => 'g', 4 => 'k', 5 => 'h');
$progressColourMap = array(0 => '000000', 1 => 'ef343f', 2 => 'f8d707', 3 => '81c341', 4 => '008cf');


$caNames=SqlSLi('SELECT ca FROM c_ca WHERE ca_id IN ('.$ca.')','ca');
$allCaNames=formatValueForXML(implode(',', $caNames));

$reviewProfileQry=SqlSLi('SELECT review_profile_id FROM dr_review_profile 
					WHERE program IN ('.$program.')
					AND coe IN ('.$coe.')
					AND review_type IN ('.$reviewType.')', 'review_profile_id');

$reviewProfile=implode(',', $reviewProfileQry);

//CALCULATE REVIEW
//---------------------------------------------------

$where = array();

if(!empty($POST['from']))
	$where[] = 'AND r.review_date > "'.$POST['from'].' 00:00:00"';
if(!empty($POST['to']))
	$where[] = 'AND r.review_date < "'.$POST['to'].' 23:59:59"';

$reviewID=SqlLi('SELECT r.review_id, r.review_done, r.validation_date, r.continuous_assessment, r.review_status, r.review_date,
						msn.msn, 
						coe.coe, 
						pro.program, 
						rt.review_type, 
						ca.ca, 
						per.perimeter,
						act.action_id, act.action_status, act.action_code, act.action_description, act.action_remark, act.action_completion, act.action_holder_name, act.action_validator_name,
						CONCAT(u1.name," ",u1.surname) AS action_holder_txt, CONCAT(u2.name," ",u2.surname) AS action_validator_txt,				
						act2.action_id AS action_id_2, 
						act2.action_status AS action_status_2, 
						act2.action_code AS action_code_2, 
						act2.action_description AS action_description_2, 
						act2.action_remark AS action_remark_2, 
						act2.action_completion AS action_completion_2, 
						act2.action_holder_name AS action_holder_name_2, 
						act2.action_validator_name AS action_validator_name_2,
						CONCAT(u4.name," ",u4.surname) AS action_holder_txt_2, CONCAT(u5.name," ",u5.surname) AS action_validator_txt_2,				
						rsk.risk_id, rsk.risk_status, rsk.risk_code, rsk.risk_description, rsk.risk_action, rsk.risk_remarks, rsk.risk_holder_name, rsk.severity, rsk.occurrence, rsk.detection,
						CONCAT(u3.name," ",u3.surname) AS risk_holder_txt,
						cas.odd, cas.id, cas.progress_trend, cas.sourcing
						FROM dr_review AS r
							INNER JOIN dr_review_applicability 		AS ra 	ON 	r.review_id=ra.review
							INNER JOIN c_ca 						AS ca 	ON 	ca.ca_id=ra.ca
							INNER JOIN c_perimeter 					AS per 	ON 	per.perimeter_id=ca.perimeter
							INNER JOIN dr_review_profile 			AS rp 	ON 	r.review_profile=rp.review_profile_id
							INNER JOIN c_coe 						AS coe 	ON 	coe.coe_id=rp.coe
							INNER JOIN c_program 					AS pro 	ON 	pro.program_id=rp.program
							INNER JOIN c_msn 						AS msn 	ON 	msn.msn_id=r.msn
							INNER JOIN dr_review_type 				AS rt 	ON 	rt.review_type_id=rp.review_type
							INNER JOIN dr_action_applicability 		AS aa 	ON 	aa.ca=ca.ca_id
							INNER JOIN dr_review_group 				AS grp  ON grp.review_type = rt.review_type_id 
							INNER JOIN dr_review_criterion 			AS crit ON crit.review_group=grp.group_id 
							LEFT JOIN dr_action 					AS act  ON act.action_id = aa.action 
																			AND act.msn = msn.msn_id 
																			AND act.criteria=crit.review_criterion_id
							LEFT JOIN dr_action 					AS act2 ON  act2.review = r.review_id
							LEFT JOIN c_user 						AS u1 	ON 	u1.user_id=act.action_holder
							LEFT JOIN c_user 						AS u2 	ON  u2.user_id=act.action_validator
							LEFT JOIN c_user 						AS u4 	ON 	u4.user_id=act2.action_holder
							LEFT JOIN c_user 						AS u5 	ON  u5.user_id=act2.action_validator
							LEFT JOIN dr_risk 						AS rsk 	ON  rsk.ca=ca.ca_id
							LEFT JOIN c_user 						AS u3 	ON  u3.user_id=rsk.risk_holder
							LEFT JOIN dr_ca_status 					AS cas 	ON 	cas.ca=ca.ca_id
						WHERE rp.review_profile_id IN ('.$reviewProfile.')
						AND ra.ca IN ('.$ca.')
						AND r.msn IN ('.$msn.')
						AND r.validation_complete = 2
						AND r.review_done = 1
						'.implode(' ', $where).'
						ORDER BY rp.review_profile_order, pro.program, coe.coe, msn.msn, ca.ca, act.action_code');

$graphPie = array();
$reviewTypeNames = array();
$reviewBetterFormatted = array();
$alreadyAddedActions = array();
$alreadyAddedRisks = array();
$reviewIdsArray = array();


$priorityMap=array('Low' => 1, 'Medium' => 2, 'High' => 3);

if(!empty($reviewID))
{
	foreach($reviewID as $q=>$z)
	{
		$reviewIdsArray[] = $z['review_id'];

		if($z['odd']=="0000-00-00") 
			$z['odd'] = 'Not Set';
		if($z['id']=="0000-00-00") 
			$z['id'] = 'Not Set';

		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['odd']['odd'] = $z['odd'];
		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['id']['id'] = $z['id'];
		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend'] = $z['progress_trend'];

		$reviewTypeNames[$z['review_type']]++;

		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['status']=$z['review_status'];
		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['date']=$z['review_date'];
		//$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']][$z['criteria_status']]++;
		//JFM 19_07_16$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['total']+=$priorityMap[$z['criterion_moc']];

		//JFM 19_07_16 if($z['criteria_status'] != '' && isset($z['criteria_status']) && $z['criteria_status']>0 && $z['criteria_status']<4)
		//JFM 19_07_16	$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['assessment']+=$priorityMap[$z['criterion_moc']];

		if($z['action_status'] != '' && isset($z['action_status']) && !in_array($z['action_id'], $alreadyAddedActions))
		{
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total']['action_total']++;
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total']++;

			if($z['action_status'] < 2)
			{
				$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total_ongoing']['action_total_ongoing']++;
				$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total_ongoing']++;
			}

			if(isset($z['action_holder_txt']))
				$actionHolder = $z['action_holder_txt'];
			else
				$actionHolder = $z['action_holder_name'];

			if(isset($z['action_validator_txt']))
				$actionValidator = $z['action_validator_txt'];
			else
				$actionValidator = $z['action_validator_name'];

			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_'.$z['action_status']].=$z['action_code'].'---'.$z['action_description'].'---'.$z['action_remark'].'---'.$z['action_completion'].'---'.$actionHolder.'---'.$actionValidator.'-!-';
			$alreadyAddedActions[] = $z['action_id'];
		}

		if($z['action_status_2'] != '' && isset($z['action_status_2']) && !in_array($z['action_id_2'], $alreadyAddedActions))
		{
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total']['action_total']++;
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total']++;

			if($z['action_status_2'] < 2)
			{
				$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total_ongoing']['action_total_ongoing']++;
				$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total_ongoing']++;
			}

			if(isset($z['action_holder_txt_2']))
				$actionHolder = $z['action_holder_txt_2'];
			else
				$actionHolder = $z['action_holder_name_2'];

			if(isset($z['action_validator_txt_2']))
				$actionValidator = $z['action_validator_txt_2'];
			else
				$actionValidator = $z['action_validator_name_2'];

			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_'.$z['action_status_2']].=$z['action_code_2'].'---'.$z['action_description_2'].'---'.$z['action_remark_2'].'---'.$z['action_completion_2'].'---'.$actionHolder.'---'.$actionValidator.'-!-';
			$alreadyAddedActions[] = $z['action_id_2'];
		}

		if($z['risk_status'] != '' && isset($z['risk_status']) && !in_array($z['risk_id'], $alreadyAddedRisks))
		{
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total']++;

			if($z['risk_status'] < 2)
				$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing']++;

			if(isset($z['risk_holder_txt']))
				$riskHolder = $z['risk_holder_txt'];
			else
				$riskHolder = $z['risk_holder_name'];

			$rpn = $z['severity'] * $z['occurrence'] * $z['detection'];

			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_'.$z['risk_status']].=$z['risk_code'].'---'.$z['risk_description'].'---'.$z['risk_action'].'---'.$z['risk_remarks'].'---'.$rpn.'---'.$riskHolder.'-!-';
		
			$alreadyAddedRisks[] = $z['risk_id'];
		}
	}

	$reviewIdsArray = array_unique($reviewIdsArray);
}

foreach ($reviewIdsArray as $reviewId) 
{
	$dofAnnoying=SqlLi('SELECT DISTINCT r.review_id, rch.criterion, rch.criterion_moc, cs.criteria_status,
						msn.msn, 
						coe.coe, 
						pro.program, 
						rt.review_type, 
						ca.ca, 
						per.perimeter
						FROM dr_review AS r
						INNER JOIN dr_review_applicability 		AS ra 	ON  ra.review = r.review_id
						INNER JOIN c_ca 						AS ca 	ON  ca.ca_id = ra.ca
						INNER JOIN dr_review_profile 			AS rp 	ON  rp.review_profile_id = r.review_profile
						INNER JOIN c_coe 						AS coe 	ON  coe.coe_id = rp.coe
						INNER JOIN c_program 					AS pro 	ON  pro.program_id = rp.program
						INNER JOIN dr_review_type 				AS rt 	ON  rt.review_type_id = rp.review_type
						INNER JOIN c_msn 						AS msn  ON  msn.msn_id = r.msn
						INNER JOIN c_perimeter 					AS per 	ON  per.perimeter_id=ca.perimeter
						INNER JOIN dr_review_configuration 		AS rc 	ON  rc.review = r.review_id
						INNER JOIN dr_review_criterion_history 	AS rch 	ON  rch.criterion = rc.criterion
						LEFT  JOIN dr_criteria_status 			AS cs 	ON  cs.review_criteria = rc.criterion
																		AND cs.msn = r.msn
																		AND cs.ca = ca.ca_id
						WHERE r.review_id = '.$reviewId.'
						AND rch.criterion_valid_from <= r.validation_date
						AND rch.criterion_valid_from != "0000-00-00 00:00:00"');

	foreach ($dofAnnoying as $k => $z) 
	{
		$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['total']+=$priorityMap[$z['criterion_moc']];

		if($z['criteria_status'] != '' && isset($z['criteria_status']) && $z['criteria_status']>0 && $z['criteria_status']<4)
			$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['assessment']+=$priorityMap[$z['criterion_moc']];
	}
}



//END REVIEW
//---------------------------------------------------


//PUT FILES IN MEMORY
//---------------------------------------------------


$firstSlide = file_get_contents('../archive/OVERVIEW_HELP_FILES/slide1.xml');


$colourForTableHeader;

for ($i=0; $i < (9+count($reviewTypeNames)); $i++) 
{ 
	$colourForTableHeader.='<a:gridCol w="1376795"/>';
}

$firstSlideReplaced=str_replace("SLIDE_1_ROW_COLOUR", $colourForTableHeader, $firstSlide);

$cellMerge='<a:tc hMerge="1"><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr marL="0" marR="0" lvl="0" indent="0" algn="l" fontAlgn="base"/><a:endParaRPr/></a:p></a:txBody><a:tcPr><a:lnL w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnL><a:lnR w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnR><a:lnT w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnT><a:lnB w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnB><a:lnTlToBr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnTlToBr><a:lnBlToTr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnBlToTr></a:tcPr></a:tc>';
$cellMergeTotal='';

$slideTitle = 'Airbus Review Tool - Report Generation for '.formatValueForXML($area['area']).' - CW'.date('W / Y');

$firstSlideReplaced=str_replace("SLIDE_TITLE_HERE", $slideTitle, $firstSlideReplaced);

$firstSlideReplaced=str_replace("SLIDE_TITLE_GRID_SPAN", (9+count($reviewTypeNames)), $firstSlideReplaced);


$headerStuff;

foreach ($reviewTypeNames as $reviewTypeSingle => $value) 
{
	$headerStuff.='<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr marL="0" marR="0" lvl="0" indent="0" algn="l" fontAlgn="base"/><a:r><a:rPr lang="en-US" sz="1200" b="1" i="0" u="none" strike="noStrike"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:latin typeface="Calibri"/></a:rPr><a:t>'.$reviewTypeSingle.'</a:t></a:r></a:p></a:txBody><a:tcPr><a:lnL w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnL><a:lnR w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnR><a:lnT w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnT><a:lnB w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnB><a:lnTlToBr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnTlToBr><a:lnBlToTr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnBlToTr><a:solidFill><a:srgbClr val="BBBCBC"><a:alpha val="73330"/></a:srgbClr></a:solidFill></a:tcPr></a:tc>';
	$cellMergeTotal.=$cellMerge;
}

$firstSlideReplaced=str_replace("SLIDE_TITLE_EXTRA_CELLS", $cellMergeTotal, $firstSlideReplaced);


$firstSlideReplaced=str_replace("ADD_HEADERS_HERE", $headerStuff, $firstSlideReplaced);

$rowToReplace;

$alreadyAdded = array();

if(!empty($reviewID))
{
	foreach($reviewID as $q=>$z)
	{
		if(empty($alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]))
		{
			$alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]=1;

			$rowToReplace.='<a:tr h="190500">';
				$rowToReplace.=calculateTableCell($z['program']);
				$rowToReplace.=calculateTableCell($z['coe']);
				$rowToReplace.=calculateTableCell($z['msn']);
				$rowToReplace.=calculateTableCell($z['ca']);
				$rowToReplace.=calculateTableCell($z['perimeter']);
				if(isset($z['sourcing']))
					$rowToReplace.=calculateTableCell($z['sourcing']);
				else
					$rowToReplace.=calculateTableCell();
				if(isset($z['odd']) && $z['odd'] != "0000-00-00")
					$rowToReplace.=calculateTableCell($z['odd']);
				else
					$rowToReplace.=calculateTableCell();
				if(isset($z['id']) && $z['id'] != "0000-00-00")
					$rowToReplace.=calculateTableCell($z['id']);
				else
					$rowToReplace.=calculateTableCell();
				if(isset($z['progress_trend']))
				{
					$progressTrendArray = split('_', $z['progress_trend']);
					$rowToReplace.=calculateTableCell($wingdingsMap[$progressTrendArray[0]], 'FFFFFF', 'Wingdings 3', $progressColourMap[$progressTrendArray[1]], '2400');
				}
				else
					$rowToReplace.=calculateTableCell();

				foreach ($reviewTypeNames as $reviewTypeSingle => $value) 
				{
					$reviewStatus = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle]['status'];
					$criteriaStatusTotal = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];
					if(isset($criteriaStatusTotal['total']) && isset($criteriaStatusTotal['assessment']))
					{
						if($criteriaStatusTotal['total'] != 0)
						{
							$overallTotalPercentage = number_format((float)(($criteriaStatusTotal['assessment']/$criteriaStatusTotal['total'])*100), 2, '.', '');
							$rowToReplace.=calculateTableCell($overallTotalPercentage.'%', $statusColourMap[$reviewStatus]);
						}
						else if(isset($reviewStatus))
						{
							$rowToReplace.=calculateTableCell(' ', $statusColourMap[$reviewStatus]);
						}
						else
						{
							$rowToReplace.=calculateTableCell('???');
						}
					}
					else if(isset($reviewStatus))
					{
						$rowToReplace.=calculateTableCell(' ', $statusColourMap[$reviewStatus]);
					}
					else
					{
						$rowToReplace.=calculateTableCell();
					}
				}
			$rowToReplace.='</a:tr>';

		}
	}
}

$firstSlideReplaced=str_replace("ADD_ROWS_HERE", $rowToReplace, $firstSlideReplaced);











//SECOND SLIDE
//------------------------------------------------------------

$secondSlide  		= file_get_contents('../archive/OVERVIEW_HELP_FILES/slide2.xml');
$secondSlideRels 	= file_get_contents('../archive/OVERVIEW_HELP_FILES/slide2.xml.rels');


$secondSlideArray = array();

$alreadyAdded=array();

if(!empty($reviewID))
{
	foreach($reviewID as $q=>$z)
	{
		if(empty($alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]))
		{
			$alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]=1;

			$secondSlideReplace = str_replace("SLIDE_TITLE_HERE", formatValueForXML($z['program']).' - '.formatValueForXML($z['coe']).' - '.formatValueForXML($z['msn']).' - '.formatValueForXML($z['perimeter']).' - '.formatValueForXML($z['ca']), $secondSlide);
		
			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['odd']['odd']))
				$secondSlideReplace = str_replace("ODD_HERE", $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['odd']['odd'], $secondSlideReplace);
			else
				$secondSlideReplace = str_replace("ODD_HERE", ' ', $secondSlideReplace);

			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['id']['id']))
				$secondSlideReplace = str_replace("ID_HERE", $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['id']['id'], $secondSlideReplace);
			else
				$secondSlideReplace = str_replace("ID_HERE", ' ', $secondSlideReplace);

			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend']))
			{
				$progressTrendArray = split('_', $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend']);
				$secondSlideReplace = str_replace("PROGRESS_TREND_CELL_HERE", calculateTableCell($wingdingsMap[$progressTrendArray[0]], 'FFFFFF', 'Wingdings 3', $progressColourMap[$progressTrendArray[1]], '2400'), $secondSlideReplace);
			}
			else
				$secondSlideReplace = str_replace("PROGRESS_TREND_CELL_HERE", calculateTableCell(), $secondSlideReplace);

			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total']))
				$secondSlideReplace = str_replace("NUMBER_OF_RISKS_HERE", $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total'], $secondSlideReplace);
			else
				$secondSlideReplace = str_replace("NUMBER_OF_RISKS_HERE", '0', $secondSlideReplace);

			if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing']))
				$secondSlideReplace = str_replace("NUMBER_OF_OPEN_RISKS_HERE", $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing'], $secondSlideReplace);
			else
				$secondSlideReplace = str_replace("NUMBER_OF_OPEN_RISKS_HERE", '0', $secondSlideReplace);



			$rowToReplace='';

			foreach ($reviewTypeNames as $reviewTypeSingle => $value) 
			{

				$reviewStatus = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle]['status'];
				$criteriaStatusTotal = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];

				$rowToReplace.='<a:tr h="190500">';
					$rowToReplace.=calculateTableCell($reviewTypeSingle);

					if(isset($criteriaStatusTotal['total']) && isset($criteriaStatusTotal['assessment']))
					{
						if($criteriaStatusTotal['total'] != 0)
						{
							//$text = ' ', $colour='FFFFFF', $font='Calibri', $fontColour='000000', $size='1200'
							$overallTotalPercentage = number_format((float)(($criteriaStatusTotal['assessment']/$criteriaStatusTotal['total'])*100), 2, '.', '');
							$rowToReplace.=calculateTableCell($statusWordMap[$reviewStatus].' - '.$overallTotalPercentage.'%', $statusColourMap[$reviewStatus]);
						}
						else if(isset($reviewStatus))
						{
							$rowToReplace.=calculateTableCell($statusWordMap[$reviewStatus], $statusColourMap[$reviewStatus]);
						}
						else
						{
							$rowToReplace.=calculateTableCell('???');
						}
					}
					else if(isset($reviewStatus))
					{
						$rowToReplace.=calculateTableCell($statusWordMap[$reviewStatus], $statusColourMap[$reviewStatus]);
					}
					else
					{
						$rowToReplace.=calculateTableCell('Not Performed');
					}

					if(isset($criteriaStatusTotal['action_total']))
						$rowToReplace.=calculateTableCell($criteriaStatusTotal['action_total']);
					else
						$rowToReplace.=calculateTableCell('0');

					if(isset($criteriaStatusTotal['action_total_ongoing']))
						$rowToReplace.=calculateTableCell($criteriaStatusTotal['action_total_ongoing']);
					else
						$rowToReplace.=calculateTableCell('0');


					$rowToReplace.='<a:tc gridSpan="2"><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr marL="0" marR="0" lvl="0" indent="0" algn="l" fontAlgn="base"/><a:endParaRPr/></a:p></a:txBody><a:tcPr><a:lnL w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnL><a:lnR w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnR><a:lnT w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnT><a:lnB w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnB><a:lnTlToBr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnTlToBr><a:lnBlToTr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnBlToTr></a:tcPr></a:tc><a:tc hMerge="1"><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr marL="0" marR="0" lvl="0" indent="0" algn="l" fontAlgn="base"/><a:endParaRPr/></a:p></a:txBody><a:tcPr><a:lnL w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnL><a:lnR w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnR><a:lnT w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnT><a:lnB w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="000000"><a:alpha val="100000"/></a:srgbClr></a:solidFill><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnB><a:lnTlToBr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnTlToBr><a:lnBlToTr w="12700" cap="flat" cmpd="sng" algn="ctr"><a:noFill/><a:prstDash val="solid"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/></a:lnBlToTr></a:tcPr></a:tc>';


				$rowToReplace.='</a:tr>';
			}

			$secondSlideReplace = str_replace("REVIEW_TYPE_ACTION_ROWS_HERE", $rowToReplace, $secondSlideReplace);



			$rowToReplace='';

			//
			//Risks
			//
			foreach ($statusColourMap as $statusNumber => $colour) 
			{
				//JFM 19_07_16 if($statusNumber < 2)
				//JFM 19_07_16 {
					if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']))
					{
						foreach ($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks'] as $riskStatusKey => $value) 
						{
							if($riskStatusKey == 'risk_'.$statusNumber)
							{
								$splitRisks = split('-!-',$value);

								for ($i=0; $i < count($splitRisks); $i++) 
								{
									if($splitRisks[$i] != '' && isset($splitRisks[$i]))
									{
										$rowToReplace.='<a:tr h="190500">';

										$splitRisksColumns = split('---', $splitRisks[$i]);

										for ($j=0; $j < count($splitRisksColumns); $j++) 
										{
											if($splitRisksColumns[$j] != '' && isset($splitRisksColumns[$j]))
											{
												if($j==0)
												{
													//JFM FIX ME!!!!
													$rowToReplace.=calculateTableCell($statusWordMap[$statusNumber].'<w:br/>'.$splitRisksColumns[$j],$colour);
												}
												else
												{
													$rowToReplace.=calculateTableCell($splitRisksColumns[$j]);
												}
											}
											else
											{
												$rowToReplace.=calculateTableCell();
											}
										}

										$rowToReplace.='</a:tr>';
									}
								}
							}
						}
					}
				//JFM 19_07_16 }
			}
			

			$secondSlideReplace = str_replace("RISK_ROWS_HERE", $rowToReplace, $secondSlideReplace);


			$rowToReplace='';

			//
			//Actions
			//
			foreach ($statusColourMap as $statusNumber => $colour) 
			{
				//JFM 19_07_16 if($statusNumber < 2)
				//JFM 19_07_16 {
					foreach ($reviewTypeNames as $reviewTypeSingle => $value) 
					{
						$actionTotalsShort = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];

						if(isset($actionTotalsShort['action_'.$statusNumber]))
						{
							$splitActions = split('-!-', $actionTotalsShort['action_'.$statusNumber]);

							for ($i=0; $i < count($splitActions); $i++) 
							{
								if($splitActions[$i] != '' && isset($splitActions[$i]))
								{
									$rowToReplace.='<a:tr h="190500">';

									$splitActionColumns = split('---', $splitActions[$i]);

									for ($j=0; $j < count($splitActionColumns); $j++) 
									{ 
										if($splitActionColumns[$j] != '' && isset($splitActionColumns[$j]))
										{
											if($j==0)
											{
												$rowToReplace.=calculateTableCell($statusWordMap[$statusNumber].'<w:br/>'.$splitActionColumns[$j],$colour);
											}
											else
											{
												$rowToReplace.=calculateTableCell($splitActionColumns[$j]);
											}
										}
										else
										{
											$rowToReplace.=calculateTableCell();
										}
									}

									$rowToReplace.='</a:tr>';
								}
							}
						}
					}
				//JFM 19_07_16 }
			}

			$secondSlideReplace = str_replace("ACTION_ROWS_HERE", $rowToReplace, $secondSlideReplace);


			$secondSlideArray[] = $secondSlideReplace;

		}
	}
}




//GENERATE ZIP
//------------------------------------------------------------

$slidesFolderLocation;

$zip = new zipfile();

$source=str_replace('\\', '/', realpath('../archive/OVERVIEW_TEMPLATE/'));
$flag=basename($source).'/';

$files= new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source),RecursiveIteratorIterator::SELF_FIRST);

foreach($files as $file)
{
	$file=str_replace('\\', '/', realpath($file));
	
	if(is_dir($file)===true)
	{
		//Do nothing
	}
	else if(is_file($file))
	{
		if(strpos($file, 'slide1')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($firstSlideReplaced, str_replace($source.'/', '', $file));
		}
		else if(strpos($file, 'slide2')  && !strpos($file, 'rels')) 
		{
			if(!empty($secondSlideArray))
			{
				$i=2;
				foreach ($secondSlideArray as $hopeThisWorks) 
				{
					$zip->addFile($hopeThisWorks, str_replace($source.'/', '', str_replace('slide2', 'slide'.$i, $file)));
					$i++;
				}
			}
		}
		else if(strpos($file, 'slide2')  && strpos($file, 'rels')) 
		{
			if(!empty($secondSlideArray))
			{
				$i=2;
				foreach ($secondSlideArray as $hopeThisWorks) 
				{
					$zip->addFile($secondSlideRels, str_replace($source.'/', '', str_replace('slide2', 'slide'.$i, $file)));
					$i++;
				}
			}
		}
		else if(strpos($file, 'Content_Types')  && !strpos($file, 'rels')) 
		{
			$contentTypes = file_get_contents('../archive/OVERVIEW_HELP_FILES/[Content_Types].xml');
			$newSlides='';

			if(!empty($secondSlideArray))
			{
				$i=2;
				foreach ($secondSlideArray as $hopeThisWorks) 
				{
					$newSlides.='<Override PartName="/ppt/slides/slide'.$i.'.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>';
					$i++;
				}
			}

			$contentTypesReplaced=str_replace("NEW_SLIDES_HERE", $newSlides, $contentTypes);

			$zip->addFile($contentTypesReplaced, str_replace($source.'/', '', $file));
		}
		else if(strpos($file, 'presentation')  && !strpos($file, 'rels')) 
		{
			$contentTypes = file_get_contents('../archive/OVERVIEW_HELP_FILES/presentation.xml');
			$newSlides='';

			if(!empty($secondSlideArray))
			{
				$i=8;
				$j=260;
				foreach ($secondSlideArray as $hopeThisWorks) 
				{
					$newSlides.='<p:sldId id="'.$j.'" r:id="rId'.$i.'"/>';
					$i++;
					$j++;
				}
			}

			$contentTypesReplaced=str_replace("NEW_SLIDE_REF_HERE", $newSlides, $contentTypes);

			$zip->addFile($contentTypesReplaced, str_replace($source.'/', '', $file));
		}
		else if(strpos($file, 'presentation')  && strpos($file, 'rels')) 
		{
			$contentTypes = file_get_contents('../archive/OVERVIEW_HELP_FILES/presentation.xml.rels');
			$newSlides='';

			if(!empty($secondSlideArray))
			{
				$i=8;
				$j=2;
				foreach ($secondSlideArray as $hopeThisWorks) 
				{
					$newSlides.='<Relationship Id="rId'.$i.'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide'.$j.'.xml"/>';
					$i++;
					$j++;
				}
			}

			$contentTypesReplaced=str_replace("NEW_SLIDES_HERE", $newSlides, $contentTypes);

			$zip->addFile($contentTypesReplaced, str_replace($source.'/', '', $file));
		}

		else $zip->addFile(file_get_contents($file), str_replace($source.'/', '', $file));
	}
}



$filename="art_overview_export_".date('Y_m_d_H_i_s');

file_put_contents('../output/'.$filename.'.pptx', $zip->file());


echo 'OK|||'.$filename;


?>