<?php
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('localSupport.php');
require_once('form.php');
require_once('zipfile.php');
$POST=cleanArray($_POST);

function generateXdpFile($reviewProfile,$ca,$target,$raiseIssue,$SESSION){
	$caArray=explode(',',$ca);
	$a0Status=array(0,2,1,3);
	$a0Ids=array();
	
	do{
		$xmlKey=randomString(32);
	}while(SqlQ('SELECT a0_report_id FROM dr_a0_report WHERE xml_lock="'.$xmlKey.'"'));
	
	$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];

	$actualIssueQry=SqlMAsArr('SELECT ca,a0_report_issue FROM dr_a0_report WHERE msn='.getFilter('msn','filter',0,$SESSION).' AND ca IN('.$ca.') AND review_profile='.$reviewProfile,'ca','a0_report_issue');
	
	foreach($caArray as $c){
		$actualMaxIssue[$c]=(is_array($actualIssueQry[$c]))?max($actualIssueQry[$c]):0;
		
		SqlLQ('INSERT INTO dr_a0_report (msn,ca,review_profile,a0_report_issue,a0_report_creation,xml_lock,user)
			VALUES ('.getFilter('msn','filter',0,$SESSION).','.$c.','.$reviewProfile.','.($actualMaxIssue[$c]+$raiseIssue).',NOW(),"'.$xmlKey.'",'.$viewAsUserId.')');

		$a0Id=SqlQ('SELECT LAST_INSERT_ID()'); //JFM 07_04_14
		array_push($a0Ids,$a0Id['LAST_INSERT_ID()']); //JFM 07_04_14
	}
	
	$programTxt=SqlQ('SELECT program FROM c_program WHERE program_id='.getFilter('program','filter',0,$SESSION));
	$coeTxt=SqlQ('SELECT coe FROM c_coe WHERE coe_id='.getFilter('coe','filter',0,$SESSION));
	
	$caName=SqlAsLi('SELECT ca_id,ca,ca_description FROM c_ca WHERE ca_id IN ('.$ca.')','ca_id');
	foreach($caName as $caId=>$caDetails){
		$caNameStringArray[]=$caDetails['ca'];
		$caDescriptionArray[]=$caDetails['ca_description'];
	}
	$caNameString=implode(', ',$caNameStringArray);
	$caDescription=implode(', ',$caDescriptionArray);
	
	$wpQry=SqlLi('SELECT w.wp_id,w.wp,w.wp_description,
							cw.ca
						FROM c_wp AS w
							INNER JOIN c_cawp AS cw ON w.wp_id=cw.wp
						WHERE cw.ca IN ('.$ca.') AND cw.msn='.getFilter('msn','filter',0,$SESSION));
	
	if(is_array($wpQry)){
		foreach($wpQry as $w){
			$wpA[]=$w['wp_id'];
			$wpNameA[$w['wp_id']]=$w['wp'];
			$caInWp[$w['wp_id']][]=$w['ca'];
			if($w['wp_description']==''){
				$w['wp_description']='N/A';
			}
			$wpDescriptionArray[$w['wp_id']]=$w['wp_description'];
		}
	}
	
	$wp=implode(',',$wpA);
	$wpName=implode(', ',$wpNameA);
	$wpDescription=implode(', ',$wpDescriptionArray);
	
	$imageFile=SqlQ('SELECT '.$target.'_image_file FROM c_'.$target.' WHERE '.$target.'_id IN ('.$$target.')');
	
	$caWpDescription=($target=='ca')?$caDescription:$wpDescription;
	
	$reviewName=$SESSION['review_type'][$reviewProfile];
	
	//JFM 14_11_13 - START
	$overallStatus=SqlQ('SELECT r.review_status
						FROM dr_review AS r
							INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
						WHERE ra.ca IN('.$ca.')
							AND r.msn='.getFilter('msn','filter',0,$SESSION).'
							AND r.review_profile='.$reviewProfile);
							
	$msnName=SqlQ('SELECT msn FROM c_msn WHERE msn_id='.getFilter('msn','filter',0,$SESSION));

	$perimeterName=SqlQ('SELECT per.perimeter 
							FROM c_perimeter  AS per
							INNER JOIN c_program AS pro ON pro.program_id=per.program
							INNER JOIN c_ca AS ca ON ca.perimeter=per.perimeter_id
						WHERE ca.ca_id IN('.$ca.')
						AND pro.program_id='.getFilter('program','filter',0,$SESSION));
	
	$responsible=getResponsibles(getFilter('program','filter',0,$SESSION),$SESSION,1,$ca,'');

	$reviewID=SqlLi('SELECT review_id, validation_date, remark, planned, review_date, delta, delta_planned, cabin_ve_name, cabin_ve_status, cabin_ve_remarks
						FROM dr_review AS r
							INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
							INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
						WHERE rp.review_profile_id='.$reviewProfile.'
						AND ra.ca IN ('.$ca.')
						AND r.msn='.getFilter('msn','filter',0,$SESSION));
	
	//JFM 09_04_14
	$group=SqlLi('SELECT DISTINCT rg.group_id, rgh.review_group_description, rgh.review_group_position
					FROM dr_review_group AS rg
						INNER JOIN 
									(
										SELECT review_group,review_group_description,review_group_position,review_group_valid_from 
												FROM dr_review_group_history 
												WHERE review_group_valid_from <= "'.$reviewID[0]['validation_date'].'" 
												ORDER BY review_group_valid_from DESC
									) AS rgh ON rgh.review_group=rg.group_id 
						INNER JOIN dr_review_profile AS rp ON rg.review_type=rp.review_type
						INNER JOIN dr_review_criterion AS rc ON rc.review_group=rg.group_id
					WHERE rp.review_profile_id='.$reviewProfile.'
					GROUP BY rgh.review_group
					ORDER BY review_group_position ASC');
						
	//JFM 09_04_14
	$criteria=SqlBDAsArr('SELECT DISTINCT rgh.review_group,rgh.review_group_description,rgh.review_group_position,
											rconf.disabled, rconf.position AS criterion_position,
											rc.review_criterion_id, rch.criterion_name, rch.criterion_description, rch.criterion_user_id, rch.criterion_showstopper, rch.criterion_moc, rch.criterion_valid_from,
											GROUP_CONCAT(g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS criterion_reference
							FROM dr_review_criterion_history AS rch 
								INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
								INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
								INNER JOIN 
											(
												SELECT review_group,review_group_description,review_group_position,review_group_valid_from 
														FROM dr_review_group_history 
														WHERE review_group_valid_from <= "'.$reviewID[0]['validation_date'].'" 
														ORDER BY review_group_valid_from DESC
											) AS rgh ON rgh.review_group=rg.group_id 
								INNER JOIN dr_review_configuration	AS rconf	ON rc.review_criterion_id = rconf.criterion
								INNER JOIN dr_review				AS r		ON r.review_id=rconf.review
								INNER JOIN dr_review_applicability	AS ra		ON r.review_id=ra.review
								INNER JOIN dr_review_profile		AS rp 		ON rp.review_profile_id=r.review_profile
								LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
								LEFT  JOIN c_grams					AS g		ON	rca.applicability=g.grams_id
																				AND	rca.object='.$SESSION['object']['grams_id'].'
																				AND rca.review_criterion_applicability_valid_from <= "'.$reviewID[0]['validation_date'].'"
							WHERE rp.review_profile_id='.$reviewProfile.'
							AND ra.ca IN ('.$ca.')
							AND r.msn='.getFilter('msn','filter',0,$SESSION).'
							AND rch.criterion_valid_from <= "'.$reviewID[0]['validation_date'].'"
							AND rch.criterion_valid_from != "0000-00-00 00:00:00"
							GROUP BY rch.criterion_validity_id
							ORDER BY rgh.review_group_position ASC, rconf.position ASC',
							'review_group','review_criterion_id');
	
	foreach($criteria as $reviewGroup=>$reviewCriteron)
	{
		foreach($reviewCriteron as $q=>$c)
		{				
			$array1=explode(", ",$c['criterion_reference']);

			$array1=array_unique($array1); //JFM 02_04_14
					
			$criteria[$reviewGroup][$q]['criterion_reference']='';
		
			foreach($array1 as $a1)
			{
				$array2=explode("---",$a1);
	
				if($array2[1]=='0000-00-00 00:00:01' && $criteria[$reviewGroup][$q]['criterion_valid_from']=="0000-00-00 00:00:00") continue;
				if($array2[2]=='0000-00-00 00:00:00' && $criteria[$reviewGroup][$q]['criterion_valid_from']!="0000-00-00 00:00:00") continue;
				if($reviewID[0]['validation_date']=="9999-12-31 00:00:00" && $array2[1]!='0000-00-00 00:00:00'  && $array2[1]!='0000-00-00 00:00:01') continue;
				else 
				{
					if(empty($criteria[$reviewGroup][$q]['criterion_reference'])) $criteria[$reviewGroup][$q]['criterion_reference']=$array2[0];
					else $criteria[$reviewGroup][$q]['criterion_reference']=$criteria[$reviewGroup][$q]['criterion_reference'].', '.$array2[0];
				}
			}
		}
	}

	$criteriaStatus=SqlAsLi('SELECT review_criteria,criteria_status_id,criteria_status,criteria_focal_point,criteria_comments
								FROM dr_criteria_status
								WHERE ca IN('.$ca.')
									AND msn='.getFilter('msn','filter',0,$SESSION),
								'review_criteria');
	
	$action=SqlBDAsArr('SELECT ac.action_id,ac.criteria,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_closure,ac.action_status,ac.action_holder,ac.action_holder_name,ac.action_validator,ac.action_validator_name,
									rd.rid_id,rd.rid_code,rd.rid_title,rd.rid_status,rd.rid_holder,rd.rid_holder_name,rd.rid_validator,rd.rid_validator_name,rd.rid_creation,rd.rid_completion,rd.rid_closure,rd.rid_showstopper,rd.rid_action_plan,
									GROUP_CONCAT(ca.ca_id SEPARATOR ",") AS action_applicability_id,
									CONCAT(u1.surname,", ",u1.name) AS action_holder_txt,
									CONCAT(u2.surname,", ",u2.name) AS action_validator_txt,
									CONCAT(u3.surname,", ",u3.name) AS rid_holder_txt,
									CONCAT(u4.surname,", ",u4.name) AS rid_validator_txt
								FROM dr_action							AS ac
									INNER JOIN	dr_action_applicability	AS ap ON ac.action_id			=ap.action
									INNER JOIN	c_ca					AS ca ON ap.ca					=ca.ca_id
									INNER JOIN	dr_review_criterion		AS cr ON ac.criteria			=cr.review_criterion_id
									INNER JOIN	dr_review_group			AS gr ON cr.review_group		=gr.group_id
									INNER JOIN	dr_review_profile		AS rp ON gr.review_type			=rp.review_type
									LEFT JOIN	dr_rid					AS rd ON ac.rid					=rd.rid_id
									LEFT JOIN	c_user					AS u1 ON ac.action_holder		=u1.user_id
									LEFT JOIN	c_user					AS u2 ON ac.action_validator	=u2.user_id
									LEFT JOIN	c_user					AS u3 ON rd.rid_holder			=u3.user_id
									LEFT JOIN	c_user					AS u4 ON rd.rid_validator		=u4.user_id
								WHERE ap.ca IN('.$ca.')
									AND ac.msn='.getFilter('msn','filter',0,$SESSION).'
									AND rp.review_profile_id='.$reviewProfile.'
								GROUP BY ac.action_id
								ORDER BY rd.rid_id ASC',
							'criteria','action_id');

	$totalActionsAndRids=array();
	$ridIdUsed=array();

	if(!empty($action))
	{
		foreach ($action as $actionKey => $actionValue) 
		{
			foreach ($actionValue as $actualActionKey => $actualActionValue) 
			{
				switch ($actualActionValue['action_status'])
				{
					case '0':
						$totalActionsAndRids['action_red']++;
					break;

					case '1':
						$totalActionsAndRids['action_amber']++;
					break;

					case '2':
						$totalActionsAndRids['action_green']++;
					break;

					case '3':
						$totalActionsAndRids['action_blue']++;
					break;
				}

				if(!in_array($actualActionValue['rid_id'], $ridIdUsed))
				{
					switch ($actualActionValue['rid_status'])
					{
						case '0':
							$totalActionsAndRids['rid_red']++;
							array_push($ridIdUsed, $actualActionValue['rid_id']);
						break;

						case '1':
							$totalActionsAndRids['rid_amber']++;
							array_push($ridIdUsed, $actualActionValue['rid_id']);
						break;

						case '2':
							$totalActionsAndRids['rid_green']++;
							array_push($ridIdUsed, $actualActionValue['rid_id']);
						break;

						case '3':
							$totalActionsAndRids['rid_blue']++;
							array_push($ridIdUsed, $actualActionValue['rid_id']);
						break;
					}
				}
			}
		}
	}
									
	//JFM 14_11_13 - END
	
	
	if($imagePath=='' && $imageFile[$target.'_image_file']!='' && file_exists('../img/'.$target.'/'.$imageFile[$target.'_image_file'])){
		$imagePath='../img/'.$target.'/'.$imageFile[$target.'_image_file'];
	}else $imagePath='../../common/img/mainLogo.png';

	$fileHandle=fopen($imagePath,'rb');
	$imageContent=fread($fileHandle,filesize($imagePath)); 
	fclose($fileHandle); 
	$imageEncoded=chunk_split(base64_encode($imageContent));
		
	@date_default_timezone_set("GMT"); 
	$writer = new XMLWriter();
	$tempFileName=newFileName('../output/','xml',16);
	
	touch($tempFileName);
	$tempFileName=realpath($tempFileName);
	
	$writer->openURI($tempFileName); 
	$writer->setIndent(4);  
	$writer->startElement("A0Report");
		$writer->startElement("part");

			//JFM 19_07_16
			$writer->writeElement('criterion-moc-header',$SESSION['table']['cat']['cat']['criterion_moc']['title']);
			$writer->writeElement('criterion-description-header',$SESSION['table']['cat']['cat']['criterion_description']['title']);

			$writer->writeElement('review_planned_date-header',$SESSION['table']['review_planning']['review']['planned']['title'].':');
			$writer->writeElement('review_actual_date-header',$SESSION['table']['review_planning']['review']['review_date']['title'].':');
			$writer->writeElement('review_delta_date-header',$SESSION['table']['review_planning']['review']['delta']['title'].':');
			$writer->writeElement('review_planned_delta_date-header',$SESSION['table']['review_planning']['review']['delta_planned']['title'].':');
			$writer->writeElement('ca-header',$SESSION['table']['review_planning']['ca']['ca']['title'].':');
			$writer->writeElement('wp-header',$SESSION['table']['review_planning']['ca']['wp']['title'].':');
			
			$writer->writeElement('ca_id',$ca);
			$writer->writeElement('ca',$caNameString);
			
			$writer->writeElement('wp_id',$wp);
			$writer->writeElement('wp',$wpName);
			
			$writer->writeElement('name',$caWpDescription);
			$writer->writeElement('ca_description',$caDescription);
			$writer->writeElement('wp_description',$wpDescription);

			$writer->startElement("draft");
				$writer->writeAttribute('xmlns:xf','http://www.w3.org/2002/xforms');
				$writer->writeAttribute('xf:base64Binary',$imageEncoded);
			$writer->endElement();
			
			$writer->writeElement('clash','');
			
			$writer->writeElement('issue',chr($a0Report['a0_report_issue']+65));
			
			$writer->writeElement('issue_nb','00');
			$writer->writeElement('issuedate',date("d.m.Y"));
			$writer->writeElement('program_id',getFilter('program','filter',0,$SESSION));
			$writer->writeElement('program',$programTxt['program']);
			$writer->writeElement('coe_id',getFilter('coe','filter',0,$SESSION));
			$writer->writeElement('coe',$coeTxt['coe']);
			$writer->writeElement('type_id',$reviewName);
			$writer->writeElement('type',$reviewName);
			$writer->writeElement('review_profile_id',$reviewProfile);
			$writer->writeElement('msn_id',getFilter('msn','filter',0,$SESSION));
			$writer->writeElement('MSN',$msnName['msn']);
			$writer->writeElement('perimeter',$perimeterName['perimeter']);
			$writer->writeElement('offRef',$reviewID[0]['reference']); //JFM 07_04_14
			$writer->writeElement('remarks',strip_tags(str_replace('<BR>', "\n",  $reviewID[0]['remark']))); //JFM 11_03_14
			
			$writer->writeElement('key', $xmlKey);
			$writer->writeElement('ovStat',$overallStatus['review_status']);

			$writer->writeElement('total_action_red',$totalActionsAndRids['action_red']);
			$writer->writeElement('total_action_amber',$totalActionsAndRids['action_amber']);
			$writer->writeElement('total_action_green',$totalActionsAndRids['action_green']);
			$writer->writeElement('total_action_blue',$totalActionsAndRids['action_blue']);
			$writer->writeElement('total_rid_red',$totalActionsAndRids['rid_red']);
			$writer->writeElement('total_rid_amber',$totalActionsAndRids['rid_amber']);
			$writer->writeElement('total_rid_green',$totalActionsAndRids['rid_green']);
			$writer->writeElement('total_rid_blue',$totalActionsAndRids['rid_blue']);

			$writer->writeElement('review_planned_date',$reviewID[0]['planned']);
			$writer->writeElement('review_actual_date',$reviewID[0]['review_date']);
			$writer->writeElement('review_delta_date',$reviewID[0]['delta']);
			$writer->writeElement('review_planned_delta_date',$reviewID[0]['delta_planned']); //JFM 19_07_16

			
			for($g=1;$g<=6;$g++){
				$rMax=($g==4)?8:4;
				if($g<=4){
					$writer->startElement('responsiblegroup_'.$g);
						$writer->writeAttribute('respgroupname',$responsible['group'][$g]);
		
						for($r=1;$r<$rMax;$r++){
							$writer->startElement('responsible_'.$g.'_'.$r);
								$writer->writeElement('role',$responsible['role'][$g][$r]);
								$writer->writeElement('name',$responsible['name'][$g][$r]);
							$writer->endElement();
						}
					$writer->endElement();
				}
				for($r=1;$r<$rMax;$r++){
					if($responsible['role'][$g][$r]=='Manufacturing Company'){
						$manufacturer=$responsible['name'][$g][$r];
					}
				}
			}
	
			$i=1;
			if(is_array($responsible['reviewPanel'])){
				foreach($responsible['reviewPanel'] as $rp){
					$writer->writeElement('reviewPanelMember_'.$i,$rp);
					$i++;
				}
			}
			
			$writer->writeElement('manufacturer',$manufacturer);
		 
		$writer->endElement(); 

		$writer->startElement('sign');
			$writer->startElement('person');
				$writer->writeElement('name','');
				$writer->writeElement('depart','');
				$writer->writeElement('signdate','');
			$writer->endElement();
			$writer->startElement('person');
				$writer->writeElement('name','');
				$writer->writeElement('depart','');
				$writer->writeElement('signdate','');
			$writer->endElement();
		$writer->endElement();
		
		$writer->startElement('ddList');
			$writer->startElement('ddEl');
				$writer->writeElement('ddName','All CA');
				$writer->writeElement('ddVal',$ca);
			$writer->endElement();

			foreach($wpNameA as $wpId=>$wpNameTxt){
				if(is_array($caInWp[$wpId])){
					$writer->startElement('ddEl');
						$writer->writeElement('ddName','WP: '.$wpNameTxt);
						$writer->writeElement('ddVal',implode(',',$caInWp[$wpId]));
					$writer->endElement();
				}
			}
			
			foreach($caName as $caId=>$caDetails){
				$writer->startElement('ddEl');
					$writer->writeElement('ddName','CA: '.$caDetails['ca']);
					$writer->writeElement('ddVal',$caId);
				$writer->endElement();
			}
		$writer->endElement();

		$typesOfStatus=array('review_status', 'criteria_status', 'action_status', 'rid_status');
		$statusMap=array(0 => 'R', 2 => 'A', 1 => 'G', 3 => 'B');

		//JFM 08_06_16
		$writer->startElement('allowedStatusList');

			foreach ($typesOfStatus as $value) 
			{	
				if($SESSION['disabled_statues'][$SESSION['object'][$value]][0] != 1)
				{		
					$writer->startElement($value);
						$writer->writeElement('name','R');
						$writer->writeElement('value',0);
					$writer->endElement();
				}
				if($SESSION['disabled_statues'][$SESSION['object'][$value]][1] != 1)
				{		
					$writer->startElement($value);
						$writer->writeElement('name','A');
						$writer->writeElement('value',2);
					$writer->endElement();
				}
				if($SESSION['disabled_statues'][$SESSION['object'][$value]][2] != 1)
				{		
					$writer->startElement($value);
						$writer->writeElement('name','G');
						$writer->writeElement('value',1);
					$writer->endElement();
				}
				if($SESSION['disabled_statues'][$SESSION['object'][$value]][3] != 1)
				{		
					$writer->startElement($value);
						$writer->writeElement('name','B');
						$writer->writeElement('value',3);
					$writer->endElement();
				}
			}

		$writer->endElement();
	
		$writer->startElement("topic-list");

		foreach($group as $g){
			/* JFM 14_11_13
			$visibleCriteria=0;
			foreach($criteria[$g['group_id']] as $c){
				if($reviewConfiguration[$c['review_criterion_id']]!=2){
					$visibleCriteria=1;
				}
			}*/
			$visibleCriteria=1; //JFM 14_11_13
			if($visibleCriteria==1){
				if(!$criteria[$g['group_id']]) continue; // JFM 18_11_13 - JFM 06_01_14
				$writer->startElement("topic");
					$writer->writeAttribute('name',$g['review_group_description']);
					foreach($criteria[$g['group_id']] as $c){
						//if($reviewConfiguration[$c['review_criteria_id']]!=2){
							if($c['disabled']==1){
								$criteriaStatus[$c['review_criterion_id']]['criteria_status']=1;
								$criteriaStatus[$c['review_criterion_id']]['criteria_comments']='NOT APPLICABLE';
							}else{
								$criteriaStatus[$c['review_criterion_id']]['criteria_status']=$a0Status[$criteriaStatus[$c['review_criterion_id']]['criteria_status']];
							}
							
							$writer->startElement("case");
								$writer->writeAttribute('status',$criteriaStatus[$c['review_criterion_id']]['criteria_status']);
								$writer->writeAttribute('number',$c['criterion_user_id']); //JFM 11_03_14
								$writer->writeElement('criteria_id',$c['review_criterion_id']);
								$writer->writeElement('description',$c['criterion_name']); // JFM 18_11_13
								$writer->writeElement('description_2',$c['criterion_description']); // JFM 18_11_13
								$writer->writeElement('moc',$c['criterion_moc']); // JFM 18_11_13
								$writer->writeElement('document','outstanding');
								$writer->writeElement('action_by',$criteriaStatus[$c['review_criterion_id']]['criteria_focal_point']);
								$writer->writeElement('comment',$criteriaStatus[$c['review_criterion_id']]['criteria_comments']);
								$writer->writeElement('reference',$c['criterion_reference']);
								$writer->writeElement('criterion_showstopper',$c['criterion_showstopper']);
								
								$openRid=0;
								$lastRid='x';
								
								if(is_array($action[$c['review_criterion_id']])){
									foreach($action[$c['review_criterion_id']] as &$a){
										if($a['rid_id']!=$lastRid || $a['rid_id']==''){
											$openRid=1;
											if($lastRid!='x'){
												$writer->endElement();
											}
											$writer->startElement("rid");
												$writer->writeAttribute('ridid',$a['rid_id']);
												$writer->writeElement('ridcode',$a['rid_code']);
												$writer->writeElement('ridtitle',$a['rid_title']);
												$writer->writeElement('ridstatus',$a0Status[$a['rid_status']]);
												$writer->writeElement('ridholder',($a['rid_holder_txt'])?$a['rid_holder_txt']:$a['rid_holder_name']);
												$writer->writeElement('ridvalidator',($a['rid_validator_txt'])?$a['rid_validator_txt']:$a['rid_validator_name']);
												$writer->writeElement('ridholderid',$a['rid_holder']);
												$writer->writeElement('ridvalidatorid',$a['rid_validator']);
												$writer->writeElement('rid_creation_date',$a['rid_creation']);
												$writer->writeElement('rid_completion_date',$a['rid_completion']);
												$writer->writeElement('rid_closure_date',$a['rid_closure']);
												$writer->writeElement('ridshowstopper',$a['rid_showstopper']);
												$writer->writeElement('ridactionplan',$a['rid_action_plan']);
										}
										$writer->startElement("action");
											$writer->writeAttribute('act_status',$a0Status[$a['action_status']]);
											$writer->writeAttribute('act_reference',$a['action_code']);
											$writer->writeElement('action_id',$a['action_id']);
											$writer->startElement('WPCAApp');
												$actionApplicability=explode(',',$a['action_applicability_id']);
												foreach($actionApplicability as $aa)$writer->writeElement('value',$aa);
											$writer->endElement();
											$writer->writeElement('actiondescription',$a['action_description']);
											$writer->writeElement('actioncreationdate',$a['action_creation']);
											$writer->writeElement('actionduedate',$a['action_completion']);
											$writer->writeElement('actionclosuredate',$a['action_closure']);
											$writer->writeElement('actionholder',($a['action_holder_txt'])?$a['action_holder_txt']:$a['action_holder_name']);
											$writer->writeElement('actionholderid',$a['action_holder']);
											$writer->writeElement('actionvalidator',($a['action_validator_txt'])?$a['action_validator_txt']:$a['action_validator_name']);
											$writer->writeElement('actionvalidatorid',$a['action_validator']);
										$writer->endElement();
										
										$lastRid=$a['rid_id'];
									}
								}
								if($openRid==1){
									$writer->endElement();
								}
							$writer->endElement();
						//}
					}
				$writer->endElement();
			}
		}

		//JFM 19_07_16
		if(getFilter('area','filter',0,$SESSION)==8)
		{		
			$writer->startElement("ecInfo");
				$writer->writeElement('name',$reviewID[0]["cabin_ve_name"]);
				$writer->writeElement('status',$reviewID[0]["cabin_ve_status"]);
				$writer->writeElement('remarks',$reviewID[0]["cabin_ve_remarks"]);
				$writer->writeElement('fulfilment','0');
			$writer->endElement();
		}
		else
		{
			$writer->startElement("ecInfo");
				$writer->writeElement('name',"DONOTWRITE");
				$writer->writeElement('status',"DONOTWRITE");
				$writer->writeElement('remarks',"DONOTWRITE");
				$writer->writeElement('fulfilment',"DONOTWRITE");
			$writer->endElement();
		}
	
	$writer->endElement();
	$writer->endDocument(); 
	$writer->flush();
	
	foreach($a0Ids as $a0Id) //JFM 07_04_14
	{
		createLog('dr_log','a0_report_id','create',$a0Id,'','',$SESSION);
	}
	
	$xdpStart="<?xml version='1.0' encoding='UTF-8'?>
	<?xfa generator='AdobeDesigner_V7.0' APIVersion='2.2.4333.0'?>
	<xdp:xdp xmlns:xdp='http://ns.adobe.com/xdp/'>
		<xfa:datasets xmlns:xfa='http://www.xfa.org/schema/xfa-data/1.0/'><xfa:data>";
	
	$xdpMid.='</xfa:data></xfa:datasets>
    <pdf xmlns="http://ns.adobe.com/xdp/pdf/"><document><chunk>';
	
	$pdfFilePath='../archive/a0report_review_template_v6-10.pdf';
	$pdfH=fopen($pdfFilePath,'rb');
	$pdfC=fread($pdfH,filesize($pdfFilePath));
	fclose($pdfH);
	$xdpPdf=chunk_split(base64_encode($pdfC));
	
	$xdpEnd.='</chunk></document></pdf></xdp:xdp>';
	
	$xdpFileName=newFileName('../output/','xdp',16);
	$fp=fopen($xdpFileName,'w');
	fwrite($fp,$xdpStart);
	fwrite($fp,utf8_encode(file_get_contents($tempFileName)));
	fwrite($fp,$xdpMid);
	fwrite($fp,$xdpPdf);
	fwrite($fp,$xdpEnd);
	fclose($fp);
	
	return $xdpFileName;
}
$xdpFile=array();

for($reportId=1;$reportId<=$POST['a0_report_count'];$reportId++){
	$xdpFile[$reportId]=generateXdpFile($POST['a0_report_review_profile'],$POST['a0_report_ca_'.$reportId],$POST['a0_report_target'],$POST['a0_report_raise_issue_'.$reportId],$SESSION);
}

$msnName=SqlQ('SELECT msn FROM c_msn WHERE msn_id='.getFilter('msn','filter',0,$SESSION));
$fileNameStart=str_replace(array(' ','/'),'_',$SESSION['review_type'][$POST['a0_report_review_profile']]).'_review_MSN_'.$msnName['msn'].'_'.date("Y-m-d");

if($POST['a0_report_count']==0) header("Location: ../home.php"); //JFM 06_01_14
else if($POST['a0_report_count']==1){
	download('xdp',$xdpFile[1],$fileNameStart.'_'.$POST['a0_report_ca_txt_1'].'.xdp');
}else{
	$xdpZipFile=new zipfile();
	foreach($xdpFile as $reportId=>$filePath){
		$xdpZipFile->add_file(implode("",file($filePath)),$fileNameStart.'_'.$POST['a0_report_ca_txt_'.$reportId].'.xdp'); 
	}
	download('zip',$xdpZipFile,$fileNameStart.'.zip');
}
storeSession($SESSION);
?>