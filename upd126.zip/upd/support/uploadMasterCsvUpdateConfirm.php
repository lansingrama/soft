<?php
/**
 * File to update the Database when Submit button is clicked on the Discrepancy page
 * Create By : Infosys Limited
 * Fix for : Improvement 2(minor)
 * Criteria Upload (Suggested by ICT)
 */

require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('form.php');

$POST = cleanArray($_REQUEST);

$removeArray = explode(',', $POST['remove']);
$csvArray = file_get_contents('php://input');
$newArray = json_decode($csvArray, true);

for($i=0; $i<count($removeArray); $i++) {
    foreach($newArray as $key => $value) {
        if($value['criterion_validity_id'] == $removeArray[$i]) {
            unset($newArray[$key]);
        }
    }    
}

foreach($newArray as $columnName => $value) {
    updateDatabase($SESSION, $value['criterion_user_id'], $value['criterion_name'], $value['criterion_description'], $value['criterion_showstopper'], $value['criterion_moc'], $value['review_group_description'], $value['review_group_position'], $value['grams_reference'], $value['criterion_validity_id'], $value['criterion_id'], $value['review_group']);    
}

$answer = 'update';
storeSession($SESSION);
echo 'OK|||'.$answer;
exit;
?>