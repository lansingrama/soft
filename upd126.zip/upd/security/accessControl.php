<?php
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');
//require_once('../../../ldap.php'); //JFM 09_04_14
require_once('../../ldap.php'); //JFM 09_04_14

$blockingTime=getBlockingTime();

if($blockingTime==0)
{
	foreach($_POST as $k=>$v)
	{
		if($k!="Password") $POST[$k]=addslashes(trim($v));
		else $POST[$k]=$v;
	}
	
	$login=$POST['User_Name'];
	$password=html_entity_decode($POST['Password']);
	$SESSION['user']=SqlQ("SELECT * FROM c_user WHERE login='$login'"); //JFM 02_04_14

	$toolId=SqlQ('SELECT tool_id FROM c_tool WHERE code="DR"');
	$SESSION['tool_id']=$toolId['tool_id'];

	$ldap_hostname = 'ldap://acdslan-vip-i.res.airbus.corp:3890';
	$ldap_search_dn = 'OU=Users,OU=1V55,OU=Apps,O=Airbus'; 
	$ldapConnect=ldap_auth($login,$password);

	if($ldapConnect=='LDAP_INVALID_USERNAME')
	{
		$ldap_hostname = 'ldap://acdslan-vip-i.res.airbus.corp:3890';
		$ldap_search_dn = 'OU=Users,OU=1V55,OU=Apps,O=Airbus';
		$ldapConnect=ldap_auth($login,$password);
	}
	
	if(strtoupper($SESSION['user']['login'])==strtoupper($login) && $ldapConnect=='LDAP_AUTH_OK' && $password!='')
	{
		if($SESSION['user']['confirmed']==0) SqlLQ('UPDATE c_user SET confirmed=1 WHERE user_id='.$SESSION['user']['user_id']);

		$outputDir='../output/';
		$dir=opendir($outputDir);
		$today=date("Y-m-d");
		while(($outputFile=readdir($dir))!==false){
			if($outputFile!='.' && $outputFile!='..'){
				$filePath=$outputDir.$outputFile;
				$modifiedDate=date("Y-m-d",filemtime($filePath));
				if($modifiedDate<$today){
					unlink($filePath);
				}
			}
		}
		

		$allowedMaintenanceUsers=array('NG3184C', 'NG23FC4','NG33826');
		$maintenance=false;
		
		if(!in_array($login, $allowedMaintenanceUsers) && $maintenance)	echo 'OK|||maintenance'; //JFM 13_05_16
		else
		{
			require_once('../support/sessionLoader.php');
			
			SqlLQ('INSERT INTO c_login(tool,login,valid_login,ip) VALUES ('.$SESSION['tool_id'].',"'.$POST['User_Name'].'",1,"'.getClientIp().'")');
			
			checkPermission('c_tool_general','view',1,'gate',$SESSION,1);
			
			createLog('dr_log','tool_id','log_in',$SESSION['tool_id'],'','',$SESSION);
			
			SqlLQ('UPDATE dr_action SET action_status=0 WHERE action_status=1 AND action_completion<SUBDATE(NOW(),INTERVAL 1 DAY)');

			echo 'OK|||home&&&'.utf8_encode($SESSION['user']['name']); //JFM 13_05_16
		}		
	}
	else if($ldapConnect=='LDAP_INVALID_PASSWORD' || $ldapConnect=='LDAP_INVALID_USERNAME' || $password=='')
	{
		$requestDump='';
		foreach($_SERVER as $k=>&$v)
		{
			$requestDump.='['.$k.']=>'.$v.'\n';
		}
		SqlLQ('INSERT INTO c_login(tool,login,valid_login,ip,request_dump) VALUES ('.$SESSION['tool_id'].',"'.$POST['User_Name'].'",0,"'.getClientIp().'","'.$ldapConnect.$requestDump.'")');
		echo 'OK|||invalid_login'; //JFM 13_05_16
	}
	else if(strtoupper($SESSION['user']['login'])!=strtoupper($login) && $ldapConnect=='LDAP_AUTH_OK')
	{
		$requestDump='';
		foreach($_SERVER as $k=>&$v)
		{
			$requestDump.='['.$k.']=>'.$v.'\n';
		}
		SqlLQ('INSERT INTO c_login(tool,login,valid_login,ip,request_dump) VALUES ('.$SESSION['tool_id'].',"'.$POST['User_Name'].'",1,"'.getClientIp().'","'.$requestDump.'")');
		echo 'OK|||not_registered'; //JFM 13_05_16
	}
	else if($ldapConnect=='Bind not possible')
	{
		$requestDump='';
		foreach($_SERVER as $k=>&$v)
		{
			$requestDump.='['.$k.']=>'.$v.'\n';
		}
		SqlLQ('INSERT INTO c_login(tool,login,valid_login,ip,request_dump) VALUES ('.$SESSION['tool_id'].',"'.$POST['User_Name'].'",1,"'.getClientIp().'","'.$requestDump.'")');
		echo 'OK|||no_ldap'; //JFM 13_05_16
	}
	else
	{
		$requestDump='';
		foreach($_SERVER as $k=>&$v)
		{
			$requestDump.='['.$k.']=>'.$v.'\n';
		}
		SqlLQ('INSERT INTO c_login(tool,login,valid_login,ip,request_dump) VALUES ('.$SESSION['tool_id'].',"'.$POST['User_Name'].'",0,"'.getClientIp().'","'.$requestDump.'")');
		SqlLQ('INSERT INTO c_error_log (time_stamp,tool,user,error_log) VALUES (NOW(),2,"'.$POST['User_Name'].'","'.addslashes(utf8_decode($ldapConnect)).'")');
		echo 'OK|||unknown'; //JFM 13_05_16
	}
}
else
{
	echo 'OK|||illegal_access'; //JFM 13_05_16
}
?>
