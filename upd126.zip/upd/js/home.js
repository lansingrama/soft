var
abDate=['a','b'],
activeCol='',
activeEdit=0,
activeSideContainer='',
activeStatus='',
activeTable,
activeTableCacheId,
actualSideElement=new Array(),
ajaxParameters,
allElementsOfForm=new Array(), //JFM 23_09_13
casSelected=0,
changeLogChecked=0,
mainTableTutorialDelayed=0, //JFM 28_10_15
chkBoxSel=new Array(),
chkTOut,
chkTOutId='',
closeFormNeeded=0,
containerDiv='',
containerDivClock='',
cwD,
cwId,
dateDiv=['Y','M','D'],
ddTarget,
editStartInfo=new Array(),
firstLoginWindowShown=0,
filterDates=['show_after','show_before'],
fltOn=false,
focusTarget='',
formCount=0,
formHeight=0,
formInitVal=Array(),
formWidth=0,
formZIndex=100,
indirectChkChange=0,
indirectChkValue,
inputId,
keepSearchFocus=0,
lastCaSelected=1,
lastCheck,
lastMenuShown=null,
lastLogId=0,
lastReviewTypeCheckedExists=0,
lastSideElementRequest=new Array(),
lastSideElementRequestCount=0,
mainRestartNeeded=0,
mainTableCacheId,
maxResults,
mOvMenu=0,
newSideElContainer,
newSideElDivId,
newSideSearchId,
newSideElText,
newSideElType,
notFoundDiv,
oldBgCol=new Array(),
oldCol='',
oldCrPos='',
oldCrRef='',
oldCrTxt='',
popUpType='',
processing=false,
previousElement=new Array(),
reloadSideElementNeeded=0,
removeCase,
removeSearchId='',
revConfigColor=['#FFFFFF','#FFFBCC','#F3CBCB'],
revDate=new Date(),
reviewCaWpTarget,
reviewTypeDetails=new Array(),
reviewTypeDetailsLoaded=0,
rmSearchImg,
rowCount=new Array(),
saveResponseDiv,
searchCount=0,
searchDivId=new Array(),
searchMax=300,
searchName=new Array(),
searchElId=new Array(),
searchTxt,
showAddInfo,
sideContainer='',
sideElement,
sideWindowId,
sideAjaxFile,
ssOn=false,
statusImg=['r','a','g','x'], //JFM 27_03_14
statusTxt=['red','amber','green','blue'], //JFM 28_10_15
subFormQueryNeeded=1,
tableCacheId='',
tempFilterTable=['action','rid','change'],
timerId=null,
timeOut=300,
today=new Date(),
userListLoaded=0,
validCaList=1,
clockNumber=0,
disableAllFormElementsNeeded=0,
graphOnClick='',
graphOnClickStatus=0,
graphOnClickMsn='',
graphOnClickMsnID='',
graphOnClickCoe='',
graphOnClickID=0,
graphOnClickReviewProfile=0,
graphOnClickCa=0,
graphOnClickArea=0,
graphOnClickProgram=0,
graphOnClickUser='',
testX, 
testY,
unifiedPresence,
movement=0,
overlibGlobalDivId='',
globalRandomCount=0,
pageRestartNeeded=0,
cancelMe,
wizardStep=0,
reportWizardStep=0,
reportWizardFileDownloadGlobal='',
fromIndex=false;
whiteBg=new Array();
inputArray =new Array();  // added by Infosys Limited of US(Role Management) - #58.1 
roleArr = '';	// added by Infosys Limited of US(Edit) - US #058 
kpiTable = new Array(); // Added for US#91
lastpage = false;
counter = 0;

overlib_pagedefaults(FGCOLOR,'#FFFFFF',BGCOLOR,'#565C6A',TEXTFONT,"Arial, Helvetica, Verdana",TEXTSIZE,"1em",TEXTCOLOR,'#565C6A');
/*
    US #058
    User Management - Edit
    Fixed By - Infosys Limited
    Version - 2
*/
function sendRolesArr(roles)
{
    var options = JSON.stringify(roles);
        options = JSON.parse(options);
		roleArr = options;
}
/* End for  US #058 User Management*/

function a0Report(object,ca,reviewProfile,batch){
	raiseIssue=(confirm('Raise Issue?'))?1:0;
	window.location='support/a0Xdp.php?object='+object+'&ca='+ca+'&reviewProfile='+reviewProfile+'&batch='+batch+'&raiseIssue='+raiseIssue;
}
function addWpApplicability(t){
	wp=ddSelectedValue(t.id);
	if(wp!=''){
		ajaxRequest('ajax/addWpApplicability.php?wp='+wp,'updateData',false,'GET');
		ajaxRequest('ajax/addWpApplicability.php?wp='+wp,'updateData',false,'GET');
		ddRemoveOption(t);
	}
}
function alertArrayContent(a){
	var txt='';
	for(i in a)txt+=a[i]+'_';
	alert(txt);
}
function alterCounter(id,count){
	if($(id)){
		var newValue=parseInt($(id).innerHTML)+count;
		$(id).innerHTML=(newValue=='0')?'':newValue;
	}
}
function attachDdValue(name,id){
	return '&'+name+'='+ddSelectedValue(id);
}
function attachRowToTable(row,table){
	$('nextResultTemp').innerHTML=row;
	$(table).appendChild($('nextResultTemp').firstChild.firstChild);
}
function avoidSendForm(key,inputCase){
	kCode=(document.all)?key.keyCode:key.which;
	if(kCode==13){
		if(inputCase=='user')hideSuggest();
	}
	return (kCode!=13);
}

function avoidSendFormSup(key,inputCase){
	kCode=(document.all)?key.keyCode:key.which;
	if(kCode==13){
		if(inputCase=='supplier')hideSuggest();
	}
	return (kCode!=13);
}

function bodyLoad()
{
	document.onkeypress=function()
	{
		keyProcessor(window.event.keyCode, window.event);
	};

	document.onmouseup = function(e) //JFM 09_04_14
	{
		e = e || window.event;
		var target = e.target || e.srcElement;

		var forceCloseMenu = true;

		if($(activeCol) && target.value!='...')
		{
			while (target.parentNode) 
			{
				target = target.parentNode;
				if(target.id == activeCol)
				{
					forceCloseMenu = false;
					break;
				}
			}

			if(forceCloseMenu) closeMenu(activeCol);
    	}
    	if($(contDiv)) hideSuggest();
	};

	//unifiedPresence=new ActiveXObject('Name.NameCtrl.1');

	/*window.onbeforeunload=function(){
		removeTableCache('all');
	};*/
	
	clock(); //JFM 14_10_13

	loadMainTable();

	//updateDataFromOtherClients(); //JFM 30_10_14
}

function clock()
{
	//ajaxRequest('ajax/validationCount.php','putInDivClock',false,'GET');
	ajaxRTick=(window.XMLHttpRequest)?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP");
	ajaxRTick.onreadystatechange=showContentTick;
	var d=new Date();
	rand=(Math.random()*99999)+'-'+d.getTime();
	urlConnector=('ajax/validationCount.php'.indexOf('?')==-1)?'?':'&';
	ajaxRTick.open('GET','ajax/validationCount.php'+urlConnector+'rand='+rand,true); //JFM 16_01_15
	ajaxRTick.send(null);

	function showContentTick()
	{
		if(ajaxRTick.readyState==4 && ajaxRTick.status==200) 
		{
			rTick=ajaxRTick.responseText;

			if(rTick=='_!exit!_')
			{
				window.location='index.php?error=session_expired';
				return false;
			}

			rTick=checkAjaxResponse(rTick);
			if(rTick!='KO')
			{
				rtArr=rTick.split('&&&');
				//JFM 12_01_16 $('validNumber').style.marginLeft=rtArr[0];
				$('validNumber').innerHTML=rtArr[1];
				$('validImg').src='../common/img/'+rtArr[2]+'.png';
			}
		}
	}

	setTimeout(clock,60000);
}

function updateDataFromOtherClients(timestamp) //JFM 31_10_14
{
	ajaxUpdateData=(window.XMLHttpRequest)?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP");
	ajaxUpdateData.onreadystatechange=showUpdate;
	if(timestamp) urlConnector='?timestamp='+timestamp+'&';
	else urlConnector='?';
	ajaxUpdateData.open('GET','ajax/updateDataFromOtherClients.php'+urlConnector,true);
	ajaxUpdateData.send(null);

	function showUpdate()
	{
		if(ajaxUpdateData.readyState==4 && ajaxUpdateData.status==200) 
		{
   			var obj=JSON.parse(ajaxUpdateData.responseText);
			updateData(obj.fileString);
			updateDataFromOtherClients(obj.fileTimeStamp);
		}
	}
}

function changeRevConfigProfile(t,container,msn,ca,revProfile){
	containerDiv=container;
	caStr=(ca=='')?'':'&ca='+ca;
	ddST=t.options[t.selectedIndex].text;
	ajaxRequest('ajax/criteriaList.php?msn='+msn+caStr+'&review='+revProfile+'&reviewConfig='+ddSelectedValue(t.id),'putInDiv',false,'GET');
	caArr=ca.split(',');
	for(i in caArr){
		updateTd='review_configuration_profile_'+caArr[i]+'_'+revProfile;
		if($(updateTd)){
			$(updateTd).innerHTML=ddST;
		}
	}
}
function changeReviewProfile(){
	//$('collapsing_title_review_report').innerHTML=ddSelectedText('rvmDdRevType')+' Review';
	if(ddSelectedText('rvmDdRevType')==''){
		$('collapsing_title_review_report').innerHTML='No Review Selected';
		$('subFormReviewReportContainer').innerHTML='<div class="sideSubFormContainerEmpty">Select an Element from the list.</div>';
	}else{
		openSideElement(previousElement[6],'rev');
	}
}
function changeRidSelect(t,wp,criteria){
	var d,n;
	switch(t.value){
		case'new':
			d=0;
			ajaxRequest('ajax/newCode.php?wp='+wp+'&criteria='+criteria+'&type=rid','newRid',false,'GET');
		break;
		default:
			d=(t.value==0)?1:0;
			n=1;
			ajaxRequest('ajax/rid.php?rid='+t.value,'updateData',false,'GET');
		break;
	}
	$('disabledRid').style.display=(d==1)?'none':'block'; //JFM 30_10_14
	if(n==1)$('rid').options[1].text='New RID...';
}
function changeStrLoc(e,skipReset) //JFM 12_01_16
{
	if(!skipReset) resetSideSelection('str'); //JFM 12_01_16
	if(e=='reset')
	{
		var listOfDropDowns = Array('strDdProgram', 'strDdCoe', 'strDdPerimeter', 'strDdMsn');

		for (var i = 0; i < listOfDropDowns.length; i++) 
		{
			$(listOfDropDowns[i]).options.length = 0;

		}

		$('strDdArea').selectedIndex = 0;
		$('wizardPleaseSelect').style.display = "none";
	}
	if(e=='area') //JFM 03_06_14
	{
		retrieveDdList('strDdProgram','','','program',attachDdValue('area','strDdArea')); //JFM 28_10_15
		retrieveDdList('strDdCoe','','','coe',attachDdValue('area','strDdArea'));
		retrieveDdList('strDdPerimeter','','','perimeter',attachDdValue('area','strDdArea'));
		retrieveDdList('strDdMsn','','','msn',attachDdValue('area','strDdArea'));
	}
	if(e=='program'){
		retrieveDdList('strDdPerimeter','','','perimeter',attachDdValue('program','strDdProgram'));
		retrieveDdList('strDdMsn','','','msn',attachDdValue('program','strDdProgram'));
	}
}
function changeUserSource(){
	var c=$('valid_user_source_new').checked;
	$('ddCorrectUser').disabled=(c==true)?true:false;
	$('newValidUser').style.display=(c==true)?'block':'none';
	if(c==true){
		validateUser();
	}else{
		$('correctInvalidUser').disabled=false;
		$('correct_user_saveResponse').style.visibility='hidden'
	}
}
function checkA0Validity(ca,rp){
	if(ca!=''){
		openForm('generateA0Report','&a0_report_ca='+ca+'&a0_report_review_profile='+rp,false,'GET');
	}
}
function checkActionsInCriteria(g,c,m){
	ajaxRequest('ajax/actionsInCriteria.php?group='+g+'&criteria='+c+'&mode='+m,'actionsInCriteria',false,'GET');
}
function checkAvailableResults(){
	if(tableCacheId)ajaxRequest('ajax/checkAvailableResults.php?tableCacheId='+tableCacheId,'checkAvailableResults',true,'GET');
}
function checkChange(t, type, element, users) {

    element = element || '';
    users = users || '';
    lastCheck = type;
    indirectChkChange = 0;
    switch (type) {
        case'cfc':
            mainRestartNeeded = 1;
                //JFM 19_07_16
            if (typeof t == "string")
            {
                t = $(t);
                chkValue = (t.checked) ? 1 : 0;
                t.checked = (t.checked) ? 0 : 1;
            } else
                chkValue = (t.checked) ? 0 : 1;
            
            if(element != 'review') {
                ajaxRequest('ajax/setDisplayedColumn.php?location=' + t.id + '&value=' + chkValue, 'checkOk', false, 'GET');            
            }      
            break;
        case'prm':
            chkValue = (t.checked) ? 1 : 0;
            ajaxRequest('ajax/setPermission.php?user=' + $('permissionUserId').value + '&location=' + t.id + '&value=' + chkValue, 'checkOk', true, 'GET');
            break;
            /*JFM 03_06_14
             case'dash':
             mainRestartNeeded=1;
             chkValue=(t.checked)?1:0;
             ajaxRequest('ajax/setDashboard.php?value='+chkValue,'restartMainTable',true,'GET'); //JFM 13_02_14
             break;*/
        case'graph':
            mainRestartNeeded = 1;
            chkValue = (t.checked) ? 1 : 0;
            ajaxRequest('ajax/setGraph.php?value=' + chkValue + '&applicability=' + t.id, 'restartMainTable', true, 'GET'); //JFM 13_02_14
            break;
        case'cont': //JFM 09_04_14
            chkValue = (t.checked) ? 1 : 0;
            ajaxRequest('ajax/setContinuousAssessment.php?value=' + chkValue + '&applicability=' + t.id, 'reloadSideElement', true, 'GET');
            break;
        case'greenAct': //JFM 12_05_15
            mainRestartNeeded = 1;
            chkValue = (t.checked) ? 1 : 0;
            ajaxRequest('ajax/setGreenActions.php?value=' + chkValue, 'restartMainTable', true, 'GET'); //JFM 13_02_14
            break;
	    //Added for #032 Bulk user upload (Suggested by ICT)
        case'bulkEdit':
            chkValue = (t.checked) ? 1 : 0;
            
	    if(chkValue == 1) 
	    {
	    	document.getElementById("Checkedid" + t.id).style.display = 'block';
	    }
	    else{
		document.getElementById("Checkedid" + t.id).style.display = 'none';
	    }
            break;
    }
	//End of Add for US #032
}

/*
 * Bug-11
 * Function to check the Column on Review page
 * @param {String} t
 * @param {String} type
 * @param {Integer} check
 * @returns {undefined}
 */
function checkReview(t, type, check) {
    
    if(type == 'cfc') {
        mainRestartNeeded = 1;
        t = $(t);

        if (check == 1) {
            t.checked = 1;
        } else if (check == 0) {
            t.checked = 0;
        }
    }
}

function checkExistingReviewType(v,n){
	loadReviewTypeDetails();
	var
	id=$('review_type_id'),
	t=$(n+'review_type'),
	d=$(n+'review_type_description'),
	c=$(n+'review_type_code'),
	vu=v.toUpperCase();
	typePosition=0;
	for(var i in reviewTypeDetails){
		if(reviewTypeDetails[i][1]==vu){
			typePosition=i;
		}
	}
	if(typePosition!=0){
		if(n=='new_'){
			d.disabled=true;
			c.disabled=true;
		}
		r=reviewTypeDetails[typePosition];
		id.value=r[0];
		t.value=r[1];
		d.value=r[2];
		c.value=r[3];
		lastReviewTypeCheckedExists=1;
	}else{
		d.disabled=false;
		c.disabled=false;
		if(lastReviewTypeCheckedExists==1){
			id.value=0;
			d.value='';
			c.value='';
		}
		lastReviewTypeCheckedExists=0;
	}
}
function checkGroup(lc,t,checked,parameter,inverted){
	lastCheck=lc;
	indirectChkChange=1;
	mainRestartNeeded=1;
	indirectChkValue=(checked==1)?true:false;
	
	if(inverted==0){
		sendingResult=checked;
	}else{
		sendingResult=(checked==1)?0:1;
	}
	
	t.checked=indirectChkValue;
        for(var p in parameter) {
            var reviewId = parameter[p];
            var cbs = document.getElementsByClassName('cbrow-' + reviewId);
            if(cbs.length > 0) {
                  for(var i in cbs) {
                     if(cbs[i].type === 'checkbox')
                     cbs[i].checked = t.checked;
                }
            }
        }
	switch(lc){
		case 'cfc':
			if(parameter[0]=='responsible'){
				ajaxRequest('ajax/hideAllResponsible.php?hide='+sendingResult,'checkOk',false,'GET');
			}
                        /*else{
				ajaxRequest('ajax/hideAllReviewColumns.php?review='+parameter+'&hide='+sendingResult,'checkOk',false,'GET');
			}*/
		break;
		case 'prm':
			ajaxRequest('ajax/grantAllReviewRights.php?user='+parameter[0]+'&object='+parameter[1]+'&applicability='+parameter[2]+'&active='+sendingResult,'checkOk',false,'GET');
		break;
	}
}
function checkMSN(v,msnList){
	var valNum=true;
	if(v==''){
		invalidMSN.innerHTML='&nbsp;';
		createMSNBt.disabled=true;
	}else{
		if(!isNaN(v)){
			vlen=v.length;
			for(var i=0;i<vlen;i++)
				if(v.charCodeAt(i)<48 || v.charCodeAt(i)>57)valNum=false;
		}else valNum=false;
		v=parseInt(v);
		if(valNum==true && v!=0){
			createMSNBt.disabled=false;
			msnArr=msnList.split('#');
			var msnFound=false;
			for(i in msnArr)if(msnArr[i]==v)msnFound=true;
			if(msnFound==false){
				invalidMSN.innerHTML='&nbsp;';
				createMSNBt.disabled=false;
			}else{
				invalidMSN.innerHTML='The MSN already exists';
				createMSNBt.disabled=true;
			}
		}else{
			createMSNBt.disabled=true;
			invalidMSN.innerHTML='It must be a number and > 0';
		}
	}
}
function checkNewChangeLog(mainTableTutorial) //JFM 28_10_15
{
	var changeLogParams=0;
	if(mainTableTutorial) changeLogParams = 1;
	ajaxRequest('ajax/checkNewChangeLog.php?main_table_tutorial='+changeLogParams,'checkNewChangeLog',true,'GET'); //JFM 12_01_16 - Set to true.
}
function checkRestartMainTable(){
	if(formCount==0 && mainRestartNeeded==1){
		mainRestartNeeded=0;
		restartMainTable();
	}
	if(formCount==0 && pageRestartNeeded==1) //JFM 25_11_13
	{
		pageRestartNeeded=0;
		location.reload(true);
	}
}
/*JFM 03_06_14
function chImg(table,tableSection,obj,app,t,img,tableCacheId,sfTxt){ 
	fltDiv='sf-'+app+'-'+obj;
	var oldSrc=t.src;
	activeTable=table;
	activeTableCacheId=tableCacheId;
	t.src='../common/img/'+img+'.png';
	t.onclick=function(){
		if(fltOn==false){
			activeCol=fltDiv;
			popUpType='filter';
			ajaxRequest('ajax/columnFilter.php?table='+table+'&table_section='+tableSection+'&object='+obj+'&app='+app+'&sfTxt='+sfTxt,'showFilter',true);
			fltOn=true;
		}
	};
	t.onmouseout=function(){
		this.src=oldSrc;
	};
}*/
function chkMinSel(id,t){
	if($(id+'red').checked==false && $(id+'amber').checked==false && $(id+'green').checked==false && $(id+'blue').checked==false && $(id+'no_status').checked==false){ //JFM 27_03_14
		t.checked=true;
		$('waitTd').innerHTML='<span style="color:#F00;">There must be one selected.</span>';
	}else $('waitTd').innerHTML='&nbsp;';
}
function chTdBg(t,c,b){
	t.style.backgroundColor=c;
	if(b){
		t.style.borderBottomColor=b;
		t.style.borderTop=b;
	}
}
function clickSubFormBar(f,sf){
	setSideVars(f);
	if($(sideContainer[sf]).style.display=='block'){
		collapseSubForm(sideContainer[sf],1);
	}else{
		if(subFormQueryNeeded==1){
			openSideElement('',f,'',sf);
		}else{
			collapseSubForm(sideContainer[sf],0);
			emptyFormMessage(sideContainer);
		}
	}
}
function closeAllForms(){
	if($('formContainer').hasChildNodes()){
		var form=$('formContainer').firstChild;
		do{
			closeForm(form.firstChild.nextSibling.firstChild);
		}while(form=form.nextSibling);
	}
}
function closeForm(form){
	nd();
	closeMenu(activeCol);
	resetFormVars('close');

	if(typeof form.parentNode.classList !== "undefined") //JFM 12_01_16
	{
		if(formCount > 0)$('whiteBG_'+whiteBg[formCount-1]).style.display='none';
		if(formCount > 1) $('whiteBG_'+whiteBg[formCount-2]).style.display='block';
		form.parentNode.style.left = '100%';
		closeFormInvoked(form);
		setTimeout(function(){destroyNode(form.parentNode.parentNode)},250);
	}
	else
	{
		destroyNode(form.parentNode.parentNode);
		closeFormInvoked(form);
	}
}
function closeFormInvoked(form) //JFM 12_01_16
{
	wizardStep=0;
	reportWizardStep=0;
	if(formCount > 0) formCount--;
	formZIndex-=2;
	if(formCount==0)
	{
		document.documentElement.style.overflow="auto";
		document.body.style.marginRight='0px';
	}
	else
	{
		if(formCount > 0) $('whiteBG_'+whiteBg[formCount-1]).style.display='block';
	}
	closeFormNeeded=0;
	lastFocused='';
	checkRestartMainTable();
}
function closeLastForm(){
	if($('formContainer').hasChildNodes()){
		closeForm($('formContainer').lastChild.firstChild.nextSibling.firstChild);
	}
}
function closeMenu(id){
	if($(id) && $(id).innerHTML!=''){
		if(id=='overDivCriteriaStatus') $(id).style.visibility='hidden'; //JFM 24_03_14
		else $(id).style.display='none'; //JFM 24_03_14
		destroyInnerHTML($(id));
		//changePopUpButtonColor(activeCol); //JFM 03_06_14
		var menuClosed=1;
	}else var menuClosed=0;
	fltOn=false;
	return menuClosed;
}
function collapseSubForm(container,c){
	$(container).previousSibling.className=(c==1)?'collapsingBarCommon collapsingBarOff':'collapsingBarCommon collapsingBarOn';
	$(container).style.display=(c==1)?'none':'block';
	$(container).previousSibling.lastChild.innerHTML=(c==1)?'&#9660;':'&#9650;';
	if(c==1){
		destroyInnerHTML(container);
	}
}
function correctUserTxt(actionId,position,userId){
	ajaxRequest('ajax/correctUserTxt.php?correct_position='+position+'&correct_action_id='+actionId+'&correct_user_id='+ddSelectedValue(userId),'updateData',true,'GET');
}

function criteriaClick(g,c,t){
	if(oldCrTxt==''){
		focusTarget=t;
		checkActionsInCriteria(g,c,'edit');
	}
}
function crtColInfo(t,review,criteria){
	t.onmouseout=function(){clearTimeout(showAddInfo);nd();};
	t.onclick=function(){clearTimeout(showAddInfo);nd();openForm('reviewManagement','',false,'GET');openSideElement(review,'rvm');};
	showAddInfo=setTimeout(function(){ajaxRequest('ajax/criteriaColumnInfo.php?review_criteria_id='+criteria,'ol',false,'GET')},500);
}
function crtInfo(t,msn,ca,criteria){
	if(processing==false){
		t.onmouseout=function(){clearTimeout(showAddInfo);nd();};
		t.onclick=function(){clearTimeout(showAddInfo);nd();openForm('criteriaStatus','&msn='+msn+'&ca='+ca+'&review_criteria_id='+criteria,true,'GET');};
		showAddInfo=setTimeout(function(){ajaxRequest('ajax/criteriaInfo.php?msn='+msn+'&ca='+ca+'&review_criteria_id='+criteria,'ol',false,'GET')},500);
	}
}
function csv(t,s,i,f,src,a) //JFM 09_04_14
{
	var confirm=window.confirm('Would you like the CSV file formatted for the German Version of Excel?');
	if(confirm) window.location='ajax/csv.php?table='+t+'&table_section='+s+'&table_cache_id='+i+'&file_name='+f+'&source='+src+'&applicability='+a+'&delimiter=semi';
}
function ddAdd(ddId,fieldId,fieldTxt,selected){
	var ddPosition=ddId.options.length;
	ddId.options[ddPosition]=new Option(fieldTxt,fieldId);
	if(selected==1){
		ddId.selectedIndex=ddPosition;
	}
}
function ddExistingReviewType(){
	ddTarget='review_profile_copy_source';
	if($('existingReviewType').value=='new')ddReset('review_profile_copy_source');
	else{
		ajaxRequest('ajax/validReviewProfile.php?review='+ddSelectedValue('existingReviewType'),'ddFill',true,'GET');
		$('copyReviewConfig').disabled=true;
	}
}
function ddFill(array){ //JFM 08_06_16
	if(array=='show')restartMainTable();
	else
	{
		if(ddTarget!='')
		{
			ddId=$(ddTarget);
			if(ddId!=null)
			{
				ddId.length=0;
				ddEls=array.split('&&&');
				if(ddEls[0]!='noBlank')
				{
					ddId.options[0]=new Option('','');
					ddElsL=ddEls.length;
					for(i=0;i<ddElsL;i++)
					{
						selVals=ddEls[i].split('%%%');
						ddId.options[i+1]=new Option(selVals[1],selVals[0]);
					}
				}
				else
				{
					ddddEls=ddEls.shift();
					ddElsL=ddEls.length;
					for(i=0;i<ddElsL;i++)
					{
						selVals=ddEls[i].split('%%%');
						ddId.options[i+1]=new Option(selVals[1],selVals[0]);
					}
					ddId.remove(0);
				}
			}
		}
	}
}
function ddRemoveOption(s){
	var sl=s.length;
	for(var i=0;i<sl;i++){
		if(s.options[i].selected){
			s.remove(i);
			break;
		}
	}
}
function ddReset(id){
	ddId=$(id);
	if(ddId)ddId.length=0;
}
function ddSelectedText(id){
	if($(id)){
		return $(id).options[$(id).selectedIndex].text;
	}
}
function ddSelectedValue(id)
{
	if($(id))
	{
		//JFM 03_06_14
		if($(id).options.length > 0) return $(id).options[$(id).selectedIndex].value;
		else return;
	}
}
function deleteCriteria(g,c){
	containerDiv='reviewCriteriaManagementList';
	ajaxRequest('ajax/deleteCriteria.php?group='+g+'&criteria='+c,'putInDiv',true,'GET');
}
function deleteReviewConfigurationProfile(id,txt){
	rcpId=(exists(id))?id:ddSelectedValue('review_configuration_profile_list');
	rcpTxt=(exists(txt))?txt:ddSelectedText('review_configuration_profile_list');
	if($('revDdProgram')){
		pStr='&program='+ddSelectedValue('revDdProgram')
	}
	if($('revDdCoe')){
		cStr='&coe='+ddSelectedValue('revDdCoe')
	}
	if(confirm('Are you sure you want to delete the Configuration '+rcpTxt+'?\n\nIt will be removed from all Reviews.\n\nThis cannot be undone.')){
		ajaxRequest('ajax/deleteReviewConfigurationProfile.php?'+pStr+cStr+'&id='+rcpId,'editReviewConfigurationProfile',true,'GET');
	}
}
function destroyInnerHTML(node){
	if(node.firstChild){
		var child=node.firstChild;
		do{
			destroyNode(child);
		}while(child=node.firstChild);
	}
}
function destroyNode(node)
{
	if(node.parentNode) node.parentNode.removeChild(node); //JFM 12_01_16
	//JFM 12_01_16 $('garbageCollector').appendChild(node);
	//JFM 12_01_16 $('garbageCollector').contentWindow.location.reload();
}
function destroySession(){
	ajaxRequest('ajax/destroySession.php','',false,'GET');
}
function displayReview(review,hide,windowId){
	processing=true;
/*	JFM 23_10_15 if(hide==0){
		expandCriteria=(confirm('Do you want to expand also the Criteria Status column?'))?'&expand_criteria=1':'';
	}else{
		expandCriteria='';
	}*/
	ajaxRequest('ajax/displayReview.php?review='+review+'&hide='+hide,'restartMainTable',false,'GET');
	//closeMenu(windowId);
}
function disableStructure(cawp,mode,d,r,p){
	parameters=(exists(p))?p:'';
	ajaxTarget=(r==1)?'restartMainTable':'reloadSideElement';
	mainRestartNeeded=1;
	ajaxRequest('ajax/saveStructure.php?objectTxt=cawp&mode='+mode+'&applicability='+cawp+'&disabled='+d+parameters,ajaxTarget,true,'POST');
}

function editCriteria(gr,cr,mode,description,reference){
	if(oldCrTxt!='' && mode=='edit'){
		alert('Please cancel the edition of the Criteria allocated in the position '+oldCrPos+'.');
	}else{
		tr=$('criteriaRow-'+gr+'-'+cr);
		if(tr){
			td1=tr.firstChild.nextSibling.nextSibling;
			td2=td1.nextSibling;
			td3=td2.nextSibling;
		
			switch(mode){
				case'edit':
					oldCrTxt=td1.innerHTML;
					td1.innerHTML='<input class="formInput"id="criteriaDescription_'+gr+'_'+cr+'"onkeyup="editCriteriaKeyPressed(\''+gr+'\',\''+cr+'\');"onMouseOver="setInputFocus(this);"size="81"type="text"value="'+oldCrTxt+'">';
					if(cr!=0){
						oldCrRef=td2.innerHTML;
						td2.innerHTML='<input class="formInput"id="criteriaReference_'+gr+'_'+cr+'"onkeyup="editCriteriaKeyPressed(\''+gr+'\',\''+cr+'\');"onMouseOver="setInputFocus(this);"size="15"type="text"value="'+oldCrRef+'">';
					}
					oldCrRC=td3.innerHTML;
					td3.innerHTML='<input class="popUpBtn"onclick="saveCriteriaConfig(\''+gr+'\',\''+cr+'\');"style="color:#00AA00;"type="button"value="&#10003;"> <input class="popUpBtn"onclick="editCriteria(\''+gr+'\',\''+cr+'\',\'cancel\')"style="color:#FF0000;"type="button"value="&#10008;">';
					switch(focusTarget){
						case 'description':
							$('criteriaDescription_'+gr+'_'+cr).focus();
						break;
						case 'reference':
							$('criteriaReference_'+gr+'_'+cr).focus();
						break;
					}
				break;
				case'cancel':
					td1.innerHTML=oldCrTxt;
					if(cr!=0)td2.innerHTML=oldCrRef;
					td3.innerHTML=oldCrRC;
					oldCrPos=oldCrTxt=oldCrRef='';
				break;
				case'update':
					td1.innerHTML=description;
					if(cr!=0)td2.innerHTML=reference;
					td3.innerHTML=oldCrRC;
					oldCrPos=oldCrTxt=oldCrRef='';
				break;
			}	
		}
	}
}
function editCriteriaKeyPressed(gr,cr){
	if(window.event.keyCode==13)saveCriteriaConfig(gr,cr);
	else if(window.event.keyCode==27)editCriteria(gr,cr,'cancel');
}
function emptyFormMessage(){
	scl=sideContainer.length;
	for(var i in sideContainer){
		if($(sideContainer[i]).style.display!='none'){
			if(scl>1){
				$(sideContainer[i]).innerHTML='<div class="sideSubFormContainerEmpty">Select an Element from the list.</div>';
			}else{
				$(sideContainer[i]).innerHTML='<div class="sideContainerEmpty">Select an Element from the list.</div>';
			}
		}
	}
}
function exists(e){
	return (e!=undefined && e!=='')?true:false;
}
function evDis(id,chk){
	for(var a in filterDates){
		for(var d in dateDiv){
			$(id+'-'+filterDates[a]+dateDiv[d]).disabled=chk;
		}
	}
}
function filterCancel(filterId){
	$(filterId).style.display='none';
	destroyInnerHTML($(filterId));
	fltOn=false;
	lastFocused='';
}
function filterFilter(filterType,filterId){
	filterProcessingStatus(filterType,filterId);
	//alert(filterId+'-form ajax/'+tableProcessor(activeTable)+'.php?list_name='+activeTable+'&removeTableCache='+activeTableCacheId+'&m=add&o='+filterId);
	sendAjaxForm(filterId+'-form','ajax/'+tableProcessor(activeTable)+'.php?list_name='+activeTable+'&removeTableCache='+activeTableCacheId+'&m=add&o='+filterId,'showTable',true);
}
function filterHide(filterType,filterId,columnId){
	filterProcessingStatus(filterType,filterId);
	ajaxRequest('ajax/setDisplayedColumn.php?location='+columnId+'&value=1&list_name='+activeTable+'&removeTableCache='+activeTableCacheId+'&table_processor='+tableProcessor(activeTable),'showTable',true,'GET');
}
function filterProcessingStatus(filterType,filterId,filter){
	if(filterType=='date'){
		storeDates(filterDates,filterId);
		$(filterId+'_AdCal').style.display='none';
		$(filterId+'_BdCal').style.display='none';
	}
	processing=true;
	waitTd.innerHTML='Processing...';
	fltOn=false;
	lastFocused='';
}
function filterReset(filterType,filterId){
	filterProcessingStatus(filterType,filterId);
	ajaxProcessor=tableProcessor(activeTable);
	ajaxRequest('ajax/'+ajaxProcessor+'.php?list_name='+activeTable+'&removeTableCache='+activeTableCacheId+'&m=reset&o='+filterId,'showTable',true,'POST');
}
function getActionEmailInfo(i,p){
	ajaxRequest('ajax/getActionEmailInfo.php?action_id='+i+'&position='+p,'sendEmail',true,'GET');
}
function getFormString(formId){
	var form=$(formId);
	var formL=form.elements.length;
	var formString='';
	var fName='';
	for(var i=0;i<formL;i++)
	{
		f=form.elements[i];

		if(((f.type!='checkbox' && formInitVal[i]!=f.value) || (f.type=='checkbox' && formInitVal[i]!=f.checked)) && f.name!='' && (f.type!='radio' || (f.type=='radio' && f.checked==true)))
		{
			if(f.type=='checkbox')
			{
				if(f.name.indexOf('-hide_')!=-1)v=(f.checked)?'':'1';
				else v=(f.checked)?'1':'';
			}
			else if(f.type=='select-multiple') //JFM 08_06_16
			{
				var values = [];
				for (var j = 0; j < f.options.length; j++) 
				{
					if(f.options[j].selected)
						values.push(encodeURIComponent(f.options[j].value))
				}
				v=values.join("&" + f.name + "=");
			}
			else v=encodeURIComponent(f.value);

			formString+='&'+f.name+'='+v;
		}
	}
	return formString;
}

function getAllElementsOfFormAndStoreInString(formName,store) //JFM 23_09_13
{
	if(document.forms[formName])
	{
		if(typeof document.forms[formName].elements!='undefined')
		{
			var concatString='';

			for(w=0; w<document.forms[formName].elements.length; w++)
			{
				var input=document.forms[formName].elements[w];
				
				if(input.type=='checkbox') concatString=concatString+input.checked;
				else if(input.type=='select-one')
				{
					if(input.options[input.selectedIndex])
						concatString=concatString+input.options[input.selectedIndex].value;
				}
				else if(input.id.indexOf("elephantTigerBeehiveinputID") != -1) continue;
				else if(input.type=='button') continue;
				else concatString=concatString+input.value;
			}
			
			concatString=concatString.replace(/\s+/g, ' ');
			
			if(store===0) return concatString;
			else allElementsOfForm[formName]=concatString;
			//alert(formName + '!!!!!' + allElementsOfForm[formName]);
		}
	}
}

function hideMenu(){
	if(mOvMenu==0 && lastMenuShown){
		lastMenuShown.style.display='none';
		cId=lastMenuShown.parentNode.id.split('_');
		if(cId[1]=='c')
		{
		// 	lastMenuShown.parentNode.style.borderColor='#C3CDDC';
		// 	lastMenuShown.parentNode.style.height='29px';
			var imageId=lastMenuShown.id.substring(0,(lastMenuShown.id.length-2));
			if(imageId=='valid')
			{
				if($('validNumber').innerHTML=='') $(imageId+'Img').src="../common/img/validOff.png";
				else $(imageId+'Img').src="../common/img/validOn.png";
			}
		 	else $(imageId+'Img').src='../common/img/'+imageId+'.png';
		 	lastMenuShown.parentNode.style.backgroundColor='#6f95ab';
		}
		lastMenuShown=null;
	}
}
function indexIsLoaded(alreadyLoggedIn){
	document.onkeypress=function(){
		keyProcessor(window.event.keyCode);
	};
	if($('usrName')) $('usrName').focus();

	var ua = window.navigator.userAgent;
	var msie = ua.indexOf("MSIE ");
	var version = 0;
	if (msie > 0) version = parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));

	$('bg').style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='../common/img/login_screen/login_image_"+Math.floor((Math.random() * 9) + 1)+".jpg', sizingMethod='scale')";
	
	//JFM 12_01_16
	if(version != 8)
	{
		$('bg').style.backgroundImage="url('../common/img/login_screen/login_image_"+Math.floor((Math.random() * 9) + 1)+".jpg');";
		$('bg').style.backgroundSize="cover";
		$('bg').style.backgroundPosition="center";
	}

	if(alreadyLoggedIn)
	{
		ajaxRequest('home.php','putInBody',true,'GET');
	}
	else
	{
		maintenance(); //JFM 24_03_14
	}
}
function keyProcessor(kc, e){
	if(oldCrTxt==''){
		switch(kc){
			case 27:
				menuClosed=closeMenu(activeCol);
				if(menuClosed==0){
					if(removeSearchId!=''){
						keepSearchFocus=1;
						removeSearchId.onclick();
					}else{
						closeLastForm();
					}
				}
			break;
			case 13: //JFM 04_08_15
				var reviewRemark = $('review_remark_formatted_area');
				if(reviewRemark)
				{
					if(reviewRemark === document.activeElement)
					{
						e.returnValue = false;

						var sel, range;
						var html = "<br />";
						if (window.getSelection) 
						{
							// IE9 and non-IE
							sel = window.getSelection();
							if (sel.getRangeAt && sel.rangeCount) 
							{
								range = sel.getRangeAt(0);
								range.deleteContents();

								var el = document.createElement("div");
								el.innerHTML = html;
								var frag = document.createDocumentFragment(), node, lastNode;
								while ( (node = el.firstChild) ) 
								{
									lastNode = frag.appendChild(node);
								}
								range.insertNode(frag);

								// Preserve the selection
								if (lastNode) 
								{
									range = range.cloneRange();
									range.setStartAfter(lastNode);
									range.collapse(true);
									sel.removeAllRanges();
									sel.addRange(range);
								}
							}
						} 
						else if (document.selection && document.selection.type != "Control") 
						{
							// IE < 9
							var range = document.selection.createRange();
							range.pasteHTML(html);
							range.move("character", 1);
							range.select();
							range.move("character", -1);
							range.select();
						}
					}
				}
			break;
		}
	}
}

function leave(){
	if(confirm('Are you sure you want to quit?')){
		removeTableCache('all');
		destroySession();
		window.location='index.php';
	}
}
function loadLink(t){
	v=$('link').value;
	t.href=(v.indexOf('http://')==-1)?'http://'+v:v;
}
function loadMainTable(){
	removeTableCache('all');
	restartMainTable();
	ssCheck();
}
function loadReviewTypeDetails(){
	if(reviewTypeDetailsLoaded==0){
		ajaxRequest('ajax/loadReviewTypeDetails.php','loadReviewTypeDetails',false,'GET');
	}
}
function loadSearchElements(container,searchId){
	var div=$(container).firstChild;
	searchDivId[searchId]=Array();
	searchName[searchId]=Array();
	searchElId[searchId]=Array();
	i=0;
	do{
		divArr=div.id.split('_');
		if(divArr[1]){
			searchDivId[searchId][i]=div.id;
			searchName[searchId][i]=div.innerHTML;
			searchElId[searchId][i]=divArr[1];
		}
		i++;
	}while(div=div.nextSibling);
}
function loadUserList(ul,ist,v){
	var underLevel='';
	var istTxt='';
	
	if(exists(ul)){
		for(i=0;i<ul;i++){
			underLevel+='../';
		}
	}else{
		underLevel='';
	}
	
	if(exists(ist) && ist==1){
		istTxt='?includeSuggestionTable=1';
		if(exists(v)) istTxt=istTxt+'&v='+v;
	}	
	else if(exists(v)) istTxt=istTxt+'?v='+v;
	
	ajaxRequest(underLevel+'ajax/loadUserList.php'+istTxt,'loadUserList',false,'GET');
}

function mainTableWaitMessage(){
	$('review_planning-tableContainer').innerHTML='<div class="noMainTableShown"style="font-size:100px;">Loading Data...<br><br><span style="font-size:36px;">Please wait</span></div>';
}
function maintenance(){
	ajaxRequest('ajax/maintenance.php','',true,'GET');
}
function mfSearch(v){
	restartMainTable('m=add&o=mf-0-overall_search&mf-0-overall_search-filter='+v);
}
function moveCa(cawp,wpid){
	mainRestartNeeded=1;
	ajaxRequest('ajax/moveCa.php?cawp='+cawp+'&wp_id='+wpid,'reloadSideElement',false,'GET');
}
function nextResult(ajaxFile,listName,tci,mr,ajaxMode,extraParameter){
	maxResults=mr;
	tableCacheId=tci;
	if(extraParameter==undefined){
		extraParameter='';
	}
	if(!exists(ajaxMode))ajaxMode='POST';
	$('requestNextResult_'+tci).value='Loading next results...';
	$('requestNextResult_'+tci).disabled=true;
	setTimeout(function(){ajaxRequest('ajax/'+ajaxFile+'.php?list_name='+listName+'&table_cache_id='+tableCacheId+extraParameter,'nextResult',false,ajaxMode)},0);
}
function newReview(){
	openForm('chooseReviewType','',false,'GET',400,400);
}
function newSideElement(searchId,textNew,container,divId,sideType,ajaxFile,parameters,sendForm){
	var found=0;
	newSideElContainer=container;
	newSideElDivId=divId;
	newSideSearchId=searchId;
	newSideElText=textNew;
	newSideElType=sideType;
	if(exists(searchId) || searchId==0){
		for(i in searchName[searchId]){
			if(searchName[searchId][i]==textNew){
				openSideElement(searchElId[searchId][i],sideType);
				found=1;
			}
		}
	}
	if(found==0){
		if(exists(sendForm)){
			sendAjaxForm(sendForm,'ajax/'+ajaxFile+'.php?'+parameters,'newSideElement','');
		}else{
			ajaxRequest('ajax/'+ajaxFile+'.php?'+parameters,'newSideElement',false,'GET');
		}
	}
}
function noProgramCoeMsn(program, coe, msn) //JFM 03_06_14
{
	updateResultsStatistics(1);
	destroyInnerHTML($('review_planning-tableContainer'));
	
	/*
	* Infosys Limited
	* Start of Bug: Structure Management
	* Menu item to be enabled even if main table is not displayed 
	*/
	document.getElementById("tools_c").style.display= 'none';
	document.getElementById("tools_c_hide").style.display= 'block';


				
	/* JFM 28_10_15
	var message=new Array();
	if(program) message.push('Program');
	if(coe) message.push('CoE');
	if(msn) message.push('MSN');
	message=message.join(' / ')*/
	$('review_planning-tableContainer').innerHTML='<div class="noMainTableShown">Select item from sidebar.<br><span style="font-size:26px;"><-----</span></div>';
}
function number_format(number,decimals,dec_point,thousands_sep){
	number=(number+'').replace(/[^0-9+\-Ee.]/g,'');
	var n=!isFinite(+number)?0:+number,
	prec=!isFinite(+decimals)?0:Math.abs(decimals),
	sep=(typeof thousands_sep === 'undefined')?',':thousands_sep,
	dec=(typeof dec_point==='undefined')?'.':dec_point,
	s='',
	toFixedFix=function(n,prec){
		var k=Math.pow(10,prec);
		return ''+Math.round(n*k)/k;
	};
	s=(prec?toFixedFix(n,prec):''+Math.round(n)).split('.');
	if(s[0].length>3){
		s[0]=s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g,sep);
	}
	if((s[1]||'').length<prec){
	s[1]=s[1]||'';
	s[1]+=new Array(prec-s[1].length + 1).join('0');
  }
  return s.join(dec);
}
function openForm(form,parameters,syncMode,ajaxMode,width,height,rolemanagement) ///paramenter we passed from Role Management (US- #58.1)
{
	if(validCaList==1)
	{
		var container,searchId;
		resetFormVars('open');
		if(exists(width) && exists(height))
		{
			formHeight=height;
			formWidth=width;
		}
		else
		{
			switch(form)
			{
				case 'newReview':
					formHeight=246;
					formWidth=400;
				break;
				case 'editStructure':
					formHeight=246;
					formWidth=400;
				break;
				//Added for Bulk User upload
				case 'getUsername':
					formHeight=600;
					formWidth=0;
				break;
				case 'list':
				case 'graphs': //JFM 13_01_14
				case 'criteriaGroups': //JFM 23_09_13 - JFM 11_11_13
					formHeight=0;
					formWidth='max';
				break;
				default:
					formHeight=formWidth=0;
				break;
			}
		}
		//alert(form+'\n'+tempFilterTable[0]+'\n'+tempFilterTable[1]+'\n'+tempFilterTable[2]);
		if(in_array(form,tempFilterTable)){
			parameters+='&m=reset&o=reset_temp&table='+form;
		}
		
		//alert('form/'+form+'.php?'+parameters);
		ajaxRequest('form/'+form+'.php?'+parameters,'openForm',syncMode,ajaxMode);
		switch(form)
		{
			case'correctUser':
				container='invalidUserList';
				searchId=2;
			break;
			case'review':
				container='reviewCaWpList';
				searchId=1;
			break;
			case'userManagement':
				container='userList';
				searchId=0;
				userListLoaded=1;
			break;
			default:
				container='';
			break;
		}
		if(container!='')
		{
			loadSearchElements(container,searchId);
		}
	}
        if(rolemanagement){
                clearAreaIds(); /// Clear hidden Area Ids
        }
}
function openList(t,qry){
	if(t.innerHTML!=''){
		openForm('list',qry,true,'POST');
	}
}
function openReviewForm(review,target){
	if(review==undefined)review='';
	if(target==undefined)target='ca';
	reviewCaWpTarget=target;
	mainTableCacheId=$('mainTableCacheId').value;
	if(exists(mainTableCacheId)){
		openForm('review','main_table_cache_id='+mainTableCacheId+'&review='+review+'&target='+target,false,'GET');
	}else{
		alert('Please, select a location (Program/CoE/MSN)');
	}
}
function openSideElement(elementId,windowCase,elementTxt,subForm){
	//alert(elementId+'###'+windowCase+'###'+elementTxt+'###'+subForm);
	setSideVars(windowCase,elementId);
	if(exists(elementId)){
		p=previousElement[sideWindowId];
		if(exists(p) && $(sideElement+'_'+p)){
			$(sideElement+'_'+p).style.fontWeight='normal';
		}
		if($(sideElement+'_'+elementId)){
			$(sideElement+'_'+elementId).style.fontWeight='bold';
		}
		previousElement[sideWindowId]=elementId;
	}else{
		if(exists(subForm)){
			elementId=previousElement[sideWindowId];
		}
	}
	if(exists(elementId)){
		if(exists(elementTxt)){
			elementTxt='&element_txt='+elementTxt;
		}else{
			elementTxt='';
		}
		if(exists(subForm)){
			activeSideContainer=sideContainer[subForm];
			collapseSubForm(activeSideContainer,0);
			lastSideElementRequestCount++;
			lastSideElementRequest[lastSideElementRequestCount]='ajax/'+sideAjaxFile[subForm]+'.php?element='+elementId+elementTxt+ajaxParameters;
			ajaxRequest(lastSideElementRequest[lastSideElementRequestCount],'openSideElement',false,'GET');
		}else{
			if(sideAjaxFile.length==sideContainer.length){
				for(var i in sideContainer){
					if($(sideContainer[i]) && $(sideContainer[i]).style.display!='none'){
						if(i>0)	//JFM 13_12_13
						{
							setTimeout(function(){
								activeSideContainer=sideContainer[i];
								lastSideElementRequestCount++;
								lastSideElementRequest[lastSideElementRequestCount]='ajax/'+sideAjaxFile[i]+'.php?element='+elementId+elementTxt+ajaxParameters;
								ajaxRequest(lastSideElementRequest[lastSideElementRequestCount],'openSideElement',false,'GET');
							},100);
						}
						else
						{
							activeSideContainer=sideContainer[i];
							lastSideElementRequestCount++;
							lastSideElementRequest[lastSideElementRequestCount]='ajax/'+sideAjaxFile[i]+'.php?element='+elementId+elementTxt+ajaxParameters;
							ajaxRequest(lastSideElementRequest[lastSideElementRequestCount],'openSideElement',false,'GET');
						}
					}
				}
			}
		}
	}
}
function popUpOpt(location,p){
	if(fltOn==false){
		popUpType='options';
		switch(location){
			case'act':
				activeCol='popUpActDiv_'+p[1];
				opts='&review='+p[0]+'&action='+p[1]+'&criteria_ca='+p[2];
			break;
			//JFM 19_07_16
			case'rid':
				activeCol='popUpRidDiv_'+p[1];
				opts='&review='+p[0]+'&rid='+p[1]+'&criteria_ca='+p[2];
			break;
			case'cap':
				activeCol='popUpCaPic';
				opts='&target='+p[0]+'&target_id='+p[1];
			break;
			case'coe':
				activeCol='popUpCoeDiv_'+p[0];
				opts='&coe='+p[0]+'&area='+p[1]; //JFM 03_06_14
			break;
			case'com':
				activeCol='popUpDiv_'+p[0];
				opts='&title='+p[0];
				pl=p.length;
				if(pl>1){
					for(var i=1;i<pl;i++){
						opts+='&var'+i+'='+p[i];
					}
				}
			break;
			case'crt':
				activeCol='popUpCrtDiv_'+p[1]+'_'+p[2];
				opts='&review='+p[0]+'&criteria='+p[1]+'&ca='+p[2]+'&review_id='+p[3]+'&valid='+p[4]+'&positionAbove='+p[5]+'&previousCriteria='+p[6]+'&review_group='+p[7]; //JFM 28_10_13 - 11_03_14
			break;
			case'crm':
				activeCol='popUpCrmDiv_'+p[0]+'_'+p[1];
				opts='&group='+p[0]+'&criteria='+p[1];
			break;
			case'cwp':
				activeCol='popUpCwpDiv_'+p[0];
				opts=(p[2])?'&cawp='+p[0]+'&program='+p[2]+'&coe='+p[3]+'&perimeter='+p[4]+'&msn='+p[5]:'&cawp='+p[0]+'&element_disabled='+p[1];
			break;
			case'msn':
				activeCol='popUpMsnDiv_'+p[1];
				opts='&program='+p[0]+'&msn='+p[1]+'&coe='+p[2];
			break;
			case'prg':
				activeCol='popUpProgDiv_'+p[0];
				opts='&program='+p[0]+'&area='+p[1]; //JFM 03_06_14
			break;
			case'prm':
				activeCol='popUpPrmDiv_'+p[1];
				opts='&program='+p[0]+'&perimeter='+p[1];
			break;
			case'rsp':
				activeCol='popUpRspDiv_'+p[1]+'_'+p[2];
				opts='&program='+p[0]+'&group_position='+p[1]+'&role_position='+p[2];
			break;
			case'std':
				var wId='popUp'+p[0]+'Div_'+p[1];
				activeCol=wId;
				opts='&window_id='+wId+'&case='+p[0].toLowerCase();
				if(p[1]!=''){
					pl=p.length;
					for(var i=1;i<pl;i++){
						opts+='&var'+(i-1)+'='+p[i];
					}
				}			
			break;
			case'tbl':
				activeCol='popUpDiv_'+p[0]+'_'+p[1];
				opts='&ca='+p[0]+'&review='+p[1]+'&cawp='+p[2]+'&element_disabled='+p[3]+'&editable_perimeter='+p[4];
			break;
			case'ttl':
				activeCol='popUpTtlDiv_'+p[0];
				opts='&title='+p[0];
				if(p[1]!=''){
					pl=p.length;
					for(var i=1;i<pl;i++){
						opts+='&var'+i+'='+p[i];
					}
				}
			break;
			case'cat': //JFM 21_08_13
				activeCol='popUpCatDiv_'+p[0];
				opts='&menuType='+p[0]+'&criterionId='+p[1]+'&reviewTypeName='+p[2]+'&reviewProfile='+p[3]+'&reviewID='+p[4]+'&criterionValid='+p[5]+'&table_cache_id='+p[6]; //JFM 09_09_13 - JFM 11_09_13 - JFM 23_09_13 - JFM 28_10_13
			break;
			case'are': //JFM 03_06_14
				activeCol='popUpAreaDiv_'+p[0];
				opts='&area='+p[0];
			break;
			case'usr': //JFM 16_01_15
				activeCol='popUpUsrDiv_'+p[0];
				opts='&userId='+p[0]+'&userName='+p[1];
			break;

			case'risk': //JFM 08_06_16
				activeCol='popUpRiskDiv_'+p[0];
				opts='&riskId='+p[0];
			break;

			case'role': //Added  Role Management screen by Infosys Limited
			activeCol='popUpRoleDiv_'+p[0];
			opts='&responsible_role_id='+p[0];
			break;
			
			// Added for Help section - US#114.1
                        case 'helpSec':
                                activeCol='popUpSecDiv_'+p[0];
                                opts='&help_section_id='+p[0];
                        break;
                        case 'addHelpSec':
                                activeCol='popUpSecDiv_'+p[0];
                                opts='&help_section_id='+p[0];
                        break;

			case'robust': //Added  Role Management screen by Infosys Limited
			activeCol='popUpRobustDiv_'+p[0];
			opts='&question_id='+p[0];
			break;



		}

		//alert('ajax/popUpOptions.php?location='+location+opts);
		ajaxRequest('ajax/popUpOptions.php?location='+location+opts,'showFilter',true,'GET');
		fltOn=true;
	}
}
function prevSel(ddt,store,value,retrieve,parameters){
	$('mainTitle').focus();
	processing=true;
	retrieveDdList(ddt,store,value,retrieve,parameters);
}
function reloadSideElement(mrn){
	reloadSideElementNeeded=0;
	if(exists(mrn)){
		mainRestartNeeded=mrn;
	}
	if(closeFormNeeded==1){
		closeLastForm();
	}
	if(exists(lastSideElementRequest[lastSideElementRequestCount])){
		ajaxRequest(lastSideElementRequest[lastSideElementRequestCount],'openSideElement',false,'GET');
	}
}
function removeCaWp(cawp,objectTxt){
	if(confirm('Are you sure you want to remove this '+objectTxt.toUpperCase()+'?\n\nIt will be just hidden. No data will disappear.')){
		mainRestartNeeded=1;
		ajaxRequest('ajax/saveStructure.php?objectTxt=cawp&mode='+((objectTxt=='ca')?'removeCa':'removeWp')+'&applicability='+cawp,'reloadSideElement',true,'POST');
	}
}
/***
 * Fix for : Bug-6
 * Funtion for removing the MSN value
 * Version: 4.2
 * @param {string} msn
 * @param {string} objectTxt
 * @param {array} cawp
 * @returns {undefined}
 */
function removeMsn(msn,objectTxt,cawp){
    if(cawp) {
        alert('The selected MSN has Group-Product mapping, kindly remove the mapping and try again');
    } else {
        if(confirm('Are you sure you want to remove this ' + objectTxt.toUpperCase() + '?\n\nIt will be just hidden. No data will disappear.')) {
            mainRestartNeeded = 1;
            if(objectTxt == 'Msn Data') {
                ajaxRequest('ajax/saveStructure.php?objectTxt=removemsn&mode=' + ((objectTxt == 'Msn Data') ? 'removeMsn' : '') + '&applicability=' + msn, 'reloadSideElement', true, 'POST');
            }
        }
    }
}
function removeCaWpPicture(t,tid){
	if(confirm('Are you sure you want to remove the picture of this '+t.toUpperCase()+'?')){
		ajaxRequest('ajax/removeCaWpPicture.php?target='+t+'&target_id='+tid,'removeCaWpPicture',true,'GET');
	}
}
function removeElement(element,id,txt){
	removeCase=element;
	if(confirm('Are you sure you want to remove the '+element+' '+txt+'?')){
		ajaxRequest('ajax/removeElement.php?element='+element+'&id='+id,'removeElement',true,'GET');
	}
}
function removeMainFilter(){
	var t=$('searchField');
	t.value='';
	txtBlr(t,'Search');
	searchChange(t);
	mfSearch('');
}
function removeOldFiles(){
	ajaxRequest('ajax/removeOldFiles.php','',true,'GET');
}

/**
 * Deprecated - Removes review profiles. Cannot be done in the new system to maintain legacy data.
 * @param  {var} id  ???
 * @param  {var} txt ???
 * @return {null}
 */
/*function removeReviewProfile(id,txt)
{
	if(confirm('Are you sure you want to remove the Review Configuration '+txt+'?\n\n\nIt will be completely removed for this Program/CoE.\n\nThis cannot be undone.'))
	{
		ajaxRequest('ajax/removeReviewProfile.php?review_profile='+id,'removeReviewProfile',true,'GET');
	}
}*/

/**
 * Waning message displayed when removing certain elements from structure management.
 * @param  {var} objectTxt        ???
 * @param  {var} caption          ???
 * @param  {var} applicability    ???
 * @param  {var} applicabilityTxt ???
 * @return {null}
 */
function removeStructureElement(objectTxt,caption,applicability,applicabilityTxt)
{
	if(confirm('Are you sure you want to remove the '+caption+' '+applicabilityTxt+'?\n\nTHIS OPERATION CANNOT BE UNDONE'))
	{
		ajaxRequest('ajax/removeStructureElement.php?objectTxt='+objectTxt+'&applicability='+applicability,'removeStructureElement',true,'GET');
	}
}

/**
 * Removed the stored table cache.
 * @param  {var} tableCacheId Table cache ID.
 * @return {null}
 */
function removeTableCache(tableCacheId)
{
	if(tableCacheId!='')
	{
		ajaxRequest('ajax/removeTableCache.php?tableCacheId='+tableCacheId,'removeTableCache',true,'GET'); //JFM 12_01_16 - Set to true.
	}
}

/**
 * Used to reset the held BRAG status icons current value.
 * Seems deprecated as this is now down in setStatusFocus but keeping it just in case.
 * @param  {var} mode
 * @return {null}
 */
function resetFormVars(mode)
{
	activeStatus='';
	//previousElement[sideWindowId]=0;
}

/**
 * Resets the various left hand sidebars around the tool.
 * @param  {var} windowCase ???
 * @return {null}
 */
function resetSideSelection(windowCase)
{
	setSideVars(windowCase);
	p=previousElement[sideWindowId];
	if($(sideElement+'_'+p)) $(sideElement+'_'+p).style.fontWeight='normal';
	actualSideElement[sideWindowId]=0;
	previousElement[sideWindowId]=0;
	emptyFormMessage(sideContainer);
}

/**
 * Reloads the main table to either dashboard or main table view without refreshing the page.
 * @param  {var} p ???
 * @return {null}
 */
function restartMainTable(p)
{
	var reviewsSelected='';

	if(!p)
	{
		p=$('storedView').innerHTML;
	}
	else
	{
		ajaxRequest('ajax/setView.php?filterName=view&value='+p,'doNothing',false,'GET');
	}
	if(p=='review_type')
	{
		//p='review_type='+$('reviewTypeSel').options[$('reviewTypeSel').selectedIndex].value;
		if(document.forms[0])
		{
			var length = document.forms[0].elements.length
			for(var i = 0; i < length; i++) 
			{
				if(document.forms[0].elements[i].checked) reviewsSelected+=document.forms[0].elements[i].id.substring(12)+',';
			}
			p='review_type='+reviewsSelected;
			ajaxRequest('ajax/setView.php?filterName=review_type_filter&value='+reviewsSelected,'doNothing',false,'GET');
		}
	}

	closeAllForms();
	activeTable='review_planning';
	mainTableWaitMessage();
	processing=true;

	//JFM 13_02_14 - JFM 03_06_14
	$('storedView').innerHTML=p;

	/* var tabArray  = Array('sumTab','tblTab','dshTab','schTab','schTab','schTab','ovwTab','wrlTab'); //JFM 02_12_15
	var caseArray = Array('sum','tbl','dsh','sch','review_type','review_type='+reviewsSelected,'ovw','wrl'); //JFM 02_12_15
	var pageArray = Array('summary','showTable','dashboard','schedule','schedule','schedule','overview','wrlModel'); //JFM 02_12_15 */
	var tabArray  = Array('sumTab','tblTab','dshTab','schTab','schTab','schTab','ovwTab','wrlTab'); //JFM 02_12_15
	var caseArray = Array('sum','tbl','dsh','sch','review_type','review_type='+reviewsSelected,'ovw','wrl'); //JFM 02_12_15
	var pageArray = Array('summary','showTable','dashboard','schedule','schedule','schedule','overview','wrlModel'); //JFM 02_12_15
	var hideArray = Array(1,0,0,0,0,0,1,0);
	var goTo = '';

	for (var i = 0; i < tabArray.length; i++) //JFM 15_09_15
	{
		if(caseArray[i] == p)
		{
			$(tabArray[i]).style.fontWeight 		='bold';
			$(tabArray[i]).style.height				='28px';
			$(tabArray[i]).style.backgroundColor	='#e7e7e8';
			$(tabArray[i]).style.color				='#004f6b';
			if(hideArray[i]) //JFM 12_01_16
			{
				$('mainTableLocation').style.width = '0px';
				$('mainTableLocation').style.overflow = 'hidden';
				$('tabBar').style.left='0';
				$('mainContainer').style.left='10px';
			}
			else 
			{
				$('mainTableLocation').style.width = '200px';
				$('mainTableLocation').style.overflow = 'auto';
				$('tabBar').style.left='200px';
				$('mainContainer').style.left='210px';
			}
			goTo = pageArray[i];
		}
		else if((goTo == 'schedule' && caseArray[i] != 'sch' && caseArray[i] != 'review_type' && caseArray[i] != 'review_type='+reviewsSelected) || goTo != 'schedule')
		{
			$(tabArray[i]).style.fontWeight 		= '';
			$(tabArray[i]).style.height				='22px';
			$(tabArray[i]).style.backgroundColor	='#6f95ab';
			$(tabArray[i]).style.color				='#FFFFFF';
		}
	}

	if(goTo=='') 
	{
		goTo = 'showTable';
		$('tblTab').style.fontWeight 		='bold';
		$('tblTab').style.height			='28px';
		$('tblTab').style.backgroundColor	='#e7e7e8';
		$('tblTab').style.color				='#004f6b';
	}

	ajaxRequest('ajax/'+goTo+'.php?tableCacheId=all&'+p,'showTable',true,'POST');
}

/**
 * Use to maintain the main Program, CoE and MSN drop down lists.
 * @param  {var} ddt        ???
 * @param  {var} store      ???
 * @param  {var} value      ???
 * @param  {var} retrieve   ???
 * @param  {var} parameters ???
 * @return {null}
 */
function retrieveDdList(ddt,store,value,retrieve,parameters)
{
	ddTarget=ddt;
	ajaxRequest('ajax/retrieveDdList.php?store='+store+'&value='+value+'&retrieve='+retrieve+parameters,'ddFill',false,'GET');
}

/**
 * Deprecated - Legacy function for saving criteria configurations which are now no longer used.
 * @param  {var} gr ???
 * @param  {var} cr ???
 * @return {null}
 */
/*function saveCriteriaConfig(gr,cr)
{
	refUrl=(cr!=0)?'&reference='+encodeURIComponent($('criteriaReference_'+gr+'_'+cr).value):'';
	ajaxRequest('ajax/saveCriteriaConfig.php?review_group_id='+gr+'&review_criteria_id='+cr+'&description='+encodeURIComponent($('criteriaDescription_'+gr+'_'+cr).value)+refUrl,'saveCriteriaConfig',true,'POST');
}*/

/**
 * Removes the item entered into the main search bar.
 * @param  {var} t
 * @return {null}
 */
function searchChange(t)
{
	var r=$('rmSearchImg');
	if(window.event.keyCode==13)
	{
		ssOn=true;
		mfSearch(t.value);
	}
	if(t.value!='' && t.value!='Search')
	{
		if(window.event.keyCode==9)t.value='';
		if(r.src.indexOf('searchBlank')!=-1)
		{
			r.src='../common/img/rmSearch.png';
			r.onclick=function(){removeMainFilter();};
			r.style.cursor='pointer';
		}
	}
	else if(r.src.indexOf('rmSearch')!=-1)
	{
		r.src='../common/img/searchBlank.png';
		r.onclick=function(){};
		r.style.cursor='normal';
	}
}

/**
 * The search magnifying glass on click function which is now fairly pointless as everything auto searches on key up.
 * It does add the "X" icon next to it so it could do with optimising.
 * @param  {var} searchTxt    Search term entered in box.
 * @param  {var} rmSearchImg  ???
 * @param  {var} inputId      Input boxes ID.
 * @param  {var} notFoundDiv  ???
 * @param  {var} searchListId ???
 * @return {null}
 */
function searchDivList(searchTxt,rmSearchImg,inputId,notFoundDiv,searchListId)
{
	if(searchTxt!='Search')
	{
		var r=$(rmSearchImg);
		var foundTxtIn='<span style="color:#FF0000"><b>';
		var foundTxtOut='</b></span>';
		if(!exists(searchListId))searchListId=0;
		s=searchTxt.toUpperCase();
		sLen=s.length
		found=0;
		first=1;
		var hTxt='';
		var inTxt='';
		
		dTxt2='';
		dTxt3='';
	
		searchLength=searchDivId[searchListId].length;
		for(var i=0;i<searchLength;i++)
		{
			div=$(searchDivId[searchListId][i]);
			dTxt=searchName[searchListId][i];
			if(sLen>0)
			{
				txtPos=dTxt.toUpperCase().indexOf(s);
				if(txtPos!=-1)
				{
					div.style.display='block';
					found=1;
					dTxt=dTxt.substring(0,txtPos)+foundTxtIn+dTxt.substring(txtPos,txtPos+sLen)+foundTxtOut+dTxt.substring(txtPos+sLen);
				}
				else div.style.display='none';
			}
			else
			{
				div.style.display='block';
			}
			div.innerHTML=dTxt;
		}
		if(s!='' && s!='Search')
		{
			r.src='../common/img/rmSearch.png';
			r.onclick=function()
			{
				$(inputId).value='';
				searchDivList('',rmSearchImg,inputId,notFoundDiv,searchListId);
				if(keepSearchFocus!=1)
				{
					txtBlr($(inputId),'Search');
				}
			};
			r.style.cursor='pointer';
			removeSearchId=r;
		}
		else
		{
			r.src='../common/img/searchBlank.png';
			r.onclick=function(){};
			r.style.cursor='normal';
			removeSearchId='';
		}
	}
	$(notFoundDiv).style.display=(searchTxt=='' || searchTxt=='Search' || found==1)?'none':'block';
}

/**
 * Select all elements from the left hand check box.
 * @param  {var} idList 
 * @return {null}
 */
function selectAll(idList)
{
	if(idList)
	{
		id=$(idList).value.split(',');
		for(var i in id)
		{
			$(idList+'_'+id[i]).checked=true;
		}
	}
	else
	{
		i=0;
		while($('caChk-'+i))
		{
			$('caChk-'+i).checked=true;
			chkBoxSel[i]=1;
			casSelected++;
			i++;
		}
	}
}

/**
 * Select one or more elements from the main table left hand check boxes.
 * @param  {var} k
 * @return {var}
 */
function selectCaElement(k)
{
	if(event.shiftKey==1)
	{
		selectCaRange(k); 
	}
	else
	{
		if($('caChk-'+k).checked==false)
		{
			casSelected--;
			chkBoxSel[k]=0;
		}
		else
		{
			chkBoxSel[k]=1;
			lastCaSelected=k;
			casSelected++;
		}
	}
}

/**
 * Used to select everything from the main table left hand check boxes if the shift key is held down.
 * Called from selectCaElement.
 * @param  {var} finalCa
 * @return {null}
 */
function selectCaRange(finalCa)
{
	if(lastCaSelected!=finalCa)
	{
		if(lastCaSelected>finalCa)
		{
			var minCa=finalCa;
			var maxCa=lastCaSelected;
		}
		else
		{
			var minCa=lastCaSelected;
			var maxCa=finalCa;
		}
		for(i=minCa;i<=maxCa;i++)
		{
			$('caChk-'+i).checked=true;
			chkBoxSel[i]=1;
			casSelected++;
		}
	}
}

/**
 * Displays the list of CAs in the program, coe and msn you have selected in the review window.
 * This list is filtered with the main table filters.
 * @return {null}
 */
function selectedCaList()
{
	caList=new Array();
	i=0;
	j=0;
	while($('caChk-'+i))
	{
		if(chkBoxSel[i]==1)
		{
			caPopUpId=$('caChk-'+i).nextSibling.id.split('_');
			caList[j]=caPopUpId[1];
			j++;
		}
		i++;
	}
	caListL=caList.length;
	if(caListL==0)
	{
		alert('No CA Selected.\n\nPlease select them from the checkbox list from the left side of the table.');
		validCaList=0;
		return false;
	}
	else
	{
		validCaList=1;
		return caList.join(',');
	}
}

/**
 * De-selects everything with ID caChk.
 * @return {null}
 */
function selectNone()
{
	casSelected=0;
	i=0;
	while($('caChk-'+i))
	{
		if(chkBoxSel[i]==1)
		{
			$('caChk-'+i).checked=false;
			chkBoxSel[i]=0;
		}
		i++;
	}
}

/**
 * Used to send an AJAX request.
 * Probably the single most important function in the tool.
 * @param  {var} formId
 * @param  {var} url
 * @param  {var} ajaxCase
 * @param  {var} respDiv
 * @param  {var} a
 * @param  {var} am
 * @return {null}
 */
function sendAjaxForm(formId,url,ajaxCase,respDiv,a,am)
{
	saveResponseDiv=(exists(respDiv))?respDiv:'';
	ajaxMethod=(exists(a))?a:'POST';
	asyncMethod=(exists(am) || am==false)?am:true;
	urlParameters=getFormString(formId);
	c=(url.indexOf('?')==-1 && urlParameters.indexOf('?')==-1)?'?':'';
	//alert(url+c+urlParameters,ajaxCase,asyncMethod,ajaxMethod);
	ajaxRequest(url+c+urlParameters,ajaxCase,asyncMethod,ajaxMethod);
}

/**
 * Used to send an email to a used with given user id.
 * What the email contains or when it's called I have no idea.
 * @param  {var} id
 * @return {null}
 */
function sendEmailUser(id)
{
	ajaxRequest('ajax/sendEmailUser.php?user_id='+id,'sendEmail',true,'GET');
}

/**
 * Used to send another user invitation email if it failed the first time or someone didn't pay attention to the first one a needs a reminder.
 * @param  {var} t
 * @param  {var} id
 * @return {null}
 */
function sendInvitation(t,id)
{
	if(confirm('When a user is created an invitation is sent automatically.\n\nAre you sure you want to send this user another email for the invitation?'))
	{
		t.disabled=true;
		reloadSideElementNeeded=1;
		ajaxRequest('ajax/sendInvitation.php?user_id='+id,'reloadSideElement',false,'GET');
	}
}

/**
 * Used to remove header items when no-longer hovering over them.
 */
function setHideTimer()
{
	if(!timerId)
	{
		timerId=window.setTimeout(hideMenu,timeOut);
	}
}

/**
 * Loads all the user drop down lists when you start typing.
 * @param {var} t
 * @param {var} c
 * @param {var} txt
 * @param {var} e
 * @param {var} id
 * @param {var} v
 */
function setInputFocus(t,c,txt,e,id,v)
{ //JFM 23_09_13
	if(t.className!='textarea')
	{
		t.onblur=function()
		{
			t.className='formInput';
			if(c)hideSuggest();
		};
		t.onfocus=function()
		{
			t.className='formInputFocused';
			if(c)loadUserSuggestion(this,c,txt,e,id,v);
		};
	}
}

/**
 * Deprecated - Used to set review configurations which no longer exist.
 * @param {var} group
 * @param {var} criteria
 * @param {var} profile
 * @param {var} newValue
 */
/*function setRevConfigValue(group,criteria,profile,newValue)
{
	ajaxRequest('ajax/setRevConfigValue.php?group='+group+'&criteria='+criteria+'&profile='+profile+'&newValue='+newValue,'setRevConfigValue',false,'GET');
}*/

/**
 * Pain in the arse function which calculates a whole bunch of crap when selecting something from the many left hand sidebars in the tool.
 * The only part of this worth paying attention too is sideAjaxFile and possibly sideContainer.
 * @param {var} w
 * @param {var} e
 */
function setSideVars(w,e)
{
	subFormQueryNeeded=1;
	switch(w)
	{
		case'cfc':
			sideElement='cfColElement';
			sideWindowId=3;
			sideAjaxFile=['displayedColumn'];
			sideContainer=['columnConfigSideContainer'];
			ajaxParameters=attachDdValue('program','cfcDdProgram')+attachDdValue('coe','cfcDdCoe');
		break;
		case'inn':
			sideElement='invalidNameElement';
			sideWindowId=5;
			sideAjaxFile=['invalidName'];
			sideContainer=['sideInvalidNameContainer'];
			ajaxParameters='';
		break;
		case'rev':
			sideElement='reviewCaWpElement';
			sideWindowId=6;
			sideAjaxFile=['reviewReport'];
			sideContainer=['subFormReviewReportContainer'];
			ajaxParameters=attachDdValue('review','rvmDdRevType')+'&target='+reviewCaWpTarget;
			/* JFM 03_06_14
			if(e)
			{
				actualSideElement[sideWindowId]=e;
			}
			if(exists(actualSideElement[sideWindowId]) && actualSideElement[sideWindowId]!=0)
			{
				cawp=reviewCaWpTarget.toUpperCase();
				$('collapsing_title_ca_info').innerHTML=cawp+' Information';
				$('collapsing_title_responsible').innerHTML=cawp+' Responsibles';
			}
			else
			{
				$('collapsing_title_ca_info').innerHTML=$('collapsing_title_responsible').innerHTML='No CA/WP Selected';
				subFormQueryNeeded=0;
			}
			ddrtTxt=ddSelectedText('rvmDdRevType');
			$('collapsing_title_review_report').innerHTML=(ddrtTxt!='')?ddrtTxt+' Review':'No Review Selected';
			*/
		break;
		case'rvm':
			sideElement='reviewElement';
			sideWindowId=2;
			sideAjaxFile=['reviewConfig'];
			sideContainer=['reviewConfigContainer'];
			ajaxParameters='';
		break;
		case'scs':
			sideElement='screenshotElement';
			sideWindowId=7;
			sideAjaxFile=['screenshot'];
			sideContainer=['sideScreenshotContainer'];
			ajaxParameters='';		
		break;
		case'str':
			sideElement='structureElement';
			sideWindowId=4;
			sideAjaxFile=['structureConfig'];
			sideContainer=['sideStructureContainer'];
			ajaxParameters=attachDdValue('area','strDdArea')+attachDdValue('program','strDdProgram')+attachDdValue('coe','strDdCoe')+attachDdValue('perimeter','strDdPerimeter')+attachDdValue('msn','strDdMsn'); //JFM 03_06_14
		break;
		case'usr':
			sideElement='userElement';
			sideWindowId=1;
			sideAjaxFile=['userPermissions'];
			sideContainer=['userRightsContainer'];
			ajaxParameters='';
		break;
		case'cat':	//JFM 23_09_13
			sideElement='catElement';
			sideWindowId=9;
			sideAjaxFile=['../form/list'];
			sideContainer=['sideCatContainer'];
			ajaxParameters='';		
		break;
		case'valid':	//JFM 02_10_13
			sideElement='validationElement';
			sideWindowId=10;
			sideAjaxFile=['validationRespond'];
			sideContainer=['sideValidationContainer'];
			ajaxParameters='';		
		break;
		default:
			sideWindowId=0;
		break;
	}
}

/**
 * Sets the status icons when selecting.
 * @param {var} t
 * @param {var} startValue
 */
function setStatusFocus(t,startValue)
{
	id=t.id.split('_');
	t.src='../common/img/'+id[1]+'30.png';
	activeStatus=''; //JFM 09_04_14

	if(activeStatus=='')
	{
		activeStatus=($(startValue).value=='')?0:$(startValue).value;
	}

	t.onblur=function()
	{
		if(activeStatus!=id[1])
		{
			t.src='../common/img/'+id[1]+'30off.png';
		}
	};

	t.onclick=function()
	{
		if(activeStatus!=id[1] && $(id[0]+'_'+activeStatus))$(id[0]+'_'+activeStatus).src='../common/img/'+activeStatus+'30off.png';
		$(startValue).value=activeStatus=id[1];

		if(startValue == 'review_status' || startValue == 'initial_review_status') //JFM 19_07_16
		{
			$('review_done').checked = true;

			if($('review_date').value == "") //JFM 19_07_16
			{
				var reviewDate = new Date();
				var day = reviewDate.getDate();
				var month = reviewDate.getMonth() + 1;

				if(day < 10)
					day = "" + 0 + day;
				if(month < 10)
					month = "" + 0 + month;

				$('review_date').value = reviewDate.getFullYear() + "-" + month + "-" + day;
			}
		}
	};

	t.onmouseout=function()
	{
		if(activeStatus!=id[1])
		{
			t.src='../common/img/'+id[1]+'30off.png';activeStatus='';
		}
	};
}

/**
 * Displays the drop down menu when hovering over the icons on the main page.
 * @param  {var} id
 * @param  {var} type
 * @return {null}
 */
function showMenu(id,type)
{
	if(timerId)
	{
		window.clearTimeout(timerId);
		timerId=null;
	}
	if(processing==false && (lastMenuShown==null || $(id+'_m').innerHTML!=lastMenuShown.innerHTML))
	{
		if(lastMenuShown) hideMenu();

		lastMenuShown=$(id+'_m');
		lastMenuShown.style.display='block';

		if(type=='header')
		{
			//$(id+'_c').style.borderColor='#565C6A';
			$(id+'_c').style.height='30px';
			$(id+'_c').style.backgroundColor='#FFFFFF';
			if(id=='valid')
			{
				if($('validNumber').innerHTML=='') $(id+'Img').src="../common/img/xvalidOff.png";
				else $(id+'Img').src="../common/img/xvalidOn.png";
			}
			else $(id+'Img').src="../common/img/x"+id+".png";
			if($(id+'_m').innerHTML=='' || id=="valid")
			{
				ajaxRequest('ajax/headerMenu.php?id='+id,'headerMenu',true);
			}
		}
	}
	else
	{
		//???
	}
}

/**
 * Displays the message after a updateData call.
 * @param  {var} id
 * @param  {var} message
 * @param  {var} color
 * @return {null}
 */
function showSaveResponse(id,message,color)
{
	if(chkTOutId!='')
	{
		chkTOut=clearTimeout(chkTOut);
		if($(chkTOutId))$(chkTOutId).style.display='none';
	}

	if($(id))
	{
		$(id).style.display='inline';
		$(id).style.visibility='visible';
		if($(id).innerHTML=='')$(id).innerHTML=(!exists(message))?'Changes were applied':message;
		if(color)$(id).style.color=color;
		chkTOut=setTimeout('if($(\''+id+'\'))$(\''+id+'\').style.display=\'none\';',1000);
		chkTOutId=id;
	}
}

/**
 * Deprecated - Changes the sidebar view in the review window from displaying CAs to displaying WPs.
 * @param  {var} t
 * @return {null}
 */
/*function sideCaWp(t){
	reviewCaWpTarget=t;
	resetSideSelection('rev');
	containerDiv='reviewCaWpList';
	ajaxRequest('ajax/sideCaWp.php?target='+t+'&main_table_cache_id='+mainTableCacheId,'putInDiv',false,'GET');
	loadSearchElements('reviewCaWpList',1);
}*/

/**
 * Displays the criteria groups in the Criteria Catalog Management window.
 * @param  {int} reviewProfile
 * @param  {var} reviewTypeName
 * @param  {int} reviewID
 * @return {null}
 */
function sideCriteriaGroups(reviewProfile,reviewTypeName,reviewID){
	resetSideSelection('cat');
	containerDiv='catContainer';
	ajaxRequest('ajax/sideCriteriaGroups.php?review_profile='+reviewProfile+'&reviewTypeName='+reviewTypeName+'&reviewID='+reviewID,'putInDiv',false,'POST');
}

/**
 * Sets the drop down box in the review window sidebar and change the sidebar contents accordingly.
 * @return {null}
 */
function sideReviews()
{
	resetSideSelection('rvm');
	containerDiv='reviewList';
	ajaxRequest('ajax/sideReviews.php?'+attachDdValue('program','revDdProgram')+attachDdValue('coe','revDdCoe'),'putInDiv',false,'GET');
}

/**
 * Sets the drop down box in the validation window sidebar and change the sidebar contents accordingly.
 * @param  {var} objectID
 * @return {null}
 */
function sideValidation(objectID)
{
	if(objectID=='findMe') objectID=$('validationType').options[$('validationType').selectedIndex].value;

	for (var i=0; i<$('validationType').options.length; i++) //JFM 09_04_14
	{
	    if ($('validationType').options[i].value == objectID)
	    {
	        $('validationType').options[i].selected = true;
	        break;
	    }
	}

	resetSideSelection('valid');
	containerDiv='validationList';
	ajaxRequest('ajax/sideValidation.php?object='+objectID,'putInDiv',false,'GET');
}

/**
 * Checks is something has been entered into the top search bar on the main page.
 * @return {null}
 */
function ssCheck()
{
	if(searchField.value!='')ssOn=true;
}

/**
 * Used for date filters. I don't know what it does.
 * @param  {array} array
 * @param  {var} id
 * @return {null}
 */
function storeDates(array,id)
{
	var y,m,d;
	arrL=array.length;
	for(i=0;i<arrL;i++)
	{
		t=id+'-'+array[i];
		y=$(t+'Y').value;
		m=$(t+'M').value;
		d=$(t+'D').value;
		$(t).value=(y==''||m==''||d=='')?'':y+'-'+m+'-'+d;
	}
}

/**
 * Used in ajax.js "showFilter" case to store formInitVal vairables. I have no idea what it's used for...
 * @param  {var} formId
 * @return {null}
 */
function storeInitialValues(formId)
{
	form=$(formId);
	formInitVal=Array();
	var formL=form.elements.length;
	for(var i=0;i<formL;i++)
	{
		f=form.elements[i];
		if(f.name!='' && (f.type!='radio' || (f.type=='radio' && f.checked==true)))
		{
			formInitVal[i]=(f.type=='checkbox')?f.checked:f.value;
		}
	}
}

/**
 * Deprecated - Used for legacy "View only relevant criteria" option.
 * @param  {var} t
 * @return {null}
 */
/*function switchCriteriaView(t){
	var tbl=$('criteriaTable');
	c=t.checked;
	if(tbl.hasChildNodes() && tbl.firstChild.hasChildNodes()){
		var r=tbl.firstChild.firstChild;
		var d=(c)?'none':'table-row';
		var b=(c)?'none':'inline';
		var tc=(c)?'#CCCCCC':'#000000';
		var bc=(c)?'#FFFFFF':'#FFFBCC';
		do{
			switch(r.criteriaStatus){
				case '1':
					var idA=r.id.split('-');
					var cId=idA[2];
					imgId=$('criteria_status_'+cId);
					imgSrc=(c)?'na':imgId.originalStatus;
					imgId.src='../common/img/'+imgSrc+'20.jpg';
					$('criteria_description_'+cId).style.color=tc;
					$('criteria_comments_'+cId).style.color=tc;
					$('criteria_reference_'+cId).style.color=tc;
					$('criteria_popup_button_'+cId).style.display=b;
					r.style.backgroundColor=bc;
					closeMenu(activeCol);
				break;
				case '2':
					r.style.display=d;
				break;
			}
		}while(r=r.nextSibling);
		ajaxRequest('ajax/switchCriteriaView.php?v='+c,'',true,'GET');
	}

}*/

/**
 * Used to get the correct php file after filters have been applied to a table.
 * @param  {var} table
 * @return {string}
 */
function tableProcessor(table)
{
	switch(table)
	{
		case 'review_planning':
			return 'showTable';
		break;
		case 'action':
		case 'change':
		case 'rid':
		case 'cat': //JFM 02_09_13
		case 'evd': //JFM 28_04_14
		case 'usr': //JFM 16_01_15
			return 'list';
		break;
	}
}

/**
 * Addeds the word pass to fld (usually "Search") to search bar passed with t.
 * @param  {[type]} t
 * @param  {[type]} fld
 * @return {[type]}
 */
function txtBlr(t,fld){
	if(t.value==''){
		t.value=fld;
		t.style.color='#999999';
	}
	keepSearchFocus=0;
}

/**
 * Removes the word passed to fld (usually "Search") from search bar passed with t.
 * @param  {var} t
 * @param  {var} fld
 * @return {null}
 */
function txtOF(t,fld)
{
	if(t.value==fld)
	{
		t.value='';
		t.style.color='#000000';
	}
}

/**
 * Updates the table on the A0 Report panel when different sidebar options are selected.
 * @return {null}
 */
function updateA0ReportPreview()
{
	containerDiv='a0ReportContentContainer';
	sendAjaxForm('generateA0ReportFrm','ajax/a0ReportPreview.php','putInDiv','false','GET');
}

/**
 * Called from ajax.js after a successful updateData ajax request.
 * Automatically updates website based on the return calls from various php pages.
 * @param  {var} rt
 * @return {null}
 */
function updateData(rt)
{
	//alert(rt);
	if(rt.length>1)
	{
		element=rt.split('&&&');
		for(i in element)
		{
			if(element[i]=='reloadSideElementNeeded')
			{
				reloadSideElementNeeded=1;
			}
			else
			{
				field=element[i].split('%%%');
				parameter=field[2];
				var f=null;
				if($(field[0])) f=$(field[0]);
				else if(parent.$(field[0])) f=parent.$(field[0]);
				else if($('t_'+field[0])) f=$('t_'+field[0]);

				if(f)
				{
					switch(field[1])
					{
						case'action':
							destroyInnerHTML(f);
							f.innerHTML=(parameter=='0')?'':parameter;
						break;

						case 'boolean':
						case'checkbox':
							f.checked=(parameter==1)?true:false;
						break;

						case'date':
							parameter=field[2].split('###');
							updRevDate(parameter,field[0],0);
						break;

						case'disabled':
							f.disabled=(parameter==1)?true:false;
						break;

						case'history':
							historyUnit=field[2].split('###');
							destroyInnerHTML($(field[0]));
							html='<div class="historyWrap">';
							for(j in historyUnit)
							{
								historyElement=historyUnit[j].split('***');
								html+='<div><span class="logLink"onClick="sendEmailUser(\''+historyElement[0]+'\');">'+historyElement[1]+'</span> on '+historyElement[2]+':<br><br>'+historyElement[3]+'</div>';
							}
							$(field[0]).innerHTML=html+'</div>';
						break;

						case'img':
							f.src='../common/img/'+parameter;
						break;

						case'link':
							if(parameter!='')
							{
								f.innerHTML='&raquo;';

								if(parameter.indexOf('http://')==-1)
								{
									parameter='http://'+parameter;
								}

								f.href=parameter;
							}else{
								f.innerHTML='';
							}
						break;

						case'listElement':
							parameter=field[2].split('###');
							f.innerHTML=parameter[0];
							if(parameter[1]!='' && parameter[2]!='')
							{
								for(var j in searchElId[parameter[2]])
								{
									if(searchElId[parameter[2]][j]==parameter[1])
									{
										searchName[parameter[2]][j]=parameter[0];
									}
								}
							}
						break;

						case 'row':
							//alert(f.innerHTML);
							//f.innerHTML+=parameter;
							attachRowToTable(field[2],field[0]);
						break;

						case 'screenshot':
							parameter=field[2].split('###');
							var plural=(parameter[1]>1)?'s':'';
							f.innerHTML='<span class="screenshot"onClick="openForm(\'screenshot\',\'change_id='+parameter[0]+'\',false,\'GET\');"onMouseOut="nd();"onMouseOver="overlib(\'Click to open a window with all the screenshots.\');">'+parameter[1]+' Screenshot'+plural+'</span>';
						break;

						case'status':
							imageTag=(f.nodeName.toLowerCase()=='td')?f.firstChild:f;
							//alert(parameter+'###'+statusImg[parameter]);
							if(exists(statusImg[parameter]))
							{
								if(imageTag.id.substring(0,2)=='t_') imageTag.src='../common/img/'+statusImg[parameter]+'30t.png';
								else imageTag.src='../common/img/'+statusImg[parameter]+'20.png';

								if(imageTag.id=='rid_status' && $('ridStatus_r')) //JFM 30_10_14
								{
									switch(parameter)
									{
										case "0":
											$('ridStatus_r').src='../common/img/r30.png';
											$('ridStatus_a').src='../common/img/a30off.png';
											$('ridStatus_g').src='../common/img/g30off.png';
											$('ridStatus_x').src='../common/img/x30off.png';
										break;
										case "1":
											$('ridStatus_r').src='../common/img/r30off.png';
											$('ridStatus_a').src='../common/img/a30.png';
											$('ridStatus_g').src='../common/img/g30off.png';
											$('ridStatus_x').src='../common/img/x30off.png';
										break;
										case "2":
											$('ridStatus_r').src='../common/img/r30off.png';
											$('ridStatus_a').src='../common/img/a30off.png';
											$('ridStatus_g').src='../common/img/g30.png';
											$('ridStatus_x').src='../common/img/x30off.png';
										break;
										case "3":
											$('ridStatus_r').src='../common/img/r30off.png';
											$('ridStatus_a').src='../common/img/a30off.png';
											$('ridStatus_g').src='../common/img/g30off.png';
											$('ridStatus_x').src='../common/img/x30.png';
										break;
									}
								}
							}
						break;

						case'user':
							f.value=parameter;
						break;

						case'text':
							if(parameter!='') f.innerHTML=parameter; //JFM 30_10_14
						break;

						case 'trend': //JFM 08_06_16
							if(field[2]==0)
							{
								f.innerHTML="";
							}
							else
							{
								var trendImage = (f.nodeName.toLowerCase()=='td')?f.firstChild:f;
								if(trendImage)
									trendImage.src='../common/img/t20'+field[2]+'.png';
								else
									f.innerHTML='<img src="../common/img/t20'+field[2]+'.png">';
							}
						break;
					}
				}
				else
				{
					switch(field[1])
					{
						case'main_restart_needed':
							if(parameter==1)
							{
								mainRestartNeeded=1;
							}
						break;
					}
				}
			}
		}
	}

	showSaveResponse(saveResponseDiv);

	if($('finishingUser') && $('finishingUser').value=='1')
	{
		alert('Changes were applied. Now you will be redirected to the login area.');
		window.location='../index.php';
	}
}

/**
 * Displays how quickly a given page is loaded in seconds.
 * Works for refresh & AJAX calls.
 * @param  {var} r
 * @return {null}
 */
function updateResultsStatistics(r)
{
	//$('resultsStatistics').innerHTML=(r==1)?'':'<b>'+$('result_count').value+'</b> results | <b>'+$('processing_time').value+'</b> seconds';
}

/**
 * Used in updateData to update the review date on the main table. Setting it red if not performed and passed the date etc.
 * @param  {var} cwD
 * @param  {var} dateId
 * @param  {var} pos
 * @return {null}
 */
function updRevDate(cwD,dateId,pos)
{
	dArr=cwD[pos].split('-');
	revDate.setFullYear(dArr[0],dArr[1]-1,dArr[2]);

	if($(dateId).type=='text')
	{
		$(dateId).value=(cwD[pos]=='0000-00-00')?'':cwD[pos];
	}
	else
	{
		$(dateId).innerHTML=(cwD[pos]=='0000-00-00')?'':cwD[pos];
		$(dateId).style.color=(cwD[pos+1]==0 && revDate<today)?'#FF0000':'#000000';
		$(dateId).style.fontWeight=(cwD[pos+1]==0 && revDate<today)?'bold':'normal';
	}
}

/**
 * Relaunch the web page as the selected user.
 * @param  {int} user
 * @param  {int} active
 * @return {null}
 */
function viewAs(user,active)
{
	ajaxRequest('ajax/viewAs.php?user='+user,'viewAs',true,'GET');
}




//-------------------JFM START----------------------------

var application3dxml,
	selection3dxml,
	application3dxmlPlayerService,
	application3dxmlToolbar,
	application3dxmlCurrentSelection,
	application3dxmlToolbarCommand=new Array();

/**
 * Shows or hides 3D XML viewer.
 * @return {null}
 */
function load3dxml()
{
	if($('3dxmlContainer').innerHTML=='') 
	{
		$('3dxmlContainer').innerHTML='<object type="application/x-3dxmlplugin" id="3dxml" width="960" height="500" style="MARGIN: 0px" border="0" align="center"><param name="DocumentFile" value="archive/A350-900_zoning.3dxml"></object><div id="3dxmlTraceDiv" width="75%" height="25px"><textarea id="3dxmlTrace" rows="7" cols="100"></textarea></div>';
		$('3dxmlContainerDisplay').value='Hide 3DXML';
	}
	else
	{
		$('3dxmlContainer').innerHTML='';
		$('3dxmlContainerDisplay').value='Show 3DXML';
	}
}

/**
 * Used when calling different events in the 3D XML viewer.
 * NOT USED HOWEVER STILL USEFUL FOR FUTURE PORJECTS.
 * @param  {var} EventCategory
 * @param  {var} EventName
 * @param  {var} EventSender
 * @param  {var} EventParameters
 * @return {null}
 */
function catia3dxmlWindowEvents(EventCategory, EventName, EventSender, EventParameters) //JFM 21_02_14
{
	switch (EventCategory)
	{
		case 'Application':
			if (EventName == 'Ready')
			{ 
				application3dxml = EventSender;
				selection3dxml = EventSender.ActiveEditor.Selection;
				application3dxmlPlayerService = EventSender.GetSessionService('PlayerService');
				application3dxmlPlayerService.SendMouseEvent(true);
				/*application3dxmlToolbar = application3dxmlPlayerService.CreateToolbar('tools');
				application3dxmlToolbarCommand['go_to_review'] = application3dxmlPlayerService.CreateCommand(application3dxmlToolbar, 'push', '', 'Go To Review', 'Searches for the current parts CA/WP reviews.', 'URL_TO_IMG_HERE');
*/

			}
		break;

		case 'Selection':
			switch (EventName)
			{
				case 'Add':
					application3dxmlPlayerService.SendMouseEvent(true);
					selection3dxml.Count;
					var selectedItem3dxml = selection3dxml.Item(1);
					var selectedIdPath3dxml = application3dxml.CreateIDPathFromReference(selectedItem3dxml);
					var selectedItem3dxmlPropertiesArray = application3dxmlPlayerService.GetObjectProperties(selectedItem3dxml);

					for (i=1; i<selectedItem3dxmlPropertiesArray.Count; i++)
					{
						selectedItem3dxmlPropertiesArray.Count;

						if(selectedItem3dxmlPropertiesArray.Item(i+1)!='')
						{
							$('3dxmlTrace').value = $('3dxmlTrace').value+selectedItem3dxmlPropertiesArray.Item(i)+'='+selectedItem3dxmlPropertiesArray.Item(i+1)+'\n';
							$('3dxmlTrace').scrollTop=$('3dxmlTrace').scrollHeight;
						}

						if(selectedItem3dxmlPropertiesArray.Item(i) == 'Product DS.Part Number') application3dxmlCurrentSelection=selectedItem3dxmlPropertiesArray.Item(i+1);
						
						i=i+1;
					}

				break;

				case 'Remove':
				break;
			}
		break;

		case 'Command':
			if(EventParameters.Item(1)==application3dxmlToolbarCommand['go_to_review'])
			{
				if(selection3dxml.Count != 1)
				{
					$('3dxmlTrace').value = $('3dxmlTrace').value+'Please select only 1 item.\n';
				}
				else
				{
					$('dashboard_check').checked = false;
					ajaxRequest('ajax/setDashboard.php?value=0&mainFilter='+application3dxmlCurrentSelection,'restartMainTable',true,'GET'); //JFM 21_02_14;
					location.reload(true);
				}
			}
		break;
	}
}

/**
 * Changes the drop downs Program, CoE & MSN on the main table when selecting a graph segment from dashboard view.
 * This is so if an action is edited in a different CoE and MSN to the graph selected it doesn't break horribly.
 * @param  {var} coeID
 * @param  {var} msnID
 * @param  {var} programID
 * @param  {var} caName
 * @return {null}
 */
function changeDropDownWhenGraphOptionSelected(coeID, msnID, programID, caName, areaID) //JFM 18_03_14 - JFM 07_04_14
{
	/*if(programID!='' && programID!='program' && typeof programID!=='undefined')
	{
		explorerMenuExpand('','program_'+programID+'_area_'+areaID, true);
	}*/

	if(coeID!='' && coeID!='coe')
	{
		explorerMenuExpand('','coe_'+coeID+'_program_'+programID+'_area_'+areaID, true);
	}

	if(msnID!='' && msnID!='msn')
	{
		explorerMenuExpand('','msn_'+msnID+'_coe_'+coeID+'_program_'+programID+'_area_'+areaID, true);
	}

	if(caName!='' && typeof caName!=='undefined')
	{
		$('dashboard_check').checked = false;
		ajaxRequest('ajax/setDashboard.php?value=0&mainFilter='+caName,'restartMainTable',true,'GET'); //JFM 21_02_14;
		location.reload(true);
	}
}

/**
 * Hides or shows a <div>'s contents or expands a textareas number of rows depending on passed params.
 * @param  {var} id
 * @param  {var} params
 * @return {null}
 */
function colapseDivFromID(id,params)
{
	if($(id))
	{
		if(params=='textarea')
		{
			if($(id).style.height=='100px') 
			{
				$(id).style.height='500px';
				$(id+'_arrow').innerHTML='&#9650;'
			}
			else
			{
				$(id).style.height='100px';
				$(id+'_arrow').innerHTML='&#9660;'
			}
		}
		else
		{
			if($(id).style.display=='none') 
			{
				$(id).style.display='block';
				$(id+'_arrow').innerHTML='&#9650;'
			}
			else
			{
				$(id).style.display='none';
				$(id+'_arrow').innerHTML='&#9660;'
			}
		}
	}
}

/**
 * Disables everything within a given form.
 * @return {null}
 */
function disableAllFormElements()
{
	var limit = document.forms[0].elements.length;

    for (i=0;i<limit;i++) 
	{
      document.forms[0].elements[i].disabled = true;
    }
    
    disableAllFormElementsNeeded=0;
}

/**
 * Ticks everything within a contained form.
 * @param  {var} formName
 * @param  {var} as
 * @return {null}
 */
function tickAllTheThings(formName,as)
{
	for(w=0; w<document.forms[formName].elements.length; w++)
	{
		var input=document.forms[formName].elements[w];
		
		if(input.type=='checkbox') input.checked = as;
	}
}

/**
 * Unhides review type rows from dashboard views action and RID tables.
 * @param  {var} table
 * @param  {var} rowId
 * @return {null}
 */
function expandGraphTableReview(table,rowId) //JFM 14_01_14
{
	var numberOfRows=$(table).rows.length;
	for(var y=0; y<numberOfRows; y++)
	{
		if($(table).rows[y].id && $(table).rows[y].id.substring(0,3)!='RSP') //JFM 16_01_15
		{
			if($(table).rows[y].id==rowId) $(table).rows[y].style.display=''; //JFM 16_01_15
			else $(table).rows[y].style.display='none';
		}
	}
}

/**
 * Used to draw the graphs from dashboard view
 * @param  {var} graphId
 * @param  {array} countEverything
 * @return {null}
 */
function graphThis(graphId, countEverything, type, biggestBar, numberOfGroups, graphHolder, graphName, burnUpFromAjaxExtraInfo) //JFM 20_05_14
{
	//			Remember this!
	//			--------------
	//  		  Math.PI*1.5
	//				  270
	//		 		   |
	//	Math.PI  180 --+-- 0
	//		 		   |   |
	//		 		  90 <-+
	//   		   Math.PI*0.5

	if(!$(graphId)) // Check that the graph isn't already displayed.
	{
		//var customRadius		=	$('graphSize').options[$('graphSize').selectedIndex].value;	// Get selected graph size.
		var graphHolder 		=	(graphHolder ? $(graphHolder) : $('graphHolder'));			// Div where the canvas' will be stored.
		var downloadGraphHolder = 	$('downloadGraphHolder');									// Div of the download XLSX button.

		switch(type)
		{
			case 'pie':
				if(biggestBar!='no') //Don't ask me why this is here. Can't remember. Not looking it up. Best not touch it!
				{
					var graphPlaceholder='<div style="position:absolute; width:300px; display:inline; margin-top:260px;">';
						graphPlaceholder+='<form style="padding-left:120px; display:inline; align:center;" id="test" action="support/graphsDownload.php" encType="multipart/form-data" method="post">';
							graphPlaceholder+='<input name="title" id="title" type="hidden" value="'+countEverything[0].replace('\\n',' ')+'"/>';
							graphPlaceholder+='<input name="red" id="red" type="hidden" value="'+countEverything[2]+'"/>';
							graphPlaceholder+='<input name="yellow" id="yellow" type="hidden" value="'+countEverything[3]+'"/>';
							graphPlaceholder+='<input name="green" id="green" type="hidden" value="'+countEverything[4]+'"/>';
							graphPlaceholder+='<input name="blue" id="blue" type="hidden" value="'+countEverything[5]+'"/>';
							graphPlaceholder+='<input type="image" src="../common/img/download.png" />';
							graphPlaceholder+='</form>';
						graphPlaceholder+='<input style="padding-left:20px; display:inline;" type="image" src="../common/img/trash.png" onclick="mainRestartNeeded=1; ajaxRequest(\'ajax/setGraph.php?value=0&applicability='+graphId+'_check\',\'restartMainTable\',true,\'GET\');"/>';
					graphPlaceholder+='</div>';
					//graphHolder.innerHTML+='<div><form id="test" action="support/graphsDownload.php" encType="multipart/form-data" method="post"><input name="title" id="title" type="hidden" value="'+countEverything[0].replace('\\n',' ')+'"/><input name="red" id="red" type="hidden" value="'+countEverything[2]+'"/><input name="yellow" id="yellow" type="hidden" value="'+countEverything[3]+'"/><input name="green" id="green" type="hidden" value="'+countEverything[4]+'"/><input name="blue" id="blue" type="hidden" value="'+countEverything[5]+'"/><input style="vertical-align: top;" type="image" src="../common/img/burn_up_small.png" /></form><input style="vertical-align: top;" type="image" src="../common/img/burn_up_small_blue.png" onclick="mainRestartNeeded=1; ajaxRequest(\'ajax/setGraph.php?value=0&applicability='+graphId+'_check\',\'restartMainTable\',true,\'GET\');"/></div>';
					
					graphHolder.innerHTML+=graphPlaceholder;
				}
 				if(typeof G_vmlCanvasManager !== "undefined") //JFM 12_01_16
				{
					var canvas=document.createElement('canvas');	// We will setup the canvas dynamically so we can get many in one div.
					canvas.setAttribute("width", 300);				// Also it's hard for IE8 to get a static canvas through an AJAX call.
					canvas.setAttribute("height",300);				// Also it makes the code a bit more generic.
					canvas.setAttribute("id", graphId);
					graphHolder.appendChild(canvas);

					canvas=G_vmlCanvasManager.initElement(canvas);	// Do this thing so dynamic setup of the canvas works correctly.
					var ctx=canvas.getContext('2d');				// Get canvas context - SO IMPORTANT!!!

					var centerX=(canvas.width/2);					// Setup calculations
					var centerY=(canvas.height/2);
					var radius =(canvas.width/3);
				}
				else
				{
					var ctx = new C2S(300,300);
					var centerX=(150);					// Setup calculations
					var centerY=(150);
					var radius =(100);
				}

				ctx.font='18px Arial';							// Draw the canvas header.
				ctx.fillStyle='black';
				ctx.textAlign='center';
				var splitlongheader=countEverything[0].split('\\n');
				ctx.fillText(splitlongheader[0],150,15,250);
				if(splitlongheader[1]) ctx.fillText(splitlongheader[1],150,35,250);

				var colours=Array('#ef343f','#f8d707','#81c341','#0088cf','black');

				var pieStart=0;
				var labelPosition=3;
				var previousLabelPosition=3;

				for (var i = 2; i < countEverything.length; i++) 
				{
					if(countEverything[i])
					{
						graphOnClickStatus=(i-2);
						var pieEnd=pieStart+(((countEverything[i]/countEverything[1])*360)*(Math.PI/180));	// Calculate correct angle in radians.

						// Start drawing pie.
						ctx.beginPath();											// Start drawing! :D
						ctx.moveTo(centerX,centerY);								// Move the start point to the middle.
						ctx.arc(centerX, centerY, radius, pieStart, pieEnd, false, true);// Draw the arc for the pie.
						ctx.lineTo(centerX,centerY);								// Move the point back to the middle otherwise the ctx.fill breaks.
						ctx.closePath();											// Stop drawing. :(
						ctx.fillStyle=colours[(i-2)];								// Setup colour and fill.
						ctx.fill();
						// Stop drawing pie.

						// Start drawing labels.
						ctx.save();						// Save the rotation & translation from the current context.

						ctx.font='14px Arial';			// Setup label style.
						ctx.fillStyle='white';
						ctx.textAlign='center';

						ctx.translate(centerX,centerY);	// Move the context to the center of the canvas.
						ctx.rotate(pieEnd);				// Rotate by how much this chunk of pie has gone around.

						if((pieEnd-pieStart) < Math.PI*0.2) 
						{
							ctx.fillStyle=colours[(i-2)];
							labelPosition=1.4;	// This is here so labels don't draw over themselves if the angle isn't big enough.
							if(previousLabelPosition==labelPosition) labelPosition=labelPosition-0.1; // This is hear to stop the labels that were drawing over themselves
																									  // from drawing over themselves. This is very confusing, I know.
						}

						if(pieEnd > Math.PI*0.5 && pieEnd < Math.PI*1.5)	// If the angle is between 90 and 270 degrees the text will be upside-down.
						{													// This fixes that.
							ctx.translate(centerX/labelPosition,0);			// Set the center point to where the label will be printed.
							ctx.rotate(Math.PI);							// Rotate it 180 degrees
							ctx.fillText(countEverything[i],0,14);			// Print the label (and move it down by the font size)

						}
						else ctx.fillText(countEverything[i],centerX/labelPosition,0);	// Otherwise just print the thing.
						

						ctx.restore();					// Restore our old canvas settings so the rest of the pie chart doesn't break.
						// Stop drawing labels.

						pieStart=pieEnd;
						previousLabelPosition=labelPosition;
						labelPosition=3;
					}
				}
				if(typeof G_vmlCanvasManager === "undefined") //JFM 12_01_16
				{
					var mySerializedSVG = ctx.getSerializedSvg(true);
					var svgdiv=document.createElement('div');
					svgdiv.setAttribute("width", 300);
					svgdiv.setAttribute("height",300);
//					svgdiv.style.setAttribute("display","inline");
					graphHolder.appendChild(svgdiv);
					svgdiv.innerHTML = mySerializedSVG;
				}
			break;

			case 'stackedBar':
				var canvas=document.createElement('canvas');	// We will setup the canvas dynamically so we can get many in one div.
				canvas.setAttribute("width", (numberOfGroups*40));
				canvas.setAttribute("height",500);
				canvas.setAttribute("id", graphId);
				graphHolder.appendChild(canvas);

				if(typeof G_vmlCanvasManager !== "undefined") //JFM 12_01_16
					canvas=G_vmlCanvasManager.initElement(canvas);	// Do this thing so dynamic setup of the canvas works correctly.
				var ctx=canvas.getContext('2d');				// Get canvas context - SO IMPORTANT!!!

				var recX=0;
				var recY=(canvas.height-30);

				var barHeightProportion=(recY-50)/biggestBar;

				ctx.fillStyle='black';
				ctx.fillRect(recX,50,1,(barHeightProportion*biggestBar)); 
				ctx.font='14px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='left';
				ctx.fillText(String(biggestBar),(recX+5),57);

				var colours=Array('#ef343f','#f8d707','#81c341','#0088cf','#8400b5','black');

				ctx.font='18px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='center';
				ctx.fillText('Number of Criteria Statuses Per Group',(canvas.width/2),15,canvas.width);

				recX+=10;

				for (var groupName in countEverything)
				{
					ctx.font='16px Arial';
					ctx.fillStyle='black';
					ctx.textAlign='left';
					ctx.fillText(String(groupName).substring(0,3),(recX+2),canvas.height-10,30);

					for (var details in countEverything[groupName])
					{
						for (var pleh in countEverything[groupName][details])
						{
							var ploo=countEverything[groupName][details][pleh]*barHeightProportion;
							recY-=ploo;
							ctx.fillStyle=colours[pleh];
							ctx.fillRect(recX,recY,30,ploo); 

							ctx.font='14px Arial';
							ctx.fillStyle='white';
							ctx.textAlign='center';
							ctx.fillText(String(countEverything[groupName][details][pleh]),(recX+15),(recY+ploo));
						}
					}

					recX+=40;
					recY=(canvas.height-30);
				}

			break;

			case 'burnDown':
				//This is never displayed. Just easier than changing all the width and height calculations below.
				var canvas=document.createElement('canvas');
				canvas.setAttribute("width", (numberOfGroups*40)+25);
				canvas.setAttribute("height",600);
				canvas.setAttribute("id", graphId);


				var split=burnUpFromAjaxExtraInfo.split('%%%');

				var graphPlaceholder='<div style="position:absolute; width:300px; display:inline; margin-top:435px; margin-left:175px;">';
					graphPlaceholder+='<form id="test" style="display:inline;" action="support/graphsDownloadBurndown.php" encType="multipart/form-data" method="post">';
						graphPlaceholder+='<input name="title" id="title" type="hidden" value="'+graphName+'"/>';
						graphPlaceholder+='<input name="cw" id="cw" type="hidden" value="'+split[0]+'"/>';
						graphPlaceholder+='<input name="actual" id="actual" type="hidden" value="'+split[1]+'"/>';
						graphPlaceholder+='<input name="predicted" id="predicted" type="hidden" value="'+split[2]+'"/>';
						graphPlaceholder+='<input name="green" id="green" type="hidden" value="'+split[3]+'"/>';
						graphPlaceholder+='<input name="max" id="max" type="hidden" value="'+biggestBar+'"/>';
						graphPlaceholder+='<input type="image" src="../common/img/download.png" />';
						graphPlaceholder+='</form>';
					graphPlaceholder+='<input style="padding-left:20px; display:inline;" type="image" src="../common/img/trash.png" onclick="mainRestartNeeded=1; ajaxRequest(\'ajax/setGraph.php?value=0&applicability='+graphId+'_check\',\'restartMainTable\',true,\'GET\');"/>';
				graphPlaceholder+='</div>';

				graphHolder.innerHTML+=graphPlaceholder;

				if(typeof G_vmlCanvasManager !== "undefined") //JFM 12_01_16
				{
					var canvas=document.createElement('canvas');
					canvas.setAttribute("width", (numberOfGroups*40)+25);
					canvas.setAttribute("height",600);
					canvas.setAttribute("id", graphId);
					graphHolder.appendChild(canvas);
					canvas=G_vmlCanvasManager.initElement(canvas);
					var ctx=canvas.getContext('2d');
				}
				else
				{
					//JFM 19_07_16
					var widthSvg = (numberOfGroups*40)+25;
					if(widthSvg < 500)
						widthSvg = 500;
					var ctx = new C2S(widthSvg,600);
				}
				ctx.scale(0.75,0.75);

				var recX=0;
				var recY=(canvas.height-130);

				var barHeightProportion=(recY-50)/biggestBar;

				var oldLineX;
				var oldLineY;

				ctx.fillStyle='black';
				ctx.fillRect(recX,50,1,(barHeightProportion*biggestBar)); 
				ctx.font='14px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='left';
				ctx.fillText(String(biggestBar),(recX+5),57);

				ctx.font='18px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='center';
				ctx.fillText((graphName ? graphName : 'Criteria Burn Down'),(canvas.width/2),15,canvas.width);
				ctx.fillText('Calender Week',(canvas.width/2),canvas.height-80,canvas.width);

				recX+=25;

				for (var groupName in countEverything)
				{
					ctx.font='16px Arial';
					ctx.fillStyle='black';
					ctx.textAlign='left';
					ctx.fillText(String(groupName).substring(groupName.length-2),(recX+2),canvas.height-110,30);

					for (var details in countEverything[groupName])
					{
						if(details=='total_validated_in_order')
						{
							var ploo=countEverything[groupName][details]*barHeightProportion;
							var recYScaled=recY-ploo;
							ctx.fillStyle='#0088cf';
							ctx.fillRect(recX,recYScaled,30,ploo); 

							ctx.font='14px Arial';
							ctx.fillStyle='white';
							ctx.textAlign='center';
							ctx.fillText(String(countEverything[groupName][details]),(recX+15),(recYScaled+ploo));
						}

						else if(details=='total_green_in_order')
						{
							var blueBar = countEverything[groupName]['total_validated_in_order']*barHeightProportion;
							var ploo=countEverything[groupName][details]*barHeightProportion;
							var recYScaled=recY-ploo-blueBar;

							ctx.fillStyle='#81c341';
							ctx.fillRect(recX,recYScaled,30,ploo); 

							ctx.font='14px Arial';
							ctx.fillStyle='white';
							ctx.textAlign='center';
							ctx.fillText(String(countEverything[groupName][details]),(recX+15),(recYScaled+ploo));
						}

						else if(details=='total_planned_in_order')
						{
							var ploo=countEverything[groupName][details]*barHeightProportion;
							var recYScaled=recY-ploo;

							if(oldLineX!=null && oldLineY!=null)
							{
								ctx.beginPath();
								ctx.moveTo(recX+15,recYScaled);
								ctx.lineWidth=2;
								ctx.lineTo(oldLineX,oldLineY);
								ctx.strokeStyle='black';
								ctx.stroke();

								ctx.font='14px Arial';
								ctx.fillStyle='black';
								ctx.textAlign='center';
								ctx.fillText(String(countEverything[groupName][details]),(recX+15),(recYScaled+16));

								oldLineX=recX+15;
								oldLineY=recYScaled;
							}
							else
							{
								ctx.font='14px Arial';
								ctx.fillStyle='black';
								ctx.textAlign='center';
								ctx.fillText(String(countEverything[groupName][details]),(recX+15),(recYScaled+16));

								oldLineX=recX+15;
								oldLineY=recYScaled;
							}
						}
					}

					recX+=40;
				}

				//Legend
				ctx.font='18px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='left';
				ctx.fillText('Legend',0,canvas.height-70);

				ctx.fillStyle='#81c341';
				ctx.fillRect(0,canvas.height-60,30,20); 
				ctx.font='16px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='left';
				ctx.fillText('- total green status',40,canvas.height-45);

				ctx.fillStyle='#0088cf';
				ctx.fillRect(0,canvas.height-30,30,20); 
				ctx.font='16px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='left';
				ctx.fillText('- total blue status',40,canvas.height-15);

				ctx.beginPath();
				ctx.moveTo(0,canvas.height+5);
				ctx.lineWidth=2;
				ctx.lineTo(30,canvas.height+5);
				ctx.strokeStyle='black';
				ctx.stroke();
				ctx.font='16px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='left';
				ctx.fillText('- total predicted closed',40,canvas.height+10);

				if(typeof G_vmlCanvasManager === "undefined") //JFM 12_01_16
				{
					var mySerializedSVG = ctx.getSerializedSvg(true);
					var svgdiv=document.createElement('div');
					svgdiv.setAttribute("width", 300);
					svgdiv.setAttribute("height",300);
//					svgdiv.style.setAttribute("display","inline");
					graphHolder.appendChild(svgdiv);
					svgdiv.innerHTML = mySerializedSVG;
				}

			break;

			case 'clusteredBar':
				var canvas=document.createElement('canvas');	// We will setup the canvas dynamically so we can get many in one div.
				canvas.setAttribute("width", ((numberOfGroups*80)));
				canvas.setAttribute("height",500);
				canvas.setAttribute("id", graphId);
				graphHolder.appendChild(canvas);

				if(typeof G_vmlCanvasManager !== "undefined") //JFM 12_01_16
					canvas=G_vmlCanvasManager.initElement(canvas);	// Do this thing so dynamic setup of the canvas works correctly.
				var ctx=canvas.getContext('2d');				// Get canvas context - SO IMPORTANT!!!

				var recX=0;
				var recY=(canvas.height-30);

				var barHeightProportion=(recY-50)/biggestBar;

				ctx.fillStyle='black';
				ctx.fillRect(recX,50,1,(barHeightProportion*biggestBar)); 
				ctx.font='14px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='left';
				ctx.fillText(String(biggestBar),(recX+5),57);

				var colours=Array('#900','#b8b000','#060','#609dc9','#8400b5','black');

				ctx.font='18px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='center';
				ctx.fillText('Progress Map',(canvas.width/2),15,canvas.width);

				recX+=10;

				for (var groupName in countEverything)
				{
					ctx.font='16px Arial';
					ctx.fillStyle='black';
					ctx.textAlign='left';
					ctx.fillText(String(groupName).substring(0,3),(recX+2),canvas.height-10,30);
					var i=0;

					for (var details in countEverything[groupName])
					{
						var ploo=countEverything[groupName][details]*barHeightProportion;
						var recYScaled=recY-ploo;
						ctx.fillStyle=colours[i];
						ctx.fillRect(recX,recYScaled,12,ploo);

						ctx.font='10px Arial';
						ctx.fillStyle='white';
						ctx.textAlign='left';
						ctx.fillText(String(countEverything[groupName][details]),(recX+1),(recYScaled+ploo));

						recX+=12;
						i++;
					}

					recX+=14;
				}

				recYScaled=(recY/2);
				var description=Array('- Checklist Criteria','- Evidence Planned','- Evidence Supplied','- Evidence Validated');

				for (var i = 0; i < 4; i++) 
				{
					ctx.fillStyle=colours[i];
					ctx.fillRect(recX,recYScaled,10,10);
					recYScaled+=20;

					ctx.font='12px Arial';
					ctx.fillStyle='black';
					ctx.textAlign='left';
					ctx.fillText(description[i],(recX+15),(recYScaled-10));
				}

			break;

			case 'stackedBarOverview': //JFM 02_12_15
				var canvas=document.createElement('canvas');	// We will setup the canvas dynamically so we can get many in one div.
				countEverything=JSON.parse(countEverything);
				canvas.setAttribute("width", (numberOfGroups*60+60));
				canvas.setAttribute("height",200);
				canvas.setAttribute("id", graphId);
				graphHolder.appendChild(canvas);

				if(typeof G_vmlCanvasManager !== "undefined") //JFM 12_01_16
					canvas=G_vmlCanvasManager.initElement(canvas);	// Do this thing so dynamic setup of the canvas works correctly.
				var ctx=canvas.getContext('2d');				// Get canvas context - SO IMPORTANT!!!

				var recX=60;
				var recY=(canvas.height-30);

				var marginTop = 20;

				var barHeightProportion=(recY-marginTop)/biggestBar;

				ctx.fillStyle='#bbbcbc';
				ctx.fillRect(recX,recY,canvas.width,1);
				ctx.fillRect(recX,((recY-marginTop)/2)+marginTop-1,canvas.width,1);
				ctx.fillRect(recX,((recY-marginTop)/4)+marginTop-1,canvas.width,1);
				ctx.fillRect(recX,((recY-marginTop)*3/4)+marginTop-1,canvas.width,1);
				ctx.fillRect(recX,((recY-marginTop)/(recY-marginTop))+marginTop-1,canvas.width,1);
				ctx.fillStyle='black';
				ctx.fillRect(recX,marginTop,1,(barHeightProportion*biggestBar));
				ctx.font='14px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='right';
				ctx.fillText(String(biggestBar),(recX-5),((recY-marginTop)/(recY-marginTop))+marginTop+7);
				ctx.fillText(String(biggestBar/4),(recX-5),((recY-marginTop)*3/4)+marginTop+7);
				ctx.fillText(String(biggestBar/2),(recX-5),((recY-marginTop)/2)+marginTop+7);
				ctx.fillText(String(biggestBar*3/4),(recX-5),((recY-marginTop)/4)+marginTop+7);
				ctx.fillText(String(0),(recX-5),recY+7);

				var colours=Array('#ef343f','#f8d707','#81c341','#0088cf','#8400b5','black');

				ctx.font='18px Arial';
				ctx.fillStyle='black';
				ctx.textAlign='center';

				recX+=10;

				for (var groupName in countEverything)
				{
					ctx.font='12px Arial';
					ctx.fillStyle='black';
					ctx.textAlign='center';
					ctx.fillText(String(groupName).substring(0,6),(recX+15),canvas.height-10,30);

					for (var details in countEverything[groupName])
					{
						for (var pleh in countEverything[groupName][details])
						{
							var ploo=countEverything[groupName][details][pleh]*barHeightProportion;
							recY-=ploo;
							ctx.fillStyle=colours[pleh];
							ctx.fillRect(recX,recY,30,ploo); 

							/*ctx.font='14px Arial';
							ctx.fillStyle='white';
							ctx.textAlign='center';
							ctx.fillText(String(countEverything[groupName][details][pleh]),(recX+15),(recY+ploo));*/
						}
					}

					recX+=60;
					recY=(canvas.height-30);
				}

			break;
		}
	}
}

/**
 * Displays pop-up which allows you to change the criteria status & comments or add providers, links and validators in continuous assessment.
 * @param  {var} t
 * @param  {int} msn
 * @param  {int} ca
 * @param  {int} criteria
 * @param  {int} review_profile
 * @param  {int} continuous_assessment
 * @param  {int} review_validated
 * @param {string} action 
 * @return {null}
 */
function criteriaStatusInfo(t,msn,ca,criteria,review_profile,continuous_assessment,review_validated,action) //JFM 24_03_14 - 09_04_14
{	
	//JFM 03_06_14
	formHeight='100%';
	formWidth='15%'; //JFM 17_08_15
	activeCol='overDivCriteriaStatus';
	ajaxRequest('ajax/criteriaInfo.php?msn='+msn+'&ca='+ca+'&review_criteria_id='+criteria+'&review_profile='+review_profile+'&continuous_assessment='+continuous_assessment+'&review_validated='+review_validated+'&action='+action,'openForm',false,'GET');

}

/**
 * The resulting table row and input box from function removeOrCreateNameSuggestion.
 * @param  {var} tableID
 * @param  {var} divID
 * @param  {var} inputID
 * @param  {var} suggestionID
 * @param  {var} v
 * @return {null}
 */
function createRowWithNameSuggestion(tableID,divID,inputID,suggestionID,v) //JFM 21_08_13 - JFM 23_09_13 - JFM 30_09_13
{
	rowCount[tableID]++;
	var table=$(tableID)
	var row=table.insertRow();
	row.id='row'+inputID+rowCount[tableID];
	var cell=row.insertCell(0);
	//JFM 28_10_15 cell.width="35%";
	cell.valign="top";
	cell.innerHTML='<div class="suggestion"id="'+divID+rowCount[tableID]+'"style="width:175px;">'
					+'</div><input class="textareaWhite" id="'+inputID+rowCount[tableID]+'"name="'+inputID+rowCount[tableID]+'" onKeyDown="removeOrCreateNameSuggestion(this,\''+tableID+'\',\''+divID+'\',\''+inputID+'\',\''+suggestionID+'\',\''+v+'\');" onFocus="loadUserSuggestion(this,\''+divID+rowCount[tableID]+'\',\''+inputID+rowCount[tableID]+'\',\'\',\''+suggestionID+rowCount[tableID]+'\',\''+v+'\');"onKeyPress="return avoidSendForm(event,\'user\');" size="28"type="text">'
					+'<input class="xRemove" onClick="deleteRowByInputID(\''+inputID+rowCount[tableID]+'\',\''+tableID+'\');"type="button" value="&#10008;"/>';
}

/**
 * Creates a row in a table with an input box if the user has entered something in a previously empty input box and no other empty input box is available.
 * @param  {var} inputIDValue
 * @param  {var} tableID
 * @param  {var} divID
 * @param  {var} inputID
 * @param  {var} suggestionID
 * @param  {var} v
 * @return {null}
 */
function removeOrCreateNameSuggestion(inputIDValue,tableID,divID,inputID,suggestionID,v) //JFM 21_08_13 - JFM 23_09_13
{
	var rowsLength=$(tableID).rows.length-1;

	rowCount[tableID] = 0;
	q=1;
	while(totalRows=$(inputID+q))
	{
		rowCount[tableID]++;
		q++;
	}

	var keyPressed = window.event.keyCode;
	if(typeof document.selection !== "undefined") //JFM 12_01_16
		var userSelection = document.selection.createRange();
	else
		var userSelection = window.getSelection();
	switch(keyPressed){
		case 9:
			//alert('Tab');
			//Do nothing.
		break;
		case 8:
			//alert('Backspace');
			if(((userSelection.text==inputIDValue.value && userSelection.text) || inputIDValue.value.length==1) && !$(tableID).rows[rowsLength].cells[0].getElementsByTagName("input")[0].value) 
			{
				$(tableID).deleteRow();
				//rowCount[tableID]--;
			}
		break;
		case 46:
			//alert('Delete');
			if(((userSelection.text==inputIDValue.value && userSelection.text) || inputIDValue.value.length==1) && !$(tableID).rows[rowsLength].cells[0].getElementsByTagName("input")[0].value)
			{
				$(tableID).deleteRow();
				//rowCount[tableID]--;
			}
		break;
		default:
			//alert('Everything else');
			if(!$(inputID+rowCount[tableID])) createRowWithNameSuggestion(tableID,divID,inputID,suggestionID,v);
			else if (inputIDValue.id==$(inputID+rowCount[tableID]).id)
			{
				if(!$(inputID+(rowCount[tableID]+1))) createRowWithNameSuggestion(tableID,divID,inputID,suggestionID,v);
			}

			if(inputIDValue.value=='' && $(inputID+rowCount[tableID]).value!='') createRowWithNameSuggestion(tableID,divID,inputID,suggestionID,v);
		break;
	}
}

/**
 * Deletes a row in a table if it contains an input box, it's not the last input box in the table and it's not the last blank input box in the table.
 * @param  {var} inputID
 * @param  {var} tableID
 * @return {null}
 */
function deleteRowByInputID(inputID,tableID)
{
	var row=$('row'+inputID); 
	var totalRows=$(tableID).rows.length-1;

	if(row.id==$(tableID).rows[1].id) //Trying to delete first row.
	{
		//alert('FIRST ROW');
		if($(tableID).rows[2]) row.parentNode.removeChild(row); //Another input box already exists - okay to delete.
		else $(inputID).value='';
	}
	else if($(inputID).value=='' && row.id==$(tableID).rows[totalRows].id) //Trying to delete last value which is blank.
	{
		//Do nothing.
	}
	else 
	{
		canDeleteRow=false;
		for(var y=1; y<=totalRows; y++)
		{
			if($(tableID).rows[y].cells[0].getElementsByTagName("input")[0].value=='' && $(tableID).rows[y].id!=row.id) 
			{
				canDeleteRow=true;
				break;
			}
		}
		if(canDeleteRow) row.parentNode.removeChild(row);
	}
}

/**
 * Deletes review if "DELETE REVIEW" is entered correctly.
 * @return {bool}
 */
function deleteReview()
{
	var deleteMe=prompt('This will cancel the review, delete all criteria information and is unrecoverable.\nIf you are sure, please type the words: DELETE REVIEW','');

	if(deleteMe=='DELETE REVIEW')
	{
		sendAjaxForm('reviewEditForm','ajax/saveReviewValidation.php','reloadSideElement',''); 
		mainRestartNeeded=1;
	} 
	else if (deleteMe!=null)
	{
		alert('Please enter the words exactly as shown.');
	}
}

 /*
  * Fix for : US #19.1 - Change workflow for creating a design review 
  *  Planned Date is mandatory for valifating a checklist
  * Version: 4.3
  * Fixed By: Infosys Limited
  */
function forceReview()
{
	
/* 	if($('planned').value =="") //Planned Date is mandatory for validating a checklist
	{
		alert('You MUST select the PLANNED DATE before validating a review.');
		
	}
	else 
	{ */
	if($('forceComments').value =="") //JFM 12_01_16
	{
		alert('You MUST enter a comment when force validating a review.');
	}
	else
	{
		var forceMe=prompt('This will force validate the review.\nIf you are sure, please type the words: FORCE REVIEW','');

		if(forceMe=='FORCE REVIEW')
		{
			sendAjaxForm('reviewForceForm','ajax/saveReviewValidation.php','reloadSideElement',''); 
			mainRestartNeeded=1;
		} 
		else if (forceMe!=null)
		{
			alert('Please enter the words exactly as shown.');
		}
	}
	//}
}
/**
 * Creates an extra row in a table from a given drop down menu.
 * @param  {var} tableID
 * @param  {var} dropDownID
 * @param  {var} rowID
 * @param  {var} doThisThing
 * @return {null}
 */
function createRowFromDropDown(tableID, dropDownID, rowID, doThisThing)
{
	dropDown=$(dropDownID);

	if(doThisThing=='add')
	{
		if(dropDown.options.value!='')
		{
			var table=$(tableID)
			var row=table.insertRow(2);
			row.id=rowID+'_break_'+dropDown.options.value+'_break_'+dropDown.options[dropDown.selectedIndex].text;
			row.className='infoRow';
			var cell=row.insertCell(0);
			cell.innerHTML='<input id="'+tableID+'_row_'+globalRandomCount+'" name="'+tableID+'_row_'+globalRandomCount+'" type="hidden" value="'+dropDown.options.value+'">'+dropDown.options[dropDown.selectedIndex].text+'<input class="xRemove" onClick="createRowFromDropDown(\''+tableID+'\', \''+dropDownID+'\',\''+row.id+'\',\'delete\')" type="button" value="&#10008;"/>';
			dropDown.remove(dropDown.selectedIndex);

			if 		(tableID=='criteriaCriteriaTable') $('criteriaCriteriaUsedInTheSameWpTableDropDownTd').style.display='none';
			else if (tableID=='criteriaCriteriaUsedInTheSameWpTable') $('criteriaCriteriaTableDropDownTd').style.display='none';

			globalRandomCount++;
		}
	}
	else if(doThisThing=='delete')
	{
		var split=rowID.split('_break_');
		var option=document.createElement('option');
		option.value=split[1];
		option.text=split[2];
    	$(rowID).parentNode.removeChild($(rowID));
    	dropDown.add(option);

    	if 		(tableID=='criteriaCriteriaTable' && $(tableID).rows.length < 4) $('criteriaCriteriaUsedInTheSameWpTableDropDownTd').style.display='block';
    	else if (tableID=='criteriaCriteriaUsedInTheSameWpTable' && $(tableID).rows.length < 4) $('criteriaCriteriaTableDropDownTd').style.display='block';
	}
	else
	{
		alert('There has been a serious issue.')
	}
}

/**
 * Display the pop-up menu when selecting a review type in dashboard view.
 * @param  {var} item
 * @param  {int} program
 * @param  {int} coe
 * @param  {int} msn
 * @param  {int} review_type
 * @return {null}
 */
function caGraphSelectionOverlib(item, program, coe, msn, review_type)
{	
	activeCol='overDivCriteriaStatus';
	ajaxRequest('ajax/dashboardCa.php?item='+item+'&program='+program+'&coe='+coe+'&msn='+msn+'&review_type='+review_type,'olsticky',false,'GET');
}

/**
 * Does a nice pie chart segment expand on mouse over.
 * @param  {object} item              VML object (this).
 * @param  {var} currentPathX      
 * @param  {var} currentPathY      
 * @param  {var} currentPathStartX 
 * @param  {var} currentPathStartY 
 * @param  {var} currentPathEndX   
 * @param  {var} currentPathEndY   
 * @param  {var} radius            
 * @param  {var} action            Expanding or contracting shape.
 * @return {[type]}                   
 */
function redoPath(item, currentPathX, currentPathY, currentPathStartX, currentPathStartY, currentPathEndX, currentPathEndY, radius, action)
{
	var m = Math;
  	var mr = m.round;

	if(action=='expand' && radius!=2000) radius+=100;
	else if (action=='contract'  && radius!=1000) 	radius-=100;

	var newWaPath='wa'+mr(currentPathX - 1 * radius)+','+mr(currentPathY - 1 * radius)+','+mr(currentPathX + 1 * radius)+','+mr(currentPathY + 1 * radius)+','+mr(currentPathStartX)+','+mr(currentPathStartY)+','+mr(currentPathEndX)+','+mr(currentPathEndY);
   
    var itemPathSplit = String(item.path).split(" ");

    var newPath=itemPathSplit[0]+itemPathSplit[1]+' '+newWaPath+' '+itemPathSplit[3]+' '+itemPathSplit[4]+' '+itemPathSplit[5];

    item.path=newPath;
}

/**
 * Changed the items on the left hand explorer menu.
 * @param  {var} e             		Item selected.
 * @param  {string} explorerMenuId 	ID of the explorer menu item to change to if not derived from e.
 * @param  {bool} noShow         	Run restart main table or not.
 * @return {null}                	null
 */
function explorerMenuExpand(e, explorerMenuId, noShow)
{
	$('mainTitle').focus();
	processing=true;
	var show='';
	var target;

	if(explorerMenuId!='' && typeof explorerMenuId!=='undefined')
	{
		target=$(explorerMenuId);
	}
	else
	{
		e = e || window.event;
		target	= e.target || e.srcElement;
	}

	var liClickTargetId		= target.id;
	var liClickInfoArray	= liClickTargetId.split('_');
	if($(liClickTargetId)) //JFM 12_01_16
	{
		var liClickedParentLiId	= $(liClickTargetId).parentNode.parentNode.id;
		
		if(liClickInfoArray[0]!='msn' && !noShow) noProgramCoeMsn(1,1,1);
		/*
		* Infosys Limited
		* Start of Bug: Structure Management
		* Menu item to be enabled even if main table is not displayed 
		*/
		
		if(liClickInfoArray[0]=='area' && !noShow){ 	
			document.getElementById("admin_c").style.display= 'none';
			document.getElementById("tools_c").style.display= 'none';
			document.getElementById("tools_c_hide").style.display= 'block';
			document.getElementById("admin_c_hide").style.display= 'block';
			show='&show=1';	
			
		}
		else if(liClickInfoArray[0]=='program' || liClickInfoArray[0]=='coe' && !noShow){  
			document.getElementById("admin_c").style.display= 'block';
			document.getElementById("tools_c").style.display= 'none';
			document.getElementById("tools_c_hide").style.display= 'block';
			document.getElementById("admin_c_hide").style.display= 'none';
			show='&show=1';	
			
		}
		else if(liClickInfoArray[0]=='msn' && !noShow){  
			document.getElementById("admin_c").style.display= 'block';
			document.getElementById("tools_c").style.display= 'block';
			document.getElementById("tools_c_hide").style.display= 'none';
			document.getElementById("admin_c_hide").style.display= 'none';
			show='&show=1';	
			
		}
		else if(noShow) show='';
		else {
			document.getElementById("admin_c").style.display= 'none';
			document.getElementById("tools_c").style.display= 'none';
			document.getElementById("tools_c_hide").style.display= 'block';
			document.getElementById("admin_c_hide").style.display= 'block';
			show='&show=1'
		};
		
		/*
		* Infosys Limited
		* Bug: Structure Management
		* End of Menu item to be enabled even if main table is not displayed 
		*/


		var explorerMenu = $('explorerMenuTopLevel').getElementsByTagName('li');

		for (var i = 0; i < explorerMenu.length; i++) 
		{
			explorerMenu[i].className = 'liNotSelected';
			target.className = 'liSelected';

			if(liClickInfoArray[0]=='program') 
			{
				target.parentNode.parentNode.className = 'liSelected';
			}
			else if(liClickInfoArray[0]=='coe') 
			{
				target.parentNode.parentNode.className = 'liSelected';
				target.parentNode.parentNode.parentNode.parentNode.className = 'liSelected';
			}
			else if(liClickInfoArray[0]=='msn') 
			{
				target.parentNode.parentNode.className = 'liSelected';
				target.parentNode.parentNode.parentNode.parentNode.className = 'liSelected';
				target.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.className = 'liSelected';
			}

			var explorerMenuArray=explorerMenu[i].id.split('_');
			if
			(
					(liClickInfoArray[0]=='area') 	&& (explorerMenuArray[0]=='area')
				||	(liClickInfoArray[0]=='program' && (explorerMenuArray[0]=='area' || explorerMenuArray[0]=='program'))
				||	(liClickInfoArray[0]=='coe' 	&& (explorerMenuArray[0]=='area' || explorerMenuArray[0]=='program' || explorerMenuArray[0]=='coe'))
				||	(liClickInfoArray[0]=='msn' 	&& (explorerMenuArray[0]=='area' || explorerMenuArray[0]=='program' || explorerMenuArray[0]=='coe' || explorerMenuArray[0]=='msn'))
			) continue;

			explorerMenu[i].style.display='none';
		}

		var liItemsUnderClicked = $(liClickTargetId).getElementsByTagName('li');

		var nextLevelId='';

		for (var j = 0; j < liItemsUnderClicked.length; j++) 
		{
			var liItemsUnderClickedInnerHTMLSubstringReplaced=liItemsUnderClicked[j].innerHTML.substring(0, 3).replace(/(\r\n|\n|\r|<)/gm,""); //JFM 12_01_15

			if(j==0 && liItemsUnderClickedInnerHTMLSubstringReplaced=='NA' )
			{
				nextLevelId=liItemsUnderClicked[j].id;
			}

			var itemsUnderSelectedArray=liItemsUnderClicked[j].id.split('_');

			if
			(
				(
					(liClickInfoArray[0]=='area' && itemsUnderSelectedArray[0]=='program') ||
					(liClickInfoArray[0]=='program' && itemsUnderSelectedArray[0]=='coe') ||
					(liClickInfoArray[0]=='coe' && itemsUnderSelectedArray[0]=='msn')
				)
				&& liItemsUnderClickedInnerHTMLSubstringReplaced!='NA'
			) liItemsUnderClicked[j].style.display='';
		}

		ajaxRequest('ajax/retrieveDdList.php?store='+liClickInfoArray[0]+'&value='+liClickInfoArray[1]+show,'ddFill',false,'GET');
		
		if(liClickInfoArray[0]=='area') refreshSession();

		if(nextLevelId!='') explorerMenuExpand(e,nextLevelId,noShow); //JFM 12_01_16 - passing noshow value.
	}
}

function runTutorial(step)
{
	var insertDiv=$('tutorialMsgBoxHolder');
	switch(step)
	{
		case 1:
			$('tutorialMsgBox_1').style.display='none';
			$('tutorial_1').style.display='none';
			$('tutorial_2').style.display='none';
			$('tutorialUnclickable').style.display='none';
			$('tutorialHolder').style.display='none';

			if(mainTableTutorialDelayed == 1)
			{
				mainTableTutorialDelayed = 0;
				checkNewChangeLog(1);
			}
		break;

		case 2:
			$('tutorialMsgBox_1').style.display='none';
			$('tutorialMsgBox_2').style.display='block';
			$('tutorial_1').style.marginLeft='200px';
			$('tutorial_2').style.height='50px';
			$('tutorial_2').style.width='200px';
			$('tutorial_2').style.display='block';
		break;

		case 3:
			$('tutorialMsgBox_2').style.display='none';
			$('tutorialMsgBox_3').style.display='block';
			$('tutorial_1').style.marginLeft='0px';
			$('tutorial_1').style.width='200px';
			$('tutorial_1').style.marginTop='45px';
			$('tutorial_2').style.width='100%';
			$('tutorial_2').style.height='85px';
		break;

		case 4:
			$('tutorialMsgBox_3').style.display='none';
			$('tutorialMsgBox_4').style.display='block';
			$('tutorial_3').style.display='block';
			$('tutorial_2').style.height='50px';
		break;

		case 5:
			$('tutorialMsgBox_4').style.display='none';
			$('tutorialMsgBox_5').style.display='block';
			$('tutorial_3').style.marginTop='50px';
			$('tutorial_2').style.width='70%';
		break;

		case 6:
			$('tutorialMsgBox_5').style.display='none';
			$('tutorialMsgBox_6').style.display='block';
			$('tutorial_1').style.margin='0';
			$('tutorial_1').style.width='100%';
			$('tutorial_2').style.display='none';
			$('tutorial_3').style.display='none';
		break;

		case 7:
			$('tutorialMsgBox_6').style.display='none';
			$('tutorial_1').style.display='none';
			$('tutorialUnclickable').style.display='none';
			$('tutorialHolder').style.display='none';

			if(mainTableTutorialDelayed == 1)
			{
				mainTableTutorialDelayed = 0;
				checkNewChangeLog(1);
			}
		break;
	}
}
function runMainTableTutorial(step)
{
	var insertDiv=$('mainTableTutorialMsgBoxHolder');
	switch(step)
	{
		case 1:
			$('mainTableTutorialMsgBox_1').style.display='none';
			$('mainTableTutorial_1').style.display='none';
			$('mainTableTutorial_2').style.display='none';
			$('mainTableTutorialUnclickable').style.display='none';
			$('mainTableTutorialMsgBoxHolder').style.display='none';
			$('tutorialHolder').style.display='none';
		break;

		case 2:
			$('mainTableTutorialMsgBox_1').style.display='none';
			$('mainTableTutorialMsgBox_2').style.display='block';
			$('mainTableTutorial_2').style.display='block';
			$('mainTableTutorial_1').style.marginLeft='0px';
			$('mainTableTutorial_1').style.width='200px';
			$('mainTableTutorial_1').style.marginTop='45px';
			$('mainTableTutorial_2').style.width='100%';
			$('mainTableTutorial_2').style.height='85px';
			$('mainTableTutorialArrow_1').style.display='block';
			$('mainTableTutorialArrow_2').style.display='block';
		break;
		
		case 3:
			$('mainTableTutorialMsgBox_2').style.display='none';
			$('mainTableTutorialMsgBox_3').style.display='block';
			$('mainTableTutorialArrow_1').style.display='none';
			$('mainTableTutorialArrow_2').style.display='none';
			$('mainTableTutorialCircle_1').style.display='block';
			$('mainTableTutorialCircle_2').style.display='block';
		break;

		case 4:
			$('mainTableTutorialMsgBox_3').style.display='none';
			$('mainTableTutorialCircle_1').style.display='none';
			$('mainTableTutorialCircle_2').style.display='none';
			$('mainTableTutorial_1').style.display='none';
			$('mainTableTutorialUnclickable').style.display='none';
			$('tutorialHolder').style.display='none';
		break;
	}
}

function showColumnFilter(table,tableSection,obj,app,t,tableCacheId,sfTxt)
{ 
	fltDiv='sf-'+app+'-'+obj;
	activeTable=table;
	activeTableCacheId=tableCacheId;

	if(fltOn==false)
	{
		activeCol=fltDiv;
		popUpType='filter';
		ajaxRequest('ajax/columnFilter.php?table='+table+'&table_section='+tableSection+'&object='+obj+'&app='+app+'&sfTxt='+sfTxt,'showFilter',true);
		fltOn=true;
	}
}

/*function changePopUpButtonColor(id)
{
	var activeButton='popUpBtn';
	var activeMenuSplit=id.split('_');
	for (var i = 1; i < activeMenuSplit.length; i++) 
	{
		activeButton=activeButton+'_'+activeMenuSplit[i];
	}

	if(exists($(activeButton)))
	{
		if($(activeButton).className=='popUpBtn') $(activeButton).className='popUpBtnBlue';
		else if($(activeButton).className=='popUpBtnBlue') $(activeButton).className='popUpBtn';
	}
}*/

function changeActiveSideContainer(sideContainer)
{
	for (var i = lastSideElementRequestCount; i >= 0; i--) 
	{
		if(lastSideElementRequest[i].search('ajax/../form/list')!=-1) lastSideElementRequestCount--;
		else break;
	}

	activeSideContainer=sideContainer; 
	reloadSideElement();
}

function changeWhiteBGCloseFormMethod(sideContainer)
{
	$('whiteBG_'+whiteBg[formCount-1]).onclick = function () { closeLastForm(); changeActiveSideContainer(sideContainer); };
}

function expandSummaryView(menuId) //JFM 02_10_14
{
	var area=menuId.split('_');

	explorerMenuExpand('','area_'+area[7], true);
	explorerMenuExpand('','program_'+area[5]+'_area_'+area[7], true);
	explorerMenuExpand('','coe_'+area[3]+'_program_'+area[5]+'_area_'+area[7], true);
	explorerMenuExpand('','msn_'+area[1]+'_coe_'+area[3]+'_program_'+area[5]+'_area_'+area[7], true);
}

function showOOUI(email,e) //JFM 02_10_14
{
	if(unifiedPresence)
	{
		e = e || window.event;
		mouseX = e.clientX;
		mouseY = e.clientY;

		unifiedPresence.ShowOOUI(email,0,mouseX,mouseY);
	}
}

function hideOOUI() //JFM 02_10_14
{
	if(unifiedPresence) unifiedPresence.HideOOUI();
}

function checkFormChanges(form) //JFM 02_10_14
{
	var formElements=getAllElementsOfFormAndStoreInString(form,0);
	// alert(formElements);
	// alert('!!!!'+allElementsOfForm[form]);
	if(formElements!=allElementsOfForm[form])
	{
		var confirm=window.confirm('Changes have not been saved!\n\nSave changes to this action?');

		if(confirm)
		{
			if(validateActionRidCreation()) 
			{
				sendAjaxForm('actionFrm','ajax/saveAction.php','updateData','action_saveResponse');
				closeLastForm();
			}
			else
			{
				alert('Some elements have not been filled in correctly.\n\nPlease review errors and try again.');
			}
		}
		else closeLastForm();
	}
	else closeLastForm();
}

function createRowWithNameSuggestionForResponsibles(rowInput)
{
	rowCount['responsibleTable'] = 0;
	q=1;
	while(totalRows=$('roleinputID'+q))
	{
		rowCount['responsibleTable']++;
		q++;
	}

	rowCount['responsibleTable']++;

	var currentRow = rowInput.parentNode.parentNode;
	var newRow = document.createElement('tr');
	newRow.id='rowroleinputID'+rowCount['responsibleTable'];

	currentRow.parentNode.insertBefore(newRow, currentRow.nextSibling );

	var cell=newRow.insertCell(0);
	//cell.innerHTML='<div class="suggestion"id="roledivID'+rowCount['responsibleTable']+'"style="width:175px;">'
					//+'</div><input class="textareaWhite" id="roleinputID'+rowCount['responsibleTable']+'"name="roleinputID'+rowCount['responsibleTable']+'" onFocus="loadUserSuggestion(this,\'roledivID'+rowCount['responsibleTable']+'\',\'roleinputID'+rowCount['responsibleTable']+'\',\'\',\'rolesuggestionID'+rowCount['responsibleTable']+'\',\'role\');"onKeyPress="return avoidSendForm(event,\'user\');" size="28"type="text">';
	cell.innerHTML='<div class="suggestion" id="roledivID'+rowCount['responsibleTable']+'"style="width:175px;"></div>';
	//onchange="getRole(this.value);getResponsibleNames(\'responsibleinputID'+rowCount['responsibleTable']+'\');"
/*
    US #058
    User Management - Edit
    Fixed By - Infosys Limited
    Version - 2
*/     
	 var opRow = '<select style="min-width: 100%;" class="showRole" id="roleinputID'+rowCount['responsibleTable']+'"name="roleinputID'+rowCount['responsibleTable']+'"><option></option>';
		if (roleArr && roleArr.length) {
			for (var i=0; i<roleArr.length;i++) {
				opRow += '<option>'+roleArr[i].role+'</option>';  
			}
		}
		opRow += "</select>"; 
    cell.innerHTML += opRow; 
/* Ed for  US #058 User Management - Edit*/
	var cell=newRow.insertCell(1);
	cell.innerHTML='<div class="suggestion"id="responsibledivID'+rowCount['responsibleTable']+'"style="width:175px;">'
					+'</div><input class="textareaWhite" id="responsibleinputID'+rowCount['responsibleTable']+'"name="responsibleinputID'+rowCount['responsibleTable']+'" onFocus="loadUserSuggestion(this,\'responsibledivID'+rowCount['responsibleTable']+'\',\'responsibleinputID'+rowCount['responsibleTable']+'\',\'\',\'responsiblesuggestionID'+rowCount['responsibleTable']+'\');"onKeyPress="return avoidSendForm(event,\'user\');" size="28"type="text">';
	
	var cell=newRow.insertCell(2);
	cell.align="center";
	cell.innerHTML='<input class="xRemove" style="font-size:18px;" onClick="createRowWithNameSuggestionForResponsibles(this);" type="button" value="&#8626;"/>';

	var cell=newRow.insertCell(3);
	cell.align="center";
	cell.innerHTML='<input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/>';
}

function preloadImages()
{
	var preloadImagesArray = new Array(	'logo_white.png','exit.png','xexit.png','help.png','xhelp.png','userMan.png','xuserMan.png','tools.png','xtools.png',
										'admin.png','xadmin.png','validOff.png','xvalidOff.png','validOn.png','xvalidOn.png','expand.png','expanded.png',
										'rmSearch.png','search.png','searchBlank.png','r20.png','a20.png','g20.png','x20.png','b20.png','na20.png',
										'calendar.jpg','filOff.png','filOn.png','srtDown.png','srtOff.png','srtUp.png','x.png','r30.png','a30.png','g30.png',
										'x30.png','g30off.png','x30off.png','a30off.png','r30off.png','info.png','loading.gif'
									  );

	for (var i = 0; i < preloadImagesArray.length; i++) 
	{
		window['images'+i] = new Image();
		window['images'+i].src='../common/img/'+preloadImagesArray[i];
	}
}

//JFM 04_08_15
function changeStyle(style)
{
	if(typeof document.selection !== "undefined") //JFM 12_01_16
	{
		var range = document.selection.createRange();
		var something = range.parentElement();
	}
	else
	{
		var range = window.getSelection();
		var something = range.anchorNode;
	}

	var styleTheText = false;

	while (something.parentNode) 
	{
		if(something.id == 'review_remark_formatted_area')
		{
			styleTheText = true;
			break;
		}
		something = something.parentNode;
	}

	if(range.toString() != "" && styleTheText)
	{
		switch (style)
		{
			case 'bold':
				insertHtmlAfterSelection("<span style='display:inline; font-weight:bold;'>" + range.toString() + "</span>");
			break;
			case 'italic':
				insertHtmlAfterSelection("<span style='display:inline; font-style:italic;'>" + range.toString() + "</span>");
			break;
			case 'normal':
				insertHtmlAfterSelection("<span style='display:inline; text-decoration:none; font-weight:normal; font-style:normal;'>" + range.toString() + "</span>");
			break;
			case 'red':
				insertHtmlAfterSelection("<span style='display:inline; color:#ef343f;'>" + range.toString() + "</span>");
			break;
			case 'amber':
				insertHtmlAfterSelection("<span style='display:inline; color:#f89f07;'>" + range.toString() + "</span>"); //JFM 19_07_16
			break;
			case 'green':
				insertHtmlAfterSelection("<span style='display:inline; color:#81c314;'>" + range.toString() + "</span>");
			break;
			case 'blue':
				insertHtmlAfterSelection("<span style='display:inline; color:#0088cf;'>" + range.toString() + "</span>");
			break;
			case 'black':
				insertHtmlAfterSelection("<span style='display:inline; color:#000000;'>" + range.toString() + "</span>");
			break;
		}
	}
}

//JFM 17_08_15
function colapseSidebar(sidebar) 
{
	switch (sidebar)
	{
		case 'reviewSideBar':

			if($('reviewSideBar').style.display != "none")
			{
				$('reviewSideBar').style.display='none';
				$('reviewCaWpList').style.display='none';
				$('sideReviewContainer').style.left='25px';
				$('colapseSidebar').innerHTML = "&#9658;<br /><br />E<br />x<br />p<br />a<br />n<br />d<br /><br />S<br />i<br />d<br />e<br />b<br />a<br />r<br /><br />&#9658;</div>";
				$('colapseSidebar').style.left='0px';
			}
			else if($('reviewSideBar').style.display == "none")
			{
				$('reviewSideBar').style.display='block';
				$('reviewCaWpList').style.display='block';
				$('sideReviewContainer').style.left='280px';
				$('colapseSidebar').innerHTML = "&#9668;<br /><br />C<br />o<br />l<br />l<br />a<br />p<br />s<br />e<br /><br />S<br />i<br />d<br />e<br />b<br />a<br />r<br /><br />&#9668;</div>";
				$('colapseSidebar').style.left='260px';
			}
			break;

		case 'criteriaTableMoreInfo':
			if($('criteriaTableMoreInfo').style.display != "none")
			{
				$('criteriaTableMoreInfo').style.display='none';
				$('moreInfo').innerHTML = "&#9660; More Info &#9660;";
			}
			else if($('criteriaTableMoreInfo').style.display == "none")
			{
				$('criteriaTableMoreInfo').style.display='block';
				$('moreInfo').innerHTML = "&#9650; More Info &#9650;";
			}
		break;

		//JFM 19_07_16
		case 'criteriaDiffMoreInfo':
			if($('criteriaDiffMoreInfo').style.display != "none")
			{
				$('criteriaDiffMoreInfo').style.display='none';
				$('moreInfo2').innerHTML = "&#9660; More Info &#9660;";
			}
			else if($('criteriaDiffMoreInfo').style.display == "none")
			{
				$('criteriaDiffMoreInfo').style.display='block';
				$('moreInfo2').innerHTML = "&#9650; More Info &#9650;";
			}
		break;
	}
}

function statusPopUpMenu(caId, reviewId)
{
	activeCol='overDivCriteriaStatus';
	ajaxRequest('ajax/newPopup.php?ca='+caId+'&review='+reviewId,'olstickyNewPopup',false,'GET');
}

function cleanPaste() //JFM 28_10_15
{
	event.returnValue = false;
	event.preventDefault();
	var clipboardData = window.clipboardData.getData("Text");
	clipboardData  = clipboardData.replace(/(?:\r\n|\r|\n)/g, "<br />");
	if(typeof document.selection !== "undefined") //JFM 12_01_16
		var range = document.selection.createRange();
	else
		var range = window.getSelection();
	//range.pasteHTML(clipboardData);
	
	insertHtmlAfterSelection(clipboardData);
}

function insertHtmlAfterSelection(html) //TODO
{
    var sel, range, node;
    if (window.getSelection)
    {
        sel = window.getSelection();
        if (sel.getRangeAt && sel.rangeCount)
        {
            range = sel.getRangeAt(0);
            range.deleteContents();

            var el = document.createElement("div");
            el.innerHTML = html;
            var frag = document.createDocumentFragment(), node, lastNode;
            while ( (node = el.firstChild) ) 
            {
                lastNode = frag.appendChild(node);
            }
            range.insertNode(frag);
        }
    }
    else if (document.selection && document.selection.createRange)
    {
        range = document.selection.createRange();
        range.collapse(false);
        range.pasteHTML(html);
    }
}

function wizardStepCalculate(whichWay) //JFM 12_01_16
{
	var whatSay=new Array(	'What would you like to do?',				//0
							'Where would you like to ',					//1
							'Please fill in the following form...',		//2
							'The following will take place...',			//3
							'Please Wait...',							//4
							'Complete!');								//5

	var problem = -1;
	var problemArray = new Array(
									'Please select both values...',
									'Please select all values...',
									'Some fields cannot be left blank...'
								);

	var creationItem = $('doWhere').options[$('doWhere').selectedIndex].text;

	whatSay[1] = whatSay[1] + $('whatDo').value + " this " + creationItem.substring(0,(creationItem.length-1)) + "?";

	if(whichWay==1)
	{	
		//Find problems at each step.
		switch(wizardStep)
		{
			case 0:
				if($('whatDo').value == 'nothing' || $('doWhere').value == 'nothing')
					problem = 0;
			break;
			case 1:
				if($('strDdArea').value == '' || 
					$('strDdProgram').value == '' ||
					$('strDdCoe').value == '' ||
					$('strDdPerimeter').value == '' ||
					$('strDdMsn').value == '')
					problem = 1;

				else if($('whatDo').value=='edit')
				{
					problem = 1;
					var radios = document.getElementsByName('wizardEdit');
					for (var i = 0, length = radios.length; i < length; i++) 
					{
						if (radios[i].checked) 
						{
							problem = -1;
							break;
						}
					}
				}
			break;
			case 2:
				switch ($('doWhere').value)
				{
					case 'wp':
						if($('wp').value == "" || $('ca').value == "")
							problem = 2;
					break;
				}
			break;
			case 5:
				closeLastForm();
				problem = 99;
			break;
		}

		//If no problems switch to different opens and display the cases based on the current step.
		if(problem < 0)
		{
			containerDiv='box2';
			switch ($('doWhere').value)
			{
				case 'ca':
				case 'wp':
					switch (wizardStep)
					{
						case 1:
							var doingWhat = '';

							if($('doWhere').value == 'wp')
							{
								doingWhat = '&mode=addWp&applicability=new';
								if($('whatDo').value=='edit')
								{
									var radios = document.getElementsByName('wizardEdit');
									for (var i = 0, length = radios.length; i < length; i++) 
									{
										if (radios[i].checked) 
										{
											doingWhat = '&mode=editCaWpName&applicability='+radios[i].id;
											break;
										}
									}
								}
							}
							else if($('doWhere').value == 'ca')
							{
								var radios = document.getElementsByName('wizardEdit');
								for (var i = 0, length = radios.length; i < length; i++) 
								{
									if (radios[i].checked) 
									{
										if($('whatDo').value=='edit')
											doingWhat = '&mode=editCaWpName&applicability='+radios[i].id;
										else 
											doingWhat = '&mode=addCa&applicability='+radios[i].id;
										break;
									}
								}
							}
							ajaxRequest('form/editStructure.php?objectTxt=cawp'+doingWhat+'&program='+$('strDdProgram').value+'&coe='+$('strDdCoe').value+'&perimeter='+$('strDdPerimeter').value+'&msn='+$('strDdMsn').value+'&included=1','putInDiv',false,'GET');
						break;
						case 2:
							if($('doWhere').value == 'ca')
							{
								if($('whatDo').value=='new')
									$('box3').innerHTML = "A new CA <b>\"" + $('ca').value + "\"</b> will be assigned to WP <b>\"" + "???" +"\"</b> in the following location:<br /><br />";
								else if($('whatDo').value=='edit')
									$('box3').innerHTML = "The CAs name will be changed to <b>\"" + $('ca').value + "\"</b> in the following location:<br /><br />";		
							}
							else if($('doWhere').value == 'wp')
							{
								if($('whatDo').value=='new')
									$('box3').innerHTML = "A new WP <b>\"" + $('wp').value + "\"</b> and CA <b>\"" + $('ca').value +"\"</b> will be added to:<br /><br />";
								else if($('whatDo').value=='edit')
									$('box3').innerHTML = "The WPs name will be changed to <b>\"" + $('wp').value + "\"</b> and CA to <b>\"" + $('ca').value +"\"</b> in the following location:<br /><br />";
							}

							$('box3').innerHTML += "<b>" + $('strDdArea').options[$('strDdArea').selectedIndex].text 			+ "</b> -> ";
							$('box3').innerHTML += "<b>" + $('strDdProgram').options[$('strDdProgram').selectedIndex].text 		+ "</b> -> ";
							$('box3').innerHTML += "<b>" + $('strDdCoe').options[$('strDdCoe').selectedIndex].text 				+ "</b> -> ";
							$('box3').innerHTML += "<b>" + $('strDdPerimeter').options[$('strDdPerimeter').selectedIndex].text 	+ "</b> -> ";
							$('box3').innerHTML += "<b>" + $('strDdMsn').options[$('strDdMsn').selectedIndex].text;

							$('forwardButton').innerHTML = "Create &#9658;&#9658;";
						break;
						case 3:
							$('buttonHolder').style.display = 'none';
							sendAjaxForm('cawp_editStructureFrm','ajax/saveStructure.php','saveStructure','','POST',true);
						break;
						case 4:
							$('buttonHolder').style.display = 'block';
							$('box5').innerHTML = "Complete!";
							$('backButton').innerHTML = "&#9668; Add Another Item";
							$('forwardButton').innerHTML = "Finish &#9658;&#9658;";
						break;
					}
				break;
				default:
					alert('not yet implemented!');
				break;
			}

			$('wizardError').style.height='0px';

			if(wizardStep != 4) $('backButton').innerHTML = "&#9668; Previous";

			$('box'+wizardStep).style.left='-1000px';
			$('box'+(wizardStep+1)).style.display='block';
			$('box'+(wizardStep+1)).style.left='50%';
			$('box'+(wizardStep+1)).style.marginLeft='-350px';

			if(wizardStep == 4)
			{
				$('timeline').style.marginRight = "-1000px";
			}
			else
			{
				$('timeline').style.marginRight = (parseInt($('timeline').style.marginRight.replace("px", "")) - 100) + "px";
			}

			$('wizard_step_'+wizardStep).style.display='';
			$('wizard_step_'+wizardStep).style.opacity=1;

			$('stepNumber').innerHTML= 'Step '+(wizardStep+2);
			$('stepDesc').innerHTML=whatSay[wizardStep+1];

			wizardStep = wizardStep+1;
		}
		else if(problem < 99)
		{
			$('wizardError').style.height='30px';
			$('wizardErrorDescription').innerHTML=problemArray[problem];
			$('box'+wizardStep).className='boxWrong';
			setTimeout(function(){$('box'+wizardStep).className = 'box';},600);
		}
	}
	else if(whichWay==0)
	{
		if(wizardStep==0)
		{		
			closeLastForm();
		}
		else
		{
			if(wizardStep == 5)
			{
				$('backButton').innerHTML = "&#9668; Exit";
				$('forwardButton').innerHTML = "Next &#9658;&#9658;";
				$('whatDo').selectedIndex = 0;
				$('doWhere').selectedIndex = 0;

				$('timeline').style.marginRight = "225px";

				while (wizardStep != 0)
				{
					$('box'+wizardStep).style.left='100%';
					$('box'+wizardStep).style.marginLeft='350px';
					$('box'+(wizardStep-1)).style.display='block';
					$('box'+(wizardStep-1)).style.left='50%';
					$('box'+(wizardStep-1)).style.marginLeft='-350px';

					$('wizard_step_'+(wizardStep-1)).style.opacity=0;
					var oldStep = wizardStep;
					setTimeout(function(){if($('wizard_step_'+(oldStep-1))) $('wizard_step_'+(oldStep-1)).style.display='none';},1000);

					$('stepNumber').innerHTML= 'Step '+(wizardStep);
					$('stepDesc').innerHTML=whatSay[wizardStep-1];

					wizardStep = wizardStep-1;
				}
			}
			else
			{
				if(wizardStep == 2)
				{
					setTimeout(function(){$('box2').innerHTML = "";},600);
				}

				$('wizardError').style.height='0px';
				
				if(wizardStep == 1) $('backButton').innerHTML = "&#9668; Exit";
				if(wizardStep == 3) $('forwardButton').innerHTML = "Next &#9658;&#9658;";

				$('box'+wizardStep).style.left='100%';
				$('box'+wizardStep).style.marginLeft='350px';
				$('box'+(wizardStep-1)).style.display='block';
				$('box'+(wizardStep-1)).style.left='50%';
				$('box'+(wizardStep-1)).style.marginLeft='-350px';

				$('timeline').style.marginRight = (parseInt($('timeline').style.marginRight.replace("px", "")) + 100) + "px";

				$('wizard_step_'+(wizardStep-1)).style.opacity=0;
				var oldStep = wizardStep;
				setTimeout(function(){if($('wizard_step_'+(oldStep-1))) $('wizard_step_'+(oldStep-1)).style.display='none';},1000);

				$('stepNumber').innerHTML= 'Step '+(wizardStep);
				$('stepDesc').innerHTML=whatSay[wizardStep-1];

				wizardStep = wizardStep-1;
			}
		}
	}
}

function checkWizardOptions()
{
	if( $('strDdArea').value != '' &&
		$('strDdProgram').value != '' &&
		$('strDdCoe').value != '' &&
		$('strDdPerimeter').value != '' &&
		$('strDdMsn').value != ''
	  )
	{
		switch ($('doWhere').value)
		{
			case 'wp':
				if($('whatDo').value == 'edit')
				{
					$('wizardPleaseSelect').style.display = "";
					containerDiv='wizardOptions';

					ajaxParameters=attachDdValue('area','strDdArea')+attachDdValue('program','strDdProgram')+attachDdValue('coe','strDdCoe')+attachDdValue('perimeter','strDdPerimeter')+attachDdValue('msn','strDdMsn'); //JFM 03_06_14

					ajaxRequest('ajax/structureConfig.php?element=cawp&included=1&editType=wp'+ajaxParameters,'putInDiv',false,'GET');
					//ajaxRequest('form/editStructure.php?objectTxt=cawp&mode=addWp&applicability=new&program='+$('strDdProgram').value+'&coe='+$('strDdCoe').value+'&perimeter='+$('strDdPerimeter').value+'&msn='+$('strDdMsn').value+'&included=1','putInDiv',false,'GET');
				}
			break;
			case 'ca':
				$('wizardPleaseSelect').style.display = "";
				containerDiv='wizardOptions';

				ajaxParameters=attachDdValue('area','strDdArea')+attachDdValue('program','strDdProgram')+attachDdValue('coe','strDdCoe')+attachDdValue('perimeter','strDdPerimeter')+attachDdValue('msn','strDdMsn'); //JFM 03_06_14

				ajaxRequest('ajax/structureConfig.php?element=cawp&included=1&editType=wp'+ajaxParameters,'putInDiv',false,'GET');
			break;
			default:
				alert('not yet implemented!');
			break;
		}
	}
	else
	{
		$('wizardOptions').innerHTML='';
	}
}


function refreshSession()
{
	ajaxRequest('support/sessionRefresh.php','doNothing',false, 'GET');
	mainRestartNeeded=1;
}

function createRowWithNameSuggestionForReviewLinks(rowInput)
{
	rowCount['reviewLinksTable'] = 0;
	q=1;
	while(totalRows=$('nameinputID'+q))
	{
		rowCount['reviewLinksTable']++;
		q++;
	}

	rowCount['reviewLinksTable']++;

	var currentRow = rowInput.parentNode.parentNode;
	var newRow = document.createElement('tr');
	newRow.id='rowLink'+rowCount['reviewLinksTable'];

	currentRow.parentNode.insertBefore(newRow, currentRow.nextSibling );

	var cell=newRow.insertCell(0);
	cell.innerHTML='<input class="textareaWhite" id="nameinputID'+rowCount['reviewLinksTable']+'"name="nameinputID'+rowCount['reviewLinksTable']+'" size="20" type="text">';
	
	var cell=newRow.insertCell(1);
	cell.innerHTML='</div><input class="textareaWhite" id="referenceinputID'+rowCount['reviewLinksTable']+'"name="referenceinputID'+rowCount['reviewLinksTable']+'" size="20" type="text">';
	
	var cell=newRow.insertCell(2);
	cell.innerHTML='</div><input class="textareaWhite" id="linkinputID'+rowCount['reviewLinksTable']+'"name="linkinputID'+rowCount['reviewLinksTable']+'" size="20" type="text">';
	
	var cell=newRow.insertCell(3);
	cell.align="center";
	cell.innerHTML='<input class="xRemove" style="font-size:18px;" onClick="createRowWithNameSuggestionForReviewLinks(this);" type="button" value="&#8626;"/>';

	var cell=newRow.insertCell(4);
	cell.align="center";
	cell.innerHTML='<input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/>';
}






function reportWizardStepCalculate(whichWay) //JFM 08_06_16
{
	var whatSay=new Array(	'What would you like to do?',		//0
							'What would you like to extract?',	//1
							'Select report options...',			//2
							'The following will take place...',	//3
							'Please Wait...',					//4
							'Complete!');						//5

	var problem = -1;
	var problemArray = new Array(
									'Please select both values...',
									'Please select at least one option from all boxes...',
									'Please select at least one slide type and at least one format...'
								);

	if(whichWay==1)
	{
		
		switch(reportWizardStep)
		{
			case 0:
				if($('whatDo').value == 'nothing' || $('doWhere').value == 'nothing')
					problem = 0;
			break;
			case 1:
				if($('program').value == '' || 
					$('coe').value == '' ||
					$('msn').value == '' ||
					$('perimeter').value == '' ||
					$('review').value == '' ||
					$('ca').value == '')
					problem = 1;
			break;
			case 2:
				switch ($('doWhere').value)
				{
					case 'statistics':
						if($('slides').value == "" || $('type').value == "")
							problem = 2;
					break;
				}
			break;
			case 5:
				closeLastForm();
				problem = 99;
			break;
		}

		//If no problems switch to different opens and display the cases based on the current step.
		if(problem < 0)
		{
			switch ($('doWhere').value)
			{
				case 'statistics':
					switch (reportWizardStep)
					{ 
                                            
						case 2:

							var dropDownBoxArray = ['program', 'coe', 'msn', 'perimeter', 'review', 'ca'];
                                                      
                                                        if($('type').value == 'powerpoint')
							{
                                                            $('box3').innerHTML = "A overview report will be extracted into a PowerPoint file with the following data:<br />";
                                                        }
                                                        else 
                                                        {
                                                             $('box3').innerHTML = "A overview report will be extracted into a Excelsheet file with the following data:<br />";
                                                        }
                                                            var newDiv = "";
							for(var dropDownBox in dropDownBoxArray)
							{
								newDiv += "<div style='font-size:14px; overflow:auto; display:inline; float:left; height:250px; margin-right:30px; margin-top:30px;'>";

								

								var obj = $(dropDownBoxArray[dropDownBox]);

								if(obj)
								{
									for (var i=0; i<obj.options.length; i++) 
									{
										if(obj.options[i].selected == true)
										{
											newDiv += obj.options[i].text + "<br />";
										}
									}
								}
								newDiv += "</div>";
							}

							$('box3').innerHTML += newDiv;

							$('forwardButton').innerHTML = "Create &#9658;&#9658;";
                                                        
                                                        
                                                     
						break;
						case 3:
                                                   
							$('buttonHolder').style.display = 'none';
                                                        if($('type').value == 'powerpoint'){
                                                        
							sendAjaxForm('reportWizardForm','support/pptxReportWizardCalculateNoLibrary.php','pptxDownload','','POST',true);
                                                    }
                                                    else if($('type').value == 'csv')
                                                    { 
                                                    
                                                     sendAjaxForm('reportWizardForm','support/csvlibrary.php','csvdownload','','POST',true);
                                                        
                                                    }
						break;
						case 4:
                                                    
							$('buttonHolder').style.display = 'block';
							$('box5').innerHTML = "Complete!";
							$('backButton').innerHTML = "&#9668; Start Again";
							$('forwardButton').innerHTML = "Finish &#9658;&#9658;";
						break;
					}
				break;
				default:
					alert('not yet implemented!');
				break;
			}

			$('wizardError').style.height='0px';

			if(reportWizardStep != 4) $('backButton').innerHTML = "&#9668; Previous";

			$('box'+reportWizardStep).style.left='-1000px';
			$('box'+(reportWizardStep+1)).style.display='block';
			$('box'+(reportWizardStep+1)).style.left='50%';
			if(reportWizardStep == 0)
				$('box'+(reportWizardStep+1)).style.marginLeft='-450px';
			else
				$('box'+(reportWizardStep+1)).style.marginLeft='-350px';

			if(reportWizardStep == 4)
			{
				$('timeline').style.marginRight = "-1000px";
			}
			else
			{
				$('timeline').style.marginRight = (parseInt($('timeline').style.marginRight.replace("px", "")) - 100) + "px";
			}

			$('wizard_step_'+reportWizardStep).style.display='';
			$('wizard_step_'+reportWizardStep).style.opacity=1;

			$('stepNumber').innerHTML= 'Step '+(reportWizardStep+2);
			$('stepDesc').innerHTML=whatSay[reportWizardStep+1];

			reportWizardStep = reportWizardStep+1;
		}
		else if(problem < 99)
		{
			$('wizardError').style.height='30px';
			$('wizardErrorDescription').innerHTML=problemArray[problem];
			$('box'+reportWizardStep).className='boxWrong';
			setTimeout(function(){$('box'+reportWizardStep).className = 'box';},600);
		}
	}
	else if(whichWay==0)
	{
		if(reportWizardStep==0)
		{		
			closeLastForm();
		}
		else
		{
			if(reportWizardStep == 5)
			{
				$('backButton').innerHTML = "&#9668; Exit";
				$('forwardButton').innerHTML = "Next &#9658;&#9658;";
				$('whatDo').selectedIndex = 0;
				$('doWhere').selectedIndex = 0;

				$('timeline').style.marginRight = "225px";

				while (reportWizardStep != 0)
				{
					$('box'+reportWizardStep).style.left='100%';
					$('box'+reportWizardStep).style.marginLeft='350px';
					$('box'+(reportWizardStep-1)).style.display='block';
					$('box'+(reportWizardStep-1)).style.left='50%';
					$('box'+(reportWizardStep-1)).style.marginLeft='-350px';

					$('wizard_step_'+(reportWizardStep-1)).style.opacity=0;
					var oldStep = reportWizardStep;
					setTimeout(function(){if($('wizard_step_'+(oldStep-1))) $('wizard_step_'+(oldStep-1)).style.display='none';},1000);

					$('stepNumber').innerHTML= 'Step '+(reportWizardStep);
					$('stepDesc').innerHTML=whatSay[reportWizardStep-1];

					reportWizardStep = reportWizardStep-1;
				}
			}
			else
			{
				$('wizardError').style.height='0px';
				
				if(reportWizardStep == 1) $('backButton').innerHTML = "&#9668; Exit";
				if(reportWizardStep == 3) $('forwardButton').innerHTML = "Next &#9658;&#9658;";

				$('box'+reportWizardStep).style.left='100%';
				$('box'+reportWizardStep).style.marginLeft='350px';
				$('box'+(reportWizardStep-1)).style.display='block';
				$('box'+(reportWizardStep-1)).style.left='50%';
				$('box'+(reportWizardStep-1)).style.marginLeft='-350px';

				$('timeline').style.marginRight = (parseInt($('timeline').style.marginRight.replace("px", "")) + 100) + "px";

				$('wizard_step_'+(reportWizardStep-1)).style.opacity=0;
				var oldStep = reportWizardStep;
				setTimeout(function(){if($('wizard_step_'+(oldStep-1))) $('wizard_step_'+(oldStep-1)).style.display='none';},1000);

				$('stepNumber').innerHTML= 'Step '+(reportWizardStep);
				$('stepDesc').innerHTML=whatSay[reportWizardStep-1];

				reportWizardStep = reportWizardStep-1;
			}
		}
	}
}

function selectAllFromSelectMultipule(selectId)
{
	var obj = $(selectId);
	for (var i=0; i<obj.options.length; i++) 
	{
		obj.options[i].selected = true;
	} 

	switch(selectId)
	{
		case 'program':
		case 'coe':
			reportWizardSelectChange('msn');
		break;
		case 'msn':
			reportWizardSelectChange('perimeter');
		break;
		case 'perimeter':
			reportWizardSelectChange('review');
		break;
		case 'review':
			reportWizardSelectChange('ca');
		break;
	}

}


function selectNoneFromSelectMultipule(selectId)
{
	var obj = $(selectId);

	for (var i=0; i<obj.options.length; i++) 
	{
		obj.options[i].selected = false;
	}

	switch(selectId)
	{
		case 'program':
		case 'coe':
			reportWizardSelectChange('msn');
		break;
		case 'msn':
			reportWizardSelectChange('msn');
		break;
		case 'perimeter':
			reportWizardSelectChange('perimeter');
		break;
		case 'review':
			reportWizardSelectChange('review');
		break;
	}
}

function setRowColour(item, colour)
{
	item.style.backgroundColor=colour;
}

function calculateRPN() //JFM 08_06_16
{
	var severity = $('severityDropDown').options[$('severityDropDown').selectedIndex].value;
	var detection = $('detectionDropDown').options[$('detectionDropDown').selectedIndex].value;
	var occurrence = $('occurrenceDropDown').options[$('occurrenceDropDown').selectedIndex].value;

	$('rpn').innerHTML = severity * detection * occurrence;
}

function reportWizardSelectChange(nextBox)
{
	var dropDownArray = [];
	switch(nextBox)
	{
		case 'msn':
			dropDownArray = ['msn', 'perimeter', 'review', 'ca'];
		break;
		case 'perimeter':
			dropDownArray = ['perimeter', 'review', 'ca'];
		break;
		case 'review':
			dropDownArray = ['review', 'ca'];
		break;
		case 'ca':
			dropDownArray = ['ca'];
		break;
	}

	for (var j = 0; j < dropDownArray.length; j++) 
	{
		for(var i = $(dropDownArray[j]).options.length - 1 ; i >= 0 ; i--)
		{
			$(dropDownArray[j]).remove(i);
		}
	}

	ddTarget=nextBox;
	sendAjaxForm('reportWizardForm','support/pptxReportWizardDDCalculate.php?nextBox='+nextBox,'ddFill','','POST',true);
}

/*
 * Start of bug 11
 * Function for checking whether the check box is clicked or not
 * @param {String} element
 */
function saveChanges(element) {
    var frmData = [];
    var frmVal = [];
    var postdata = "";
    var postval = "";
    var cbs = document.getElementsByClassName('ReviewRowName');    
    if(cbs.length > 0) {
          for(var i in cbs) {
             if(cbs[i].type === 'checkbox') {
                 let checkValue = (cbs[i].checked)?0:1;
                 frmData.push(cbs[i].id);
                 frmVal.push(checkValue);
             }
        }
        if(frmData.length) {
            postdata = frmData.join(",");
            postval = frmVal.join(",");
            
            ajaxRequest('ajax/setDisplayedColumn.php?location='+postdata+'&value='+postval+'&element='+element,'checkOk',false,'POST');
        }
    }
}

/*
 * Function to send the ajax request on click of Toggle All button on Master criteria page
 * @param {String} reviewProfileId
 * @param {String} groupId
 * @param {String} reviewId
 * @param {String} flag
 */
function toggleIncluded(reviewProfileId,groupId,reviewId,flag) 
{
    ajaxRequest('ajax/deleteCriteria.php?review_profile='+reviewProfileId+'&group_id='+groupId+'&review_id='+reviewId+'&flag=' + flag,'checkOkAll',true,'GET');
}

/*
 * Function to save all the selected users for bulk edit in User management
 * Toggle all function 
 */
function checkAll(t)
{	
    var frmData = [];
    var frmVal = [];
	var cbs = document.getElementsByName('individualCheckedUser');  
	if(t) {
		for (var i = 0; i < cbs.length; i++) {
        if (document.getElementsByName("individualCheckedUser")[i].checked) {
            document.getElementsByName("individualCheckedUser")[i].checked = false;
        } else {
            document.getElementsByName("individualCheckedUser")[i].checked = true;
			var getUserId = document.getElementsByName("individualCheckedUser")[i].value;
			frmData.push(getUserId);
        }	
		} 
	} 
    ajaxRequest('form/list.php?bulkEdit='+frmData,true,'POST');
}
/*
Function to save all the individual selected users for bulk edit in User management
*/
function individualChecked(){
	var frmData = [];
    var frmVal = [];	
var checkedValue = null; 
var inputElements = document.getElementsByClassName('individualCheckedUser');
for(var i=0; inputElements[i]; ++i){
      if(inputElements[i].checked){
           checkedValue = inputElements[i].value;		   
		   frmData.push(checkedValue);		  
      }
}
 ajaxRequest('form/list.php?bulkEdit='+frmData,true,'POST');
}

/*
* Role Management -- Start of US #58.1 
* Mapping Multiple Areas to Single Role
* @param {String} tableID
*/
function addRow(tableID) {
			var sel = document.getElementById("assigned_area");
			var assigned_area_txt= sel.options[sel.selectedIndex].text;
			var screen = document.getElementById('screen'); 
			var assigned_area = document.getElementById("assigned_area");
			inputArray.push(assigned_area.value);
			screen.value = inputArray;
			var table = document.getElementById(tableID);
			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);
			var colCount = table.rows[1].cells.length;
			for(var i=0; i<colCount; i++) {

				var newcell	= row.insertCell(i);
				newcell.innerHTML = table.rows[1].cells[i].innerHTML;
				switch(newcell.childNodes[0].type) {
					case "text":
							newcell.childNodes[0].value = assigned_area_txt;
							newcell.className = 'paramDef';
							break;
					case "checkbox":
							var getAreaValue= sel.options[sel.selectedIndex].value;
							var getAreaLabel= sel.options[sel.selectedIndex].text;
							newcell.className = 'paramDef';
							newcell.childNodes[0].checked = false;
							newcell.childNodes[0].value = getAreaValue+"-"+getAreaLabel;
							//newcell.childNodes[0].id = getAreaLabel;
							break;
				}
			}

		/*
		* Remove already selected value from dynamic Area List
		*/
                    var i;
                    var selectbox = document.getElementById("assigned_area");
                    selectbox.remove(selectbox.selectedIndex);
			
		}
		
/*
* Add option in dynamic dropdown
*/
function addOption(selectbox,text,value )
{
        var optn = document.createElement("OPTION");
        optn.text = text;
        optn.value = value;
        selectbox.options.add(optn);
}
		
/*
 * Remove option in dynamic dropdown
 */
		
 function deleteRow(btn) {
    var responsible_role_id = document.getElementById('responsible_role_id').value;
    if (responsible_role_id == 'new') {
        var row = btn.parentNode.parentNode;
        var IsDeleted = document.querySelector('.removeAreaIds:checked').value;

        var IsDeleted = IsDeleted.split('-');
        var IsDeletedLabel = document.querySelector('.removeAreaIds:checked').id;
        var addAreaValue = document.getElementById('screen').value;
        var replaceAreaId = addAreaValue.split(',');

        var index = replaceAreaId.indexOf(IsDeleted[0]);
        if (index > -1) {
            replaceAreaId.splice(index, 1);
            inputArray.splice(index,1);
        }

        var rows = document.getElementById("dataTable").getElementsByTagName("tr").length;
        var retVal = confirm("Do you want to Remove?");
        if (retVal == true) {
            row.parentNode.removeChild(row);
            document.getElementById('screen').value = replaceAreaId;

            /*
             * Add already selected value from dynamic Area List
             */
            addOption(document.roleInfoForm.assigned_area, IsDeleted[1], IsDeleted[0]);
            return true;
        } else {
            btn.checked = false;
            return false;
        }

    } else {
        var row = btn.parentNode.parentNode;
        var IsDeleted = document.querySelector('.removeAreaIds:checked').value;

        var IsDeleted = IsDeleted.split('-');
        var IsDeletedLabel = document.querySelector('.removeAreaIds:checked').id;
        var editAreaValue = document.getElementById('screen_value').value;
        var replaceAreaId = editAreaValue.split(',');
        var index = replaceAreaId.indexOf(IsDeleted[0]);
        if (index == -1) {
            var editAreaValue = document.getElementById('screen').value;
            var replaceAreaId = editAreaValue.split(',');
            var index = replaceAreaId.indexOf(IsDeleted[0]);
            if (index > -1) {
                replaceAreaId.splice(index, 1);
                inputArray.splice(index,1);
            }
            var retVal = confirm("Do you want to Remove?");
            if (retVal == true) {
                row.parentNode.removeChild(row);
                document.getElementById('screen').value = replaceAreaId;

                /*
                 * Add already selected value from dynamic Area List
                 */
                addOption(document.roleInfoForm.assigned_area, IsDeleted[1], IsDeleted[0]);
                return true;
            } else {
                btn.checked = false;
                return false;
            }
        } else {
            if (index > -1) {
                replaceAreaId.splice(index, 1);
                inputArray.splice(index,1);
            }

            var retVal = confirm("Do you want to Remove?");
            if (retVal == true) {
                row.parentNode.removeChild(row);
                document.getElementById('screen_value').value = replaceAreaId;

                /*
                 * Add already selected value from dynamic Area List
                 */
                addOption(document.roleInfoForm.assigned_area, IsDeleted[1], IsDeleted[0]);
                return true;
            } else {
                btn.checked = false;
                return false;
            }
        }
    }
} 
		
/*
Clear For Exsiting Area ids
*/
function clearAreaIds(){
	inputArray= new Array();
}
		
/*
Validation for Existing role Name
*/
function chkExistingRoleName(roleName){
    var roleName = document.getElementById('roleName').value;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var returnval = xmlhttp.responseText;
            returnval = returnval.substr(5, 6);

            if (returnval >= 1) {
                document.getElementById("addRole_saveResponse").style.display = 'block';
                document.getElementById("applyRoleChanges").disabled = true;
                document.getElementById("applyRoleChanges").style.color = "#ccc";
            } else if (returnval == 0) {
                document.getElementById("addRole_saveResponse").style.display = 'none';
                document.getElementById("applyRoleChanges").disabled = false;
                document.getElementById("applyRoleChanges").style.color = "#004f6b";
            }
        }
    };
    xmlhttp.open("GET", "ajax/chkRoleInfo.php?roleName=" + roleName, true);
    xmlhttp.send();
}
/*
* End of US Role Management -- #58.1
*/

/*
 * Function to thow an error and disable the OK button when the user selected wrong Level1 & Level2
 * Fix for: Bug#27: Data structure
 * Fixed By: Inofsys Limited
 * Version: 4.3
 */
function cawpValidation() {
    var coe = document.getElementById('strDdCoe').value;
    var msn = document.getElementById('strDdMsn').value;

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var returnval = xmlhttp.responseText;
            returnval = returnval.substr(5, 6);
            if (returnval >= 1) {
                document.getElementById("btnSaveStructureElement").disabled = false;
                document.getElementById("newDev").style.display = 'none';
            } else if (returnval == 0) {
                document.getElementById("newDev").style.display = 'block';
                document.getElementById("btnSaveStructureElement").disabled = true;
                document.getElementById("btnSaveStructureElement").style.color = "#808080";
            }
        }
    }
    xmlhttp.open("GET", 'ajax/saveStructureCawp.php?coe=' + coe + '&msn=' + msn, true);
    xmlhttp.send();
}

/*
 * Function to handle the Supplier value
 * Fix for: US#021 - Siglum/Company name
 * Added by: Infosys Limited
 */
function externalCheck() {
    var checkbox = document.getElementById('externalUser');
    if(checkbox.checked == true){
        document.getElementsByName("supplierName")[0].disabled=false;
    }else{
        document.getElementsByName("supplierName")[0].disabled=true;
        document.getElementById("supplierId").value='';
   }
}

/*
 * Function to skip the Load User list function for Supplier field in User Management
 * Fix for: US#021 - Siglum/Company name
 * @param {String} value
 */
function skipLoadUserList(value) {
    var t= document.getElementById("skipLoadUser");
    if(t) {
            t.value = value;
    }
}

/* Added for #032 Bulk user upload (Suggested by ICT)
 * Function to save the selected user permission 
 * @param {String} element
 * @param {String} users
 * @param {String} action
 * @param {String} respDiv
 * @param {String} type
 */
function saveEditUserPermissionChanges(element, users, action, respDiv, type)
{
    saveResponseDiv = (exists(respDiv)) ? respDiv : '';
    var frmData = [];
    var frmVal = [];
    var postdata = "";
    var postval = "";

    if (type == 'generalInfo') {
        var cbs = document.getElementsByClassName('EditGenUserCheck');
    } else {
        var cbs = document.getElementsByClassName('EditUserCheck');
    }

    for (var i = 0; cbs[i]; ++i) {
        if (cbs[i].checked) {
            checkedValue = cbs[i].value;
            if (checkedValue == 1) {
                frmData.push(cbs[i].id);
                frmVal.push(checkedValue);
            }
        }
    }
    if (frmData.length) {
        postdata = frmData.join(",");
        postval = frmVal.join(",");
        ajaxRequest('ajax/editBulkUserSetPermission.php?location=' + postdata + '&value=' + postval + '&element=' + element + '&userList=' + users + '&action=' + action, 'bulkEdit', true, 'POST', type);
    }
}

/* Added for #032 Bulk user upload (Suggested by ICT)
 * Function to clear the checked check box
 * @param {String} type
 */
function clearCheckbox(type)
{
    if (type == 'generalInfo') {
        var cbs = document.getElementsByClassName('EditGenUserCheck');

        for (var i = 0; i < cbs.length; i++) {
            if (document.getElementsByName("EditGenUserCheck")[i].checked) {
                document.getElementsByName("EditGenUserCheck")[i].checked = false;
                document.getElementById("Checkedid" + cbs[i].id).style.display = 'none';
            }
        }
    } else if (type == 'specific') {
        var cbsSpecific = document.getElementsByClassName('EditUserCheck');

        for (var j = 0; j < cbsSpecific.length; j++) {
            if (document.getElementsByName("EditUserCheck")[j].checked) {
                document.getElementsByName("EditUserCheck")[j].checked = false;
                document.getElementById("Checkedid" + cbsSpecific[j].id).style.display = 'none';
            }
        }
    }
}

/*
* Remove User Supplier option in dynamic dropdown
* US#021.1 - Siglum/Comapny Name
* @param {object} btn
*/
		
 function deleteSupRow(btn) {
    var prm_id = document.getElementById('prm_id').value;
    if (prm_id == 'new') {
        var row = btn.parentNode.parentNode;
        var IsDeleted = document.querySelector('.removeSupIds:checked').value;
        var IsDeleted = IsDeleted.split('-');
        var addSupValue = document.getElementById('screen').value;
        var replaceSupId = addSupValue.split(',');

        var index = replaceSupId.indexOf(IsDeleted[0]);
        if (index > -1) {
            replaceSupId.splice(index, 1);
            inputArray.splice(index,1);
        }

        var retVal = confirm("Do you want to Remove?");
        if (retVal == true) {
            row.parentNode.removeChild(row);
            document.getElementById('screen').value = replaceSupId;

            /*
             * Add already selected value from dynamic Area List
             */
            addOption(document.getElementById('assigned_sup'), IsDeleted[1], IsDeleted[0]);
            return true;
        } else {
            btn.checked = false;
            return false;
        }

    } else {
        var row = btn.parentNode.parentNode;
        var IsDeleted = document.querySelector('.removeSupIds:checked').value;
        var IsDeleted = IsDeleted.split('-');
        var editSupValue = document.getElementById('screen_value').value;
        var replaceSupId = editSupValue.split(',');        
        var index = replaceSupId.indexOf(IsDeleted[0]);
        if (index == -1) {
            var editSupValue = document.getElementById('screen').value;
            var replaceSupId = editSupValue.split(',');
            var index = replaceSupId.indexOf(IsDeleted[0]);
            if (index > -1) {
                replaceSupId.splice(index, 1);
                inputArray.splice(index,1);
            }
            var retVal = confirm("Do you want to Remove?");
            if (retVal == true) {
                row.parentNode.removeChild(row);
                document.getElementById('screen').value = replaceSupId;

                /*
                 * Add already selected value from dynamic Area List
                 */
                addOption(document.getElementById('assigned_sup'), IsDeleted[1], IsDeleted[0]);
                return true;
            } else {
                btn.checked = false;
                return false;
            }
        } else {
            if (index > -1) {
                replaceSupId.splice(index, 1);
                inputArray.splice(index,1);
            }

            var retVal = confirm("Do you want to Remove?");
            if (retVal == true) {
                row.parentNode.removeChild(row);
                document.getElementById('screen_value').value = replaceSupId;

                /*
                 * Add already selected value from dynamic Supplier List
                 */
                addOption(document.getElementById("assigned_sup"), IsDeleted[1], IsDeleted[0]);
                return true;
            } else {
                btn.checked = false;
                return false;
            }
        }
    }
}

/*
 * US#021.1 - Siglum/Comapny Name
 * Mapping Multiple Suppliers to Single Perimeter
 * @param {String} tableID
 */
function addSupRow(tableID) {
    var sel = document.getElementById("assigned_sup");
    var assigned_sup_txt = sel.options[sel.selectedIndex].text;
    var screen = document.getElementById('screen');
    var assigned_sup = document.getElementById("assigned_sup");
    inputArray.push(assigned_sup.value);
    screen.value = inputArray;
    var table = document.getElementById(tableID);
    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);
    var colCount = table.rows[1].cells.length;

    for (var i = 0; i < colCount; i++) {
        var newcell = row.insertCell(i);
        newcell.innerHTML = table.rows[1].cells[i].innerHTML;
        switch (newcell.childNodes[0].type) {
            case "text":
                newcell.childNodes[0].value = assigned_sup_txt;
                newcell.className = 'paramDef';
                break;
            case "checkbox":
                var getSupValue = sel.options[sel.selectedIndex].value;
                var getSupLabel = sel.options[sel.selectedIndex].text;
                newcell.className = 'paramDef';
                newcell.childNodes[0].checked = false;
                newcell.childNodes[0].value = getSupValue + "-" + getSupLabel;
                break;
        }
    }

    /*
     * Remove already selected value from dynamic Supplier List
     */
    var i;
    var selectbox = document.getElementById("assigned_sup");
    selectbox.remove(selectbox.selectedIndex);
}

/* 
 * Funtion to redirect the page to home page when Back button is clicked on Edit User screen
 * Added to reload the modified user information
 * Version: 4.3
 * Fixed By: Infosys Limited
 */
function refreshUserMan() {
    closeLastForm();
    openForm('../home','',false,'GET');
    document.getElementById("tblTab").click();
}
// End of US#21.1

/*
 * Fix for : US#106 Improvement: Freeze Function for completed DR 
 * Added for freeze/unfreeze function
 * Version: 4.3
 * Fixed By: Infosys Limited
 */
		
function saveDisabledReview(reviewId,caId,userId,flag) {
		var freezeMe=prompt('This will freeze the review.\nIf you are sure, please type the words: FREEZE REVIEW','');
		if(freezeMe=='FREEZE REVIEW')
		{
                  ajaxRequest('ajax/saveReviewFreeze.php?reviewId='+reviewId+'&caId='+caId+'&userId='+userId+'&isfreeze='+flag,false,'GET');
              	  alert("Review has been frozen");				  
 				  openForm('../home','',false,'GET');
				  document.getElementById("tblTab").click();
		} 
		else if (freezeMe!=null)
		{
			alert('Please enter the words exactly as shown.');
		}
}

function unfreezeReview(reviewId,caId,flag) {
		var unfreezeMe=prompt('This will unfreeze the review.\nIf you are sure, please type the words: UNFREEZE REVIEW','');
		if(unfreezeMe=='UNFREEZE REVIEW')
		{
			    ajaxRequest('ajax/saveReviewFreeze.php?reviewId='+reviewId+'&caId='+caId+'&isfreeze='+flag,false,'GET');
				alert("Review has been enabled");
				openForm('../home','',false,'GET');
				document.getElementById("tblTab").click();
		} 
		else if (unfreezeMe!=null)
		{
			alert('Please enter the words exactly as shown.');
		}
}
/* End for US#106 Improvement: Freeze Function for completed DR */

/*
 * Fix for : US #19 - Change workflow for creating a design review 
 * Added for general information above checklist
 * Version: 4.3
 * Fixed By: Infosys Limited
 */
function clickMainTable(){
				sendAjaxForm('reviewInfoFrm','ajax/saveReviewInfo.php','updateData','review_saveResponse');
				closeLastForm();
				openForm('../home','',false,'GET');
				document.getElementById("tblTab").click();
				openForm('../home','',false,'GET');
				document.getElementById("tblTab").click();
				
}
function refreshMainTable(){
				closeLastForm();
				openForm('../home','',false,'GET');
				document.getElementById("tblTab").click();			
}
/* End for US #19 - Change workflow for creating a design review */

/*
 * Fix for : US #19.1 - Change workflow for creating a design review 
 * Added for general information above checklist
 * Version: 4.3
 * Fixed By: Infosys Limited
 */
function plannedDateMandatory(){
	if($('planned').value =="") 
	{
		alert('You MUST select the PLANNED DATE before validating a review.');
		document.getElementById("createCriteriaSubmit").disabled=true;
		
	}
	else{
		alert('You MUST click APPLY CHANGES button to save the PLANNED DATE before validating a review.');
	}
}
// END for US #19.1 - Change workflow for creating a design review

/*
 * To Delete Review Type
 * US#110 - Possibility to delete Review Type, L1, L2 and L3
 * @param {String} objectTxt
 * @param {String} reviewProfile
 * @param {String} area
 * @param {Integer} reviewCount
 */
function removeReviewType(objectTxt, reviewProfile, area, reviewCount)
{
    if (confirm('Are you sure you want to remove the Review Type ?\n\nThis will delete all the review(s) and \n\n Criteria under this Rivew type'))
    {
        ajaxRequest('ajax/saveStructure.php?objectTxt=' + objectTxt + '&reviewProfile=' + reviewProfile + '&area=' + area, 'reloadSideElement', true, 'POST');
    }
}

/*
 * To Delete Level3 (MSN)
 * US#110 - Possibility to delete Review Type, L1, L2 and L3
 * @param {String} msn
 */
function removeMsn(msn) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var returnval = xmlhttp.responseText;
            returnval = returnval.substr(5, 6);
            var retVal = confirm('Are you sure you want to remove the Level? \n\n This will delete all the reviews. \n\n All CA and WP under this Level ');
            if (retVal == true) {
                xmlhttp.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        var returnval = xmlhttp.responseText;
                        if (returnval) {
                            closeLastForm();
                            openForm('structure', '', false, 'GET');
                            setTimeout(function () {
                                document.getElementById("structureElement_msn").click();
                                document.getElementById("structureElement_msn").click();
                            }, 10);
                            setTimeout(function () {
                                document.getElementById("structureElement_msn").click();
                                document.getElementById("structureElement_msn").click();
                            }, 10);
                        }
                    }
                }
                xmlhttp.open("GET", 'ajax/deletelevels.php?msn=' + msn, true);
                xmlhttp.send();
                return true;
            } else {
                return false;
            }
        }
    }
    xmlhttp.open("GET", 'ajax/getReviewsCount.php?msn=' + msn, true);
    xmlhttp.send();
}

/*
 * To Delete Level1 (MSN)
 * US#110 - Possibility to delete Review Type, L1, L2 and L3
 * @param {String} Program
 */
function removeProgram(program) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var returnval = xmlhttp.responseText;
            returnval = returnval.substr(5, 6);
            var retVal = confirm('Are you sure you want to remove the Level? \n\n This will delete all the reviews. \n\n All CA and WP under this Level ');
            if (retVal == true) {
                xmlhttp.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        var returnval = xmlhttp.responseText;
                        if (returnval) {
                            closeLastForm();
                            openForm('structure', '', false, 'GET');
                            setTimeout(function () {
                                document.getElementById("structureElement_program").click();
                                document.getElementById("structureElement_program").click();
                            }, 10);
                            setTimeout(function () {
                                document.getElementById("structureElement_program").click();
                                document.getElementById("structureElement_program").click();
                            }, 10);
                        }
                    }
                }
                xmlhttp.open("GET", 'ajax/deletelevels.php?program=' + program, true);
                xmlhttp.send();
                return true;
            } else {
                return false;
            }
        }

    }
    xmlhttp.open("GET", 'ajax/getReviewsCount.php?program=' + program, true);
    xmlhttp.send();
}

/*
 * To Delete Level1 (MSN)
 * US#110 - Possibility to delete Review Type, L1, L2 and L3
 * @param {String} Program
 */
function removeCoe(coe) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var returnval = xmlhttp.responseText;
            returnval = returnval.substr(5, 6);
            var retVal = confirm('Are you sure you want to remove the Level? \n\n This will delete all the reviews. \n\n All CA and WP under this Level ');
            if (retVal == true) {
                xmlhttp.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        var returnval = xmlhttp.responseText;
                        if (returnval) {
                            closeLastForm();
                            openForm('structure', '', false, 'GET');
                            setTimeout(function () {
                                document.getElementById("structureElement_coe").click();
                                document.getElementById("structureElement_coe").click();
                            }, 10);
                            setTimeout(function () {
                                document.getElementById("structureElement_coe").click();
                                document.getElementById("structureElement_coe").click();
                            }, 10);
                        }
                    }
                }
                xmlhttp.open("GET", 'ajax/deletelevels.php?coe=' + coe, true);
                xmlhttp.send();
                return true;
            } else {
                return false;
            }
        }

    }
    xmlhttp.open("GET", 'ajax/getReviewsCount.php?coe=' + coe, true);
    xmlhttp.send();
}

/*
 * To refresh the main table on click of Back button on Structure Management
 * US#110 - Possibility to delete Review Type, L1, L2 and L3
 */
function refreshMainPage(){
    closeLastForm();
    window.location.href = 'index.php';
}
// End - US110
/*
 * Start of US#018-Create Design Review From Review 
 * To retrieve the Coe(level 2) data based on selection of level 1
 * fixed by Infosys Limited
 * @param {Interger} Program id
 */
function getListOfCoe(programValue)
{
	var program_id = programValue;
	var review = document.getElementById('review').value;
	var selected= document.getElementById('caInfoBox2');
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () 
	{
        if (this.readyState == 4 && this.status == 200) 
		{
            var returnval = xmlhttp.responseText;
            returnval = returnval.substr(5);
			if (returnval) 
			{
					removeOptions(selected);
					var options = returnval.split(',');
					for(var i = 0; i < options.length; i++) 
					{
					var opt = options[i];
					var result = opt.split('-');
					var el = document.createElement("option");
					el.textContent = result[2];
					el.value = result[0]+'_'+result[1]; 
					selected.appendChild(el);
					}
            }	
        }
    };
    xmlhttp.open("GET", "ajax/getCoe.php?program_id=" + program_id+'&review='+review, true);
    xmlhttp.send();
}
/*
 * Remove options for selected value in the dropdown list
 * US#018-Create Design Review From Review 
 * fixed by Infosys Limited
 * @param {String} dropdown
 */
 
function removeOptions(select) {
  while (select.options.length > 1) {                
    select.remove(1);
  }
  select.value = "";
}

/*
 * To retrieve the MSN(level 3) data based on selection of level 2
 * US#018-Create Design Review From Review 
 * fixed by Infosys Limited
 * @param {Interger} Coe id
 */
 
function getListOfMsn(Coevalue)
{
	var coe_id = Coevalue;
	var review = document.getElementById('review').value;
	var selected= document.getElementById('caInfoBox');
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function ()
	{
        if (this.readyState == 4 && this.status == 200)
		{
            var returnval = xmlhttp.responseText;
            returnval = returnval.substr(5);
			if(returnval)
			{
					removeOptions(selected);
					var options = returnval.split(',');
					for(var i = 0; i < options.length; i++) {
					var opt = options[i];
					var result = opt.split('-');
					var el = document.createElement("option");
					el.textContent = result[2]+'-'+result[3];
					el.value = result[0]+'_'+result[1];; 
					selected.appendChild(el);
					}
			}
			else
			{
				var selectbox = document.getElementById('caInfoBox');
				selectbox.remove(selectbox.selectedIndex);
			}	
        }
    };
    xmlhttp.open("GET", "ajax/getCoe.php?coe_id=" + coe_id+'&review='+review, true);
    xmlhttp.send();
}
/// End of US#018-Create Design Review From Review
/*
 * US#113 - Managing of new criteria in different criteria lists
 * Get the Program, Coe and MSN of DR to check the criteria discrepancy
 * Version: 4.4
 * Fixed by: Infosys Limited
 */
function criteriaCheck() {
    var ca = document.getElementById('caInfoBox').value;
    var program_coe = document.getElementById('caInfoBox2').value;
    var res = ca.split('_');
    var res1 = program_coe.split('_');
    
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var returnval = xmlhttp.responseText;
            returnval = returnval.substr(5);
            if (returnval == 'criteria_modified&') {
                document.getElementById('criteriaModify').style.display = 'block';
                document.getElementById('criteriaAdded').style.display = 'none';
                document.getElementById('criteriaModAdd').style.display = 'none';
            }
            else if (returnval == '&criteria_added') {
                document.getElementById('criteriaAdded').style.display = 'block';
                document.getElementById('criteriaModify').style.display = 'none';
                document.getElementById('criteriaModAdd').style.display = 'none';
            } 
             else if (returnval == 'criteria_modified&criteria_added') {
                document.getElementById('criteriaModAdd').style.display = 'block';
                document.getElementById('criteriaModify').style.display = 'none';
                document.getElementById('criteriaAdded').style.display = 'none';
            } 
            else {
                document.getElementById('criteriaModify').style.display = 'none';
                document.getElementById('criteriaAdded').style.display = 'none';
                document.getElementById('criteriaModAdd').style.display = 'none';
            }
        }
    }
    xmlhttp.open("GET", 'form/checkCriteriaDiscrepancy.php?caId='+res[0]+'&reviewType='+res[1]+'&program='+res1[0]+'&coe='+res1[1], true);
    xmlhttp.send();
}
//End of US#113

/*
 * US#91 - Improvement:Extra all design reviews
 * Get the Program, Coe and MSN based on the area selection
 * Version: 4.4
 * Created by: Infosys Limited
 */

function showErrroMsg()
{
    if ($('areaselect').value == '') {
        document.getElementById('wizardAreaSelection').style.display = 'block';
        document.getElementById('wizardAreaSelection').style.height = '30px';
    } 
	else if(kpiTable.length === 0){ 
		if ($('program').value == '' || $('coe').value == '' || $('msn').value == '')
    {
        document.getElementById('wizardlevelSelection').style.display = 'block';
        document.getElementById('wizardlevelSelection').style.height = '30px';
		document.getElementById("graphHolder").style.display = "block";
    }
     else{
		 document.getElementById('wizardDataSelection').style.display = 'block';
         document.getElementById('wizardDataSelection').style.height = '30px';
		 document.getElementById("graphHolder").style.display = "block";
	 }	
	} else {

        document.getElementById('wizardlevelSelection').style.display = 'none';
        document.getElementById("box1").style.display = "none";
        document.getElementById("box2").style.display = "block";
		document.getElementById("backButtonDiv").style.display = "block";
		document.getElementById("forwardButtonDiv").style.display = "none";
    }    
}	 
function goToPreviousPage()
{
        document.getElementById("box1").style.display = "block";
        document.getElementById("box2").style.display = "none";
		document.getElementById("backButtonDiv").style.display = "none";
		document.getElementById("forwardButtonDiv").style.display = "block";
		document.getElementById("actionKpi").style.display = "none";
		document.getElementById("criteriaKpi").style.display = "none";
		document.getElementById("piemsg").style.display = "none";
		document.getElementById("box5").style.display = "none";
		document.getElementById("revGraphHolder").style.display = "none";
                document.getElementById("actnGraphHolder").style.display = "none";
                document.getElementById("pieActionmsg").style.display = "none";
		
}
function kpiWizardAreaSelectChange()
{
	document.getElementById('additm').style.opacity = '0.5';
	document.getElementById('additm').disabled = true;
	var areaId = document.getElementById("areaselect").value;
	document.getElementById('wizardAreaSelection').style.display ='none';
	var programselected = document.getElementById("program");
	var msnselected = document.getElementById("msn");
	msnselected.innerHTML="";
	var coeSelected   =document.getElementById("coe");
	var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () 
	{
        if (this.readyState == 4 && this.status == 200)
		{
            returnval = xmlhttp.responseText;
            returnval = returnval.substr(5);
            pgm = returnval.substring( 0, returnval.indexOf("@"));
            coe = returnval.substring(returnval.indexOf("@")+1, returnval.length);
            if(pgm)
            {
                programselected.innerHTML="";
			    options = pgm.split(',');
                for(var i = 0; i < options.length; i++) 
				{ 
                    var opt = options[i];
					var resultPgm = opt.split('+');
				    var el = document.createElement("option");
                    el.textContent= resultPgm[1];
					el.value = resultPgm[0];
                    programselected.appendChild(el); 
          		} 
				
			}
			if(coe)
            {
                coeSelected.innerHTML="";
			    optionCoe = coe.split(',');
                for(var i = 0; i < optionCoe.length; i++) 
				{ 
                    var optCoe = optionCoe[i];
					var resultCoe = optCoe.split('+');
				    var el = document.createElement("option");
                    el.textContent= resultCoe[1];
					el.value = resultCoe[0];
                    coeSelected.appendChild(el); 
          		} 
				
			}
		}   
	
	}
    xmlhttp.open("GET",'ajax/kpiReportWizardcal.php?areaId='+areaId, true);
    xmlhttp.send();
 
}

function selectKpiAllMultiple(selectId)
{
	var obj = $(selectId);
	for (var i=0; i<obj.options.length; i++) 
	{
		obj.options[i].selected = true;
	}  
    
	switch(selectId)
	{
		case 'program':
		case 'coe':
			kpiWizardSelectAllChange('msn');
		break;
		
	}

} 

function selectKpiNoneMultiple(selectId)
{
	var obj = $(selectId);

	for (var i=0; i<obj.options.length; i++) 
	{
		obj.options[i].selected = false;
	}

	switch(selectId)
	{
		case 'program':
		case 'coe':
			kpiWizardSelectNoneChange('msn');
		break;
		case 'msn':
			kpiWizardSelectNoneChange('msn');
		break;
		
	}
}

function kpiWizardSelectAllChange(nextBox)
{
	if($('coe').value == '' || $('msn').value == ''){
		document.getElementById('additm').style.opacity = '0.5';
		document.getElementById('additm').disabled = true;	
	}
	else {
      document.getElementById('additm').style.opacity = '1';
	  document.getElementById('additm').disabled = false;	
	}
	document.getElementById('additm').style.opacity = '0.5';
	document.getElementById('additm').disabled = true;
    document.getElementById('wizardlevelSelection').style.display = 'none';
	document.getElementById('wizardDataSelection').style.display = 'none';
	var pgmArray = [];
	var areaId = document.getElementById("areaselect").value;
	var pgmSelect=document.getElementById("program");
	var msnselected = document.getElementById("msn");
		for ( var i = 0; i < pgmSelect.options.length; i++ ) {
            if ( pgmSelect.options[i].selected === true ) {
                    pgmArray.push(pgmSelect.options[i].value);
            }
        }		
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () 
	{
        if (this.readyState == 4 && this.status == 200)
		{
            returnval = xmlhttp.responseText;
            returnval = returnval.substr(5);
			if(returnval)
			{
				    msnselected.innerHTML="";
					var options = returnval.split(',');
					for(var i = 0; i < options.length; i++) {
					var opt = options[i];
					var result = opt.split('+');
					var el = document.createElement("option");
					el.textContent = result[1];
					el.value = result[0]; 
					msnselected.appendChild(el);
					}
			}
		
		}   
	
	}
	if(pgmArray.length == pgmSelect.options.length){
	xmlhttp.open("GET","ajax/kpiReportWizardcal.php?nextBox="+nextBox+'&areaId='+areaId, true);
	xmlhttp.send();
	}
	else{
		xmlhttp.open("GET","ajax/kpiReportWizardcal.php?nextBox="+nextBox+'&pgmId='+pgmArray, true);
        xmlhttp.send();
	}
	
}	 

	

function kpiWizardSelectNoneChange(nextBox)
{
	var dropDownArray = [];
	dropDownArray.push(nextBox);
	for (var j = 0; j < dropDownArray.length; j++) 
	{
		for(var i = $(dropDownArray[j]).options.length - 1 ; i >= 0 ; i--)
		{
			$(dropDownArray[j]).remove(i);
		}
	}
	document.getElementById('additm').style.opacity = '0.5';
	document.getElementById('additm').disabled = true;
} 

function selectAllMsn() { 
   selectBox=document.getElementById('msn');
        for (var i = 0; i < selectBox.options.length; i++) { 
             selectBox.options[i].selected = true; 
        }
    document.getElementById('additm').style.opacity = '1';
	document.getElementById('additm').disabled = false;		
    }

/*
 * Function to create the Data structure table dynamically - US#091
 */
function addItemToTable() {
	document.getElementById('wizardDataSelection').style.display = 'none';
    //Scroll Bar
	var boxs=document.getElementById('box1');
	boxs.style.height='450px';
	boxs.style.width='800px'; 
	boxs.style.overflow='auto';
	//Area
    var area = document.getElementById('areaselect');
    var areas = area.options[area.selectedIndex].text;
    var areaId = area.options[area.selectedIndex].value;
    
    //Program
    var program = document.getElementById('program');
    var programs = [];
    var programIds = [];
    for (var i = 0; i < program.options.length; i++) {
        if (program.options[i].selected) {
            programs.push(program.options[i].text);
            programIds.push(program.options[i].value);
        }
    } 
    // coe
    var coe = document.getElementById('coe');
    var coes = [];
    var coeIds = [];
    for (var i = 0; i < coe.options.length; i++) {
        if (coe.options[i].selected) {
            coes.push(coe.options[i].text);
            coeIds.push(coe.options[i].value);
        }
    }
    // MSN
    var msn = document.getElementById('msn');
    var msns = [];
    var msnIds = [];
    for (var i = 0; i < msn.options.length; i++) {
        if (msn.options[i].selected) {
            msns.push(msn.options[i].text);
            msnIds.push(msn.options[i].value);
        }
    }
    
    var kpiArray = {
        area:areaId,
        program: programIds.toString(),
        coe: coeIds.toString(),
        msn: msnIds.toString()
    };
    
    // Push all the values to global array
    kpiTable.push(kpiArray);

    var table = document.getElementById('dataTable');
    var row = table.insertRow(1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    cell1.innerHTML = areas;
    cell2.innerHTML = programs.toString();
    cell3.innerHTML = coes.toString();
    cell4.innerHTML = msns.toString();
    cell5.innerHTML = '<input type="button" id=' +counter+ ' class="stdBtn" value="&#10007;" onClick="deleteCurrentRow(this)" />';
    counter++;	
}

/*
 * Function to Delete a row on click of delete button
 */
function deleteCurrentRow(r) {
  var i = r.parentNode.parentNode.rowIndex;
  document.getElementById("dataTable").deleteRow(i);
  //delete kpiTable[r.id];
  kpiTable.splice(kpiTable[r.id],1);
}   

/*
* Function on click of generate reports
*/

function generateReport() {
	//From date value(Month,Year,Date)
    var calFromDate = document.getElementById("from").value;
    var fromYear = calFromDate.substring(0, 4);
    var fromMonth = calFromDate.substring(5, 7);
    var fromDate = calFromDate.substring(8);
    var fromDateVal = new Date(fromYear, fromMonth, fromDate);
    //To date value(Month,Year,Date)
    var calToDate = document.getElementById("to").value;
    var toYear = calToDate.substring(0, 4);
    var toMonth = calToDate.substring(5, 7);
    var toDate = calToDate.substring(8);
    var toDateVal = new Date(toYear, toMonth, toDate);
    var datediffval = (toDateVal - fromDateVal);

    if (calFromDate == '') {
        document.getElementById('wizardDateSelection').style.display = 'block';
        document.getElementById('wizardDateSelection').style.height = '30px';
    } else if (calToDate == '') {
        document.getElementById('wizardDateSelection').style.display = 'block';
        document.getElementById('wizardDateSelection').style.height = '30px';
    } else if (calFromDate == '' && calToDate == '') {
        document.getElementById('wizardDateSelection').style.display = 'block';
        document.getElementById('wizardDateSelection').style.height = '30px';
    } else if (datediffval < 0) {
        document.getElementById('wizardDateValidation').style.display = 'block';
        document.getElementById('wizardDateValidation').style.height = '30px';
    } else {
        document.getElementById('wizardDateValidation').style.display = 'none';
        document.getElementById('wizardDateSelection').style.display = 'none';
        var kpivalue = document.getElementById('kipoption');
        var kpival = kpivalue.options[kpivalue.selectedIndex].text;
        var kpiData = JSON.stringify(kpiTable);
        if (kpival == 'Extract Design Reviews') {            
            sendAjaxForm('KpiReportWizardForm', 'support/kpiGenerate.php?kpiData=' + kpiData +'&type=review', 'exceldownload', '', 'POST', true);
        } else if (kpival == 'Generate Design Reviews Piechart') {
            generatekpirev('Reviews');
            document.getElementById("revGraphHolder").style.display = "block";
        } else if(kpival == 'Extract Criteria') {
            sendAjaxForm('KpiReportWizardForm', 'support/kpiGenerate.php?kpiData=' + kpiData+'&type=criteria', 'criteriaReport', '', 'POST', true);
        } else if(kpival == 'Extract Actions & RIDs') {
            sendAjaxForm('KpiReportWizardForm', 'support/kpiGenerate.php?kpiData=' + kpiData+'&type=action', 'actionReport', '', 'POST', true);
        }
        else if (kpival == 'Generate Actions Piechart') {
            generatekpirev('Actions');
            document.getElementById("actnGraphHolder").style.display = "block";
        }
    }

}

/*
* #094-Improvement: Measure DR effectiveness
*  Function to get piechart data
* Version: 4.4
* Created by: Infosys Limited
*/
function generatekpirev(pieType)
{
    var graphArr = [];
    var graphMeArr = [];
    var fromDate = document.getElementById("from").value;
    var toDate = document.getElementById("to").value;
    var kpiData = JSON.stringify(kpiTable);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var returnval = xmlhttp.responseText;
            var rtArraySplit = returnval.split('&&&');
            graphArr = rtArraySplit[1].split('---');
            graphMeArr = graphArr[1].split(',');
            if(graphMeArr[0] == 'Reviews Count') {
                kpigraph(graphArr[0], graphArr[1].split(','), 'revGraphHolder');
            } else if(graphMeArr[0] == 'Actions Count') {
                kpigraph(graphArr[0], graphArr[1].split(','), 'actnGraphHolder');
            }
            
        }
    };
    // Added conditions for Action Pie chart - US#096
    if(pieType == 'Reviews') {
        xmlhttp.open("GET", 'ajax/kpiReviewPie.php?kpiData=' + kpiData + '&from=' + fromDate + '&to=' + toDate, true);
    } else if(pieType == 'Actions') {
        xmlhttp.open("GET", 'ajax/kpiActionsPie.php?kpiData=' + kpiData + '&from=' + fromDate + '&to=' + toDate, true);
    }
    
    xmlhttp.send();
}

/*
* #094-Improvement: Measure DR effectiveness
*  Function to draw piechart
* Version: 4.4
* Created by: Infosys Limited
*/
function kpigraph(graphId, countEverything, graphType)
{
    // Added conditions for Action Pie chart - US#096
    if (countEverything[1] == 0 && graphType == 'revGraphHolder') {
        document.getElementById('piemsg').style.display = 'block';
    } else  if (countEverything[1] == 0 && graphType == 'actnGraphHolder') {
        document.getElementById('pieActionmsg').style.display = 'block';
    } else {
        document.getElementById('piemsg').style.display = 'none';
        document.getElementById('pieActionmsg').style.display = 'none';
    }

    if (graphType == 'revGraphHolder') {
        var svg = document.getElementById('kpiRPie');
    } else if (graphType == 'actnGraphHolder') {
        var svg = document.getElementById('kpiAPie');
    }

    if (svg) {
        svg.removeChild(svg.firstChild);
        document.getElementById(graphType).innerHTML = '';
    }

    var graphHolder = (graphHolder ? $(graphHolder) : $(graphType));
    var graphPlaceholder = '<div style="position:absolute; width:300px; display:inline; margin-top:260px;">';
    graphPlaceholder += '<form style="padding-left:120px; display:inline; align:center;" id="test" encType="multipart/form-data" method="post">';
    graphPlaceholder += '<input name="title" id="title" type="hidden" value="' + countEverything[0].replace('\\n', ' ') + '"/>';
    graphPlaceholder += '<input name="red" id="red" type="hidden" value="' + countEverything[2] + '"/>';
    graphPlaceholder += '<input name="yellow" id="yellow" type="hidden" value="' + countEverything[3] + '"/>';
    graphPlaceholder += '<input name="green" id="green" type="hidden" value="' + countEverything[4] + '"/>';
    graphPlaceholder += '<input name="blue" id="blue" type="hidden" value="' + countEverything[5] + '"/>';
    graphPlaceholder += '</form>';
    graphPlaceholder += '</div>';
    //graphHolder.innerHTML+='<div><form id="test" action="support/graphsDownload.php" encType="multipart/form-data" method="post"><input name="title" id="title" type="hidden" value="'+countEverything[0].replace('\\n',' ')+'"/><input name="red" id="red" type="hidden" value="'+countEverything[2]+'"/><input name="yellow" id="yellow" type="hidden" value="'+countEverything[3]+'"/><input name="green" id="green" type="hidden" value="'+countEverything[4]+'"/><input name="blue" id="blue" type="hidden" value="'+countEverything[5]+'"/><input style="vertical-align: top;" type="image" src="../common/img/burn_up_small.png" /></form><input style="vertical-align: top;" type="image" src="../common/img/burn_up_small_blue.png" onclick="mainRestartNeeded=1; ajaxRequest(\'ajax/setGraph.php?value=0&applicability='+graphId+'_check\',\'restartMainTable\',true,\'GET\');"/></div>';

    graphHolder.innerHTML += graphPlaceholder;

    if (typeof G_vmlCanvasManager !== "undefined") //JFM 12_01_16
    {
        var canvas = document.createElement('canvas');	// We will setup the canvas dynamically so we can get many in one div.
        canvas.setAttribute("width", 300);				// Also it's hard for IE8 to get a static canvas through an AJAX call.
        canvas.setAttribute("height", 300);				// Also it makes the code a bit more generic.
        canvas.setAttribute("id", graphId);
        graphHolder.appendChild(canvas);

        canvas = G_vmlCanvasManager.initElement(canvas);	// Do this thing so dynamic setup of the canvas works correctly.
        var ctx = canvas.getContext('2d');				// Get canvas context - SO IMPORTANT!!!

        var centerX = (canvas.width / 2);					// Setup calculations
        var centerY = (canvas.height / 2);
        var radius = (canvas.width / 3);
    } else
    {
        var ctx = new C2S(300, 300);
        var centerX = (150);					// Setup calculations
        var centerY = (150);
        var radius = (100);
    }

    ctx.font = '18px Arial';							// Draw the canvas header.
    ctx.fillStyle = 'black';
    ctx.textAlign = 'center';
    var splitlongheader = countEverything[0].split('\\n');
    ctx.fillText(splitlongheader[0], 150, 15, 250);
    if (splitlongheader[1])
        ctx.fillText(splitlongheader[1], 150, 35, 250);

    var colours = Array('#ef343f', '#f8d707', '#81c341', '#0088cf', 'black');

    var pieStart = 0;
    var labelPosition = 3;
    var previousLabelPosition = 3;

    for (var i = 2; i < countEverything.length; i++)
    {
        if (countEverything[i])
        {
            graphOnClickStatus = (i - 2);
            var pieEnd = pieStart + (((countEverything[i] / countEverything[1]) * 360) * (Math.PI / 180));	// Calculate correct angle in radians.

            // Start drawing pie.
            ctx.beginPath();											// Start drawing! :D
            ctx.moveTo(centerX, centerY);								// Move the start point to the middle.
            ctx.arc(centerX, centerY, radius, pieStart, pieEnd, false, true);// Draw the arc for the pie.
            ctx.lineTo(centerX, centerY);								// Move the point back to the middle otherwise the ctx.fill breaks.
            ctx.closePath();											// Stop drawing. :(
            ctx.fillStyle = colours[(i - 2)];								// Setup colour and fill.
            ctx.fill();
            // Stop drawing pie.

            // Start drawing labels.
            ctx.save();						// Save the rotation & translation from the current context.

            ctx.font = '14px Arial';			// Setup label style.
            ctx.fillStyle = 'white';
            ctx.textAlign = 'center';

            ctx.translate(centerX, centerY);	// Move the context to the center of the canvas.
            ctx.rotate(pieEnd);				// Rotate by how much this chunk of pie has gone around.

            if ((pieEnd - pieStart) < Math.PI * 0.2)
            {
                ctx.fillStyle = colours[(i - 2)];
                labelPosition = 1.4;	// This is here so labels don't draw over themselves if the angle isn't big enough.
                if (previousLabelPosition == labelPosition) labelPosition = labelPosition - 0.1; // This is hear to stop the labels that were drawing over themselves
                // from drawing over themselves. This is very confusing, I know.
            }

            if (pieEnd > Math.PI * 0.5 && pieEnd < Math.PI * 1.5)	// If the angle is between 90 and 270 degrees the text will be upside-down.
            {													// This fixes that.
                ctx.translate(centerX / labelPosition, 0);			// Set the center point to where the label will be printed.
                ctx.rotate(Math.PI);							// Rotate it 180 degrees
                ctx.fillText(countEverything[i], 0, 14);			// Print the label (and move it down by the font size)

            } else
                ctx.fillText(countEverything[i], centerX / labelPosition, 0);	// Otherwise just print the thing.


            ctx.restore();					// Restore our old canvas settings so the rest of the pie chart doesn't break.
            // Stop drawing labels.

            pieStart = pieEnd;
            previousLabelPosition = labelPosition;
            labelPosition = 3;
        }
    }
    if (typeof G_vmlCanvasManager === "undefined") //JFM 12_01_16
    {
        var mySerializedSVG = ctx.getSerializedSvg(true);
        var svgdiv = document.createElement('div');
        
        if (graphType == 'revGraphHolder') {
            svgdiv.setAttribute("id", "kpiRPie");
        } else if (graphType == 'actnGraphHolder') {
            svgdiv.setAttribute("id", "kpiAPie");
        }

        svgdiv.setAttribute("width", 300);
        svgdiv.setAttribute("height", 300);
//					svgdiv.style.setAttribute("display","inline");
        graphHolder.appendChild(svgdiv);
        svgdiv.innerHTML = mySerializedSVG;
    }
}

/* #094-Improvement: Measure DR effectiveness */

/*
 * US#91 - Improvement:Extra all design reviews
 * Deselect the Coe and MSN 
 * Version: 4.4
 * Created by: Infosys Limited
 */
 
function selectNoneMsn() { 
   
   document.getElementById('wizardDataSelection').style.display = 'none'; 
   selectBox=document.getElementById('msn');
        for (var i = 0; i < selectBox.options.length; i++) { 
             selectBox.options[i].selected = false; 
        }
      document.getElementById('additm').style.opacity = '0.5';
	  document.getElementById('additm').disabled = true;		
    }

function selectNoneCoe() { 
   
    document.getElementById('wizardDataSelection').style.display = 'none'; 
    selectBox=document.getElementById('coe');
        for (var i = 0; i < selectBox.options.length; i++) { 
             selectBox.options[i].selected = false; 
        } 
		
      document.getElementById('additm').style.opacity = '0.5';
	  document.getElementById('additm').disabled = true;			
    }

/*
 * US#91 - Improvement:Extra all design reviews
 * select the Coe and MSN based on the selected value
 * Version: 4.4
 * Created by: Infosys Limited
 */
 
function kpiWizardSelectMsnChange()
{
	document.getElementById('wizardlevelSelection').style.display = 'none';
		if($('program').value == '' || $('coe').value == ''){
			document.getElementById('additm').style.opacity = '0.5';
			document.getElementById('additm').disabled = true;	
		}
		else{
			document.getElementById('additm').style.opacity = '1';
			document.getElementById('additm').disabled = false;	
		}
}

function kpiWizardSelectCoeChange()
{
	document.getElementById('wizardlevelSelection').style.display = 'none';	
     if($('program').value == '' || $('msn').value == ''){
		document.getElementById('additm').style.opacity = '0.5';
		document.getElementById('additm').disabled = true;	
	}
	else {
      document.getElementById('additm').style.opacity = '1';
	  document.getElementById('additm').disabled = false;	
	}
}

/*
 * Function to clear the global KPI array to remove all the previous selections
*/
function clearKpiTable() {
    kpiTable = [];
}
//End of US#91

/*
 * To check Section is already exist
 * US#114.1 - Update Help Area
 * Created By - Infosys Limited
 * Version: 4.4
 */
function chkExistingSecName(){
    var secName = document.getElementById('sectionName').value;
    
    if(secName == "") {
        document.getElementById("sectionempty").style.display = 'block';
        document.getElementById("applySecChanges").disabled = true;
        document.getElementById("applySecChanges").style.color = "#ccc";
    } else {
        document.getElementById("sectionempty").style.display = 'none';
        
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var returnval = xmlhttp.responseText;
                returnval = returnval.substr(5, 6);

                if (returnval >= 1) {
                    document.getElementById("sectionWarn").style.display = 'block';
                    document.getElementById("applySecChanges").disabled = true;
                    document.getElementById("applySecChanges").style.color = "#ccc";
                } else if (returnval == 0) {
                    document.getElementById("sectionWarn").style.display = 'none';
                    document.getElementById("applySecChanges").disabled = false;
                    document.getElementById("applySecChanges").style.color = "#004f6b";
                }
            }
        };
        xmlhttp.open("GET", "ajax/checkHelpSection.php?sectionName=" + secName, true);
        xmlhttp.send();
    }
}

/* 
 * Function to remove Help Seciton - US#114.1 
 */
function removeSection(sectionId) {
    var retVal = confirm('Are you sure you want to delete the section ? \n\n This will delete all the documents under this section.');
    if (retVal == true) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var returnval = xmlhttp.responseText;
                if (returnval) {
                    closeLastForm();
                    openForm('help','',false,'POST');
                }
            }
        };
        xmlhttp.open("GET", 'ajax/deleteHelpSec.php?section_id=' + sectionId, true);
        xmlhttp.send();
    } 
}

/*
 * To check Section is already exist - US#114.1
 */
function chkExistingDocName(){
    var docName = document.getElementById('docName').value;
    var sectionId = document.getElementById('secName').value;
    
    if(docName == "") {
        document.getElementById("docEmpty").style.display = 'block';
        document.getElementById("uploadDoc").disabled = true;
        document.getElementById("uploadDoc").style.color = "#ccc";
    } else {
        document.getElementById("docEmpty").style.display = 'none';
        
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var returnval = xmlhttp.responseText;
                returnval = returnval.substr(5, 6);

                if (returnval >= 1) {
                    document.getElementById("docWarn").style.display = 'block';
                    document.getElementById("uploadDoc").disabled = true;
                    document.getElementById("uploadDoc").style.color = "#ccc";
                } else if (returnval == 0) {
                    document.getElementById("docWarn").style.display = 'none';
                    document.getElementById("uploadDoc").disabled = false;
                    document.getElementById("uploadDoc").style.color = "#004f6b";
                }
            }
        };
        xmlhttp.open("GET", "ajax/checkHelpSection.php?docName=" + docName+"&sectionId="+sectionId, true);
        xmlhttp.send();
    }    
}

/*
 * To delete the document from help section
 * US#114.1 - Update Help Area
 */
function deleteDoc(btn) {
    var docId =  btn.id;
    
    var retVal = confirm("Do you want to Remove?");
    if (retVal == true) {
        document.getElementById("row_"+docId).style.display = 'none';
        
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var returnval = xmlhttp.responseText;
                returnval = returnval.substr(5, 6);

                if (returnval >= 1) {
                    document.getElementById("deleteHelpdoc").style.display = 'block';
                } else if (returnval == 0) {
                    document.getElementById("deleteHelpdoc").style.display = 'none';
                }
            }
        };
        xmlhttp.open("GET", "ajax/deleteHelpDoc.php?docId=" + docId, true);
        xmlhttp.send();
    }
}

// End of US#114.1

/*
* US#134 - New section inside the Design Review information, to manage robustness assessment.
* Version: V 4.6
* To perform form validation in view assessment page 
* Fixed by: Infosys Limited
*/

function valRobustForm(){
    var inputs = robustSaveResponse.elements;
    var check = false;
    var radios = [];

    for (var i = 0; i < inputs.length; ++i) {
        if (inputs[i].type == 'radio') {
            radios.push(inputs[i]);
        }
    }
    for (var i = 0; i < radios.length; i += 2) {
        if (!(radios[i].checked || radios[i + 1].checked)) {    
            
            check = true; 
        }
    }
    if(check == false) {
        sendAjaxForm('robustSaveResponse','ajax/saveRobustResponse.php','saveRobust','');
        document.getElementById("robustSaveResponse").reset();
        alert("Questions were answered succesfully")
    }
    else {
        alert('Please answer all the questions before submitting');
    }
}

