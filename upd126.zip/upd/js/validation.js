var checkInterval;
var passwordRequired=0;
var ridStartInfo=new Array();
var ridFields=['rid_id','rid_code','ridStatus','ridTitle','ridCrDateY','ridCrDateM','ridCrDateD','rH','ridCmDateY','ridCmDateM','ridCmDateD','rHEmail'];
function checkDate(id){
	return(checkDateItem(id+'D',1,31)==0 || checkDateItem(id+'M',1,12)==0 || checkDateItem(id+'Y',2000,2050)==0)?0:1;
}
function checkDateGroup(startDate,endDate){
	return(convertToDate(endDate)-convertToDate(startDate)>0)?1:0;
}
function checkDateItem(id,minVal,maxVal){
	return($(id).value=='' || isNaN($(id).value) || $(id).value<minVal || $(id).value>maxVal)?0:1;
}
function checkEmail(email){
	return(String($(email).value).search(/^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/)!=-1)?1:0;
}
function checkExistingInput(inputField,formName){
	m='';
	v=1;
	for(var i in inputField){
		//if(v==1){
		if($(inputField[i][1])){ 
			//alert($(inputField[i][1]).value);
			invalidInput=$(inputField[i][1]).value.toLowerCase().split(',');
			//alert(inputField[i][0]);
			if(in_array($(inputField[i][0]).value.toLowerCase(),invalidInput)){
                                if(inputField[i][2] == 'Level 3') {
                                    document.getElementById("btnSaveStructureElement").disabled = true;
                                    document.getElementById("btnSaveStructureElement").style.color = "#808080";
                                }
				m='WARNING! - '+inputField[i][2]+' already exists. Possible duplication. Check that this item does not already exist for this area.<br />'; //JFM 03_06_14 - JFM 28_10_15
				v=0;
			} else {
                            document.getElementById("btnSaveStructureElement").disabled = false;
                            document.getElementById("btnSaveStructureElement").style.color = "#004f6b";
                        }
		}
	}
	
	if($('new_review_type'))
	{
		if($('new_review_type').value.length<1)
		{
			m=m+'You MUST have a review name.<br />';
			v=0;
		}
	}
	
	if($('new_review_type_code'))
	{
		if($('new_review_type_code').value.length<1)
		{
			m=m+'You MUST have a review code.';
			v=0;
		}
	}
	
	if($('review_group_name'))
	{
		if($('review_group_name').value.length<1)
		{
			m=m+'Please enter a value.';
			v=0;
		}
	}
        /***
         * Fix for : Bug-9
         * Version :4.1
         * Fixed by : Infosys Limited
         * Validation for checking the length of supplier filed exists 30 characters*/
        if($('perimeter'))
	{
		if($('perimeter').value.length>30)
		{
			m=m+'Please enter the Supplier name less than 30 characters.<br />';
			v=0;
		}
	}
	
	//displayValidationResult(formName+'_saveResponse','btnSaveStructureElement',m,v);

	displayValidationResult(formName+'_saveResponse','',m,v); //JFM 03_06_14
	
	if(v==1) return true;
	else	 return false;
}
function checkPassword(pwdId,rptPwdId){
	pwd=$(pwdId).value;
	rptPwd=$(rptPwdId).value;
	pwdRegExp=/^(?=.*[A-Za-z])(?=.*[0-9])(?!.*\s).{5,29}$/; //JFM 04_03_14
	if(passwordRequired==0 && pwd=='' && rptPwd=='')return 1;
	else return(String(pwd).search(pwdRegExp)==-1 || String(rptPwd).search(pwdRegExp)==-1 || pwd!=rptPwd)?0:1;
}
function checkUserNameExists(){
	userFound=0;
	completeName=$('surnameUserMainDataForm').value.toLowerCase()+', '+$('nameUserMainDataForm').value.toLowerCase();
	//JFM 19_07_16 if(userListLoaded==0){
	//Added for US #021 - To skip the function call for Supplier field
        var t= document.getElementById("skipLoadUser");
        if(t && t.value== 'skip') {
            //skip the user list for Supplier;
        } else {
            loadUserList();
        }
	// End - US#021
	//}
	for(i in searchName[0]){
		if(searchName[0][i].toLowerCase()==completeName && (!$('permissionUserId') || searchElId[0][i]!=$('permissionUserId').value)){
			return 0;
		}
	}
	return 1;
}
function convertToDate(id){
	var d=new Date();
	d.setDate(parseInt($(id+'D').value,10));
	d.setMonth(parseInt($(id+'M').value,10)-1);
	d.setFullYear(parseInt($(id+'Y').value,10));
	return d;
}
function displayValidationResult(responseDiv,saveButton,m,v){
	u=$(responseDiv);
	u.style.color=(m=='')?'#009900':'#FF0000';
	u.style.visibility=(m=='')?'hidden':'visible';
	u.style.display=(m=='')?'none':'block';
	u.innerHTML=m;
	//JFM 23_09_13 $(saveButton).disabled=(v==0)?true:false;
	if($(saveButton)) $(saveButton).disabled=(v==0)?true:false;	
}
function endNewRid(){
	var d=new Date();
	if(newRidId==0){
		newRidId=(Math.random()*99999)+'-'+d.getTime();
		rsl=$('ridSelect').options.length;
		$('ridSelect').options[$('ridSelect').options.length]=new Option($('ridTitle').value,(newRidId));
		lastRid=rsl;
	}else $('ridSelect').options[$('ridSelect').selectedIndex].text=$('ridTitle').value;
	
	$('ridContainer').innerHTML=$('ridFormContainer').innerHTML;
	hideWindow('ridWindow');
}
function validateAction(){
	v=1;
	m='';
	if($('login').value.length<5){
		m='Invalid Login';
		v=0;
	}else if($('name').value.length<3){
		m='Invalid First Name';
		v=0;
	}else if($('surname').value.length<3){
		m='Invalid Second Name';
		v=0;
	}else if(checkUserNameExists()==0){
		m='User Name already exists';
		v=0;
	}else if(checkEmail('email')==0){
		m='Invalid Email';
		v=0;
	}else if($('password') && (checkPassword('password','rptPassword')==0 || ($('finishingUser').value=='1' && $('password').value==''))){
		m='Invalid Password. It must be equal, between 6 and 30 characters and contain a number and a letter';
		v=0;
	}else if($('allowTracking') && $('allowTracking').checked==false){
		m='You need to accept to be tracked before continue';
		v=0;
	}else{
		m='';
		$('applyUserChanges').disabled=false;
	}
	displayValidationResult('user_saveResponse','applyUserChanges',m,v);
}
function validateForgotPassword(){
	v=1;
	m='';
	if($('login').value.length<5){
		m='Invalid Login';
		v=0;
	}else if(checkEmail('email')==0){
		m='Invalid Email';
		v=0;
	}else{
		m='';
		$('sendNewPassword').disabled=false;
	}
	displayValidationResult('forgotPassword_saveResponse','sendNewPassword',m,v);
}
function validateRid(){
	v=1;
	m='';
	if($('ridTitle').innerHTML.length<5){
		m='Invalid RID Title';
		v=0;
	}else if($('rH').value==''){
		m='Invalid RID Holder';
		v=0;
	}else if($('rHEmail').value==''){
		m='Invalid RID Holder Email';
		v=0;
	}else if(checkDate('ridCrDate')==0){
		m='Invalid Creation Date';
		v=0;
	}else if(checkDate('ridCmDate')==0){
		m='Invalid Completion Date';
		v=0;
	}else if(checkDateGroup('ridCrDate','ridCmDate')==0){
		m='The Completion Date must be after the Creation Date';
		v=0;
	}else{
		m='';
		$('saveRid').disabled=false;
	}
	$('errorMsg').innerHTML=m;
	if(v==0)$('saveRid').disabled=true;
}
function validateReview(){
	v=1;
	m='';
	if($('review_type').value.length<2){
		m='Review Type name too short';
		v=0;
	}else if($('review_type_description').value.length<5){
		m='Review Description too short';
		v=0;
	}else if($('review_type_code').value.length<2){
		m='Code too short';
		v=0;
	}
	displayValidationResult('review_saveResponse','applyReviewChanges',m,v);
}
function validateReviewType(inputId){
	$('btnNewReviewType').disabled=($('existingReviewType').value=='new' && $('newReviewType').value=='')?true:false;
	$('newReviewType').disabled=(ddSelectedValue('existingReviewType')=='new')?false:true;
	$('review_profile_copy_source').disabled=(ddSelectedValue('existingReviewType')=='new')?true:false;
	if(inputId=='existingReviewType')$('copyReviewConfig').checked=false;
	$('copyReviewConfig').disabled=((inputId=='review_profile_copy_source' && $('review_profile_copy_source').value=='') || $('existingReviewType').value=='new')?true:false;
}
function validateRowConfig(){
	v=1;
	m='';
	if(isNaN($('header_frequency').value)){
		m='The Header frequency must be a number';
		v=0;
	}else if(isNaN($('max_results').value)){
		m='The Max Results must be a number';
		v=0;
	}else if($('header_frequency').value==''){
		m='The Header frequency cannot be empty';
		v=0;		
	}else if($('max_results').value==''){
		m='The Max Results cannot be empty';
		v=0;		
	}
	displayValidationResult('rowConfig_saveResponse','applyRowConfigChanges',m,v);
}
function validateUser(){
	if(!$('valid_user_source_new') || $('valid_user_source_new').checked==true){
		v=1;
		m='';
		
		saveButton=($('applyUserChanges'))?'applyUserChanges':'correctInvalidUser';
		responseDiv=($('correct_user_saveResponse'))?'correct_user_saveResponse':'user_saveResponse';

		if($('login') && $('login').value.length<3){
			m='Login must be at least 3 Characters long';
			v=0;
		}else if($('name').value.length<3){
			m='Invalid First Name';
			v=0;
		}else if($('surname').value.length<2){
			m='Invalid Second Name';
			v=0;
		}else if(checkUserNameExists()==0){
			m='User Name already exists';
			v=0;
		}else if(checkEmail('emailUserMainDataForm')==0){
			m='Invalid Email';
			v=0;
		}
		/* JFM 09_04_14
		else if($('password') && (checkPassword('password','rptPassword')==0 || ($('finishingUser').value=='1' && $('password').value==''))){
			m='Invalid Password. It must be equal, between 6 and 30 characters and contain a number and a letter';
			v=0;
		}*/
		else if($('allowTracking') && $('allowTracking').checked==false){
			m='You must accept to be tracked before you can continue.';
			v=0;
		}else{
			m='';
			$(saveButton).disabled=false;
		}
		displayValidationResult(responseDiv,saveButton,m,v);
	}
}

function validateCriteria(name,surname,skipNoFormChangeCheck,forceValidate) //JFM 23_09_13 - JFM 19_07_16
{
	v=1;
	m='';
	saveButton='none';
	responseDiv='createCriteriaSubmitResponse';
	$('inputIDResponse').style.visibility='hidden';
	$('criteriaDescriptionResponse').style.visibility='hidden';
	$('createCriteriaSubmitResponse').style.visibility='hidden';
	$('criteriaNameResponse').style.visibility='hidden';
	$('criteriaUserIDResponse').style.visibility='hidden';
	if($('groupBox')) $('criteriaGroupBoxResponse').style.visibility='hidden';

	
	//Check their is a description.
	if($('criteriaDescription').value.length<1)
	{
		v=0;
		m='You must have a valid description.';	
		displayValidationResult('criteriaDescriptionResponse',saveButton,m,v);
		m='';
	}
	if($('criterionName').value.length<1)
	{
		v=0;
		m='You must have a valid name.';	
		displayValidationResult('criteriaNameResponse',saveButton,m,v);
		m='';
	}
	if($('criteriaUserID').value.length<1)
	{
		v=0;
		m='You must have a valid ID.';	
		displayValidationResult('criteriaUserIDResponse',saveButton,m,v);
		m='';
	}
	if($('groupBox'))
	{
		if($('groupBox').value=="None")
		{
			v=0;
			m='You must select a group for this new criteria.';	
			displayValidationResult('criteriaGroupBoxResponse',saveButton,m,v);
			m='';
		}
	}

	//Check that something has been entered into the validation loop.
	if(forceValidate != 1)
	{
		if($('criteriaValidatorsTable').rows[1].cells[0].getElementsByTagName("input")[0].value.length<1)
		{
			v=0;
			m='You must have at least 1 criteria validator.';	
			displayValidationResult('inputIDResponse',saveButton,m,v);
			m='';
		}
	}
	
	q=0;
	
	//Check that valid users have been entered into the validation loop.
	var numberOfRows=$('criteriaValidatorsTable').rows.length-1;
	for(var y=1; y<=numberOfRows; y++)
	{
		inputID=$('criteriaValidatorsTable').rows[y].cells[0].getElementsByTagName("input")[0];
		found=false;

		//Get the value of each validation loop input.
		if(inputID.value != '')
		{
			userFound=0;
			completeName=inputID.value.toLowerCase();

			loadUserList();
			
			for(i in searchName[0])
			{
				if(searchName[0][i].toLowerCase()==completeName && (!$('permissionUserId') || searchElId[0][i]!=$('permissionUserId').value))
				{
					//Username has been found.
					found=true;
					//Check if it is not the users username.
					if((surname+', '+name).toLowerCase()==searchName[0][i].toLowerCase())
					{
						v=0;
						m='You cannot be a validator for your own criteria.<br />';
					}
					break;
				}
			}
			
			if(!found)
			{
				//Username has not been found. Throw error.
				v=0;
				if(m=='') m='All validators must be valid users. Users not found:<br />- '+inputID.value;
				else if(m=='You cannot be a validator for your own criteria.<br />') m=m+'<br />All validators must be valid users. Users not found:<br />- '+inputID.value;
				else m=m+'<br />- '+inputID.value;
			}
		}
		q++;
	}	
	if(v==0 && m!='') 
	{
		displayValidationResult('inputIDResponse',saveButton,m,v);
		m='';
	}
	
	//Check that the criteria has been changed in some way
	if(skipNoFormChangeCheck!=1) toCompare=getAllElementsOfFormAndStoreInString('criteriaForm',0); //JFM 03_12_13
	else toCompare='';

	if(toCompare==allElementsOfForm['criteriaForm'])
	{
		v=0;
		m='<br />You did not modify any information on this criteria!<br />You must change something to submit it for approval.';
		displayValidationResult('createCriteriaSubmitResponse',saveButton,m,v);
		m='';
	}	

	if(v==0)
	{
		alert('Some fields have not been entered correctly.\nPlease correct and try again.');
		return false;
	}
	else 
	{
		if($('editCriteria').value==1)
		{
			if(confirm('WARNING: You are about to edit criteria ID #'+$('criteriaID').value+
						'.\n\nBefore the criteria modifications are made, it will need to be approved by ALL of the criteria validators you have selected.\n\nAre you sure you wish to continue?')) return true;
			else return false;
		}
		else
		{
			if(confirm('WARNING: You are about to add a new criteria to the database.'+
						'\n\nBefore this new criteria can be used, it will need to be approved by ALL of the criteria validators you have selected.\n\nAre you sure you wish to continue?')) return true;
			else return false;
		}
	}
}

function validateDecision(name,surname)
{
	v=1;
	m='';
	saveButton='none';
	responseDiv='decision_saveResponse';
	$('decisionResponse').style.visibility='hidden';
	$('decisionCommentsResponse').style.visibility='hidden';
	
	found=false;
	var y;
	
	//Check if a decision has been made.
	var numberOfCells=$('decisionTable').rows[1].cells.length-1;
	for(y=1; y<=numberOfCells; y++)
	{
		if($('decisionTable').rows[1].cells[y].getElementsByTagName("input")[0].checked)
		{
			found=true;
			break;
		}
	}
	
	//If a decision HASN'T been made.
	if(!found)
	{
		v=0;
		m='You must make a decision before submitting.';
		displayValidationResult('decisionResponse',saveButton,m,v);
		m='';
	}
	
	//If a decision HAS been made.
	else
	{
		//If the decision is "Forward To..."
		if(y==2)
		{
			//Check that the user has entered a name.
			if($('forwardName').value.length<1)
			{
				v=0;
				m='You must enter a name to forward to.';			
				displayValidationResult('decisionResponse',saveButton,m,v);
				m='';
			}
			
			//Check that the name is a valid user.
			else
			{
				userFound=0;
				completeName=$('forwardName').value.toLowerCase();

				loadUserList();
				found=false;
				
				for(i in searchName[0])
				{
					if(searchName[0][i].toLowerCase()==completeName && (!$('permissionUserId') || searchElId[0][i]!=$('permissionUserId').value))
					{
						//Username has been found.
						found=true;
						
						//Check if it is not the users username.
						if((surname+', '+name).toLowerCase()==searchName[0][i].toLowerCase())
						{
							v=0;
							m='You cannot forward a decision to yourself.';
							displayValidationResult('decisionResponse',saveButton,m,v);
							m='';
							break;
						}
						
						//Check it is not already a person in the validation loop.
						var numberOfNames=$('workflowTable').rows.length-1;
						for(var q=1; q<=numberOfNames; q++)
						{
							if($('workflowTable').rows[q].cells[0].innerHTML.toLowerCase()==completeName)
							{
								v=0;
								m='That person is already in the validation loop.';
								displayValidationResult('decisionResponse',saveButton,m,v);
								m='';
								break;
							}
						}
						break;
					}
				}
				
				if(!found)
				{
					//Username has not been found. Throw error.
					v=0;
					m='Must be forwarded to a valid user. User not found - '+$('forwardName').value;
					displayValidationResult('decisionResponse',saveButton,m,v);
					m='';
				}
			}
		}
		
		//If the decision is "Remove me form the loop" or "Reject"
		else if(y==3 || y==4)
		{
			//Check that the user has entered a comment.
			if($('decisionComments').value.length<1)
			{
				v=0;
				m='You must enter a comment to make this decision.';		
				displayValidationResult('decisionCommentsResponse',saveButton,m,v);
				m='';
			}
		}
	}
	
	if(v==1) return true;
	else	 return false;
	
}


function validateReview(name,surname)
{
	v=1;
	m='';
	saveButton='none';
	responseDiv='createCriteriaSubmitResponse';
	$('reviewValidatorsResponse').style.visibility='hidden';
		
	//Check that something has been entered into the validation loop.
	if($('reviewValidatorsTable').rows[1].cells[0].getElementsByTagName("input")[0].value.length<1)
	{
		v=0;
		m='<br />You must have at least 1 criteria validator.';	
		displayValidationResult('reviewValidatorsResponse',saveButton,m,v);
		m='';
	}
	
	q=0;
	
	//Check that valid users have been entered into the validation loop.
	var numberOfRows=$('reviewValidatorsTable').rows.length-1;
	for(var y=1; y<=numberOfRows; y++)
	{
		inputID=$('reviewValidatorsTable').rows[y].cells[0].getElementsByTagName("input")[0];
		found=false;

		//Get the value of each validation loop input.
		if(inputID.value != '')
		{
			userFound=0;
			completeName=inputID.value.toLowerCase();

			loadUserList();
			
			for(i in searchName[0])
			{
				if(searchName[0][i].toLowerCase()==completeName && (!$('permissionUserId') || searchElId[0][i]!=$('permissionUserId').value))
				{
					//Username has been found.
					found=true;
					//Check if it is not the users username.
					if((surname+', '+name).toLowerCase()==searchName[0][i].toLowerCase())
					{
						v=0;
						m='<br />You cannot be a validator for your own review.';
					}
					break;
				}
			}
			
			if(!found)
			{
				//Username has not been found. Throw error.
				v=0;
				if(m=='') m='<br />All validators must be valid users. Users not found:<br />- '+inputID.value;
				else if(m=='<br />You cannot be a validator for your own review.') m=m+'<br />All validators must be valid users. Users not found:<br />- '+inputID.value;
				else m=m+'<br />- '+inputID.value;
			}
		}
		q++;
	}	
	if(v==0 && m!='') 
	{
		displayValidationResult('reviewValidatorsResponse',saveButton,m,v);
		m='';
	}
	
	if(v==1) return true;
	else	 return false;
}


function validateReviewDefinition()
{
	v=1;
	m='';
	saveButton='none';
	responseDiv='createCriteriaSubmitResponse';
	$('defineReview_saveResponse').style.visibility='hidden';
	var isChecked=new Array();
	isChecked[0]=0;
	isChecked[1]=0;
	isChecked[2]=0;
	
	if($('defineReviewRadioMaster'))
	{
		if($('defineReviewRadioMaster').checked)
		{
			isChecked[0]=1;
		}
		
	}
	
	if($('defineReviewRadioReview'))
	{
		if($('defineReviewRadioReview').checked)
		{
			isChecked[1]=1;
			/*
 * Showing message for user should select level 1,2 and 3 dropdown
 * US#018-Create Design Review From Review
 * Version:4.3  
 * fixed by Infosys Limited
 */
 	var level3 = document.getElementById('caInfoBox').value;
	var level2 = document.getElementById('caInfoBox2').value;
	var level1 = document.getElementById('caInfoBox1').value;
	if (level1 == '')
	{
		v=0;
		m='<br />Please select a level 1.';
	}
	else if (level2 == '')
	{
		v=0;
		m='<br />Please select a level 2.';
	}
	else if (level3 == '')
	{
		v=0;
		m='<br />Please select a level 3 - CA.';
	}
// End of  US#018-Create Design Review From Review
		}
		
	}
	
	if($('defineReviewRadioBlank'))
	{
		if($('defineReviewRadioBlank').checked)
		{
			isChecked[2]=1;
		}
		
	}
	if($('defineReviewRadioNA'))  //JFM 02_10_14
	{
		if($('defineReviewRadioNA').checked)
		{
			isChecked[3]=1;
		}
		
	}

		
	if(!isChecked[0] && !isChecked[1]  && !isChecked[2] && !isChecked[3])  //JFM 02_10_14
	{
		v=0;
		m='<br />Please select a criterion source.';
	}
/*
 * Showing message for user should select level 1,2 and 3 dropdown
 * US#018-Create Design Review From Review
 * Version:4.3  
 * fixed by Infosys Limited
 */
	else if (level1 == '')
	{
		v=0;
		m='<br />Please select a level 1.';
	}
	else if (level2 == '')
	{
		v=0;
		m='<br />Please select a level 2.';
	}
	else if (level3 == '')
	{
		v=0;
		m='<br />Please select a level 3 - CA.';
	}
// End of  US#018-Create Design Review From Review
	found=false;
	
	var foundCount = 0;

	var numberOfRows=$('defineReviewTableApplicability').getElementsByTagName("input").length;
	for(var y=0; y<numberOfRows; y++)
	{
		if($('defineReviewTableApplicability').rows[y].cells[0].getElementsByTagName("input")[0].checked)
		{
			found=true;
			foundCount++;
		}
	}
	
	if(!found)
	{
		v=0;
		m=m+'<br />Please select at least 1 applicable CA.';
	}

	if(v==0 && m!='') 
	{
		displayValidationResult('defineReview_saveResponse',saveButton,m,v);
		m='';
	}
	
	if(v==1) 
	{
		if(foundCount>1) //JFM 17_08_15
		{
			if(confirm("WARNING!\n\nThis will create a single review for all "+foundCount+" CAs.\n\nIf you wish to hold separate reviews for these CAs, press cancel and define the reviews individually.\n\nAre you sure you wish to continue?"))
				return true;
			else
				return false;
		}
		else
			return true;
	}
	else	 return false;
}

function validateActionRidCreation(startingValidation)
{
	v=1;
	m='';
	saveButton='none';
	responseDiv='action_saveResponse';
	$('action_saveResponse').style.visibility='hidden';
	
	if($('action_holder_name').value.length<1)
	{
		v=0;
		m=m+'You MUST have an action holder.';
	}

	if($('action_validator_name').value.length<1)
	{
		v=0;
		m=m+'<br />You MUST have an action validator.';
	}

	if($('validationCheckYes').checked==true)
	{
		if($('action_description_action_form').value.length<1)
		{
			v=0;
			m=m+'<br />For the validation loop - You MUST have an action description.';
		}

		if(startingValidation==1 && $('action_remark_action_form').value.length<1) //JFM 30_10_14
		{
			v=0;
			m=m+'<br />To start the validation loop - You MUST have an action remark.';
		}
		var tmpArray=["action_holder_name","action_validator_name"];

		for (var q = 0; q < tmpArray.length; q++) 
		{
			var found=false;
			if($(tmpArray[q]).value != '')
			{
				loadUserList();
				
				for(i in searchName[0])
				{
					if(searchName[0][i].toLowerCase()==$(tmpArray[q]).value.toLowerCase())
					{
						//Username has been found.
						found=true;
						break;
					}
				}
				if(!found)
				{
					//Username has not been found. Throw error.
					v=0;
					if(tmpArray[q]=='action_holder_name') m=m+'<br />For the validation loop - The action holder MUST be a registered ART user.';
					else m=m+'<br />For the validation loop - The action validator MUST be a registered ART user.';
				}
			}
		}
	}

	if($('rid')) //JFM 09_04_14
	{
		if($('rid').options[$('rid').selectedIndex].value!=0)
		{
			if($('rid_holder_name').value.length<1)
			{
				v=0;
				m=m+'<br />You MUST have an RID holder.';
			}

			if($('rid_validator_name').value.length<1) //JFM 30_10_14
			{
				v=0;
				m=m+'<br />You MUST have an RID validator.';
			}

			if($('validationCheckYes').checked==true)
			{
				var tmpArray=["rid_holder_name","rid_validator_name"];
				for (var q = 0; q < tmpArray.length; q++) 
				{
					var found=false;
					if($(tmpArray[q]).value != '')
					{
						loadUserList();
						
						for(i in searchName[0])
						{
							if(searchName[0][i].toLowerCase()==$(tmpArray[q]).value.toLowerCase())
							{
								//Username has been found.
								found=true;
								break;
							}
						}
						
						if(!found)
						{
							//Username has not been found. Throw error.
							v=0;
							if(tmpArray[q]=='rid_holder_name') m=m+'<br />For the validation loop - The RID holder MUST be a registered ART user.';
							else m=m+'<br />For the validation loop - The RID validator MUST be a registered ART user.';
						}
					}
				}
			}
		}
	}

	if(v==0 && m!='') 
	{
		displayValidationResult('action_saveResponse',saveButton,m,v);
		m='';
	}
	
	if(v==1) //JFM 27_03_14
	{
		displayValidationResult('action_saveResponse',saveButton,m,v);
		return true;
	}
	else return false;
}

function validateEvidence(checkEvidence)
{
	v=1;
	m='';
	saveButton='none';
	responseDiv='criteriaStatus_saveResponse';
	$('inputIDResponse').style.visibility='hidden';
	$('providerResponse').style.visibility='hidden';
	$('inputIDResponse').innerHTML='';
	$('providerResponse').innerHTML='';
		
	//Check that something has been entered into the validation loop.
	if(typeof $('criteriaValidatorsTable').rows[1]=='undefined')
	{
		v=0;
		m='<br />No stakeholder has been assigned to this criteria!';	
		displayValidationResult('inputIDResponse',saveButton,m,v);
		m='';
	}
	else if($('criteriaValidatorsTable').rows[1].cells[0].getElementsByTagName("input")[0].value.length<1)
	{
		v=0;
		m='<br />You must have at least 1 validator.';	
		displayValidationResult('inputIDResponse',saveButton,m,v);
		m='';
	}
	
	q=0;
	
	//Check that valid users have been entered into the validation loop.
	var numberOfRows=$('criteriaValidatorsTable').rows.length-1;
	for(var y=1; y<=numberOfRows; y++)
	{
		inputID=$('criteriaValidatorsTable').rows[y].cells[0].getElementsByTagName("input")[0];
		found=false;

		//Get the value of each validation loop input.
		if(inputID.value != '')
		{
			userFound=0;
			completeName=inputID.value.toLowerCase();

			loadUserList();
			
			for(i in searchName[0])
			{
				if(searchName[0][i].toLowerCase()==completeName && (!$('permissionUserId') || searchElId[0][i]!=$('permissionUserId').value))
				{
					//Username has been found.
					found=true;
					break;
				}
			}
			
			if(!found)
			{
				//Username has not been found. Throw error.
				v=0;
				if(m=='') m='<br />All validators must be valid users. Users not found:<br />- '+inputID.value;
				else m=m+'<br />- '+inputID.value;
			}
		}
		q++;
	}	
	if(v==0 && m!='') 
	{
		displayValidationResult('inputIDResponse',saveButton,m,v);
		m='';
	}


	//PROVIDERZ
	//-----------------------------------------------------------------------------------------------------------------------------------------


	//Check that something has been entered into the validation loop.
	if($('criteriaprovidersTable').rows[1].cells[0].getElementsByTagName("input")[0].value.length<1)
	{
		v=0;
		m='<br />You must have at least 1 provider.';	
		displayValidationResult('providerResponse',saveButton,m,v);
		m='';
	}
	
	q=0;
	
	//Check that valid users have been entered into the validation loop.
	var numberOfRows=$('criteriaprovidersTable').rows.length-1;
	for(var y=1; y<=numberOfRows; y++)
	{
		inputID=$('criteriaprovidersTable').rows[y].cells[0].getElementsByTagName("input")[0];
		found=false;

		//Get the value of each validation loop input.
		if(inputID.value != '')
		{
			userFound=0;
			completeName=inputID.value.toLowerCase();

			loadUserList();
			
			for(i in searchName[0])
			{
				if(searchName[0][i].toLowerCase()==completeName && (!$('permissionUserId') || searchElId[0][i]!=$('permissionUserId').value))
				{
					//Username has been found.
					found=true;
					break;
				}
			}
			
			if(!found)
			{
				//Username has not been found. Throw error.
				v=0;
				if(m=='') m='<br />All validators must be valid users. Users not found:<br />- '+inputID.value;
				else m=m+'<br />- '+inputID.value;
			}
		}
		q++;
	}	
	if(v==0 && m!='') 
	{
		displayValidationResult('providerResponse',saveButton,m,v);
		m='';
	}

	if(checkEvidence && $('criteriaEvidenceTable').rows[1].cells[0].getElementsByTagName("input")[0].value.length<1)
	{
		v=0;
		m='<br />You must have at least 1 evidence link.';	
		displayValidationResult('evidenceResponse',saveButton,m,v);
		m='';
	}
	
	if(v==1)
	{
		if(checkEvidence)
		{
			if(confirm('WARNING!\n\nThis will send the linked evidences for this criteria to the validators listed for approval.\n\nOnce submitted you will be unable to make modifications.\n\nAre you sure you wish to continue?'))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return true;
		}
	}
	else
	{
		return false;
	}
}

function validateForceEditStakeholders()
{
	v=1;
	m='';
	saveButton='none';
	responseDiv='forceEditValidationLoopPerson_saveResponse';
		
	//Check that something has been entered into the validation loop.
	if(typeof $('criteriaValidatorsTable').rows[1]=='undefined')
	{
		v=0;
		m='<br />No stakeholder has been assigned to this criteria!';	
		displayValidationResult('forceEditValidationLoopPerson_saveResponse',saveButton,m,v);
		m='';
	}
	else if($('criteriaValidatorsTable').rows[1].cells[1].getElementsByTagName("input")[0].value.length<1)
	{
		v=0;
		m='<br />You must enter a name!';	
		displayValidationResult('forceEditValidationLoopPerson_saveResponse',saveButton,m,v);
		m='';
	}
	
	q=0;
	
	//Check that valid users have been entered into the validation loop.

	inputID=$('criteriaValidatorsTable').rows[1].cells[1].getElementsByTagName("input")[0];
	found=false;

	//Get the value of each validation loop input.
	if(inputID.value != '')
	{
		userFound=0;
		completeName=inputID.value.toLowerCase();

		loadUserList();
		
		for(i in searchName[0])
		{
			if(searchName[0][i].toLowerCase()==completeName && (!$('permissionUserId') || searchElId[0][i]!=$('permissionUserId').value))
			{
				//Username has been found.
				found=true;
				break;
			}
		}
		
		if(!found)
		{
			//Username has not been found. Throw error.
			v=0;
			if(m=='') m='<br />All validators must be valid users. Users not found:<br />- '+inputID.value;
			else m=m+'<br />- '+inputID.value;
		}
	}
	q++;
	
	if(v==0 && m!='') 
	{
		displayValidationResult('forceEditValidationLoopPerson_saveResponse',saveButton,m,v);
		m='';
	}
	if(v==1)
	{
		return true;
	}
	else
	{
		return false;
	}
}

function checkAreaManagment(areaName)
{
	v=1;
	m='';
	saveButton='none';
	responseDiv='area_saveResponse';

	var tableArray=Array('areaManagementTable_MainTableLeft', 'areaManagementTable_MainTableRight', 'areaManagementTable_CriteriaTable');

	for (var j = 0; j < tableArray.length; j++) 
	{
		var numberOfRows=$(tableArray[j]).rows.length-1;
		for(var y=2; y<=numberOfRows; y++)
		{
			var inputID=$(tableArray[j]).rows[y].cells[2].getElementsByTagName("input")[0];

			var inputIDAsNumber = Number(inputID.value);

			if(inputID.value.length<1)
			{
				v=0;
				m='<br />Position cannot be blank!';	
				displayValidationResult('area_saveResponse',saveButton,m,v);
				m='';
			}
			else if (Math.floor(inputIDAsNumber) != inputIDAsNumber)
			{
				v=0;
				m='<br />Position must be an integer!';	
				displayValidationResult('area_saveResponse',saveButton,m,v);
				m='';
			}

		}
	}

	if(v==1)
	{
		var confirmOk = confirm('This will modify the ' + areaName + ' area for ALL USERS.\n\nAre you sure you wish to continue?');
		if(confirmOk)
			return true;
		else
			return false;
	}
	else
	{
		return false;
	}
}

//JFM 08_06_16
function validateRiskCreation()
{
	v=1;
	m='';
	saveButton='none';
	responseDiv='risk_saveResponse';
	$('risk_saveResponse').style.visibility='hidden';
	
	if($('risk_holder_name').value.length<1)
	{
		v=0;
		m=m+'You MUST have an risk holder.<br />';
	}

	if($('risk_description_risk_form').value.length<1)
	{
		v=0;
		m=m+'You MUST have an risk description.';
	}


	if(v==0 && m!='') 
	{
		displayValidationResult(responseDiv,saveButton,m,v);
		m='';
	}
	
	if(v==1) //JFM 27_03_14
	{
		displayValidationResult(responseDiv,saveButton,m,v);
		return true;
	}
	else return false;
}
