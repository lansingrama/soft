function allowTrack(){
	try {
		if(document.getElementById('confirmTrack').checked==false){
			alert('You must allow to be tracked before continue');
			return 1;
		}
		else return 0;
	} catch(err) {return 0;}
}
function Different_Passwords(){
	if(document.New_User.elements.New_Password.value != document.New_User.elements.New_Password_Repeat.value){
		alert('The password repeated is not the same than the original');
		return 1;
	}
	else return 0;
}
function Incorrect_Email(){
	if(!document.New_User.elements.New_Email.value.indexOf("@")){
		alert('The email introduced is not correct');
		return 1;
	}
	else return 0;
}
function Invalid_Password(Password_Exists){
	var Correct_Password=new RegExp('(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{6,30})$');
	if(Correct_Password.test(document.New_User.elements.New_Password.value)) return 0;
	else if(Password_Exists==1 && document.New_User.elements.New_Password.value=='') return 0;
	else{
		Message='The password inserted is incorrect.\n';
		Message+='Please check you fulfill all requirements:\n';
		Message+='\n';
		Message+='- It must be at least 6 character long\n';
		Message+='- Not longer than 30 characters\n';
		Message+='- Must contain a letter\n';
		Message+='- Must contain a number\n';
		Message+='- Cannot contain special characters (like &, $ or %)\n';
		Message+='- Cannot contain spaces\n';
		alert(Message);
		return 1;
	}
}
function Password_Needed(Password_Exists){
	if(Password_Exists==0 && document.New_User.elements.New_Password.value==''){
		alert('A new password is needed');
		return 1;
	}
	else return 0;
}
function Validate_User(Password_Exists){
	var Result=0;
	Result=Password_Needed(Password_Exists);
	if(Result==0) Result=allowTrack();
	if(Result==0) Result=Invalid_Password(Password_Exists);
	if(Result==0) Result=Different_Passwords();
	if(Result==0) Result=Incorrect_Email();
	if(Result==0) document.New_User.submit()
}