function $(id){return document.getElementById(id)}
function uploadCaWpImgOK(fileName,w,h){
	var img=parent.$('caWpImg');
	img.style.display='block';
	img.src=fileName;
	img.width=w;
	img.height=h;
	if(parent.$('inf'))parent.$('inf').style.display='none';
}
function uploadCaWpImgKO(){
	alert('There has been an error uploading the image. Please try again.');
}
