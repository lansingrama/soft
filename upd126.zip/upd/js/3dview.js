function applyNewColors (value, timestamp) 
{
	trailingEdgeColor[0] = trailingEdgeArray[0]; 
	trailingEdgeColor[1] = trailingEdgeArray[1]; 
	trailingEdgeColor[2] = trailingEdgeArray[2]; 

	midboxColor[0] = midboxArray[0]; 
	midboxColor[1] = midboxArray[1]; 
	midboxColor[2] = midboxArray[2]; 

	leadingEdgeColor[0] = leadingEdgeArray[0]; 
	leadingEdgeColor[1] = leadingEdgeArray[1]; 
	leadingEdgeColor[2] = leadingEdgeArray[2]; 

}
function trailingEdgeTouched (value, timestamp) 
{
	if(value) print ('\n trailingEdgeTouched!'); 
}
function boxTouched (value, timestamp) 
{
	if(value) print ('\n boxTouched!'); 
}
function leadingEdgeTouched (value, timestamp) 
{ 
	if(value) print ('\n leadingEdgeTouched!'); 
}