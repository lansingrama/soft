var reloadTime='';
function $(id){return document.getElementById(id)}
function normalBodyLoad(){
	if($('usrName'))$('usrName').focus();
}
function setBlockingTime(totalTime){
	var d=new Date();
	reloadTime=(d.getTime()/1000)+totalTime;
	setInterval('updateBlockingTime()',1000);
}
function updateBlockingTime(){
	var d=new Date();
	actualTime=(d.getTime()/1000);
	
	timeLeft=reloadTime-actualTime;
	minutesLeft=Math.floor(timeLeft/60);
	secondsLeft=Math.floor(timeLeft-(minutesLeft*60));
	
	if(minutesLeft<10)minutesLeft='0'+minutesLeft;
	if(secondsLeft<10)secondsLeft='0'+secondsLeft;
	if(timeLeft>0)
		$('blockingTime').innerHTML=minutesLeft+':'+secondsLeft;
	else{
		window.location.href='index.php';
	}
}
