var actualSuggestFocus=20;
var contDiv='';
var txtField='';
var emailField='';
var lastFocused='';
var lastSuggestElement=0;
var suggestList=new Array();
var suggestUserId=new Array();
var txtModified=0;
var txtPosArr=new Array();
var userCount=0;
var userIdField;
var usrList=new Array();
var foundTxtIn='<span style="color:#FF0000"><b>';
var foundTxtOut='</b></span>';

function clickSuggList(t,i){
	if(t.innerHTML!='' && t.innerHTML!='No results found')hideSuggest();
}
function focusOff(t){
	if(t){
		t.style.backgroundColor='#FFFFFF';
		t.style.color='#000000';
	}
}
function focusOn(t,i){
	t.style.backgroundColor='#C3CDDC';
	t.style.color='#000000';
	s=suggestList[i];
	if(s!='' && s!='No results found'){
		$(txtField).value=s;
	}
}
function getUsrEmail(usr){
	if(usr=='' && $(emailField))$(emailField).value='';
	else ajaxRequest('ajax/usrEmail.php?u='+usr,'usrEmail',true);
}
function hideSuggest(){
	if($(contDiv).style.display!='none'){
		if(txtModified==1 && $(emailField))getUsrEmail($(txtField).value);
		focusOff($('se'+actualSuggestFocus));
		if($(userIdField))
		{
			if(typeof suggestUserId[actualSuggestFocus]!='undefined') $(userIdField).value=suggestUserId[actualSuggestFocus]; //JFM 30_10_14
			else
			{
				for(i in searchName[0])
				{
					if(searchName[0][i].toLowerCase()==$(txtField).value.toLowerCase())
					{
						$(userIdField).value=searchElId[0][i];
						break;
					}
					else $(userIdField).value='undefined';
				}
			}
		}
		actualSuggestFocus=20;
		lastSuggestElement=0;
		$(contDiv).style.display='none';
	}
}
function loadUserSuggestion(t,c,txt,e,id,v){ //JFM 23_09_13
	txtModified=0;
	if(lastFocused!=c){
		loadNeeded=1;
		if($(contDiv) && $(contDiv).innerHTML!=undefined && $(contDiv).innerHTML!=''){
			$(c).innerHTML=$(contDiv).innerHTML;
			$(contDiv).innerHTML='';
		}else loadNeeded=1;
		t.onkeyup=function(){suggest(t.value)};
		//t.onkeypress=function(){return avoidSendForm(event)};
		contDiv=c;
		txtField=txt;
		emailField=e;
		lastFocused=c;
		userIdField=id;
		if(loadNeeded==1){
			loadUserList('',1,v);
		}
	}
}

/*
 * Function to load Supplier List in User management
 * Fix for: US#021-Siglum/Company Name
 * Added By: Infosys Limited
 * @param {Object} t 
 * @param {String} c
 * @param {String} txt 
 * @param {String} e 
 * @param {String} id 
 * @param {String} v 
 * @param {String} value 
 */
function supplierSuggestion(t,c,txt,e,id,v,value){ //JFM 23_09_13
        var it= document.getElementById("skipLoadUser");
        console.log(it);
        if(it) {
            it.value = value;
        }
	txtModified=0;
	if(lastFocused!=c){
		loadNeeded=1;
		if($(contDiv) && $(contDiv).innerHTML!=undefined && $(contDiv).innerHTML!=''){
			$(c).innerHTML=$(contDiv).innerHTML;
			$(contDiv).innerHTML='';
		}else loadNeeded=1;
		t.onkeyup=function(){suggest(t.value)};
		contDiv=c;
		txtField=txt;
		emailField=e;
		lastFocused=c;
		userIdField=id;
		if(loadNeeded==1){
			loadUserList('',1,v);
		}
	}
}

function suggest(text){
	switch(window.event.keyCode){
		case 40:
			suggestListDown();
		break;
		case 38:
			suggestListUp();
		break;
		case 27:
		case 13:
			hideSuggest();
		break;
		default:
			txtModified=1;
			var actualSuggestFocus=20;
			if(text.length>0){
				$(contDiv).style.display='block';
				suggestList.length=0;
				txtPosArr.length=0;
				resCount=0;
				for(i=0;i<userCount;i++){
					if(resCount<20){
						txtPos=searchName[0][i].toUpperCase().indexOf(text.toUpperCase());
						if(txtPos!=-1){
							txtPosArr[resCount]=txtPos;
							suggestList[resCount]=searchName[0][i];
							suggestUserId[resCount]=searchElId[0][i];
							resCount++;
						}
					}
				}
				sLL=suggestList.length;
				for(i=0;i<sLL;i++){
					if($('se'+i)){
						$('se'+i).innerHTML=suggestList[i].substring(0,txtPosArr[i])+foundTxtIn+suggestList[i].substring(txtPosArr[i],txtPosArr[i]+text.length)+foundTxtOut+suggestList[i].substring(txtPosArr[i]+text.length);
					}
					lastSuggestElement=i;
				}
				for(i=sLL;i<20;i++){
					if($('se'+i)){
						$('se'+i).innerHTML='';
					}
				}
				if(resCount==0){
					$('se0').innerHTML='No results found';
				}
			}else hideSuggest();
		break;
	}
}
function suggestListDown(){
	if(actualSuggestFocus==20){
		actualSuggestFocus=-1;
	}else{
		focusOff($('se'+actualSuggestFocus));
	}
	
	actualSuggestFocus=actualSuggestFocus+1;
	
	if(actualSuggestFocus>lastSuggestElement){
		actualSuggestFocus=20;
	}else{
		focusOn($('se'+actualSuggestFocus),actualSuggestFocus);
	}
}
function suggestListUp(){
	if(actualSuggestFocus==20){
		actualSuggestFocus=lastSuggestElement+1;
	}else{
		focusOff($('se'+actualSuggestFocus));
	}
	
	actualSuggestFocus=actualSuggestFocus-1;
	
	if(actualSuggestFocus<0){
		actualSuggestFocus=20;
	}else{
		focusOn($('se'+actualSuggestFocus),actualSuggestFocus);
	}
}
function suggMOv(t,i){
	if(t.innerHTML!='' && t.innerHTML!='No results found'){
		focusOn(t,i);
		actualSuggestFocus=i;
	}
}