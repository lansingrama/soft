function loadImg(){
	var scrollTop=document.body.scrollTop;
    var innerHeight=window.innerHeight;
    //var images=document.getElementsByName("myImage");
 	
	
	var lc=lastCa.value;
	var caArr=new Array();
	var idArr=new Array();
	var caAPos=0;
	alert('Voy a ello! '+lc+' CAs por revisar!');
	for(var i=0;i<lc;i++){
		
		//if()
		cawp=document.getElementById('cawp_'+i).value;
	}

	alert('Hecho!');
    /*for(var i=0;i<images.length;i++){
        var imageHeight=posGet(images[i])[1];
        if(imageHeight>scrollTop&&imageHeight<(scrollTop+innerHeight))images[i].src=images_src[i];
    }*/
	
}
function posGet(Object){
    if('undefined'!=typeof(Object.offsetParent)){
        for(var posX=0,posY=0;Object;Object=Object.offsetParent){
            posX += Object.offsetLeft;
            posY += Object.offsetTop;
        }
        return [posX,posY];
    }else return [Object.x,Object.y];
}
window.onscroll=function(){loadImg();
}