<?php

/*
* US#134 - New section inside the Design Review information, to manage robustness assessment.
* Version: V 4.6
* To display the list of questions in Robustness Assessment page
* Fixed by: Infosys Limited
*/

require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');
$GET=cleanArray($_GET);

$area=getFilter('area','filter',0,$SESSION);
$SESSION['rId']=$GET['reviewId'];
$user = $SESSION['user']['user_id'];
$kp =[];

$question_name= SqlLi('SELECT question_id,question_name from dr_assessment_questions where question_hidden = 0 and area= "'.$area.'"');
$user_response= SqlLi('SELECT question,response from dr_question_response where user = "'.$user.'" and area= "'.$area.'" ');

// foreach($user_response as $ur){
// 	if($ur['response'] != null){
// 		$kp = array_fill_keys($ur['question'],$ur['response'])
// 	}

?>OK|||<div id="roleContainer" class="sideContainer"><?php
?><div class="formHeader"><?php
?><div class="formHeaderInfo">Robustness Assessment</div><?php
?><div class="xDiv" onclick="closeLastForm();">&#9668;◄ Back</div><?php
		?><div class="sp"></div><?php
		?>
		<form action="#" enctype="multipart/form-data" id="robustSaveResponse" name="robustSaveResponse" method="POST" style="display:inline;" onsubmit="return false">
		
	<div class="prompt" style="float:left;width:60%;padding-bottom:10px;z-index:100">
		<div class="save" >
			<input class="stdBtn" id="applyRobustChanges" onClick="valRobustForm();" type="button" value="Apply Changes &#9658;">
			<input class="stdBtn" onClick="document.getElementById('robustSaveResponse').reset();" type="button" value="Cancel &#9658;">
		</div>
	</div>
	
		<div class="elementDetailsContainer">

		<?php
			?><table class="criteriaTable" style="width:100%;" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup">
			<?php if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){
			?><td style="width:5%;"><input class="popUpBtnBlue"onClick="popUpOpt('robust',['new'],'robustElement');"type="button"value="&#8801;"><div class="popUpMenu"id="popUpRobustDiv_new"></div></td>
			<?php } else { ?>
                    <td></td>
                <?php }

					?><td style="width:100%;">Questions</td><?php
				?></tr><?php
				foreach($question_name as $question){
				?><tr class="" style="margin-bottom:1px solid #ccc"><?php
				?><td style="width:5%;" class="paramDef">
				<?php if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)
				{ ?>
					<input class="popUpBtn"onClick="popUpOpt('robust',['<?=$question['question_id'];?>','<?=$question['question_name'];?>','robustElement']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpRobustDiv_<?=$question['question_id']?>"></div>
					<?php } ?>								
					<td style="width:25%;"><?php echo $question['question_name']; ?></br>
					<input type="radio" id = "answerYes_<?php echo $question['question_id']; ?>" name="<?=$question['question_id'];?>" value="yes"> Yes
					<input type="radio" id = "answerNo_<?php echo $question['question_id']; ?>" name="<?=$question['question_id'];?>" value="no"> No<br> </td><?php// }
					?>
					<?php
			?></tr> <?php }	
			?>  <?php
			?></table>
			</form><?php
		?></div><?php
			?><div class="sideDetailsContainer"id="sideRoleManagementContainer"><?php
		?><div class="sideContainerEmpty">Select an Element from the list.</div><?php
	?></div><?php
?></div><?php
?></div>


<?php
storeSession($SESSION);
 ?>