<?php
require_once('../support/header.php');
require_once('../support/localSupport.php');
session_start();
$SESSION=$_SESSION;
$included=1;
/*foreach($SESSION['table']['action']['action'] as $columnName=>&$columnDetails){
	//$SESSION['filter'][$SESSION['object'][$columnName]]=$SESSION['filter'][$SESSION['object'][$columnName]][$SESSION['user_action']['hide']];
	$SESSION['filter'][$SESSION['object'][$columnName]]='';
}*/
/*$tableCacheId=randomString(16);
while($SESSION['table_cache'][$tableCacheId]){
	$tableCacheId=randomString(16);
}*/

$tableCacheId=newTableCacheId($SESSION);

?>OK|||<?php
?><div id="actionListContainer">
	<div class="formStdContainer">
		<div class="xDiv"><img alt="Close this Window" onClick="removeTableCache('<?=$tableCacheId?>');closeLastForm();"src="../common/img/x.png"style="cursor:pointer;"></div><?php
		?><div class="formHeaderInfo"><input class="popUpBtn"onClick="openForm('columnConfig','',false,'GET');openSideElement('action','cfc')"type="button"value="...">Action List</div><?php
	?></div><?php
	?><div class="sp"></div><?php
	?><div id="nextResultTemp" style="display:none;"></div><?php
		require_once('../ajax/actionList.php');
	?><div class="sp"></div><?php
?></div>