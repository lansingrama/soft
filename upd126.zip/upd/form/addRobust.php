<?php 
/*
* US#134 - New section inside the Design Review information, to manage robustness assessment.
* Version: V 4.7
* To add questions for Robustness Assessment page
* Fixed by: Infosys Limited
*/ 

require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
$POST=cleanArray($_GET);
if(is_numeric($POST['question_id'])){
$selected_question = SqlLi("SELECT question_name FROM dr_assessment_questions WHERE question_id=".$POST['question_id']);
}

?>OK||| <?php

?><div id="edit_robustContainer"><?php

 	?><div class="formHeader"><?php 
		?><div class="formHeaderInfo">Robustness Management</div><?php
		?><div class="xDiv" onclick="closeLastForm();openForm('robustnessAssessment','',false,'GET')">&#9668; Back</div><?php
	?></div>
	
	<div class="locationSideContainer"><?php
	?><div class="prompt"><?php	
	?><form action="#" enctype="multipart/form-data" id="robustInfoForm" name="robustInfoForm" method="post" style="display:inline;" onsubmit="return false";><?php
				?><div class="save" ><?php
				if(is_numeric($POST['question_id']))
				{
				?>
				<span class="saveResponse"id="robust_saveResponse">Changes were applied</span>
				<input class="stdBtn" id="applyRobustChanges" onClick="sendAjaxForm('robustInfoForm','ajax/saveRobustInfo.php','saveRobust','');closeLastForm();openForm('robustnessAssessment','',false,'GET');closeLastForm();openForm('robustnessAssessment','',false,'GET');" type="button" value="Apply Changes &#9658;"><?php
				}
				else {
				?>
				<span class="saveResponse"id="robust_saveResponse">Question added successfully!</span>
				<input class="stdBtn" id="applyRobustChanges" onClick="sendAjaxForm('robustInfoForm','ajax/saveRobustInfo.php','saveRobust','');closeLastForm();openForm('robustnessAssessment','',false,'GET');closeLastForm();openForm('robustnessAssessment','',false,'GET');" type="button" value="Add question &#9658;"><?php
				}
				?><input class="stdBtn"onClick="closeLastForm();openForm('robustnessAssessment','',false,'GET');"type="button"value="Cancel &#9658;"><br/><br/><?php
			?><table class="criteriaTable" style="width:380px;" cellspacing="0" cellpadding="5"><?php
			?><tbody><?php
			?><tr class="tableGroup prmRow"><td></td><td>Question Details</td></tr><?php
			?><tr class="infoRow"><?php
			?><td class="paramDef">Question</td><?php
			foreach($selected_question as $question_name){
			}
			?><td><input type="hidden" name="question_id" id="question_id" value="<?php echo $POST['question_id']?>">
				  <input type="hidden" name="applicability" id="applicability" value="<?php echo $POST['applicability']?>">
				  <?php
					if( $POST['applicability'] == 'edit' OR  $POST['applicability'] == 'new' ){
					?><textarea rows="4" cols="40" class="textareaWhite" id="question"name="question"> <?php  echo htmlspecialchars($question_name['question_name']); ?> </textarea><?php
				    }
				  ?>
			      <?php
				    if( $POST['applicability'] == 'remove'){
					?><textarea rows="4" cols="40" class="textareaWhite" id="question"name="question" readonly> <?php  echo htmlspecialchars($question_name['question_name']); ?> </textarea><?php
					}
				  ?>
			</td></tr><?php
			?></tbody>
			</table>
			<br/><br/>
	
	</form><?php
			?></div><?php
		?></div><?php
?></div>

	
<?php
storeSession($SESSION);

?>