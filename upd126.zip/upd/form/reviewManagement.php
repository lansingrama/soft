<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
/*$startTime=microtime(true);
echo(microtime(true)-$startTime)*1000,' ms to process<br>';*/
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
$program=getFilter('program','filter',0,$SESSION);
$coe=getFilter('coe','filter',0,$SESSION);
$msn=getFilter('msn','filter',0,$SESSION);
$included=1;

?>OK|||<div id="reviewManagementContainer"style="text-align:center;width:960px;"><?php

	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo">Master List Management</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php

	?><div class="sideList"id="reviewList"style="top:50px;"><?php
		include('../ajax/sideReviews.php');
	?></div><?php

	?><div class="sideDetailsContainer"id="reviewConfigContainer"><?php
		?><div class="sideContainerEmpty">Select an Element from the list.</div><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>