<?php
/*
 * File to create a screen to edit Multiple users
 * Fix for: Improvement - Bulk user upload (Suggested by ICT)
 * Created By: Infosys Ltd
 * Version: 4.3
 */

require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
//require_once('../support/form.php');
require_once('../support/editMultipleUsers.php');
require_once('../support/mail.php');

$GET=cleanArray($_GET);
$usersId = $GET['userID'];

$bulkEditUserclick = 'bulkEditUser';

function drawSpecPerm($title,$object,$array,$right,$SESSION,$oldArray,$areas,$accessAction)
{
	$previousRight=array('area_id' => 'area_id', 'program_id' => 'area_id', 'coe_id' => 'area_id', 'perimeter_id' => 'program_id');
	$idCodes=array('program_id' => 'PRO_', 'coe_id' => 'COE_', 'perimeter_id' => 'PRE_');

	?><tr class="tableGroup prmRow"><?php
		?><td style="width:220px;"><?=$title?></td><td>View</td><td>Edit</td><td>Create</td><td>Delete</td><td>Export</td><td>Upload</td><?php
	?></tr><?php

	$draw=array();
	foreach ($oldArray as $k=>$v) 
	{
            $draw[]=$k;
	}
	$drawn=false;

	foreach($array as $k=>$v)
	{
            foreach ($areas as $key => $value) 
            {
                if($object=='area_id' || (in_array($value[$previousRight[$object]], $draw) && $value[$object]==$k))
                {				
                    $rowsId=($object=='area_id')?'SP_TOP_'.$v:'SP_'.$idCodes[$object].substr($v, 0, strpos($v, ' -'));
                    drawPermissionsBulkUsers($v,$object,$k,1,1,0,0,1,0,$right,$SESSION,'','',$rowsId,$accessAction);
                    $drawn=true;
                    break;
                }
            }

            if(!$drawn) drawPermissionsBulkUsers($v,$object,$k,1,1,0,0,1,0,$right,$SESSION,'',1,'SP_'.$idCodes[$object].substr($v, 0, strpos($v, ' -'),$accessAction));
            $drawn=false;
	}
}

$area=SqlAsArr('SELECT area_id,area FROM c_area','area_id','area');

// Added program_id & coe_hidden flag to check if the review is active - US#110
$program=SqlAsArr('SELECT CONCAT(a.area," - ",pro.program) as a_pro, program_id 
					FROM c_program AS pro
						INNER JOIN c_area AS a ON a.area_id=pro.area WHERE pro.program_hidden=0','program_id','a_pro');

$coe=SqlAsArr('SELECT CONCAT(a.area," - ",coe.coe) as a_coe, coe_id 
				FROM c_coe AS coe
					INNER JOIN c_area AS a ON a.area_id=coe.area WHERE coe.coe_hidden=0','coe_id','a_coe');

$perimeter=SqlAsArr('SELECT CONCAT(a.area," - ",prg.program," - ",prm.perimeter) as prg_prm,prm.perimeter_id
						FROM c_perimeter AS prm
							INNER JOIN c_program AS prg ON prm.program=prg.program_id
							INNER JOIN c_area AS a ON a.area_id=prg.area','perimeter_id','prg_prm');

$areas=SqlLi('SELECT DISTINCT a.area_id, pro.program_id, coe.coe_id, pr.perimeter_id
				FROM c_area AS a
				INNER JOIN c_program AS pro ON pro.area=a.area_id
				INNER JOIN c_coe AS coe ON coe.area=a.area_id
				INNER JOIN c_perimeter AS pr ON pr.program=pro.program_id');

$activePermission=SqlQ('SELECT permission_id FROM c_permission WHERE user="'.$userId.'" AND tool="'.$SESSION['tool_id'].'" AND active=1 LIMIT 1');
$SESSION['edit_user']['active_permission']=($activePermission['permission_id']!='')?1:0;

if($user['confirmed']==1){
	$SESSION['edit_user']['user_invited']=1;
}else{
	$userInvited=SqlQ('SELECT user_invitation_id FROM c_user_invitation WHERE user="'.$userId.'" LIMIT 1');
	$SESSION['edit_user']['user_invited']=($userInvited['user_invitation_id']!='')?1:0;
}

?>OK|||<?php
	?><div class="formHeader"><?php
		?><div class="formHeaderInfo"><?php
			?>Edit Multiple Users Permission<?php
		?></div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php

if((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1) && $SESSION['edit_user']['user_invited']){	
	if($SESSION['edit_user']['user_invited']){
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo"><?php
				?><div class="tableTitle">General Permissions:</div><?php
					?><table class="criteriaTable" style="width:703px;" cellpadding="0" cellspacing="0"><?php
						?><tr class="tableGroup prmRow"style="text-align:center;"><?php
							?><td></td><td>View</td><td>Edit</td><td>Create</td><td>Delete</td><td>Export</td><td>Upload</td><?php
						?></tr><?php
						drawGnInfoPermissions('Tool','c_tool_general',$SESSION['tool_id'],1,0,0,0,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('Area','c_area_general', 0,1,1,1,0,0,0,$right,$SESSION,$users,0,0,$GET['action']);						
						drawGnInfoPermissions('Program','c_program_general',0,1,1,1,0,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('CoE','c_coe_general',0,1,1,1,0,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('Perimeter','c_perimeter_general',0,1,1,1,0,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('MSN','c_msn_general',0,0,1,1,1,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('CA','c_ca_general',0,0,1,1,1,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('Review Profile','dr_review_profile_general',0,1,1,1,1,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('Responsible Configuration','dr_responsible_configuration_general',0,0,1,0,0,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('Log','dr_log_general',0,1,0,0,0,1,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('User','c_user_general',0,1,1,1,0,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('Company','c_company_general',0,1,1,1,1,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('Department','c_department_general',0,1,1,1,1,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('Continuous Assessment','continuous_assessment',0,0,0,1,0,0,0,$right,$SESSION,$users,0,0,$GET['action']);
						drawGnInfoPermissions('Force Review Validation','force_validation',0,0,0,1,0,0,0,$right,$SESSION,$users,0,0,$GET['action']); //JFM 12_01_16
					?></table><?php
					?></br></br><?php                                        
                                        ?><input class="stdBtn" id="applyUserChanges" name="applychanges" onclick="saveEditUserPermissionChanges('<?=$bulkEditUserclick?>','<?=$usersId?>','<?=$GET['action']?>','user_saveResponse','generalInfo')" type="button" value="Apply Changes ►" /><?php                                        
					?><input class="stdBtn" id="getLdapInfo" onClick="clearCheckbox('generalInfo');closeMenu('<?=$windowId?>');" type="button" value="Clear All &#9658;"><br></br><?php
                                        ?><span class="saveResponseBkEdit" id="bulkUsersGenSpan" style="display:none;color:green;">Changes were applied</span><?php
                                        
			?></div><?php
		?></div><?php
		
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo">
				<div class="tableTitle">Specific Permissions:</div>
					<table class="criteriaTable" id="specificPermissionsTable" style="width:703px;" cellpadding="0" cellspacing="0"><?php //JFM 16_01_15
						drawSpecPerm('Area','area_id',$area,$right,$SESSION,$area,$areas,$GET['action']);
						drawSpecPerm('Program','program_id',$program,$right,$SESSION,$area,$areas,$GET['action']);
						drawSpecPerm('CoE','coe_id',$coe,$right,$SESSION,$area,$areas,$GET['action']);
						drawSpecPerm('Perimeter','perimeter_id',$perimeter,$right,$SESSION,$program,$areas,$GET['action']);
					?></table>
                                </br></br><input class="stdBtn" id="applyUserChanges" name="applychanges" onclick="saveEditUserPermissionChanges('<?=$bulkEditUserclick?>','<?=$usersId?>','<?=$GET['action']?>','user_saveResponse','specific')" type="button" value="Apply Changes ►" /><?php
					?><input class="stdBtn" id="getLdapInfo" onClick="clearCheckbox('specific');closeMenu('<?=$windowId?>');" type="button" value="Clear All &#9658;"><?php
                                        ?><span class="saveResponseBkEdit" id="bulkUsersSpecSpan" style="display:none;color:green;">Changes were applied</span><?php
			?></div><?php
		?></div><?php		
	}
}
?>
