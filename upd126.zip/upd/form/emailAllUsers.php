<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');

?>OK|||<div id="changeContainer"style="float:left;text-align:left;width:800px;"><?php
	formTitle('','Email all Users','changeContainer','',$popUpParameter='');
	/*?><div class="sp"></div><?php*/
	?><div class="formStdContainer"><?php
		?><form action="#"enctype="multipart/form-data"id="emailAllUsersFrm"method="post"style="display:inline;"><?php
			?><div class="leftInfoBox"style="margin-top:50px;width:800px;"><?php
				?><table class="criteriaTable"style="width:800px;"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Email Content</td><?php
					?></tr><?php
					drawStdField('Subject','subject','',133);
					?><tr class="infoRow"><?php
						?><td class="paramDef">Description</td><?php
						?><td><textarea class="formInput"cols="135"id="message"name="message"onMouseOver="setInputFocus(this);"rows="7"style="overflow-x:hidden;"></textarea></td><?php
					?></tr><?php
				?></table><?php
				?><div class="save"><?php
					?><input class="stdBtn"onClick="sendAjaxForm('emailAllUsersFrm','ajax/emailAllUsers.php','showMessage','');closeLastForm();"type="button"value="Send"><?php
				?></div><?php
			?></div><?php
		?></form><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>