<?php
//JFM 08_06_16
require_once('../support/header.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

?>OK|||<div id="uploadFileContainer" style="text-align:center;" style="width:380px;"><?php
	formTitle(380,'Upload Review Report','uploadFileContainer');
	?><div class="sp"></div><?php

	?><form action="support/uploadA0ReportPreCheck.php" enctype="multipart/form-data" id="uploadFileFrm" method="post" target="resultIFrame"><?php

		?><input name="type" type="hidden" value="<?=$GET['type']?>"><?php
		?><div class="prompt"><?php
			?><input class="stdBtn" id="uploadedFile" type="file" name="uploadedFile" size="31"> <?php
			//JFM 19_07_16
			?><input class="stdBtn" type="submit" value="Load A0 Export &#9658;" onclick="this.value = ''; $('resultIFrame').style.height = '90%';">&nbsp;<?php
		?></div><?php

	?></form><?php

	?><div id="uploadA0ReportHolder"><?php

	?></div><?php

	?><iframe id="resultIFrame" name="resultIFrame" style="border:none; position:absolute; width:99%; top:120px; height:0%;"></iframe><?php

?></div>