<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET=cleanArray($_GET);

$change=SqlQ('SELECT clt.change_log_type_in
				FROM dr_change AS chg
					INNER JOIN c_change_log_type AS clt ON chg.change_type=clt.change_log_type_id
				WHERE chg.change_id="'.$GET['change_id'].'"');

$screenshot=SqlAsArr('SELECT chs.change_screenshot_id,chs.change_screenshot_creation
						FROM dr_change_screenshot AS chs
						WHERE chs.change="'.$GET['change_id'].'"
						ORDER BY change_screenshot_creation DESC',
						'change_screenshot_id','change_screenshot_creation');

?>OK|||<div id="screenshotContainer"style="text-align:center;width:960px;"><?php

	?><div class="formStdContainer">
		<div class="xDiv"><img alt="Close this Window"onClick="closeLastForm();"src="../common/img/x.png"style="cursor:pointer;"></div><?php
		?><div class="formHeaderInfo">Screenshots for the <?=$change['change_log_type_in']?> #<?=$GET['change_id']?></div><?php
	?></div><?php
	
	?><div class="sideList"id="invalidUserList"><?php
		if(is_array($screenshot)){
			foreach($screenshot as $screenshotId=>$screenshotDate){
				?><div class="sideElement"id="screenshotElement_<?=$screenshotId?>"onClick="openSideElement('<?=$screenshotId?>','scs');"><?=utf8_encode($screenshotDate)?></div><?php
			}
		}
	?></div><?php
	
	?><div class="sideDetailsContainer"id="sideScreenshotContainer"><?php
		?><div class="sideContainerEmpty">Select a Screenshot from the list.</div><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>