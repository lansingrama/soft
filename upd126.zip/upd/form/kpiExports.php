<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET=cleanArray($_GET);

$included=1;

?>OK|||<div id="structureContainer"><?php

	?><div class="formHeader" style="height:100px;"><?php
		?><div id="stepNumber" style="position:absolute; width:100%; text-align: center; top:40px; font-weight:bold;">KPI Export</div><?php
		//<div id="stepDesc" style="position:absolute; width:100%; text-align: center; top:80px;">What would you like to do?</div>
		?>
		<div class="xDiv" onclick="closeLastForm();clearKpiTable();">◄ Exit</div> 
	</div> <?php

	?><div class="sideDetailsContainer"id="structureWizardContainer" style="left:0px; top:125px; background-color:transparent;">
	<?php		

		if($GET['wizard'] == 'kpi')
		{
			require_once("../ajax/kpiReportWizard.php");
		}
		
		else
		{
			?>You don't appear to have permission to do anything on this page. Sorry! :(<?php
		}

	?></div><?php
?></div><?php
?>