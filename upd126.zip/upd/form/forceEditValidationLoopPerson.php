<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET=cleanArray($_GET);

$hideRemove=true;

?>OK|||<?php

?><div class="formHeader"><?php
	?><div class="formHeaderInfo">Edit Stakeholder</div><?php
	?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
?></div><?php


?><div style="margin-top:60px; text-align:left; padding:5px;"><?php 
	?><form action="#" enctype="multipart/form-data" id="forceEditValidationLoopPerson" name="forceEditValidationLoopPerson" method="post"style="display:inline;"><?php
		?><input id="applicability"name="applicability"type="hidden"value="<?=$GET['applicability']?>"><?php
		?><input id="object"name="object"type="hidden"value="<?=$GET['object']?>"><?php
		?><input id="validation_loop_structure_id"name="validation_loop_structure_id"type="hidden" value="<?=$GET['validation_loop_structure_id']?>"><?php
		?><input id="validator"name="validator"type="hidden" value="<?=$GET['validator']?>"><?php

		?><table class="criteriaTable" id="criteriaValidatorsTable" align="left" cellspacing="0"><?php
			?><tr class="tableGroup" width="55px;" ><?php
				?><td colspan="2">Stakeholders</td><?php
			?></tr><?php
			?><tr><?php
				?><td class="paramDef">New Stakeholder Name</td><?php
				?><td><?php
					?><div class="suggestion"id="divID0"style="width:159px;"></div><?php
					?><input class="textareaWhite" id="elephantTigerBeehiveinputID0"name="elephantTigerBeehiveinputID0"  onFocus="loadUserSuggestion(this,'divID0','elephantTigerBeehiveinputID0','','suggestionID0');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
				?></td><?php
			?></tr><?php
			?><tr><?php
				?><td class="paramDef" rowspan="3">Options</td><?php
				?><td><input type="radio" name="forceEditValidationLoopPersonRadio" value="edit">Change Stakeholder</td><?php
			?></tr><?php
			if(!$hideRemove)
			{
				?><tr><?php
					?><td><input type="radio" name="forceEditValidationLoopPersonRadio" value="remove">Remove Stakeholder</td><?php
				?></tr><?php
			}
			?><tr><?php
				?><td><input type="radio" name="forceEditValidationLoopPersonRadio" value="add">Add Stakeholder</td><?php
			?></tr><?php
		?></table><?php

		?><div class="save"><?php
			?><span class="saveResponse"id="forceEditValidationLoopPerson_saveResponse">Changes were applied</span><?php
			?><input class="stdBtn" id="validateDecisionSubmit" onClick="if(validateForceEditStakeholders()){sendAjaxForm('forceEditValidationLoopPerson','ajax/saveForceEditValidationLoopPerson.php','saveRowConfig','');}"type="button"value="Submit &#9658;"><?php
		?></div><?php

	?></form><?php
?></div><?php					

storeSession($SESSION);
?>