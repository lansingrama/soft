<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
$status=array('r','a','g','x'); //JFM 27_03_14
$program=getFilter('program','filter',0,$SESSION);
$validExtension=array('jpg','gif','png','bmp');

if($GET['target']=='wp'){
	$caWp=SqlSLi('SELECT DISTINCT ca
					FROM c_cawp
					WHERE msn="'.getFilter('msn','filter',0,$SESSION).'"
						AND wp IN (
							SELECT wp
							FROM c_cawp
							WHERE msn="'.getFilter('msn','filter',0,$SESSION).'"
								AND ca IN ('.$GET['ca'].')
						)','ca');
	$GET['ca']=implode(',',$caWp);
}

$multipleCa=(stristr($GET['ca'],','))?1:0;

$caMlt=SqlLi('SELECT c.ca_id,c.ca,c.ca_description,c.caa,c.ca_image_file,
					p.perimeter_id,p.perimeter,
					w.wp_id,w.wp,w.wp_description,w.wp_image_file,
					s.assembly,s.assembly_done,s.kodd,s.kodd_done
				FROM c_ca 						AS c
					INNER JOIN	c_perimeter 	AS p 	ON c.perimeter=p.perimeter_id
					INNER JOIN	c_cawp 			AS cw	ON c.ca_id=cw.ca
					INNER JOIN	c_wp 			AS w 	ON cw.wp=w.wp_id
					LEFT JOIN	dr_ca_status	AS s	ON (s.ca=c.ca_id
															AND s.msn="'.getFilter('msn','filter',0,$SESSION).'")
				WHERE c.ca_id IN ('.$GET['ca'].')
					AND cw.msn="'.getFilter('msn','filter',0,$SESSION).'"');



if(is_array($caMlt[0])){
	foreach($caMlt[0] as $k=>&$v){
		$caCombined[$k]=combinedResult($caMlt,$k,$SESSION['table']['review_planning']['ca'][$k]['type'],$SESSION);
	}
	if($caCombined['wp_id']!='m'){
		$caInWp=SqlSLi('SELECT ca FROM c_cawp WHERE msn="'.getFilter('msn','filter',0,$SESSION).'" AND wp="'.$caCombined['wp_id'].'" ORDER BY ca ASC','ca');
		$caArray=explode(',',$GET['ca']);
		sort($caArray);
		$caCount=count($caInWp);
		$uniqueWpSelected=1;
		for($i=0;$i<$caCount;$i++){
			if($caInWp[$i]!=$caArray[$i]){
				$uniqueWpSelected=0;
			}
		}
	}
}

if($uniqueWpSelected==1){
	$target='wp';
	$targetId=$caCombined['wp_id'];
}else{
	$target='ca';
	$targetId=$GET['ca'];
}

foreach($caMlt as &$c){
	$cawp[]=array('ca'=>$c['ca'],'wp'=>$c['wp']);
	$wpMlt[]=$c['wp_id'];
	$caPerimeter[$c['perimeter_id']]=1;
}

$wp=implode(',',array_unique($wpMlt));

$perimeter=SqlAsArr('SELECT perimeter_id,perimeter FROM c_perimeter WHERE program="'.$program.'"','perimeter_id','perimeter');

$editablePerimeter=1;
if(is_array($caPerimeter)){
	foreach($caPerimeter as $k=>$v){
		if(checkPermission('perimeter_id','edit',$k,'check',$SESSION)!=1){
			$editablePerimeter=0;
		}
	}
}

$responsible=getResponsibles($program,$SESSION,1,$GET['ca'],'');

$imagePath='';

if(!$multipleCa || $uniqueWpSelected==1){
	$imageFile=($uniqueWpSelected==1)?$caCombined['wp_image_file']:$caCombined['ca_image_file'];
	if($imagePath=='' && $imageFile!='' && file_exists('../img/'.$target.'/'.$imageFile)){
		$imagePath='img/'.$target.'/'.$imageFile;
	}
	
	
	if($imagePath!=''){
		$imageProperty=getimagesize('../'.$imagePath);
		if($imageProperty[0]>$imageProperty[1])$imageSize='width="350"';
		else $imageSize='height="220"';
	}
}

$editableCa=(checkPermission('program_id','edit',getFilter('program','filter',0,$SESSION),'check',$SESSION)==1 &&
				checkPermission('coe_id','edit',getFilter('coe','filter',0,$SESSION),'check',$SESSION)==1 &&
				$editablePerimeter==1)?1:0;

?>OK|||<div id="reviewReportContainer"style="text-align:center;width:960px;"><?php
	?><div class="formStdContainer"><?php
		?><div class="xDiv"><img alt="Close this Window"onClick="closeLastForm();"src="../common/img/x.png"style="cursor:pointer;"></div><?php
		?><div class="formHeaderInfo"><?=strtoupper($target)?> Information</div><?php
	?></div><?php
	?><div class="sp"></div><?php
	?><div class="formStdContainer"><?php
		?><div class="reviewCaList"><?php
			?><div class="tableTitle">Selected CAs:</div><?php
			?><table class="criteriaTable"style="width:150px;"><?php
				?><tr class="tableGroup"><?php
					?><td>CA</td><?php
					?><td>WP</td><?php
				?></tr><?php
				foreach($cawp as &$cw){
					?><tr class="infoRow"><?php
						?><td><?=$cw['ca']?></td><?php
						?><td><?=$cw['wp']?></td><?php
					?></tr><?php
				}
			?></table><?php
		?></div><?php
		?><div class="leftInfoBox" style="width:790px;"><?php
			?><div class="tableTitle">General Information:</div><?php
			?><form action="#"enctype="multipart/form-data"id="caFrm"method="post"style="display:inline;"><?php
				?><input id="ca"name="ca"type="hidden"value="<?=$GET['ca']?>"><?php
				?><input id="wp"name="wp"type="hidden"value="<?=$wp?>"><?php
				?><table class="criteriaTable" style="width:790px;"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Dates</td><?php
						?><td>Performed</td><?php
						?><td style="width:340px;">Picture</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:127px;">Assemmbly Start</td><?php
						?><td style="width:125px;"><?php drawDate('assembly','assemblyCal',$caCombined['assembly'],false,$editableCa)?></td><?php
						?><td><?php drawRadio('assembly_done',$caCombined['assembly_done'],$editableCa)?></td><?php
						?><td><?php if((!$multipleCa || $uniqueWpSelected==1) && $editableCa==1){?><input class="popUpBtn"id="caPicture"onClick="popUpOpt('cap',['<?=$target?>','<?=$targetId?>']);"type="button"value="..."><div class="popUpMenu"id="popUpCaPic"></div><?php }?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">KODD</td><?php
						?><td><?php drawDate('kodd','koddCal',$caCombined['kodd'],false,$editableCa)?></td><?php
						?><td><?php drawRadio('kodd_done',$caCombined['kodd_done'],$editableCa)?></td><?php
						?><td align="center" rowspan="7" valign="middle"><?php
							$noImgTxt=($multipleCa && $uniqueWpSelected!=1)?'Multiple CAs':'Image Not Found';
							if($imagePath){
								?><img id="caWpImg"<?=$imageSize?>src="<?=$imagePath?>"><div class="inf"id="inf"style="display:none;"><?=$noImgTxt?></div><?php
							}else{
								?><img id="caWpImg"style="display:none;"><div class="inf"id="inf"><?=$noImgTxt?></div><?php
							}
						?></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="3">Other Information</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Perimeter</td><?php
						?><td colspan="2"><?php
							?><select id="perimeter"name="perimeter"<?php if($editableCa!=1){?>readonly<?php }?>><?php
								if($caCombined['perimeter_id']=='m'){?><option selected value="m">Mixed</option><?php }
								foreach($perimeter as $k=>&$v){?><option<?php if($caCombined['perimeter_id']==$k)echo' selected'?> value="<?=$k?>"><?=$v?></option><?php }
							?></select><?php
						?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Conf. &amp; Att. Acc.</td><?php
						?><td colspan="2"><?php
							?><input class="formInput"id="caa"name="caa"onMouseOver="setInputFocus(this);"<?php if($editableCa!=1){?>readonly <?php }?>size="46"type="text"value="<?=$caCombined['caa']?>"><?php
						?></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="3">Notes</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef"style="width:111px;">CA Description</td><?php
						?><td colspan="2"><textarea class="formInput"cols="52"id="ca_description"name="ca_description"onMouseOver="setInputFocus(this);"<?php if($editableCa!=1){?>readonly <?php }?>rows="5"style="overflow-x:hidden;"><?=$caCombined['ca_description']?></textarea></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">WP Description</td><?php
						?><td colspan="2"><textarea class="formInput"cols="52"id="wp_description"name="wp_description"onMouseOver="setInputFocus(this);"<?php if($editableCa!=1){?>readonly <?php }?>rows="4"style="overflow-x:hidden;"><?=$caCombined['wp_description']?></textarea></td><?php
					?></tr><?php
			?></table><?php
				if($editableCa==1){?><div class="save"><span class="saveResponse"id="ca_saveResponse">Changes were applied</span><input class="stdBtn"onClick="sendAjaxForm('caFrm','ajax/saveCa.php','updateData','ca_saveResponse');"type="button"value="Apply Changes"></div><?php }
			?></form><?php
		?></div><?php
	?></div><?php
	?><div class="sp"></div><?php
	?><div class="formStdContainer"><?php
		?><div class="leftInfoBox" style="width:790px;"><?php
			?><div class="tableTitle">Responsibles:</div><?php
			?><form action="#"enctype="multipart/form-data"id="responsibleFrm"method="post"style="display:inline;"><?php
				?><input id="ca"name="ca"type="hidden"value="<?=$GET['ca']?>"><?php				
				?><table class="criteriaTable" style="width:790px;"><?php
					?><tr class="tableGroup"><?php
						?><td>Group</td><?php
						?><td>Role</td><?php
						?><td>Responsible</td><?php
					?></tr><?php
					foreach($responsible['group'] as $groupPosition=>&$group){
						?><tr class="infoRow"><?php
							?><td class="paramDef" rowspan="<?=$responsible['group_count'][$groupPosition]?>" style="width:93px;"><?=$group?></td><?php
							$repeatedGroup=0;
							foreach($responsible['role'][$groupPosition] as $rolePosition=>&$role){
								if($repeatedGroup==1){
									?></tr><tr class="infoRow"><?php
								}else $repeatedGroup=1;
								?><td class="paramDef" style="width:175px;"><?=$role?></td><?php
								?><td><?php
									?><input class="formInput"id="responsible_<?=$groupPosition?>_<?=$rolePosition?>"name="responsible_<?=$groupPosition?>_<?=$rolePosition?>"onMouseOver="setInputFocus(this);"<?php if($editableCa!=1){?>readonly <?php }?>size="87"type="text"value="<?=$responsible['name'][$groupPosition][$rolePosition]?>"><?php
								?></td><?php
							}
						?></tr><?php
					}
				?></table><?php
				
				if($editableCa==1){?><div class="save"><span class="saveResponse"id="responsible_saveResponse">Changes were applied</span><input class="stdBtn"onClick="sendAjaxForm('responsibleFrm','ajax/saveResponsible.php','updateData','responsible_saveResponse');"type="button"value="Apply Changes"></div><?php }
			?></form><?php
		?></div><?php
	?></div><?php
	?><div class="sp"></div><?php
?></div><?php
storeSession($SESSION);
?>