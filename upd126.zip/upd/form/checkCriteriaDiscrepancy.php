<?php

/*
 * To find out the discripancies between the Master list and Toggled crtieria list for a review
 * US#113 - Managing of new criteria in different criteria lists
 * Version: 4.4
 * Created by: Infosys Limited
 */
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET = cleanArray($_GET);

$reviewProfile = SqlQ('SELECT rp.review_profile_id FROM dr_review_profile as rp JOIN dr_review as re ON rp.review_profile_id = re.review_profile WHERE rp.review_type ="' . $GET['reviewType'] . '"  AND rp.program ="' . $GET['program'] . '"  AND rp.coe=' . $GET['coe']);
$reviewId = SqlQ('SELECT re.review_id FROM `dr_review_applicability` as ra JOIN c_ca as ca ON ra.ca=ca.ca_id JOIN dr_review as re ON ra.review = re.review_id WHERE ca.ca_id = "' . $GET['caId'] . '" AND re.review_profile ="' . $reviewProfile['review_profile_id'] . '"');
$reviewValidDate = SqlQ('SELECT validation_date FROM dr_review WHERE review_id="' . $reviewId['review_id'] . '"');

// Get all the Toggled criteria in Master List
$masterCriteria = SqlLi('SELECT DISTINCT rc.review_criterion_id
				FROM dr_review_criterion_history AS rch 
				INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
				INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
				INNER JOIN dr_review_group_history 	AS rgh 		ON rgh.review_group=rg.group_id
				INNER JOIN dr_review_master			AS rm		ON rc.review_criterion_id=rm.criterion
				INNER JOIN dr_review_master_history	AS rmh		ON rm.review_master_id=rmh.review_master
				INNER JOIN dr_review_profile		AS rp 		ON rp.review_type=rm.review_type
				LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
				LEFT  JOIN c_grams					AS g		ON	rca.applicability=g.grams_id
					AND	rca.object=' . $SESSION['object']['grams_id'] . '
					AND rca.review_criterion_applicability_valid_from != "0000-00-00 00:00:00"
				WHERE rp.review_profile_id=' . $reviewProfile['review_profile_id'] . '
                                    AND rch.criterion_valid_from != "0000-00-00 00:00:00"
                                    AND rgh.review_group_valid_to="0000-00-00 00:00:00"
                                    AND rmh.review_master_valid_to="0000-00-00 00:00:00"
				GROUP BY rch.criterion_validity_id
				ORDER BY rgh.review_group_position ASC,rgh.review_group_description ASC,rch.criterion_position	ASC,criterion_user_id ASC');

$criteriaList = criteriaList($SESSION, $reviewProfile['review_profile_id'], $reviewId['review_id'], 'M');

if (!empty($reviewId)) {
    $criteriaMapped = SqlLi('SELECT criterion AS review_criterion_id FROM dr_review_configuration WHERE review ="' . $reviewId['review_id'] . '"');
}
// To check if the selected DR has been validated
if (!empty($reviewValidDate) && ($reviewValidDate['validation_date'] != "9999-12-31 00:00:00")) {
    $drValidationDate = new DateTime($reviewValidDate['validation_date']);
    foreach ($criteriaMapped as $arr => $criterion) {

        $criterion_validity = SqlQ('SELECT criterion_validity_id FROM `dr_review_criterion_history` WHERE criterion="' . $criterion['review_criterion_id'] . '" AND criterion_valid_to = "0000-00-00 00:00:00"');

        // To check if the Criteria mapped to the selected DR is present in Master list
        if (in_array($criterion, $masterCriteria)) {
            $criterion_valid = SqlQ('SELECT criterion_valid_from FROM dr_review_criterion_history WHERE criterion_validity_id="' . $criterion_validity['criterion_validity_id'] . '"');
            $criteriaValidFrom = new DateTime($criterion_valid['criterion_valid_from']);

            // To check if the criteria is modified after the validation of DR
            if ($criteriaValidFrom > $drValidationDate) {
                $answer = 'criteria_modified';
            }
        } else {
            $answer = 'criteria_modified'; 
        }
    }
    // To check if new criteria has been added to Master list after the review validation date
    foreach ($criteriaList as $key => $criterion) {
        $criterion_toggled = SqlQ('SELECT rmh.review_master_valid_from,rmh.review_master_valid_to FROM dr_review_master AS rm join dr_review_master_history AS rmh
                        ON rm.review_master_id= rmh.review_master
                        WHERE rm.criterion="' . $criterion['criterion'] . '" AND rmh.review_master_valid_to="0000-00-00 00:00:0"');
        $criterion_toggled_date = new DateTime($criterion_toggled['review_master_valid_from']);
        if ($criterion_toggled_date > $drValidationDate) {
            $response = 'criteria_added';
        }
    }
}
echo 'OK|||' . $answer . '&' . $response;
