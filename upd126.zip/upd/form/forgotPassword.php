<?php
require_once('../support/header.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');

?>OK|||<div id="forgotPasswordContainer"style="float:left;width:380px;"><?php
	formTitle(380,'Forgot Password','forgotPasswordContainer');
	?><div class="sp"></div><?php
	?><form action="#"enctype="multipart/form-data"id="forgotPasswordFrm"method="post"style="display:inline;"><?php
		?><div class="prompt"onClick="validateForgotPassword();"onKeyUp="validateForgotPassword();"><?php
			?><table class="criteriaTable" style="width:390px;"><?php
				?><tr class="tableGroup prmRow"><?php
					?><td></td><td>Please, type your information in</td><?php
				?></tr><?php
				drawStdField('Login','login','',55);
				drawStdField('Email','email','',55);
			?></table><?php
		?></div><?php
		?><div class="save"style="width:390px;"><?php
			?><span class="saveResponse"id="forgotPassword_saveResponse">Changes were applied</span><?php
			?><input class="stdBtn"id="sendNewPassword"onClick="sendAjaxForm('forgotPasswordFrm','usr/sendNewPassword.php','forgotPassword','');"type="button"value="Send"> <?php
			?><input class="stdBtn"onClick="closeLastForm();"type="button"value="Cancel"><?php
		?></div><?php
	?></form><?php
?></div>