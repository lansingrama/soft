<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

//JFM 30_10_14 foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);
$GET=cleanArray($_GET);

$allTypesOfValidation=SqlLi('SELECT DISTINCT obj.object_id, obj.object 
							FROM c_object AS obj
								INNER JOIN dr_validation_loop AS vl ON obj.object_id=vl.object');
$included=1;

?>OK|||<div id="columnValidationContainer"style="text-align:center; width:1300;"><?php
	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo">Validation</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="locationSideContainer" style=""><?php
		?><div style="float:left;">Item: </div><?php
		?><div style="float:left;"><?php							
			?><select id="validationType" name="validationType" onChange="sideValidation('findMe')"><?php
				
				foreach($allTypesOfValidation as $oneValidationType)
				{
					if($oneValidationType['object']=='criterion_validity_id') $oneValidationType['object']='Criterion';
					if($oneValidationType['object']=='review_id') $oneValidationType['object']='Review';
					if($oneValidationType['object']=='criteria_status_id') $oneValidationType['object']='Evidence'; //JFM 09_04_14
					if($oneValidationType['object']=='action_id') $oneValidationType['object']='Action'; //JFM 30_10_14
	
					?><option id="validationDropdown" value="<?=$oneValidationType['object_id']?>"<?php		
					if($oneValidationType['object_id']==$GET['object']) echo 'selected="selected"';
					?>><?=$oneValidationType['object']?></option><?php
				}
				
				//JFM 07_04_14
				?><option id="validationDropdown" value="All"<?php		
					if('All'==$GET['object']) echo 'selected="selected"';
					?>>My Ongoing Workflows</option><?php
			?></select><?php
		?></div><?php
	?></div><?php
	
	?><div class="sideList"id="validationList" style="top:100px;"><?php
		include('../ajax/sideValidation.php');
	?></div><?php

	?><div class="sideDetailsContainer"id="sideValidationContainer"><?php
		?><div class="sideContainerEmpty">Select an Element from the list.</div><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>