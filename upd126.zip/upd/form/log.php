<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');
if(!$GET)cleanArray($_GET);
$tableCacheId=newTableCacheId($SESSION);
$included=1;
?>OK|||<div id="logContainer"style="text-align:center;width:960px;"><?php
	formTitle('','Log','logContainer',$tableCacheId,array('log','log','log',$tableCacheId,$GET['source'],$GET['applicability']));
	?><div class="sp"></div><?php

	?><div class="wideFormTable" id="reviewCriteriaList"><?php
		require_once('../ajax/log.php');
	?></div><?php
storeSession($SESSION);
?>