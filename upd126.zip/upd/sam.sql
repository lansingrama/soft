-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2019 at 08:45 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `art`
--

-- --------------------------------------------------------

--
-- Table structure for table `dr_assessment_questions`
--

CREATE TABLE IF NOT EXISTS `dr_assessment_questions` (
  `question_id` int(11) NOT NULL,
  `question_name` longtext NOT NULL,
  `question_hidden` int(10) DEFAULT '0',
  `admin_modifier_id` int(11) DEFAULT '0',
  `area` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dr_assessment_questions`
--

INSERT INTO `dr_assessment_questions` (`question_id`, `question_name`, `question_hidden`, `admin_modifier_id`, `area`) VALUES
(1, 'Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?', 0, 0, 1),
(2, 'How may actions are completed?', 0, 0, 1),
(3, 'How many persons are currently logged in?', 0, 0, 1),
(4, 'How many reviews are currently Pending?', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dr_question_response`
--

CREATE TABLE IF NOT EXISTS `dr_question_response` (
`response_id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `question` int(11) NOT NULL,
  `response` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `review` int(11) NOT NULL,
  `area` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dr_question_response`
--

INSERT INTO `dr_question_response` (`response_id`, `user`, `question`, `response`, `review`, `area`) VALUES
(119, 1485, 1, 'yes', 5430, 1),
(120, 1485, 2, 'yes', 5430, 1),
(121, 1485, 3, 'yes', 5430, 1),
(122, 1485, 4, 'yes', 5430, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dr_assessment_questions`
--
ALTER TABLE `dr_assessment_questions`
 ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `dr_question_response`
--
ALTER TABLE `dr_question_response`
 ADD PRIMARY KEY (`response_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dr_question_response`
--
ALTER TABLE `dr_question_response`
MODIFY `response_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=123;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
