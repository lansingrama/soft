<?php

//margin-right -100px for each step!
?><div class="timeline" id="timeline" style="margin-right:225px;"></div><?php

?><div style="position:absolute; top:0px; left:50%; margin-left:-225px; width:450px;z-index:999;"><?php
	?><img style="padding-right:50px;" src="../common/img/step_1_off.png"><?php
	?><img style="padding-right:50px;" src="../common/img/step_2_off.png"><?php
	?><img style="padding-right:50px;" src="../common/img/step_3_off.png"><?php
	?><img style="padding-right:50px;" src="../common/img/step_4_off.png"><?php
	?><img style="padding-right:00px;" src="../common/img/step_5_off.png"><?php
?></div><?php

?><div style="position:absolute; top:0px; left:50%; margin-left:-225px; width:450px;z-index:999;"><?php
	?><img class="wizardImage" id="wizard_step_0" style="padding-right:50px; display:none; opacity: 0;" src="../common/img/step_1_on.png"><?php
	?><img class="wizardImage" id="wizard_step_1" style="padding-right:50px; display:none; opacity: 0;" src="../common/img/step_2_on.png"><?php
	?><img class="wizardImage" id="wizard_step_2" style="padding-right:50px; display:none; opacity: 0;" src="../common/img/step_3_on.png"><?php
	?><img class="wizardImage" id="wizard_step_3" style="padding-right:50px; display:none; opacity: 0;" src="../common/img/step_4_on.png"><?php
	?><img class="wizardImage" id="wizard_step_4" style="padding-right:00px; display:none; opacity: 0;" src="../common/img/step_5_on.png"><?php
?></div><?php

//Box0
?><div class="box" id="box0" style="position:absolute; top:40%; left:50%; width:700px; margin-left:-350px; font-size:24px; text-align:center;"><?php 
	?>I would like to... <?php
	?><select class="wizardDropDownSelect" id="whatDo" name="whatDo" style="margin-right:30px;" onchange="changeStrLoc('reset',true);"><?php
		?><option value="nothing" disabled="disabled" selected="selected">Select a Value</option><?php
		?><option value="create">create a new...</option><?php
		?><option value="edit">edit an existing...</option><?php
	?></select><?php

	?><select class="wizardDropDownSelect" id="doWhere" name="doWhere"><?php
		?><option value="nothing" disabled="disabled" selected="selected">Select a Value</option><?php
		?><option value="sidebar">sidebar item.</option><?php
		?><option value="perimeter">perimeter.</option><?php
		?><option value="wp">WP.</option><?php
		?><option value="ca">CA.</option><?php
		?><option value="review">review type.</option><?php
	?></select><?php
?></div><?php


//Box1
?><div class="box" id="box1" style="position:absolute; top:15%; left:100%; width:90%; margin-left:350px; font-size:24px; text-align:left; display:none;"><?php 
	$areaList=allowedSimpleObject('area','area',$SESSION,'c_');
	?><table><tr><td><?php

		?><table cellpadding="0" cellspacing="5" style="height: 300px;"><?php
			?><tr><?php
				?><td>Area</td><?php
				?><td><?php
					drawddList('strDdArea',$areaList,'','','changeStrLoc(\'area\',true);checkWizardOptions();',1,'',1,'wizardDropDownSelect');
				?></td><?php
			?></tr><?
			?><tr><?php
				?><td style="padding-left: 20px;">&#8627; Level 1</td><?php
				?><td><?php
					//$programList=allowedSimpleObject('program','program',$SESSION,'c_','area='.getFilter('area','filter',0,$SESSION)); //JFM 03_06_14
					drawddList('strDdProgram',$programList,'','','changeStrLoc(\'program\',true);checkWizardOptions();',0,'',0,'wizardDropDownSelect');
				?></td><?php
			?></tr><?php
			?><tr><?php
				?><td style="padding-left: 40px;">&#8627; Level 2</td><?php
				?><td><?php
					//$coeList=allowedSimpleObject('coe','coe',$SESSION,'c_','area='.getFilter('area','filter',0,$SESSION)); //JFM 03_06_14
					drawddList('strDdCoe',$coeList,'','','changeStrLoc(\'coe\',true);checkWizardOptions();',0,'',0,'wizardDropDownSelect');
				?></td><?php
			?></tr><?php
			?><tr><?php
				?><td style="padding-left: 60px;">&#8627; Level 3</td><?php
				?><td><?php
					//$msnList=allowedSimpleObject('perimeter','perimeter',$SESSION,'c_','program='.getFilter('program','filter',0,$SESSION));
					drawddList('strDdMsn',$msnList,'','','changeStrLoc(\'msn\',true);checkWizardOptions();',0,'',0,'wizardDropDownSelect');
				?></td><?php
			?></tr><?php
			?><tr><?php
				?><td style="padding-left: 80px;">&#8627; Perimeter</td><?php
				?><td><?php
					//$msnList=allowedMsn($SESSION);
					drawddList('strDdPerimeter',$msnList,'','','changeStrLoc(\'perimeter\',true);checkWizardOptions();',0,'',0,'wizardDropDownSelect');
				?></td><?php
			?></tr><?php
		?></table><?php

		?></td><td><?php

		?><table id="wizardPleaseSelect" cellpadding="0" cellspacing="5" style="display: none;"><?php
			?><tr><?php
				?><td style="padding-left: 40px;">Please select:</td><?php
			?></tr><?php
			?><tr><?php
				?><td style="width: 250px; padding-left: 40px;"><div id="wizardOptions" style="height: 280px; overflow: auto;"></div></td><?php
			?></tr><?php
		?></table><?php

	?></td></tr></table><?php
?></div><?php

//Box2
?><div class="box" id="box2" style="position:absolute; top:40%; left:100%; width:700px; margin-left:350px; font-size:24px; text-align:center; display:none;"><?php 
	?>Box 2<?php
?></div><?php

//Box3
?><div class="box" id="box3" style="position:absolute; top:40%; left:100%; width:700px; margin-left:350px; font-size:24px; text-align:center; display:none;"><?php 
	?>Box 3<?php
?></div><?php

//Box4
?><div class="box" id="box4" style="position:absolute; top:40%; left:100%; width:700px; margin-left:350px; font-size:24px; text-align:center; display:none;"><?php 
	?>Processing...<?php
?></div><?php

//Box5
?><div class="box" id="box5" style="position:absolute; top:40%; left:100%; width:700px; margin-left:350px; font-size:24px; text-align:center; display:none;"><?php 
	?>Box 5<?php
?></div><?php

?><div id="buttonHolder" style="position:absolute; bottom:35px; left:50%; margin-left:-130px; width:260px;"><?php
	?><div onclick="wizardStepCalculate(0);" style="background-color:#6f95ab; width:120px; height:50px; text-align:center; color:#FFFFFF; font-size:16px; cursor:pointer; float:left;"><?php
		?><div id="backButton" style="margin-top:15px;">&#9668; Exit</div><?php
	?></div><?php

	?><div  onclick="wizardStepCalculate(1);" style="background-color:#f47922; width:120px; height:50px; text-align:center; color:#FFFFFF; font-size:16px; cursor:pointer; float:right;"><?php
		?><div id="forwardButton" style="margin-top:15px;">Next &#9658;&#9658;</div><?php
	?></div><?php
?></div><?php

?><div class="wizardError" id="wizardError"><?php
	?><div id="wizardErrorDescription" style="text-align:center; font-size:16px; margin-top:5px;"><?php
		?>Problem<?php
	?></div><?php
?></div><?php

?>