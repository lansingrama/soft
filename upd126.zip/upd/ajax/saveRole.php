<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');


$POST=cleanArray($_POST);

 /**
    US #19.1 - Change Workflow
	Bug fix for View/Edit responsible button should be enabled
    Fixed By - Infosys Limited
    Version - 4.3
*/
 if(!empty($POST['reviewCa']) && !empty($POST['reviewProfile']) && $POST['reviewCa'] != "" && $POST['reviewProfile'] != "")
{
	$allArr=SqlLi('SELECT r.*, rr.*
							FROM responsible AS r
							INNER JOIN dr_responsible_role AS rr ON rr.responsible_role_id=r.role
							WHERE r.review='.$POST['reviewProfile'].' AND r.ca='.$POST['reviewCa'].'
							ORDER BY position ASC');
}
else
{ 
	$allArr = getResponsibles($POST['reviewId'],$SESSION);
}
//End of US #19.1
if(!empty($POST['reviewCa']) && !empty($POST['reviewProfile']) && $POST['reviewCa'] != "" && $POST['reviewProfile'] != "")
{

for ($i = 0; $i<count($allArr); $i++) {
   if ($POST['editId'] == $i) {
     $allArr[$i]['responsible'] = $POST['responsibleinputID'];
     $allArr[$i]['responsible_role'] = $POST['roleinputID'];
   }
}

$roleArray=array();
$responsibleArray=array();
		
for ($i = 0; $i<count($allArr); $i++) {
    array_push($roleArray,$allArr[$i]['responsible_role']);
    array_push($responsibleArray,$allArr[$i]['responsible']);
    
}
$allRoles=SqlLi('SELECT * FROM dr_responsible_role');

	SqlLQ('DELETE FROM responsible WHERE review="'.$POST['reviewProfile'].'"');

	for ($i=0; $i < count($responsibleArray); $i++) 
	{ 
		$nameSplit=explode(", ",$responsibleArray[$i]);
		$fullName=$nameSplit[1].' '.$nameSplit[0];
		$fullName=trim($fullName);

		$foundRole=false;
		$foundRoleId;
		
		foreach ($allRoles as $roleAlreadyInDatabase) 
		{
			if($roleAlreadyInDatabase['responsible_role']==$roleArray[$i])
			{
				$foundRole=true;
				$foundRoleId=$roleAlreadyInDatabase['responsible_role_id'];
				break;
			}
		}

		if($foundRole) SqlLQ('INSERT INTO responsible (review,ca, role, responsible, position) VALUES ('.$POST['reviewProfile'].','.$POST['reviewCa'].', '.$foundRoleId.',"'.$fullName.'", '.($i+1).')');
	}	
}
else
{
for ($i = 0; $i<count($allArr); $i++) {
   if ($POST['editId'] == $i) {
     $allArr[$i]['responsible'] = $POST['responsibleinputID'];
     $allArr[$i]['responsible_role'] = $POST['roleinputID'];
   }
}

$roleArray=array();
$responsibleArray=array();
		
for ($i = 0; $i<count($allArr); $i++) {
    array_push($roleArray,$allArr[$i]['responsible_role']);
    array_push($responsibleArray,$allArr[$i]['responsible']);
    
}

$allRoles=SqlLi('SELECT * FROM dr_responsible_role');
SqlLQ('DELETE FROM dr_responsible WHERE review="'.$POST['reviewId'].'"');

	for ($i=0; $i < count($responsibleArray); $i++) 
	{ 
		$nameSplit=explode(", ",$responsibleArray[$i]);
		$fullName=$nameSplit[1].' '.$nameSplit[0];
		$fullName=trim($fullName);

		$foundRole=false;
		$foundRoleId;
		
		foreach ($allRoles as $roleAlreadyInDatabase) 
		{
			if($roleAlreadyInDatabase['responsible_role']==$roleArray[$i])
			{
				$foundRole=true;
				$foundRoleId=$roleAlreadyInDatabase['responsible_role_id'];
				break;
			}
		}

		if($foundRole) SqlLQ('INSERT INTO dr_responsible (review, role, responsible, position) VALUES ('.$POST['reviewId'].', '.$foundRoleId.',"'.$fullName.'", '.($i+1).')');
		else
		{
			SqlLQ('INSERT INTO dr_responsible_role (responsible_role) VALUES ("'.$roleArray[$i].'")');
			$lastInsertId=SqlQ('SELECT LAST_INSERT_ID()');
			SqlLQ('INSERT INTO dr_responsible (review, role, responsible, position) VALUES ('.$POST['reviewId'].', '.$lastInsertId['LAST_INSERT_ID()'].',"'.$fullName.'", '.($i+1).')');
		}
	}
}
echo 'OK|||';
storeSession($SESSION);
?>
