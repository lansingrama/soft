<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);
$delimiter;
if($GET['delimiter']=='semi') 	$delimiter=';';
else	$delimiter=',';
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename='.$GET['file_name'].'.csv');
header("Cache-Control: private");
header("Pragma: private");
$rowEnd='
';

/***
 * Fix for Improvement-2(minor)
 * Criteria upload (Suggested by ICT)
 * Fixed By - Infosys Limited
 * Version - 4.2
 */
if (preg_match("/^cat_list/", $GET['file_name'])) {
    
    if (empty($POST['review_profile'])) {
        $reviewProfile = $SESSION['list_cat']['review_profile'];
        $reviewID = $SESSION['list_cat']['reviewID'];
    } else {
        $reviewProfile = $POST['review_profile'];
        $reviewID = $POST['reviewID'];

        $SESSION['list_cat']['review_profile'] = $reviewProfile;
        $SESSION['list_cat']['reviewID'] = $reviewID;
    }

    if ($reviewID == 'M') {
        $reviewID = '';
        $reviewMa = 1;
        
        // To insert the data to dr_a0_report on click of Export CSV
        $xmlKey=randomString(32);
        $viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
        SqlLQ('INSERT INTO dr_csv_report (review_id,csv_report_creation,xml_lock,user)
            VALUES ('.$reviewProfile.',NOW(),"'.$xmlKey.'",'.$viewAsUserId.')');
        $csvId=SqlQ('SELECT LAST_INSERT_ID()');
        
        $user_CSV[0] = array('Criterion Validity ID', 'Criterion ID', 'Group ID', 'Criterion User ID', 'Name', 'Description', 'Show stopper?', 'Priority', 'Group Name', 'Group Position',
            'References', 'Criterion Valid from', 'Included?', 'Validated?', 'Action(Add/Modify/Delete)');
        
        $rawData = criteriaList($SESSION, $reviewProfile, $reviewID, $reviewMa);

        for ($i = 0; $i < count($rawData); $i++) {            
            $rawData[$i]['criterion_user_id'] = "\t" . $rawData[$i]['criterion_user_id'];
            array_push($user_CSV, $rawData[$i]);
        }
        
        // To write the data to CSV file
        $fp = fopen('php://output', 'w');
        foreach ($user_CSV as $line) {
            fputcsv($fp, $line, ';');
        }
        fclose($fp);
        
        createLog('dr_log','csv_report_id','create',$csvId["LAST_INSERT_ID()"],'','',$SESSION);
    }
}

//End of Improvement-2(minor)

$status=array('Red','Amber','Green','Blue'); //JFM 27_03_14

function formatCsvString($type,$value,$disabled,$SESSION)
{
	$status=array('Red','Amber','Green','Blue','No Status');
	$parsedCsvString=str_replace(array('\r','\n','\r\n',chr(10),chr(13),';',',','"','\''),' ',$value); //JFM 15_09_15
	switch($type){
		case 'date':
			if($parsedCsvString!='0000-00-00' && $disabled!=1)
			{
				//JFM 19_07_16
				if(getFilter('dates_cw','filter',0,$SESSION)==1)
					return date("y\C\WW", strtotime($parsedCsvString));
				else
					return $parsedCsvString;
			}
		break;
		case 'status':
			return ($disabled==1)?'N/A':$status[$parsedCsvString];
		break;
		case 'user':
			return ($disabled==1)?'':$parsedCsvString;
		break;
		case 'boolean': //JFM 14_11_13
			if($value==1)	return 'Yes';
			else			return 'No';
		break;
		default:
			return $parsedCsvString;
		break;
	}

}

function writeCsvColumnSection($row,$displayedColumn,&$firstColumn,$delimiter,$SESSION){
	if(is_array($displayedColumn)){
		foreach($displayedColumn as $applicability=>$applGroup){
			foreach($applGroup as $columnName=>$columnDetails){
				writeSemiColon($firstColumn,$delimiter);
				if($applicability!=0){
					if($columnName=='review_status' && $row['review_'.$applicability.'_review_done']==0){
						$row['review_'.$applicability.'_review_status']=3;
					}
					$columnName='review_'.$applicability.'_'.$columnName;
				}
				if($columnDetails['type']=='user'){
					if($row[$columnName.'_txt']==''){
						$columnName=$columnName.'_name';
					}else{
						$columnName=$columnName.'_txt';
					}
				}
				echo formatCsvString($columnDetails['type'],$row[$columnName],$row['element_disabled'],$SESSION);
			}
		}
	}
}

function writeSemiColon(&$firstColumn,$delimiter){
	if($firstColumn==1){
		$firstColumn=0;
	}else{
		echo $delimiter;
	}
}

if(cacheExists($GET['table_cache_id'])){
	if($GET['table']=='log' && $GET['table_section']=='log'){
		require_once('../support/log.php');
		if($GET['source']!='' && $GET['applicability']!=''){
			$logWhereQry='WHERE o.source="'.$_t_[$GET['source']].'" AND l.applicability="'.$GET['applicability'].'"';
		}
		
		$data='';
		$log=retrieveLogData($GET['user'],$GET['source'],$GET['applicability'],$data,'',$SESSION,0);
		
		$csv='Date;Event'.$rowEnd;
		
		if(is_array($log)){
			foreach($log as &$l){
				echo $l['date'],';',str_replace(array('\r','\n','\r\n',chr(10),chr(13),';'),' ',$l['event']),$rowEnd;
			}
		}
	}elseif($GET['table']=='review_planning'){
		$firstColumn=1;
		unset($column,$columnDetails);
		foreach($SESSION['table']['review_planning']['ca'] as $column=>$columnDetails){
			if(getFilter($column,'hide',0,$SESSION)!=1){
				writeSemiColon($firstColumn,$delimiter);
				echo $columnDetails['title'];
				$displayedCaColumn[0][$column]=$columnDetails;
			}
		}
		
		$responsible=getResponsibles(getFilter('program','filter',0,$SESSION),$SESSION,0);
		
		if(!empty($responsible['role'])){
			foreach($responsible['role'] as $groupPosition=>$r){
				foreach($r as $rolePosition=>$roleDetails){
					writeSemiColon($firstColumn,$delimiter);
					echo $roleDetails;
					$displayedResponsibleColumn[0]['dr_responsible_configuration_general_'.$responsible['config'][$groupPosition][$rolePosition]]=$columnDetails;
				}
			}
		}

		$reviewProfileList=allowedReviews($SESSION,'view','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION));

		if(!empty($reviewProfileList)){
			
			foreach($reviewProfileList as $reviewId=>$reviewTypeId){
				foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails){
					if(getFilter($columnName,'hide',$reviewId,$SESSION)!=1){
						writeSemiColon($firstColumn,$delimiter);
						echo $SESSION['review_type'][$reviewId],' ',$columnDetails['title'];
						$displayedReviewColumn[$reviewId][$columnName]=$columnDetails;
					}
				}
			}
		}
		
		echo $rowEnd;
		
		$cache=loadCache('csv',$GET['table_cache_id']);
		foreach($cache as $rowId=>$row){
			$firstColumn=1;
			writeCsvColumnSection($row,$displayedCaColumn,$firstColumn,$delimiter,$SESSION);
			writeCsvColumnSection($row,$displayedResponsibleColumn,$firstColumn,$delimiter,$SESSION);
			writeCsvColumnSection($row,$displayedReviewColumn,$firstColumn,$delimiter,$SESSION);
			echo $rowEnd;
		}
	}

	else if ($GET['table']=='evd') //JFM 28_04_14
	{

		$tableStructure=$SESSION['table']['evd']['evd'];

		$tableCache=loadCache('csv',$GET['table_cache_id']);

		$allCAsArray=explode(',', $GET['applicability']);

		foreach ($allCAsArray as $oneCA) 
		{
			$tableStructure['ca_evidence_info_'.$oneCA]=array('table' => 'none', 'table_short_name' => 'n', 'type' => 'text', 'title' => $oneCA, 'filter' => 'evidence_ca_table_header', 'applicability_needed' => 1 );

			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['criteria_status_'.$oneCA]	=$tableStructure['criteria_status'];
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['provider_'.$oneCA]			=$tableStructure['provider'];
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['stakeholder_'.$oneCA]		=$tableStructure['stakeholder'];
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['planned_evd_'.$oneCA]		=$tableStructure['planned_evd'];
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['supplied_'.$oneCA]			=$tableStructure['supplied'];
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['file_link_'.$oneCA]			=$tableStructure['file_link'];
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['action_taken_on_'.$oneCA]	=$tableStructure['action_taken_on'];
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['validator_'.$oneCA]			=$tableStructure['validator'];

			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['criteria_status_'.$oneCA]['fakeColumnHeader']	='criteria_status_'.$oneCA;
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['provider_'.$oneCA]['fakeColumnHeader']			='provider_'.$oneCA;
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['stakeholder_'.$oneCA]['fakeColumnHeader']		='stakeholder_'.$oneCA;
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['planned_evd_'.$oneCA]['fakeColumnHeader']		='planned_evd_'.$oneCA;
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['supplied_'.$oneCA]['fakeColumnHeader']			='supplied_'.$oneCA;
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['file_link_'.$oneCA]['fakeColumnHeader']			='file_link_'.$oneCA;
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['action_taken_on_'.$oneCA]['fakeColumnHeader']	='action_taken_on_'.$oneCA;
			$tableStructure['ca_evidence_info_'.$oneCA]['extras']['validator_'.$oneCA]['fakeColumnHeader']			='validator_'.$oneCA;
		}


		unset($tableStructure['provider']);
		unset($tableStructure['stakeholder']);
		unset($tableStructure['planned_evd']);
		unset($tableStructure['supplied']);
		unset($tableStructure['file_link']);
		unset($tableStructure['action_taken_on']);
		unset($tableStructure['validator']);
		if(count($allCAsArray)<=1) unset($tableStructure['criteria_status']);
		else $tableStructure['criteria_status']['title']='Overall';

		$firstColumn=1;
		foreach($tableStructure as $columnName=>$columnDetails)
		{
			if(getFilter($columnName,'hide',0,$SESSION)!=1)
			{
				if(is_array($columnDetails['extras']))
				{
					foreach($columnDetails['extras'] as $extraColumnName=>$extraColumnDetails)
					{
						writeSemiColon($firstColumn,$delimiter);
						foreach ($tableCache as $z => $x) 
						{
							if(!empty($tableCache[$z][$columnName]))
							{
								echo $tableCache[$z][$columnName];
								break;
							}
						}
					}
				}
				else
				{
					writeSemiColon($firstColumn,$delimiter);
				}
			}
		}

		echo $rowEnd;
		$firstColumn=1;

		foreach($tableStructure as $columnName=>$columnDetails)
		{
			if(getFilter($columnName,'hide',0,$SESSION)!=1)
			{
				if(is_array($columnDetails['extras']))
				{
					foreach($columnDetails['extras'] as $extraColumnName=>$extraColumnDetails)
					{
						writeSemiColon($firstColumn,$delimiter);
						echo $extraColumnDetails['title'];
						$displayedColumn[0][$extraColumnName]=$extraColumnDetails;
					}
				}
				else
				{
					writeSemiColon($firstColumn,$delimiter);
					echo $columnDetails['title'];
					$displayedColumn[0][$columnName]=$columnDetails;
				}
			}
		}

		echo $rowEnd;

		foreach($tableCache as $rowId=>$row)
		{
			$firstColumn=1;
                        /*
                         * Fix for: Bug: #71:All CA Evidences CSV export
                         * Fixed By: Infosys Limited
                         * Version: 4.3
                         */
                        $row["criterion_user_id"] = "\t" . $row["criterion_user_id"];
			writeCsvColumnSection($row,$displayedColumn,$firstColumn,$delimiter,$SESSION);
			echo $rowEnd;
		}
	}

	else
	{
		$firstColumn=1;
		foreach($SESSION['table'][$GET['table']][$GET['table_section']] as $columnName=>$columnDetails){
			if(getFilter($columnName,'hide',0,$SESSION)!=1){
				writeSemiColon($firstColumn,$delimiter);
				echo $columnDetails['title'];
				$displayedColumn[0][$columnName]=$columnDetails;
			}
		}
		echo $rowEnd;
		foreach(loadCache('csv',$GET['table_cache_id']) as $rowId=>$row){
			$firstColumn=1;
			writeCsvColumnSection($row,$displayedColumn,$firstColumn,$delimiter,$SESSION);
			echo $rowEnd;
		}
	}
}

storeSession($SESSION);
?>