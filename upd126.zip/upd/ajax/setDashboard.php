<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);

modifyFilter('dashboard','filter',0,$GET['value'],$SESSION,1);


if($GET['mainFilter']) modifyFilter('overall_search','filter',0,$GET['mainFilter'],$SESSION,1);

storeSession($SESSION);
echo 'OK|||';
?>