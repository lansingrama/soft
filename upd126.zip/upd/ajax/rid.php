<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
$ridId=addslashes($_GET['rid']);

if($ridId!=0){
	$rid=SqlQ('	SELECT 
					r.rid_code,r.rid_title,r.rid_status,r.rid_holder,r.rid_holder_name,r.rid_validator,r.rid_validator_name,r.rid_creation,r.rid_completion, r.rid_showstopper, r.rid_action_plan, r.rid_change_note,
					CONCAT(u.surname,", ",u.name) AS rid_holder_txt 
				FROM dr_rid AS r
					LEFT JOIN c_user AS u ON r.rid_holder=u.user_id
				WHERE rid_id="'.addslashes($ridId).'"'); //JFM 30_10_14
	$rid=utf8enc($rid);
	
	if($rid['rid_holder_txt']!='')$rid['rid_holder_name']=$rid['rid_holder_txt'];
}else{
	foreach($SESSION['table']['rid']['rid'] as $k=>&$v){
		$rid[$k]='';
	}
}

if($rid){
	$firstItem=0;
	foreach($SESSION['table']['rid']['rid'] as $k=>&$v){
		if(isset($rid[$k])){
			if($firstItem!=0)$answer.='&&&';
			else $firstItem=1;
			if($v['type']=='user'){
				$answer.=$v['txt_format'].'%%%'.$v['type'].'%%%'.$rid[$v['txt_format']];
			}
			else $answer.=$k.'%%%'.$v['type'].'%%%'.$rid[$k];
			if($v['done']!='')$answer.='###'.$rid[$v['done']];
		}
	}
}
//echo $answer;
echo 'OK|||'.$answer;
storeSession($SESSION);
?>