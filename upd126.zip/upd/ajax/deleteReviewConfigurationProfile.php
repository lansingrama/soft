<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');

$GET=cleanArray($_GET);

//JFM TODO - CRIT
if(checkPermission('dr_review_profile_general','delete',0,'check',$SESSION)==1){
	$reviewProfile=SqlQ('SELECT review_profile FROM dr_review_configuration_profile WHERE review_configuration_profile_id="'.$GET['id'].'"');
	if(in_array($reviewProfile['review_profile'],array_keys(allowedReviews($SESSION,'edit','program='.$GET['program'].' AND coe='.$GET['coe'])))){
		SqlLQ('UPDATE dr_review SET review_configuration_profile=0 WHERE review_configuration_profile="'.$GET['id'].'"');
		SqlLQ('DELETE FROM dr_review_configuration WHERE review_configuration_profile="'.$GET['id'].'"');
		SqlLQ('DELETE FROM dr_review_configuration_profile WHERE review_configuration_profile_id="'.$GET['id'].'"');
		$answer='delete%%%0%%%0%%%'.$reviewProfile['review_profile'];
	}
}
storeSession($SESSION);
?>OK|||<?=$answer?>