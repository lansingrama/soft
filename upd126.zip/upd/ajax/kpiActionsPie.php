<?php

/* 
 * US#96 - Improvement: Measure Action Management Effectiveness
 * To Calculate the number of actions with different statuses
 * Created By: Infosys Limited
 * Version: 4.5
 */
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
	
$POST = cleanArray($_GET);
$kpiArr = json_decode( html_entity_decode( stripslashes ($POST['kpiData'] ) ) );

$area = array();
$program = array();
$coe = array();
$msn = array();

foreach($kpiArr as $kpiDetails) {
    if(!empty($kpiDetails)) {
        array_push($area,$kpiDetails->area);
        array_push($program,$kpiDetails->program);
        array_push($coe,$kpiDetails->coe);
        array_push($msn,$kpiDetails->msn);
    }    
}
$area = implode(',', array_unique($area));
$program = implode(',', $program);
$coe = implode(',', $coe);
$msn = implode(',', $msn);

$programArr = explode(',', $program);
$coeArr = explode(',', $coe);
$msnArr = explode(',', $msn);

// To remove the duplicates in Program, coe and msn
$program = implode(',', array_unique($programArr));
$coe = implode(',', array_unique($coeArr));
$msn = implode(',', array_unique($msnArr));

if ($program && $coe) {
$ca = SqlSLi('SELECT ca_id FROM c_ca 
		WHERE program IN (' . $program . ')
		AND coe IN (' . $coe . ')', 'ca_id');

$ca = implode(',', $ca);

$reviewProfileQry = SqlSLi('SELECT review_profile_id FROM dr_review_profile 
                WHERE program IN (' . $program . ')
                AND coe IN (' . $coe . ') AND rp_hidden=0', 'review_profile_id');

$reviewProfile = implode(',', $reviewProfileQry);
}

$specificFilter = array();

if ($msn) {
	$specificFilter[] = 'r.msn IN(' . $msn . ')';
}

if ($ca) {
	$specificFilter[] = 'ra.ca IN('. $ca .')';
}

if ($reviewProfile) {
	$specificFilter[] = 'r.review_profile IN(' . $reviewProfile . ')';
}
if (!empty($POST['from'])) {
    $specificFilter[] = 'r.planned >= "' . $POST['from'] . '"';
}
if (!empty($POST['to'])) {
    $specificFilter[] = 'r.planned <= "' . $POST['to'] . '"';
}
if(count($specificFilter)>0){
	$qryFilter = '  WHERE '.implode(' AND ',$specificFilter);
}

$filter = array();
if ($msn) {
	$filter[] = 'rs.msn IN(' . $msn . ')';
}
if ($ca) {
    $filter[] = 'rs.ca IN(' . $ca . ')';
}
if ($reviewProfile) {
	$filter[] = 'rs.review_profile IN(' . $reviewProfile . ')';
}
if (!empty($POST['from'])) {
    $filter[] = 'rs.planned >= "' . $POST['from'] . '"';
}
if (!empty($POST['to'])) {
    $filter[] = 'rs.planned <= "' . $POST['to'] . '"';
}
if (count($specificFilter) > 0) {
    $pfilter = '  WHERE ' . implode(' AND ', $filter);
}

// Query to select all the DRs for the selected Area and Levels
$review = SqlLi('SELECT msn.msn,ca.ca,ca.ca_description,pro.program,coe.coe,area.area,per.perimeter,wp.wp,wp.wp_description,
    r.review_id, r.planned,r.review_date, r.review_done,r.delta_planned,r.delta,r.delta_done,r.review_status,r.validation_complete,r.validation_date, r.continuous_assessment,r.initial_review_status,rt.review_type
            FROM dr_review AS r 
                    INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id 
                    INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
                    INNER JOIN dr_review_type AS rt ON rp.review_type=rt.review_type_id
                    INNER JOIN c_ca as ca ON ra.ca=ca.ca_id
                    INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
                    INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND r.msn=m.msn_id)
                    INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
                    INNER JOIN c_msn as msn ON r.msn=msn.msn_id
                    INNER JOIN c_perimeter AS per ON ca.perimeter=per.perimeter_id
                    INNER JOIN c_program AS pro ON ca.program=pro.program_id
                    INNER JOIN c_coe AS coe ON ca.coe=coe.coe_id
                    INNER JOIN c_area AS area ON coe.area=area.area_id
					'.$qryFilter.'
					AND r.planned > "0000-00-00"');
					
$reviewPlanned = SqlLi('SELECT r.review_id, rs.planned,r.review_date, r.review_done,r.delta_planned,r.delta,r.delta_done,r.review_status,r.validation_complete,r.validation_date, r.continuous_assessment,r.initial_review_status, rt.review_type,msn.msn,ca.ca,ca.ca_description,pro.program,coe.coe,area.area,per.perimeter,wp.wp,wp.wp_description
	FROM dr_review_status as rs LEFT JOIN dr_review as r ON rs.review_profile=r.review_profile 
	INNER JOIN dr_review_profile as rp ON rs.review_profile=rp.review_profile_id
	INNER JOIN dr_review_type AS rt ON rp.review_type=rt.review_type_id
	INNER JOIN c_ca as ca ON rs.ca=ca.ca_id
	INNER JOIN c_cawp AS cw	ON rs.ca=cw.ca
	INNER JOIN c_wp As wp ON cw.wp=wp.wp_id
	INNER JOIN c_msn AS msn ON rs.msn=msn.msn_id
	INNER JOIN c_perimeter as per ON ca.perimeter=per.perimeter_id
	INNER  JOIN c_coe as coe ON ca.coe=coe.coe_id
	INNER JOIN c_program as pro ON ca.program=pro.program_id
	INNER JOIN c_area as area ON pro.area=area.area_id
	'.$pfilter.'
	AND rs.planned > "0000-00-00" AND r.review_id IS NULL
GROUP BY rs.id'); 

foreach($reviewPlanned as $item) {
    array_push($review, $item);
}

if(!empty($review)) {
    $review_id = array();
    foreach($review as $reviewID) {
        if($reviewID['review_id']) {
            array_push($review_id,$reviewID['review_id']);
        }
    }
    $drIds = implode(',', $review_id);
    
    // Action Extract
    $actions = SqlLi('SELECT r.review_id,act.criteria,act.action_id,act.action_code,act.action_description,
        act.action_remark,act.action_creation,act.action_completion,
        act.action_closure,act.action_status,act.action_holder,act.action_holder_name,
        CONCAT(u1.surname,", ",u1.name) as user_holder,act.action_validator,act.action_validator_name,
        CONCAT(u2.surname,", ",u2.name) as user_validator,
        rid.rid_id, rid.rid_code, rid.rid_code,rid.rid_title,rid.rid_status,rid.rid_holder_name,rid.rid_creation,
        rid.rid_completion,rid.rid_closure,rid.rid_showstopper,rid.rid_validator_name
        FROM dr_action AS act
                INNER JOIN dr_action_applicability AS aap ON act.action_id=aap.action
                INNER JOIN dr_review_configuration AS rconf ON rconf.criterion=act.criteria
                INNER JOIN dr_review as r ON r.review_id=rconf.review
                LEFT JOIN dr_rid as rid ON act.rid=rid.rid_id
                INNER JOIN c_user AS u1 ON act.action_holder=u1.user_id
                INNER JOIN c_user AS u2 ON act.action_validator=u2.user_id 
        WHERE act.msn IN ('.$msn.')
            AND aap.ca IN (' . $ca . ')
            AND r.review_profile IN (' . $reviewProfile . ')
            AND r.review_id IN ('.$drIds.')
        GROUP BY act.criteria,act.action_status');
}

if(!empty($actions))
{
	foreach ($actions as $action)
	{
		$involvement='';
		$actionTotal['total']++;

		switch ($action['action_status']) 
		{
			case 0:
				$actionTotal['red']++;
			break;
			case 1:
				$actionTotal['amber']++;
			break;
			case 2:
				$actionTotal['green']++;
			break;
			case 3:
				$actionTotal['blue']++;
			break;
		} 
	}
}

$graphMeArray=Array('Actions Count',$actionTotal['total'],$actionTotal['red'],$actionTotal['amber'],$actionTotal['green'],$actionTotal['blue']);
$answer='&&&my_actions---'.implode(',',$graphMeArray);

echo $answer;