<?php
/*
* US#134 - New section inside the Design Review information, to manage robustness assessment.
* Version: V 4.7
* To save added questions for Robustness Assessment page
* Fixed by: Infosys Limited
*/ 

require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$POST=cleanArray($_POST);
$area=getFilter('area','filter',0,$SESSION);
if(is_numeric($POST['question_id']))
{
   	if (isset($POST['applicability']) && !empty($POST['applicability']) && $POST['applicability']== "edit") 
	{
		SqlLQ('UPDATE dr_assessment_questions SET question_name ="'.$POST['question'].'" ,admin_modifier_id="'.$SESSION['user']['user_id'].'"  WHERE question_id ="'.$POST['question_id'].'"');
	}
	else
	{
		SqlLQ('UPDATE dr_assessment_questions SET question_hidden =1,admin_modifier_id="'.$SESSION['user']['user_id'].'" WHERE question_id ="'.$POST['question_id'].'"');
	}

}
else 
{

	if (isset($POST['question']) && !empty($POST['question'])) 
	{
		SqlLQ('INSERT INTO dr_assessment_questions(question_name,admin_modifier_id,area_id) VALUES ("'.$POST['question'].'","'.$SESSION['user']['user_id'].'","'.$area.'" )');
			  						
	}
}
echo 'OK|||';
?>
