<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

if($SESSION['user']['view_as']!=''){
	$viewAsUserId=$SESSION['user']['view_as'];
	$senderEmailQry=SqlQ('SELECT email FROM c_user WHERE user_id="'.$viewAsUserId.'"');
	$senderEmail=$senderEmail['email'];
}else{
	$viewAsUserId=$SESSION['user']['user_id'];
	$senderEmail=$SESSION['user']['email'];
}
$viewAsUserName=$SESSION['user_list'][$viewAsUserId];

$user=SqlQ('SELECT name,surname,email
				FROM c_user
				WHERE user_id="'.$GET['user_id'].'"');

storeSession($SESSION);
?>OK|||mailto:<?=$user['email']?>&body=Dear <?=rawurlencode($user['name']),' ',rawurlencode($user['surname'])?>:%0D%0A%0D%0A%0D%0A
%0D%0A%0D%0A%0D%0A%0D%0A%0D%0A%0D%0A
Best Regards,%0D%0A%0D%0A
<?=rawurlencode($viewAsUserName)?>%0D%0A
<?=$senderEmail?>