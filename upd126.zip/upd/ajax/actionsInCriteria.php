<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

if($GET['criteria']==0){
	//JFM TODO - CRIT
	$action=SqlSLi('SELECT a.action_code
					FROM dr_action AS a
						INNER JOIN dr_review_criteria AS c ON a.criteria=c.review_criteria_id
					WHERE c.review_group="'.$GET['group'].'"','action_code');
}else{
	$action=SqlSLi('SELECT action_code FROM dr_action WHERE criteria="'.$GET['criteria'].'"','action_code');
}

echo 'OK|||'.$GET['group'].'%%%'.$GET['criteria'].'%%%'.$GET['mode'].'&&&';
if(is_array($action)){
	echo count($action).'&&&';
	for($i=0;$i<10;$i++){
		if($action[$i]!=''){
			echo $action[$i],'
';
		}
	}
}
storeSession($SESSION);
?>