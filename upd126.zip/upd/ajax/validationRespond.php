<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

//$getObjectType=SqlLi('SELECT object FROM c_object WHERE object_id='.$GET['object']);

if($GET['object']==$SESSION['object']['criterion_validity_id'])
{								
	$criterionValidityId=$GET['applicability'];
	$criterionId=$GET['criterionID'];
	$reviewProfile=0;
	$included=1;
	
	$header=$GET['criterion_user_id'].' for '.$GET['review_type'].' reviews'; //JFM 03_12_13
}

else if($GET['object']==$SESSION['object']['review_id'])
{
	$allReviewInfo=SqlLi('SELECT DISTINCT r.review_profile, r.remark, ra.ca, r.msn, r.remark, p.program, c.coe, m.msn AS msn_name, ca.ca AS ca_name, rt.review_type
							FROM dr_review AS r
								INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
								INNER JOIN dr_review_profile AS rp ON rp.review_profile_id=r.review_profile
								INNER JOIN c_program AS p ON p.program_id=rp.program
								INNER JOIN c_coe AS c ON c.coe_id=rp.coe
								INNER JOIN c_msn AS m ON m.msn_id=r.msn
								INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
								INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
							WHERE review_id='.$GET['applicability']);

	$validatorsQry=SqlLi('SELECT CONCAT(u.surname,\', \',u.name) AS validator_full_name
								FROM c_user as u 
									INNER JOIN dr_validation_loop_structure	AS vls ON u.user_id=vls.validator
								WHERE vls.object=(SELECT object_id FROM c_object WHERE object="review_id")
								AND vls.applicability='.$GET['applicability'].'
								AND vls.validation_loop_structure_step!=0
								AND vls.validator_removed=0
								ORDER BY validation_loop_structure_id ASC');

							
	$reviewProfile=$allReviewInfo[0]['review_profile'];
	$ca=$allReviewInfo[0]['ca'];
	$msn=$allReviewInfo[0]['msn'];
	$reviewId[0]=$GET['applicability'];
	$reviewValidated=0;
	$reviewValidationCommencing=1;
	$included=1;

	function item($item) { return $item['ca_name']; }
	$caNames=array_map('item', $allReviewInfo);
	$casAsString=implode(', ', $caNames);

	if(strlen($casAsString) > 25)
	{
		$casAsStringShort = '<div style="display:inline;" onMouseOut="nd();"onMouseOver="overlib(\''.htmlentities(utf8_decode($casAsString)).'\');">'.substr($casAsString,0,22).'...</div>';
	}
	else $casAsStringShort=$casAsString;

	$header=$allReviewInfo[0]['program'].' - '.$allReviewInfo[0]['coe'].' - MSN '.$allReviewInfo[0]['msn_name'];
}
else if($GET['object']==$SESSION['object']['criteria_status_id'])
{
	$allEvidenceInfo=SqlQ('SELECT *
							FROM dr_criteria_status AS ca
							WHERE criteria_status_id='.$GET['applicability']);

	$reviewProfile=SqlLi('SELECT DISTINCT rp.review_profile_id, p.program, c.coe, m.msn, ca.ca, rt.review_type, r.review_id
							FROM dr_review_profile AS rp
								INNER JOIN dr_review_group AS rg ON rg.review_type=rp.review_type
								INNER JOIN dr_review_criterion AS rc ON rc.review_group=rg.group_id
								INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
								INNER JOIN dr_criteria_status as cs ON cs.review_criteria=rc.review_criterion_id
								INNER JOIN dr_review_applicability AS ra ON ra.ca=cs.ca
																		AND ra.review=r.review_id
								INNER JOIN c_program AS p ON p.program_id=rp.program
								INNER JOIN c_coe AS c ON c.coe_id=rp.coe
								INNER JOIN c_msn AS m ON m.msn_id=r.msn
													AND cs.msn=r.msn
								INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
								INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
							WHERE cs.criteria_status_id='.$GET['applicability']);

	function item2($item) { return $item['review_id']; }
	$reviewIds=array_map('item2', $reviewProfile);

	$allCas=SqlSLi('SELECT ca.ca FROM dr_review_applicability AS ra INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca WHERE review IN ('.implode(',',$reviewIds).')','ca');

	$casAsString=implode(', ', $allCas);

	if(strlen($casAsString) > 25)
	{
		$casAsStringShort = '<div style="display:inline;" onMouseOut="nd();"onMouseOver="overlib(\''.htmlentities(utf8_decode($casAsString)).'\');">'.substr($casAsString,0,22).'...</div>';
	}
	else $casAsStringShort=$casAsString;

	$header=$reviewProfile[0]['program'].' - '.$reviewProfile[0]['coe'].' - MSN '.$reviewProfile[0]['msn'];

	$included=1;
}
else if($GET['object']==$SESSION['object']['action_id']) //JFM 30_10_14
{
	$actionInfo=SqlLi('SELECT DISTINCT act.action_code, rt.review_type, ca.ca
							FROM dr_action AS act
							INNER JOIN dr_action_applicability 	AS app ON app.action=act.action_id
							INNER JOIN c_ca 					AS ca  ON ca.ca_id=app.ca
							INNER JOIN dr_review_applicability 	AS rpp ON rpp.ca=ca.ca_id
							INNER JOIN dr_review 				AS r   ON r.review_id=rpp.review
							INNER JOIN dr_review_profile		AS rp  ON rp.review_profile_id=r.review_profile
							INNER JOIN dr_review_type 			AS rt  ON rt.review_type_id=rp.review_type
							WHERE act.action_id ='.$GET['applicability']);
	$header='Action '.$actionInfo[0]['action_code'].' - '.$actionInfo[0]['ca'].' - '.$actionInfo[0]['review_type'];

	$included=1;
}

?>OK|||<?php
?><div class="formHeaderInfo"id="userDetailsTitle" style="left:0px;"><?=$header?></div><?php

?><div><?php
	 
	include('../form/workflow.php');

if($maxValidationLoopStructureStep==0 && !$GET['noDecision'])  //JFM 14_10_13
{
	?><div id="alreadyInValidationLoopResponse" style="font-size:14px; font-weight:bold; color:#FF0000; margin-bottom:-45px;">
											This item has been REJECTED.<br />Please review the comments from the rejecter and modify the item accordingly.</div><?php
	$modifying=1;
	$reviewValidationCommencing=0;
}
	
?></div><?php

switch($GET['object'])
{
	case $SESSION['object']['criterion_validity_id']:
		?><div style="font-size:14px; color:#000000; margin-top:40px; margin-bottom:10px;">Proposed Criterion:</div><?php
		
		include('../form/criteriaCreate.php');
		
	break;

	case $SESSION['object']['review_id']:

		$GET['ca']=$ca;
		$GET['msn']=$msn;
		$GET['review']=$reviewProfile;
		
		?><div style="font-size:14px; color:#000000; margin-top:40px; margin-bottom:10px;">Proposed Review:</div><?php

		?><div class="wideFormTable"id="reviewCriteriaReportList"><?php
			?><div class="tableTitle" style="width:40%;">Review Remarks:</div><?php
			?><div id="review_remark_formatted_area" class="textarea" style="text-align:left; color:black; height:100px;"><?=str_replace( "\n", '<br />',utf8_encode($allReviewInfo[0]['remark']))?></div><?php
						
			?><div style="width:95%; text-align:right;"><?php	
				?><div title="Expand..." style="width:25%; text-align:right; display:inline; cursor:pointer; font-size:20px; font-weight:bold; color:#004f6b;" id="review_remark_formatted_area_arrow" onclick="colapseDivFromID('review_remark_formatted_area','textarea');">&#9660;</div><?php //&#9660;
			?></div><?php

			include('../ajax/criteriaList.php');
		?></div><?php
	
	break;

	case $SESSION['object']['criteria_status_id']:
		?><div style="font-size:14px; color:#000000; margin-top:40px; margin-bottom:10px;">Proposed Evidence:</div><?php
		$GET['msn']=$allEvidenceInfo['msn'];
		$GET['ca']=$allEvidenceInfo['ca'];
		$GET['review_criteria_id']=$allEvidenceInfo['review_criteria'];
		$GET['review_profile']=$reviewProfile[0]['review_profile_id'];
		$GET['continuous_assessment']=1;
		$GET['review_validated']=1;
		include('../ajax/criteriaColumnTable.php');
		include('../ajax/criteriaInfo.php');
	break;

	case $SESSION['object']['action_id']: //JFM 30_10_14
		?><div style="font-size:14px; color:#000000; margin-top:40px; margin-bottom:10px;">Proposed Action:</div><?php

		$GET['action']=$GET['applicability'];

		include('../form/action.php');

		?><div class="sp"></div><?php
		
	break;
}
	
if(!$GET['noDecision']) //JFM 07_04_14
{
	if($maxValidationLoopStructureStep!=0)
	{	
		?><div style="clear:both;"><?php

			?><div style="font-size:14px; color:#000000;  margin-top:40px; margin-bottom:10px; text-align:left;">Decision:</div><?php
		
			include('../form/decision.php');
			
		?></div><?php
	}
	else
	{
		if($GET['object']==$SESSION['object']['review_id'])
		{
			?><form action="#" enctype="multipart/form-data" id="reviewEditForm" name="reviewEditForm" method="post"style="display:inline;"><?php

				/*?><div style="width:55%; float:right; height:100px;">&zwnj;</div><?php*/

				?><table class="criteriaTable" id="placeholderTable" style="width:45%; float:left; border-bottom:0px;" cellspacing="0" cellpadding="5"><?php
					?><tr class="tableGroup"><?php
						?><td>Review Validators:<span id="reviewValidatorsResponse" style="visibility:hidden;" >&zwnj;</span></td><?php
					?></tr><?php
				?></table><?php
				?><table class="criteriaTable" id="reviewValidatorsTable" style="width:45%; float:left; border-top:0px;" cellspacing="0" cellpadding="5"><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" rowspan="100" width="15%">Review Validators:<div id="reviewValidatorsResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
					?></tr><?php

					$i=0;
					if(!empty($validatorsQry)) //JFM 03_12_13
					{
						foreach($validatorsQry as $validator)
						{
							?><tr id="rowelephantTigerBeehive<?=$i?>"><?php
								?><td width="35%" valign="top"><?php
									?><div class="suggestion"id="test<?=$i?>"style="width:159px;"></div><?php
									?><input class="textareaWhite" id="elephantTigerBeehive<?=$i?>"name="elephantTigerBeehive<?=$i?>" value="<?=utf8_encode($validator['validator_full_name'])?>" onKeyDown="removeOrCreateNameSuggestion(this,'reviewValidatorsTable','test','elephantTigerBeehive','suggestionID');" onFocus="loadUserSuggestion(this,'test<?=$i?>','elephantTigerBeehive<?=$i?>','','suggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');"size="28"type="text"><?php
									?><input class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehive<?=$i?>','reviewValidatorsTable');" type="button" value="&#10008;"/><?php
								?></td><?php
							?></tr><?php
							$i++;
						}
					}
					
					?><tr id="rowelephantTigerBeehive<?=$i?>"><?php
						?><td width="35%" valign="top"><?php
							?><div class="suggestion"id="test<?=$i?>"style="width:159px;"></div><?php
							?><input class="textareaWhite" id="elephantTigerBeehive<?=$i?>"name="elephantTigerBeehive<?=$i?>" onKeyDown="removeOrCreateNameSuggestion(this,'reviewValidatorsTable','test','elephantTigerBeehive','suggestionID');" onFocus="loadUserSuggestion(this,'test<?=$i?>','elephantTigerBeehive<?=$i?>','','suggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');"size="28"type="text"><?php
							?><input class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehive<?=$i?>','reviewValidatorsTable');" type="button" value="&#10008;"/><?php
						?></td><?php
					?></tr><?php
				?></table><?php
			
				?><div style="clear:both;"><?php
					?><input class="formInput" id="reviewID" name="reviewID" type="text" value="<?=$GET['applicability']?>" style="display:none;" disabled /><?php
					?><input class="formInput" id="modify" name="modify" type="text" value="1" style="display:none;" disabled /><?php
					?><input class="formInput" id="cancel" name="cancel" type="text" value="0" style="display:none;" disabled /><?php
					?><input class="formInput" id="maxValidationLoopID" name="maxValidationLoopID" type="text" size="50" value="<?=$maxValidationLoopID?>" style="display:none;" disabled /><?php
					?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(validateReview('<?=utf8_encode($SESSION['user']['name'])?>','<?=utf8_encode($SESSION['user']['surname'])?>',1)) { this.disabled=true; this.value='Please Wait...'; sendAjaxForm('reviewEditForm','ajax/saveReviewValidation.php','updateData','criteria_saveResponse'); clock(); clock(); sideValidation(<?=$GET['object']?>);}"type="button"value="Modify Review &#9658;"><?php
					?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(confirm('This will cancel the proposed criteria.\nAre you sure you wish to continue?')){ this.disabled=true; this.value='Please Wait...'; $('cancel').value=1; sendAjaxForm('reviewEditForm','ajax/saveReviewValidation.php','updateData','criteria_saveResponse'); mainRestartNeeded=1; clock(); clock(); sideValidation(<?=$GET['object']?>);}"type="button"value="Cancel Review &#9658;"><?php
				?></div><?php
			?></form><?php
		}
	}
}
else if($maxValidationLoopStructureStep!=0) //JFM 07_04_14
{
	?><form action="#" enctype="multipart/form-data" id="decisionForm" name="decisionForm" method="post"style="display:inline;"><?php
		?><input id="validationLoopID" name="validationLoopID" style="visibility:hidden" value="<?=$maxValidationLoopID?>" disabled /><?php
		?><input id="validationLoopStructureStep" name="validationLoopStructureStep" style="visibility:hidden" value="<?=$maxValidationLoopStructureStep?>" disabled /><?php
		?><input id="object" name="object" style="visibility:hidden" value="<?=$GET['object']?>" disabled /><?php
		?><input id="applicability" name="applicability" style="visibility:hidden" value="<?=$GET['applicability']?>" disabled /><?php
		?><input id="decisionRadio" name="decisionRadio" style="visibility:hidden" value="returned" disabled /><?php
		?><input id="decisionComments" name="decisionComments" style="visibility:hidden" value="Returned to Originator" disabled /><?php
		?><div align="center" style="clear:both;"><?php
			?><input class="stdBtn" id="validateDecisionSubmit" onClick="if(confirm('WARNING:\n\nThis will stop the current validation loop and return the item to you for changes. The validation loop will need to be restarted once changes have been made.\n\nAre you sure you wish to continue?')){ this.disabled=true; this.value='Please Wait...'; sendAjaxForm('decisionForm','ajax/saveDecision.php','putInDiv','decision_saveResponse','POST',false); clock(); clock(); sideValidation(<?=$GET['object']?>);}" type="button" value="Return Workflow To Me &#9658;"><?php
		?></div><?php
	?></form><?php

}

?><div class="sp"></div><?php

storeSession($SESSION);
?>