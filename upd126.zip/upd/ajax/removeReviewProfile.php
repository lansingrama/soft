<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

if(checkPermission('dr_review_profile_general','delete',0,'check',$SESSION)==1){
	$criteriaId=SqlSLi('SELECT rcr.review_criteria_id
						FROM dr_review_criteria AS rcr
							INNER JOIN dr_review_group AS rgr ON rcr.review_group=rgr.review_group_id
						WHERE review_profile="'.$GET['review_profile'].'"','review_criteria_id');
	
	$criteriaTxt='('.implode(',',$criteriaId).')';

	$review=SqlSLi('SELECT review_id
								FROM dr_review
								WHERE review_profile="'.$GET['review_profile'].'" AND(
									planned			!="0000-00-00"	OR
									review_date		!="0000-00-00"	OR
									review_done		!=0				OR
									delta			!="0000-00-00"	OR
									delta_done		!=0				OR
									review_status	!=0				OR
									link			!=""			OR
									remark			!=""
								)','review_id');
	if(is_array($review) && count($review)!=0){
		$answer='no_empty_review';
	}else{
		if(is_array($criteriaId)){
			$criteriaStatus=SqlSLi('SELECT criteria_status_id
												FROM dr_criteria_status
												WHERE review_criteria IN '.$criteriaTxt.' AND(
													criteria_status			!=0		OR
													criteria_focal_point	!=""	OR
													criteria_comments		!=""
												)','criteria_status_id');
			
			if(is_array($criteriaStatus) && count($criteriaStatus)!=0){
				$answer='no_empty_criteria_status';
			}else{
				$action=SqlSLi('SELECT action_id
													FROM dr_action
													WHERE criteria IN '.$criteriaTxt.' AND(
														action_description		!=""			OR
														action_remark			!=""			OR
														action_creation			!="0000-00-00"	OR
														action_completion		!="0000-00-00"	OR
														action_status			!=0				OR
														action_holder			!=0				OR
														action_holder_name		!=""			OR
														action_validator		!=0				OR
														action_validator_name	!=""
													)','action_id');
				if(is_array($action) && count($action)!=0){
					$answer='no_empty_action';
				}else{
					$rid=SqlSLi('SELECT rid_id
														FROM dr_rid
														WHERE criteria IN '.$criteriaTxt.' AND(
															rid_title		!=""			OR
															rid_status		!=0				OR
															rid_holder		!=0				OR
															rid_holder_name	!=""			OR
															rid_creation	!="0000-00-00"	OR
															rid_completion	!="0000-00-00"
														)','rid_id');
					if(is_array($rid) && count($rid)!=0){
						$answer='no_empty_rid';
					}else{
						$answer=1;
					}
				}
			}
		}else{
			$answer=1;
		}
	}
}else{
	$answer='no_rights';
}

//JFM TODO - CRIT
if($answer==1){
	SqlLQ('DELETE FROM dr_rid							WHERE criteria				IN '.$criteriaTxt);
	SqlLQ('DELETE FROM dr_action_applicability			WHERE action				IN (SELECT action_id FROM dr_action WHERE criteria IN '.$criteriaTxt.')');
	SqlLQ('DELETE FROM dr_action						WHERE criteria				IN '.$criteriaTxt);
	SqlLQ('DELETE FROM dr_criteria_status				WHERE review_criteria		IN '.$criteriaTxt);
	SqlLQ('DELETE FROM dr_review_configuration			WHERE criteria				IN '.$criteriaTxt);
	SqlLQ('DELETE FROM dr_review_criteria				WHERE review_criteria_id	IN '.$criteriaTxt);
	SqlLQ('DELETE FROM dr_review						WHERE review_profile		="'.$GET['review_profile'].'"');
	SqlLQ('DELETE FROM dr_review_configuration_profile	WHERE review_profile		="'.$GET['review_profile'].'"');
	SqlLQ('DELETE FROM dr_review_group					WHERE review_profile		="'.$GET['review_profile'].'"');
	SqlLQ('DELETE FROM dr_review_profile				WHERE review_profile_id		="'.$GET['review_profile'].'"');
	?>OK|||1<?php
}else{
	echo 'OK|||',$answer;
}
storeSession($SESSION);
?>