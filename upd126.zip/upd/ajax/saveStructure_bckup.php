<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');

function getResponsibleConfigurationId($level,$name,$a0Display=''){			
	$existingName=SqlQ('SELECT responsible_'.$level.'_id FROM dr_responsible_'.$level.' WHERE responsible_'.$level.'="'.$name.'"');
	if($existingName){
		$id=$existingName['responsible_'.$level.'_id'];
	}else{
		if($a0Display!=''){
			$a0DisplayField=',a0_display';
			$a0DisplayValue=',"'.$a0Display.'"';
		}
		SqlLQ('INSERT INTO dr_responsible_'.$level.' (responsible_'.$level.$a0DisplayField.') VALUES ("'.$name.'"'.$a0DisplayValue.')');
		$lastId=SqlQ('SELECT LAST_INSERT_ID()');
		$id=$lastId['LAST_INSERT_ID()'];
	}
	return $id;
}

$POST=cleanArray($_POST);
$closeForm=1;
if($POST['applicability']=='new'){
	switch($POST['objectTxt']){
		case 'area': //JFM 03_06_14
			if(!empty($POST['area']))
			{
				foreach ($POST as $key => $value) 
				{
					if(empty($value)) $POST[$key]=0;
				}

				SqlLQ('INSERT INTO c_area (area,need_program,need_coe,need_msn,need_criteria_validation,need_review_validation,need_evidence_validation) VALUES ("'.$POST['area'].'",'.$POST['need_program'].','.$POST['need_coe'].','.$POST['need_msn'].','.$POST['need_criteria_validation'].','.$POST['need_review_validation'].','.$POST['need_evidence_validation'].')');

				$areaId=SqlQ('SELECT LAST_INSERT_ID() AS areaId');

				if($POST['need_program']==0)
				{
					SqlLQ('INSERT INTO c_program (program, program_code, area) VALUES ("NA", "Z",'.$areaId['areaId'].')');

					$programId=SqlQ('SELECT LAST_INSERT_ID() AS programId');

					SqlLQ('INSERT INTO c_coe (coe, area) VALUES ("NA",'.$areaId['areaId'].')');

					if($POST['need_msn']==0)
					{
						SqlLQ('INSERT INTO c_msn (msn, program) VALUES ("NA",'.$programId['programId'].')');
					}	
				}
				else if($POST['need_coe']==0) SqlLQ('INSERT INTO c_coe (coe, area) VALUES ("NA",'.$areaId['areaId'].')');

				//JFM 28_10_15
				$newDdTxt=$POST['area'];
				$newDdList='strDdArea';
				$newDdId=$areaId['areaId'];
			}
		break;
		case 'program':
			SqlLQ('INSERT INTO c_program (program,program_code,military,area) VALUES ("'.$POST['program'].'","'.$POST['program_code'].'","'.$POST['military'].'","'.$POST['area'].'")'); //JFM 03_06_14
			
			// JFM 25_11_13	- JFM 03_06_14
			$programID=SqlQ('SELECT LAST_INSERT_ID()');
			$allReviewTypes=SqlLi('SELECT review_type_id FROM dr_review_type WHERE area='.$POST['area']);
			$allCoeTypes=SqlLi('SELECT coe_id FROM c_coe WHERE area='.$POST['area']);
			
			if(!empty($allReviewTypes))
			{
				foreach($allReviewTypes as $k=>$v)
				{
					if(!empty($allCoeTypes))
					{
						foreach($allCoeTypes as $o=>$p)
						{
							SqlLQ('INSERT INTO dr_review_profile (review_type, coe, program) VALUES ("'.$v['review_type_id'].'", "'.$p['coe_id'].'", "'.$programID['LAST_INSERT_ID()'].'")');
						}
					}
				}
			}
			// JFM 25_11_13	- END
			
			$neededItems=SqlQ('SELECT * FROM c_area WHERE area_id='.$POST['area']);
			if($neededItems['need_msn']==0)
			{
				SqlLQ('INSERT INTO c_msn (msn, program) VALUES ("NA",'.$programID['LAST_INSERT_ID()'].')');
			}
			
			if($POST['import_responsible_configuration']!=''){
				$lastProgramId=SqlQ('SELECT LAST_INSERT_ID()');
				importResponsibleConfiguration($lastProgramId['LAST_INSERT_ID()'],$POST['import_responsible_configuration']);
			}
			$newDdTxt=$POST['program'];
			$newDdList='strDdProgram';
			$newDdId=$programID['LAST_INSERT_ID()'];
		break;
		case 'coe':
			SqlLQ('INSERT INTO c_coe (coe,area) VALUES ("'.$POST['coe'].'","'.$POST['area'].'")'); //JFM 03_06_14
			
			// JFM 25_11_13	- JFM 03_06_14
			$coeID=SqlQ('SELECT LAST_INSERT_ID()');
			$allReviewTypes=SqlLi('SELECT review_type_id FROM dr_review_type WHERE area='.$POST['area']);
			$allProgramTypes=SqlLi('SELECT program_id FROM c_program WHERE area='.$POST['area']);
			
			if(!empty($allReviewTypes))
			{
				foreach($allReviewTypes as $k=>$v)
				{
					if(!empty($allProgramTypes))
					{
						foreach($allProgramTypes as $o=>$p)
						{
							SqlLQ('INSERT INTO dr_review_profile (review_type, coe, program) VALUES ("'.$v['review_type_id'].'", "'.$coeID['LAST_INSERT_ID()'].'", "'.$p['program_id'].'")');
						}
					}
				}
			}
			
			$newDdTxt=$POST['coe'];
			$newDdList='strDdCoe';
			$newDdId=$coeID['LAST_INSERT_ID()'];
		break;
		case 'perimeter':
			SqlLQ('INSERT INTO c_perimeter (program,perimeter) VALUES ("'.$POST['program'].'","'.$POST['perimeter'].'")');
			$newDdTxt=$POST['perimeter'];
			$newDdList='strDdPerimeter';
		break;
		case 'msn':
			SqlLQ('INSERT INTO c_msn (program,msn) VALUES ("'.$POST['program'].'","'.$POST['msn'].'")');
			if($POST['msn_applicability'] && $POST['msn_applicability']!=''){
				$lastMsnId=SqlQ('SELECT LAST_INSERT_ID()');
				SqlLQ('INSERT INTO c_cawp
						(msn,ca,wp)
							SELECT "'.$lastMsnId['LAST_INSERT_ID()'].'",ca,wp
							FROM c_cawp
							WHERE msn="'.$POST['msn_applicability'].'"');
			}
			$newDdTxt=$POST['msn'];
			$newDdList='strDdMsn';
		break;
		case 'cawp':
			if($POST['existingWp']!=''){
				$wp['wp']=$POST['existingWp'];
			}elseif($POST['wp']!=''){
				SqlLQ('INSERT INTO c_wp (program,coe,wp) VALUES ('.$POST['program'].','.$POST['coe'].',"'.$POST['wp'].'")');
				$wp=SqlQ('SELECT LAST_INSERT_ID() AS wp');
			}
			if($POST['existingCa']!=''){
				$ca['ca']=$POST['existingCa'];
			}elseif($POST['ca']!=''){
				SqlLQ('INSERT INTO c_ca (program,coe,perimeter,ca) VALUES ('.$POST['program'].','.$POST['coe'].','.$POST['perimeter'].',"'.$POST['ca'].'")');
				$ca=SqlQ('SELECT LAST_INSERT_ID() AS ca');
			}
			if($wp['wp'] && $ca['ca']){
				SqlLQ('INSERT INTO c_cawp (msn,ca,wp) VALUES ('.$POST['msn'].','.$ca['ca'].','.$wp['wp'].')');
			}
		break;
		case 'review':
 			$reviewType=$POST['review_type_id'];
			if($reviewType=='' || $reviewType==0){
				SqlLQ('INSERT INTO dr_review_type (review_type,review_type_description,review_type_code, area) VALUES ("'.$POST['new_review_type'].'","'.$POST['new_review_type_description'].'","'.$POST['new_review_type_code'].'","'.$POST['area'].'")');
				$reviewTypeQry=SqlQ('SELECT LAST_INSERT_ID()');
				$reviewType=$reviewTypeQry['LAST_INSERT_ID()'];
				$SESSION['new_review_type'][$reviewType]=$POST['new_review_type'];
			}
			
			//SqlLQ('INSERT INTO dr_review_profile (program,coe,review_type) VALUES ("'.$POST['program'].'","'.$POST['coe'].'","'.$reviewType.'")');
			
			SqlLQ('INSERT INTO dr_review_profile (program,coe,review_type,review_profile_order) SELECT program_id, coe_id, "'.$reviewType.'", "'.$POST['new_review_profile_order'].'" FROM c_coe, c_program WHERE c_coe.area='.$POST['area'].' AND c_program.area='.$POST['area']); //JFM 03_06_14
			
			$reviewProfileId=SqlQ('SELECT LAST_INSERT_ID() AS review_profile_id');
			$reviewProfileOutput=$reviewProfileId['review_profile_id'];
			
			/* JFM 11_11_13 - Can no longer import configurations or from other reviews. Therefore this is all pointless.
			
			$reviewProfileSource=$POST['review_profile_copy_source'];
			
			if($reviewProfileSource!='' && $reviewProfileSource!=0){
				repairReviewPosition($reviewProfileSource);
				//JFM TODO - CRIT - All of this down.
				$reviewGroup=SqlAsLi('SELECT review_group_id,group_description,group_position FROM dr_review_group WHERE review_profile="'.$reviewProfileSource.'"','review_group_id');
				
				if(is_array($reviewGroup)){
					foreach($reviewGroup as $groupSource=>$group){
						SqlLQ('INSERT INTO dr_review_group (review_profile,group_description,group_position) VALUES ("'.$reviewProfileOutput.'","'.addslashes($group['group_description']).'","'.$group['group_position'].'")');
						$groupDestinationQry=SqlQ('SELECT LAST_INSERT_ID() AS id');
						$groupDestination=$groupDestinationQry['id'];
						
						$reviewCriteria=SqlAsLi('SELECT review_criteria_id,criteria_description,reference,criteria_position FROM dr_review_criteria WHERE review_group="'.$groupSource.'"','review_criteria_id');
						
						if(is_array($reviewCriteria)){
							foreach($reviewCriteria as $criteriaSource=>$criteria){
								SqlLQ('INSERT INTO dr_review_criteria (review_group,criteria_description,reference,criteria_position) VALUES ("'.$groupDestination.'","'.addslashes($criteria['criteria_description']).'","'.addslashes($criteria['reference']).'","'.$criteria['criteria_position'].'")');
								$criteriaDestinationQry=SqlQ('SELECT LAST_INSERT_ID() AS id');
								$criteriaDestination[$criteriaSource]=$criteriaDestinationQry['id'];
							}
						}
					}
				}
				
				if($POST['import_review_configuration']==1){
					$reviewConfigurationProfile=SqlAsLi('SELECT review_configuration_profile_id,review_configuration_profile FROM dr_review_configuration_profile WHERE review_profile="'.$reviewProfileSource.'"','review_configuration_profile_id');
					
					if(is_array($reviewConfigurationProfile)){
						foreach($reviewConfigurationProfile as $configurationProfileSource=>$configurationProfile){
							SqlLQ('INSERT INTO dr_review_configuration_profile (review_profile,review_configuration_profile) VALUES ("'.$reviewProfileOutput.'","'.addslashes($configurationProfile['review_configuration_profile']).'")');
							$configurationProfileDestinationQry=SqlQ('SELECT LAST_INSERT_ID() AS id');
							$configurationProfileDestination=$configurationProfileDestinationQry['id'];
							
							$reviewConfiguration=SqlAsLi('SELECT review_configuration_id,criteria,review_configuration FROM dr_review_configuration WHERE review_configuration_profile="'.$configurationProfileSource.'"','review_configuration_id');
							
							if(is_array($reviewConfiguration)){
								foreach($reviewConfiguration as $configurationSource=>$configuration){
									SqlLQ('INSERT INTO dr_review_configuration (review_configuration_profile,criteria,review_configuration) VALUES ("'.$configurationProfileDestination.'","'.$criteriaDestination[$configuration['criteria']].'","'.$configuration['review_configuration'].'")');
								}
							}
						}
					}
				}
			}
			else
			{
				SqlLQ('INSERT INTO dr_review_group (review_profile,group_description,group_position) VALUES ('.$reviewProfileOutput.',"New Group",1)');
				SqlLQ('INSERT INTO dr_review_criteria (review_group,criteria_description,reference,criteria_position) VALUES (LAST_INSERT_ID(),"New Criteria","",1)');
			}*/
		break;
		case 'review_configuration_profile':
			$existingReviewConfigurationProfile=SqlQ('SELECT review_configuration_profile_id FROM dr_review_configuration_profile WHERE review_profile="'.$POST['review_profile'].'" AND review_configuration_profile="'.$POST['review_configuration_profile'].'"');
			if(!$existingReviewConfigurationProfile){
				SqlLQ('INSERT INTO dr_review_configuration_profile (review_profile,review_configuration_profile) VALUES ("'.$POST['review_profile'].'","'.$POST['review_configuration_profile'].'")');
				$newReviewConfigurationProfile=SqlQ('SELECT LAST_INSERT_ID()');
			}
		break;
		case 'company':
			$existingCompany=SqlQ('SELECT company_id FROM c_company WHERE company="'.$POST['company'].'"');
			if(!$existingCompany && $POST['company']!=''){
				SqlLQ('INSERT INTO c_company (company) VALUES ("'.$POST['company'].'")');
			}
		break;
		case 'department':
			$existingDepartment=SqlQ('SELECT department_id FROM c_department WHERE siglum="'.$POST['siglum'].'" OR department_description="'.$POST['department_description'].'"');
			if(!$existingDepartment && $POST['siglum']!='' && $POST['department_description']!=''){
				SqlLQ('INSERT INTO c_department (siglum,department_description) VALUES ("'.$POST['siglum'].'","'.$POST['department_description'].'")');
			}
		break;
		case 'cat':
			SqlLQ('INSERT INTO dr_review_group (review_type) VALUES ("'.$POST['review_type'].'")');
			$groupID=SqlQ('SELECT LAST_INSERT_ID() AS groupID');
			SqlLQ('INSERT INTO dr_review_group_history (review_group, review_group_description, review_group_position, review_group_valid_from) VALUES ("'.$groupID['groupID'].'","'.$POST['review_group_name'].'","'.($POST['review_group_position']+1).'",SYSDATE())');
			repairReviewPosition($POST['reviewProfile']);
		break;
		
		case 'grams':
			SqlLQ('INSERT INTO c_grams (grams_reference) VALUES ("'.$POST['grams_reference_value'].'")');
		break;
	}
	if($newDdList!=''){
		if(!$newDdId) //JFM 25_11_13
		{
			$lastId=SqlQ('SELECT LAST_INSERT_ID()');
			$newDdId=$lastId['LAST_INSERT_ID()'];
		}
	}
}else{
	switch($POST['objectTxt']){
		case 'area': //JFM 03_06_14
			if(!empty($POST['area']))
			{
				foreach ($POST as $key => $value) 
				{
					if(empty($value)) $POST[$key]=0;
				}

			SqlLQ('UPDATE c_area SET area="'.$POST['area'].'",need_program='.$POST['need_program'].',need_coe='.$POST['need_coe'].',need_msn='.$POST['need_msn'].',need_criteria_validation='.$POST['need_criteria_validation'].',need_review_validation='.$POST['need_review_validation'].',need_evidence_validation='.$POST['need_evidence_validation'].' WHERE area_id="'.$POST['applicability'].'"');

			}
		break;
		case 'program':
			SqlLQ('UPDATE c_program SET program="'.$POST['program'].'",program_code="'.$POST['program_code'].'",military="'.$POST['military'].'" WHERE program_id="'.$POST['applicability'].'"');
		break;
		case 'coe':
			SqlLQ('UPDATE c_coe SET coe="'.$POST['coe'].'" WHERE coe_id="'.$POST['applicability'].'"');
		break;
		case 'perimeter':
			SqlLQ('UPDATE c_perimeter SET perimeter="'.$POST['perimeter'].'" WHERE perimeter_id="'.$POST['applicability'].'"');
		break;
		case 'msn':
			SqlLQ('UPDATE c_msn SET msn="'.$POST['msn'].'" WHERE msn_id="'.$POST['applicability'].'"');
		break;
		case 'cawp':
			$cawpLocation=SqlQ('SELECT cw.msn,cw.ca,cw.wp,
						ca.program,ca.coe,ca.perimeter,ca.ca AS ca_txt,
						wp.wp AS wp_txt
					FROM c_cawp AS cw
						INNER JOIN c_ca AS ca ON cw.ca=ca.ca_id
						INNER JOIN c_wp AS wp ON cw.wp=wp.wp_id
					WHERE cw.cawp_id IN('.$POST['applicability'].')');
			switch($POST['mode']){
				case 'addCa':
					if($POST['existingCa']!=''){
						SqlLQ('INSERT INTO c_cawp (msn,ca,wp) VALUES ('.$cawpLocation['msn'].','.$POST['existingCa'].','.$cawpLocation['wp'].')');
					}elseif($POST['ca']!=''){
						SqlLQ('INSERT INTO c_ca (program,coe,perimeter,ca) VALUES ('.$cawpLocation['program'].','.$cawpLocation['coe'].','.$cawpLocation['perimeter'].',"'.$POST['ca'].'")');
						SqlLQ('INSERT INTO c_cawp (msn,ca,wp) VALUES ('.$cawpLocation['msn'].',LAST_INSERT_ID(),'.$cawpLocation['wp'].')');
					}
				break;
				case 'disableCa':
					if($POST['id_type']=='ca'){
						$cawpId=SqlQ('SELECT GROUP_CONCAT(cawp_id SEPARATOR ",") AS cawp
										FROM c_cawp
										WHERE msn='.getFilter('msn','filter',0,$SESSION).'
											AND ca IN('.$POST['applicability'].')');
						$POST['applicability']=$cawpId['cawp'];
					}
					SqlLQ('UPDATE c_cawp SET cawp_disabled="'.$POST['disabled'].'" WHERE cawp_id IN('.$POST['applicability'].')');
					$oldValue=($POST['disabled']==1)?0:1;
					$caArray=explode(',',$POST['applicability']);
					foreach($caArray as $c){
						createLog('dr_log','cawp_disabled','edit',$c,$oldValue,$POST['disabled'],$SESSION);
					}
					$closeForm=0;
				break;
				case 'disableWp':
					$wpList=SqlAsArr('SELECT cawp_id,wp FROM c_cawp WHERE cawp_id="'.$POST['applicability'].'"','cawp_id','wp');
					if(is_array($wpList)){
						SqlLQ('UPDATE c_cawp SET cawp_disabled="'.$POST['disabled'].'" WHERE wp IN ('.implode(',',$wpList).')');
						$oldValue=($POST['disabled']==1)?0:1;
						foreach($wpList as $k=>&$v){
							createLog('dr_log','cawp_disabled','edit',$k,$oldValue,$POST['disabled'],$SESSION);
						}
					}
					$closeForm=0;
				break;
				case 'editCaWpName':
					if($POST['ca']!=$cawpLocation['ca_txt']){
						SqlLQ('UPDATE c_ca SET ca="'.$POST['ca'].'" WHERE ca_id="'.$cawpLocation['ca'].'"');
					}
					if($POST['wp']!=$cawpLocation['wp_txt']){
						SqlLQ('UPDATE c_wp SET wp="'.$POST['wp'].'" WHERE wp_id="'.$cawpLocation['wp'].'"');
					}
				break;
				case 'removeCa':
					SqlLQ('DELETE FROM c_cawp WHERE cawp_id="'.$POST['applicability'].'"');
					$closeForm=0;
				break;
				case 'removeWp':
					$wpList=SqlSLi('SELECT wp FROM c_cawp WHERE cawp_id="'.$POST['applicability'].'"','wp');
					if(is_array($wpList)){
						SqlLQ('DELETE FROM c_cawp WHERE wp IN ('.implode(',',$wpList).')');
					}
					$closeForm=0;
				break;
			}
		break;
		case 'responsible':
			$a0Display=SqlQ('SELECT g.a0_display
								FROM dr_responsible_group AS g
									INNER JOIN dr_responsible_configuration AS c ON g.responsible_group_id=c.responsible_group
								WHERE c.program="'.$POST['program'].'"
									AND c.group_position="'.$POST['group_position'].'"
									AND c.role_position="'.$POST['role_position'].'"');
									
			$groupId=getResponsibleConfigurationId('group',$POST['responsible_group'],$a0Display['a0_display']);
			$roleId=getResponsibleConfigurationId('role',$POST['responsible_role']);
			
			if($groupId && $roleId){
				SqlLQ('UPDATE dr_responsible_configuration SET responsible_group="'.$groupId.'" WHERE program="'.$POST['program'].'" AND group_position="'.$POST['group_position'].'"');
				SqlLQ('UPDATE dr_responsible_configuration SET responsible_role="'.$roleId.'" WHERE program="'.$POST['program'].'" AND group_position="'.$POST['group_position'].'" AND role_position="'.$POST['role_position'].'"');
			}
		break;
		case 'review':

			//JFM 19_07_16
			SqlLQ('UPDATE dr_review_type SET review_type="'.$POST['review_type'].'", review_type_description="'.$POST['review_type_description'].'", review_type_code="'.$POST['review_type_code'].'" WHERE review_type_id="'.$POST['review_type_id'].'"');

			SqlLq('UPDATE dr_review_profile SET review_profile_order ="'.$POST['review_profile_order'].'" WHERE review_type="'.$POST['review_type_id'].'"');

			/* JFM 19_07_16
			$reviewDetails=SqlQ('SELECT program,coe FROM dr_review_profile WHERE review_profile_id="'.$POST['applicability'].'"');
			
			$existingReview=SqlQ('SELECT rpr.review_profile_id
									FROM dr_review_profile			AS rpr
										INNER JOIN dr_review_type	AS rt ON rpr.review_type=rt.review_type_id
									WHERE rt.review_type="'.$POST['review_type'].'"
										AND rpr.review_profile_id!="'.$POST['applicability'].'"
										AND rpr.program!="'.$reviewDetails['program'].'"
										AND rpr.coe!="'.$reviewDetails['coe'].'"');
			
			if(!$existingReview){
				$reviewTypeId=SqlQ('SELECT review_type_id FROM dr_review_type WHERE review_type="'.$POST['review_type'].'"');
				if(!$reviewTypeId['review_type_id']){
					SqlLQ('INSERT INTO dr_review_type (review_type,review_type_description,review_type_code) VALUES ("'.$POST['review_type'].'","'.$POST['review_type_description'].'","'.$POST['review_type_code'].'")');
					$reviewTypeId=SqlQ('SELECT LAST_INSERT_ID() AS review_type_id');
				}else{
					SqlLQ('UPDATE dr_review_type SET review_type_description="'.$POST['review_type_description'].'",review_type_code="'.$POST['review_type_code'].'" WHERE review_type_id="'.$reviewTypeId['review_type_id'].'"');
				}
				if($reviewTypeId['review_type_id']!='' && $reviewTypeId['review_type_id']!='0'){
					SqlLQ('UPDATE dr_review_profile SET review_type="'.$reviewTypeId['review_type_id'].'" WHERE review_profile_id="'.$POST['applicability'].'"');
				} 
				$reviewProfileOutput='reviewElement_'.$POST['applicability'].'%%%text%%%'.$POST['review_type'].
										'&&&reviewConfigTitle'.'%%%text%%%'.$POST['review_type'].' Review'.
										'&&&editReviewConfigTitle'.'%%%text%%%Review Type (valid for all '.$POST['review_type'].' Reviews):';
				
				if($reviewDetails['program']==getFilter('program','filter',0,$SESSION) && $reviewDetails['coe']==getFilter('coe','filter',0,$SESSION)){
					$reviewProfileOutput.='&&&main_restart_needed%%%main_restart_needed%%%1';
				}
				
			}*/
		break;
		case 'review_configuration_profile':
			SqlLQ('UPDATE dr_review_configuration_profile SET review_configuration_profile="'.$POST['review_configuration_profile'].'" WHERE review_configuration_profile_id="'.$POST['applicability'].'"');
		break;
		case 'company':
			if($POST['applicability']!='' && $POST['company']!='' && checkPermission('c_company_general','edit',0,'check',$SESSION)==1){
				SqlLQ('UPDATE c_company SET company="'.$POST['company'].'" WHERE company_id="'.$POST['applicability'].'"');
			}
		break;
		case 'department':
			if($POST['applicability']!='' && $POST['siglum']!='' && $POST['department_description']!='' && checkPermission('c_department_general','edit',0,'check',$SESSION)==1){
				SqlLQ('UPDATE c_department SET siglum="'.$POST['siglum'].'",department_description="'.$POST['department_description'].'" WHERE department_id="'.$POST['applicability'].'"');
			}
		break;
		case 'cat':
			$groupHistoryID=SqlQ('SELECT review_group_history_id FROM dr_review_group_history WHERE review_group='.$POST['groupID'].' AND review_group_valid_to="0000-00-00 00:00:00"');
			SqlLQ('UPDATE dr_review_group_history SET review_group_valid_to=SYSDATE() WHERE review_group_history_id='.$groupHistoryID['review_group_history_id']);
			SqlLQ('INSERT INTO dr_review_group_history (review_group, review_group_description, review_group_position, review_group_valid_from) VALUES ("'.$POST['groupID'].'","'.$POST['review_group_name'].'","'.($POST['review_group_position']+1).'",SYSDATE())');
			repairReviewPosition($POST['reviewProfile']);
		break;
	}
}
storeSession($SESSION);
?>OK|||<?php

if($POST['fromWizard']==1)
{
	echo 'wizardOK';
}
else
{
	switch($POST['objectTxt'])
	{
		case 'review':
			echo $reviewProfileOutput;
		break;
		case 'review_configuration_profile':
			echo $POST['applicability'],'%%%',$newReviewConfigurationProfile['LAST_INSERT_ID()'],'%%%',$POST['review_configuration_profile'],'%%%',$POST['review_profile'];
		break;
		default:
			if($newDdList!='')
			{
				echo $POST['applicability'],'%%%',$POST['objectTxt'],'&&&',$newDdList,'%%%',$newDdId,'%%%',$newDdTxt;
			}
		break;
	}
}
?>