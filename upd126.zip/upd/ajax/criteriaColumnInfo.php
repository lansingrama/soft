<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');

$GET['criteria']=$_GET['criteria'];
?>OK|||<div class="olHeader">Criteria Column Details</div><?php
?><div class="olSpT"></div><?php
require_once('criteriaColumnTable.php');
?><div class="olSpB"></div><?php
storeSession($SESSION);
?>