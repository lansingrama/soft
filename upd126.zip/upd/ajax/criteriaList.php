<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');

$caArray=explode(',',$GET['ca']);
$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
/*
	* Fix for : US#106 Improvement: Freeze Function for completed DR 
	* Added for freeze/unfreeze function
	* Version: 4.3
	* Fixed By: Infosys Limited
*/
if ($GET['review'] && $GET['ca']) {
	$reviewInfo = SqlLi('SELECT * FROM dr_review_freeze WHERE review = '.$GET['review'].' AND ca_id = '.$GET['ca'].'');
}

if(!is_array($combinedReview) && !isset($reviewProfile))
{
	require_once('../../support.php');
	require_once('../support/localSupport.php');
	require_once('../support/form.php');
	foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
	$status=array('r','a','g','x'); //JFM 27_03_14
	$msn=getFilter('msn','filter',0,$SESSION);
	$reviewProfile=$GET['review'];
	if(isset($GET['ca'])){
		// JFM 22_10_13  Replaced with below $existingReview=SqlSLi('SELECT ca FROM dr_review WHERE ca IN('.$GET['ca'].') AND msn="'.$msn.'" AND review_profile="'.$reviewProfile.'"','ca');
		$existingReview=SqlSLi('SELECT ca 
								FROM dr_review_applicability AS ra
									INNER JOIN dr_review AS r ON ra.review=r.review_id
								WHERE ca IN('.$GET['ca'].') 
								AND msn="'.$msn.'" 
								AND review_profile="'.$reviewProfile.'"','ca');
		foreach($caArray as $c){
			if(!in_array($c,$existingReview)){
				$missingReview[]=$c;
			}
		}
		if(is_array($missingReview))
		{
			foreach($missingReview as $m)
			{
				// JFM 22_10_13 Replaced with below SqlLQ('INSERT INTO dr_review (ca,msn,review_profile) VALUES ("'.$GET['ca'].'","'.$msn.'","'.$reviewProfile.'")');
				SqlLQ('INSERT INTO dr_review (msn,review_profile) VALUES ("'.$msn.'","'.$reviewProfile.'")');
				$reviewID=SqlQ('SELECT LAST_INSERT_ID() AS reviewID');
				SqlLQ('INSERT INTO dr_review_applicability (review,ca) VALUES (\''.$reviewID['reviewID'].'\',\''.$GET['ca'].'\')');
			}
		}
		/* JFM 22_10_13 Replaced with below SqlLQ('UPDATE dr_review SET review_configuration_profile="'.$GET['reviewConfig'].'" WHERE ca IN('.$GET['ca'].') AND msn="'.$msn.'" AND review_profile="'.$reviewProfile.'"');
		$review=SqlQ('SELECT * FROM dr_review WHERE ca IN('.$GET['ca'].') AND msn="'.$msn.'" AND review_profile="'.$reviewProfile.'"');*/
		
		SqlLQ('UPDATE dr_review AS r 
				INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
					SET review_configuration_profile="'.$GET['reviewConfig'].'" WHERE ca IN('.$GET['ca'].') AND msn="'.$msn.'" AND review_profile="'.$reviewProfile.'"');
		
	}elseif(!isset($GET['review_configuration_profile']))
	{
		$review['review_configuration_profile']=$GET['reviewConfig'];
	}
}

$revConfigColor=array('#FFFFFF','#FFFBCC','#F3CBCB','#CCEBFF');

//
// Goes here if looking at specific review.
//

if(isset($GET['ca']))
{
	if(isset($GET['msn'])) $msn=$GET['msn'];
	else $msn=getFilter('msn','filter',0,$SESSION);

	//JFM 16_09_13				
	$reviewID=SqlLi('SELECT review_id, validation_date, continuous_assessment, inherited
						FROM dr_review AS r
							INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
							INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
						WHERE rp.review_profile_id='.$reviewProfile.'
						AND ra.ca IN ('.$GET['ca'].')
						AND r.msn='.$msn);

	//JFM 19_07_16
	if($reviewID[0]['inherited'] != 0)
	{
		$inheritedReviewInfo = SqlLi('SELECT DISTINCT 	pro.program,
														coe.coe,
														msn.msn,
														per.perimeter,
														wp.wp,
														ca.ca
										FROM dr_review AS r
										INNER JOIN dr_review_profile AS rp ON rp.review_profile_id = r.review_profile
										INNER JOIN c_program AS pro ON pro.program_id = rp.program
										INNER JOIN c_coe AS coe ON coe.coe_id = rp.coe
										INNER JOIN c_msn AS msn ON msn.msn_id = r.msn
										INNER JOIN c_perimeter AS per ON per.program = pro.program_id
										INNER JOIN dr_review_applicability AS app ON app.review=r.review_id
										INNER JOIN c_ca AS ca ON ca.ca_id = app.ca
										INNER JOIN c_cawp AS cawp ON cawp.ca=ca.ca_id
										INNER JOIN c_wp AS wp ON wp.wp_id = cawp.wp
										WHERE review_id = '.$reviewID[0]['inherited']);

		$inheritedReviewCriteria = SqlAsLi('SELECT DISTINCT rch.*, rc.review_criterion_id
											FROM dr_review_criterion_history AS rch
											INNER JOIN dr_review_configuration AS rconf ON rconf.criterion = rch.criterion
											INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
											AND rch.criterion_valid_from <= "'.$reviewID[0]['validation_date'].'"
											AND rch.criterion_valid_from != "0000-00-00 00:00:00"
											AND rconf.review = '.$reviewID[0]['inherited'].'
											ORDER BY rconf.position ASC','review_criterion_id');
	}
					
	//JFM 09_04_14	
         /**
          * Fix for : Bug-7
          * Version :4.1
          * Fixed by : Infosys Limited 
          * Criteria group and criteria id in design review management display in  lexicon sorted
         */
        $criteria = SqlAsLi('SELECT DISTINCT rgh.review_group,GROUP_CONCAT(rgh.review_group_description ORDER BY rgh.review_group_history_id DESC SEPARATOR \'---!---\') AS review_group_description, rgh.review_group_position,
										rconf.disabled, rconf.position AS criterion_position,
										rc.review_criterion_id, rch.criterion_name, rch.criterion_description, rch.criterion_user_id, rch.criterion_showstopper, rch.criterion_mg_elements, rch.criterion_moc, rch.criterion_valid_from,
										GROUP_CONCAT(g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS criterion_reference
						FROM dr_review_criterion_history AS rch 
							INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
							INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
							INNER JOIN dr_review_group_history  AS rgh 		ON rgh.review_group=rg.group_id
																			AND review_group_valid_from <= "'.$reviewID[0]['validation_date'].'" 
							INNER JOIN dr_review_configuration	AS rconf	ON rc.review_criterion_id = rconf.criterion
							INNER JOIN dr_review				AS r		ON r.review_id=rconf.review
							INNER JOIN dr_review_applicability	AS ra		ON r.review_id=ra.review
							INNER JOIN dr_review_profile		AS rp 		ON rp.review_profile_id=r.review_profile
							LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
							LEFT  JOIN c_grams					AS g		ON	rca.applicability=g.grams_id
																			AND	rca.object='.$SESSION['object']['grams_id'].'
																			AND rca.review_criterion_applicability_valid_from <= "'.$reviewID[0]['validation_date'].'"
						WHERE rp.review_profile_id='.$reviewProfile.'
						AND ra.ca IN ('.$GET['ca'].')
						AND r.msn='.$msn.'
						AND rch.criterion_valid_from <= "'.$reviewID[0]['validation_date'].'"
						AND rch.criterion_valid_from != "0000-00-00 00:00:00"
						GROUP BY rch.criterion_validity_id
						','review_criterion_id'); //DEFAULT - GOOD! JFM 04_03_14 - 11_03_14
//End of bug 7					   	
	//JFM 27_08_13
	$action=SqlBDAsArr('SELECT act.criteria,act.action_status,COUNT(DISTINCT act.action_id) AS action_count
					FROM dr_action AS act
						INNER JOIN dr_action_applicability AS aap ON act.action_id=aap.action
						INNER JOIN dr_review_configuration AS rconf ON rconf.criterion=act.criteria
						INNER JOIN dr_review as r ON r.review_id=rconf.review 
					WHERE act.msn="'.$msn.'"
						AND aap.ca IN ('.$GET['ca'].')
						AND r.review_profile="'.$reviewProfile.'"
					GROUP BY act.criteria,act.action_status','criteria','action_status');
	
	function item8888($item) { return $item['review_id']; }
	$reviewIdsMap=array_map('item8888', $reviewID);
	$allCas=SqlSLi('SELECT ca FROM dr_review_applicability WHERE review IN ('.implode(',',$reviewIdsMap).')','ca');

	//JFM 27_08_13 - JFM 24_03_14
	$criteriaStatusQry=mysql_query('SELECT DISTINCT s.review_criteria,s.ca,s.criteria_status_id,s.criteria_status,s.criteria_focal_point,s.criteria_comments, s.criteria_planned, GROUP_CONCAT(DISTINCT csp.provider) AS provider, GROUP_CONCAT(DISTINCT vl.validator) AS stakeholder
									FROM c_ca AS ca
										LEFT JOIN dr_criteria_status AS s ON ca.ca_id=s.ca
										LEFT JOIN dr_criteria_status_provider AS csp ON csp.criteria_status=s.criteria_status_id
										LEFT JOIN dr_validation_loop_structure AS vl ON vl.applicability=s.criteria_status_id
																					AND vl.object='.$SESSION['object']['criteria_status_id'].'
										INNER JOIN dr_review_configuration AS c ON s.review_criteria=c.criterion
										INNER JOIN dr_review AS g ON c.review=g.review_id
									WHERE s.msn="'.$msn.'"
									AND ca.ca_id IN('.implode(',',$allCas).')
									AND g.review_profile="'.$reviewProfile.'"
									GROUP BY review_criteria',$p12) or die(mysql_error());

	while($c=mysql_fetch_assoc($criteriaStatusQry))
	{
		foreach($c as $k=>$v)
		{
			$criteriaStatus[$c['review_criteria']][$GET['ca']][$k]=$v;
		}
	}
		
	if(is_array($criteriaStatus))
	{
		foreach($criteriaStatus as $k=>&$v)
		{
			$criteria[$k]['criteria_status_id']=combinedResult($v,'criteria_status_id','id',$SESSION);
			$criteria[$k]['criteria_status']=combinedResult($v,'criteria_status','status',$SESSION);
			$criteria[$k]['criteria_focal_point']=combinedResult($v,'criteria_focal_point','text',$SESSION);
			$criteria[$k]['criteria_comments']=combinedResult($v,'criteria_comments','text',$SESSION);
			$criteria[$k]['criteria_planned']=(combinedResult($v,'criteria_planned','text',$SESSION)=='0000-00-00')?'':combinedResult($v,'criteria_planned','text',$SESSION);
			$criteria[$k]['provider']=combinedResult($v,'provider','text',$SESSION);
			$criteria[$k]['stakeholder']=combinedResult($v,'stakeholder','text',$SESSION);
		}
	}			
}
else
{

//
// Goes here if admin > master list management.
//

	//JFM TODO - Put this back in
	if($reviewPositionRepaired!=1){
		repairReviewPosition($reviewProfile);
	}								
	//Bug-7							
	$criteria=SqlAsLi('SELECT DISTINCT rgh.review_group,rgh.review_group_description,rgh.review_group_position,
										rc.review_criterion_id, rch.criterion_name, rch.criterion_description, rch.criterion_user_id, rch.criterion_showstopper, rch.criterion_moc, rch.criterion_valid_from,
										GROUP_CONCAT(rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS criterion_reference
						FROM dr_review_criterion_history AS rch 
							INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
							INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
							INNER JOIN dr_review_group_history 	AS rgh 		ON rgh.review_group=rg.group_id
							INNER JOIN dr_review_master			AS rm		ON rc.review_criterion_id=rm.criterion
							INNER JOIN dr_review_master_history	AS rmh		ON rm.review_master_id=rmh.review_master
							INNER JOIN dr_review_profile		AS rp 		ON rp.review_type=rm.review_type
							LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
							LEFT  JOIN c_grams					AS g		ON	rca.applicability=g.grams_id
																			AND	rca.object='.$SESSION['object']['grams_id'].'
																			AND rca.review_criterion_applicability_valid_from != "0000-00-00 00:00:00"
						WHERE rp.review_profile_id='.$reviewProfile.'
						AND rch.criterion_valid_from != "0000-00-00 00:00:00"
						AND rgh.review_group_valid_to="0000-00-00 00:00:00"
						AND rmh.review_master_valid_to="0000-00-00 00:00:00"
						GROUP BY rch.criterion_validity_id
					','review_criterion_id'); //JFM 03_12_13
								 
	$reviewId[0]='M';
}

if($review['review_configuration_profile']!=0 && $review['review_configuration_profile']!='mixed'){
	/*JFM TODO
	$revConfig=SqlAsArr('SELECT rc.criteria,rc.review_configuration
		FROM dr_review_configuration AS rc
			INNER JOIN dr_review_configuration_profile AS rcp ON rc.review_configuration_profile=rcp.review_configuration_profile_id
		WHERE rc.review_configuration_profile="'.$review['review_configuration_profile'].'"
	','criteria','review_configuration');*/
	
	if(is_array($revConfig)){
		foreach($revConfig as $k=>&$v){
			$radioConfig[$k][$v]=' checked';
		}
	}
}else $disabledRadio=' disabled';

$reviewConfigurationProfileTxt=$revConfigList[$review['review_configuration_profile']];
$viewOlnyRelevantCriteria=(isset($GET['ca']))?getFilter('relevant_criteria','view',0,$SESSION):0;
$reviewTypeName=SqlLi('SELECT rt.review_type FROM dr_review_type AS rt INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id WHERE rp.review_profile_id='.$reviewProfile);

if($included!=1)echo'OK|||';

$canEdit=0;

if(checkPermission('review_profile_id','edit',$GET['review'],'check',$SESSION)==1 || checkPermission('review_profile_id','create',$GET['review'],'check',$SESSION)==1 ||
	checkPermission('dr_review_profile_general','edit',0,'check',$SESSION)==1 || checkPermission('dr_review_profile_general','create',0,'check',$SESSION)==1)
{
	$canEdit=1;
}

if(!empty($criteria))
{
	if(isset($GET['ca']))
	{
		//--------------------------------------------------------------------------------------------------
		// EC INFO
		//--------------------------------------------------------------------------------------------------

		$lastGroup=0;
		$totalGroups = 2;
		$calculationArrayTotalsForEC=array();
		$calculationArrayGroupsForEC=array();
		$priorityMap=array('Low' => 1, 'Medium' => 2, 'High' => 3);

		$calculationArrayTotalsAll=array('review_total' => 0, 0 => 0, 1 => 0, 2 => 0, 3 => 0);
		$calculationArrayGroupsAll=array();

		foreach($criteria as $q=>$c)
		{
			$groupFix = split('---!---', $c['review_group_description']);
			$criteria[$q]['review_group_description'] = $groupFix[0];

			$calculationArrayTotalsAll['review_total']++;
			if($c['criteria_status'] != '' && isset($c['criteria_status']) && $c['criteria_status']<4)
			{
				$calculationArrayTotalsAll[$c['criteria_status']]++;
			}


			$calculationArrayTotalsForEC['review_total'] += $priorityMap[$c['criterion_moc']];

			if($c['criteria_status'] != '' && isset($c['criteria_status']) && $c['criteria_status']>0 && $c['criteria_status']<4)
				$calculationArrayTotalsForEC['assessment_total'] += $priorityMap[$c['criterion_moc']];
			
			if($lastGroup!=$c['review_group'])
			{
				$totalGroups++;
				$lastGroup=$c['review_group'];
				$calculationArrayGroupsForEC[$lastGroup]['review_group_description'] = $c['review_group_description'];
				$calculationArrayGroupsForEC[$lastGroup]['group_total']=0;

				$calculationArrayGroupsAll[$lastGroup]['review_group_description'] = $c['review_group_description'];
				$calculationArrayGroupsAll[$lastGroup]['group_total']=0;
				$calculationArrayGroupsAll[$lastGroup][0]=0;
				$calculationArrayGroupsAll[$lastGroup][1]=0;
				$calculationArrayGroupsAll[$lastGroup][2]=0;
				$calculationArrayGroupsAll[$lastGroup][3]=0;
			}

			$calculationArrayGroupsAll[$lastGroup]['group_total']++;
			if($c['criteria_status'] != '' && isset($c['criteria_status']) && $c['criteria_status']<4)
			{
				$calculationArrayGroupsAll[$lastGroup][$c['criteria_status']]++;
			}

			$calculationArrayGroupsForEC[$lastGroup]['group_total'] += $priorityMap[$c['criterion_moc']];
			
			if($c['criteria_status'] != '' && isset($c['criteria_status']) && $c['criteria_status']>0)
				$calculationArrayGroupsForEC[$lastGroup]['assessment_total'] += $priorityMap[$c['criterion_moc']];

		}

		if($calculationArrayTotalsForEC['review_total'] != 0)
			$overallTotalPercentage = number_format((float)(($calculationArrayTotalsForEC['assessment_total']/$calculationArrayTotalsForEC['review_total'])*100), 2, '.', '');
		$colour = '#ef343f';
		if($overallTotalPercentage > 90) $colour = '#81c341';
		else if($overallTotalPercentage > 80) $colour = '#f8d707';

		?><div style="float:left; display:inline;"><?php
			?><div class="tableTitle" style="padding-top:20px;">Overall Information:</div><?php

			?><div style="float:right;display:inline;"><?php
				//JFM 19_07_16
				if(!empty($inheritedReviewInfo))
				{
					?><table class="criteriaTable" align="center" cellspacing="0" cellpadding="5" style="width:500px; padding-left:20px;"><?php
						?><tr class="tableGroup"><?php
							?><td colspan="2">Checklist Information</td><?php
						?></tr><?php
						?><tr><?php
							?><td class="paramDef">Imported From</td><?php
							?><td><?=$inheritedReviewInfo[0]['program']?> - <?=$inheritedReviewInfo[0]['coe']?> - <?=$inheritedReviewInfo[0]['msn']?> - <?=$inheritedReviewInfo[0]['perimeter']?> - <?=$inheritedReviewInfo[0]['wp']?> - <?=$inheritedReviewInfo[0]['ca']?></td><?php
						?></tr><?php

						if(!empty($inheritedReviewCriteria) && !empty($criteria))
						{
							$criteriaRemoved		= array_diff_key($inheritedReviewCriteria, $criteria);
							$criteriaAdded			= array_diff_key($criteria, $inheritedReviewCriteria);

							if(!empty($criteriaRemoved) && !empty($criteriaAdded)) $inheritedReviewDiff=array_merge($criteriaRemoved, $criteriaAdded);
							else if (!empty($criteriaRemoved)) $inheritedReviewDiff=$criteriaRemoved;
							else if (!empty($criteriaAdded)) $inheritedReviewDiff=$criteriaAdded;
							
							?><tr><?php
								?><td class="paramDef">Checklist Changes</td><?php
								?><td><?=count($inheritedReviewDiff)?></td><?php
							?></tr><?php

							if(count($inheritedReviewDiff) > 0)
							{
								?><tr class="tableGroup prmRow"><?php
									?><td id="moreInfo2" colspan="2" style="text-align:center;" onclick="colapseSidebar('criteriaDiffMoreInfo')">&#9660; More Info &#9660;</td><?php //JFM 17_11_15
								?></tr><?php
							}

						}

					?></table><?php

					if(count($inheritedReviewDiff) > 0)
					{
						?><table class="criteriaTable" id="criteriaDiffMoreInfo" align="center" cellspacing="0" cellpadding="5" style="width:500px; padding-left:20px; display:none;"><?php
							?><tr class="infoRow"><?php
								?><td class="paramDef">Action</td><?php
								?><td class="paramDef"><?=$SESSION['table']['cat']['cat']['criterion_user_id']['title']?></td><?php
								?><td class="paramDef"><?=$SESSION['table']['cat']['cat']['criterion_name']['title']?></td><?php
								?><td class="paramDef"><?=$SESSION['table']['cat']['cat']['criterion_moc']['title']?></td><?php
							?></tr><?php
							foreach ($inheritedReviewDiff as $name => $value) 
							{
								if(array_key_exists($value['criterion'], $inheritedReviewCriteria))
									$inheritedReviewAction = "Removed";
								else
									$inheritedReviewAction = "Added";

								?><tr class="infoRow"><?php
									?><td><?=$inheritedReviewAction?></td><?php
									?><td><?=$value['criterion_user_id']?></td><?php
									?><td><?=$value['criterion_name']?></td><?php
									?><td><?=$value['criterion_moc']?></td><?php
								?></tr><?php
							}
						?></table><?php
					}
				}
			?></div><?php

			?><div style="float:left; display:inline;"><?php
				?><table class="criteriaTable" align="center" cellspacing="0" cellpadding="5" style="width:300px;"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="6">Degree of fulfilment</td><?php
					?></tr><?php
					?><tr><?php

						?></tr><?php
						?><tr><?php
							?><td class="paramDef"></td><?php
							if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][0] == 0)
							{
								?><td class="paramDef">Red</td><?php
							}
							if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][1] == 0)
							{
								?><td class="paramDef">Amber</td><?php
							}
							if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][2] == 0)
							{
								?><td class="paramDef">Green</td><?php
							}
							if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][3] == 0)
							{
								?><td class="paramDef">Blue</td><?php
							}
							?><td class="paramDef">Total</td><?php
							if(!empty($overallTotalPercentage))
							{
								?><td class="paramDef">%</td><?php
							}
						?></tr><?php
						?><tr><?php

						?><td class="paramDef" style="width:200px;">Overall Assessment</td><?php
						if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][0] == 0)
						{
							?><td style="color:#ef343f;"><?=$calculationArrayTotalsAll[0]?> </td><?php
						}
						if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][1] == 0)
						{
							?><td style="color:#f8d707;"><?=$calculationArrayTotalsAll[1]?> </td><?php
						}
						if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][2] == 0)
						{
							?><td style="color:#81c341;"><?=$calculationArrayTotalsAll[2]?> </td><?php
						}
						if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][3] == 0)
						{
							?><td style="color:#0088cf;"><?=$calculationArrayTotalsAll[3]?> </td><?php
						}

						?><td><?=$calculationArrayTotalsAll['review_total']?></td><?php

						if(!empty($overallTotalPercentage))
						{
							?><td style="color:#000"><?=$overallTotalPercentage?>%</td><?php
						}
					?></tr><?php
					?><tr class="tableGroup prmRow"><?php
						?><td id="moreInfo" colspan="6" style="text-align:center;" onclick="colapseSidebar('criteriaTableMoreInfo')">&#9660; More Info &#9660;</td><?php //JFM 17_11_15
					?></tr><?php
				?></table><?php

				?><table class="criteriaTable" id="criteriaTableMoreInfo" align="center" cellspacing="0" cellpadding="5" style="width:300px; display:none;"><?php
					foreach ($calculationArrayGroupsAll as $groupName => $groupValue) 
					{
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:200px;"><?=$groupValue['review_group_description']?></td><?php
							if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][0] == 0)
							{
								?><td style="color:#ef343f;"><?=$calculationArrayGroupsAll[$groupName][0]?></td><?php
							}
							if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][1] == 0)
							{
								?><td style="color:#f8d707;"><?=$calculationArrayGroupsAll[$groupName][1]?></td><?php
							}
							if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][2] == 0)
							{
								?><td style="color:#81c341;"><?=$calculationArrayGroupsAll[$groupName][2]?></td><?php
							}
							if($SESSION['disabled_statues'][$SESSION['object']['criteria_status']][3] == 0)
							{
								?><td style="color:#0088cf;"><?=$calculationArrayGroupsAll[$groupName][3]?></td><?php
							}
							?><td><?=$calculationArrayGroupsAll[$groupName]['group_total']?></td><?php
							if(!empty($overallTotalPercentage))
							{
								$overallTotalPercentage = number_format((float)(($calculationArrayGroupsForEC[$groupName]['assessment_total']/$calculationArrayGroupsForEC[$groupName]['group_total'])*100), 2, '.', '');
								$colour = '#ef343f';
								if($overallTotalPercentage > 90) $colour = '#81c341';
								else if($overallTotalPercentage > 80) $colour = '#f8d707';
								?><td style="color:<?=$colour?>;"><?=$overallTotalPercentage?>%</td><?php
							}
						?></tr><?php
					}
				?></table><?php
			?></div><?php
		?></div><?php
		
		?><div class="sp" style="height:40px;"></div><?php
	}


	?><div class="tableTitle" style="display:inline; float:left;"><?php

	?><input id="refresh" class="refresh" style="position:relative;" type="button" onclick="reloadSideElement(); this.blur();" value="&#8634;"><?php

	?><div class="popUpMenu" id="popUpCatDiv_Review"></div>&nbsp;Criteria Table:</div><?php

	if((!$reviewValidated && !$reviewValidationCommencing) || checkPermission('superadmin','superadmin',0,'check',$SESSION)==1) 
	{
		/* JFM 28_10_15 ?><input class="popUpBtn" id="popUpBtn_Review" onClick="popUpOpt('cat',['Review',<?=$reviewProfile?>,'<?=$reviewTypeName[0]['review_type']?>','<?=$reviewId[0]?>','<?=$modifying?>']);"type="button"value="&#8801;"><?php */
		
		//opts='&menuType='+p[0]+'&criterionId='+p[1]+'&reviewTypeName='+p[2]+'&reviewProfile='+p[3]+'&reviewID='+p[4]+'&criterionValid='+p[5]+'&table_cache_id='+p[6]; //JFM 09_09_13 - JFM 11_09_13 - JFM 23_09_13 - JFM 28_10_13

		$changeWhiteBGCloseFormMethod='';
		if($reviewId[0]=='M')  							$changeWhiteBGCloseFormMethod="changeWhiteBGCloseFormMethod('reviewConfigContainer');";
		else if($modifying && $modifying!='undefined') 	$changeWhiteBGCloseFormMethod="changeWhiteBGCloseFormMethod('sideValidationContainer');";
		else if($reviewId[0])  							$changeWhiteBGCloseFormMethod="changeWhiteBGCloseFormMethod('sideReviewContainer');";
		/*
		* Fix for : US#106 Improvement: Freeze Function for completed DR 
		* Added for freeze/unfreeze function
		* Version: 4.3
		* Fixed By: Infosys Limited
		*/
		if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
			?><div style="float:right; clear:none; display:inline;padding-top:15px;"><input class="stdBtn" id="manageCriteria" onClick="openForm('criteriaGroups','list_name=cat&review_profile=<?=$reviewProfile?>&reviewTypeName=<?=$reviewTypeName[0]['review_type']?>&reviewID=<?=$reviewId[0]?>',false,'POST'); openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$reviewProfile?>&reviewTypeName=<?=$reviewTypeName[0]['review_type']?>&reviewID=<?=$reviewId[0]?>'); <?=$changeWhiteBGCloseFormMethod?> "type="button"value="Manage Criteria &#9658;"></div><?php
		} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
			?><div style="float:right; clear:none; display:inline;padding-top:15px;" class="disablediv"><input class="stdBtn" id="manageCriteria" onClick="openForm('criteriaGroups','list_name=cat&review_profile=<?=$reviewProfile?>&reviewTypeName=<?=$reviewTypeName[0]['review_type']?>&reviewID=<?=$reviewId[0]?>',false,'POST'); openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$reviewProfile?>&reviewTypeName=<?=$reviewTypeName[0]['review_type']?>&reviewID=<?=$reviewId[0]?>'); <?=$changeWhiteBGCloseFormMethod?> "type="button"value="Manage Criteria &#9658;"></div><?php
		} else {
			?><div style="float:right; clear:none; display:inline;padding-top:15px;"><input class="stdBtn" id="manageCriteria" onClick="openForm('criteriaGroups','list_name=cat&review_profile=<?=$reviewProfile?>&reviewTypeName=<?=$reviewTypeName[0]['review_type']?>&reviewID=<?=$reviewId[0]?>',false,'POST'); openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$reviewProfile?>&reviewTypeName=<?=$reviewTypeName[0]['review_type']?>&reviewID=<?=$reviewId[0]?>'); <?=$changeWhiteBGCloseFormMethod?> "type="button"value="Manage Criteria &#9658;"></div><?php
		}
	} 
	if(isset($GET['ca']))
					{?>
	
	<div class="newCriteria" style="float:left;clear: both;display:inline;padding-left: 30px;padding-bottom: 10px;"> 
	<span title="New Criteria" style="color:#669900;font-size: 16px;">&#9830; </span><span style="color:#669900;font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 12px;"> - New Criteria</span>
	<span title="Modify Criteria" style="color:#cc9900;font-size: 16px;">&#9830; </span><span style="color:#cc9900;font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 12px;"> - Modify Criteria</span>
	</div>
					<?php  }
					
						
	//JFM 27_08_13 - START - All of the column names have been changed below.
	/*?><div style="position:relative;float:left;clear:both;z-index:-1;"><?php*/
		?><table class="criteriaTable"id="criteriaTable" cellspacing="0"><?php
			$lastGroup=0;
			$firstRow=0;
			$replaceString=array('\r','\n','\r\n',chr(10),chr(13));
			$previousCriteria=0; //JFM 11_03_14
			$previousCriteriaPosition=0; //JFM 11_03_14
			//$reviewLocation=$msn.'&ca='.$GET['ca'];
			foreach($criteria as $q=>$c)
			{
				$array1=explode(", ",$c['criterion_reference']);
						
				$criteria[$q]['criterion_reference']='';
			
				foreach($array1 as $a1)
				{
					$array2=explode("---",$a1);

					if($array2[1]=='0000-00-00 00:00:01' && $criteria[$q]['criterion_valid_from']=="0000-00-00 00:00:00") continue;
					if($array2[2]=='0000-00-00 00:00:00' && $criteria[$q]['criterion_valid_from']!="0000-00-00 00:00:00") continue;
					if($reviewID[0]['validation_date']=="9999-12-31 00:00:00" && $array2[1]!='0000-00-00 00:00:00'  && $array2[1]!='0000-00-00 00:00:01') continue;
					else 
					{
						if(empty($criteria[$q]['criterion_reference'])) $criteria[$q]['criterion_reference']=$array2[0];
						else $criteria[$q]['criterion_reference']=$criteria[$q]['criterion_reference'].', <br />'.$array2[0];
					}
				}

				if(isset($GET['ca']))
				{
					$criteriaLocation=$GET['ca'].'&review_criteria_id='.$c['review_criterion_id'];
					$criteriaComments=str_replace($replaceString,'<br>',str_replace('\'','"',$c['criteria_comments']));
					$criteriaDescription=str_replace($replaceString,'<br>',str_replace('\'','"',$c['criterion_description'])); //JFM 06_01_14
					$criteriaMgElements=str_replace($replaceString,'<br>',str_replace('\'','"',$c['criterion_mg_elements'])); //JFM 30_10_14
					$commentsLenght=strlen($criteriaComments);
					$comments=($commentsLenght>25)?substr($criteriaComments,0,25).'&#8801;':$criteriaComments;
					$actionCount=$c['review_red_action']+$c['review_amber_action']+$c['review_green_action'];
				}
				if($lastGroup!=$c['review_group'])
				{
					$lastGroup=$c['review_group'];
					?><tr class="tableGroup"id="criteriaRow-<?=$c['review_group']?>-0"><?php
						//if($firstRow==0){
							if(isset($GET['ca']))
							{
								if($canEdit) { if((!$reviewValidationCommencing && !$reviewValidated) || checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){ ?><td></td><?php } }
								?><td width="5%"><?=$SESSION['table']['cat']['cat']['criterion_user_id']['title']?></td><?php
								?><td width="25%" colspan="2"><?=$c['review_group_description']?></td><?php
								?><td width="25%"><?=$SESSION['table']['cat']['cat']['criterion_moc']['title']?></td><?php
								if(getFilter('area','filter',0,$SESSION)==3) { ?><td width="0%">Elem.</td><?php }
								?><td width="0%"><?=$SESSION['table']['cat']['cat']['criterion_description']['title']?></td><?php
								if($reviewValidated && !$reviewValidationCommencing) { ?><td width="25%">Comments/Highlights</td><?php }
								?><td width="0%">Refer.</td><?php
								?><td width="0%"><?=$SESSION['table']['cat']['cat']['criterion_showstopper']['title']?></td><?php
								if($reviewValidated && !$reviewValidationCommencing) { ?><td colspan="5">Actions</td><?php }
								//JFM 27_03_14
								if($canEdit) { ?><td></td><?php }
								if($reviewID[0]['continuous_assessment']==1) { ?><td width="13%">Cont. Ass.</td><?php }
							}
							else
							{
								?><td><input class="popUpBtn" id="popUpBtn_<?=$c['review_group']?>_0" onClick="popUpOpt('crm',[<?=$c['review_group']?>,0]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCrmDiv_<?=$c['review_group']?>_0"></div></td><?php
								?><td width="12%"><?=$SESSION['table']['cat']['cat']['criterion_user_id']['title']?></td><?php
								?><td width="44%"><?=$c['review_group_description']?></td><?php
								?><td width="44%"><?=$SESSION['table']['cat']['cat']['criterion_moc']['title']?></td><?php
								if(getFilter('area','filter',0,$SESSION)==3) { ?><td width="0%">Elem.</td><?php }
								?><td width="44%"><?=$SESSION['table']['cat']['cat']['criterion_description']['title']?></td><?php
								?><td width="0%"><?=$SESSION['table']['cat']['cat']['criterion_showstopper']['title']?></td><?php
								?><td title="Showstopper">S</td><?php
							}
					?></tr><?php
					$previousCriteria=0; //JFM 11_03_14
					$previousCriteriaPosition=0; //JFM 11_03_14
				}
				$rowColor;
				if(in_array($viewAsUserId, explode(',', $c['provider']))) $rowColor=1;
				else if(in_array($viewAsUserId, explode(',', $c['stakeholder']))) $rowColor=3;
				else $rowColor=0;

				$cellColor;
				if($c['criteria_planned']!='' && $c['criteria_planned'] < date('Y-m-d') && $c['criteria_status']!=3) $cellColor=2;
				else if (in_array($viewAsUserId, explode(',', $c['provider']))) $cellColor=1;
				else if(in_array($viewAsUserId, explode(',', $c['stakeholder']))) $cellColor=3;
				else $cellColor=0;
		?>
				<tr class="infoRow" id="criteriaRow-<?=$c['review_group']?>-<?=$c['review_criterion_id']?>" style="background-color:<?=$revConfigColor[$rowColor]?>;"><?php
					
				
				if(isset($GET['ca']))
					{
						/*
							* Fix for : US#113.1 Adding new criteria from Masterlist 
							* Adding new criteria and hightlight the newly added criteria
							* Version: 4.6
							* Fixed By: Infosys Limited
						*/
						
						$inheritedReviewDetails = SqlQ('SELECT inherited,validation_complete FROM dr_review WHERE review_id='.$reviewId[0]);
						$dr_reviewDate = SqlQ('SELECT validation_date FROM dr_review WHERE review_id='.$inheritedReviewDetails['inherited']);
						if(!empty($inheritedReviewDetails)){
						$reviewCriteria=SqlQ('SELECT review, criterion, position FROM dr_review_configuration WHERE review='.$inheritedReviewDetails['inherited'].' AND criterion='.$c['review_criterion_id']);
						}
						$modifyCriteria = SqlQ('SELECT  rch.criterion,rch.criterion_user_id,rch.criterion_name,rch.criterion_description,rch.criterion_valid_from,rch.criterion_reference,rch.criterion_showstopper,rch.criterion_position FROM dr_review_criterion_history AS rch 
							INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
							INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
							INNER JOIN dr_review_group_history 	AS rgh 		ON rgh.review_group=rg.group_id
							INNER JOIN dr_review_master			AS rm		ON rc.review_criterion_id=rm.criterion
							INNER JOIN dr_review_master_history	AS rmh		ON rm.review_master_id=rmh.review_master
							INNER JOIN dr_review_profile		AS rp 		ON rp.review_type=rm.review_type
							INNER JOIN dr_review		AS dr 		ON rp.review_profile_id =dr.review_profile
							LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
						WHERE  dr.review_id='.$inheritedReviewDetails['inherited'].' AND rch.criterion='.$c['review_criterion_id'].'
						GROUP BY rch.criterion_validity_id');
						$modifyCriteriaCount = SqlSLi('SELECT  rch.criterion,rch.criterion_user_id,rch.criterion_name,rch.criterion_description,rch.criterion_reference,rch.criterion_showstopper,rch.criterion_position FROM dr_review_criterion_history AS rch 
							INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
							INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
							INNER JOIN dr_review_group_history 	AS rgh 		ON rgh.review_group=rg.group_id
							INNER JOIN dr_review_master			AS rm		ON rc.review_criterion_id=rm.criterion
							INNER JOIN dr_review_master_history	AS rmh		ON rm.review_master_id=rmh.review_master
							INNER JOIN dr_review_profile		AS rp 		ON rp.review_type=rm.review_type
							INNER JOIN dr_review		AS dr 		ON rp.review_profile_id =dr.review_profile
							LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
						WHERE  dr.review_id='.$inheritedReviewDetails['inherited'].' AND dr.validation_date !="9999-12-31 00:00:00" AND rch.criterion='.$c['review_criterion_id'].'
						GROUP BY rch.criterion_validity_id');
						
						$reviewDate = new DateTime($dr_reviewDate['validation_date']);
						$criteriaDate = new DateTime($c['criterion_valid_from']);
						
						/// End of US#113.1
						
						$redAction=$action[$c['review_criterion_id']][0]['action_count'];
						$amberAction=$action[$c['review_criterion_id']][1]['action_count'];
						$greenAction=$action[$c['review_criterion_id']][2]['action_count'];
						$blueAction=$action[$c['review_criterion_id']][3]['action_count']; //JFM 27_03_14
						/*
							* Fix for : US#106 Improvement: Freeze Function for completed DR 
							* Added for freeze/unfreeze function
							* Version: 4.3
							* Fixed By: Infosys Limited
						*/
						if($canEdit)
						{
							if((!$reviewValidationCommencing && !$reviewValidated) || checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){ 
								if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
									?><td><input class="popUpBtn"id="popUpBtn_<?=$c['review_criterion_id']?>_<?=$GET['ca']?>"onClick="popUpOpt('crt',[<?=$reviewProfile?>,<?=$c['review_criterion_id']?>,'<?=$GET['ca']?>','<?=$reviewId[0]?>','<?=$reviewValidated?>',<?=$previousCriteriaPosition?>,<?=$previousCriteria?>,<?=$c['review_group']?>]);"<?php if($viewOlnyRelevantCriteria==1 && $revConfig[$c['review_criterion_id']]==1){?>style="display:none;"<?php }?>type="button"value="&#8801;"><div class="popUpMenu"id="popUpCrtDiv_<?=$c['review_criterion_id']?>_<?=$GET['ca']?>"></div></td><?php 
								} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
									?><td class="disablediv"><input class="popUpBtn"id="popUpBtn_<?=$c['review_criterion_id']?>_<?=$GET['ca']?>"onClick="popUpOpt('crt',[<?=$reviewProfile?>,<?=$c['review_criterion_id']?>,'<?=$GET['ca']?>','<?=$reviewId[0]?>','<?=$reviewValidated?>',<?=$previousCriteriaPosition?>,<?=$previousCriteria?>,<?=$c['review_group']?>]);"<?php if($viewOlnyRelevantCriteria==1 && $revConfig[$c['review_criterion_id']]==1){?>style="display:none;"<?php }?>type="button"value="&#8801;"><div class="popUpMenu"id="popUpCrtDiv_<?=$c['review_criterion_id']?>_<?=$GET['ca']?>"></div></td><?php 
								} else {
									?><td><input class="popUpBtn"id="popUpBtn_<?=$c['review_criterion_id']?>_<?=$GET['ca']?>"onClick="popUpOpt('crt',[<?=$reviewProfile?>,<?=$c['review_criterion_id']?>,'<?=$GET['ca']?>','<?=$reviewId[0]?>','<?=$reviewValidated?>',<?=$previousCriteriaPosition?>,<?=$previousCriteria?>,<?=$c['review_group']?>]);"<?php if($viewOlnyRelevantCriteria==1 && $revConfig[$c['review_criterion_id']]==1){?>style="display:none;"<?php }?>type="button"value="&#8801;"><div class="popUpMenu"id="popUpCrtDiv_<?=$c['review_criterion_id']?>_<?=$GET['ca']?>"></div></td><?php 
								}
							} //JFM 11_03_14
						}

						//JFM 13_05_16 if($comments!='' || $c['criteria_focal_point']!='' || $redAction!=0 || $amberAction!=0 || $greenAction!=0 || $blueAction!=0 || $reviewID[0]['continuous_assessment']==1)
						//JFM 13_05_16{ //JFM 27_03_14
						if($c['criteria_status']=='')
							//JFM 13_05_16 $c['criteria_status']=0;
							$criteriaStatusImg='b';
						else
							$criteriaStatusImg=$status[$c['criteria_status']];
						/*//JFM 13_05_16}
						else
						{
							$criteriaStatusImg='b';
						}*/
						if(is_array($caArray) && $criteriaStatusImg!='b' && $criteriaStatusImg!='m')
						{
							foreach($caArray as $ca)
							{
								if($criteriaStatus[$c['review_criterion_id']][$ca]['criteria_status']=='')
								{
									//$criteriaStatusImg='m';
									break 1;
								}
							}
						}
						
						$textColor=($viewOlnyRelevantCriteria==1 && $revConfig[$c['review_criterion_id']]==1)?'style="color:#CCCCCC;"':'';

						?><td id="criteria_user_id_<?=$c['review_criterion_id']?>"> <?=$c['criterion_user_id']?><?php 
						if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1) echo ' '.$c['criteria_status_id'];
						?></td><?php
						/*
						* Fix for : US#106 Improvement: Freeze Function for completed DR 
						* Added for freeze/unfreeze function
						* Version: 4.3
						* Fixed By: Infosys Limited
						*/
						if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
							//JFM 24_03_14
						?><td id="criteria_description_<?=$c['review_criterion_id']?>"><img id="criteria_status_<?=$c['review_criterion_id']?>" <?php if(($canEdit || in_array($viewAsUserId, explode(',', $c['provider']))) && ($reviewValidated || $reviewID[0]['continuous_assessment'])) { ?> onClick="criteriaStatusInfo(this,<?=$msn?>,<?=$GET['ca']?>,<?=$c['review_criterion_id']?>,<?=$reviewProfile?>,<?=$reviewID[0]['continuous_assessment']?>,<?=$reviewValidated?>,'new');" style="cursor:pointer;" <?php } ?> height="20"originalStatus="<?=$criteriaStatusImg?>"src="../common/img/<?=(($viewOlnyRelevantCriteria==1 && $revConfig[$c['review_criterion_id']]==1) || $c['disabled'])?'na':$criteriaStatusImg?>20.png"width="20"><?php
						
						if(count($modifyCriteriaCount)>1) {
							if($criteriaDate > $reviewDate)
						{
						if($c['criterion_user_id'] != $modifyCriteria['criterion_user_id'] || $c['criterion_name']!=$modifyCriteria['criterion_name'] || $c['criterion_description']!=$modifyCriteria['criterion_description'] || $c['criterion_reference']!=$modifyCriteria['criterion_reference'] || $c['criterion_showstopper']!=$modifyCriteria['criterion_showstopper'] || $c['criterion_position']!=$modifyCriteria['criterion_position']){ ?>

						<span class="modifyCriteria" title="Modify Criteria" style="color:#cc9900;font-size: 16px;font-weight:bold;">&#9830;</span>
						 <?php 
						}
						}
						}
						 else if($reviewCriteria['criterion'] != $c['review_criterion_id']){  ?>
							<span class="newCriteria" title="New Criteria" style="color:#669900;font-size: 16px;font-weight:bold;">&#9830;</span> 
						<?php }
						 ?></td><?php
						} else if (($reviewInfo[1]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
							//JFM 24_03_14
							?><td class="disablediv" id="criteria_description_<?=$c['review_criterion_id']?>"><img id="criteria_status_<?=$c['review_criterion_id']?>" <?php if(($canEdit || in_array($viewAsUserId, explode(',', $c['provider']))) && ($reviewValidated || $reviewID[0]['continuous_assessment'])) { ?> onClick="criteriaStatusInfo(this,<?=$msn?>,<?=$GET['ca']?>,<?=$c['review_criterion_id']?>,<?=$reviewProfile?>,<?=$reviewID[0]['continuous_assessment']?>,<?=$reviewValidated?>,'new');" style="cursor:pointer;" <?php } ?> height="20"originalStatus="<?=$criteriaStatusImg?>"src="../common/img/<?=(($viewOlnyRelevantCriteria==1 && $revConfig[$c['review_criterion_id']]==1) || $c['disabled'])?'na':$criteriaStatusImg?>20.png"width="20"><?php
						 if(count($modifyCriteriaCount) >1){
							 if($criteriaDate > $reviewDate) {
						 if($c['criterion_user_id']!=$modifyCriteria['criterion_user_id'] || $c['criterion_name']!=$modifyCriteria['criterion_name'] || $c['criterion_description']!=$modifyCriteria['criterion_description'] || $c['criterion_reference']!=$modifyCriteria['criterion_reference'] || $c['criterion_showstopper']!=$modifyCriteria['criterion_showstopper'] || $c['criterion_position']!=$modifyCriteria['criterion_position']){ ?>

						<span class="modifyCriteria" title="Modify Criteria" style="color:#cc9900;font-size: 16px;font-weight:bold;">&#&#9830;;</span>
						 <?php }
						 }
						 }
						 else if($reviewCriteria['criterion'] != $c['review_criterion_id']){  ?>
							<span class="newCriteria" title="New Criteria" style="color:#669900;font-size: 16px;font-weight:bold;">&#9830;</span> 
						<?php } ?>
						 </td><?php
						} else {
							//JFM 24_03_14
							?><td id="criteria_description_<?=$c['review_criterion_id']?>"><img id="criteria_status_<?=$c['review_criterion_id']?>" <?php if(($canEdit || in_array($viewAsUserId, explode(',', $c['provider']))) && ($reviewValidated || $reviewID[0]['continuous_assessment'])) { ?> onClick="criteriaStatusInfo(this,<?=$msn?>,<?=$GET['ca']?>,<?=$c['review_criterion_id']?>,<?=$reviewProfile?>,<?=$reviewID[0]['continuous_assessment']?>,<?=$reviewValidated?>,'new');" style="cursor:pointer;" <?php } ?> height="20"originalStatus="<?=$criteriaStatusImg?>"src="../common/img/<?=(($viewOlnyRelevantCriteria==1 && $revConfig[$c['review_criterion_id']]==1) || $c['disabled'])?'na':$criteriaStatusImg?>20.png"width="20"><?php
					 if(count($modifyCriteriaCount)>1){
						 if(count($modifyCriteriaCount) >1) {
					 if($c['criterion_user_id']!=$modifyCriteria['criterion_user_id'] || $c['criterion_name']!=$modifyCriteria['criterion_name'] || $c['criterion_description']!=$modifyCriteria['criterion_description'] || $c['criterion_reference']!=$modifyCriteria['criterion_reference'] || $c['criterion_showstopper']!=$modifyCriteria['criterion_showstopper'] || $c['criterion_position']!=$modifyCriteria['criterion_position']){ ?>

						<span class="modifyCriteria" title="Modify Criteria" style="color:#cc9900;font-size: 16px;font-weight:bold;">&#9830;</span>
						 <?php }
					 }
					 }
						else if($reviewCriteria['criterion'] != $c['review_criterion_id']){   ?>
							<span class="newCriteria" title="New Criteria" style="color:#669900;font-size: 16px;font-weight:bold;">&#9830;</span> 
						<?php }
						 ?></td><?php
						}
						?><td id="criteria_description_<?=$c['review_criterion_id']?>"<?=$textColor?>><?=$c['criterion_name']?></td><?php
						?><td id="criteria_moc_<?=$c['review_criterion_id']?>"><?=$c['criterion_moc']?></td><?php
						if(getFilter('area','filter',0,$SESSION)==3) { ?><td id="criteria_mg_elements_<?=$c['review_criterion_id']?>" <?php if($criteriaMgElements){ ?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($criteriaMgElements))?>', ABOVE);" <?php } ?> ><?php if($criteriaMgElements){ ?><center>&raquo;</center><?php } ?></td><?php }
						?><td id="criteria_description_<?=$c['review_criterion_id']?>" <?php if($criteriaDescription){ ?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($criteriaDescription))?>', ABOVE);" <?php } ?> ><?php if($criteriaDescription){ ?><center>&raquo;</center><?php } ?></td><?php
						if($reviewValidated && !$reviewValidationCommencing) { ?><td id="criteria_comments_<?=$c['review_criterion_id']?>" ><?php if($criteriaComments){ ?><?=$criteriaComments?><?php } ?></td><?php }
						?><td id="criteria_reference_<?=$c['review_criterion_id']?>"<?=$textColor?> <?php if($criteria[$q]['criterion_reference']){ ?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($criteria[$q]['criterion_reference']))?>', ABOVE);" <?php } ?> ><?php if($criteria[$q]['criterion_reference']){ ?><center>&raquo;</center><?php } ?></td><?php
						?><td id="criterion_showstopper_"<?=$textColor?>><?=drawBooleanValue($c['criterion_showstopper'])?></td><?php
						if($reviewValidated && !$reviewValidationCommencing) 
						{ 
							?><td class="reviewAction r"id="criteria_red_action_<?=$GET['ca']?>_<?=$c['review_criterion_id']?>"onClick="openList(this,'list_name=action&ca=<?=$criteriaLocation?>&action_status=0');"style="color:#900;"><?=$redAction?></td><?php
							?><td class="reviewAction a"id="criteria_amber_action_<?=$GET['ca']?>_<?=$c['review_criterion_id']?>"onClick="openList(this,'list_name=action&ca=<?=$criteriaLocation?>&action_status=1');"style="color:#CC0;"><?=$amberAction?></td><?php
							?><td class="reviewAction g"id="criteria_green_action_<?=$GET['ca']?>_<?=$c['review_criterion_id']?>"onClick="openList(this,'list_name=action&ca=<?=$criteriaLocation?>&action_status=2');"style="color:#060;"><?=$greenAction?></td><?php
							?><td class="reviewAction x"id="criteria_blue_action_<?=$GET['ca']?>_<?=$c['review_criterion_id']?>"onClick="openList(this,'list_name=action&ca=<?=$criteriaLocation?>&action_status=3');"style="color:#609dc9;;"><?=$blueAction?></td><?php //JFM 27_03_14
							$totalAction=$redAction+$amberAction+$greenAction+$blueAction;
							?><td class="reviewAction"id="criteria_total_action_<?=$GET['ca']?>_<?=$c['review_criterion_id']?>"onClick="openList(this,'list_name=action&ca=<?=$criteriaLocation?>');"><?php if($totalAction!=0)echo $totalAction?></td><?php
						}
						if($canEdit)
						{
							if($reviewValidated && !$reviewValidationCommencing) { ?><td><input class="stdBtn" onClick="closeMenu(oldCol); openForm('action','action=new&ca=<?=$GET['ca']?>&review_criteria_id=<?=$c['review_criterion_id']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button"value="Add Action / RID &#9658;"><div class="popUpMenu"id="popUpCrtDiv_<?=$c['review_criterion_id']?>_<?=$GET['ca']?>"></div></td><?php }
							else { ?><td></td><?php }
						}
							if($reviewID[0]['continuous_assessment']==1) { ?><td style="background-color:<?=$revConfigColor[$cellColor]?>;" id="criteria_planned_<?=$c['review_criterion_id']?>"><?=$c['criteria_planned']?></td><?php }
					}
					else
					{
						?><td style="padding:0px 5px;"><input class="popUpBtn"onClick="popUpOpt('crm',[<?=$c['review_group']?>,<?=$c['review_criterion_id']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCrmDiv_<?=$c['review_group']?>_<?=$c['review_criterion_id']?>"></div></td><?php
						?><td id="criteria_user_id_<?=$c['review_criterion_id']?>"><?=$c['criterion_user_id']?></td><?php
						?><td id="criteria_description_<?=$c['review_criterion_id']?>"<?=$textColor?>><?=$c['criterion_name']?></td><?php //JFM 27_08_13
						?><td id="criteria_moc_<?=$c['review_criterion_id']?>"><?=$c['criterion_moc']?></td><?php
						?><td id="criteria_description_<?=$c['review_criterion_id']?>" <?php if($criteriaDescription){ ?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($criteriaDescription))?>', ABOVE);" <?php } ?> ><?php if($criteriaDescription){ ?><center>&raquo;</center><?php } ?></td><?php
						?><td id="criteria_reference_<?=$c['review_criterion_id']?>"<?=$textColor?> <?php if($criteria[$q]['criterion_reference']){ ?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($criteria[$q]['criterion_reference']))?>', ABOVE);" <?php } ?> ><?php if($criteria[$q]['criterion_reference']){ ?><center>&raquo;</center><?php } ?></td><?php //JFM 27_08_13
						?><td id="criterion_showstopper_"<?=$textColor?>><?=drawBooleanValue($c['criterion_showstopper'])?></td><?php //JFM 09_09_13
					}
				?></tr><?php
				$previousCriteria=$c['review_criterion_id']; //JFM 11_03_14
				$previousCriteriaPosition=$c['criterion_position']; //JFM 11_03_14
			}
		?></table><?php
	/*?></div><?php*/
	?><div class="sp"></div><?php
	//JFM 27_08_13 - END
}
else
{
	?><div class="formStdContainer"><?php
		?><div style="font-size:24px; color: #004f6b; text-align:center;">No Criteria Selected<br /><br /><?php
		?><input class="stdBtn" id="manageCriteria" onClick="openForm('criteriaGroups','list_name=cat&review_profile=<?=$reviewProfile?>&reviewTypeName=<?=$reviewTypeName[0]['review_type']?>&reviewID=<?=$reviewId[0]?>',false,'POST'); openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$reviewProfile?>&reviewTypeName=<?=$reviewTypeName[0]['review_type']?>&reviewID=<?=$reviewId[0]?>');"type="button"value="Manage Criteria &#9658;"><?php
	?></div><?php
}

storeSession($SESSION);
?>