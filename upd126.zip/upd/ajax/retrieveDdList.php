<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');

//foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
$GET = cleanArray($_GET); //JFM 28_10_15

//print_r($GET);

switch($GET['store']){
	case 'area': //JFM 03_06_14
		modifyFilter('area','filter',0,$GET['value'],$SESSION,1);
		modifyFilter('program','filter',0,'',$SESSION,1);
		modifyFilter('coe','filter',0,'',$SESSION,1);
		modifyFilter('msn','filter',0,'',$SESSION,1);
	break;
	case 'program':
		modifyFilter('program','filter',0,$GET['value'],$SESSION,1);
		modifyFilter('coe','filter',0,'',$SESSION,1);
		modifyFilter('msn','filter',0,'',$SESSION,1);
	break;
	case 'coe':
		modifyFilter('coe','filter',0,$GET['value'],$SESSION,1);
		modifyFilter('msn','filter',0,'',$SESSION,1);
	break;
	case 'msn':
		modifyFilter('msn','filter',0,$GET['value'],$SESSION,1);
	break;
}

switch($GET['retrieve']){
	case 'program':
		$ddList=allowedSimpleObject('program','program',$SESSION,'c_','program_hidden=0 AND area='.$GET['area'],'view','ASC'); //JFM 03_06_14
	break;
	case 'coe':
		$ddList=allowedSimpleObject('coe','coe',$SESSION,'c_','coe_hidden=0 AND area='.$GET['area'],'view','ASC'); //JFM 09_04_14
	break;
	case 'msn':
		$ddList=allowedMsn($SESSION,$GET['program'],1);
           /// print_r($ddList);
	break;
	case 'perimeter':
		$ddList=SqlAsArr('SELECT perimeter_id,perimeter FROM c_perimeter WHERE program="'.$GET['program'].'"','perimeter_id','perimeter');
            //print_r($ddList);
            
	break;
}

$answer='';
if($GET['show']==1)$answer='show';
else{
	if(is_array($ddList)){
		$firstItem=0;
		generateSimpleResponse($answer,$firstItem,$ddList);
	}
}
echo 'OK|||',$answer;
storeSession($SESSION);

?>