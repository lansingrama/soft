<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){
	if($GET['change_id']!=''){
		switch($GET['mode']){
			case 'status':
				if($GET['change_status']==2){
					SqlLQ('UPDATE dr_change SET change_status="'.$GET['change_status'].'",change_completion=NOW() WHERE change_id="'.$GET['change_id'].'"');
				}else{
					SqlLQ('UPDATE dr_change SET change_status="'.$GET['change_status'].'" WHERE change_id="'.$GET['change_id'].'"');
				}
				$change=SqlQ('SELECT chg.change_status,chg.change_type,chg.change_description,chg.change_completion FROM dr_change AS chg WHERE change_id="'.$GET['change_id'].'"');
				if($change){
					if($GET['change_status']==2){
						SqlLQ('INSERT INTO c_change_log (tool,change_id,change_log_type,change_log)
								VALUES ("'.$SESSION['tool_id'].'","'.$GET['change_id'].'","'.$change['change_type'].'","'.addslashes($change['change_description']).'")');
					}
					?>OK|||change_status_<?=$GET['change_id']?>%%%status%%%<?php
					echo $change['change_status'];
					if($GET['change_status']==2){
						?>&&&change_completion_<?=$GET['change_id']?>%%%date%%%<?php
					echo $change['change_completion'];
					}
				}else{
					?>OK|||error|||Invalid Id<?php
				}
			break;
			case 'disable':
				SqlLQ('UPDATE dr_change SET change_disabled="'.$GET['change_disabled'].'" WHERE change_id="'.$GET['change_id'].'"');
			break;
		}
	}else{
		?>OK|||error|||Invalid Id<?php
	}
}else{
	?>OK|||no_rights<?php
}
storeSession($SESSION);
?>