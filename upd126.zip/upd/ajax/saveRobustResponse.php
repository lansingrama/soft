<?php
/*
* US#134 - New section inside the Design Review information, to manage robustness assessment.
* Version: V 4.7
* To save added questions for Robustness Assessment page
* Fixed by: Infosys Limited
*/ 

require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$POST=cleanArray($_POST);
$area=getFilter('area','filter',0,$SESSION);

$user_response= SqlLi('SELECT * from dr_question_response where review =  "'.$SESSION['rId'].'" and user = "'.$SESSION['user']['user_id'].'" and area = "'.$area.'" ');
// $response_count = count($user_response);
// var_dump($user_response);

	$i=0;
	foreach($POST as $key => $val){
		if($user_response != NULL){						//table not empty
			if($user_response[$i]['question'] == $key and $user_response[$i]['response'] != $val ){
				SqlLi('UPDATE dr_question_response SET response = "'.$val.'" where question = "'.$key.'"  AND review =  "'.$SESSION['rId'].'" and user = "'.$SESSION['user']['user_id'].'" and area = "'.$area.'" ');
				echo('UPDATE dr_question_response SET response = "'.$val.'" where question = "'.$key.'" AND review =  "'.$SESSION['rId'].'" and user = "'.$SESSION['user']['user_id'].'" and area = "'.$area.'" ');
			}	
		}		
		else {
			SqlLi('INSERT INTO dr_question_response(user,question,response,review,area) VALUES ("'.$SESSION['user']['user_id'].'","'.$key.'","'.$val.'","'.$SESSION['rId'].'","'.$area.'")');
			echo('INSERT INTO dr_question_response(user,question,response,review,area) VALUES ("'.$SESSION['user']['user_id'].'","'.$key.'","'.$val.'","'.$SESSION['rId'].'","'.$area.'")');
		}
		$i++;
	}


// foreach($user_response as $ur){
// 	foreach($POST as $key => $val){
// 		while($user_response != NULL){
// 			if($ur['question'] == $key){
// 				SqlLQ('UPDATE dr_question_response SET response = "'.$val.'" where review =  "'.$SESSION['rId'].'" and user = "'.$SESSION['user']['user_id'].'" and area = "'.$area.'" ');
// 			}
// 		}
// 		SqlLQ('INSERT INTO dr_question_response(user,question,response,review,area) VALUES ("'.$SESSION['user']['user_id'].'","'.$key.'","'.$val.'","'.$SESSION['rId'].'","'.$area.'")');
//    }
// }



// foreach($POST as $key => $val) {
// 	 SqlLQ('INSERT INTO dr_question_response(user,question,response,review,area) VALUES ("'.$SESSION['user']['user_id'].'","'.$key.'","'.$val.'","'.$SESSION['rId'].'","'.$area.'")');
// }

echo 'OK|||';
?>
