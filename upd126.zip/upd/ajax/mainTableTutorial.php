<?php echo 'OK|||';
?><div class="mainTableTutorialUnclickable" id="mainTableTutorialUnclickable"></div><?php 
?><div class="mainTableTutorial_1" id="mainTableTutorial_1"></div><?php 
?><div class="mainTableTutorial_2" id="mainTableTutorial_2"></div><?php 
?><div class="mainTableTutorial_3" id="mainTableTutorial_3"></div><?php 
?><div id="mainTableTutorialMsgBoxHolder"><?php 
	?><div class="mainTableTutorialMsgBox_1" id="mainTableTutorialMsgBox_1"><?php
		?><div style="font-size:20px; text-align:center;"><br />ART Main Table Tutorial<hr style="color:#565C6A" size="1" /></div><?php
		?>The Main Table tab is at the very heart of ART. This is where you will see your defined reviews, projects, actions, etc.<?php
		?><br /><br /><span style="color:red; font-weight:bold;">It is essential to have a good understanding of how the Main Table is structured before continuing.</span><?php
		?><br /><br />The following interactive tutorial will help you understand how it is structured.<?php
		?><br /><br />To start - please click next.<?php
		?><br /><br />To skip this tutorial - click skip. (not recommended)<?php
		?><div style="text-align:center;"><br /><input class="stdBtn"onClick="runMainTableTutorial(1);"type="button"value="Skip &#9658;&#9658;"> <input class="stdBtn"onClick="runMainTableTutorial(2);"type="button"value="Next &#9658;"></div><?php
	?></div><?php
	
	?><div class="mainTableTutorialArrow_1" id="mainTableTutorialArrow_1"><?php
		?><div style="font-size:30px; clear:none; float:left;">1</div><?php
		?><div style="font-size:70px; clear:none; float:right;">&#8681;</div><?php
	?></div><?php
	
	?><div class="mainTableTutorialArrow_2" id="mainTableTutorialArrow_2"><?php
		?><div style="font-size:30px; clear:none; float:left;">2</div><?php
		?><div style="font-size:70px; clear:none; float:right;">&#8681;</div><?php
	?></div><?php
	
	?><div class="mainTableTutorialMsgBox_2" id="mainTableTutorialMsgBox_2"><?php
		?><div style="font-size:18px;">Main Table<hr style="color:#565C6A" size="1" /></div><?php
		?><br />The main table is split into two different sections<?php
		?><ol><?php
			?><li>The left hand side displays information about projects which have or will have reviews performed on them.</li><?php
			?><li>The right hand side displays information about the different review types & reviews which have been or will be performed on those projects.</li><?php
		?></ol><?php
		?>Everything in this main table lines up horizontally and vertically. So when looking at a project on the left hand side of the table, you can follow its row horizontally to see the reviews which have been performed on it. <?php
		?><br /><br />The table below shows an example of how the main table is split up. <br /><br /><?php
		?><div align="center"><table cellpadding="5" cellspacing="0"><?php
			?><tr style="color:white; background-color:#6F95AB"><?php
				?><td>WP</td><?php
				?><td style="border-right:1px solid white;">CA</td><?php
				?><td style="border-right:1px solid white;">PDR</td><?php
				?><td>CDR</td><?php
			?></tr><?php
			?><tr><?php
				?><td>Project 1</td><?php
				?><td style="border-right:1px solid #bbbcbc;">Sub-Project 1</td><?php
				?><td style="border-right:1px solid #bbbcbc;">Sub-Project 1 PDR Review</td><?php
				?><td>Sub-Project 1 CDR Review</td><?php
			?></tr><?php
			?><tr><?php
				?><td>Project 1</td><?php
				?><td style="border-right:1px solid #bbbcbc;">Sub-Project 2</td><?php
				?><td style="border-right:1px solid #bbbcbc;">Sub-Project 2 PDR Review</td><?php
				?><td>Sub-Project 2 CDR Review</td><?php
			?></tr><?php
		?></table></div><?php
		?><div style="text-align:center;"><br /><input class="stdBtn"onClick="runMainTableTutorial(3);"type="button"value="Next &#9658;"></div><?php
	?></div><?php

	?><div class="mainTableTutorialCircle_1" id="mainTableTutorialCircle_1"><?php
		?><div style="font-size:30px; clear:none; float:left;">1</div><?php
		?><div style="font-size:70px;">&#9898;</div><?php
	?></div><?php

	?><div class="mainTableTutorialCircle_2" id="mainTableTutorialCircle_2"><?php
		?><div style="font-size:30px; clear:none; float:left;">2</div><?php
		?><div style="font-size:70px;">&#9898;</div><?php
	?></div><?php

	?><div class="mainTableTutorialMsgBox_2" id="mainTableTutorialMsgBox_3"><?php
		?><div style="font-size:18px;">Customising Main Table<hr style="color:#565C6A" size="1" /></div><?php
		?>The main table can be customised (columns can be hidden, columns can be filtered, review types can be hidden, etc.) to you personal needs.<?php
		?><br /><br />The customisation you set will be saved to the ART database. Meaning when you logout & login, the customisation you set will be restored.<?php
		?><br /><br /><span style="color:red;">It is highly encouraged that you customise the main table to your personal requirements before doing anything else in ART.</span><?php
		?><br /><br />Clicking the icons highlighted will allow you to:<?php
		?><ol><?php
			?><li>Show & hide columns from the main table.</li><?php
			?><li>Filter the column. Any column in any table with this icon in ART can be filtered.</li><?php
		?></ol><?php
		?><div style="text-align:center;"><br /><input class="stdBtn"onClick="runMainTableTutorial(4);"type="button"value="Finish &#9658;&#9658;"></div><?php
	?></div><?php
?></div>