<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
/*$startTime=microtime(true);
echo(microtime(true)-$startTime)*1000,' ms to process<br>';*/
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

//foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
$GET=cleanArray($_GET);
$status=array('r','a','g','x','b','m'); //JFM 27_03_14
$msn=getFilter('msn','filter',0,$SESSION);
$reviewProfile=$GET['review'];

$reviewDefined=1;
$reviewValidated=1;
$reviewValidationCommencing=0;
$review=Array();

if($reviewProfile=='')
{
	?>OK|||<div class="sideSubFormContainerEmpty">Select an Element from the list.</div><?php
}
else
{
	$included=1;
	
	$GET['ca']=defineReviewCa($GET['element'],$GET['target'],$SESSION);
	
	//JFM 22_10_13
	$reviewQry='SELECT * 
				FROM dr_review AS r
					INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
				WHERE ca IN('.$GET['ca'].') AND msn="'.$msn.'" AND review_profile="'.$reviewProfile.'"';
	$reviewMlt=SqlLi($reviewQry);
	/*
	* Fix for : US#106 Improvement: Freeze Function for completed DR 
	* Added for freeze/unfreeze function
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
	$reviewInfo = SqlLi('SELECT * FROM dr_review_freeze WHERE review = '.$GET['review'].' AND ca_id = '.$GET['ca'].'');
		
	if(is_array($reviewMlt)){
		foreach($reviewMlt as $r){
			$reviewId[]=$r['review_id'];
			if($r['validation_complete']==-1) //JFM 18_03_14
			{
				$reviewDefined=0;
				break;
			}
			if(($r['validation_complete']==0 || $r['validation_complete']==1 || $r['validation_complete']==-2) && $reviewValidated==1) 
			{
				$reviewValidated=0;
				if($r['validation_complete']==1) $reviewValidationCommencing=1;
			}
		}
	}else{
		$reviewDefined=0;
		$reviewId=array();
		$review['review_status']=4; //JFM 27_03_14
	}
	
	if(is_array($reviewMlt[0])){
		foreach($reviewMlt[0] as $k=>$v){
			$review[$k]=combinedResult($reviewMlt,$k,$SESSION['table']['review_planning']['review'][$k]['type'],$SESSION);
		}
	}
	
	$caInfo=SqlLi('SELECT c.ca,w.wp
					FROM c_ca AS c
						INNER JOIN c_cawp AS cw ON c.ca_id=cw.ca
						INNER JOIN c_wp AS w ON cw.wp=w.wp_id
					WHERE cw.msn="'.$msn.'"
						AND c.ca_id IN('.$GET['ca'].')
					ORDER BY w.wp ASC');
	
	if(checkPermission('review_profile_id','edit',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','edit',0,'check',$SESSION)==1){
		$editableReview=1;
	}else{
		$editableReview=0;
	}

	$reviewActions=SqlBDAsArr('SELECT act.review, act.action_status, COUNT(DISTINCT act.action_id) AS action_count
								FROM dr_action AS act
									INNER JOIN dr_action_applicability AS aap ON act.action_id=aap.action
									INNER JOIN dr_review as r ON r.review_id=act.review 
								WHERE act.msn="'.$msn.'"
									AND aap.ca IN ('.$GET['ca'].')
									AND r.review_profile="'.$reviewProfile.'"
									and act.criteria=0
								GROUP BY act.review, act.action_status','review','action_status');

	$redAction=$reviewActions[$reviewMlt[0]['review_id']][0]['action_count'];
	$amberAction=$reviewActions[$reviewMlt[0]['review_id']][1]['action_count'];
	$greenAction=$reviewActions[$reviewMlt[0]['review_id']][2]['action_count'];
	$blueAction=$reviewActions[$reviewMlt[0]['review_id']][3]['action_count'];
	
	$perimetersAllowed=allowedSimpleObject('perimeter','perimeter',$SESSION,'c_'); //JFM 16_01_15

	$reviewType = SqlQ('SELECT review_type_id FROM dr_review_type AS rt 
											INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id 
											WHERE rp.review_profile_id='.$reviewProfile);

	//JFM 18_03_14 - JFM 28_10_15 FIX ME
	$caName=SqlLi('SELECT DISTINCT ca.ca_id, ca.ca, coe.coe, pro.program, msn.msn, rt.review_type_id
					FROM c_ca AS ca
						INNER JOIN dr_review_applicability 	AS 	ra 	ON 	ra.ca				=	ca.ca_id
						INNER JOIN dr_review				AS	r	ON 	r.review_id			=	ra.review
						INNER JOIN dr_review_profile		AS	rp	ON	rp.review_profile_id=	r.review_profile
						INNER JOIN dr_review_type 			AS  rt 	ON  rt.review_type_id   =   rp.review_type
						INNER JOIN c_coe 					AS  coe ON  coe.coe_id 			= 	rp.coe
						INNER JOIN c_program 				AS 	pro ON 	pro.program_id 		= 	rp.program
						INNER JOIN c_msn 					AS 	msn ON 	msn.msn_id  		= 	r.msn
					WHERE rp.rp_hidden=0 AND pro.program_hidden=0 AND r.validation_complete!=-1
					AND r.review_status!=4
					AND coe.area = '.getFilter('area','filter',0,$SESSION).'
					AND pro.area = '.getFilter('area','filter',0,$SESSION).'
					AND rp.review_type = '.$reviewType['review_type_id'].'
					AND ca.perimeter IN ("'.implode('","', array_keys($perimetersAllowed)).'")
					ORDER BY pro.program, coe.coe, msn.msn, ca.ca ASC');
		/// Added by Infosys limited for US #18 - Create design review from review				
	$programName=SqlLi('SELECT DISTINCT pro.program,pro.program_id,rt.review_type_id
					FROM dr_review AS r
						INNER JOIN dr_review_profile		AS	rp	ON	rp.review_profile_id=	r.review_profile
						INNER JOIN dr_review_type 			AS  rt 	ON  rt.review_type_id   =   rp.review_type
						INNER JOIN c_program 				AS 	pro ON 	pro.program_id 		= 	rp.program
					WHERE rp.rp_hidden=0 AND pro.program_hidden=0 AND r.validation_complete!=-1
					AND r.review_status!=4
					AND pro.area = '.getFilter('area','filter',0,$SESSION).'
					AND rp.review_type = '.$reviewType['review_type_id'].'
					ORDER BY pro.program ASC');
					
	unset($SESSION['undo'][$reviewMlt[0]['review_id']]); //JFM 04_03_13

	if(!empty($reviewMlt[0]['review_id']))
		$reviewLinks = SqlLi('SELECT * FROM dr_review_links WHERE review='.$reviewMlt[0]['review_id']);

	// var_dump($reviewMlt[0]['review_id']);
	?>OK|||<?php
	
	
	function drawValidationTable($validationState, $validationDate, $reviewId, $SESSION, $editableReview, $review, $drawTable=1)
	{
	/*
	* Fix for : US#106 Improvement: Freeze Function for completed DR 
	* Added for freeze/unfreeze function
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
		$reviewInfo = SqlLi('SELECT * FROM dr_review_freeze WHERE review = '.$review['review_profile'].' AND ca_id = '.$review['ca'].'');  /// freeze
		
		if($drawTable)
		{
			/*?><div class="tableTitle" style="width:95%;">Validation:</div><?php*/
		
			?><div class="formStdContainer" style="padding-right:5px; padding-top:5px;"><?php
				?><table class="criteriaTable" id="workflowTable" style="width:500px;" align="left" cellspacing="0"><?php
		}

		?><tr class="tableGroup"><?php 
			?><td colspan="6">Validation</td>
			
				
			<?php
	/*		if($validationState==2)
			{
				?><td colspan="3">ECM Information</td><?php
			}*/
		?></tr><?php
		
		if($validationState!=0) //JFM 28_10_15
		{
			?><tr class="infoRow"><?php

				?><td class="paramDef">Validated</td><?php
				?><td style="text-align:center;" colspan="2"><?php
					
					switch ($validationState) 
					{
						case 0:
							?><span style="color:#ef343f">No</span><?php
						break;

						case 1:
							?><span style="color:#f8d707">Commencing</span><?php
						break;

						case 2:
							?><span style="color:#81c341">Yes</span><?php
						break;
						
						default:
							?><span>Unknown</span><?php
						break;
					}

				?></td><?php

				?><td style="<?=($validationState==1)?'width:100px;':''?>" class="paramDef">Workflow</td><?php	
				if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
					?><td align="center" colspan="2"><input class="stdBtn" onClick="openForm('workflow','applicability=<?=$reviewId?>&object=<?=$SESSION['object']['review_id']?>&criterionID=<?=$reviewId?>',false,'GET');" type="button"value="View Workflow &#9658;"></td><?php
				} else if (($reviewInfo[0]['is_freeze'] == 1)){
					?><td colspan="2" align="center"><input  disabled="true" class="stdBtn disabledField" onClick="openForm('workflow','applicability=<?=$reviewId?>&object=<?=$SESSION['object']['review_id']?>&criterionID=<?=$reviewId?>',false,'GET');" type="button"value="View Workflow &#9658;"></td><?php
				} else {
					?><td align="center" colspan="2"> <input class="stdBtn" onClick="openForm('workflow','applicability=<?=$reviewId?>&object=<?=$SESSION['object']['review_id']?>&criterionID=<?=$reviewId?>',false,'GET');" type="button"value="View Workflow &#9658;"></td><?php
				}
			?></tr><?php

			//JFM 19_07_16
			if($editableReview && $validationState == 2)
			{
				?><tr class="infoRow"><?php
					?><td class="paramDef">Make NA</td><?php
					?><td><?php
						?><form action="#" enctype="multipart/form-data" id="reviewEditForm" name="reviewEditForm" method="post" style="text-align:center; height:10px;"><?php
							?><input style="width:0px; display:none;" id="reviewID" name="reviewID" type="text" value="<?=$reviewId?>" disabled ><?php
							?><input style="width:0px; display:none;" id="makeApplicable" name="makeApplicable" type="text" value="1" disabled ><?php
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(confirm('This will mark the review as Not Applicable. No information will be lost.\n\nAre you sure you wish to continue?')) {ajaxRequest('ajax/saveReviewValidation.php?makeApplicable=1&reviewID=<?=$reviewId?>','reloadSideElement',false,'POST'); mainRestartNeeded=1;}" type="button" value="Make Review Not Applicable &#9658;"><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><input class="stdBtn disabledField" id="createCriteriaSubmit" onClick="if(confirm('This will mark the review as Not Applicable. No information will be lost.\n\nAre you sure you wish to continue?')) {ajaxRequest('ajax/saveReviewValidation.php?makeApplicable=1&reviewID=<?=$reviewId?>','reloadSideElement',false,'POST'); mainRestartNeeded=1;}" type="button" value="Make Review Not Applicable &#9658;"><?php
							} else {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(confirm('This will mark the review as Not Applicable. No information will be lost.\n\nAre you sure you wish to continue?')) {ajaxRequest('ajax/saveReviewValidation.php?makeApplicable=1&reviewID=<?=$reviewId?>','reloadSideElement',false,'POST'); mainRestartNeeded=1;}" type="button" value="Make Review Not Applicable &#9658;"><?php
							}
						?></form><?php
					?></td><?php
				?></tr><?php
			}
		}

		if($validationState==0)
		{
			?><tr class="infoRow"><?php
				?><td style="width:100px;" class="paramDef">Delete Checklist</td><?php
				?><td><?php
					?><form action="#" enctype="multipart/form-data" id="reviewEditForm" name="reviewEditForm" method="post" style="text-align:center; height:10px;"><?php
						?><input style="width:0px; display:none;" id="reviewID" name="reviewID" type="text" value="<?=$reviewId?>" disabled ><?php
						?><input style="width:0px; display:none;" id="cancel" name="cancel" type="text" value="1" disabled ><?php
						?><input style="width:0px; display:none;" id="maxValidationLoopID" name="maxValidationLoopID" type="text" size="50" value="0" disabled ><?php
						if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
							?><input class="stdBtn" id="createCriteriaSubmit" onClick="deleteReview();"type="button"value="Delete Checklist &#9658;"><?php
						} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
							?><input class="stdBtn disabledField" id="createCriteriaSubmit" onClick="deleteReview();"type="button"value="Delete Checklist &#9658;"><?php
						} else {
							?><input class="stdBtn" id="createCriteriaSubmit" onClick="deleteReview();"type="button"value="Delete Checklist &#9658;"><?php
						}
					?></form><?php
				?></td><?php
			?></tr><?php

			if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 || checkPermission('force_validation','create',0,'check',$SESSION)==1) //JFM 12_01_16
			{
				?><tr class="infoRow"><?php
					?><td class="paramDef">Force Validation</td><?php
					?><td style="text-align:center;"><?php
						?><form action="#" enctype="multipart/form-data" id="reviewForceForm" name="reviewForceForm" method="post"><?php
							?><textarea class="textareaWhite" style="width:98%;" rows="4" id="forceComments" name="forceComments"></textarea><?php
							?><input style="width:0px; display:none;" id="reviewID" name="reviewID" type="text" value="<?=$reviewId?>" disabled ><?php
							?><input style="width:0px; display:none;" id="force" name="force" type="text" value="1" disabled ><?php
						$plannedDateInfo=SqlLi('SELECT planned FROM dr_review_status WHERE review_profile="'.$review['review_profile'].'" AND ca='.$review['ca'].'');
						if($plannedDateInfo[0]['planned'] == '0000-00-00'){ 
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="plannedDateMandatory();"type="button"value="Force Validation &#9658;"><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="plannedDateMandatory();"type="button"value="Force Validation &#9658;"><?php
							} else {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="plannedDateMandatory();"type="button"value="Force Validation &#9658;"><?php
							}
						}
						else if($plannedDateInfo[0]['planned']){
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="forceReview();"type="button"value="Force Validation &#9658;"><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><input class="stdBtn disabledField" id="createCriteriaSubmit" onClick="forceReview();"type="button"value="Force Validation &#9658;"><?php
							} else {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="forceReview();"type="button"value="Force Validation &#9658;"><?php
							}	}
						else {
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="plannedDateMandatory();"type="button"value="Force Validation &#9658;"><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><input class="stdBtn disabledField" id="createCriteriaSubmit" onClick="plannedDateMandatory();"type="button"value="Force Validation &#9658;"><?php
							} else {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="plannedDateMandatory();"type="button"value="Force Validation &#9658;"><?php
							}
							}
						?></form><?php
					?></td><?php
				?></tr><?php
			}
		}	
			
		if($drawTable)
		{	
			?></table><?php	
	
		?></div><?php
		}
		
	}	
	if($reviewDefined && $reviewValidated)
	{	
		//JFM 13_12_13
		$allCAsInThisReview=SqlLi('SELECT DISTINCT ca.ca_id, ca.ca 
									FROM c_ca AS ca
										INNER JOIN dr_review_applicability 	AS 	ra 	ON 	ra.ca = ca.ca_id
									WHERE ra.review ="'.$reviewMlt[0]['review_id'].'"
									ORDER BY ca.ca ASC');
			/*
			* Fix for : US#106 Improvement: Freeze Function for completed DR 
			* Added for freeze/unfreeze function
			* Version: 4.3
			* Fixed By: Infosys Limited
			*/
		$reviewInfo = SqlLi('SELECT * FROM dr_review_freeze WHERE review = '.$reviewProfile.' AND ca_id = '.$GET['ca'].'');  /// freeze
		
		$plannedDateInfo=SqlLi('SELECT planned FROM dr_review_status WHERE review_profile="'.$reviewProfile.'" AND ca='.$GET['ca'].'');  // Change worflow							
			?>
			
			<div class="formStdContainer" style="margin-right:30px;"><?php

			?><div class="reviewStatus"><img id="bigReviewStatus"src="../common/img/<?=$status[$review['review_status']]?>100.jpg"></div><?php

			?><div class="leftInfoBox"><?php
				?><div class="tableTitle" style="padding-top:20px;">General Information:</div><?php
				?><form action="#" enctype="multipart/form-data" id="reviewInfoFrm" method="post" style="display:inline;"><?php
					?><input id="ca"name="ca"type="hidden"value="<?=$GET['ca']?>"><?php
					?><input id="review"name="review"type="hidden"value="<?=$reviewProfile?>"><?php
					?><input id="msn"name="msn"type="hidden"value="<?=$msn?>"><?php
					?><input id="review_status"name="review_status"type="hidden"value="<?=$status[$review['review_status']]?>"><?php
					?><input id="initial_review_status" name="initial_review_status" type="hidden" value="<?=$status[$review['initial_review_status']]?>"><?php //JFM 13_05_16

					?><table class="criteriaTable" align="center" cellspacing="0" cellpadding="0"><?php

						?><tr class="tableGroup"><?php
							?><td colspan="6"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Information</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Details</td><?php
							/*
								US109-General Information not editable by supplier
								Passing review profile id (rpid)
								Fixed By - Infosys Limited
								Version: V 4.5
							*/
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><td colspan="2" align="center"><input class="stdBtn" onClick="openForm('../ajax/ca','element=<?=$GET['ca']?>&rpid=<?=$GET['review']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Details &#9658;"></td><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><td colspan="2" align="center"><input disabled="true" class="stdBtn disabledField" onClick="openForm('../ajax/ca','element=<?=$GET['ca']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Details &#9658;"></td><?php
							} else {
								?><td colspan="2" align="center"><input class="stdBtn" onClick="openForm('../ajax/ca','element=<?=$GET['ca']?>&rpid=<?=$GET['review']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Details &#9658;"></td><?php
							}
							/* End for US109 */
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Responsibles</td><?php
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><td colspan="2" align="center"><input class="stdBtn" onClick="openForm('../ajax/responsible','element=<?=$reviewMlt[0]['review_id']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Responsibles &#9658;"></td><?php			
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><td colspan="2" align="center"><input disabled="true" class="stdBtn disabledField" onClick="openForm('../ajax/responsible','element=<?=$reviewMlt[0]['review_id']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Responsibles &#9658;"></td><?php			
							} else {
								?><td colspan="2" align="center"><input class="stdBtn" onClick="openForm('../ajax/responsible','element=<?=$reviewMlt[0]['review_id']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Responsibles &#9658;"></td><?php			
							}
						?></tr><?php

						?><tr class="tableGroup"><?php
							?><td colspan="3">Review Information</td><?php
							?><td colspan="2">Milestone</td><?php
							?><td style="width:75px">Performed</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php	//JFM 25_11_13
							?><td class="paramDef" style="width:55px;">Applicable <?=$SESSION['table']['review_planning']['ca']['ca']['title']?>s</td><?php
							?><td colspan="2"><?php
								foreach($allCAsInThisReview as $oneCAInThisReview) $allCAsInThisReviewAsString=$allCAsInThisReviewAsString.$oneCAInThisReview['ca'].', ';
								$allCAsInThisReviewAsString=rtrim($allCAsInThisReviewAsString, ", ");
								echo $allCAsInThisReviewAsString;
							?></td><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['planned']['title']?></td><?php
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><td style="width:125px;"><?php
									if(!empty($plannedDateInfo[0]['planned'])){
									//drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
									drawDate('planned','plannedDateCal',$plannedDateInfo[0]['planned'],false,$editableReview);
									}
									else{
										drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
									}	
								?></td><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><td style="width:125px;" class="disablediv"><?php
									if(!empty($plannedDateInfo[0]['planned'])){
									//drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
									drawDate('planned','plannedDateCal',$plannedDateInfo[0]['planned'],false,$editableReview);
									}
									else{
										drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
									}	
								?></td><?php
							} else {
								?><td style="width:125px;" class="disablediv"><?php
									if(!empty($plannedDateInfo[0]['planned'])){
									//drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
									drawDate('planned','plannedDateCal',$plannedDateInfo[0]['planned'],false,$editableReview);
									}
									else{
										drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
									}	
								?></td><?php
							}
							?><td></td><?php
						?></tr><?php		
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;"><?=$SESSION['table']['review_planning']['review']['initial_review_status']['title']?></td><?php
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><td colspan="2"><?php
									drawStatus('initial_review_status','initialReviewStatus',$review['initial_review_status'],$editableReview,$SESSION); //JFM 13_05_16
								?></td><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><td colspan="2" class="disablediv"><?php
									drawStatus('initial_review_status','initialReviewStatus',$review['initial_review_status'],$editableReview,$SESSION); //JFM 13_05_16
								?></td><?php
							} else {
								?><td colspan="2"><?php
									drawStatus('initial_review_status','initialReviewStatus',$review['initial_review_status'],$editableReview,$SESSION); //JFM 13_05_16
								?></td><?php
							}
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['review_date']['title']?></td><?php
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><td><?php
									drawDate('review_date','reviewDateCal',$review['review_date'],false,$editableReview);
								?></td><?php
								?><td style="width:25px;"><?php drawRadio('review_done',$review['review_done'],$editableReview)?></td><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><td class="disablediv"><?php
									drawDate('review_date','reviewDateCal',$review['review_date'],false,$editableReview);
								?></td><?php
								?><td class="disablediv" style="width:25px;"><?php drawRadio('review_done',$review['review_done'],$editableReview)?></td><?php
							} else {
								?><td><?php
									drawDate('review_date','reviewDateCal',$review['review_date'],false,$editableReview);
								?></td><?php
								?><td style="width:25px;"><?php drawRadio('review_done',$review['review_done'],$editableReview)?></td><?php
							}
						?></tr><?php
							?><tr class="infoRow"><?php //JFM 09_04_14
							?><td class="paramDef" style="width:55px;"><?=$SESSION['table']['review_planning']['review']['review_status']['title']?></td><?php
							?><td colspan="2"><?php
								drawStatus('review_status','reviewStatus',$review['review_status'],$editableReview,$SESSION); //JFM 13_05_16
							?></td><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['delta_planned']['title']?></td><?php //JFM 08_06_16
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><td style="width:125px;"><?php
									drawDate('delta_planned','deltaPlannedDateCal',$review['delta_planned'],false,$editableReview);
								?></td><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><td style="width:125px;" class="disablediv"><?php
									drawDate('delta_planned','deltaPlannedDateCal',$review['delta_planned'],false,$editableReview);
								?></td><?php
							} else {
								?><td style="width:125px;"><?php
									drawDate('delta_planned','deltaPlannedDateCal',$review['delta_planned'],false,$editableReview);
								?></td><?php
							}
							?><td></td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;" onMouseOut="nd();"onMouseOver="overlib('<b>Non-Criteria Specific Actions</b><br />These are minor actions unrelated to any criteria.<br />Examples of NCSAs could be document typos which need correcting or long term future actions which do not directly impact the current review.', ABOVE);">NCSA<?php
							?><div style="cursor:pointer">(?)</div></td><?php
							?><td colspan="2"><?php
								?><table><?php
									?><tr><?php
										if($editableReview)
										{
											if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
												?><td><input class="stdBtn" onClick="closeMenu(oldCol); openForm('action','action=new&ca=<?=$GET['ca']?>&review_criteria_id=0&review_id=<?=$reviewMlt[0]['review_id']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button"value="Add NCSA &#9658;"></td><?php
											} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
												?><td class="disablediv"><input class="stdBtn" onClick="closeMenu(oldCol); openForm('action','action=new&ca=<?=$GET['ca']?>&review_criteria_id=0&review_id=<?=$reviewMlt[0]['review_id']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button"value="Add NCSA &#9658;"></td><?php
											} else {
												?><td><input class="stdBtn" onClick="closeMenu(oldCol); openForm('action','action=new&ca=<?=$GET['ca']?>&review_criteria_id=0&review_id=<?=$reviewMlt[0]['review_id']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button"value="Add NCSA &#9658;"></td><?php
											}
										}
										?><td class="reviewAction r"id="criteria_red_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=0');"style="color:#900;"><?=$redAction?></td><?php
										?><td class="reviewAction a"id="criteria_amber_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=1');"style="color:#CC0;"><?=$amberAction?></td><?php
										?><td class="reviewAction g"id="criteria_green_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=2');"style="color:#060;"><?=$greenAction?></td><?php
										?><td class="reviewAction x"id="criteria_blue_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=3');"style="color:#609dc9;"><?=$blueAction?></td><?php
										$totalAction=$redAction+$amberAction+$greenAction+$blueAction;
										?><td class="reviewAction"id="criteria_total_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0');"><?php if($totalAction!=0)echo $totalAction?></td><?php
									?></tr><?php
								?></table><?php
							?></td><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['delta']['title']?></td><?php //JFM 08_06_16
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><td><?php
									drawDate('delta','deltaDateCal',$review['delta'],false,$editableReview);
								?></td><?php
								?><td><?php drawRadio('delta_done',$review['delta_done'],$editableReview)?></td><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><td class="disablediv"><?php
									drawDate('delta','deltaDateCal',$review['delta'],false,$editableReview);
								?></td><?php
								?><td class="disablediv"><?php drawRadio('delta_done',$review['delta_done'],$editableReview)?></td><?php
							} else {
								?><td><?php
									drawDate('delta','deltaDateCal',$review['delta'],false,$editableReview);
								?></td><?php
								?><td><?php drawRadio('delta_done',$review['delta_done'],$editableReview)?></td><?php
							}
						?></tr><?php

						drawValidationTable($reviewMlt[0]['validation_complete'], $reviewMlt[0]['validation_date'], $reviewMlt[0]['review_id'], $SESSION,$editableReview,$review,0);

						?><tr class="tableGroup"><?php
							?><td colspan="6">Continuous Assessment Process</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef">Active</td><?php
							?><td align="center" colspan="2"><?php
								/*?><input id="continuousassessment_<?=$reviewMlt[0]['review_id']?>" onclick="if(confirm('Are you sure?')){checkChange(this,'cont');}" type="checkbox" value="1" <?php if($reviewMlt[0]['continuous_assessment']==1) echo' checked="checked"'; if(checkPermission('continuous_assessment','create',0,'check',$SESSION)!=1) echo 'disabled="disabled"';?>/><?php*/
							
								switch ($reviewMlt[0]['continuous_assessment']) 
								{
									case 0:
										?><span style="color:#ef343f">No</span><?php
									break;

									case 1:
										?><span style="color:#81c341">Yes</span><?php
									break;
									
									default:
										?><span>Unknown</span><?php
									break;
								}

							?></td><?php
							?><td class="paramDef">CAP Setup</td><?php
							?><td colspan="2" align="center"><?php
								if(checkPermission('continuous_assessment','create',0,'check',$SESSION)==1)
								{
									if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
										?><input class="stdBtn" onClick="openForm('capSetup','ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button" value="View CAP Setup &#9658;"><?php
									} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
										?><input class="stdBtn disabledField" onClick="openForm('capSetup','ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button" value="View CAP Setup &#9658;"><?php
									} else {
										?><input class="stdBtn" onClick="openForm('capSetup','ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button" value="View CAP Setup &#9658;"><?php
									}
								}
								else
								{
									?><input class="stdBtn disablediv" type="button" value="View CAP Setup &#9658;" disabled="disabled"><?php
								}
							?></td><?php
						?></tr>	
						
						<?php 
						/*
							* US#134 - New section inside the Design Review information, to manage robustness assessment.
							* Version: V 4.7
							* To display the header and button in design review information page
							* Fixed by: Infosys Limited
						*/
						?>
						<tr class="tableGroup"><?php
							?><td colspan="6">Robustness Assessment</td><?php
						?></tr><?php
						?>
						<tr class="infoRow"><?php
							?><td class="paramDef">Assessment</td><?php
							?><td  colspan="2" align="center"><?php
								
					?><input class="stdBtn" onClick="openForm('robustnessAssessment','reviewId=<?=$reviewMlt[0]['review_id']?>',true,'GET');" type="button" value="View Assessment &#9658;"><?php									
									
							?></td><?php
						?></tr>
						<?php 
						/*
							* US#134 - New section inside the Design Review information, to manage robustness assessment.
							* Version: V 4.7
							* To display the header and button in design review information page
							* Fixed by: Infosys Limited
						*/
						?>
						
						
						<input type="hidden" name="freezeReviewIdHiddens" id="freezeReviewIdHiddens" value="<?=$review['review_profile']?>">
					<input type="hidden" name="freezeCaIdHiddens" id="freezeCaIdHiddens" value="<?=$review['ca']?>">
					<input type="hidden" name="freezeUserIdHiddens" id="freezeUserIdHiddens" value="<?=utf8_encode($SESSION['user']['user_id'])?>">
		<?php

						//JFM 13_05_16
						?><tr class="tableGroup"><?php
							?><td colspan="6">Document Links</td><?php
						?></tr><?php
						?><tr><?php
							?><td colspan="6"><?php
								?><table class="criteriaTable" id="reviewLinksTable" style="margin:0; padding:0;" width="100%" align="left" cellspacing="0" cellpadding="5"><?php
									?><tr><?php
										?><td class="paramDef">Name</td><?php
										?><td class="paramDef">Reference</td><?php
										?><td class="paramDef">Link</td><?php
										?><td class="paramDef"></td><?php
										?><td class="paramDef"></td><?php
									?></tr><?php
									$i=0;
									if(!empty($reviewLinks))
									{
										
										foreach($reviewLinks as $reviewLink)
										{
											/*
											* Fix for : US #19 - Change workflow for creating a design review 
											* Fields disabled for user
											* Version: 4.3
											* Fixed By: Infosys Limited
											*/
											
											?><tr id="rowLink<?=$i?>"><?php
													if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
														?><td height="18px;" valign="top"><?php
														?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="nameinputID<?=$i?>" name="nameinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['name'])?>"><?php
														?></td><?php
														?><td height="18px;" valign="top"><?php
															?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="referenceinputID<?=$i?>" name="referenceinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['reference'])?>"><?php
														?></td><?php
														?><td height="18px;" valign="top"><?php
															?><input class="textareaWhite" <?php if($editableReview!=1)echo'disabled '?> id="linkinputID<?=$i?>" name="linkinputID<?=$i?>" onKeyUp="$('linkArrow<?=$i?>').style.display=(this.value=='')?'none':'inline';" size="20" type="text" value="<?=$reviewLink['link']?>"><?php
															?><a class="arrowLink" href="<?=$reviewLink['link']?>" id="linkArrow<?=$i?>" onMouseDown="loadLink(this); "target="_blank"<?php if(!$reviewLink['link']){?>style="display:none;"<?php }?>>&raquo;</a><?php
														?></td><?php
													} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
														?><td height="18px;" valign="top" class="disablediv"><?php
														?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="nameinputID<?=$i?>" name="nameinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['name'])?>"><?php
														?></td><?php
														?><td height="18px;" valign="top"  class="disablediv"><?php
															?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="referenceinputID<?=$i?>" name="referenceinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['reference'])?>"><?php
														?></td><?php
														?><td height="18px;" valign="top"><?php
															?><input class="textareaWhite disablediv" <?php if($editableReview!=1)echo'disabled '?> id="linkinputID<?=$i?>" name="linkinputID<?=$i?>" onKeyUp="$('linkArrow<?=$i?>').style.display=(this.value=='')?'none':'inline';" size="20" type="text" value="<?=$reviewLink['link']?>"><?php
															?><a class="arrowLink" href="<?=$reviewLink['link']?>" id="linkArrow<?=$i?>" onMouseDown="loadLink(this); "target="_blank"<?php if(!$reviewLink['link']){?>style="display:none;"<?php }?>>&raquo;</a><?php
														?></td><?php
													} else {
														?><td height="18px;" valign="top"><?php
														?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="nameinputID<?=$i?>" name="nameinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['name'])?>"><?php
														?></td><?php
														?><td height="18px;" valign="top"><?php
															?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="referenceinputID<?=$i?>" name="referenceinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['reference'])?>"><?php
														?></td><?php
														?><td height="18px;" valign="top"><?php
															?><input class="textareaWhite" <?php if($editableReview!=1)echo'disabled '?> id="linkinputID<?=$i?>" name="linkinputID<?=$i?>" onKeyUp="$('linkArrow<?=$i?>').style.display=(this.value=='')?'none':'inline';" size="20" type="text" value="<?=$reviewLink['link']?>"><?php
															?><a class="arrowLink" href="<?=$reviewLink['link']?>" id="linkArrow<?=$i?>" onMouseDown="loadLink(this); "target="_blank"<?php if(!$reviewLink['link']){?>style="display:none;"<?php }?>>&raquo;</a><?php
														?></td><?php
													}
													if($editableReview == 1)
													{
														?><td style="text-align:center;"><?php
															?><input class="xRemove" style="font-size:18px;" onClick="createRowWithNameSuggestionForReviewLinks(this);" type="button" value="&#8626;"/><?php
														?></td><?php
														if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
															?><td style="text-align:center;"><?php
															?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
															?></td><?php
														} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
															?><td style="text-align:center;" class="disablediv"><?php
															?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
															?></td><?php
														} else {
															?><td style="text-align:center;"><?php
															?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
															?></td><?php
														}
													}
										    ?></tr><?php
											$i++;
										}
									}

									if($editableReview == 1 && $i==0)
									{
	/*
	* Fix for : US#106 Improvement: Freeze Function for completed DR 
	* Added for freeze/unfreeze function
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
									 ?><tr id="rowLink<?=$i?>"><?php
											?><td height="18px;" valign="top"><?php
												?><input class="textareaWhite" id="nameinputID<?=$i?>" name="nameinputID<?=$i?>" size="20" type="text"><?php
											?></td><?php
											?><td height="18px;" valign="top"><?php
												?><input class="textareaWhite" id="referenceinputID<?=$i?>" name="referenceinputID<?=$i?>" size="20" type="text"><?php
											?></td><?php
											?><td height="18px;" valign="top"><?php
												?><input class="textareaWhite" <?php if($editableReview!=1)echo'disabled '?> id="linkinputID<?=$i?>" name="linkinputID<?=$i?>" onKeyUp="$('linkArrow<?=$i?>').style.display=(this.value=='')?'none':'inline';" size="20" type="text" value="<?=$reviewLink['link']?>"><?php
												?><a class="arrowLink" href="<?=$reviewLink['link']?>" id="linkArrow<?=$i?>" onMouseDown="loadLink(this); "target="_blank"<?php if(!$reviewLink['link']){?>style="display:none;"<?php }?>>&raquo;</a><?php
											?></td><?php
											?><td style="text-align:center;"><?php
												?><input class="xRemove" style="font-size:18px;" onClick="createRowWithNameSuggestionForReviewLinks(this);" type="button" value="&#8626;"/><?php
											?></td><?php
											?><td style="text-align:center;"><?php
												?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
											?></td><?php
										?></tr><?php
									}

								?></table><?php
							?></td><?php
						?></tr><?php

						if(getFilter('area','filter',0,$SESSION)==8)
						{
							?><tr class="tableGroup"><?php
								?><td colspan="6">Design Office Statement</td><?php
							?></tr><?php
							?><tr class="infoRow"><?php
								?><td class="paramDef">Decision of Engineering</td><?php
								?><td colspan="2"><?php
									?><select name="versionEngineerOpinion"><?php
										?><option value="0"></option><?php                                                                                
										?><option value="1" <?=($reviewMlt[0]['cabin_ve_status']==1)?'selected="selected"':''?> >Pass</option><?php
										?><option value="2" <?=($reviewMlt[0]['cabin_ve_status']==2)?'selected="selected"':''?> >Fail</option><?php
									?></select><?php
								?></td><?php
								?><td class="paramDef" rowspan="2">Engineering Remarks</td><?php
								?><td rowspan="2" colspan="2"><?php
									?><textarea class="textareaWhite" id="versionEngineerRemark" name="versionEngineerRemark" rows="5" cols="30"><?=$reviewMlt[0]['cabin_ve_remarks']?></textarea><?php
								?></td><?php
							?></tr><?php

							?><tr class="infoRow"><?php
								?><td class="paramDef">Approver Name</td><?php
								  ?><td><?php
									?><div class="suggestion" id="versionEngineerDiv" style="width:159px;"></div><?php
									?><input value="<?=$reviewMlt[0]['cabin_ve_name']?>" class="textareaWhite" id="versionEngineer" name="versionEngineer" value="" onFocus="loadUserSuggestion(this,'versionEngineerDiv','versionEngineer','','versionEngineerSuggestion');" onKeyPress="return avoidSendForm(event,'user');" size="28" type="text"><?php
								  ?></td><?php
							?></tr><?php
						}
						
					?></table>
						<?php
	/*
	* Fix for : US#106 Improvement: Freeze Function for completed DR 
	* Added for freeze/unfreeze function
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
					if($editableReview==1){
						?><div class="save"><span class="saveResponse"id="review_saveResponse">Changes were applied</span><?php
						?><span style="color: red;display: inline;font-size: 10px;padding-right:10px;display:none;" id="review_freeze_saveResponse">Review has been frozen</span><?php
						?><span style="color: #009900;display: inline;font-size: 10px;padding-right:10px;display:none;" id="review_unfreeze_saveResponse">Review has been unfrozen</span><?php
						?><input class="stdBtn"onClick="sendAjaxForm('reviewInfoFrm','ajax/saveReviewInfo.php','updateData','review_saveResponse');" type="button"value="Apply Changes &#9658;"><?php
						if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
							if ($reviewInfo[0]['is_freeze'] == 1){
								?><input disabled="true" class="stdBtn disablediv" id="rfreeze" onClick="saveDisabledReview(<?=$GET['review']?>,<?=$GET['ca']?>,<?=utf8_encode($SESSION['user']['user_id'])?>,'freeze');" type="button" value="Freeze Review &#9658;"><?php
							}
							else{
								?><input class="stdBtn" id="rfreeze" onClick="saveDisabledReview(<?=$GET['review']?>,<?=$GET['ca']?>,<?=utf8_encode($SESSION['user']['user_id'])?>,'freeze');" type="button" value="Freeze Review &#9658;"><?php
							}	
						}
						else if ($reviewInfo[0]['is_freeze'] == 1){
							?><input disabled="true" class="stdBtn disablediv" id="rfreeze" onClick="saveDisabledReview(<?=$GET['review']?>,<?=$GET['ca']?>,<?=utf8_encode($SESSION['user']['user_id'])?>,'freeze');" type="button" value="Freeze Review &#9658;"><?php
						}else{
							?><input class="stdBtn" id="rfreeze" onClick="saveDisabledReview(<?=$GET['review']?>,<?=$GET['ca']?>,<?=utf8_encode($SESSION['user']['user_id'])?>,'freeze');" type="button" value="Freeze Review &#9658;"><?php
						}	
						if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1) {
							if ($reviewInfo[0]['is_freeze'] == 0){
								?><input disabled="true" class="stdBtn disablediv" id="runfreeze" onClick="unfreezeReview(<?=$GET['review']?>,<?=$GET['ca']?>,'unfreeze');" type="button" value="Unfreeze Review &#9658;"><?php
							} else {
								?><input class="stdBtn" id="runfreeze" onClick="unfreezeReview(<?=$GET['review']?>,<?=$GET['ca']?>,'unfreeze');" type="button" value="Unfreeze Review &#9658;"><?php
							}
						}
					        ?></div><?php
					}
				?></form><?php
			?></div><?php
		?></div><?php
				
		/*?><div style="position:relative;height:50px;"></div><?php*/
				
		/*?><div class="sp" style="height:40px;"></div><?php*/
		?><div class="wideFormTable"id="reviewCriteriaReportList"><?php

			$SESSION['undo'][$reviewMlt[0]['review_id']][0]=$reviewMlt[0]['remark'];

			?><div class="tableTitle" style="width:40%;">Review Remarks:</div><?php
			?><form action="#" enctype="multipart/form-data" id="reviewRemarkForm" name="reviewRemarkForm" method="post"style="display:inline;" align="left"><?php
				?><input id="reviewID" name="reviewID" style="display:none;" value="<?=$reviewMlt[0]['review_id']?>" disabled /><?php
				if($editableReview)
				{
					if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
						//JFM 04_08_15
						?><div id="review_remark_formatted_area" class="textarea" style="text-align:left; color:black; height:100px;" contenteditable="true" onPaste="cleanPaste();"><?=str_replace( "\n", '<br />',utf8_encode($reviewMlt[0]['remark']))?></div><?php
						?><textarea id="review_remark" name="review_remark" style="display:none;"></textarea><?php
						/*?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" onblur="sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php','updateData','review_remark_saveResponse');"><?=utf8_encode($reviewMlt[0]['remark'])?></textarea><?php*/
					} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
						//JFM 04_08_15
						?><div id="review_remark_formatted_area" class="textarea disablediv" style="text-align:left; color:black; height:100px;" contenteditable="true" onPaste="cleanPaste();"><?=str_replace( "\n", '<br />',utf8_encode($reviewMlt[0]['remark']))?></div><?php
						?><textarea disabled="true" id="review_remark" name="review_remark" style="display:none;"></textarea><?php
						/*?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" onblur="sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php','updateData','review_remark_saveResponse');"><?=utf8_encode($reviewMlt[0]['remark'])?></textarea><?php*/
					} else {
						//JFM 04_08_15
						?><div id="review_remark_formatted_area" class="textarea" style="text-align:left; color:black; height:100px;" contenteditable="true" onPaste="cleanPaste();"><?=str_replace( "\n", '<br />',utf8_encode($reviewMlt[0]['remark']))?></div><?php
						?><textarea id="review_remark" name="review_remark" style="display:none;"></textarea><?php
						/*?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" onblur="sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php','updateData','review_remark_saveResponse');"><?=utf8_encode($reviewMlt[0]['remark'])?></textarea><?php*/
					}
				}
				else
				{
					if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
						?><div id="review_remark_formatted_area" class="textarea" style="text-align:left; color:black; height:100px;"><?=str_replace( "\n", '<br />',utf8_encode($reviewMlt[0]['remark']))?></div><?php
						/*?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" readonly="readonly"><?=utf8_encode($reviewMlt[0]['remark'])?></textarea><?php*/
					} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
						?><div id="review_remark_formatted_area" class="textarea disablediv" style="text-align:left; color:black; height:100px;"><?=str_replace( "\n", '<br />',utf8_encode($reviewMlt[0]['remark']))?></div><?php
						/*?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" readonly="readonly"><?=utf8_encode($reviewMlt[0]['remark'])?></textarea><?php*/
					} else {
						?><div id="review_remark_formatted_area" class="textarea" style="text-align:left; color:black; height:100px;"><?=str_replace( "\n", '<br />',utf8_encode($reviewMlt[0]['remark']))?></div><?php
						/*?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" readonly="readonly"><?=utf8_encode($reviewMlt[0]['remark'])?></textarea><?php*/
					}
				}
			?></form><?php
			if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
				?><div style="width:95%; text-align:right;"><?php
				if($editableReview) 
				{
					//JFM 04_08_15
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Bold', ABOVE, WRAP);" 			style="font-size:12px; float:left; font-weight:bold;" value="B" onclick="changeStyle('bold');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Italic', ABOVE, WRAP);" 			style="font-size:12px; float:left; font-style:italic;" value="I" onclick="changeStyle('italic');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Return to normal', ABOVE, WRAP);" style="float:left; font-size:12px;" value="N" onclick="changeStyle('normal');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Red', ABOVE, WRAP);" 				style="font-size:12px; float:left; color:#ef343f;" value="&#9632" onclick="changeStyle('red');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Amber', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#f8d707;" value="&#9632" onclick="changeStyle('amber');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Green', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#81c314;" value="&#9632" onclick="changeStyle('green');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Blue', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#0088cf;" value="&#9632" onclick="changeStyle('blue');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Black', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#000000;" value="&#9632" onclick="changeStyle('black');"><?php
					?><input class="stdBtn" type="button" style="float:left;" value="Save &#9658;" onclick="$('review_remark').value = $('review_remark_formatted_area').innerHTML;sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php','updateData','review_remark_saveResponse');"><?php
					?><span class="saveResponse"id="review_remark_saveResponse" style="float: left;">Changes were applied</span><?php
					/*?><div title="Undo..." style="width:25%; text-align:right; display:inline; cursor:pointer; font-size:20px; font-weight:bold; color:#004f6b;" id="review_remark_undo" onclick="sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php?undo=1','putInReviewRemark','review_remark_saveResponse');">&#8630;</div><?php */
				}
				?><div title="Expand..." style="width:25%; text-align:right; display:inline; cursor:pointer; font-size:20px; font-weight:bold; color:#004f6b;" id="review_remark_formatted_area_arrow" onclick="colapseDivFromID('review_remark_formatted_area','textarea');">&#9660;</div><?php //&#9660;
				?></div><?php
			} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
				?><div style="width:95%; text-align:right;" class="disablediv"><?php
				if($editableReview) 
				{
					//JFM 04_08_15
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Bold', ABOVE, WRAP);" 			style="font-size:12px; float:left; font-weight:bold;" value="B" onclick="changeStyle('bold');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Italic', ABOVE, WRAP);" 			style="font-size:12px; float:left; font-style:italic;" value="I" onclick="changeStyle('italic');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Return to normal', ABOVE, WRAP);" style="float:left; font-size:12px;" value="N" onclick="changeStyle('normal');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Red', ABOVE, WRAP);" 				style="font-size:12px; float:left; color:#ef343f;" value="&#9632" onclick="changeStyle('red');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Amber', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#f8d707;" value="&#9632" onclick="changeStyle('amber');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Green', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#81c314;" value="&#9632" onclick="changeStyle('green');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Blue', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#0088cf;" value="&#9632" onclick="changeStyle('blue');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Black', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#000000;" value="&#9632" onclick="changeStyle('black');"><?php
					?><input class="stdBtn" type="button" style="float:left;" value="Save &#9658;" onclick="$('review_remark').value = $('review_remark_formatted_area').innerHTML;sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php','updateData','review_remark_saveResponse');"><?php
					?><span class="saveResponse"id="review_remark_saveResponse" style="float: left;">Changes were applied</span><?php
					/*?><div title="Undo..." style="width:25%; text-align:right; display:inline; cursor:pointer; font-size:20px; font-weight:bold; color:#004f6b;" id="review_remark_undo" onclick="sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php?undo=1','putInReviewRemark','review_remark_saveResponse');">&#8630;</div><?php */
				}
				?><div title="Expand..." style="width:25%; text-align:right; display:inline; cursor:pointer; font-size:20px; font-weight:bold; color:#004f6b;" id="review_remark_formatted_area_arrow" onclick="colapseDivFromID('review_remark_formatted_area','textarea');">&#9660;</div><?php //&#9660;
				?></div><?php
			} else {
				?><div style="width:95%; text-align:right;"><?php
				if($editableReview) 
				{
					//JFM 04_08_15
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Bold', ABOVE, WRAP);" 			style="font-size:12px; float:left; font-weight:bold;" value="B" onclick="changeStyle('bold');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Italic', ABOVE, WRAP);" 			style="font-size:12px; float:left; font-style:italic;" value="I" onclick="changeStyle('italic');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Return to normal', ABOVE, WRAP);" style="float:left; font-size:12px;" value="N" onclick="changeStyle('normal');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Red', ABOVE, WRAP);" 				style="font-size:12px; float:left; color:#ef343f;" value="&#9632" onclick="changeStyle('red');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Amber', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#f8d707;" value="&#9632" onclick="changeStyle('amber');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Green', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#81c314;" value="&#9632" onclick="changeStyle('green');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Blue', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#0088cf;" value="&#9632" onclick="changeStyle('blue');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Black', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#000000;" value="&#9632" onclick="changeStyle('black');"><?php
					?><input class="stdBtn" type="button" style="float:left;" value="Save &#9658;" onclick="$('review_remark').value = $('review_remark_formatted_area').innerHTML;sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php','updateData','review_remark_saveResponse');"><?php
					?><span class="saveResponse"id="review_remark_saveResponse" style="float: left;">Changes were applied</span><?php
					/*?><div title="Undo..." style="width:25%; text-align:right; display:inline; cursor:pointer; font-size:20px; font-weight:bold; color:#004f6b;" id="review_remark_undo" onclick="sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php?undo=1','putInReviewRemark','review_remark_saveResponse');">&#8630;</div><?php */
				}
				?><div title="Expand..." style="width:25%; text-align:right; display:inline; cursor:pointer; font-size:20px; font-weight:bold; color:#004f6b;" id="review_remark_formatted_area_arrow" onclick="colapseDivFromID('review_remark_formatted_area','textarea');">&#9660;</div><?php //&#9660;
				?></div><?php
			}
			
			?><div class="sp" style="height:10px;"></div><?php

			include('../ajax/criteriaList.php');
		?></div><?php
		?><div style="position:relative;height:50px;"></div><?php
	}
	else if($reviewDefined && $review['review_status']==4) //Defined & NA - //JFM 02_10_14not applicable
	{
		?><div class="formStdContainer"><?php
			?><div class="otherStatus" style="font-size:36px;">Review Not Applicable</div><?php //JFM 18_03_14
		?></div><?php

		?><div><img id="bigReviewStatus"src="../common/img/na100.jpg"></div><?php

		?><div class="tableTitle" style="width:40%;">Remarks:</div><?php
		?><form action="#" enctype="multipart/form-data" id="reviewRemarkForm" name="reviewRemarkForm" method="post"style="display:inline;" align="left"><?php
			?><input id="reviewID" name="reviewID" style="display:none;" value="<?=$reviewMlt[0]['review_id']?>" disabled /><?php
			if($editableReview)
			{
				?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" onblur="sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php','updateData','review_remark_saveResponse');"><?=$reviewMlt[0]['remark']?></textarea><?php
			}
			else
			{
				?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" readonly="readonly"><?=$reviewMlt[0]['remark']?></textarea><?php
			}
		?></form><?php
		?><div class="save"><span class="saveResponse"id="review_remark_saveResponse">Changes were applied</span></div><?php

		if(checkPermission('review_profile_id','create',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','create',0,'check',$SESSION)==1)
		{
			?><form action="#" enctype="multipart/form-data" id="reviewEditForm" name="reviewEditForm" method="post" style="text-align:center; height:10px;"><?php
				?><input style="width:0px; display:none;" id="reviewID" name="reviewID" type="text" value="<?=$reviewMlt[0]['review_id']?>" disabled ><?php
				?><input style="width:0px; display:none;" id="makeApplicable" name="makeApplicable" type="text" value="1" disabled ><?php
				?><input style="width:0px; display:none;" id="maxValidationLoopID" name="maxValidationLoopID" type="text" size="50" value="0" disabled ><?php
				?><input class="stdBtn" id="createCriteriaSubmit" onClick="sendAjaxForm('reviewEditForm','ajax/saveReviewValidation.php','reloadSideElement',''); mainRestartNeeded=1;"type="button"value="Make Review Applicable &#9658;"><?php
			?></form><?php
		}
	}
	
	else if($reviewDefined) 
	{
	/*
	* Fix for : US#019,US#019.1 Change workflow for creating a design review
	* Added for displaying general information page above checklist
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
	$apply_flag = 2;  // Staus for customizing checlist
		
	$plannedDateInfo=SqlLi('SELECT planned,approver_name,decision_status,engineering_remarks FROM dr_review_status WHERE review_profile="'.$reviewProfile.'" AND ca='.$GET['ca'].'');
	$reviewLinks = SqlLi('SELECT * FROM dr_review_links WHERE review='.$reviewProfile);
		?><div class="formStdContainer" style="margin-right:30px;"><?php

		 	?><div class="reviewStatus"><img id="bigReviewStatus"src="../common/img/na100.jpg"></div><?php
 
			?><div class="leftInfoBox"><?php
				?><div class="tableTitle" style="padding-top:20px;">General Information:</div><?php
				?><form action="#" enctype="multipart/form-data" id="reviewInfoFrm" method="post" style="display:inline;"><?php
					?><input id="apply_flag" name="aflag" type="hidden"value="<?=$apply_flag?>"><?php
					?><input id="ca"name="ca"type="hidden"value="<?=$GET['ca']?>"><?php
					?><input id="review"name="review"type="hidden"value="<?=$reviewProfile?>"><?php
					?><input id="msn"name="msn"type="hidden"value="<?=$msn?>"><?php
					?><input id="review_status"name="review_status"type="hidden"value="<?=$status[$review['review_status']]?>"><?php
					?><input id="initial_review_status" name="initial_review_status" type="hidden" value="<?=$status[$review['initial_review_status']]?>"><?php //JFM 13_05_16

					?><table class="criteriaTable" align="center" cellspacing="0" cellpadding="0"><?php

						?><tr class="tableGroup"><?php
							?><td colspan="6"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Information</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Details</td><?php
							/*
								US109-General Information not editable by supplier
								Passing review profile id (rpid)
								Fixed By - Infosys Limited
								Version: V 4.5
							*/
								?><td colspan="2" align="center"><input class="stdBtn" onClick="openForm('../ajax/ca','element=<?=$GET['ca']?>&rpid=<?=$GET['review']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Details &#9658;"></td><?php
							/* End for US109 */
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Responsibles</td><?php
								?><td colspan="2" align="center"><input class="stdBtn" onClick="openForm('../ajax/responsible','element=<?=$reviewMlt[0]['review_id']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Responsibles &#9658;"></td><?php			
						?></tr><?php

						?><tr class="tableGroup"><?php
							?><td colspan="3">Review Information</td><?php
							?><td colspan="2">Milestone</td><?php
							?><td style="width:75px">Performed</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php	//JFM 25_11_13
							?><td class="paramDef" style="width:55px;">Applicable <?=$SESSION['table']['review_planning']['ca']['ca']['title']?>s</td><?php
							?><td colspan="2"><?php
								foreach($allCAsInThisReview as $oneCAInThisReview) $allCAsInThisReviewAsString=$allCAsInThisReviewAsString.$oneCAInThisReview['ca'].', ';
								$allCAsInThisReviewAsString=rtrim($allCAsInThisReviewAsString, ", ");
								echo $allCAsInThisReviewAsString;
							?></td><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['planned']['title']?></td><?php
								?><td style="width:125px;"><?php
								if(!empty($plannedDateInfo[0]['planned'])){
									//drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
									drawDate('planned','plannedDateCal',$plannedDateInfo[0]['planned'],false,$editableReview);
								}
								else{
									drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
								}	
								?></td><?php
							?><td></td><?php
						?></tr><?php
/*
* Fix for : US#019.1 Change workflow for creating a design review
* Status option to be disabled until review is validated
* Version: 4.3
* Fixed By: Infosys Limited
*/								
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;"><?=$SESSION['table']['review_planning']['review']['initial_review_status']['title']?></td><?php
							?><td class="disablediv"colspan="2"><?php
								drawStatus('initial_review_status','initialReviewStatus',$review['initial_review_status'],$editableReview,$SESSION); //JFM 13_05_16
							?></td><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['review_date']['title']?></td><?php
								?><td><?php
									drawDate('review_date','reviewDateCal',$review['review_date'],false,$editableReview);
								?></td><?php
								?><td style="width:25px;"><?php drawRadio('review_done',$review['review_done'],$editableReview)?></td><?php
						?></tr><?php
						?><tr class="infoRow"><?php //JFM 09_04_14
							?><td class="paramDef" style="width:55px;"><?=$SESSION['table']['review_planning']['review']['review_status']['title']?></td><?php
							?><td class="disablediv" colspan="2"><?php
								drawStatus('review_status','reviewStatus',$review['review_status'],$editableReview,$SESSION,'defineReviewChklist'); //JFM 13_05_16
							?></td><?php
/// Status option to be disabled until review is validated
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['delta_planned']['title']?></td><?php //JFM 08_06_16
								?><td style="width:125px;"><?php
									drawDate('delta_planned','deltaPlannedDateCal',$review['delta_planned'],false,$editableReview);
								?></td><?php
							?><td></td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;" onMouseOut="nd();"onMouseOver="overlib('<b>Non-Criteria Specific Actions</b><br />These are minor actions unrelated to any criteria.<br />Examples of NCSAs could be document typos which need correcting or long term future actions which do not directly impact the current review.', ABOVE);">NCSA<?php
							?><div style="cursor:pointer">(?)</div></td><?php
							?><td colspan="2"><?php
								?><table><?php
									?><tr><?php
										if($editableReview)
										{
												?><td class="disablediv"><input class="stdBtn" onClick="closeMenu(oldCol); openForm('action','action=new&ca=<?=$GET['ca']?>&review_criteria_id=0&review_id=<?=$reviewMlt[0]['review_id']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button"value="Add NCSA &#9658;"></td><?php

										}
										?><td class="reviewAction r"id="criteria_red_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=0');"style="color:#900;"><?=$redAction?></td><?php
										?><td class="reviewAction a"id="criteria_amber_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=1');"style="color:#CC0;"><?=$amberAction?></td><?php
										?><td class="reviewAction g"id="criteria_green_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=2');"style="color:#060;"><?=$greenAction?></td><?php
										?><td class="reviewAction x"id="criteria_blue_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=3');"style="color:#609dc9;"><?=$blueAction?></td><?php
										$totalAction=$redAction+$amberAction+$greenAction+$blueAction;
										?><td class="reviewAction"id="criteria_total_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0');"><?php if($totalAction!=0)echo $totalAction?></td><?php
									?></tr><?php
								?></table><?php
							?></td><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['delta']['title']?></td><?php //JFM 08_06_16
								?><td><?php
									drawDate('delta','deltaDateCal',$review['delta'],false,$editableReview);
								?></td><?php
								?><td><?php drawRadio('delta_done',$review['delta_done'],$editableReview)?></td><?php
						?></tr>
					<tr class="tableGroup"><?php 
			?><td colspan="6">Validation</td><?php
		?></tr>
					<tr class="infoRow"><?php
				?><td class="paramDef">Validated</td><?php
				?><td style="text-align:center;" colspan="2"><?php
						if (!isset($reviewMlt[0]['validation_complete'])) {
							?><span style="color:#ef343f">No</span></td><?php 
						} else if ($reviewMlt[0]['validation_complete'] == 0) {
							?><span style="color:#ef343f">No</span></td><?php 
						} else if ($reviewMlt[0]['validation_complete'] == 1){
							?><span style="color:#f8d707">Commencing</span><?php 
						} 

				?><td style="width:100px;" class="paramDef">Workflow</td><?php	
					?><td align="center" colspan="2" class="disablediv"> <input class="stdBtn" onClick="openForm('workflow','applicability=<?=$reviewId?>&object=<?=$SESSION['object']['review_id']?>&criterionID=<?=$reviewId?>',false,'GET');" type="button"value="View Workflow &#9658;"></td><?php
			?></tr><?php
							?><tr class="infoRow"><?php
					?><td class="paramDef">Make NA</td><?php
					?><td class="disablediv"><?php
						?><form action="#" enctype="multipart/form-data" id="reviewEditForm" name="reviewEditForm" method="post" style="text-align:center; height:10px;"><?php
							?><input style="width:0px; display:none;" id="reviewID" name="reviewID" type="text" value="<?=$reviewId?>" disabled ><?php
							?><input style="width:0px; display:none;" id="makeApplicable" name="makeApplicable" type="text" value="1" disabled ><?php
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(confirm('This will mark the review as Not Applicable. No information will be lost.\n\nAre you sure you wish to continue?')) {ajaxRequest('ajax/saveReviewValidation.php?makeApplicable=1&reviewID=<?=$reviewId?>','reloadSideElement',false,'POST'); mainRestartNeeded=1;}" type="button" value="Make Review Not Applicable &#9658;"><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><input class="stdBtn disabledField" id="createCriteriaSubmit" onClick="if(confirm('This will mark the review as Not Applicable. No information will be lost.\n\nAre you sure you wish to continue?')) {ajaxRequest('ajax/saveReviewValidation.php?makeApplicable=1&reviewID=<?=$reviewId?>','reloadSideElement',false,'POST'); mainRestartNeeded=1;}" type="button" value="Make Review Not Applicable &#9658;"><?php
							} else {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(confirm('This will mark the review as Not Applicable. No information will be lost.\n\nAre you sure you wish to continue?')) {ajaxRequest('ajax/saveReviewValidation.php?makeApplicable=1&reviewID=<?=$reviewId?>','reloadSideElement',false,'POST'); mainRestartNeeded=1;}" type="button" value="Make Review Not Applicable &#9658;"><?php
							}
						?></form><?php
					?></td><?php
				?></tr><?php
							?><tr class="tableGroup"><?php
							?><td colspan="6">Continuous Assessment Process</td><?php
						?></tr><?php
											?><tr class="infoRow"><?php
							?><td class="paramDef">Active</td><?php
							?><td align="center" colspan="2"><?php
								/*?><input id="continuousassessment_<?=$reviewMlt[0]['review_id']?>" onclick="if(confirm('Are you sure?')){checkChange(this,'cont');}" type="checkbox" value="1" <?php if($reviewMlt[0]['continuous_assessment']==1) echo' checked="checked"'; if(checkPermission('continuous_assessment','create',0,'check',$SESSION)!=1) echo 'disabled="disabled"';?>/><?php*/
							
								switch ($reviewMlt[0]['continuous_assessment']) 
								{
									case 0:
										?><span style="color:#ef343f">No</span><?php
									break;

									case 1:
										?><span style="color:#81c341">Yes</span><?php
									break;
									
									default:
										?><span>Unknown</span><?php
									break;
								}

							?></td><?php
							?><td class="paramDef">CAP Setup</td><?php
							?><td colspan="2" align="center"><?php
								if(checkPermission('continuous_assessment','create',0,'check',$SESSION)==1)
								{
										?><input class="stdBtn" onClick="openForm('capSetup','ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button" value="View CAP Setup &#9658;"><?php
								}
								else
								{
									?><input class="stdBtn" type="button" value="View CAP Setup &#9658;" disabled="disabled"><?php
								}
							?></td><?php
						?></tr>
												<tr class="tableGroup"><?php
							?><td colspan="6">Document Links</td><?php
						?></tr><?php
						?><tr><?php
							?><td colspan="6"><?php
								?><table class="criteriaTable" id="reviewLinksTable" style="margin:0; padding:0;" width="100%" align="left" cellspacing="0" cellpadding="5"><?php
									?><tr><?php
										?><td class="paramDef">Name</td><?php
										?><td class="paramDef">Reference</td><?php
										?><td class="paramDef">Link</td><?php
										?><td class="paramDef"></td><?php
										?><td class="paramDef"></td><?php
									?></tr><?php
									$i=0;
									if(!empty($reviewLinks))
									{
										
										foreach($reviewLinks as $reviewLink)
										{
												?><tr id="rowLink<?=$i?>"><?php
													?><td height="18px;" valign="top"><?php
														?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="nameinputID<?=$i?>" name="nameinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['name'])?>"><?php
													?></td><?php
													?><td height="18px;" valign="top"><?php
														?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="referenceinputID<?=$i?>" name="referenceinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['reference'])?>"><?php
													?></td><?php
													?><td height="18px;" valign="top"><?php
														?><input class="textareaWhite" <?php if($editableReview!=1)echo'disabled '?> id="linkinputID<?=$i?>" name="linkinputID<?=$i?>" onKeyUp="$('linkArrow<?=$i?>').style.display=(this.value=='')?'none':'inline';" size="20" type="text" value="<?=$reviewLink['link']?>"><?php
														?><a class="arrowLink" href="<?=$reviewLink['link']?>" id="linkArrow<?=$i?>" onMouseDown="loadLink(this); "target="_blank"<?php if(!$reviewLink['link']){?>style="display:none;"<?php }?>>&raquo;</a><?php
													?></td><?php
													if($editableReview == 1)
													{
														?><td style="text-align:center;"><?php
															?><input class="xRemove" style="font-size:18px;" onClick="createRowWithNameSuggestionForReviewLinks(this);" type="button" value="&#8626;"/><?php
														?></td><?php
														?><td style="text-align:center;"><?php
															?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
														?></td><?php
													}
												?></tr><?php
											$i++;
										}
									}

									if($editableReview == 1 && $i==0)
									{
										?><tr id="rowLink<?=$i?>"><?php
											?><td height="18px;" valign="top"><?php
												?><input class="textareaWhite" id="nameinputID<?=$i?>" name="nameinputID<?=$i?>" size="20" type="text"><?php
											?></td><?php
											?><td height="18px;" valign="top"><?php
												?><input class="textareaWhite" id="referenceinputID<?=$i?>" name="referenceinputID<?=$i?>" size="20" type="text"><?php
											?></td><?php
											?><td height="18px;" valign="top"><?php
												?><input class="textareaWhite" <?php if($editableReview!=1)echo'disabled '?> id="linkinputID<?=$i?>" name="linkinputID<?=$i?>" onKeyUp="$('linkArrow<?=$i?>').style.display=(this.value=='')?'none':'inline';" size="20" type="text" value="<?=$reviewLink['link']?>"><?php
												?><a class="arrowLink" href="<?=$reviewLink['link']?>" id="linkArrow<?=$i?>" onMouseDown="loadLink(this); "target="_blank"<?php if(!$reviewLink['link']){?>style="display:none;"<?php }?>>&raquo;</a><?php
											?></td><?php
											?><td style="text-align:center;"><?php
												?><input class="xRemove" style="font-size:18px;" onClick="createRowWithNameSuggestionForReviewLinks(this);" type="button" value="&#8626;"/><?php
											?></td><?php
											?><td style="text-align:center;"><?php
												?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
											?></td><?php
										?></tr><?php
									}

								?></table><?php
							?></td><?php
						?></tr>
						<?php
						if(getFilter('area','filter',0,$SESSION)==8)
						{
							?><tr class="tableGroup"><?php
								?><td colspan="6">Design Office Statement</td><?php
							?></tr><?php
							?><tr class="infoRow"><?php
								?><td class="paramDef">Decision of Engineering</td><?php
									?><td colspan="2"><?php
									?><select name="versionEngineerOpinion"><?php
										?><option value="0"></option><?php                                                                                
										?><option value="1" <?=($plannedDateInfo[0]['decision_status']==1)?'selected="selected"':''?> >Pass</option><?php
										?><option value="2" <?=($plannedDateInfo[0]['decision_status']==2)?'selected="selected"':''?> >Fail</option><?php
									?></select><?php
									?></td><?php
								?><td class="paramDef" rowspan="2">Engineering Remarks</td><?php
								?><td rowspan="2" colspan="2"><?php
									?><textarea class="textareaWhite" id="versionEngineerRemark" name="versionEngineerRemark" rows="5" cols="30"><?=$plannedDateInfo[0]['engineering_remarks']?></textarea><?php
								?></td><?php
							?></tr><?php

							?><tr class="infoRow"><?php
								?><td class="paramDef">Approver Name</td><?php
										?><td><?php
									?><div class="suggestion" id="versionEngineerDiv" style="width:159px;"></div><?php
									?><input value="<?=$plannedDateInfo[0]['approver_name']?>" class="textareaWhite" id="versionEngineer" name="versionEngineer" value="" onFocus="loadUserSuggestion(this,'versionEngineerDiv','versionEngineer','','versionEngineerSuggestion');" onKeyPress="return avoidSendForm(event,'user');" size="28" type="text"><?php
									?></td><?php
							?></tr><?php
						}?>
						<input type="hidden" name="defineReviewChklist" id="defineReviewChklist" value="defineReviewChklist">
					</table>
						<?php
					///if($editableReview==1){
						?><div class="save"><span class="saveResponse"id="review_saveResponse">Changes were applied</span><?php
							?><input class="stdBtn" onClick="clickMainTable();" type="button"value="Apply Changes &#9658;"><?php
					        ?></div><?php
					///}
				?></form><?php
			?></div><?php
		?></div><?php
		?><div style="clear:both;"></div><?php
            //Defined but not validated or in validation loop.
		?><div class="formStdContainer"><?php
			?><div class="otherStatus" style="font-size:36px;">Checklist <?=($reviewMlt[0]['validation_complete']==0)?'Customisation':'Validation'?> Commencing</div><?php //JFM 18_03_14
			//JFM 28_10_15
			?><div style=" width:650px; text-align:center; height:100px; position:relative; left:50%; margin-left:-375px;"><?php
				?><div style="position:absolute; left:0px;"   class="checklistDefinitionWorkflowContainerBox"><div style="margin-top:20px;">Define Initial Checklist</div></div><?php
				?><div style="position:absolute; left:150px;" class="checklistDefinitionWorkflowContainerArrow">&#8594;</div><?php
				?><div style="position:absolute; left:200px;" class="checklistDefinitionWorkflowContainerBox<?=($reviewMlt[0]['validation_complete']==0)?'Current':''?>"><div style="margin-top:25px;">Customise Checklist</div></div><?php
				?><div style="position:absolute; left:350px;" class="checklistDefinitionWorkflowContainerArrow">&#8594;</div><?php
				?><div style="position:absolute; left:400px;" class="checklistDefinitionWorkflowContainerBox<?=($reviewMlt[0]['validation_complete']==1)?'Current':''?>"><div style="margin-top:25px;">Checklist Validation</div></div><?php
				?><div style="position:absolute; left:550px;" class="checklistDefinitionWorkflowContainerArrow">&#8594;</div><?php
				?><div style="position:absolute; left:600px;" class="checklistDefinitionWorkflowContainerBox"><div style="margin-top:25px;">Checklist Validated</div></div><?php
			?></div><?php
		?></div><?php

		//JFM 17_08_15
		$allCAsInThisReview=SqlLi('SELECT DISTINCT ca.ca_id, ca.ca 
									FROM c_ca AS ca
										INNER JOIN dr_review_applicability 	AS 	ra 	ON 	ra.ca = ca.ca_id
									WHERE ra.review ="'.$reviewMlt[0]['review_id'].'"
									ORDER BY ca.ca ASC');

		/*?><div class="tableTitle" style="width:50%;">Applicable CAs:</div><?php*/
		?><table class="criteriaTable" id="placeholderTable" style="width:500px; float:left; border-bottom:0px; margin-top:10px;" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup"><?php
				?><td colspan="2">Applicable CAs</td><?php
			?></tr><?php
			?><tr class="infoRow"><?php 
				?><td class="paramDef" style="width:100px;">Applicable CAs</td><?php //JFM 17_08_15
				?><td><?php
					foreach($allCAsInThisReview as $oneCAInThisReview) $allCAsInThisReviewAsString=$allCAsInThisReviewAsString.$oneCAInThisReview['ca'].'<br />';
					$allCAsInThisReviewAsString=rtrim($allCAsInThisReviewAsString, ", ");
					echo $allCAsInThisReviewAsString;
				?></td><?php
			?></tr><?php
		?></table><?php
		?><br /><?php
		
		if(checkPermission('review_profile_id','create',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','create',0,'check',$SESSION)==1)
		{	//echo $reviewMlt[0]['validation_complete'];
                //exit;
			drawValidationTable($reviewMlt[0]['validation_complete'], $reviewMlt[0]['validation_date'], $reviewMlt[0]['review_id'], $SESSION,$editableReview,$review);
			
			//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			
			$isThereAnythingInDrReviewConfigurationForThisReviewId=SqlLi('SELECT 1 FROM dr_review_configuration WHERE review='.$reviewMlt[0]['review_id']);
			if(empty($isThereAnythingInDrReviewConfigurationForThisReviewId)) $reviewMlt[0]['validation_complete']=1;
			
			if($reviewMlt[0]['validation_complete']==0)
			{		
				?><form action="#" enctype="multipart/form-data" id="reviewValidatorForm" name="reviewValidatorForm" method="post"style="display:inline;"><?php
					
					?><table class="criteriaTable" id="placeholderTable" style="width:500px; float:left; border-bottom:0px; margin-top:0px;" cellspacing="0" cellpadding="5"><?php
						?><tr class="tableGroup"><?php
							?><td>Review Validators<span id="reviewValidatorsResponse" style="display:none;" >&zwnj;</span></td><?php
						?></tr><?php
					?></table><?php
					?><table class="criteriaTable" id="reviewValidatorsTable" style="width:500px; float:left; border-top:0px;" cellspacing="0" cellpadding="5"><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" rowspan="100" width="100px">Review Validators<div id="reviewValidatorsResponse" style="display:none;" >&zwnj;</div></td><?php
						?></tr><?php
						
						?><tr id="rowelephantTigerBeehive0"><?php
							?><td width="400px" valign="top"><?php
								?><div class="suggestion"id="test0"style="width:159px;"></div><?php
								?><input class="textareaWhite" id="elephantTigerBeehive0"name="elephantTigerBeehive0" onKeyDown="removeOrCreateNameSuggestion(this,'reviewValidatorsTable','test','elephantTigerBeehive','suggestionID');" onFocus="loadUserSuggestion(this,'test0','elephantTigerBeehive0','','suggestionID0');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
								?><span class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehive0','reviewValidatorsTable');">&#10008;</span><?php
							?></td><?php
						?></tr><?php
					?></table><?php
					
					?><div style="position:relative;height:50px;"></div><?php
					
					?><div class="save" style="float:left"><?php
/*
* Fix for : US #19.1 - Change workflow for creating a design review 
* Planned Date is mandatory for general information above checklist
* Version: 4.3
* Fixed By: Infosys Limited
*/
					$plannedDateInfo=SqlLi('SELECT planned FROM dr_review_status WHERE review_profile="'.$reviewProfile.'" AND ca='.$GET['ca'].'');
						if($plannedDateInfo[0]['planned'] == '0000-00-00'){ 
							?><input class="stdBtn" id="createCriteriaSubmit" onClick="plannedDateMandatory();"type="button"value="Submit For Validation &#9658;"><?php
						}
						else if($plannedDateInfo[0]['planned']){
							?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(validateReview('<?=utf8_encode($SESSION['user']['name'])?>','<?=utf8_encode($SESSION['user']['surname'])?>',1)) {this.disabled=true; this.value='Please Wait...'; sendAjaxForm('reviewValidatorForm','ajax/saveReviewValidation.php','reloadSideElement','criteria_saveResponse');}"type="button"value="Submit For Validation &#9658;"><?php
						}
						else{
							?><input class="stdBtn" id="createCriteriaSubmit" onClick="plannedDateMandatory();"type="button"value="Submit For Validation &#9658;"><?php
						} 
					?></div><?php
//Planned Date is mandatory for general information above checklist					
					?><input id="reviewID" name="reviewID" style="display:none;" value="<?=$reviewMlt[0]['review_id']?>" disabled /><?php
					?><input id="editReview" name="editReview" style="display:none;" value="0" disabled /><?php
					
				?></form><?php
			}
			//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			
			?><div class="sp" style="height:20px;"></div><?php
			?><div class="wideFormTable"id="reviewCriteriaReportList"><?php

			$SESSION['undo'][$reviewMlt[0]['review_id']][0]=$reviewMlt[0]['remark'];

			?><div class="tableTitle" style="width:40%;">Review Remarks:</div><?php
			?><form action="#" enctype="multipart/form-data" id="reviewRemarkForm" name="reviewRemarkForm" method="post"style="display:inline;" align="left"><?php
				?><input id="reviewID" name="reviewID" style="display:none;" value="<?=$reviewMlt[0]['review_id']?>" disabled /><?php
				if($editableReview)
				{
					//JFM 04_08_15
					?><div id="review_remark_formatted_area" class="textarea" style="text-align:left; color:black; height:100px;" contenteditable="true" onPaste="cleanPaste();"><?=str_replace( "\n", '<br />',utf8_encode($reviewMlt[0]['remark']))?></div><?php
					?><textarea id="review_remark" name="review_remark" style="display:none;"></textarea><?php
					/*?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" onblur="sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php','updateData','review_remark_saveResponse');"><?=utf8_encode($reviewMlt[0]['remark'])?></textarea><?php*/
				}
				else
				{
					?><div id="review_remark_formatted_area" class="textarea" style="text-align:left; color:black; height:100px;"><?=str_replace( "\n", '<br />',utf8_encode($reviewMlt[0]['remark']))?></div><?php
					/*?><textarea align="left" class="textarea" id="review_remark" name="review_remark" rows="5" readonly="readonly"><?=utf8_encode($reviewMlt[0]['remark'])?></textarea><?php*/
				}
			?></form><?php
			?><div style="width:95%; text-align:right;"><?php
				if($editableReview) 
				{
					//JFM 04_08_15
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Bold', ABOVE, WRAP);" 			style="font-size:12px; float:left; font-weight:bold;" value="B" onclick="changeStyle('bold');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Italic', ABOVE, WRAP);" 			style="font-size:12px; float:left; font-style:italic;" value="I" onclick="changeStyle('italic');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Return to normal', ABOVE, WRAP);" style="float:left; font-size:12px;" value="N" onclick="changeStyle('normal');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Red', ABOVE, WRAP);" 				style="font-size:12px; float:left; color:#ef343f;" value="&#9632" onclick="changeStyle('red');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Amber', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#f8d707;" value="&#9632" onclick="changeStyle('amber');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Green', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#81c314;" value="&#9632" onclick="changeStyle('green');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Blue', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#0088cf;" value="&#9632" onclick="changeStyle('blue');"><?php
					?><input class="stdBtn" type="button" onMouseOut="nd();"onMouseOver="overlib('Black', ABOVE, WRAP);" 			style="font-size:12px; float:left; color:#000000;" value="&#9632" onclick="changeStyle('black');"><?php
					?><input class="stdBtn" type="button" style="float:left;" value="Save &#9658;" onclick="$('review_remark').value = $('review_remark_formatted_area').innerHTML;sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php','updateData','review_remark_saveResponse');"><?php
					?><span class="saveResponse"id="review_remark_saveResponse" style="float: left;">Changes were applied</span><?php
					/*?><div title="Undo..." style="width:25%; text-align:right; display:inline; cursor:pointer; font-size:20px; font-weight:bold; color:#004f6b;" id="review_remark_undo" onclick="sendAjaxForm('reviewRemarkForm','ajax/saveReviewRemark.php?undo=1','putInReviewRemark','review_remark_saveResponse');">&#8630;</div><?php */
				}
				?><div title="Expand..." style="width:25%; text-align:right; display:inline; cursor:pointer; font-size:20px; font-weight:bold; color:#004f6b;" id="review_remark_formatted_area_arrow" onclick="colapseDivFromID('review_remark_formatted_area','textarea');">&#9660;</div><?php //&#9660;
			?></div><?php
			?><div class="sp" style="height:40px;"></div><?php

			include('../ajax/criteriaList.php');
		?></div><?php
		?><div style="position:relative;height:50px;"></div><?php

		}
		else
		{
			?><center>You do not have permissions to define a new review.</center><?php
		}
	}
	
	else //JFM 22_10_13 - Review needs to be defined.
	{
		//echo $GET['review'];3259
        
		$isThereCriteriaInTheMasterReview=SqlLi('SELECT 1 FROM dr_review_master AS rm
															INNER JOIN dr_review_profile AS rp ON rm.review_type=rp.review_type
														WHERE rp.review_profile_id='.$GET['review']);
		
		$wp=implode(',',SqlSLi('SELECT wp FROM c_cawp WHERE msn="'.$msn.'" AND ca IN ('.$GET['ca'].')','wp'));

		//JFM 18_03_14
		$ca=SqlAsLi('SELECT c.ca_id,c.ca,w.wp_id,w.wp
					FROM c_ca AS c
						INNER JOIN c_cawp	AS cw	ON c.ca_id=cw.ca
						INNER JOIN c_wp		AS w	ON cw.wp=w.wp_id
					WHERE cw.msn="'.$msn.'" AND cw.wp IN ('.$wp.')
					AND c.ca_id NOT IN (SELECT ca FROM dr_review_applicability AS ra INNER JOIN dr_review AS r ON ra.review=r.review_id WHERE r.msn="'.$msn.'" AND r.review_profile='.$reviewProfile.' AND r.validation_complete!=-1)
					ORDER BY ca ASC','ca_id');
	/*
	* Fix for : US#019 Change workflow for creating a design review
	* Added for displaying general information page above checklist
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
	$apply_flag = 1;
		$plannedDateInfo=SqlLi('SELECT planned FROM dr_review_status WHERE review_profile="'.$reviewProfile.'" AND ca='.$GET['ca'].'');
		$reviewLinks = SqlLi('SELECT * FROM dr_review_links WHERE review='.$reviewProfile);
		?><div class="formStdContainer" style="margin-right:30px;"><?php

		 	?><div class="reviewStatus"><img id="bigReviewStatus"src="../common/img/na100.jpg"></div><?php
 
			?><div class="leftInfoBox"><?php
				?><div class="tableTitle" style="padding-top:20px;">General Information:</div><?php
				?><form action="#" enctype="multipart/form-data" id="reviewInfoFrm" method="post" style="display:inline;"><?php
					?><input id="apply_flag" name="aflag" type="hidden"value="<?=$apply_flag?>"><?php
					?><input id="ca"name="ca"type="hidden"value="<?=$GET['ca']?>"><?php
					?><input id="review"name="review"type="hidden"value="<?=$reviewProfile?>"><?php
					?><input id="msn"name="msn"type="hidden"value="<?=$msn?>"><?php
					?><input id="review_status"name="review_status"type="hidden"value="<?=$status[$review['review_status']]?>"><?php
					?><input id="initial_review_status" name="initial_review_status" type="hidden" value="<?=$status[$review['initial_review_status']]?>"><?php //JFM 13_05_16

					?><table class="criteriaTable" align="center" cellspacing="0" cellpadding="0"><?php

						?><tr class="tableGroup"><?php
							?><td colspan="6"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Information</td><?php
						?></tr><?php
								?><tr class="infoRow"><?php
							/*
								US109-General Information not editable by supplier
								Passing review profile id (rpid)
								Fixed By - Infosys Limited
								Version: V 4.5
							*/
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Details</td><?php
								?><td colspan="2" align="center"><input class="stdBtn" onClick="openForm('../ajax/ca','element=<?=$GET['ca']?>&rpid=<?=$GET['review']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Details &#9658;"></td><?php
							/* End for US109 */
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Responsibles</td><?php
								?><td  colspan="2" align="center"><input class="stdBtn" onClick="openForm('../ajax/responsible','element=<?=$reviewProfile?>&reviewProfile=<?=$reviewProfile?>&reviewCa=<?=$GET['ca']?>',false,'GET');" type="button" value="View<?=($editableReview==1)?'/Edit':''?> Responsibles &#9658;"></td><?php			
						?></tr><?php

						?><tr class="tableGroup"><?php
							?><td colspan="3">Review Information</td><?php
							?><td colspan="2">Milestone</td><?php
							?><td style="width:75px">Performed</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php	//JFM 25_11_13
							?><td class="paramDef" style="width:55px;">Applicable <?=$SESSION['table']['review_planning']['ca']['ca']['title']?>s</td><?php
							?><td colspan="2"><?php
								foreach($allCAsInThisReview as $oneCAInThisReview) $allCAsInThisReviewAsString=$allCAsInThisReviewAsString.$oneCAInThisReview['ca'].', ';
								$allCAsInThisReviewAsString=rtrim($allCAsInThisReviewAsString, ", ");
								echo $allCAsInThisReviewAsString;
							?></td><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['planned']['title']?></td><?php
								?><td style="width:125px;"><?php
								if(!empty($plannedDateInfo[0]['planned'])){
									//drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
									drawDate('planned','plannedDateCal',$plannedDateInfo[0]['planned'],false,$editableReview);
								}
								else{
									drawDate('planned','plannedDateCal',$review['planned'],false,$editableReview);
								}	
								?></td><?php
							?><td></td><?php
						?></tr><?php		
						?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:55px;"><?=$SESSION['table']['review_planning']['review']['initial_review_status']['title']?></td><?php
	/*
	* Fix for : US#019.1 Change workflow for creating a design review
	* Status option to be disabled until review is validated
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/							
							?><td class="disablediv" colspan="2"><?php
								drawStatus('initial_review_status','initialReviewStatus',$review['initial_review_status'],$editableReview,$SESSION); //JFM 13_05_16
							?></td><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['review_date']['title']?></td><?php
								?><td><?php
									drawDate('review_date','reviewDateCal',$review['review_date'],false,$editableReview);
								?></td><?php
								?><td style="width:25px;"><?php drawRadio('review_done',$review['review_done'],$editableReview)?></td><?php
						?></tr><?php
						?><tr class="infoRow"><?php //JFM 09_04_14
							?><td class="paramDef" style="width:55px;"><?=$SESSION['table']['review_planning']['review']['review_status']['title']?></td><?php
							?><td class="disablediv" colspan="2"><?php
								drawStatus('review_status','reviewStatus',$review['review_status'],$editableReview,$SESSION,'defineReviewChklist'); //Maheswari
							?></td><?php
//Status option to be disabled until review is validated
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['delta_planned']['title']?></td><?php //JFM 08_06_16
								?><td style="width:125px;"><?php
									drawDate('delta_planned','deltaPlannedDateCal',$review['delta_planned'],false,$editableReview);
								?></td><?php
							?><td></td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;" onMouseOut="nd();"onMouseOver="overlib('<b>Non-Criteria Specific Actions</b><br />These are minor actions unrelated to any criteria.<br />Examples of NCSAs could be document typos which need correcting or long term future actions which do not directly impact the current review.', ABOVE);">NCSA<?php
							?><div style="cursor:pointer">(?)</div></td><?php
							?><td colspan="2"><?php
								?><table><?php
									?><tr><?php
										if($editableReview)
										{
												?><td class="disablediv"><input class="stdBtn" onClick="closeMenu(oldCol); openForm('action','action=new&ca=<?=$GET['ca']?>&review_criteria_id=0&review_id=<?=$reviewMlt[0]['review_id']?>&review_profile=<?=$GET['review']?>',true,'GET');" type="button"value="Add NCSA &#9658;"></td><?php

										}
										?><td class="reviewAction r"id="criteria_red_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=0');"style="color:#900;"><?=$redAction?></td><?php
										?><td class="reviewAction a"id="criteria_amber_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=1');"style="color:#CC0;"><?=$amberAction?></td><?php
										?><td class="reviewAction g"id="criteria_green_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=2');"style="color:#060;"><?=$greenAction?></td><?php
										?><td class="reviewAction x"id="criteria_blue_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0&action_status=3');"style="color:#609dc9;"><?=$blueAction?></td><?php
										$totalAction=$redAction+$amberAction+$greenAction+$blueAction;
										?><td class="reviewAction"id="criteria_total_action_<?=$GET['ca']?>_0"onClick="openList(this,'list_name=action&ca=<?=$GET['ca']?>&review_criteria_id=0');"><?php if($totalAction!=0)echo $totalAction?></td><?php
									?></tr><?php
								?></table><?php
							?></td><?php
							?><td class="paramDef"><?=$SESSION['table']['review_planning']['review']['delta']['title']?></td><?php //JFM 08_06_16
								?><td><?php
									drawDate('delta','deltaDateCal',$review['delta'],false,$editableReview);
								?></td><?php
								?><td><?php drawRadio('delta_done',$review['delta_done'],$editableReview)?></td><?php
						?></tr>
					<tr class="tableGroup"><?php 
			?><td colspan="6">Validation</td><?php
		?></tr>
					<tr class="infoRow"><?php
				?><td class="paramDef">Validated</td><?php
				?><td style="text-align:center;" colspan="2"><?php
						if (!isset($reviewMlt[0]['validation_complete'])) {
							?><span style="color:#ef343f">No</span></td><?php 
						} else if ($reviewMlt[0]['validation_complete'] == 0) {
							?><span style="color:#ef343f">No</span></td><?php 
						} else if ($reviewMlt[0]['validation_complete'] == 1){
							?><span style="color:#f8d707">Commencing</span><?php 
						} 

				?><td style="width:100px;" class="paramDef">Workflow</td><?php	
					?><td class="disablediv"  align="center" colspan="2"> <input class="stdBtn" onClick="openForm('workflow','applicability=<?=$reviewId?>&object=<?=$SESSION['object']['review_id']?>&criterionID=<?=$reviewId?>',false,'GET');" type="button"value="View Workflow &#9658;"></td><?php
			?></tr><?php
							?><tr class="infoRow"><?php
					?><td class="paramDef">Make NA</td><?php
					?><td class="disablediv"><?php
						?><form action="#" enctype="multipart/form-data" id="reviewEditForm" name="reviewEditForm" method="post" style="text-align:center; height:10px;"><?php
							?><input style="width:0px; display:none;" id="reviewID" name="reviewID" type="text" value="<?=$reviewId?>" disabled ><?php
							?><input style="width:0px; display:none;" id="makeApplicable" name="makeApplicable" type="text" value="1" disabled ><?php
							if ((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)) {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(confirm('This will mark the review as Not Applicable. No information will be lost.\n\nAre you sure you wish to continue?')) {ajaxRequest('ajax/saveReviewValidation.php?makeApplicable=1&reviewID=<?=$reviewId?>','reloadSideElement',false,'POST'); mainRestartNeeded=1;}" type="button" value="Make Review Not Applicable &#9658;"><?php
							} else if (($reviewInfo[0]['is_freeze'] == 1) && !empty($reviewInfo[0]['review']) && !empty($reviewInfo[0]['ca_id'])){
								?><input class="stdBtn disabledField" id="createCriteriaSubmit" onClick="if(confirm('This will mark the review as Not Applicable. No information will be lost.\n\nAre you sure you wish to continue?')) {ajaxRequest('ajax/saveReviewValidation.php?makeApplicable=1&reviewID=<?=$reviewId?>','reloadSideElement',false,'POST'); mainRestartNeeded=1;}" type="button" value="Make Review Not Applicable &#9658;"><?php
							} else {
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(confirm('This will mark the review as Not Applicable. No information will be lost.\n\nAre you sure you wish to continue?')) {ajaxRequest('ajax/saveReviewValidation.php?makeApplicable=1&reviewID=<?=$reviewId?>','reloadSideElement',false,'POST'); mainRestartNeeded=1;}" type="button" value="Make Review Not Applicable &#9658;"><?php
							}
						?></form><?php
					?></td><?php
				?></tr><?php
							?><tr class="tableGroup"><?php
							?><td colspan="6">Continuous Assessment Process</td><?php
						?></tr><?php
											?><tr class="infoRow"><?php
							?><td class="paramDef">Active</td><?php
							?><td align="center" colspan="2"><?php
								/*?><input id="continuousassessment_<?=$reviewMlt[0]['review_id']?>" onclick="if(confirm('Are you sure?')){checkChange(this,'cont');}" type="checkbox" value="1" <?php if($reviewMlt[0]['continuous_assessment']==1) echo' checked="checked"'; if(checkPermission('continuous_assessment','create',0,'check',$SESSION)!=1) echo 'disabled="disabled"';?>/><?php*/
							
								switch ($reviewMlt[0]['continuous_assessment']) 
								{
									case 0:
										?><span style="color:#ef343f">No</span><?php
									break;

									case 1:
										?><span style="color:#81c341">Yes</span><?php
									break;
									
									default:
										?><span>Unknown</span><?php
									break;
								}

							?></td><?php
							?><td class="paramDef">CAP Setup</td><?php
							?><td class="disablediv" colspan="2" align="center"><?php
								if(checkPermission('continuous_assessment','create',0,'check',$SESSION)==1)
								{
										?><input class="stdBtn" onClick="openForm('capSetup','ca=<?=$GET['ca']?>&review_profile=<?=$reviewId?>',true,'GET');" type="button" value="View CAP Setup &#9658;"><?php
								}
								else
								{
									?><input class="stdBtn" type="button" value="View CAP Setup &#9658;" disabled="disabled"><?php
								}
							?></td><?php
						?></tr>
												<tr class="tableGroup"><?php
							?><td colspan="6">Document Links</td><?php
						?></tr><?php
						?><tr><?php
							?><td colspan="6"><?php
								?><table class="criteriaTable" id="reviewLinksTable" style="margin:0; padding:0;" width="100%" align="left" cellspacing="0" cellpadding="5"><?php
									?><tr><?php
										?><td class="paramDef">Name</td><?php
										?><td class="paramDef">Reference</td><?php
										?><td class="paramDef">Link</td><?php
										?><td class="paramDef"></td><?php
										?><td class="paramDef"></td><?php
									?></tr><?php
									$i=0;
									if(!empty($reviewLinks))
									{
										
										foreach($reviewLinks as $reviewLink)
										{
												?><tr id="rowLink<?=$i?>"><?php
													?><td height="18px;" valign="top"><?php
														?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="nameinputID<?=$i?>" name="nameinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['name'])?>"><?php
													?></td><?php
													?><td height="18px;" valign="top"><?php
														?><input class="textareaWhite" <?php if(!$editableReview) echo 'disabled'; ?> id="referenceinputID<?=$i?>" name="referenceinputID<?=$i?>" size="20" type="text" value="<?=utf8_encode($reviewLink['reference'])?>"><?php
													?></td><?php
													?><td height="18px;" valign="top"><?php
														?><input class="textareaWhite" <?php if($editableReview!=1)echo'disabled '?> id="linkinputID<?=$i?>" name="linkinputID<?=$i?>" onKeyUp="$('linkArrow<?=$i?>').style.display=(this.value=='')?'none':'inline';" size="20" type="text" value="<?=$reviewLink['link']?>"><?php
														?><a class="arrowLink" href="<?=$reviewLink['link']?>" id="linkArrow<?=$i?>" onMouseDown="loadLink(this); "target="_blank"<?php if(!$reviewLink['link']){?>style="display:none;"<?php }?>>&raquo;</a><?php
													?></td><?php
													if($editableReview == 1)
													{
														?><td style="text-align:center;"><?php
															?><input class="xRemove" style="font-size:18px;" onClick="createRowWithNameSuggestionForReviewLinks(this);" type="button" value="&#8626;"/><?php
														?></td><?php
														?><td style="text-align:center;"><?php
															?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
														?></td><?php
													}
												?></tr><?php
											$i++;
										}
									}

									if($editableReview == 1 && $i==0)
									{
										?><tr id="rowLink<?=$i?>"><?php
											?><td height="18px;" valign="top"><?php
												?><input class="textareaWhite" id="nameinputID<?=$i?>" name="nameinputID<?=$i?>" size="20" type="text"><?php
											?></td><?php
											?><td height="18px;" valign="top"><?php
												?><input class="textareaWhite" id="referenceinputID<?=$i?>" name="referenceinputID<?=$i?>" size="20" type="text"><?php
											?></td><?php
											?><td height="18px;" valign="top"><?php
												?><input class="textareaWhite" <?php if($editableReview!=1)echo'disabled '?> id="linkinputID<?=$i?>" name="linkinputID<?=$i?>" onKeyUp="$('linkArrow<?=$i?>').style.display=(this.value=='')?'none':'inline';" size="20" type="text" value="<?=$reviewLink['link']?>"><?php
												?><a class="arrowLink" href="<?=$reviewLink['link']?>" id="linkArrow<?=$i?>" onMouseDown="loadLink(this); "target="_blank"<?php if(!$reviewLink['link']){?>style="display:none;"<?php }?>>&raquo;</a><?php
											?></td><?php
											?><td style="text-align:center;"><?php
												?><input class="xRemove" style="font-size:18px;" onClick="createRowWithNameSuggestionForReviewLinks(this);" type="button" value="&#8626;"/><?php
											?></td><?php
											?><td style="text-align:center;"><?php
												?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
											?></td><?php
										?></tr><?php
									}

								?></table><?php
							?></td><?php
						?></tr>
						<?php
	/*
	* Fix for : US#019.1 Change workflow for creating a design review
	* Editing information to save into database for displaying gneral inforamtion above the checklist define
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/		
						if(getFilter('area','filter',0,$SESSION)==8)
						{
							?><tr class="tableGroup"><?php
								?><td colspan="6">Design Office Statement</td><?php
							?></tr><?php
							?><tr class="infoRow"><?php
								?><td class="paramDef">Decision of Engineering</td><?php
									?><td colspan="2"><?php
									?><select name="versionEngineerOpinion"><?php
										?><option value="0"></option><?php                                                                                
										?><option value="1" <?=($plannedDateInfo[0]['decision_status']==1)?'selected="selected"':''?> >Pass</option><?php
										?><option value="2" <?=($plannedDateInfo[0]['decision_status']==2)?'selected="selected"':''?> >Fail</option><?php
									?></select><?php
									?></td><?php
								?><td class="paramDef" rowspan="2">Engineering Remarks</td><?php
								?><td rowspan="2" colspan="2"><?php
									?><textarea class="textareaWhite" id="versionEngineerRemark" name="versionEngineerRemark" rows="5" cols="30"><?=$plannedDateInfo[0]['engineering_remarks']?></textarea><?php
								?></td><?php
							?></tr><?php

							?><tr class="infoRow"><?php
								?><td class="paramDef">Approver Name</td><?php
										?><td><?php
									?><div class="suggestion" id="versionEngineerDiv" style="width:159px;"></div><?php
									?><input value="<?=$plannedDateInfo[0]['approver_name']?>" class="textareaWhite" id="versionEngineer" name="versionEngineer" value="" onFocus="loadUserSuggestion(this,'versionEngineerDiv','versionEngineer','','versionEngineerSuggestion');" onKeyPress="return avoidSendForm(event,'user');" size="28" type="text"><?php
									?></td><?php
							?></tr><?php
						}
	//Editing information to save into database for displaying gneral inforamtion above the checklist define
						?><input type="hidden" name="defineReviewChklist" id="defineReviewChklist" value="defineReviewChklist">
					</table>
						<?php
					///if($editableReview==1){
						?><div class="save"><span class="saveResponse"id="review_saveResponse">Changes were applied</span><?php
							?><input class="stdBtn" onClick="clickMainTable();" type="button"value="Apply Changes &#9658;"><?php
					        ?></div><?php
					///}
				?></form><?php
			?></div><?php
		?></div><?php
		?><div style="clear:both;"></div><?php	
		?><div class="formStdContainer"><?php
			?><div class="otherStatus" style="font-size:36px;">No Initial Checklist Defined</div><?php
			//JFM 28_10_15
			?><div style=" width:650px; text-align:center; height:100px; position:relative; left:50%; margin-left:-375px;"><?php
				?><div style="position:absolute; left:0px;"   class="checklistDefinitionWorkflowContainerBoxCurrent"><div style="margin-top:20px;">Define Initial Checklist</div></div><?php
				?><div style="position:absolute; left:150px;" class="checklistDefinitionWorkflowContainerArrow">&#8594;</div><?php
				?><div style="position:absolute; left:200px;" class="checklistDefinitionWorkflowContainerBox"><div style="margin-top:25px;">Customise Checklist</div></div><?php
				?><div style="position:absolute; left:350px;" class="checklistDefinitionWorkflowContainerArrow">&#8594;</div><?php
				?><div style="position:absolute; left:400px;" class="checklistDefinitionWorkflowContainerBox"><div style="margin-top:20px;">Checklist Validation Commencing</div></div><?php
				?><div style="position:absolute; left:550px;" class="checklistDefinitionWorkflowContainerArrow">&#8594;</div><?php
				?><div style="position:absolute; left:600px;" class="checklistDefinitionWorkflowContainerBox"><div style="margin-top:25px;">Checklist Validated</div></div><?php
			?></div><?php
		?></div><?php
				
		if(checkPermission('review_profile_id','create',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','create',0,'check',$SESSION)==1)
		{
			?><div class="tableTitle" align="left">Define New Review Checklist:</div><?php
	
			?><div class="formStdContainer" style="padding-right:5px;"><?php
			
				?><form action="#" enctype="multipart/form-data" id="defineReview" name="defineReview" method="post"><?php
				
					?><input id="review" name="review" type="hidden" value="<?=$reviewProfile?>"><?php
					?><input id="msn" name="msn" type="hidden" value="<?=$msn?>"><?php
					?><input id="review_status" name="review_status" type="hidden" value="<?=$status[$review['review_status']]?>"><?php
					?><input id="initial_review_status" name="initial_review_status" type="hidden" value="<?=$status[$review['initial_review_status']]?>"><?php //JFM 13_05_16
					?><input id="reviewID" name="reviewID" style="display:none;" value="<?=$reviewMlt[0]['review_id']?>" disabled /><?php
					
					?><table class="criteriaTable" id="defineReviewTable" style="width:100%;" align="left" cellspacing="0"><?php
						?><tr class="tableGroup"><?php
							?><td colspan="10">New Review Checklist</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" rowspan="100" width="15%">Import Criteria:</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							if(!empty($isThereCriteriaInTheMasterReview) && getFilter('area','filter',0,$SESSION)!=8) //JFM 19_07_16
							{
								?><td width="20%"><input type="radio" name="defineReviewRadio" id="defineReviewRadioMaster" onclick="if($('reviewNameDiv')) $('reviewNameDiv').style.visibility='hidden';" value="master">From Master</td><?php
							}
							else
							{
								?><td></td><?php
							}
							?><td></td><?php
							?><td class="paramDef" rowspan="100" bgcolor="#E5E5E5" width="20%">Applicability</td><?php
							?><td rowspan="100" width="100%"><?php
							
								?><table id="defineReviewTableApplicability"><?php
									foreach($ca as $caId=>$caDetails)
									{
										?><tr class="infoRow"><?php
											?><td class="chkList"><input id="applicable_ca_<?=$caId?>"name="applicable_ca_<?=$caId?>" type="checkbox"<?php
											if($caId==$GET['ca']) echo 'checked';
											?>></td><?php
											?><td><?=$caDetails['ca']?></td><?php
										?></tr><?php
									}
								?></table><?php
								
							?></td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
/*
	* Fix for : #018-Create Design Review From Review 
	* Showing level1, level2 and Level3 interdependent dropdown
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
						if(!empty($programName))
						{
							?><td width="20%"><input type="radio" name="defineReviewRadio" id="defineReviewRadioReview" onclick="$('reviewNameDiv').style.visibility='visible';" value="fromCa">From Review</td><?php
							?><td width="25%"><?php
								?><div id="reviewNameDiv" style="visibility:hidden"><?php	
							/* 	?><select id="caInfoBox_existing" name="caInfoBox_existing" style="width:100%">
								
								<?php	foreach($caName as $oneCaName)
										{
											?><option value="<?=$oneCaName['ca_id']?>_<?=$oneCaName['review_type_id']?>"><?=$oneCaName['program']?> - <?=$oneCaName['coe']?> - <?=$oneCaName['msn']?> - <?=$oneCaName['ca']?></option><?php
										}
										
									?></select> <?php */
									?><div class="ddSpace"></div><?php
									/// Level 1 dropdown
									?><div style="float:left;width:30%">Level 1</div><?php 
									?><div style="float:right;width:70%;">
									<select id="caInfoBox1" name="caInfoBox1" style="width:100%;" onChange="getListOfCoe(this.value)">
											<option value="" disabled selected>-- Select -- </option>
											<?php	foreach($programName as $oneCaName)
												{
													?><option value="<?=$oneCaName['program_id']?>"><?=$oneCaName['program']?></option><?php
												}
										
									?></select> 
									</div><?php
									// Level 2 dropdown
									?><div class="ddSpace"></div><?php
									?><div style="float:left;width:30%;">Level 2</div><?php 
									?><div style="float:right;width:70%;">
									<select id="caInfoBox2" name="caInfoBox2" style="width:100%" onChange="getListOfMsn(this.value)">
										<?php	
																?><option value="" disabled selected>-- Select -- </option><?php
														
														
									?></select> 
									</div><?php
									// Level 3 dropdown
									?><div class="ddSpace"></div><?php
									?><div style="float:left;width:30%;">Level 3 - CA</div><?php 
									?><div style="float:right;width:70%;"><?php
                                                                        /*
                                                                         * US#113 - Managing of new criteria in different criteria lists
                                                                         * Added span tags for displaying the Warning message when criteria have discrepancy
                                                                         * Version: 4.4
                                                                         * Fixed by: Infosys Limited
                                                                         */     
									?><span id="criteriaModify" style="color:red;display:none;">The Master Criteria have been modified for this Review</span>
                                                                        <span id="criteriaAdded" style="color:red;display:none;">New Criteria have been added to the Master list</span>
                                                                        <span id="criteriaModAdd" style="color:red;display:none;">New Criteria have been added to the Master list and/or Some criteria have been modified</span><?php
                                                                        // End of US#113
									?><select id="caInfoBox" name="caInfoBox" onchange="criteriaCheck();" style="width:100%">
									<option value="" disabled selected>-- Select -- </option><?php
										
									?></select> </div><?php
								?></div><?php
							?></td><?php
						}
	/// End of US#018-Create Design Review From Review 
						?></tr><?php
						
						?><tr class="infoRow"><?php
							?><td width="20%"><input type="radio" name="defineReviewRadio" id="defineReviewRadioBlank" onclick="if($('reviewNameDiv')) $('reviewNameDiv').style.visibility='hidden';" value="blank">Blank Review</td><?php
						?></tr><?php

						?><tr class="infoRow"><?php  //JFM 02_10_14
							?><td width="20%"><input type="radio" name="defineReviewRadio" id="defineReviewRadioNA" onclick="if($('reviewNameDiv')) $('reviewNameDiv').style.visibility='hidden';" value="na">N/A Review</td><?php
						?></tr><?php
					?></table><?php
					
				?></form><?php
				
				?><div class="save" style="float:none; text-align:center;"><?php
					?><span class="saveResponse" id="defineReview_saveResponse"></span><?php
					?><input class="stdBtn" onClick="if(validateReviewDefinition()) {this.disabled=true; this.value='Please Wait...'; sendAjaxForm('defineReview','ajax/saveReviewInfo.php','reloadSideElement','defineReview_saveResponse','POST',true); mainRestartNeeded=1;}"type="button"value="Define Review &#9658;"><?php //JFM 12_01_16
				?></div><?php

			?></div><?php	
		}
		else
		{
			?><center>You do not have permissions to define a new review.</center><?php
		}
		
	}
}
storeSession($SESSION);
?>