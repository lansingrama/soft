<?php
/*
 * US#91 - Improvement:Extra all design reviews
 * Get the Program, Coe and MSN based on the area selection
 * Version: 4.4
 * Created by: Infosys Limited
 */
?><form action="#" enctype="multipart/form-data" id="KpiReportWizardForm" method="post" style="display:inline;">	
<div class="box" id="box1" style="top:15%; left:100%;margin-left:350px;bottom font-size:24px;text-align:center;">
    <div style="font-family: Verdana, Arial, Helvetica, sans-serif;top:115px;text-align: center;margin-right: 381px;padding: 10px 0 10px 0;font-size: 20px;"><?php 
	?>Area: <?php
	?><select  id="areaselect" style="margin-right:30px;" name="area" onchange="kpiWizardAreaSelectChange();">
	<option value="" selected disabled>Select a area</option>
	<?php 
	$areaQuery =sqlLi('SELECT area_id,area FROM `c_area`');
	foreach ($areaQuery as $aname) {
	 ?> <option value="<?=$aname['area_id']?>"> <?=$aname['area']?> </option><?php
	}?>
	
	</select><?php 
		?>
    </div><?php 
    ?><div style="font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 20px;text-align:center;padding-right:320px;">Hold down the Ctrl or Shift button to select multiple options.</div><?php
    ?><div style="height:50%;display:inline;float:left;margin-right:50px;margin-top:20px;"><?php
	?><select id="program" name="program" style="height:250px; width:100%" multiple="multiple" onchange="kpiWizardSelectAllChange('msn');">
        </select><?php
	?><div style="clear:both;"><?php
            ?><input class="stdBtn" type="button" onclick="selectKpiAllMultiple('program');" value="Select All"><?php
            ?><input class="stdBtn" type="button" onclick="selectKpiNoneMultiple('program');" value="Select None"><?php
	?></div><?php
    ?></div>  <?php

    ?><div style="height:60%;display:inline;float:left;margin-right:50px;margin-top: 20px;"><?php
            ?><select id="coe" name="coe" style="height:250px; width:100%" multiple="multiple" onchange="kpiWizardSelectCoeChange();"><?php

            ?></select><?php
            ?><div style="clear:both;"><?php
                    ?><input class="stdBtn" type="button" onclick="selectKpiAllMultiple('coe');" value="Select All"><?php
                    ?><input class="stdBtn" type="button" onclick="selectNoneCoe('coe');" value="Select None"><?php
            ?></div><?php
    ?></div><?php

    ?><div style="height:60%;display:inline;float:left;margin-right:50px;margin-top: 20px;"><?php
            ?><select id="msn" name="msn" style="height:250px; width:100%" multiple="multiple" onchange="kpiWizardSelectMsnChange();"><?php
                            ?></select><?php
            ?><div style="clear:both;"><?php
                    ?><input class="stdBtn" type="button" onclick="selectAllMsn();" value="Select All"><?php
                    ?><input class="stdBtn" type="button" onclick="selectNoneMsn('msn');" value="Select None"><?php
            ?></div><?php
    ?></div><?php
                
    // Add button
    ?><div style="height:60%;display:inline;float:left;margin-right:50px;margin-top: 20px;"><?php
            ?><input id="additm" class="stdBtn" style="opacity:0.5;" type="button" onclick="addItemToTable();" value="Add Items &#9658;" disabled><?php			
    ?></div><?php
?>
<br><?php

?><div style="margin-top: 285px;padding-right: 350px;"><?php
    // Data structure
    ?><table id="dataTable" class="criteriaTable" style="width:380px;" cellspacing="0" cellpadding="5" align="center">
        <tbody>
            <tr class="tableGroup prmRow">
                <td class="paramDef">Area</td>
                <td class="paramDef">Level1</td>
                <td class="paramDef">Level2</td>
                <td class="paramDef">Level3</td>
                <td class="paramDef">Remove</td>
            </tr>
        </tbody>
    </table><?php
?></div>
</div><?php
// Date Picker ?>
 
 <div id="box2" style="height:55%; display:none; float:left; margin-right:50px; font-size:14px;padding-left:60px;position:absolute;left:34%;"><?php
    ?><table cellpadding="5" cellspacing="0"><?php
            ?><tr><?php
                    ?><td>From:</td><?php
                    ?><td id="fromDate"><?php
                            drawDate('from','fromDateCal','',false,1);
                    ?></td><?php
            ?></tr><?php
            ?><tr><?php
                    ?><td>To:</td><?php
                    ?><td id="toDate"><?php
                            drawDate('to','toDateCal','',false,1);
                    ?></td><?php
            ?></tr><?php
			?><tr><td></td></tr><?php
			?><tr><?php
				?><td>Select Option: </td><?php
				?><td><select  id="kipoption" style="margin-right:30px;" name="kipoption">
					<option>Extract Design Reviews</option>					
                                        <option>Extract Criteria</option>
                                        <option>Extract Actions & RIDs</option>
                                        <option>Generate Design Reviews Piechart</option>
                                        <option>Generate Actions Piechart</option>
				</select></td><?php 
			?></tr><?php
			?><tr><td></td></tr><?php
			?><tr><td></td></tr><?php
			?><tr><td><span id="genkpi" name="genkpi" class="stdBtn" onclick="generateReport();">Genarate Report &#9658;</span></td></tr><?php
    ?></table><?php
?></div>

<div class="box" id="box5" style="font-size:14px;position:absolute; top:40%;left:10%;text-align:center; display:none;"><?php 
?></div><?php

?><div class="box" id="criteriaKpi" style="font-size:14px;position:absolute; top:40%;left:22%;text-align:center; display:none;"><?php 
?></div><?php

?><div class="box" id="actionKpi" style="font-size:14px;position:absolute; top:40%;left:36%;text-align:center; display:none;"><?php 
?></div><?php

?><div style="position:absolute; top:44%;left:52%;display:none;" id="piemsg">No data for the selection</div><?php
?><div id="revGraphHolder" name="revGraphHolder" style="position:absolute; top:36%;left:48%;"></div>	<?php

// Added for US096
?><div style="position:absolute; top:44%;left:70%;display:none;" id="pieActionmsg">No Actions for the selection</div><?php
?><div id="actnGraphHolder" name="actnGraphHolder" style="position:absolute; top:36%;left:65%;"></div><?php
//End of US#096
?></form>
<div id="buttonHolder" style="margin:auto; width:50px;padding:20px;"><?php
                ?><div id="forwardButtonDiv" onclick="showErrroMsg();" style="background-color:#f47922; width:120px; height:50px; text-align:center; color:#FFFFFF; font-size:16px; cursor:pointer; float:right;"><?php
                                ?><div id="forwardButton" style="margin-top:15px;">Next &#9658;&#9658;</div><?php
                ?></div>
				<div id="backButtonDiv" onclick="goToPreviousPage();" style="display:none;position:absolute;margin-top:34%;background-color:#6f95ab; width:120px; height:50px; text-align:center; color:#FFFFFF; font-size:16px; cursor:pointer; float:left;"><?php
		?><div id="backButton" style="margin-top:15px; bottom:-15px">&#9668; Previous</div>
	</div>
				<?php
				
?></div>
<div >
    <div id="wizardAreaSelection" class="wizardError" style="text-align:center; font-size:16px; margin-top:5px;display:none"><?php
		?><span>Please select a area</span><?php
    ?></div>
    <div id="wizardlevelSelection" class="wizardError" style="text-align:center; font-size:16px; margin-top:5px;display:none"><?php
       ?><span>Please select at least one option from all boxes</span><?php
    ?></div>
	<div id="wizardDateSelection" class="wizardError" style="text-align:center; font-size:16px; margin-top:5px;display:none"><?php
       ?><span>Please select the Date</span><?php
    ?></div>
	<div id="wizardDateValidation" class="wizardError" style="text-align:center; font-size:16px; margin-top:5px;display:none"><?php
       ?><span>FROM date should be less than TO date !!</span><?php
    ?></div>
	<div id="wizardDataSelection" class="wizardError" style="text-align:center; font-size:16px; margin-top:5px;display:none"><?php
       ?><span>Please Add the Items</span><?php
    ?></div>
	
</div><?php
?>