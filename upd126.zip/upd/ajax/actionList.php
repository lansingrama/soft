<?php

if($included!=1){

	require_once('../support/header.php');

	require_once('../security/checkExpiredSession.php');

	require_once('../../support.php');

	require_once('../support/localSupport.php');

	foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);

}

$status=array('r','a','g');



$validFilter=array('msn','ca','review_criteria_id','action_status');

$actionFilter=array();



foreach($validFilter as $v){

	if(isset($GET[$v]))$actionFilter[]=$v.' IN('.$GET[$v].')';

}

if(count($actionFilter)>0)$qryFilter='WHERE '.implode(' AND ',$actionFilter);


//JFM TODO - CRIT
$action=SqlLi('SELECT ac.action_id,ac.msn,ac.criteria,ac.rid,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_status,ac.action_holder,ac.action_holder_name,ac.action_validator,ac.action_validator_name,

					rd.rid_code,rd.rid_title,rd.rid_status,rd.rid_holder,rd.rid_holder_name,rd.rid_creation,rd.rid_completion,

					CONCAT(u1.surname,", ",u1.name) AS action_holder_txt,CONCAT(u2.surname,", ",u2.name) AS action_validator_txt

				FROM dr_action AS ac

					INNER JOIN dr_action_applicability	AS ap ON ap.action=ac.action_id

					INNER JOIN dr_review_criteria 		AS cr ON ac.criteria=cr.review_criteria_id

					INNER JOIN dr_review_group 			AS gr ON cr.review_group=gr.review_group_id

					LEFT JOIN dr_rid AS rd ON ac.rid=rd.rid_id

					LEFT JOIN c_user AS u1 ON ac.action_holder=u1.user_id

					LEFT JOIN c_user AS u2 ON ac.action_validator=u2.user_id

				'.$qryFilter.'

				ORDER BY ac.rid DESC');



/*

$validFilter=array('msn','ca','review_criteria_id','action_status');



$SESSION['table']['action']['action']

*/





?><div class="wideFormTable"id="actionList"><?php

	?><table class="criteriaTable" style="width:960px;"><?php

		if(is_array($action)){

			?><tr class="tableGroup"><td></td><td>Status</td><td>Code</td><td>Description</td><td>Remark</td><td>Creation</td><td>Completion</td><td>Holder</td><td>Validator</td></tr><?php

			$lastRid='';

			foreach($action as $a){

				foreach($a as $k=>$v)$a[$k]=utf8_encode(stripslashes($v));

				if($a['action_holder']==0){

					$actionHolder=$a['action_holder_name'];

					$actionHolderHighlight=' style="color:#FF0000;"';

				}else{

					$actionHolder=$a['action_holder_txt'];

					$actionHolderHighlight='';

				}

	

				if($a['action_validator']==0){

					$actionValidator=$a['action_validator_name'];

					$actionValidatorHighlight=' style="color:#FF0000;"';

				}else{

					$actionValidator=$a['action_validator_txt'];

					$actionValidatorHighlight='';

				}

				/*if($a['rid']!=$lastRid){

					if($lastRid!=''){?></table></td></tr><?php }

					if($a['rid']!=0){

						?><tr class="tableGroup"><td colspan="<?=($SESSION['Level']>0)?7:6?>" style="background-color:#FF0000;"><?php

							?><table class="criteriaTable"style="background-color:#FFFFFF;"><?php

								?><tr class="tableGroup"><?php

									?><td align="left" colspan="<?=($SESSION['Level']>0)?6:5?>"><b>RID:</b> <?=$a['rid_code']?></td><?php

									?><td align="right"><img alt="Edit this RID"onClick="ajaxRequest('ajax/editRid.php?rid=<?=$a['rid']?>','editRid',true)"src="images/editElement.gif"style="cursor:pointer;">&nbsp;&nbsp;</td><?php

								?></tr><?php

								?><tr><td align="left" colspan="4" valign="middle"><b>Title:</b> <span id="ridTitle_<?=$a['rid']?>"><?=tabIt($a,'rid_title')?></span></td><?php

								?><td colspan="<?=($SESSION['Level']>0)?3:2?>" align="right" valign="middle"><b>Status: </b><img id="ridStatus_<?=$a['rid']?>"src="../common/img/<?=$status[$a['rid_status']]?>20.jpg"></td></tr><?php

								?><tr><?php

									?><td align="left" colspan="2"><?php

										?><b>Creation:</b> <span id="ridCrDate_<?=$a['rid']?>"><?=tabIt($a,'rid_creation')?></span>, <b>Completion:</b> <span id="ridCmDate_<?=$a['rid']?>"><?=tabIt($a,'rid_completion')?></span><?php

									?></td><?php

									?><td align="right" colspan="<?=($SESSION['Level']>0)?5:4?>"><?php

										?><b>RID Holder:</b> <span id="rHName_<?=$a['rid']?>"><?=tabIt($a,'rid_holder_name')?></span><?php

										?> <a href="mailto:<?=$a['rid_holder_email']?>?subject=<?=$SESSION['revT']?>&body=Dear <?=utf8_encode(stripslashes($a['rid_holder_name']))?>,%0D%0A%0D%0A%0D%0A%0D%0A%0D%0A%0D%0ABest Regards,"><img id="rHEmail_<?=$a['rid']?>" alt="Send an Email to <?=$a['rid_holder_name']?>" src="images/email.jpg"></a><?php

									?></td><?php

								?></tr><?php

					}

				}*/

				?><tr<?php /*if($a['rid']!=0){?> style="background-color:#FFFFFF;"<?php }*/?>><?php

					?><td><input class="popUpBtn"onClick="popUpOpt('act','<?=$a['action_id']?>','');"type="button"value="..."><div class="filterMenu"id="popUpActDiv_<?=$a['action_id']?>"></div></td><?php

					?><td align="center"><img id="action_status-<?=$a['action_id']?>"src="../common/img/<?=$status[$a['action_status']]?>20.jpg"></td><?php

					?><td id="action_code-<?=$a['action_id']?>"><?php tabIt($a['action_code'])?></td><?php

					?><td><?php txtBox($a['action_description'],'action_description-'.$a['action_id'])?></td><?php

					?><td><?php txtBox($a['action_remark'],'action_remark-'.$a['action_id'])?></td><?php

					?><td id="action_creation-<?=$a['action_id']?>"><?php tabIt($a['action_creation'])?></td><?php

					?><td id="action_completion-<?=$a['action_id']?>"><?php tabIt($a['action_completion'])?></td><?php

					?><td id="action_holder-<?=$a['action_id']?>"<?=$actionHolderHighlight?>><?php tabIt($actionHolder)?></td><?php

					?><td id="action_validator-<?=$a['action_id']?>"<?=$actionValidatorHighlight?>><?php tabIt($actionValidator)?></td><?php

				?></tr><?php

				$lastRid=$a['rid'];

			}

		}else{

			?><tr class="tableGroup"><td>No results</td></tr><?php

			?><td class="emptyTable">No available Actions for the selected parameters</td><?php

		}

	?></table><?php

?></div>

