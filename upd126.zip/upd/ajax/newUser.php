<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');

require_once('../../support.php');

$userIdQry='SELECT user_id FROM c_user WHERE name="New" AND surname="User"';

$userId=SqlQ($userIdQry);

if(!$userId){
	SqlLQ('INSERT INTO c_user (name,surname) VALUES ("New","User")');
	$userId=SqlQ($userIdQry);
}

$md5Keys=SqlSLi('SELECT user_key FROM c_user','user_id');
$ok=0;
while($ok==0){
	$md5Str=md5($userId.microtime(true).rand());
	if(!in_array($md5Str,$md5Keys)){
		SqlLQ('UPDATE c_user SET user_key="'.$md5Str.'" WHERE user_id="'.$userId['user_id'].'"');
		//$md5Keys[]=$md5Str;
		$ok=1;
	}
}
storeSession($SESSION);

echo 'OK|||'.$userId['user_id'];
?>