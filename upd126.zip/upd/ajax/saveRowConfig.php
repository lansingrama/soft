<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

foreach($_POST as $k=>&$v)$POST[$k]=addslashes(utf8_decode(str_replace(array('|||','&&&','%%%','###'),'_',$v)));

if($POST['repeat_header']=='')$POST['repeat_header']=0;
if($POST['disabled_ca']=='')$POST['disabled_ca']=0;

modifyFilter('max_results',			'view',0,$POST['max_results'],		$SESSION,1);
modifyFilter('repeat_header',		'view',0,$POST['repeat_header'],	$SESSION,1);
modifyFilter('header_frequency',	'view',0,$POST['header_frequency'],	$SESSION,1);
modifyFilter('disabled_ca',			'view',0,$POST['disabled_ca'],		$SESSION,1);

storeSession($SESSION);

?>OK|||1