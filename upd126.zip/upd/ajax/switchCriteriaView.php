<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$v=($_GET['v']=='true')?1:0;

modifyFilter('relevant_criteria','view',0,$v,$SESSION,1);

storeSession($SESSION);
?>OK|||