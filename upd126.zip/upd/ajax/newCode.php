<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
$newCode=newCode($GET['wp'],$GET['criteria'],$SESSION,$GET['type']);
storeSession($SESSION);
echo 'OK|||'.$newCode?>