<?php //JFM 24_03_14
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

if($included!=1) $GET=cleanArray($_GET);
$GET['list_name']='action';
$caArr=explode(',',$GET['ca']);
$caCount=count($caArr);
$criteriaStatusIds;
$allCriteriaInValidationLoop;
$criteriaStatusIfCAPFromRed='a';
if(!empty($GET['msn'])) $msn=$GET['msn'];
else $msn=getFilter('msn','filter',0,$SESSION);

$status=array('r','a','g','x','b','m'); // JFM 27_03_14

$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];

$canEdit=0;

if(checkPermission('review_profile_id','edit',$GET['review_profile'],'check',$SESSION)==1 || checkPermission('review_profile_id','create',$GET['review_profile'],'check',$SESSION)==1 ||
	checkPermission('dr_review_profile_general','edit',0,'check',$SESSION)==1 || checkPermission('dr_review_profile_general','create',0,'check',$SESSION)==1)
{
	$canEdit=1;
}
	
$reviewIDs=SqlSLi('SELECT review_id FROM dr_review AS r
						INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
					WHERE ca IN ('.implode(',',$caArr).') AND msn="'.$msn.'"
					AND review_profile='.$GET['review_profile'],'review_id');

$reviewValidationDate=SqlQ('SELECT validation_date FROM dr_review WHERE review_id='.$reviewIDs[0]);
					
$allCas=SqlSLi('SELECT ca FROM dr_review_applicability WHERE review IN ('.implode(',',$reviewIDs).')','ca');
	
$caArr=$allCas;

/*
 * US#117 - Mirroring Pre-review PPT content in the review view
 * Added addtional columns for Criteria Evidence and Criteria Next Steps
 * Version: 4.4
 * Fixed by: Infosys Limited
 */
$criteriaMlt=SqlLi('SELECT DISTINCT s.criteria_status_id, s.criteria_status,s.criteria_focal_point,s.criteria_comments,s.criteria_evidence,s.criteria_next_steps,s.criteria_planned, cse.criteria_status_evidence_id,ce.*
					FROM dr_criteria_status AS s
						INNER JOIN dr_review_criterion			AS c ON s.review_criteria=c.review_criterion_id
						LEFT JOIN dr_criteria_status_evidence	AS cse ON s.criteria_status_id=cse.criteria_status
						LEFT JOIN dr_criteria_evidence			AS ce ON ce.criteria_evidence_id=cse.criteria_evidence
					WHERE s.msn="'.$GET['msn'].'"
						AND s.ca IN('.implode(',',$caArr).')
						AND c.review_criterion_id="'.$GET['review_criteria_id'].'"');
if(!empty($criteriaMlt))
{
	function item($item) { return $item['criteria_status_id']; }
	$criteriaStatusIds=array_map('item', $criteriaMlt);

	if($GET['continuous_assessment'])
	{
		$providersQry=SqlLi('SELECT CONCAT(u.surname,\', \',u.name) AS provider_full_name, user_id, email
									FROM c_user as u 
										INNER JOIN dr_criteria_status_provider AS csp ON u.user_id=csp.provider
									WHERE csp.criteria_status IN ('.implode(',', $criteriaStatusIds).')');

		$validatorsQry=SqlLi('SELECT CONCAT(u.surname,\', \',u.name) AS validator_full_name, vls.validation_loop_structure_id, vls.validator, u.email
									FROM c_user as u 
										INNER JOIN dr_validation_loop_structure	AS vls ON u.user_id=vls.validator
									WHERE vls.object='.$SESSION['object']['criteria_status_id'].'
									AND vls.applicability IN ('.implode(',', $criteriaStatusIds).')
									AND vls.validation_loop_structure_step!=0
									AND vls.validator_removed=0
									ORDER BY validation_loop_structure_id ASC');

		$overridersQry=SqlLi('SELECT DISTINCT user_id
										FROM c_user as u 
											INNER JOIN dr_validation_loop_override AS vlo ON u.user_id=vlo.user
										WHERE vlo.applicability IN ('.implode(',', $criteriaStatusIds).')
										AND vlo.object='.$SESSION['object']['criteria_status_id']);

		$overriderUserIds=array();

		if(!empty($overridersQry))
		{
			foreach ($overridersQry as $key => $userId) 
			{
				array_push($overriderUserIds, $userId['user_id']);
			}
		}

		$applicableCriteriaQry=SqlLi('SELECT DISTINCT u.user_id, rch.criterion_user_id, rch.criterion
										FROM c_user as u 
											INNER JOIN dr_criteria_status_provider	AS csp ON u.user_id=csp.provider
											INNER JOIN dr_criteria_status			AS s ON s.criteria_status_id=csp.criteria_status
											INNER JOIN dr_review_criterion_history	AS rch ON rch.criterion=s.review_criteria
										WHERE s.msn="'.$GET['msn'].'"
										AND s.ca IN ('.implode(',',$caArr).')
										AND u.user_id='.$viewAsUserId.'
										AND rch.criterion_valid_from <= "'.$reviewValidationDate['validation_date'].'"
										AND rch.criterion_valid_to = "0000-00-00 00:00:00"
										ORDER BY rch.criterion_user_id ASC');

		$criteriaUserId=SqlQ('SELECT DISTINCT criterion_user_id 
								FROM dr_review_criterion_history 
								WHERE criterion='.$GET['review_criteria_id'].'
								AND criterion_valid_from <= "'.$reviewValidationDate['validation_date'].'"
								AND criterion_valid_to = "0000-00-00 00:00:00"');

		$allCriteriaInValidationLoopQry=SqlLi('SELECT DISTINCT s.review_criteria
												FROM c_ca AS ca
													INNER JOIN dr_criteria_status		AS s ON ca.ca_id=s.ca
													INNER JOIN dr_review_configuration	AS c ON s.review_criteria=c.criterion
													INNER JOIN dr_review				AS g ON c.review=g.review_id
													INNER JOIN dr_validation_loop		AS vl ON vl.applicability=s.criteria_status_id
																						AND vl.object='.$SESSION['object']['criteria_status_id'].'
												WHERE s.msn="'.$GET['msn'].'"
												AND ca.ca_id IN ('.implode(',',$caArr).')
												AND g.review_profile="'.$GET['review_profile'].'"');

		$caWp=SqlQ('SELECT wp FROM c_cawp WHERE ca IN ('.implode(',',$caArr).') AND msn="'.$GET['msn'].'"');

		$applicabileCriteriaUsedInTheSameWpQry=SqlLi('SELECT DISTINCT ca.ca_id, ca.ca, vl.validation_loop_id
														FROM c_ca AS ca
														INNER JOIN c_cawp 					AS cawp 	ON  cawp.ca=ca.ca_id
														INNER JOIN dr_review_applicability	AS ra 		ON  ra.ca=ca.ca_id
																										AND ra.ca=cawp.ca
														INNER JOIN dr_review 				AS r 		ON  r.review_id=ra.review
														INNER JOIN dr_review_configuration	AS rconf 	ON  rconf.review=r.review_id
														INNER JOIN dr_criteria_status 		AS cs 		ON  cs.ca=ca.ca_id
																										AND cs.review_criteria=rconf.criterion
														INNER JOIN dr_criteria_status_provider	AS csp  ON csp.criteria_status=cs.criteria_status_id
														LEFT  JOIN dr_validation_loop 		AS vl 		ON  vl.applicability=cs.criteria_status_id
																										AND vl.object='.$SESSION['object']['criteria_status_id'].'
																										AND vl.action_taken='.$SESSION['user_action']['originated'].'
														WHERE 	cawp.wp='.$caWp['wp'].'
														AND 	csp.provider='.$viewAsUserId.'
														AND 	ca.ca_id NOT IN ('.implode(',',$caArr).')
														AND 	rconf.criterion='.$GET['review_criteria_id'].'
														AND 	r.continuous_assessment=1');

		$caName=SqlQ('SELECT ca FROM c_ca WHERE ca_id IN ('.implode(',',$caArr).')');


		if(!empty($allCriteriaInValidationLoopQry)) 
		{
			function item3($item) { return $item['review_criteria']; }
			$allCriteriaInValidationLoop=array_map('item3', $allCriteriaInValidationLoopQry);

			if(in_array($GET['review_criteria_id'], $allCriteriaInValidationLoop)) $alreadyInValidationLoop=1;
		}

		$validatedCheck=SqlQ('SELECT validation_loop_id FROM dr_validation_loop WHERE applicability IN ('.implode(",", $criteriaStatusIds).') AND object='.$SESSION['object']['criteria_status_id'].' AND action_taken=0');

		if($alreadyInValidationLoop==1 && empty($validatedCheck)) $validated=1;

		if($alreadyInValidationLoop==1 && $included!=1) 
		{
			if($validated) $criteriaStatusIfCAPFromRed='x';
			else $criteriaStatusIfCAPFromRed='g';
		}
	}
}

$criteriaMlt=addMissingResults($criteriaMlt,$caCount);

// Added fields criteria_evidence, criteria_next_steps - US#117
$criteria['criteria_status']=combinedResult($criteriaMlt,'criteria_status','status',$SESSION,$caCount);
$criteria['criteria_focal_point']=combinedResult($criteriaMlt,'criteria_focal_point','text',$SESSION,$caCount);
$criteria['criteria_comments']=combinedResult($criteriaMlt,'criteria_comments','text',$SESSION,$caCount);
$criteria['criteria_evidence']=combinedResult($criteriaMlt,'criteria_evidence','text',$SESSION,$caCount);
$criteria['criteria_next_steps']=combinedResult($criteriaMlt,'criteria_next_steps','text',$SESSION,$caCount);
$criteria['criteria_planned']=combinedResult($criteriaMlt,'criteria_planned','date',$SESSION,$caCount);


$activeStatus=pictureStatus($criteria['criteria_status']);

if($included!=1)
{ 
	?>OK|||<?php 
	?><div class="formHeader"><?php
			?><div class="formHeaderInfo">Criteria Details</div><?php
			?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
		?></div><?php
}

?><div style="margin-top: 60px;"><?php
	?><form action="#"enctype="multipart/form-data"id="criteriaStatusFrm"method="post"style="display:inline;"><?php
		?><input id="ca"name="ca"type="hidden"value="<?=$GET['ca']?>"><?php
		?><input id="criteriaCriteriaTable0"name="criteriaCriteriaTable0"type="hidden"value="<?=$GET['review_criteria_id']?>"><?php
		?><input id="criteria_status"name="criteria_status"type="hidden" value="<?=$status[$criteria['criteria_status']]?>"><?php
		?><input id="review_profile"name="review_profile"type="hidden" value="<?=$GET['review_profile']?>"><?php

		if($alreadyInValidationLoop==1 && $included!=1) 
		{
			$textColour=($validated)?'green':'#FF0000';
			?><div align="center" style="font-size:14px; font-weight:bold; color:<?=$textColour?>;"><?php
				if($validated) echo 'Evidences have been validated.';
				else echo 'Evidences have been submitted and are in the process of being validated.';
			?><br /><br /></div><?php
		}
                
                /*
                 * Fix for: Improvement - Comments Criteria ID
                 * Fixed By: Infosys Limited
                 * Version: 4.2
                 * Added 'Associated Criteria' section
                 */   
                if($GET['action'] == 'new') {
                    $action['review_profile_id']=$GET['review_profile'];
                    $action['criteria']=$GET['review_criteria_id'];
                    $action['review']=$GET['review_id'];
                    $action['action_status']=1;
                    $action['rid_status']=1;

                    if($action['validation_loop']==1 && $action['action_status']>1)	
                        $editableAction=0;
                    else if(checkPermission('review_profile_id','edit',$action['review_profile_id'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','edit',0,'check',$SESSION)==1) 
                        $editableAction=1;
                    else if ($action['action_holder']==$SESSION['user']['user_id'] || $action['action_validator']==$SESSION['user']['user_id'])
                        $editableAction=1;
                    else $editableAction=0;

                    if($action['criteria']!=0)
                    {
                        ?><div class="tableTitle" style="text-align:left;"><?php
                                ?>Associated Criteria:<?php
                        ?></div><?php
                        require_once('../ajax/criteriaColumnTable.php');
                    }
                }
                ?><br></br><?php
                //End of Improvement - Comments Criteria ID
                
                ?><table class="criteriaTable" align="left" cellspacing="0" width="600px;"><?php
                
			if(!$GET['continuous_assessment'])
			{

				?><tr class="tableGroup"><?php
					?><td colspan="10">Criteria Status</td><?php
				?></tr><?php
				?><tr class="infoRow"><?php
					?><td class="paramDef" style="width:55px;">Status</td><?php
					?><td colspan="2"><?php
						drawStatus('criteria_status','criteriaStatus',$criteria['criteria_status'],$canEdit,$SESSION); //JFM 13_05_16
					?></td><?php
                                        ?><td><input class="stdBtn"onClick="sendAjaxForm('criteriaStatusFrm','ajax/saveCriteriaStatus.php','updateData','criteriaStatus_saveResponse'); closeLastForm();"type="button"value="Apply Changes &#9658;"></td><?php
				?></tr><?php
			}
			else
			{
				?><tr class="tableGroup"><?php
					?><td colspan="2">Continuous Assessment Evidence</td><?php
				?></tr><?php
				?><tr class="infoRow"><?php
					?><td class="paramDef"  width="30%">Planned</td><?php
					?><td><?php
						drawDate('criteriaPlanned','criteriaPlannedDateCal',$criteria['criteria_planned'],false, $canEdit);
					?></td><?php
				?></tr><?php
				?><tr class="infoRow"><?php
					?><td class="paramDef"  width="30%">At Risk</td><?php
					?><td><?php
						?><input type="checkbox" onclick="if(this.checked==false) $('criteria_status').value='<?=$criteriaStatusIfCAPFromRed?>'; if(this.checked==true) $('criteria_status').value='r';" name="statusRed" id="statusRed" <?php if($criteria['criteria_status']==0) echo 'checked '; if(!$canEdit) echo 'disabled="disabled"'; ?> /><?php
					?></td><?php
				?></tr><?php
				?></table><?php

				//
				// Provider List
				//
				
				$providerUserIds=array();

				?><table class="criteriaTable" id="criteriaprovidersTable" align="left" cellspacing="0" width="600px;"><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" rowspan="100" width="15%">Providers<div id="providerResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
					?></tr><?php
					
						$i=0;
						if(!empty($providersQry))
						{
							foreach($providersQry as $provider)
							{
								?><tr id="rowprovidersinputID<?=$i?>"><?php
									?><td width="35%" valign="top"><?php
										?><div class="suggestion"id="providersdivID<?=$i?>"style="width:159px;"></div><?php
										?><input <?php if($alreadyInValidationLoop || !$canEdit) echo 'disabled'; ?> class="textareaWhite" id="providersinputID<?=$i?>"name="providersinputID<?=$i?>" value="<?=utf8_encode($provider['provider_full_name'])?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaprovidersTable','providersdivID','providersinputID','providerssuggestionID');" onFocus="loadUserSuggestion(this,'providersdivID<?=$i?>','providersinputID<?=$i?>','','providerssuggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php

										if(!$alreadyInValidationLoop && $canEdit)
										{
											?><input class="xRemove" onClick="deleteRowByInputID('providersinputID<?=$i?>','criteriaprovidersTable');" type="button" value="&#10008;"/><?php
										}

										?><img class="xRemove" style="cursor:pointer;" alt="Open Contact Card" onclick="showOOUI('<?=$provider['email']?>');" onmouseout="hideOOUI();" src="../common/img/info.png"><?php //JFM 02_10_14

									?></td><?php
								?></tr><?php
								$i++;

								array_push($providerUserIds, $provider['user_id']);
							}
						}
					
					if(!$alreadyInValidationLoop && $canEdit)
					{
						?><tr id="rowprovidersinputID<?=$i?>"><?php
							?><td width="35%" valign="top"><?php
								?><div class="suggestion"id="providersdivID<?=$i?>"style="width:159px;"></div><?php
								?><input class="textareaWhite" id="providersinputID<?=$i?>"name="providersinputID<?=$i?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaprovidersTable','providersdivID','providersinputID','providerssuggestionID');" onFocus="loadUserSuggestion(this,'providersdivID<?=$i?>','providersinputID<?=$i?>','','providerssuggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
								?><input class="xRemove" onClick="deleteRowByInputID('providersinputID<?=$i?>','criteriaprovidersTable');" type="button" value="&#10008;"/><?php
							?></td><?php
						?></tr><?php
					}

				?></table><?php

				//
				// Evidence List
				//
				
				?><table class="criteriaTable" id="criteriaEvidenceTable" align="left" cellspacing="0" width="600px;"><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" rowspan="100" width="15%">Links<div id="evidenceResponse" style="visibility:hidden;">&zwnj;</div></td><?php
					?></tr><?php

					$alertColorMessage=array('red'=>'________________________<br /><b>FILE STATUS: WARNING</b><br />&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;<br />The live file & server information does not match.<br /><br />This means the file has changed since being submitted and must be revalidated.',
											 'yellow'=>'________________________<br /><b>FILE STATUS: UNKNOWN</b><br />&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;<br />Could not get information about the file.<br /><br />This maybe caused by the file being stored on a unmounted network drive, private iShare or other secure server.<br />It may also be caused by an incorrect file URL.',
											 'green'=>'________________________<br /><b>FILE STATUS: OK</b><br />&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;&#8254;<br />The live file & server information match correctly.');
					$i=0;
					if(!empty($criteriaMlt) && $GET['review_validated'])
					{
						foreach($criteriaMlt as $evidence)
						{
							if(!empty($evidence['file_link']))
							{
								$alertColor='';
								if($evidence['file_size']=='-1' && $evidence['file_date_modified']=='9999-12-31 00:00:00') $alertColor='yellow';
								
								else
								{
									$checkFileLink=@fopen($evidence['file_link'],'r');
									$checkedFileLinkData=@stream_get_meta_data($checkFileLink);
									@fclose($checkFileLink);			 
									$date = substr(substr($checkedFileLinkData['wrapper_data'][4],15),0,-4);
									$dateInfo = date_parse_from_format_for_php_5_2_9('D, j M Y H:i:s', $date);
									$dateInfoFinal=$dateInfo['year'].'-'.str_pad($dateInfo['month'],2,'0',STR_PAD_LEFT).'-'.str_pad($dateInfo['day'],2,'0',STR_PAD_LEFT).' '.str_pad($dateInfo['hour'],2,'0',STR_PAD_LEFT).':'.str_pad($dateInfo['minute'],2,'0',STR_PAD_LEFT).':'.str_pad($dateInfo['second'],2,'0',STR_PAD_LEFT);

									if(substr($checkedFileLinkData['wrapper_data'][1],16)!=$evidence['file_size'] || $dateInfoFinal!=$evidence['file_date_modified']) $alertColor='red';
									else $alertColor='green';
								}

								?><tr id="rowevidencesinputID<?=$i?>"><?php
									?><td width="35%" valign="top"><?php
										?><div class="suggestion"id="evidencesdivID<?=$i?>"style="width:159px;"></div><?php
										?><input <?php if(!in_array($viewAsUserId, $providerUserIds) || ($alreadyInValidationLoop && !$modifying)) echo 'disabled'; ?> class="textareaWhite" id="evidencesinputID<?=$i?>"name="evidencesinputID<?=$i?>" value="<?=$evidence['file_link']?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaEvidenceTable','evidencesdivID','evidencesinputID','evidencessuggestionID','evidence');" onFocus="loadUserSuggestion(this,'evidencesdivID<?=$i?>','evidencesinputID<?=$i?>','','evidencessuggestionID<?=$i?>','evidence');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
										
										if(in_array($viewAsUserId, $providerUserIds) && (!$alreadyInValidationLoop || $modifying))
										{
											?><input class="xRemove" onClick="deleteRowByInputID('evidencesinputID<?=$i?>','criteriaEvidenceTable');" type="button" value="&#10008;"/><?php
										}
										
										?><a href="<?=$evidence['file_link']?>" target="_blank"><?php
											?><img class="xRemove" style="cursor:pointer;" id="alert" onMouseOut="nd();" onMouseOver="overlibGlobalDivId='testTest'; overlib('<?=$alertColorMessage[$alertColor]?>', RIGHT, CAPTION,'FOR YOUR INFORMATION', WIDTH, 320);overlibGlobalDivId='';"src="../common/img/alert_<?=$alertColor?>_small.png"><?php
										?></a><?php
										?> <a href="<?=$evidence['file_link']?>" target="_blank">GoTo &#9658;</a><?php
									?></td><?php
								?></tr><?php
								$i++;
							}
						}
					}
					
					if((!$alreadyInValidationLoop  || $modifying) && $GET['review_validated'])
					{
						?><tr id="rowevidencesinputID<?=$i?>"><?php
							?><td width="35%" valign="top"><?php
								?><div class="suggestion"id="evidencesdivID<?=$i?>"style="width:159px;"></div><?php
								?><input <?php if(!in_array($viewAsUserId, $providerUserIds)) echo 'disabled'; ?> class="textareaWhite" id="evidencesinputID<?=$i?>"name="evidencesinputID<?=$i?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaEvidenceTable','evidencesdivID','evidencesinputID','evidencessuggestionID','evidence');" onFocus="loadUserSuggestion(this,'evidencesdivID<?=$i?>','evidencesinputID<?=$i?>','','evidencessuggestionID<?=$i?>','evidence');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
								
								if(in_array($viewAsUserId, $providerUserIds))
								{
									?><input class="xRemove" onClick="deleteRowByInputID('evidencesinputID<?=$i?>','criteriaEvidenceTable');" type="button" value="&#10008;"/><?php
								}
							?></td><?php
						?></tr><?php
					}
					
				?></table><?php

				//
				// Validation List
				//
				
				?><table class="criteriaTable" id="criteriaValidatorsTable" align="left" cellspacing="0" width="600px;"><?php
					?><tr class="infoRow" width="55px;"><?php
						?><td class="paramDef" rowspan="100" width="15%">Stakeholders<div id="inputIDResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
					?></tr><?php
					
						$i=0;
						if(!empty($validatorsQry))
						{
							foreach($validatorsQry as $validator)
							{
								?><tr id="rowelephantTigerBeehiveinputID<?=$i?>"><?php
									?><td width="35%" valign="top"><?php
										?><div class="suggestion"id="divID<?=$i?>"style="width:159px;"></div><?php
										?><input <?php if($alreadyInValidationLoop || !$canEdit) echo 'disabled'; ?>  class="textareaWhite" id="elephantTigerBeehiveinputID<?=$i?>"name="elephantTigerBeehiveinputID<?=$i?>" value="<?=utf8_encode($validator['validator_full_name'])?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaValidatorsTable','divID','elephantTigerBeehiveinputID','suggestionID');" onFocus="loadUserSuggestion(this,'divID<?=$i?>','elephantTigerBeehiveinputID<?=$i?>','','suggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
										
										if(!$alreadyInValidationLoop && $canEdit)
										{
											?><input class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehiveinputID<?=$i?>','criteriaValidatorsTable');" type="button" value="&#10008;"/><?php
										}

										?><img class="xRemove" style="cursor:pointer;" alt="Open Contact Card" onclick="showOOUI('<?=$validator['email']?>');" onmouseout="hideOOUI();" src="../common/img/info.png"><?php //JFM 02_10_14

										if(!$validated && in_array($viewAsUserId, $overriderUserIds) && $alreadyInValidationLoop) //JFM 01_10_14
										{
											?><input class="xRemove" onClick="closeLastForm(); openForm('forceEditValidationLoopPerson','applicability=<?=implode(',', $criteriaStatusIds)?>&object=<?=$SESSION['object']['criteria_status_id']?>&validation_loop_structure_id=<?=$validator['validation_loop_structure_id']?>&validator=<?=$validator['validator']?>',false,'GET',500,230);" type="button" value="Change Stakeholder &#9658;"/><?php											
										}
									?></td><?php
								?></tr><?php
								$i++;
							}
						}
					
					if(!$alreadyInValidationLoop && $canEdit)
					{
						?><tr id="rowelephantTigerBeehiveinputID<?=$i?>"><?php
							?><td width="35%" valign="top"><?php
								?><div class="suggestion"id="divID<?=$i?>"style="width:159px;"></div><?php
								?><input class="textareaWhite" id="elephantTigerBeehiveinputID<?=$i?>"name="elephantTigerBeehiveinputID<?=$i?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaValidatorsTable','divID','elephantTigerBeehiveinputID','suggestionID');" onFocus="loadUserSuggestion(this,'divID<?=$i?>','elephantTigerBeehiveinputID<?=$i?>','','suggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
								?><input class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehiveinputID<?=$i?>','criteriaValidatorsTable');" type="button" value="&#10008;"/><?php
							?></td><?php
						?></tr><?php
					}

				?></table><?php

				//
				// Applicable Criterias
				//

				?><table class="criteriaTable" id="criteriaCriteriaTable" align="left" cellspacing="0" width="600px;"><?php
					?><tr class="infoRow" width="55px;"><?php
						?><td class="paramDef" rowspan="100" width="30%">Applicable Criteria<div id="applicableCriteriaResponse" style="visibility:hidden;">&zwnj;</div></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td><?php
							?><?=$criteriaUserId['criterion_user_id']?><?php
						?></td><?php
					?></tr><?php
					?><tr><?php
						?><td id="criteriaCriteriaTableDropDownTd"><?php
							if(!empty($applicableCriteriaQry) && in_array($viewAsUserId, $providerUserIds) && !$alreadyInValidationLoop)
							{
								?><select id="applicableCriteriaBox" name="applicableCriteriaBox" style="width:80%;"><?php
									
									foreach($applicableCriteriaQry as $applicableCriteria)
									{
										if($applicableCriteria['criterion']!=$GET['review_criteria_id'] && !in_array($applicableCriteria['criterion'], $allCriteriaInValidationLoop))
										{
											?><option value="<?=$applicableCriteria['criterion']?>"><?=$applicableCriteria['criterion_user_id']?></option><?php
										}
									}
									
								?></select><?php
								?><input class="xRemove" onClick="createRowFromDropDown('criteriaCriteriaTable', 'applicableCriteriaBox','applicableCriteriainputID','add')" type="button" value="+"/><?php
							}
						?></td><?php
					?></tr><?php
				?></table><?php


				//
				// Applicable CAs in WP.
				//

				?><table class="criteriaTable" id="criteriaCriteriaUsedInTheSameWpTable" align="left" cellspacing="0" width="600px;"><?php
					?><tr class="infoRow" width="55px;"><?php
						?><td class="paramDef" rowspan="100" width="30%">Applicable CAs<div id="applicableCAsResponse" style="visibility:hidden;">&zwnj;</div></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td><?php
							?><?=$caName['ca']?><?php
						?></td><?php
					?></tr><?php
					?><tr><?php
						?><td id="criteriaCriteriaUsedInTheSameWpTableDropDownTd"><?php
							if(!empty($applicabileCriteriaUsedInTheSameWpQry) && !$alreadyInValidationLoop)
							{
								?><select id="applicableCriteriaUsedInTheSameWpBox" name="applicableCriteriaUsedInTheSameWpBox" style="width:80%;"><?php
									
									foreach($applicabileCriteriaUsedInTheSameWpQry as $applicabileCriteriaUsedInTheSameWp)
									{
										if($applicabileCriteriaUsedInTheSameWp['validation_loop_id']=='')
										{
											?><option value="<?=$applicabileCriteriaUsedInTheSameWp['ca_id']?>"><?=$applicabileCriteriaUsedInTheSameWp['ca']?></option><?php
										}
									}
									
								?></select><?php
								?><input class="xRemove" onClick="createRowFromDropDown('criteriaCriteriaUsedInTheSameWpTable', 'applicableCriteriaUsedInTheSameWpBox','applicableCriteriaUsedInTheSameWpinputID','add');" type="button" value="+"/><?php
							}
						?></td><?php
					?></tr><?php
				?></table><?php
			}

			?><table class="criteriaTable" style="width:600px; margin-top:20px;" align="left" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup"><?php
				?><td colspan="3">Details</td><?php
			?></tr><?php
			drawStdField('Focal Point','criteria_focal_point',$criteria['criteria_focal_point'],42);
			?><tr class="infoRow"><?php
				?><td class="paramDef">Comments\Highlights</td><?php
				?><td colspan="2"><textarea class="textareaWhite" style="background-color:#FFFFFF;" cols="80" rows="30" id="criteria_comments"name="criteria_comments"rows="6"style="overflow-x:hidden;"><?=utf8_encode($criteria['criteria_comments'])?></textarea></td><?php
			?></tr><?php
                        // Added new textboxes for Evidence and Next steps - US#117
                        ?><tr class="infoRow"><?php
				?><td class="paramDef">Evidence</td><?php
				?><td colspan="2"><textarea class="textareaWhite" style="background-color:#FFFFFF;" cols="80" rows="20" id="criteria_evidence" name="criteria_evidence"rows="6"style="overflow-x:hidden;"><?=utf8_encode($criteria['criteria_evidence'])?></textarea></td><?php
			?></tr><?php
                        ?><tr class="infoRow"><?php
				?><td class="paramDef">Next Steps</td><?php
				?><td colspan="2"><textarea class="textareaWhite" style="background-color:#FFFFFF;" cols="80" rows="20" id="criteria_next_steps" name="criteria_next_steps"rows="6"style="overflow-x:hidden;"><?=utf8_encode($criteria['criteria_next_steps'])?></textarea></td><?php
			?></tr><?php
                        // End of US#117
		?></table><?php
		if($included!=1 || $modifying)
		{
			if((!$GET['continuous_assessment'] || $alreadyInValidationLoop) && !$modifying)
			{
				?><div class="save" style="float:left;"><?php
					?><span class="saveResponse"id="criteriaStatus_saveResponse">Changes were applied</span><?php 
					
					if($alreadyInValidationLoop) 
					{ 
						?><input class="stdBtn"onClick="openForm('workflow','applicability=<?=implode(',', $criteriaStatusIds)?>&object=<?=$SESSION['object']['criteria_status_id']?>',false,'GET');"type="button"value="View Workflow &#9658;"><?php 
						
						if(!$validated && in_array($viewAsUserId, $overriderUserIds))
						{

							?><input class="stdBtn" onClick="openForm('../ajax/validationRespond','applicability=<?=$criteriaStatusIds[0]?>&object=<?=$SESSION['object']['criteria_status_id']?>&extra_comments=1',false,'GET');" type="button" value="Override Workflow &#9658;"><?php
						}
					} 

					
					?><input class="stdBtn"onClick="sendAjaxForm('criteriaStatusFrm','ajax/saveCriteriaStatus.php','updateData','criteriaStatus_saveResponse'); closeLastForm();"type="button"value="Apply Changes &#9658;"><?php
				?></div><?php
			}
			else
			{
				?><input id="continuous_assessment"name="continuous_assessment"type="hidden" value="<?=$GET['continuous_assessment']?>"><?php
				?><input id="startValidationLoop"name="startValidationLoop"type="hidden" value="0"><?php
				?><input id="msn"name="msn"type="hidden" value="<?=$GET['msn']?>"><?php
				if($modifying) { ?><input id="modifying"name="modifying"type="hidden" value="1"><?php }
				?><div class="save" style="float:left;"><input class="stdBtn" style="display:inline;" <?php if(!in_array($viewAsUserId, $providerUserIds) || !$GET['review_validated']) echo 'disabled'; ?> onClick="if(validateEvidence('1')){$('startValidationLoop').value=1; sendAjaxForm('criteriaStatusFrm','ajax/saveCriteriaStatus.php','updateData','criteriaStatus_saveResponse'); closeLastForm();<?php if($modifying){ ?> clock(); clock(); sideValidation(<?=$SESSION['object']['criteria_status_id']?>); <?php } ?>}" type="button"value="Start Validation &#9658;" /><?php if(!$modifying) { ?><input class="stdBtn" style="display:inline;" onClick="if(validateEvidence()){sendAjaxForm('criteriaStatusFrm','ajax/saveCriteriaStatus.php','updateData','criteriaStatus_saveResponse'); closeLastForm();}"type="button"value="Apply Changes &#9658;" /><?php } ?></div><?php
			}
		}
	?></form><?php
?></div><?php
storeSession($SESSION);
?>