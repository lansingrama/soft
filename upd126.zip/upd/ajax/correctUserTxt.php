<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$GET=cleanArray($_GET);

if($GET['correct_position']!='' && $GET['correct_action_id']!='' && $GET['correct_user_id']!=''){
	/*$userTxtQry=SqlQ('SELECT action_'.$GET['correct_position'].'_name FROM dr_action WHERE action_id="'.$GET['correct_action_id'].'"');
	$POST['action_'.$POST['correct_position'].'_name']=$userTxtQry['action_'.$POST['correct_position'].'_name'];*/
	
	
	
	/*echo 'UPDATE dr_action
			SET action_'.$GET['correct_position'].'="'.$GET['correct_user_id'].'", action_'.$GET['correct_position'].'_name=""
			WHERE action_id="'.$GET['correct_action_id'].'"<br>';
	
	echo 'SELECT CONCAT(u.name," ",u.surname) AS user_name
					FROM dr_action AS a
						INNER JOIN c_user AS u ON a.action_'.$GET['correct_position'].'=u.user_id
					WHERE action_id="'.$GET['correct_action_id'].'"';*/
	
	SqlLQ('UPDATE dr_action
			SET action_'.$GET['correct_position'].'="'.$GET['correct_user_id'].'", action_'.$GET['correct_position'].'_name=""
			WHERE action_id="'.$GET['correct_action_id'].'"');
	$correctedName=SqlQ('SELECT CONCAT(u.surname,", ",u.name) AS user_name
					FROM dr_action AS a
						INNER JOIN c_user AS u ON a.action_'.$GET['correct_position'].'=u.user_id
					WHERE action_id="'.$GET['correct_action_id'].'"');
	if($correctedName['user_name']!=''){
		echo 'OK|||action_'.$GET['correct_position'].'_'.$GET['correct_action_id'].'%%%text%%%'.$correctedName['user_name'];
	}
}
storeSession($SESSION);
?>