<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$GET = cleanArray($_GET);

//if($GET['objTxt'] == 'program') {
    $msnQry= mysql_query('SELECT count(*) FROM c_msn WHERE coe='.$GET['coe'].' AND msn_id='.$GET['msn']);
//} elseif($GET['objTxt'] == 'cawp'){
//    if($GET['product']) {
//        $msnQry = mysql_query('SELECT count(*) FROM c_ca WHERE ca='.$GET['product']);
//    }
    
//}

$countQry=mysql_result($msnQry, 0);

echo 'OK|||',$countQry;
?>
