<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

$imageFile=SqlQ('SELECT '.$GET['target'].'_image_file FROM c_'.$GET['target'].' WHERE '.$GET['target'].'_id="'.$GET['target_id'].'"');

if($imageFile){
	unlink('../img/'.$GET['target'].'/'.$imageFile[$GET['target'].'_image_file']);
	SqlLQ('UPDATE c_'.$GET['target'].' SET '.$GET['target'].'_image_file="" WHERE '.$GET['target'].'_id="'.$GET['target_id'].'"');
}
storeSession($SESSION);

?>OK|||OK