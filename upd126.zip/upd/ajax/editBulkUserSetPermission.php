<?php

/*
 * File to set the permissions for Bulk users when edited from 'Edit Multiple Users' 
 * Fix for US #032,#033 Improvement - Bulk user upload (Suggested by ICT)
 * Created By: Infosys Ltd
 * Version: 4.3
 */

require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/mail.php');
$POST=cleanArray($_POST);
$postValues = trim($POST['location']);
$clickValues = trim($POST['value']);
$element = trim($POST['element']);
$users = explode(',', $POST['userList']);

if ($element == 'bulkEditUser') {
    if ($postValues != "") {
        $postValuesArray = explode(",", $postValues);
        $clickValuesArray = explode(",", $clickValues);
        if (is_array($postValuesArray)) {
            foreach ($postValuesArray as $key => $value) {
                $location = split('-', $value);
		if(is_array($location)){
                    $modifieldField = $location[1] . '-' . $location[2] . '-' . $location[3];
                    $val = $clickValuesArray[$key];
                    
                    if($POST['action'] == 'provide') {
                        providePermissionBulkUsers($SESSION['tool_id'],$users,$location[1],$location[2],$location[3],$val,$SESSION);
                    }
                    elseif($POST['action'] == 'remove') {
                        removePermissionBulkUsers($SESSION['tool_id'],$users,$location[1],$location[2],$location[3],$val,$SESSION);
                    }
                    
                }
	    }
        }
    }
}
echo 'OK|||',$location[1],'-',$location[2],'-',$location[3];
if($SESSION['edit_user']['user_invited']==1 && $userWasInvited==0) echo '&&&reloadSideElementNeeded';
storeSession($SESSION);
?>