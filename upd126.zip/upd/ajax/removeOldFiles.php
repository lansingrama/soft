<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');

$fileFolder=array('cache/csv','cache/html','session');
$root=dirname(__FILE__).'/../';

foreach($fileFolder as $folder){
	$file=glob($root.$folder."/*");
	if(is_array($file)){
		foreach($file as $f){
			if(is_file($f) && (time()-filemtime($f)>=1*24*60*60)){
				unlink($f);
			}
		}
	}
}

storeSession($SESSION);
?>OK|||OK