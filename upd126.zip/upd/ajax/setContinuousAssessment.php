<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');
foreach($_GET as $k=>&$v) $GET[$k]=addslashes($v);

$reviewIdArray=explode("_", $GET['applicability']);
$criteria=array();
$msn=getFilter('msn','filter',0,$SESSION);

SqlLQ('UPDATE dr_review SET continuous_assessment="'.$GET['value'].'" WHERE review_id='.$reviewIdArray[1]);


if($GET['value']==1)
{
	$allCriteria=SqlLi('SELECT DISTINCT criterion FROM dr_review_configuration WHERE review='.$reviewIdArray[1]);
	$allCas=SqlSLi('SELECT DISTINCT ca FROM dr_review_applicability WHERE review='.$reviewIdArray[1],'ca');

	foreach ($allCriteria as $oneCriteria)
	{
		$existingCa=array();

		$criteriaMlt=SqlAsLi('SELECT *
								FROM dr_criteria_status AS s
									INNER JOIN dr_review_criterion AS c ON s.review_criteria=c.review_criterion_id
								WHERE s.msn="'.$msn.'"
									AND s.ca IN('.implode(',',$allCas).')
									AND c.review_criterion_id="'.$oneCriteria['criterion'].'"','ca');

		if(!empty($criteriaMlt))
		{
			foreach($criteriaMlt as $criteriaCa=>$criteriaDetails)
			{
				$existingCa[]=$criteriaCa;
			}
		}

		foreach($allCas as $c)
		{
			if(!in_array($c,$existingCa))
			{
				SqlLQ('INSERT INTO dr_criteria_status (msn,ca,review_criteria) VALUES ("'.$msn.'","'.$c.'","'.$oneCriteria['criterion'].'")');
				$lastCaStatusId=SqlQ('SELECT LAST_INSERT_ID()');
				$criteria=SqlQ('SELECT * FROM dr_criteria_status WHERE criteria_status_id='.$lastCaStatusId['LAST_INSERT_ID()']);
				SqlLQ('UPDATE dr_criteria_status SET criteria_status=1 WHERE msn="'.$msn.'" AND ca="'.$c.'" AND review_criteria="'.$oneCriteria['criterion'].'"');
			}
			else
			{
				$criteria['criteria_status_id']=$criteriaMlt[$c]['criteria_status_id'];
			}
		}
	}
}

echo 'OK|||';
storeSession($SESSION);
?>