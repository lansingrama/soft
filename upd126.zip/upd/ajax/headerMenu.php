<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$id=addslashes($_GET['id']);

if($id=='valid')
{
	$allCriteriaInValidationLoop=SqlLi('SELECT * 
										 FROM dr_validation_loop
										 WHERE validator='.$SESSION['user']['user_id'].'
										 AND action_taken_on ="0000-00-00 00:00:00"
										 AND object='.$SESSION['object']['criterion_validity_id']);
										 
	$allReviewsInValidationLoop=SqlLi('SELECT * 
										FROM dr_validation_loop
										WHERE validator='.$SESSION['user']['user_id'].'
										AND action_taken_on ="0000-00-00 00:00:00"
										AND object='.$SESSION['object']['review_id']);

	$allEvidencesInValidationLoop=SqlLi('SELECT DISTINCT vl1.* 
										FROM dr_validation_loop AS vl1
										LEFT JOIN dr_criteria_status_provider AS csp 
											ON vl1.applicability=csp.criteria_status
											AND vl1.object="'.$SESSION['object']['criteria_status_id'].'"
										WHERE 
										(
											vl1.validator='.$SESSION['user']['user_id'].' 
											OR 
											(
												vl1.validator=0
												AND csp.provider='.$SESSION['user']['user_id'].'
											)
										)
										AND vl1.action_taken_on ="0000-00-00 00:00:00"
										AND vl1.object='.$SESSION['object']['criteria_status_id']); //JFM 09_04_14

	$allActionsInValidationLoop=SqlLi('SELECT * 
										FROM dr_validation_loop
										WHERE validator='.$SESSION['user']['user_id'].'
										AND action_taken_on ="0000-00-00 00:00:00"
										AND object='.$SESSION['object']['action_id']); //JFM 30_10_14

	$allThingsCurrentlyOngoing=SqlLi('SELECT DISTINCT vl1.object, vl1.applicability FROM dr_validation_loop AS vl1
												INNER JOIN dr_validation_loop AS vl2 
													ON vl1.object=vl2.object
													AND vl1.applicability=vl2.applicability
													AND vl2.action_taken=0
												LEFT JOIN dr_criteria_status_provider AS csp 
													ON vl1.applicability=csp.criteria_status
													AND vl1.object="'.$SESSION['object']['criteria_status_id'].'"
												WHERE 
												(
													vl1.validator='.$SESSION['user']['user_id'].' 
													OR 
													(
														vl1.validator=0
														AND csp.provider='.$SESSION['user']['user_id'].'
													)
												)
												AND vl1.validation_loop_step=0
												AND vl1.action_taken!=0'); //JFM 07_04_14 - JFM 09_04_14
}

echo 'OK|||',$id,'###';

/*?><table cellpadding="5"cellspacing="0"><?php*/
?><div class="headerMenuContent"style="font-weight:bold;"><?php

switch($id){
	case'userMan':
		?><div class="headerMenuTitle">Personal Configuration</div><?php
		/*?><div class="headerSpace"></div><?php*/
		?><div onClick="openForm('columnConfig','',false,'GET');hideMenu();">Configure Columns</div><?php
		?><div onClick="openForm('rowConfig','',false,'GET',403,400);hideMenu();">Configure Rows</div><?php
		/*JFM 16_01_15 ?><div onClick="openForm('userManagement','',false,'GET');openSideElement('<?=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id']?>','usr');hideMenu();">Edit My Account</div><?php*/
		?><div onClick="openForm('userPermissions', 'element=<?=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id']?>');hideMenu();">Edit My Account</div><?php
		/*?><div class="headerSpace"></div><?php*/
	break;
	case 'tools':
		?><div class="headerMenuTitle">Tools</div><?php
		?><div onClick="openReviewForm();hideMenu();">View / Edit Reviews</div><?php
		?><div onClick="openForm('list','list_name=action',false,'GET');hideMenu();">Action List</div><?php
		?><div onClick="openForm('list','list_name=rid',false,'POST');hideMenu();">RID List</div><?php
		/*JFM 13_02_14 ?><div onClick="openForm('graphs','',false,'POST');hideMenu();">Graphical Info</div><?php*/
		?><div onClick="openForm('correctUser','',false,'GET');hideMenu();">Correct Users</div><?php
		$uploadCapability=0;
		if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){
			$uploadCapability=1;
			$downloadCapability=1;
		}else{
			$uploadCapability=checkAllApplicabilities('review_profile_id','upload',$SESSION);
			$downloadCapability=checkAllApplicabilities('review_profile_id','export',$SESSION);
		}
		$check = checkExternal($SESSION);
		if($downloadCapability==1  && $check != 1)
		{
			?><div onClick="openForm('structureWizard','wizard=report',false,'GET',0,600); hideMenu();">Report Wizard</div><?php
	/*
 * US#91 - Improvement:Extra all design reviews
 * Get the Program, Coe and MSN based on the area selection
 * Version: 4.4
 * Created by: Infosys Limited
 */
			?><div onClick="openForm('kpiExports','wizard=kpi',false,'GET'); hideMenu();">KPI Export</div>
			
			<?php 
 //End of US#91
			?><div onClick="csv('review_planning','',$('mainTableCacheId').value,'review_planning_<?=date('Y-m-d', time())?>','','');hideMenu();">Export view in CSV</div><?php
			?><div onClick="checkA0Validity(selectedCaList(),'');hideMenu();">Generate A0 Report</div><?php 
		}
		//JFM 08_06_16
		if($uploadCapability==1 && $check != 1){?><div onClick="openForm('uploadA0ReportForm','type=a0Report&title=<?=htmlentities('A0 Report')?>&ca=<?=$GET['ca']?>',false,'GET');hideMenu(); mainRestartNeeded=1;">Upload A0 Report</div><?php }
	break;
	case 'admin':
		?><div class="headerMenuTitle">Administration</div><?php
		$check = checkExternal($SESSION);
		/* JFM 16_01_15 ?><div onClick="openForm('userManagement','',false,'GET');hideMenu();">User Management</div><?php*/
		if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 || checkPermission('c_user_general','edit',0,'check',$SESSION)==1){
			?><div onClick="openForm('list','list_name=usr',false,'GET');hideMenu();">User Management</div><?php
		}
		/*
		* Added By Infosys Limited for Role Management US (#58.1)
		*/
		if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){
			?><div onClick="openForm('roleManagement','role',false,'GET');hideMenu();">Role Management</div><?php
		}
		if((checkPermission('dr_log_general','view',0,'check',$SESSION)==1)&& $check != 1){?><div onClick="openForm('log','',false,'GET');hideMenu();">User Log</div><?php }
		/* JFM 13_05_16 ?><div onClick="openForm('structureWizard','wizard=structure',false,'GET',0,600);hideMenu();">Structure Wizard</div><?php*/
		?><div onClick="openForm('structure','',false,'GET');hideMenu();">Structure Management</div><?php
		if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 || checkPermission('c_area_management','edit',0,'check',$SESSION)==1)
		{
			?><div onClick="openForm('areaManagement','',false,'GET');hideMenu();">Area Management</div><?php //JFM 13_05_16
		} 
		//if(checkPermission('dr_review_profile_general','view',0,'check',$SESSION)==1)
		if((checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 || checkPermission('force_validation','create',0,'check',$SESSION)==1)&& $check != 1)//JFM 13_05_16
		{
			?><div onClick="openForm('reviewManagement','',false,'GET');hideMenu();">Master List Management</div><?php 
		} //JFM 30_09_13
		/*JFM 09_09_13 if(checkPermission('dr_review_profile_general','view',0,'check',$SESSION)==1){?><div onClick="openForm('list','list_name=cat',false,'POST');hideMenu();">Criteria Catalogue Management</div><?php }*/ //JFM 21_08_13 JFM TODO - Change Permission Check.
		?><div onClick="openForm('list','list_name=change',false,'POST');hideMenu();">Bugs / Improvements</div><?php
		/*?><div onClick="openForm('changeLog','',false,'GET');hideMenu();">Change Log</div><?php*/
		if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)
		{
			?><div onClick="openForm('emailAllUsers','',false,'GET',810,232);hideMenu();">Email all Users</div><?php
		}
		/*?><div onClick="restartMainTable('m=reset&o=reset_all');fltOn=false;hideMenu();">Reset Table Filters</div><?php*/
	break;
	case'valid':		
		?><div class="headerMenuTitle">Validation</div><?php
		?><div onClick="openForm('validation','object=<?=$allCriteriaInValidationLoop[0]['object']?>',false,'GET');hideMenu();"><?=count($allCriteriaInValidationLoop)?> - Criteria</div><?php
		?><div onClick="openForm('validation','object=<?=$allReviewsInValidationLoop[0]['object']?>',false,'GET');hideMenu();"><?=count($allReviewsInValidationLoop)?> - Review Checklists</div><?php
		?><div onClick="openForm('validation','object=<?=$allEvidencesInValidationLoop[0]['object']?>',false,'GET');hideMenu();"><?=count($allEvidencesInValidationLoop)?> - Evidences</div><?php //JFM 09_04_14
		?><div onClick="openForm('validation','object=<?=$allActionsInValidationLoop[0]['object']?>',false,'GET');hideMenu();"><?=count($allActionsInValidationLoop)?> - Actions</div><?php //JFM 30_10_14	
		?><div onClick="openForm('validation','object=All',false,'GET');hideMenu();"><?=count($allThingsCurrentlyOngoing)?> - My ongoing workflow<?=(count($allThingsCurrentlyOngoing)==1)?'':'s'?></div><?php //JFM 07_04_14
	break;
}
/*?></table><?php*/

?></div><?php


storeSession($SESSION);
?>