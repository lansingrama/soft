<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('loadUserList.php');
?>$$$<table cellspacing="0"cellpadding="0"class="suggestTable"><?php
for($i=0;$i<20;$i++){?><tr><td id="se<?=$i?>"onClick="clickSuggList(this,<?=$i?>);"onMouseOver="suggMOv(this,<?=$i?>);"onMouseOut="focusOff(this);"style="cursor:pointer"></td></tr><?php }
?><tr><td align="right"width="208"><span onClick="hideSuggest()"style="cursor:pointer;text-decoration:underline;">Close</span></td></tr>
</table><?php
storeSession($SESSION);
?>