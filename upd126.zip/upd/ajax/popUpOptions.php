<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');

$pathLevel=2;
require_once('../support/localSupport.php');
require_once('../support/form.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
function checkUser($action,$position,$windowId,$SESSION){
	$ucPosition=ucwords($position);

	if($action['action_'.$position.'_email']!=''){?><div onClick="getActionEmailInfo('<?=$action['action_id']?>','<?=$position?>');closeMenu('<?=$windowId?>');">Email <?=$ucPosition?></div><?php }
	
	if($action['action_'.$position]==0 && $action['action_'.$position.'_name']!=''){
		if(checkPermission('c_user_general','create',0,'check',$SESSION)){ if(($action['action_holder_name']!=$action['action_validator_name'])||$position=='holder')?><div onClick="closeMenu('<?=$windowId?>');">Create the User <?=$action['action_'.$position.'_name']?></div><?php } //JFM 04_03_14
		?><div><?php
		?>Correct <?=$ucPosition?> to&nbsp;&nbsp;<?php
		drawddList('ddCorrect'.$ucPosition,similarName($action['action_'.$position.'_name'],$SESSION),'',175);
		?>&nbsp;&nbsp;<input class="stdBtn"onClick="/*closeLastForm();*/correctUserTxt('<?=$action['action_id']?>','<?=$position?>','ddCorrect<?=$ucPosition?>');closeMenu('<?=$windowId?>');"type="button"value="Confirm"><?php
		?></div><?php
	}
}

function popUpHeader($title,$windowId){
	/* JFM 09_04_14
	?><div class="headerMenuTitle"><?php x($windowId);echo $title?> Options</div><?php */
	?><div class="headerMenuTitle"><?=$title?> Options</div><?php
}

/* JFM 09_04_14
function x($windowId){
	?><div style="text-align:right;"><img alt="Close this Window"onClick="closeMenu('<?=$windowId?>');"src="../common/img/x.png"style="cursor:pointer;"></div><?php
}*/

$windowIdArr=array(
	'act'=>'popUpActDiv_'.$GET['action'],
	'cap'=>'popUpCaPic',
	'coe'=>'popUpCoeDiv_'.$GET['coe'],
	'com'=>'popUpDiv_'.$GET['title'],
	'crt'=>'popUpCrtDiv_'.$GET['criteria'].'_'.$GET['ca'],
	'crm'=>'popUpCrmDiv_'.$GET['group'].'_'.$GET['criteria'],
	'cwp'=>'popUpCwpDiv_'.$GET['cawp'],
	'msn'=>'popUpMsnDiv_'.$GET['msn'],
	'prg'=>'popUpProgDiv_'.$GET['program'],
	'prm'=>'popUpPrmDiv_'.$GET['perimeter'],
	'rsp'=>'popUpRspDiv_'.$GET['group_position'].'_'.$GET['role_position'],
	'std'=>$GET['window_id'],
	'tbl'=>'popUpDiv_'.$GET['ca'].'_'.$GET['review'],
	'ttl'=>'popUpTtlDiv_'.$GET['title'],
	'usr'=>'popUpRiskDiv_'.$GET['riskId'],	 //JFM 08_06_16
	'usr'=>'popUpUsrDiv_'.$GET['userId'], 	 //JFM 12_01_16
	'cat'=>'popUpCatDiv_'.$GET['menuType'],  //JFM 21_08_13
	'are'=>'popUpAreaDiv_'.$GET['menuType'], //JFM 03_06_14
	'rid'=>'popUpActDiv_'.$GET['rid'],		 //JFM 19_07_16
	'role'=>'popUpRoleDiv_'.$GET['responsible_role_id'], /// Infosys limited added by Role Management - US (#58.1)
	
/*
* US#134 - New section inside the Design Review information, to manage robustness assessment.
* Version: V 4.7
* To get the question id
* Fixed by: Infosys Limited
*/ 

	'robust'=>'popUpRobustDiv_'.$GET['question_id'] //
);

$windowId=$windowIdArr[$GET['location']];

?>OK|||<?php

?><div class="headerMenuContent"><?php

switch($GET['location']){
	case 'act':
		$action=SqlQ('SELECT a.action_id,a.action_code,a.action_holder,a.action_holder_name,a.action_validator,a.action_validator_name,
							u1.email AS action_holder_email,
							u2.email AS action_validator_email
						FROM dr_action AS a
							LEFT JOIN c_user AS u1 ON a.action_holder=u1.user_id
							LEFT JOIN c_user AS u2 ON a.action_validator=u2.user_id
						WHERE action_id="'.$GET['action'].'"');
		
		$action=utf8enc($action);
		
		popUpHeader('Action',$windowId);
		
		?><div onClick="openForm('action','action=<?=$GET['action']?>&criteria_ca=<?=$GET['criteria_ca']?>',true,'GET');closeMenu('<?=$windowId?>');">View / Edit Action</div><?php
		?><div onClick="openForm('workflow','applicability=<?=$GET['action']?>&object=<?=$SESSION['object']['action_id']?>',false,'GET'); closeMenu('<?=$windowId?>');">View Action Workflow</div><?php //JFM 30_10_14

		checkUser($action,'holder',$windowId,$SESSION);
		checkUser($action,'validator',$windowId,$SESSION);
		
		if(checkPermission('review_profile_id','delete',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','delete',0,'check',$SESSION)==1){
			?><div onClick="removeElement('action','<?=$GET['action']?>','<?=$action['action_code']?>');closeMenu('<?=$windowId?>');">Delete Action</div><?php
		}
	break;

	//JFM 19_07_16
	case 'rid':
		$actions=SqlLi('SELECT action_id, action_code
						FROM dr_action 
						WHERE rid='.$GET['rid']);
				
		popUpHeader('RID',$windowId);

		if($actions)
		{
			foreach ($actions as $action) 
			{
				?><div onClick="openForm('action','action=<?=$action['action_id']?>&criteria_ca=<?=$GET['criteria_ca']?>',true,'GET');closeMenu('<?=$windowId?>');">View / Edit Action <?=$action['action_code']?></div><?php
			}
		}
		
	break;

	case 'risk': //JFM 08_06_16
		popUpHeader('Risk',$windowId);
		?><div onClick="openForm('risk','riskId=<?=$GET['riskId']?>',false,'GET');closeMenu('<?=$windowId?>');">View / Edit Risk</div><?php
	break;

	case 'cap':
		popUpHeader('Picture',$windowId);
		?><div onClick="openForm('uploadFile','type=caPicture&title=<?=strtoupper($GET['target'])?> Picture&target=<?=$GET['target']?>&target_id=<?=$GET['target_id']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Upload New Picture</div><?php
		?><div onClick="removeCaWpPicture('<?=$GET['target']?>','<?=$GET['target_id']?>');closeMenu('<?=$windowId?>');">Remove Picture</div><?php
	break;
	case 'coe':
		popUpHeader('CoE',$windowId);
		if($GET['coe']=='new'){
			?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=coe&applicability=new&area=<?=$GET['area']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">New Level 2</div><?php //JFM 08_06_16
		}else{
			if(checkPermission('c_coe_general','edit',0,'check',$SESSION)==1){?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=coe&applicability=<?=$GET['coe']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit</div><?php }
			if(checkPermission('c_coe_general','delete',0,'check',$SESSION)==1){?><div onClick="removeStructureElement('coe',<?=$GET['coe']?>);closeMenu('<?=$windowId?>');">Remove</div><?php }
		}
	break;
	case 'com':
		switch($GET['title']){
			case 'revConfigProfile':
				popUpHeader('Rev. Config.',$windowId);
				?><div onClick="openForm('editStructure','objectTxt=review_configuration_profile&applicability=new&review_profile=<?=$GET['var2']?>',false,'GET');closeMenu('<?=$windowId?>');">New Profile</div><?php
				if($GET['var3']!='' && $GET['var3']!=0){
					?><div onClick="openForm('editStructure','objectTxt=review_configuration_profile&applicability=<?=$GET['var3']?>&review_profile=<?=$GET['var2']?>',false,'GET');closeMenu('<?=$windowId?>');">Edit Profile</div><?php
					?><div onClick="deleteReviewConfigurationProfile('<?=$GET['var3']?>','<?=$GET['var4']?>');closeMenu('<?=$windowId?>');">Delete Profile</div><?php
				}
			break;
		}
	break;
	case 'crt':
		popUpHeader('Criteria',$windowId);
		// JFM 02_09_13 - JFM 20_10_13 PUT BACK IN	
		/*if($GET['valid']==1) //JFM 28_10_13
		{
			if(checkPermission('review_profile_id','edit',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','edit',0,'check',$SESSION)==1){
				?><div onClick="openForm('criteriaStatus','msn=<?=getFilter('msn','filter',0,$SESSION)?>&ca=<?=$GET['ca']?>&review_criteria_id=<?=$GET['criteria']?>',true,'GET','max',0);closeMenu('<?=$windowId?>');">Edit Criteria Status</div><?php
			}
			if(checkPermission('review_profile_id','create',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','create',0,'check',$SESSION)==1){
				?><div onClick="openForm('action','action=new&ca=<?=$GET['ca']?>&review_criteria_id=<?=$GET['criteria']?>',true,'GET');closeMenu('<?=$windowId?>');">New Action</div><?php
			}
		}*/
		//else //JFM 28_10_13
		//{
                        /**
                         * Start of bug 7 
                         * Remove Moveup from UI for displaying the criteria id in lexicon sorted order
                         */
			/*if($GET['positionAbove']!=0)
			{
				?><div onClick="ajaxRequest('ajax/deleteCriteria.php?review_id=<?=$GET['review_id']?>&criteria=<?=$GET['criteria']?>&previousCriteria=<?=$GET['previousCriteria']?>&positionAbove=<?=$GET['positionAbove']?>&delete=3','reloadSideElement',true,'GET');">Move Up</div><?php
			}*/
                        //End of bug 7
			?><div onClick="ajaxRequest('ajax/deleteCriteria.php?review_id=<?=$GET['review_id']?>&criteria=<?=$GET['criteria']?>&delete=0','reloadSideElement',true,'GET');">Toggle Criteria N/A</div><?php
			?><div onClick="ajaxRequest('ajax/deleteCriteria.php?review_id=<?=$GET['review_id']?>&criteria=<?=$GET['criteria']?>&review_group=<?=$GET['review_group']?>&delete=1','removeRowById',true,'GET');">Remove Criteria</div><?php
		//}
	break;
	case 'crm':
		$target=($GET['criteria']==0)?'Group':'Criteria';
		$targetLow=strtolower($target);
		popUpHeader($target,$windowId);
		/* JFM 27_08_13 JFM TODO - add new menu items here
		?><div onClick="focusTarget='description';checkActionsInCriteria('<?=$GET['group']?>','<?=$GET['criteria']?>','edit');closeMenu('<?=$windowId?>');" >Edit <?=$target?></div><?php
		?><div onClick="containerDiv='reviewCriteriaManagementList';ajaxRequest('ajax/newCriteria.php?target=<?=$targetLow?>&position=up&review_group_id=<?=$GET['group']?>&review_criteria_id=<?=$GET['criteria']?>','putInDiv',false,'GET');closeMenu('<?=$windowId?>');">Insert a <?=$target?> above this one</div><?php
		?><div onClick="containerDiv='reviewCriteriaManagementList';ajaxRequest('ajax/newCriteria.php?target=<?=$targetLow?>&position=down&review_group_id=<?=$GET['group']?>&review_criteria_id=<?=$GET['criteria']?>','putInDiv',false,'GET');closeMenu('<?=$windowId?>');">Insert a <?=$target?> under this one</div><?php
		if($target=='Group'){
			?><div onClick="containerDiv='reviewCriteriaManagementList';ajaxRequest('ajax/newCriteria.php?target=criteria&position=up&review_group_id=<?=$GET['group']?>&review_criteria_id=0','putInDiv',false,'GET');closeMenu('<?=$windowId?>');">Add a Criteria at the beginning of the Group</div><?php
			?><div onClick="containerDiv='reviewCriteriaManagementList';ajaxRequest('ajax/newCriteria.php?target=criteria&position=down&review_group_id=<?=$GET['group']?>&review_criteria_id=0','putInDiv',false,'GET');closeMenu('<?=$windowId?>');">Add a Criteria at the end of the Group</div><?php
		}
		if(checkPermission('dr_review_profile_general','delete',0,'check',$SESSION)==1){
			?><div onClick="checkActionsInCriteria('<?=$GET['group']?>','<?=$GET['criteria']?>','delete');closeMenu('<?=$windowId?>');">Remove <?=$target?></div><?php
		}*/
	break;
	case 'cwp':
		popUpHeader('CA - WP',$windowId);
		if($GET['cawp']=='new'){
			?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=cawp&mode=addWp&applicability=new&program=<?=$GET['program']?>&coe=<?=$GET['coe']?>&perimeter=<?=$GET['perimeter']?>&msn=<?=$GET['msn']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">New <?=$SESSION['table']['review_planning']['ca']['wp']['title']?></div><?php
		}else{
			if(checkPermission('c_ca_general','create',0,'check',$SESSION)==1){
				?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=cawp&mode=addCa&applicability=<?=$GET['cawp']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Add <?=$SESSION['table']['review_planning']['ca']['ca']['title']?> to this <?=$SESSION['table']['review_planning']['ca']['wp']['title']?></div><?php
			}
			if(checkPermission('c_ca_general','edit',0,'check',$SESSION)==1){
				$existingWp=SqlAsArr('SELECT w.wp_id,w.wp
										FROM c_wp AS w
											INNER JOIN c_cawp AS c ON w.wp_id=c.wp
										WHERE c.msn IN(
											SELECT msn
											FROM c_cawp
											WHERE cawp_id='.$GET['cawp'].'
										)','wp_id','wp');
				?><div onClick="//closeMenu('<?=$windowId?>');"><?php
					?>Move <?=$SESSION['table']['review_planning']['ca']['ca']['title']?> to <?=$SESSION['table']['review_planning']['ca']['wp']['title']?>: <?php
					drawddList('moveCa',$existingWp,'',100,'moveCa(\''.$GET['cawp'].'\',ddSelectedValue(\'moveCa\'))');
				?></div><?php
				?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=cawp&mode=editCaWpName&applicability=<?=$GET['cawp']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit <?=$SESSION['table']['review_planning']['ca']['wp']['title']?> / <?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Name</div><?php
				if($GET['element_disabled']==1){
					?><div onClick="disableStructure(<?=$GET['cawp']?>,'disableCa',0,0);closeMenu('<?=$windowId?>');">Make <?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Applicable</div><?php
					?><div onClick="disableStructure(<?=$GET['cawp']?>,'disableWp',0,0);closeMenu('<?=$windowId?>');">Make <?=$SESSION['table']['review_planning']['ca']['wp']['title']?> Applicable</div><?php
				}else{
					?><div onClick="disableStructure(<?=$GET['cawp']?>,'disableCa',1,0);closeMenu('<?=$windowId?>');">Make <?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Not Applicable</div><?php
					?><div onClick="disableStructure(<?=$GET['cawp']?>,'disableWp',1,0);closeMenu('<?=$windowId?>');">Make <?=$SESSION['table']['review_planning']['ca']['wp']['title']?> Not Applicable</div><?php
				}
			}
			if(checkPermission('c_ca_general','delete',0,'check',$SESSION)==1){
				?><div onClick="removeCaWp(<?=$GET['cawp']?>,'<?=$SESSION['table']['review_planning']['ca']['ca']['title']?>');closeMenu('<?=$windowId?>');">Remove <?=$SESSION['table']['review_planning']['ca']['ca']['title']?></div><?php
				?><div onClick="removeCaWp(<?=$GET['cawp']?>,'<?=$SESSION['table']['review_planning']['ca']['wp']['title']?>');closeMenu('<?=$windowId?>');">Remove <?=$SESSION['table']['review_planning']['ca']['wp']['title']?></div><?php
			}
		}
	break;
	case 'msn':
            /***
             * Fix for : Bug-6
             * Version :4.1
             * Fixed by : Infosys Limited
             * $tile varaiable is passed as arguments for removeMsn funtion
             * $title @string
             */
                $title = "Msn Data";
                $cawp = SqlAsLi('SELECT c.ca,cw.cawp_id,cw.cawp_disabled AS element_disabled,w.wp_id,w.wp
                    FROM c_ca AS c
                    INNER JOIN c_cawp AS cw ON c.ca_id=cw.ca
                    INNER JOIN c_wp AS w ON cw.wp=w.wp_id
                    WHERE c.program="'.$GET['program'].'"
                    AND cw.msn="'.$GET['msn'].'"
                    ORDER BY w.wp_id,c.ca','cawp_id');
             /*End of added for Bug- 6*/
		popUpHeader('MSN',$windowId);
		if($GET['msn']=='new'){
			?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=msn&program=<?=$GET['program']?>&applicability=new',false,'GET',400,400);closeMenu('<?=$windowId?>');">New Level 3</div><?php //JFM 08_06_16
		}else{
			if(checkPermission('c_msn_general','edit',0,'check',$SESSION)==1){?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=msn&program=<?=$GET['program']?>&applicability=<?=$GET['msn']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit</div><?php }
                        /*Calling removeMsn() onclick of Remove button for Bug - 6
			/*if(checkPermission('c_msn_general','delete',0,'check',$SESSION)==1){?><div onClick="closeMenu('<?=$windowId?>');">Remove</div><?php }*/
                         if (checkPermission('c_msn_general', 'delete', 0, 'check',$SESSION) == 1) {
                       ?><div onClick="removeMsn(<?=$GET['msn']?>,'<?=$title?>','<?=$cawp?>');closeMenu('<?=$windowId?>');">Remove</div><?php
                        }
		}
	break;
	case 'prg':
		popUpHeader('Program',$windowId);
		if($GET['program']=='new'){
			?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=program&applicability=new&area=<?=$GET['area']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">New Level 1</div><?php //JFM 03_06_14 - JFM 08_06_16
		}else{
			if(checkPermission('c_program_general','edit',0,'check',$SESSION)==1){
				?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=program&applicability=<?=$GET['program']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit</div><?php
			}
			/*if(checkPermission('c_program_general','delete',0,'check',$SESSION)==1){?><div onClick="closeMenu('<?=$windowId?>');">Remove</div><?php }*/
		}
	break;
	case 'prm':
		popUpHeader('Perimeter',$windowId);
		if($GET['perimeter']=='new'){
			?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=perimeter&program=<?=$GET['program']?>&applicability=new',false,'GET',400,400);closeMenu('<?=$windowId?>');">New <?=$SESSION['table']['review_planning']['ca']['perimeter']['title']?></div><?php
		}else{
			if(checkPermission('c_perimeter_general','edit',0,'check',$SESSION)==1){?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=perimeter&program=<?=$GET['program']?>&applicability=<?=$GET['perimeter']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit</div><?php }
			if(checkPermission('c_perimeter_general','delete',0,'check',$SESSION)==1){?><div onClick="closeMenu('<?=$windowId?>');">Remove</div><?php }
		}
	break;
	case 'rsp':
		popUpHeader('Responsible',$windowId);
		?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=responsible&program=<?=$GET['program']?>&group_position=<?=$GET['group_position']?>&role_position=<?=$GET['role_position']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit</div><?php
		/*?><div onClick="closeMenu('<?=$windowId?>');">Remove</div><?php*/
	break;
	case 'std':
		switch($GET['case']){
			case 'chg':
				popUpHeader('Bug / Improvement',$windowId);
				$change=SQlQ('SELECT change_status,change_disabled FROM dr_change WHERE change_id="'.$GET['var0'].'"');
				if($change['change_status']==2){
					if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){
						?><div onClick="ajaxRequest('ajax/modifyChange.php?change_id=<?=$GET['var0']?>&mode=status&change_status=0','updateData',true,'GET');closeMenu('<?=$windowId?>');">Reopen (Set as "Not Started")</div><?php
					}
				}else{
					?><div onClick="openForm('changeRemark','change_id=<?=$GET['var0']?>&change_remark_id=new',false,'GET',810,207);closeMenu('<?=$windowId?>');">Add a Remark</div><?php
					?><div onClick="openForm('uploadFile','type=changeScreenshot&title=Screenshot&change_id=<?=$GET['var0']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Add a Screenshot</div><?php
					if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){
						if($change['change_status']!=0){
							?><div onClick="ajaxRequest('ajax/modifyChange.php?change_id=<?=$GET['var0']?>&mode=status&change_status=0','updateData',true,'GET');closeMenu('<?=$windowId?>');">Set as "Not Started"</div><?php
						}
						if($change['change_status']!=1){
							?><div onClick="ajaxRequest('ajax/modifyChange.php?change_id=<?=$GET['var0']?>&mode=status&change_status=1','updateData',true,'GET');closeMenu('<?=$windowId?>');">Set as "In Progress"</div><?php
						}
						if($change['change_status']!=2){
							?><div onClick="ajaxRequest('ajax/modifyChange.php?change_id=<?=$GET['var0']?>&mode=status&change_status=2','updateData',true,'GET');closeMenu('<?=$windowId?>');">Set as "Closed"</div><?php
						}
						?><div onClick="openForm('change','change=<?=$GET['var0']?>&removeTableCache=<?=$GET['var3']?>',false,'GET',810,207);closeMenu('<?=$windowId?>');">Edit Change</div><?php
						if($change['change_disabled']==1){
							?><div onClick="ajaxRequest('ajax/modifyChange.php?change_id=<?=$GET['var0']?>&mode=disable&change_disabled=0','showTable',true,'GET');closeMenu('<?=$windowId?>');">Enable</div><?php
						}else{
							?><div onClick="ajaxRequest('ajax/modifyChange.php?change_id=<?=$GET['var0']?>&mode=disable&change_disabled=1','showTable',true,'GET');closeMenu('<?=$windowId?>');">Disable</div><?php
						}
					}
				}
			break;
			case 'cmp':
				popUpHeader('Company',$windowId);
				if($GET['var0']=='new'){
					if(checkPermission('c_company_general','create',0,'check',$SESSION)==1){
						?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=company&applicability=new',false,'GET',400,400);closeMenu('<?=$windowId?>');">New Company</div><?php
					}
				}else{
					if(checkPermission('c_company_general','edit',0,'check',$SESSION)==1){
						?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=company&applicability=<?=$GET['var0']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit</div><?php
					}
					if(checkPermission('c_company_general','delete',0,'check',$SESSION)==1){
						?><div onClick="closeFormNeeded=1;closeMenu('<?=$windowId?>');">Remove</div><?php
					}
				}
			break;
			case 'dpt':
				popUpHeader('Company',$windowId);
				if($GET['var0']=='new'){
					if(checkPermission('c_department_general','create',0,'check',$SESSION)==1){
						?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=department&applicability=new',false,'GET',400,400);closeMenu('<?=$windowId?>');">New Department</div><?php
					}
				}else{
					if(checkPermission('c_department_general','edit',0,'check',$SESSION)==1){
						?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=department&applicability=<?=$GET['var0']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit</div><?php
					}
					if(checkPermission('c_department_general','delete',0,'check',$SESSION)==1){
						?><div onClick="closeFormNeeded=1;closeMenu('<?=$windowId?>');">Remove</div><?php
					}
				}
			break;
		}
	break;
	case 'tbl':
		if($GET['ca']==0){
			if($GET['review']==0){
				popUpHeader('Table',$windowId);
				?><div onClick="selectAll();closeMenu('<?=$windowId?>');">Select All</div><?php
				?><div onClick="selectNone();closeMenu('<?=$windowId?>');">Select None</div><?php
				if(is_array(perimeterPermission($SESSION,'edit'))){
					/*?><div onClick="openReviewForm('','ca');openSideElement(selectedCaList(),'rev','',0);closeMenu('<?=$windowId?>');">Edit All Selected</div><?php JFM 13_12_13*/
					/*?><div onClick="disableStructure(selectedCaList(),'disableCa',0,1,'&id_type=ca');closeMenu('<?=$windowId?>');">Make All Selected Applicable</div><?php
					?><div onClick="disableStructure(selectedCaList(),'disableCa',1,1,'&id_type=ca');closeMenu('<?=$windowId?>');">Make All Selected Not Applicable</div><?php*/
				}
			}else{
				if(checkPermission('review_profile_id','view',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','view',0,'check',$SESSION)==1){
					popUpHeader('Review',$windowId);
					/* JFM 28_10_15 ?><div onClick="displayReview('<?=$GET['review']?>',0,'<?=$windowId?>');">Expand Review</div><?php*/
					?><div onClick="displayReview('<?=$GET['review']?>',1,'<?=$windowId?>');">Hide Review</div><?php
					/*?><div onClick="openForm('reviewReport','ca='+selectedCaList()+'&review=<?=$GET['review']?>',false,'GET');closeMenu('<?=$windowId?>');">View / Edit All Selected</div><?php*/
					/*?><div onClick="openReviewForm('<?=$GET['review']?>','ca');openSideElement(selectedCaList(),'rev','',2);closeMenu('<?=$windowId?>');">View / Edit All Selected</div><?php JFM 13_12_13*/
					if(checkPermission('dr_review_profile_general','edit',$GET['review'],'check',$SESSION)==1){
						?><div onClick="openForm('reviewManagement','',false,'GET');openSideElement('<?=$GET['review']?>','rvm');closeMenu('<?=$windowId?>');">Edit Review Profile</div><?php
					}
					if(checkPermission('review_profile_id','export',$GET['review'],'check',$SESSION)==1){
						?><div onClick="checkA0Validity(selectedCaList(),<?=$GET['review']?>);closeMenu('<?=$windowId?>');">Generate All Review Reports</div><?php
					}
				}
			}
		}else{
			$wp=SqlLi('SELECT cw.wp,cw.cawp_disabled AS element_disabled,
							c.ca_id,c.ca
						FROM c_cawp AS cw
							INNER JOIN c_ca AS c ON cw.ca=c.ca_id
						WHERE wp IN(
							SELECT wp
							FROM c_cawp
							WHERE msn="'.getFilter('msn','filter',0,$SESSION).'"
								AND ca="'.$GET['ca'].'"
						)
							AND msn="'.getFilter('msn','filter',0,$SESSION).'"');
			
			$disabledCaFound=array();
			if(is_array($wp)){
				foreach($wp as $w){
					if($w['element_disabled']==1){
						$disabledCaFound[]=$w['ca'];
					}else{
						$caTxtA[]=$w['ca_id'];
					}
					$wpId=$w['wp'];
				}
				if(count($disabledCaFound)>0){
					$notAllCaEnabledAlert='alert(\'WARNING: Following CAs into this WP have been disabled:\\n\\n'.implode('\\n',$disabledCaFound).'\\n\\nThey will not be considered when applying actions into the WP.\');';
				}
				if(is_array($caTxtA)){
					$caTxt=implode(',',$caTxtA);
				}else{
					$caTxt='';
				}
				
				if($GET['review']==0){
					popUpHeader('CA',$windowId);
					if($GET['editable_perimeter']==1){
						if($GET['element_disabled']==1){
							?><div onClick="disableStructure(<?=$GET['cawp']?>,'disableCa',0,1);closeMenu('<?=$windowId?>');">Make CA Applicable</div><?php
							?><div onClick="disableStructure(<?=$GET['cawp']?>,'disableWp',0,1);closeMenu('<?=$windowId?>');">Make WP Applicable</div><?php
						}else{
		
							?><div onClick="openForm('../ajax/ca','element=<?=$GET['ca']?>',false,'GET');closeMenu('<?=$windowId?>');">View / Edit CA</div><?php //JFM 11_08_14
							/*?><div onClick="<?=$notAllCaEnabledAlert?>openReviewForm('','wp');openSideElement('<?=$wpId?>','rev','',0);closeMenu('<?=$windowId?>');">View / Edit WP</div><?php*/
							?><div onClick="disableStructure(<?=$GET['cawp']?>,'disableCa',1,1);closeMenu('<?=$windowId?>');">Make CA Not Applicable</div><?php
							/*?><div onClick="disableStructure(<?=$GET['cawp']?>,'disableWp',1,1);closeMenu('<?=$windowId?>');">Make WP Not Applicable</div><?php*/
							
						}
					}else{
						if($GET['element_disabled']!=1){
							?><div onClick="openForm('../ajax/ca','element=<?=$GET['ca']?>',false,'GET');closeMenu('<?=$windowId?>');">View CA</div><?php
							/*?><div onClick="openForm('ca','ca=<?=$GET['ca']?>&target=wp',false,'GET');closeMenu('<?=$windowId?>');">View WP</div><?php*/
						}
					}
				}else{
					if(checkPermission('review_profile_id','view',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','view',0,'check',$SESSION)==1){
						popUpHeader('Review',$windowId);

						?><div style="padding-bottom:10px;" onClick="openReviewForm('<?=$GET['review']?>','ca');openSideElement('<?=$GET['ca']?>','rev');closeMenu('<?=$windowId?>');">View / Edit Review</div><?php
						
						?><div style="padding-bottom:10px;" onClick="ajaxRequest('ajax/setFav.php?ca=<?=$GET['ca']?>&reviewProfile=<?=$GET['review']?>','setFav',false,'GET');closeMenu('<?=$windowId?>');"><?=(getFilter('fav','filter','fav_'.$GET['ca'].'_'.$GET['review'],$SESSION))?'Un-':''?>Bookmark Review</div><?php //JFM 12_01_16
						
						if(checkPermission('c_ca_general','create',0,'check',$SESSION)==1) //JFM 08_06_16
						{
							?><div style="padding-bottom:10px;" onClick="openForm('risk','ca=<?=$GET['ca']?>&riskId=new',false,'GET'); closeMenu('<?=$windowId?>');">Add Risk</div><?php
						}

						?><div onClick="openForm('list','list_name=action&ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('<?=$windowId?>');">All Actions for this Review</div><?php
						?><div onClick="openForm('list','list_name=evd&ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('<?=$windowId?>');">All Evidences for this Review</div><?php //JFM 28_04_14
						?><div style="padding-bottom:10px;" onClick="var selectedCAs=selectedCaList(); openForm('list','list_name=evd&ca='+selectedCAs+'&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('<?=$windowId?>');">All Evidences for Selected CAs</div><?php //JFM 28_04_14
						
						?><div onClick="openForm('graphsSpecificCa','ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('<?=$windowId?>');">Criteria Graphs for this Review</div><?php //JFM 20_05_14
						?><div style="padding-bottom:10px;" onClick="var selectedCAs=selectedCaList(); openForm('graphsSpecificCa','ca='+selectedCAs+'&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('<?=$windowId?>');">Criteria Graphs for Selected CAs</div><?php //JFM 11_08_14
						
						?><div style="padding-bottom:10px;" onClick="openForm('workflow','applicability=<?=$GET['ca']?>&object=<?=$SESSION['object']['review_id']?>&ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',false,'GET'); closeMenu('<?=$windowId?>');">View Review Workflow</div><?php
	$check = checkExternal($SESSION);
                                               // if($externalUsr['type'] != 1){
											   if($check != 1){
						if(getFilter('area','filter',0,$SESSION) == 9)
						{
							?><div style="padding-bottom:10px;" onClick="openForm('dmuQgTemplate','',false,'POST');" closeMenu('<?=$windowId?>');">DMU QG Template Download</div><?php
						}

						?><div onClick="window.open('support/pptxDownload.php?ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>','_self');closeMenu('<?=$windowId?>');">Generate Pre-Review PowerPoint</div><?php //JFM 19_01_15
						?><div onClick="window.open('support/pptxPostReviewDownload.php?ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>','_self');closeMenu('<?=$windowId?>');">Generate Review Statistics PowerPoint</div><?php //JFM 28_10_15
						?><div onClick="window.open('support/pptxPostReviewDownload.php?ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>&perimeter=1','_self');closeMenu('<?=$windowId?>');">Generate Perimeter Statistics PowerPoint</div><?php //JFM 27_11_15

						if(
							checkPermission('review_profile_id','export',$GET['review'],'check',$SESSION)==1 ||
							checkPermission('area_id','export',getFilter('area','filter',0,$SESSION),'check',$SESSION)==1 ||
							checkPermission('program_id','export',getFilter('program','filter',0,$SESSION),'check',$SESSION)==1 ||
							checkPermission('coe_id','export',getFilter('coe','filter',0,$SESSION),'check',$SESSION)==1

							)
						{
							?><div onClick="checkA0Validity(<?=$GET['ca']?>,<?=$GET['review']?>);closeMenu('<?=$windowId?>');">Generate Review Report</div><?php
						}
            }
					}
				
				}
			}else{
				popUpHeader('Error',$windowId);
				?><div onClick="closeMenu('<?=$windowId?>');">Invalid WP</div><?php
			}
		}
	break;
	case 'ttl':
		switch($GET['title']){
			case 'group': //JFM 11_11_13
				popUpHeader('Criteria Group',$windowId);
				?><div onClick="openForm('editStructure','objectTxt=cat&applicability=edit&reviewProfile=<?=$GET['var1']?>&reviewID=<?=$GET['var2']?>&groupID=<?=$GET['var3']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit Criteria Group</div><?php //JFM 26_09_13
			break;
			case 'log':
				popUpHeader('Log',$windowId);
				?><div onClick="csv('<?=$GET['var1']?>','<?=$GET['var2']?>','<?=$GET['var3']?>','log_<?=date('Y-m-d', time())?>','<?=$GET['var4']?>','<?=$GET['var5']?>');closeMenu('<?=$windowId?>');">Export in CSV</div><?php
			break;
			case 'lst':
				popUpHeader('List',$windowId);
				if($GET['var2']=='change')
				{
					?><div onClick="openForm('change','change=new&change_type=1&removeTableCache=<?=$GET['var3']?>',false,'GET',810,207);closeMenu('<?=$windowId?>');">Report a Bug</div><?php
					?><div onClick="openForm('change','change=new&change_type=2&removeTableCache=<?=$GET['var3']?>',false,'GET',810,207);closeMenu('<?=$windowId?>');">Add an Improvement proposal</div><?php
				}
				?><div onClick="csv('<?=$GET['var1']?>','<?=$GET['var2']?>','<?=($GET['var2']=='cat')?$GET['var5']:$GET['var3']?>','<?=$GET['var2']?>_list_<?=date('Y-m-d', time())?>','','<?=$GET['var5']?>');closeMenu('<?=$windowId?>');">Export in CSV</div><?php //JFM 28_04_14
                                // To Upload the CSV report in Master List: Improvement-2(minor)
   
                                    ?><div onClick="openForm('uploadExportMasterCsv','type=uploadcsv&title=<?=htmlentities('Upload CSV')?>',false,'GET');hideMenu(); mainRestartNeeded=1;">Upload CSV</div><?php
                                
				if($GET['var2']=='cat')
				{
					?><div onClick="openForm('editStructure','objectTxt=cat&applicability=new&reviewProfile=<?=$GET['var3']?>&reviewID=<?=$GET['var4']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Create Criteria Group</div><?php //JFM 26_09_13
					?><div onClick="openForm('criteriaCreate','reviewProfile=<?=$GET['var3']?>&reviewID=<?=$GET['var4']?>',false,'GET');closeMenu('<?=$windowId?>'); getAllElementsOfFormAndStoreInString('criteriaForm');">Create New Criteria</div><?php //JFM 21_08_13
				}
				if($GET['var2']=='usr' && checkPermission('c_user_general','create',0,'check',$SESSION)==1) //JFM 16_01_15
				{
					?><div onClick="openForm('../usr/userMainDataForm', '');closeMenu('<?=$windowId?>');">New User</div><?php
                                        ?><div onClick="openForm('editBulkUserPermissions', '');closeMenu('<?=$windowId?>');">Edit Multiple Users</div><?php
				}
			break;
			case 'rrp':
				popUpHeader('Review Report',$windowId);
				?><div onClick="openForm('log','source=dr_review&applicability=<?=$GET['var1']?>',false,'GET');closeMenu('<?=$windowId?>');">View Log</div><?php
			break;
			case 'rvm':
				popUpHeader('Review',$windowId);
				?><div onClick="removeReviewProfile('<?=$GET['var1']?>','<?=$GET['var2']?>');closeMenu('<?=$windowId?>');">Delete Review Profile</div><?php
			break;
			case 'rvw': //JFM 11_11_13
				popUpHeader('Review',$windowId);
				?><div onClick="openForm('editStructure','objectTxt=review&applicability=new&program=<?=getFilter('program','filter',0,$SESSION)?>&coe=<?=getFilter('coe','filter',0,$SESSION)?>&area=<?=$GET['var1']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">New Review</div><?php //JFM 03_06_14
			break;
			case 'usr':
				popUpHeader('User',$windowId);
				$s=(strtolower(substr($GET['var2'], -1))!='s')?'s':'';
				?><div onClick="openForm('log','user=<?=$GET['var1']?>',false,'GET');closeMenu('<?=$windowId?>');">Show <?=$GET['var2']?>'<?=$s?> Log</div><?php
				?><div onClick="viewAs('<?=$GET['var1']?>');closeMenu('<?=$windowId?>');">View Tool as <?=$GET['var2']?></div><?php
			break;
			case 'grams': //JFM 03_12_13
				popUpHeader('References',$windowId);
				?><div onClick="openForm('editStructure','objectTxt=grams&applicability=new',false,'GET',400,400);closeMenu('<?=$windowId?>');">New Reference</div><?php
			break;
		}
	break;
	case 'usr':
		popUpHeader('User',$windowId);
		$s=(strtolower(substr($GET['userName'], -1))!='s')?'s':'';
		?><div onClick="openForm('userPermissions', 'element=<?=$GET['userId']?>',true,'GET');closeMenu('<?=$windowId?>');">Edit User</div><?php //JFM 16_01_15
		?><div onClick="openForm('log','user=<?=$GET['userId']?>',false,'GET');closeMenu('<?=$windowId?>');">Show <?=$GET['userName']?>'<?=$s?> Log</div><?php
		?><div onClick="viewAs('<?=$GET['userId']?>');closeMenu('<?=$windowId?>');">View Tool as <?=$GET['userName']?></div><?php
	break;
	case 'cat':  //JFM 21_08_13	
		//JFM 09_09_13
		if(strstr($GET['menuType'],'Review') !== false)
		{
			$tableCacheId=newTableCacheId($SESSION); //JFM 14_11_13	
			popUpHeader('Review',$windowId);
			$changeWhiteBGCloseFormMethod='';
			if($GET['reviewProfile']=='M')  							$changeWhiteBGCloseFormMethod="changeWhiteBGCloseFormMethod('reviewConfigContainer');";
			else if($GET['reviewID'] && $GET['reviewID']!='undefined') 	$changeWhiteBGCloseFormMethod="changeWhiteBGCloseFormMethod('sideValidationContainer');";
			else if($GET['reviewProfile'])  							$changeWhiteBGCloseFormMethod="changeWhiteBGCloseFormMethod('sideReviewContainer');";

/*			?><div onClick="openForm('criteriaGroups','list_name=cat&review_profile=<?=$GET['criterionId']?>&reviewTypeName=<?=$GET['reviewTypeName']?>&reviewID=<?=$GET['reviewProfile']?>&comingFromValidationWindow=<?=$GET['reviewID']?>&table_cache_id=<?=$tableCacheId?>',false,'POST'); openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$GET['criterionId']?>&reviewTypeName=<?=$GET['reviewTypeName']?>&reviewID=<?=$GET['reviewProfile']?>&table_cache_id=<?=$tableCacheId?>'); closeMenu('<?=$windowId?>'); <?=$changeWhiteBGCloseFormMethod?> ">Manage Criteria</div><?php
*/			
			//JFM 19_07_16
			if(checkPermission('dr_review_profile_general','edit',0,'check',$SESSION)==1)
			{
				//Here the criterionId is the review_profile_id and reviewProfile is the area.
				?><div onClick="openForm('editStructure','objectTxt=review&applicability=<?=$GET['criterionId']?>&area=<?=$GET['reviewProfile']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit Review Type Details</div><?php //JFM 03_06_14
			}
		}
		else
		{
			$allReviewGroups=SqlLi('SELECT rgh.review_group_description, rg.group_id
						FROM dr_review_group_history		AS rgh
							INNER JOIN dr_review_group		AS rg ON rgh.review_group=rg.group_id
							INNER JOIN dr_review_profile	AS rp ON rg.review_type=rp.review_type
						WHERE rp.review_profile_id="'.$GET['reviewProfile'].'"
						AND rgh.review_group_valid_to="0000-00-00 00:00:00"
						ORDER BY rgh.review_group_position'); //JFM 30_10_14

			popUpHeader('Criterion',$windowId);
			if($GET['reviewID']!="undefined" && $GET['reviewID']!="" && $GET['criterionValid']!=0) { ?><div onClick="ajaxRequest('ajax/deleteCriteria.php?review_id=<?=$GET['reviewID']?>&criteria=<?=$GET['criterionId']?>&reviewProfile=<?=$GET['reviewProfile']?>&table_cache_id=<?=$GET['table_cache_id']?>&delete=2','updateBooleanValue',true,'GET'); closeMenu('<?=$windowId?>');">Toggle Include Criteria</div><?php } //JFM 28_10_13
			?><div onClick="openForm('criteriaCreate','criterionId=<?=$GET['criterionId']?>&criterionValidityId=<?=$GET['reviewTypeName']?>&reviewProfile=<?=$GET['reviewProfile']?>&reviewID=<?=$GET['reviewID']?>&subVersion=1',false,'GET'); getAllElementsOfFormAndStoreInString('criteriaForm'); closeMenu('<?=$windowId?>');">Create Criterion Sub-Version</div><?php //JFM 20_11_13
			?><div>Copy Criteria To Group...<?php //JFM 30_10_14
				?><form action="#"enctype="multipart/form-data"id="copyGroupFrm"method="post"><?php
					?><input id="copy"name="copy"type="hidden"value="1"><?php
					?><input id="criteria"name="criteria"type="hidden"value="<?=$GET['criterionId']?>"><?php
					?><select id="groupBox" name="groupBox" style="width:200px;" onchange="if(confirm('Are you sure you wish to copy this criteria to the \''+this.options[this.selectedIndex].text+'\' group?')){sendAjaxForm('copyGroupFrm','ajax/saveCriteria.php','showMessage'); closeMenu('<?=$windowId?>');}"><?php
						?><option value="None" disabled selected>Please select a value...</option><?php
						foreach($allReviewGroups as $oneReviewGroup)
						{
							?><option value="<?=$oneReviewGroup['group_id']?>"><?=$oneReviewGroup['review_group_description']?></option><?php
						}
					?></select><?php
				?></form><?php	
			?></div><?php
			if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){ ?><div onClick="openForm('criteriaCreate','criterionId=<?=$GET['criterionId']?>&criterionValidityId=<?=$GET['reviewTypeName']?>&reviewProfile=<?=$GET['reviewProfile']?>&reviewID=<?=$GET['reviewID']?>',false,'GET'); getAllElementsOfFormAndStoreInString('criteriaForm'); closeMenu('<?=$windowId?>');">Edit Criterion</div><?php } //JFM 11_09_13
			?><div onClick="openForm('workflow','applicability=<?=$GET['reviewTypeName']?>&object=<?=$SESSION['object']['criterion_validity_id']?>&criterionID=<?=$GET['criterionId']?>',false,'GET'); closeMenu('<?=$windowId?>');">View Criterion Workflow</div><?php
		}
	break;
	case 'are': //JFM 03_06_14
		popUpHeader('Area',$windowId);
		if($GET['area']=='new')
		{
			?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=area&applicability=new',false,'GET',400,400);closeMenu('<?=$windowId?>');">New Area</div><?php
		}
		else
		{
			if(checkPermission('c_area_general','edit',0,'check',$SESSION)==1)
			{
				?><div onClick="closeFormNeeded=1;openForm('editStructure','objectTxt=area&applicability=<?=$GET['area']?>',false,'GET',400,400);closeMenu('<?=$windowId?>');">Edit</div><?php
			}
		}
	break;
	/*
	* Added By Infosys Limited for Role Management US (#58.1)
	*/
	case 'role':
				popUpHeader('Role',$windowId);
				if($GET['responsible_role_id'] == 'new'){
						?><div  id="newRoleAdded" onClick="closeLastForm();openForm('addRole','responsible_role_id=<?=$GET['responsible_role_id']?>',false,'GET','','','rolemanagement');closeMenu('<?=$windowId?>');">New Role</div><?php
				}
				else {
				?><div onClick="closeLastForm();openForm('addRole','responsible_role_id=<?=$GET['responsible_role_id']?>',false,'GET','','','rolemanagement');closeMenu('<?=$windowId?>');">Edit</div><?php
				}
				break;

	
				
	/*
	*#134 - New section inside the Design Review information, to manage robustness assessment.
	* Version: V 4.7
	* To redirect to add/edit/remove the questions in the Robustness Assessment page
	* Fixed by: Infosys Limited
	*/ 
	case 'robust':
				popUpHeader('Robust',$windowId);
				if($GET['question_id'] == 'new'){
						?><div  id="newRobustAdded" onClick="closeLastForm();openForm('addRobust','question_id=<?=$GET['question_id']?>&applicability=new',false,'GET','','','robustmanagement');closeMenu('<?=$windowId?>');">Add Question</div><?php
				}
				else {
				?><div onClick="closeLastForm();openForm('addRobust','question_id=<?=$GET['question_id']?>&applicability=edit',false,'GET','','','robustmanagement');closeMenu('<?=$windowId?>');">Edit</div>
				<div onClick="closeLastForm();openForm('addRobust','question_id=<?=$GET['question_id']?>&applicability=remove',false,'GET','','','robustmanagement');closeMenu('<?=$windowId?>');">Remove</div><?php
			
				}
				break;

	/*
	* US#134 - New section inside the Design Review information, to manage robustness assessment.
	* Version: V 4.7
	* To add questions for Robustness Assessment page
	* Fixed by: Infosys Limited
	*/ 


}
?></div><?php
if($GET['location']=='capp'){?></form><?php }
storeSession($SESSION);
?>