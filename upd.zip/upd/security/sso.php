<?php
$pathLevel=1;
require_once('support/localSupport.php');
//PUTBACKIN 
//require_once('../../ldap.php');

//COMMENT OUT:
function get_plumid()
{

        
        //$useless = $_SERVER['HTTP_REMOTE_UID'];
		$useless = 'ng4d11f'; //Deepshika
		//$useless = 'ng88407'; //venkat
		//$useless = 'ng7d6ee'; //Maheswari
	    //$useless ='trdtgrdtgrgtr';
        return $useless;
}

$ssoSuccess=false;

$blockingTime=getBlockingTime();

if($blockingTime==0)
{
/*	$ldap_hostname = 'ldap://DE0-DC01.eu.airbus.corp';
	$ldap_search_dn = 'ou=Persons,dc=eu,dc=airbus,dc=corp';
	$userInfo=get_airbus_user();
	
	if(empty($userInfo)) //Check NA
	{
		$ldap_hostname = 'ldap://na.airbus.corp:389';
		$ldap_search_dn = 'ou=Persons,dc=na,dc=airbus,dc=corp';
		$userInfo=get_airbus_user();
	}
*/
	$userInfo=get_plumid();

	if(!empty($userInfo))
	{
		//$login = $userInfo['userid'];
		$login = $userInfo;
		$SESSION['user'] = SqlQ("SELECT * FROM c_user WHERE login='$login'");

		$toolId=SqlQ('SELECT tool_id FROM c_tool WHERE code="DR"');
		$SESSION['tool_id']=$toolId['tool_id'];

		if(strtoupper($SESSION['user']['login'])==strtoupper($login))
		{
			$allowedMaintenanceUsers=array('NG4725A','NG4D11F','NG643F7');
			$maintenance=false;
			
			if(!in_array($login, $allowedMaintenanceUsers) && $maintenance)	
			{
				$_GET['error'] = "maintenance";
			}
			else
			{
				if($SESSION['user']['confirmed']==0) SqlLQ('UPDATE c_user SET confirmed=1 WHERE user_id='.$SESSION['user']['user_id']);

				$outputDir='output/';
				$dir=opendir($outputDir);
				$today=date("Y-m-d");
				while(($outputFile=readdir($dir))!==false)
				{
					if($outputFile!='.' && $outputFile!='..')
					{
						$filePath=$outputDir.$outputFile;
						$modifiedDate=date("Y-m-d",filemtime($filePath));
						if($modifiedDate<$today)
						{
							unlink($filePath);
						}
					}
				}
				
				require_once('support/sessionLoader.php');

				SqlLQ('INSERT INTO c_login(tool,login,valid_login,ip) VALUES ('.$SESSION['tool_id'].',"'.$POST['User_Name'].'",1,"'.getClientIp().'")');
				
				checkPermission('c_tool_general','view',1,'gate',$SESSION,1);
				
				createLog('dr_log','tool_id','log_in',$SESSION['tool_id'],'','',$SESSION);
				
				SqlLQ('UPDATE dr_action SET action_status=0 WHERE action_status=1 AND action_completion<SUBDATE(NOW(),INTERVAL 1 DAY)');

				$ssoSuccess=true;
			}
		}
		else
		{
			//Not registered
			$GET['error'] = 'not_registered';
		}
	}
	else
	{
		//Cannot get user
	}
}
else
{
	$GET['error'] = '';
}
?>