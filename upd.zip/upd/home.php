<?php
require_once('support/header.php');
$pathLevel=1;
require_once('../support.php');
require_once('../common/php/common.php');
require_once('support/localSupport.php');
require_once('security/checkExpiredSession.php');
require_once('support/sessionLoader.php');

function drawExplorerMenu($SESSION)
{
	$areaList		=SqlLi('SELECT * FROM c_area ORDER BY area ASC');
        // Added hidden flag to hide the levels when they have been removed from Structure Management - US#110
	$programList	=SqlLi('SELECT * FROM c_program WHERE program_hidden=0 ORDER BY program ASC');
	$coeList		=SqlLi('SELECT * FROM c_coe WHERE coe_hidden=0 ORDER BY coe ASC');
	$msnList		=SqlLi('SELECT * FROM c_msn WHERE msn_hidden=0 ORDER BY msn ASC');
	$drawHr=false;

	?><ul id="explorerMenuTopLevel" class="ulTopLevel" onclick="explorerMenuExpand();" ><?php
		foreach ($areaList as $areaId => $areaName) 
		{
			if(checkPermission('area_id','view',$areaName['area_id'],'check',$SESSION,0)!=1 && 
				checkPermission('c_area_general','view',0,'check',$SESSION,0)!=1) continue;
			/*if($drawHr) echo '<hr style="color:#565C6A;" size="1"/><br />';*/
			else $drawHr=true;
                        ?><li id="area_<?=$areaName['area_id']?>" class="<?=(getFilter('area','filter',0,$SESSION)==$areaName['area_id'])?'liSelected':'liNotSelected'?>"><?php
				echo $areaName['area'];
				?><ul class="ulNextLevel"><?php
					foreach ($programList as $programId => $programName) 
					{
						if(checkPermission('program_id','view',$programName['program_id'],'check',$SESSION,0)!=1 && 
							checkPermission('c_program_general','view',0,'check',$SESSION,0)!=1) continue;

						if($areaName['area_id']==$programName['area'])
						{
							?><li id="program_<?=$programName['program_id']?>_area_<?=$areaName['area_id']?>" class="<?=(getFilter('program','filter',0,$SESSION)==$programName['program_id'])?'liSelected':'liNotSelected'?>" style="display:<?=(getFilter('area','filter',0,$SESSION)==$areaName['area_id'] && $programName['program']!='NA')?'':'none'?>;"><?php
								echo $programName['program'];
								?><ul class="ulNextLevel"><?php
									foreach ($coeList as $coeId => $coeName) 
									{
										if(checkPermission('coe_id','view',$coeName['coe_id'],'check',$SESSION,0)!=1 && 
											checkPermission('c_coe_general','view',0,'check',$SESSION,0)!=1) continue;
										if($areaName['area_id']==$coeName['area'])
										{
											?><li id="coe_<?=$coeName['coe_id']?>_program_<?=$programName['program_id']?>_area_<?=$areaName['area_id']?>" class="<?=(getFilter('coe','filter',0,$SESSION)==$coeName['coe_id'])?'liSelected':'liNotSelected'?>" style="display:<?=(getFilter('program','filter',0,$SESSION)==$programName['program_id'] && $coeName['coe']!='NA')?'':'none'?>;"><?php
												echo $coeName['coe'];                                                                                                
                                                                                                
												?><ul class="ulNextLevel"><?php
                                                                                                        //To restrict the copy of Level3 to all Level2's for New Development
                                                                                                        if($programName['program'] == 'New Development') {
                                                                                                            $msnListNewDev = SqlLi('SELECT * FROM c_msn WHERE program='.$programName['program_id'].' AND coe='.$coeName['coe_id'].' ORDER BY msn ASC');
                                                                                                            
                                                                                                            foreach ($msnListNewDev as $msnId => $msnName) 
                                                                                                            {
														if($programName['program_id']==$msnName['program'])
														{
															?><li id="msn_<?=$msnName['msn_id']?>_coe_<?=$coeName['coe_id']?>_program_<?=$programName['program_id']?>_area_<?=$areaName['area_id']?>" class="<?=(getFilter('msn','filter',0,$SESSION)==$msnName['msn_id'])?'liSelected':'liNotSelected'?>" style="display:<?=(getFilter('coe','filter',0,$SESSION)==$coeName['coe_id'] && getFilter('program','filter',0,$SESSION)==$programName['program_id'] && $msnName['msn']!='NA')?'':'none'?>;"><?php
																echo $msnName['msn'];
															?></li><?php
														}
                                                                                                            }
                                                                                                        }
                                                                                                        else {
                                                                                                            foreach ($msnList as $msnId => $msnName) 
                                                                                                            {
														if($programName['program_id']==$msnName['program'])
														{
															?><li id="msn_<?=$msnName['msn_id']?>_coe_<?=$coeName['coe_id']?>_program_<?=$programName['program_id']?>_area_<?=$areaName['area_id']?>" class="<?=(getFilter('msn','filter',0,$SESSION)==$msnName['msn_id'])?'liSelected':'liNotSelected'?>" style="display:<?=(getFilter('coe','filter',0,$SESSION)==$coeName['coe_id'] && getFilter('program','filter',0,$SESSION)==$programName['program_id'] && $msnName['msn']!='NA')?'':'none'?>;"><?php
																echo $msnName['msn'];
															?></li><?php
														}
                                                                                                            }
                                                                                                        }
													
												?></ul><?php
											?></li><?php
										}
									}
								?></ul><?php
							?></li><?php
						}
					}
				?></ul><?php
			?></li><?php
		}
	?></ul><?php
}

$POST=cleanArray($_POST);
$GET=cleanArray($_GET);

checkPermission('c_tool_general','view',1,'gate',$SESSION,0);

//$changeLogCount=SqlQ('SELECT COUNT(*) FROM c_change_log WHERE tool="'.$SESSION['tool_id'].'"');

echo 'OK|||<br><br><br><br>';

//echo '<br><br><br><br>';

//echo session_id();  

//echo md5('test');

//print_r($SESSION);

//echo strlen( serialize( $_SESSION ) );

//require_once('../common/php/lineCounter.php');

//echo md5(microtime(true));

//$lines=countLines('e:/xampp/htdocs/design_reviews_SVN/dr_report/');
//print_r($lines);

$mainFilter=getFilter('overall_search','filter',0,$SESSION);
$view=getFilter('view','filter',0,$SESSION);
$allItemsInValidationLoop=SqlLi('SELECT * FROM dr_validation_loop WHERE validator='.$SESSION['user']['user_id'].' AND action_taken_on ="0000-00-00 00:00:00"');
$count=count($allItemsInValidationLoop);
?><div id="nextResultTemp"style="display:none;"></div><?php
?><div id="formContainer"></div><?php
?><div class="loadingMsg" id="loadingMsg"></div><?php //JFM 13_12_13
?><div class="loadingMsgTextNew" id="loadingMsgText"><div class="loadingMsgProgressBar" id="loadingMsgPercent"></div></div><?php //JFM 12_01_16

?><div id="tutorialHolder" style="position:fixed; left:0px; top:0px; width:100%; height:100%; display:none; z-index:999;"></div><?php

if($SESSION['user']['view_as']!=''){
	$viewAsUser=SqlQ('SELECT CONCAT(name," ",surname) AS user_name FROM c_user WHERE user_id="'.$SESSION['user']['view_as'].'"');
	?><div class="viewAs"><?php
		?><span class="rb">Warning:</span> You are viewing the Tool as <b><?=$viewAsUser['user_name']?></b><?php
		?> <input class="stdBtn"onClick="viewAs('');"type="button"value="Restore"><?php
	?></div><?php
}
?><div class="pageHeader"><?php
	?><div class="pageHeaderContainer"><?php 

		?><div class="titleLeft" id="mainTitle" onClick="restartMainTable();"><?php //JFM 19_07_16
			?><img src="../common/img/logo_white.png"><?php
		?></div><?php

		?><div class="searchContainer"><?php
			?><input class="searchField <?php if(!$mainFilter)echo'inactive'?>" id="searchField"onBlur="txtBlr(this,'Search');"onFocus="txtOF(this,'Search');"onKeyUp="searchChange(this)"size="35"type="text"value="<?=($mainFilter)?$mainFilter:'Search'?>"><?php
			if($mainFilter!=''){?><img alt="Remove the search" id="rmSearchImg" onClick="removeMainFilter();" src="../common/img/rmSearch.png" style="cursor:pointer;  position:absolute; right:23px;"><?php }
			else{?><img id="rmSearchImg" style="position:absolute; right:23px;" src="../common/img/searchBlank.png"><?php }
			?><img alt="Click to search" onClick="mfSearch($('searchField').value);" src="../common/img/search.png" style="cursor:pointer; position:absolute; right:0;"><?php
		?></div><?php

			/*
			* Infosys Limited
			* Bug: Structure Management
			* Menu item to be enabled even if main table is not displayed 
			* version:4.3
			*/
		?><div class="sideInformation"><?php
			?><div><img alt="Exit and close the session"onClick="leave();"src="../common/img/exit.png"></div><?php //JFM 04_09_13
			?><div><img alt="Help, FAQs & About" onClick="openForm('help','',false,'POST');" src="../common/img/help.png"></div><?php //JFM 06_02_14
			?><div style="display:none;"><img alt="Help, FAQs & About" onClick="openForm('help','',false,'POST');" src="../common/img/help.png"></div><?php //JFM 06_02_14
			?><div class="menuHover" id="userMan_c"><div class="pageHeaderMenu"id="userMan_m"onMouseOut="setHideTimer();"onMouseOver="showMenu('userMan','header');"></div><img id="userManImg"onClick="showMenu('userMan','header');"onMouseOut="setHideTimer();"onMouseOver="showMenu('userMan','header'); closeMenu(oldCol);"src="../common/img/userMan.png"></div><?php
			?><div class="menuHover" id="tools_c"><div class="pageHeaderMenu"id="tools_m"onMouseOut="setHideTimer();"onMouseOver="showMenu('tools','header');"></div><img id="toolsImg"onClick="showMenu('tools','header');"onMouseOut="setHideTimer();"onMouseOver="showMenu('tools','header'); closeMenu(oldCol);"src="../common/img/tools.png"></div><?php
			?><div class="menuHover" id="tools_c_hide" style="display:none;opacity:0.5;"><div class="pageHeaderMenu"id="tools_m_hide"></div><img id="toolsImg"src="../common/img/tools.png"></div><?php
			?><div class="menuHover" id="admin_c"><div class="pageHeaderMenu"id="admin_m"onMouseOut="setHideTimer();"onMouseOver="showMenu('admin','header');"></div><img id="adminImg"onClick="showMenu('admin','header');"onMouseOut="setHideTimer();"onMouseOver="showMenu('admin','header'); closeMenu(oldCol);"src="../common/img/admin.png"></div><?php
			?><div class="menuHover" id="admin_c_hide"style="display:none;opacity:0.5;"><div class="pageHeaderMenu"id="admin_m_hide"onMouseOut="setHideTimer();"onMouseOver="showMenu('admin','header');"></div><img id="adminImg" src="../common/img/admin.png"></div><?php
			?><div class="menuHover" id="valid_c"><div class="pageHeaderMenu"id="valid_m"onMouseOut="setHideTimer();"onMouseOver="showMenu('valid','header');"></div><div id="validMenuNumber"><div id="validNumber" style="width: 45px; color: white; font-family: Sans-Serif; font-weight: bold; margin-top: 19px; position: absolute;">?</div><img id="validImg" onClick="showMenu('valid','header');"onMouseOut="setHideTimer();"onMouseOver="showMenu('valid','header'); closeMenu(oldCol);"src="../common/img/validOff.png"></div></div><?php	//JFM 14_10_13 - All done in bodyLoad() method. - JFM 12_01_16
		?></div><?php

	?></div><?php
?></div><?php

?><div class="mainTableLocation" id="mainTableLocation"><?php
	?><div class="locationLeft"><?php

		drawExplorerMenu($SESSION);

	?></div><?php
?></div><?php

?><div class="tabBar" id="tabBar"><?php 
	?><input id="sumTab" class="tabButton" style="left:12px;"  type="button" onclick="restartMainTable('sum'); this.blur();" value="My Tasks"><?php //JFM 02_10_14 - JFM 15_09_15
	?><input id="tblTab" class="tabButton" style="left:112px;" type="button" onclick="restartMainTable('tbl'); this.blur();" value="Main Table"><?php
	     ?><input id="dshTab" <?php $check = checkExternal($SESSION);
		if($check == 1){?>style="display:none;" <?php } ?> class="tabButton" style="left:212px;" type="button" onclick="restartMainTable('dsh'); this.blur();" value="Dashboard"><?php
	?><input id="schTab" <?php 
	if($check == 1){?>style="display:none;" <?php } ?> class="tabButton" style="left:312px;" type="button" onclick="restartMainTable('sch'); this.blur();" value="Schedule"><?php
	//}?><input style="display:none;" id="ovwTab" class="tabButton" style="left:412px;" type="button" onclick="restartMainTable('ovw'); this.blur();" value="Overview"><?php //JFM 02_12_15
	?><input style="display:none;" id="wrlTab" class="tabButton" style="left:510px;" type="button" onclick="restartMainTable('wrl'); this.blur();" value="3D"><?php
	?><input id="refresh" class="refresh" type="button" onclick="restartMainTable(); this.blur();" value="&#8634;"><?php
	?><div class="welcome"><b>Welcome,</b> <?=utf8_encode($SESSION['user']['name'])?></div><?php
?></div><?php

?><div class="mainContainer" id="mainContainer"><?php
	?><div id="review_planning-tableContainer"><div class="noMainTableShown"style="font-size:100px;">Loading Data...<br><br><span style="font-size:36px;">Please wait</span></div></div><?php
?></div><?php

?><div id="ajaxTest"></div><?php
?><input id="debug_mode"type="hidden"value="<?=checkPermission('superadmin','superadmin',0,'check',$SESSION)?>"><?php
?><iframe id="hiFr"name="hiFr" style="margin-top:500px; display:none;">AAHHHHH</iframe><?php
?><div style="text-align:left; color:#565c6a;" id="resultsStatistics"></div><?php
?><iframe id="garbageCollector"name="garbageCollector"width="1"height="1"style="visibility:hidden"></iframe><?php
?><div style="display:none" id="storedView"><?=getFilter('view','filter',0,$SESSION)?></div><?php 