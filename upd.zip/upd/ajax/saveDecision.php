<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');
require_once('../support/mail.php'); //JFM 28_10_15

$POST=cleanArray($_POST); //JFM 25_11_13

$fullUserInfo=Array();
$oldUserInfo=Array();
$finalValidation=false;
$ridCanBeClosed=false;

$checkIfValidationLoopHasntChanged=SqlQ('SELECT 1 FROM dr_validation_loop WHERE validation_loop_id='.$POST['validationLoopID'].' AND action_taken=0 AND action_taken_on="0000-00-00 00:00:00"'); //JFM 30_10_14

if(!empty($checkIfValidationLoopHasntChanged)) //JFM 30_10_14
{
	$validationLoopStructure=SqlLi('SELECT * FROM dr_validation_loop_structure WHERE applicability='.$POST['applicability'].' AND object='.$POST['object'].' ORDER BY validation_loop_structure_step ASC');

	if($POST['decisionRadio']=='validate')
	{
		//Check for comments.
		if($POST['decisionComments']=='' && $POST['extra_comments']=='')
		{
			SqlLQ('UPDATE dr_validation_loop
					SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="validated"),
					action_taken_on=SYSDATE()
					WHERE validation_loop_id='.$POST['validationLoopID']);
		}
		else
		{
			SqlLQ('UPDATE dr_validation_loop
					SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="validated"),
					action_taken_on=SYSDATE(),
					validator_comment="'.$POST['extra_comments'].$POST['decisionComments'].'"
					WHERE validation_loop_id='.$POST['validationLoopID']);
		}
		
		//Get next validator.
		if(!empty($validationLoopStructure[($POST['validationLoopStructureStep']+1)]['validation_loop_structure_step']))
		{
			$q=1;
			
			foreach($validationLoopStructure as $k=>$v)
			{
				if($validationLoopStructure[($POST['validationLoopStructureStep']+$q)]['validator_removed']!=1)
				{
					break;
				}
				else
				{
					$q++;
				}
			}
			
			SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
						VALUES ('.$POST['object'].',"'.$POST['applicability'].'",'.$validationLoopStructure[($POST['validationLoopStructureStep']+$q)]['validator'].','.$validationLoopStructure[($POST['validationLoopStructureStep']+$q)]['validation_loop_structure_step'].',SYSDATE())');
			
			$fullUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[($POST['validationLoopStructureStep']+$q)]['validator']);
			
			if($POST['extra_comments']!='') $oldUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[$POST['validationLoopStructureStep']]['validator']);
		}
		else
		{
			//VALIDATE
			switch($POST['object'])
			{
				case $SESSION['object']['criterion_validity_id']:
				
					$criteriaID=SqlLi('SELECT criterion
						FROM dr_review_criterion_history 
						WHERE criterion_validity_id='.$POST['applicability']);
			
					$criteriaOldqry=SqlLi('SELECT criterion_validity_id, criterion
										FROM dr_review_criterion_history 
										WHERE criterion='.$criteriaID[0]['criterion'].'
										AND criterion_valid_from!="0000-00-00 00:00:00"
										AND criterion_valid_to="0000-00-00 00:00:00"');

					$criteriaNewqry=SqlLi('SELECT criterion_validity_id, criterion
											FROM dr_review_criterion_history 
											WHERE criterion='.$criteriaID[0]['criterion'].'
											AND criterion_valid_from="0000-00-00 00:00:00"
											AND criterion_valid_to="0000-00-00 00:00:00"');
					
					if(!empty($criteriaOldqry))
					{
						SqlLQ('UPDATE dr_review_criterion_history  
								SET criterion_valid_to=SYSDATE() 
								WHERE criterion_validity_id='.$criteriaOldqry[0]['criterion_validity_id']);
					}
							
					SqlLQ('UPDATE dr_review_criterion_history  
							SET criterion_valid_from=SYSDATE() 
							WHERE criterion_validity_id='.$criteriaNewqry[0]['criterion_validity_id']);
							
					SqlLQ('UPDATE dr_review_criterion_applicability 
							SET review_criterion_applicability_valid_to=SYSDATE()
							WHERE criterion='.$criteriaID[0]['criterion'].'
							AND review_criterion_applicability_valid_to="0000-00-00 00:00:01"');
							
					SqlLQ('UPDATE dr_review_criterion_applicability 
							SET review_criterion_applicability_valid_from=SYSDATE()
							WHERE criterion='.$criteriaID[0]['criterion'].'
							AND review_criterion_applicability_valid_from="0000-00-00 00:00:00"');
				break;

				case $SESSION['object']['review_id']:
				
					SqlLQ('UPDATE dr_review  
								SET validation_date=SYSDATE(),
									validation_complete=2
								WHERE review_id='.$POST['applicability']);			
				break;

				case $SESSION['object']['criteria_status_id']: //JFM 09_04_14

					$reviewIDs=SqlSLi('SELECT review_id FROM dr_review AS r
											INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
										WHERE ca ='.$POST['ca'].' AND msn="'.$POST['msn'].'"
										AND review_profile='.$POST['review_profile'],'review_id');
										
					$allCas=SqlSLi('SELECT ca FROM dr_review_applicability WHERE review IN ('.implode(',',$reviewIDs).')','ca');
				
					SqlLQ('UPDATE dr_criteria_status SET criteria_status=3 WHERE msn="'.$POST['msn'].'" AND ca IN ('.implode(',',$allCas).') AND review_criteria="'.$POST['review_criteria_id'].'"');

				break;

				case $SESSION['object']['action_id']: //JFM 31_10_14

					SqlLQ('UPDATE dr_action  
								SET action_closure=SYSDATE(),
									action_status=3
								WHERE action_id='.$POST['applicability']);

					SqlLQ('INSERT INTO dr_log (log_date, user, object, action, applicability, old_value, new_value) VALUES 
											 (SYSDATE(), '.$SESSION['user']['user_id'].','.$SESSION['object']['action_status'].','.$SESSION['user_action']['edit'].','.$POST['applicability'].',2,3)');

					$ridFound=SqlQ('SELECT rid FROM dr_action WHERE action_id='.$POST['applicability']);

					if(!empty($ridFound) && $ridFound['rid']!=0)
					{
						$otherActionsWithThisRid=SqlLi('SELECT action_status 
														FROM dr_action 
														WHERE rid='.$ridFound['rid'].'
														AND action_id!='.$POST['applicability']);

						$setRidBlue=false;

						if(is_array($otherActionsWithThisRid))
						{
							$notBlue=false;

							foreach($otherActionsWithThisRid as $otherActionWithThisRid)
							{
								if($otherActionWithThisRid['action_status']!=3)
								{
									$notBlue=true;
									break;
								}
							}
							if(!$notBlue)
							{
								$setRidBlue=true;
							}
						}
						else $setRidBlue=true;
						
						if($setRidBlue) $ridCanBeClosed=true;
					}

				break;
			}

			$fullUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[0]['validator']);
			if($POST['extra_comments']!='') $oldUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[$POST['validationLoopStructureStep']]['validator']);
			$finalValidation=true;

		}
				
	}

	else if($POST['decisionRadio']=='reject')
	{
		SqlLQ('UPDATE dr_validation_loop
				SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="rejected"),
				action_taken_on=SYSDATE(),
				validator_comment="'.$POST['extra_comments'].$POST['decisionComments'].'"
				WHERE validation_loop_id='.$POST['validationLoopID']);
				
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
						VALUES ('.$POST['object'].',"'.$POST['applicability'].'",'.$validationLoopStructure[0]['validator'].','.$validationLoopStructure[0]['validation_loop_structure_step'].',SYSDATE())');

		$fullUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[0]['validator']);
		if($POST['extra_comments']!='') $oldUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[$POST['validationLoopStructureStep']]['validator']);
	}

	else if($POST['decisionRadio']=='returned') //JFM 07_04_14
	{
		SqlLQ('UPDATE dr_validation_loop
				SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="returned"),
				action_taken_on=SYSDATE(),
				validator_comment="'.$POST['decisionComments'].'"
				WHERE validation_loop_id='.$POST['validationLoopID']);
				
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
						VALUES ('.$POST['object'].',"'.$POST['applicability'].'",'.$validationLoopStructure[0]['validator'].','.$validationLoopStructure[0]['validation_loop_structure_step'].',SYSDATE())');

		$fullUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[0]['validator']);
	}

	else if($POST['decisionRadio']=='forward')
	{
		$nameSplit=explode(", ",$POST['forwardName']);

		if($POST['neverAgainCheck']==1) //JFM 21_10_13
		{
			SqlLQ('UPDATE dr_validation_loop_structure
					SET validator_removed=1
					WHERE applicability='.$POST['applicability'].' AND object='.$POST['object'].' AND validation_loop_structure_step='.$POST['validationLoopStructureStep']);
					
			SqlLQ('UPDATE dr_validation_loop
					SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="forward and never ask"),
					action_taken_on=SYSDATE(),
					validator_comment="'.$POST['extra_comments'].$POST['decisionComments'].'"
					WHERE validation_loop_id='.$POST['validationLoopID']);
		}
		else
		{
			SqlLQ('UPDATE dr_validation_loop
					SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="forward"),
					action_taken_on=SYSDATE(),
					validator_comment="'.$POST['extra_comments'].$POST['decisionComments'].'"
					WHERE validation_loop_id='.$POST['validationLoopID']);
		}
		
		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ('.$POST['object'].',"'.$POST['applicability'].'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.($POST['validationLoopStructureStep']+1).')');
				
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
				VALUES ('.$POST['object'].',"'.$POST['applicability'].'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.($POST['validationLoopStructureStep']+1).',SYSDATE())');
				
		//re-order
		$reOrderMe=SqlLi('SELECT * from dr_validation_loop_structure WHERE applicability='.$POST['applicability'].' AND object='.$POST['object'].' ORDER BY validation_loop_structure_step ASC, validation_loop_structure_id DESC');
		
		$count=count($reOrderMe);

		for ($z=0; $z<$count;$z++)
		{
			if($reOrderMe[$z]['validation_loop_structure_step']!=$z)
			{
				SqlLQ('UPDATE dr_validation_loop_structure
					SET validation_loop_structure_step='.$z.'
					WHERE validation_loop_structure_id='.$reOrderMe[$z]['validation_loop_structure_id']);
			}
		}

		$fullUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE  user_id=(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'")');
		if($POST['extra_comments']!='') $oldUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[$POST['validationLoopStructureStep']]['validator']);
	}

	else if($POST['decisionRadio']=='remove')
	{
		SqlLQ('UPDATE dr_validation_loop
						SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="removed"),
						action_taken_on=SYSDATE(),
						validator_comment="'.$POST['extra_comments'].$POST['decisionComments'].'"
						WHERE validation_loop_id='.$POST['validationLoopID']);
				
		SqlLQ('UPDATE dr_validation_loop_structure
				SET validator_removed=1
				WHERE applicability='.$POST['applicability'].' AND object='.$POST['object'].' AND validation_loop_structure_step='.$POST['validationLoopStructureStep']);
				
				
		//Get next validator.
		if(!empty($validationLoopStructure[($POST['validationLoopStructureStep']+1)]['validation_loop_structure_step']))
		{
			SqlLQ('UPDATE dr_validation_loop
					SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="removed"),
					action_taken_on=SYSDATE(),
					validator_comment="'.$POST['extra_comments'].$POST['decisionComments'].'"
					WHERE validation_loop_id='.$POST['validationLoopID']);
					
			SqlLQ('UPDATE dr_validation_loop_structure
					SET validator_removed=1
					WHERE applicability='.$POST['applicability'].' AND object='.$POST['object'].' AND validation_loop_structure_step='.$POST['validationLoopStructureStep']);
				
			$q=1;
			
			foreach($validationLoopStructure as $k=>$v)
			{
				if($validationLoopStructure[($POST['validationLoopStructureStep']+$q)]['validator_removed']!=1)
				{
					break;
				}
				else
				{
					$q++;
				}
			}
			
			SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
						VALUES ('.$POST['object'].',"'.$POST['applicability'].'",'.$validationLoopStructure[($POST['validationLoopStructureStep']+$q)]['validator'].','.$validationLoopStructure[($POST['validationLoopStructureStep']+$q)]['validation_loop_structure_step'].',SYSDATE())');
		
			$fullUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[($POST['validationLoopStructureStep']+$q)]['validator']);
			if($POST['extra_comments']!='') $oldUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[$POST['validationLoopStructureStep']]['validator']);
		}
		
		//JFM 03_12_13
		else
		{
			//Check that not all of the validators have selected "Remove me from loop"
			$hasSomeoneValidated=SqlLi('SELECT *
										FROM dr_validation_loop
										WHERE applicability='.$POST['applicability'].'
										AND object ='.$POST['object'].'
										AND action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="validated")');
										
			//If all of them have been removed from the loop, reject the criteria back to the originator.
			if(count($hasSomeoneValidated)==0)
			{
				SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
						VALUES ('.$POST['object'].',"'.$POST['applicability'].'",'.$validationLoopStructure[0]['validator'].','.$validationLoopStructure[0]['validation_loop_structure_step'].',SYSDATE())');

				$fullUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[0]['validator']);
			}
			
			//Otherwise validate.
			else
			{	
				//VALIDATE
				switch($POST['object'])
				{
					case $SESSION['object']['criterion_validity_id']:
					
						$criteriaID=SqlLi('SELECT criterion
							FROM dr_review_criterion_history 
							WHERE criterion_validity_id='.$POST['applicability']);
				
						$criteriaOldqry=SqlLi('SELECT criterion_validity_id, criterion
											FROM dr_review_criterion_history 
											WHERE criterion='.$criteriaID[0]['criterion'].'
											AND criterion_valid_from!="0000-00-00 00:00:00"
											AND criterion_valid_to="0000-00-00 00:00:00"');

						$criteriaNewqry=SqlLi('SELECT criterion_validity_id, criterion
												FROM dr_review_criterion_history 
												WHERE criterion='.$criteriaID[0]['criterion'].'
												AND criterion_valid_from="0000-00-00 00:00:00"
												AND criterion_valid_to="0000-00-00 00:00:00"');
						
						if(!empty($criteriaOldqry))
						{
							SqlLQ('UPDATE dr_review_criterion_history  
									SET criterion_valid_to=SYSDATE() 
									WHERE criterion_validity_id='.$criteriaOldqry[0]['criterion_validity_id']);
						}
								
						SqlLQ('UPDATE dr_review_criterion_history  
								SET criterion_valid_from=SYSDATE() 
								WHERE criterion_validity_id='.$criteriaNewqry[0]['criterion_validity_id']);
								
						SqlLQ('UPDATE dr_review_criterion_applicability 
								SET review_criterion_applicability_valid_to=SYSDATE()
								WHERE criterion='.$criteriaID[0]['criterion'].'
								AND review_criterion_applicability_valid_to="0000-00-00 00:00:01"');
								
						SqlLQ('UPDATE dr_review_criterion_applicability 
								SET review_criterion_applicability_valid_from=SYSDATE()
								WHERE criterion='.$criteriaID[0]['criterion'].'
								AND review_criterion_applicability_valid_from="0000-00-00 00:00:00"');
					break;

					case $SESSION['object']['review_id']:
					
						SqlLQ('UPDATE dr_review  
									SET validation_date=SYSDATE(),
										validation_complete=2
									WHERE review_id='.$POST['applicability']);			
					break;

					case $SESSION['object']['criteria_status_id']: //JFM 09_04_14
				
						$reviewIDs=SqlSLi('SELECT review_id FROM dr_review AS r
												INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
											WHERE ca ='.$POST['ca'].' AND msn="'.$POST['msn'].'"
											AND review_profile='.$POST['review_profile'],'review_id');
											
						$allCas=SqlSLi('SELECT ca FROM dr_review_applicability WHERE review IN ('.implode(',',$reviewIDs).')','ca');
					
						SqlLQ('UPDATE dr_criteria_status SET criteria_status=3 WHERE msn="'.$POST['msn'].'" AND ca IN ('.implode(',',$allCas).') AND review_criteria="'.$POST['review_criteria_id'].'"');
					
					break;

					case $SESSION['object']['action_id']: //JFM 31_10_14

						SqlLQ('UPDATE dr_action  
									SET action_closure=SYSDATE(),
										action_status=3
									WHERE action_id='.$POST['applicability']);

						SqlLQ('INSERT INTO dr_log (log_date, user, object, action, applicability, old_value, new_value) VALUES 
											 (SYSDATE(), '.$SESSION['user']['user_id'].','.$SESSION['object']['action_status'].','.$SESSION['user_action']['edit'].','.$POST['applicability'].',2,3)');


						$ridFound=SqlQ('SELECT rid FROM dr_action WHERE action_id='.$POST['applicability']);

						if(!empty($ridFound) && $ridFound['rid']!=0)
						{
							$otherActionsWithThisRid=SqlLi('SELECT action_status 
															FROM dr_action 
															WHERE rid='.$ridFound['rid'].'
															AND action_id!='.$POST['applicability']);

							$setRidBlue=false;

							if(is_array($otherActionsWithThisRid))
							{
								$notBlue=false;

								foreach($otherActionsWithThisRid as $otherActionWithThisRid)
								{
									if($otherActionWithThisRid['action_status']!=3)
									{
										$notBlue=true;
										break;
									}
								}
								if(!$notBlue)
								{
									$setRidBlue=true;
								}
							}
							else $setRidBlue=true;
							
							if($setRidBlue) $ridCanBeClosed=true;
						}
					break;

					$fullUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[0]['validator']);
					if($POST['extra_comments']!='') $oldUserInfo=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$validationLoopStructure[$POST['validationLoopStructureStep']]['validator']);
					$finalValidation=true;
				}
			}
		}
	}

	if(!empty($fullUserInfo)) //JFM 28_10_15 - Everything in this if.
	{
		$object;
		$whatDone;
		$message;
		$doSomething;
		$subject;

		switch($POST['object']) //Send emails.
		{
			case $SESSION['object']['criterion_validity_id']:

				$object='Criterion';

				$criterionID=SqlLi('SELECT rch.criterion, rch.criterion_user_id, rt.review_type
										FROM dr_review_criterion_history AS rch
											INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
											INNER JOIN dr_review_group AS rg ON rg.group_id=rc.review_group
											INNER JOIN dr_review_type AS rt ON rt.review_type_id=rg.review_type
										WHERE criterion_validity_id='.$POST['applicability']);

				if($finalValidation)
				{
					$whatDone='Validated';
					$message='This is an automatic email to inform you that your criterion has been validated.<br><br>
									This criterion is <strong>'.$criterionID[0]['criterion_user_id'].' for '.$criterionID[0]['review_type'].' reviews.</strong>';

					$doSomething='use the criterion in a checklist';
					$subject='Criterion Validation Complete! - Airbus Review Tool';
				}
				else if($POST['decisionRadio']=='reject')
				{
					$whatDone='Rejected';
					$message='This is an automatic email to inform you that your criterion has been rejected.<br><br>
									This criterion is <strong>'.$criterionID[0]['criterion_user_id'].' for '.$criterionID[0]['review_type'].' reviews.</strong>';

					$doSomething='update the criterion';
					$subject='Criterion Rejected - Airbus Review Tool';
				}
				else
				{
					$whatDone='Validation';
					$message='This is an automatic email to inform you a criteria requires your validation.<br><br>
									This criteria is for <strong>'.$criterionID[0]['review_type'].' reviews.</strong>';

					$doSomething='validate the criterion';
					$subject='Criterion Validation Required - Airbus Review Tool';
				}

				if($fullUserInfo['allow_emails']!=1) sendThemMailings($object, $whatDone, $message, $doSomething, $subject, $fullUserInfo['email'], $fullUserInfo['name'], $fullUserInfo['surname']); 
					
			break;

			case $SESSION['object']['review_id']:

				$object='Review Checklist';

				$reviewInfo=SqlLi('SELECT rt.review_type, ca.ca, coe.coe, p.program
									FROM dr_review_type AS rt
										INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id
										INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
										INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
										INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
										INNER JOIN c_program AS p ON p.program_id=rp.program
										INNER JOIN c_coe AS coe ON coe.coe_id=rp.coe
									WHERE review_id ='.$POST['applicability']);

				$caString='';
				$caStringShort='';
				foreach($reviewInfo as $l=>$m) $caString=$caString.$m['ca'].',';
				$caString=rtrim($caString, ",");

				if($finalValidation)
				{
					$whatDone='Validated';
					$message='This is an automatic email to inform you that your review checklist has been validated.<br><br>
								This review checklist is <strong>'.$reviewInfo[0]['program'].' - '.$reviewInfo[0]['coe'].' - '.$reviewInfo[0]['review_type'].' for CA(s) - '.$caString.'</strong> ';

					$doSomething='perform your reivew';
					$subject='Review Checklist Validation Complete! - Airbus Review Tool';
				}
				else if($POST['decisionRadio']=='reject')
				{
					$whatDone='Rejected';
					$message='This is an automatic email to inform you that your review checklist has been rejected.<br><br>
								This review checklist is <strong>'.$reviewInfo[0]['program'].' - '.$reviewInfo[0]['coe'].' - '.$reviewInfo[0]['review_type'].' for CA(s) - '.$caString.'</strong> ';

					$doSomething='update the review checklist';
					$subject='Review Checklist Rejected - Airbus Review Tool';
				}
				else
				{
					$whatDone='Validation';
					$message='This is an automatic email to inform you a review checklist requires your validation.<br><br>
								This review is a <strong>'.$reviewInfo[0]['program'].' - '.$reviewInfo[0]['coe'].' - '.$reviewInfo[0]['review_type'].' for CA(s) - '.$caString.'</strong>';

					$doSomething='validate the review checklist';
					$subject='Review Checklist Validation Required - Airbus Review Tool';
				}

				if($fullUserInfo['allow_emails']!=1) sendThemMailings($object, $whatDone, $message, $doSomething, $subject, $fullUserInfo['email'], $fullUserInfo['name'], $fullUserInfo['surname']);
	
			break;

			case $SESSION['object']['criteria_status_id']:

				$object='Evidence';

				$allEvidenceInfo=SqlQ('SELECT *
								FROM dr_criteria_status AS ca
								WHERE criteria_status_id='.$POST['applicability']);

				$reviewProfile=SqlLi('SELECT DISTINCT rp.review_profile_id, p.program, c.coe, m.msn, ca.ca, rt.review_type, r.review_id, rch.criterion_user_id
										FROM dr_review_profile AS rp
											INNER JOIN dr_review_group AS rg ON rg.review_type=rp.review_type
											INNER JOIN dr_review_criterion AS rc ON rc.review_group=rg.group_id
											INNER JOIN dr_review_criterion_history	AS rch ON rch.criterion=rc.review_criterion_id
											INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
											INNER JOIN dr_criteria_status as cs ON cs.review_criteria=rc.review_criterion_id
											INNER JOIN dr_review_applicability AS ra ON ra.ca=cs.ca
																					AND ra.review=r.review_id
											INNER JOIN c_program AS p ON p.program_id=rp.program
											INNER JOIN c_coe AS c ON c.coe_id=rp.coe
											INNER JOIN c_msn AS m ON m.msn_id=r.msn
																AND cs.msn=r.msn
											INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
											INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
										WHERE cs.criteria_status_id='.$POST['applicability']);

				function item($item) { return $item['review_id']; }
				$reviewIds=array_map('item', $reviewProfile);

				$allCas=SqlSLi('SELECT ca.ca FROM dr_review_applicability AS ra INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca WHERE review IN ('.implode(',',$reviewIds).')','ca');

				$casAsString=implode(', ', $allCas);

				$whatDone='Validation';
				$message='This is an automatic email to inform you a piece of evidence requires your validation.<br><br>
							This evidence is for <strong>'.$reviewProfile[0]['program'].' - '.$reviewProfile[0]['coe'].' - '.$reviewProfile[0]['msn'].' - '.$casAsString.' - Criteria '.$reviewProfile[0]['criterion_user_id'].'</strong>';

				$doSomething='validate the evidence';
				$subject='Evidence Validation Required - Criteria '.$reviewProfile[0]['criterion_user_id'].' - Airbus Review Tool';

				if($fullUserInfo['allow_emails']!=1) sendThemMailings($object, $whatDone, $message, $doSomething, $subject, $fullUserInfo['email'], $fullUserInfo['name'], $fullUserInfo['surname']);
			
			break;

			case $SESSION['object']['action_id']:

				$object='Action';

				$actionValidated=SqlQ('SELECT * FROM dr_action WHERE action_id='.$POST['applicability']);

				if($finalValidation)
				{
					$whatDone='Validated';
					$message='This is an automatic email to inform you that your action has been validated.<br><br>
									This action is <strong>'.$actionValidated['action_code'].'.</strong> ';

					$doSomething='view your completed action';
					$subject='Action Validation Complete! - Airbus Review Tool';
				}
				else if($POST['decisionRadio']=='reject')
				{
					$whatDone='Rejected';
					$message='This is an automatic email to inform you that your action has been rejected.<br><br>
								This action is <strong>'.$actionValidated['action_code'].'.</strong> ';

					$doSomething='update the action';
					$subject='Action Rejected - Airbus Review Tool';
				}
				else
				{
					$whatDone='Validation';
					$message='This is an automatic email to inform you a action requires your validation.<br><br>
									This action is for <strong>'.$actionValidated['action_code'].'.</strong>';

					$doSomething='validate the action';
					$subject='Action Validation Required - Airbus Review Tool';
				}

				if($fullUserInfo['allow_emails']!=1) sendThemMailings($object, $whatDone, $message, $doSomething, $subject, $fullUserInfo['email'], $fullUserInfo['name'], $fullUserInfo['surname']);

				if($ridCanBeClosed)
				{
					$fullUserInfo=SqlQ('SELECT u1.email, u1.name, u1.surname, u1.allow_emails, rid.rid_code FROM c_user AS u1
										INNER JOIN dr_rid AS rid ON rid.rid_validator=u1.user_id
										INNER JOIN dr_action AS act ON act.rid=rid.rid_id
										WHERE act.action_id='.$POST['applicability']);

					$object='RID';
					$whatDone='Can Be Closed';
					$message='This is an automatic email to inform you all actions have been completed for RID:<br><br>
										<strong>'.$fullUserInfo['rid_code'].'</strong> ';
					$doSomething='close the RID';
					$subject='RID Can Be Closed - Airbus Review Tool';

					if($fullUserInfo['allow_emails']!=1) sendThemMailings($object, $whatDone, $message, $doSomething, $subject, $fullUserInfo['email'], $fullUserInfo['name'], $fullUserInfo['surname']);
				}
					
			break;
		}
	}
	else if($POST['object']==$SESSION['object']['criteria_status_id']) //Send emails to all evidence providers. - JFM 28_10_15
	{
		$allEvidenceInfo=SqlQ('SELECT *
								FROM dr_criteria_status AS ca
								WHERE criteria_status_id='.$POST['applicability']);

		$reviewProfile=SqlLi('SELECT DISTINCT rp.review_profile_id, p.program, c.coe, m.msn, ca.ca, rt.review_type, r.review_id, rch.criterion_user_id
								FROM dr_review_profile AS rp
									INNER JOIN dr_review_group AS rg ON rg.review_type=rp.review_type
									INNER JOIN dr_review_criterion AS rc ON rc.review_group=rg.group_id
									INNER JOIN dr_review_criterion_history	AS rch ON rch.criterion=rc.review_criterion_id
									INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
									INNER JOIN dr_criteria_status as cs ON cs.review_criteria=rc.review_criterion_id
									INNER JOIN dr_review_applicability AS ra ON ra.ca=cs.ca
																			AND ra.review=r.review_id
									INNER JOIN c_program AS p ON p.program_id=rp.program
									INNER JOIN c_coe AS c ON c.coe_id=rp.coe
									INNER JOIN c_msn AS m ON m.msn_id=r.msn
														AND cs.msn=r.msn
									INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
									INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
								WHERE cs.criteria_status_id='.$POST['applicability']);

		function item2($item) { return $item['review_id']; }
		$reviewIds=array_map('item2', $reviewProfile);

		$allCas=SqlSLi('SELECT ca.ca FROM dr_review_applicability AS ra INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca WHERE review IN ('.implode(',',$reviewIds).')','ca');

		$casAsString=implode(', ', $allCas);

		$user=SqlLi('SELECT name, surname, email, allow_emails  FROM c_user  AS u
						INNER JOIN dr_criteria_status_provider AS csp
							ON csp.provider=u.user_id
						WHERE csp.criteria_status ='.$POST['applicability']);

		foreach ($user as $k=>$l)
		{
			$object='Evidence';

			if($finalValidation)
			{
				$whatDone='Validated';
				$message='This is an automatic email to inform you that your evidence has been validated.<br><br>
							This evidence is for <strong>'.$reviewProfile[0]['program'].' - '.$reviewProfile[0]['coe'].' - '.$reviewProfile[0]['msn'].' - '.$casAsString.' - Criteria '.$reviewProfile[0]['criterion_user_id'].'</strong> ';

				$doSomething='view the accepted evidence';
				$subject='Evidence Validation Complete! - Criteria '.$reviewProfile[0]['criterion_user_id'].' - Airbus Review Tool';
			}
			else if($POST['decisionRadio']=='reject')
			{
				$whatDone='Rejected';
				$message='This is an automatic email to inform you that your evidence has been rejected.<br><br>
							This evidence is for <strong>'.$reviewProfile[0]['program'].' - '.$reviewProfile[0]['coe'].' - '.$reviewProfile[0]['msn'].' - '.$casAsString.' - Criteria '.$reviewProfile[0]['criterion_user_id'].'</strong> ';

				$doSomething='update the evidence';
				$subject='Evidence Rejected - Airbus Review Tool';
			}
			else
			{
				$whatDone='Validation';
				$message='This is an automatic email to inform you a piece of evidence requires your validation.<br><br>
							This evidence is for <strong>'.$reviewProfile[0]['program'].' - '.$reviewProfile[0]['coe'].' - '.$reviewProfile[0]['msn'].' - '.$casAsString.' - Criteria '.$reviewProfile[0]['criterion_user_id'].'</strong> ';

				$doSomething='validate the evidence';
				$subject='Evidence Validation Required - Airbus Review Tool';
			}

			if($l['allow_emails']!=1) sendThemMailings($object, $whatDone, $message, $doSomething, $subject, $l['email'], $l['name'], $l['surname']);
		}
	}

	if(!empty($oldUserInfo))
	{
		switch($POST['object']) //Send emails.
		{
			case $SESSION['object']['criterion_validity_id']:
				//not yet implemented
			break;

			case $SESSION['object']['review_id']:
				//not yet implemented
			break;

			case $SESSION['object']['criteria_status_id']:

				$allEvidenceInfo=SqlQ('SELECT *
								FROM dr_criteria_status AS ca
								WHERE criteria_status_id='.$POST['applicability']);

				$reviewProfile=SqlLi('SELECT DISTINCT rp.review_profile_id, p.program, c.coe, m.msn, ca.ca, rt.review_type, r.review_id, rch.criterion_user_id
										FROM dr_review_profile AS rp
											INNER JOIN dr_review_group AS rg ON rg.review_type=rp.review_type
											INNER JOIN dr_review_criterion AS rc ON rc.review_group=rg.group_id
											INNER JOIN dr_review_criterion_history	AS rch ON rch.criterion=rc.review_criterion_id
											INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
											INNER JOIN dr_criteria_status as cs ON cs.review_criteria=rc.review_criterion_id
											INNER JOIN dr_review_applicability AS ra ON ra.ca=cs.ca
																					AND ra.review=r.review_id
											INNER JOIN c_program AS p ON p.program_id=rp.program
											INNER JOIN c_coe AS c ON c.coe_id=rp.coe
											INNER JOIN c_msn AS m ON m.msn_id=r.msn
																AND cs.msn=r.msn
											INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
											INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
										WHERE cs.criteria_status_id='.$POST['applicability']);

				function item300($item) { return $item['review_id']; }
				$reviewIds=array_map('item300', $reviewProfile);

				$allCas=SqlSLi('SELECT ca.ca FROM dr_review_applicability AS ra INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca WHERE review IN ('.implode(',',$reviewIds).')','ca');

				$casAsString=implode(', ', $allCas);

				$headers="MIME-Version: 1.0\r\n";
				$headers.="Content-type: text/html; charset=utf-8\r\n";
				$headers.="From: Airbus No Reply <noreply@airbus.com>\r\n"; 
				$headers.="Reply-To: noreply@airbus.com\r\n"; 
				$headers.="Return-path: noreply@airbus.com\r\n";
				$headers.="Cc: \r\n";
				$headers.="Bcc: \r\n";

				$mailBody='
				<html>
				<head>
					<title>Evidence Validation</title>
				</head>
				<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
					<div style="width: 100%; height: 300px; cellSpacing=0; cellPadding=5; border=0;">
					<table align="center">
					  <tr>
						<td style="background-color:#6f95ab;color:#FFFFFF;font-family:Verdana,Arial,Helvetica,sans-serif;font-size:11px;font-weight:normal;padding-left:10px;">
							Evidence Validation
						</td>	
					</tr>
					<tr>
						<td style="border-width:0px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; padding-left:10px;">
							<strong>Dear '.$oldUserInfo['name'].' '.$oldUserInfo['surname'].',</strong><br>
							<p>
							This is an automatic email to inform you ';

							switch ($POST['decisionRadio']) 
							{
								case 'validate':
									$mailBody.='a piece of evidence has been <strong>validated</strong> in your name by <strong>'.$SESSION['user']['name'].' '.$SESSION['user']['surname'].'</strong>.<br><br>';
								break;
								case 'reject':
									$mailBody.='a piece of evidence has been <strong>rejected</strong> in your name by <strong>'.$SESSION['user']['name'].' '.$SESSION['user']['surname'].'</strong>.<br><br>';
								break;
								case 'forward':
									$nameSplit=explode(", ",$POST['forwardName']);
									$mailBody.='a piece of evidence has been <strong>forwarded</strong> in your name to <strong>'.$nameSplit[1].' '.$nameSplit[0].'</strong> by <strong>'.$SESSION['user']['name'].' '.$SESSION['user']['surname'].'</strong>.<br><br>';
								break;
								case 'remove':
									$mailBody.='you have been <strong>removed</strong> from the validation loop of a piece of evidence name by <strong>'.$SESSION['user']['name'].' '.$SESSION['user']['surname'].'</strong>.<br><br>';
								break;
							}

							$mailBody.=$SESSION['user']['name'].' '.$SESSION['user']['surname'].'s comments:<br>
							<i>'.$POST['decisionComments'].'</i>
							<br><br>
							This evidence was for <strong>'.$reviewProfile[0]['program'].' - '.$reviewProfile[0]['coe'].' - '.$reviewProfile[0]['msn'].' - '.$casAsString.' - Criteria '.$reviewProfile[0]['criterion_user_id'].'</strong> 
							<br><br>
							If you believe this has been done in error please contact '.$SESSION['user']['name'].' '.$SESSION['user']['surname'].' for clarification.
							</p>
							<br><br>
							Please, do not reply to this message.<br>
							<br><br><br>
							Best regards,<br><br>
							Airbus Review Tool Team.
						</td>
					  </tr>
					</table>
				</div>
				</body>
				</html>';
				
				if($oldUserInfo['allow_emails']!=1) mail($oldUserInfo['email'],'Evidence validation changed on your behalf - Criteria '.$reviewProfile[0]['criterion_user_id'],$mailBody,$headers);
			break;
		}
	}
}
else //JFM 30_10_14
{
	$answer="!!!ATTENTION!!!\n\nThe validation loop for this item has updated since\nyou last visited the page.\n\nThis window will now refresh.\n\nYour decision has NOT been saved.";
}

echo 'OK|||'.$answer;
storeSession($SESSION);
?>