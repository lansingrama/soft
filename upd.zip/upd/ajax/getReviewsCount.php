<?php

/*
 * To get the Number of reviews defiened under each level - US#110 (Possibility to delete Review type, L1, L2 and L3 from Structure Management)
 * Created by : Infosys Limited
 * Version : 4.3
 */
require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$POST = cleanArray($_GET);
if ($POST['program']) {
    $reviewQry = SqlQ('SELECT COUNT(*) FROM dr_review as dr JOIN dr_review_profile as drp ON dr.review_profile=drp.review_profile_id  WHERE program=' . $POST['program'] . '');
} else if ($POST['msn']) {
    $reviewQry = SqlQ('SELECT COUNT(*) FROM dr_review WHERE msn=' . $POST['msn'] . '');
} else if ($POST['coe']) {
    $reviewQry = SqlQ('SELECT COUNT(*) FROM dr_review as dr JOIN dr_review_profile as drp ON dr.review_profile=drp.review_profile_id  WHERE coe=' . $POST['coe'] . '');
}
echo 'OK|||', $reviewQry['COUNT(*)'];
?>
