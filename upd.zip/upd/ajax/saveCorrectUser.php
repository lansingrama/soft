<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');

$POST=cleanArray($_POST);
$correctUserId='';
$newUserCreated=0;
function writeCorrectedAnswer(&$answer,$invalidTargetId,$target,$position,$correctUserId,$correctUserName){
	if(is_array($invalidTargetId)){
		//echo 'UPDATE dr_'.$target.' SET '.$target.'_holder='.$correctUserId.','.$target.'_holder_name="" WHERE '.$target.'_id IN ('.implode(',',$invalidTargetId).')';
		SqlLQ('UPDATE dr_'.$target.' SET '.$target.'_'.$position.'='.$correctUserId.','.$target.'_'.$position.'_name="" WHERE '.$target.'_id IN ('.implode(',',$invalidTargetId).')');
		foreach($invalidTargetId as $i){
			$answer[]='chk_'.$target.'_'.$i.'%%%checkbox%%%0';
			$answer[]='chk_'.$target.'_'.$i.'%%%disabled%%%1';
			$answer[]=$target.'_'.$position.'_name_'.$i.'%%%text%%%'.$correctUserName;
		}
	}
}

if($POST['valid_user_source']=='existing'){
	$correctUserId=$POST['ddCorrectUser'];
}else{
	if($POST['name']!='' && $POST['surname']!='' && $POST['email']!=''){
		$existingUserId=SqlQ('SELECT user_id FROM c_user WHERE name="'.$POST['name'].'" AND surname="'.$POST['surname'].'" AND email="'.$POST['email'].'"');
		if(!$existingUserId){
			SqlLQ('INSERT INTO c_user (name,surname,email) VALUES ("'.$POST['name'].'","'.$POST['surname'].'","'.$POST['email'].'")');
			$lastUserId=SqlQ('SELECT LAST_INSERT_ID() AS last_user_id');
			$correctUserId=$lastUserId['last_user_id'];
			$newUserCreated=1;
		}else{
			$correctUserId=$existingUserId['user_id'];
		}
	}
}

if($correctUserId!='' && $POST['invalid_name']!=''){
	$review=array_keys(allowedReviews($SESSION,'edit','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION)));
	$perimeter=array_keys(perimeterPermission($SESSION,'view'));

	foreach($POST as $field=>$value){
		if(substr($field,0,8)=='chk_rid_' && $value==1){
			$invalidRid[]=substr($field,8,(strlen($field)-8));
		}
		if(substr($field,0,11)=='chk_action_' && $value==1){
			$invalidAction[]=substr($field,11,(strlen($field)-11));
		}
	}
	//JFM TODO - CRIT
	if(is_array($invalidRid)){
		$ridUser=SqlLi('SELECT DISTINCT rid.rid_id,rid.rid_holder_name
							FROM dr_rid AS rid
								INNER JOIN dr_action				AS act	ON rid.rid_id=act.rid
								INNER JOIN dr_review_criteria		AS rcr	ON act.criteria=rcr.review_criteria_id
								INNER JOIN dr_review_group			AS rgr	ON rcr.review_group=rgr.review_group_id
								INNER JOIN dr_action_applicability	AS aap	ON act.action_id=aap.action
								INNER JOIN c_ca						AS c	ON aap.ca=c.ca_id
							WHERE	rgr.review_profile	IN ('.implode(',',$review).')
								AND	c.perimeter			IN ('.implode(',',$perimeter).')
								AND	rid_id				IN ('.implode(',',$invalidAction).')');
		if(is_array($ridUser)){
			foreach($ridUser as $ridUser){
				if($ridUser['rid_holder_name']==$POST['invalid_name']){
					$invalidRidHolder[]=$a['rid_id'];
				}
			}
		}
	}
	//JFM TODO - CRIT
	if(is_array($invalidAction)){
		$actionUser=SqlLi('SELECT DISTINCT act.action_id,act.action_holder_name,act.action_validator_name
							FROM dr_action AS act
								INNER JOIN dr_review_criteria		AS rcr	ON act.criteria=rcr.review_criteria_id
								INNER JOIN dr_review_group			AS rgr	ON rcr.review_group=rgr.review_group_id
								INNER JOIN dr_action_applicability	AS aap	ON act.action_id=aap.action
								INNER JOIN c_ca						AS c	ON aap.ca=c.ca_id
							WHERE	rgr.review_profile	IN ('.implode(',',$review).')
								AND	c.perimeter			IN ('.implode(',',$perimeter).')
								AND	action_id			IN ('.implode(',',$invalidAction).')');
		if(is_array($actionUser)){
			foreach($actionUser as $a){
				if($a['action_holder_name']==$POST['invalid_name']){
					$invalidActionHolder[]=$a['action_id'];
				}
				if($a['action_validator_name']==$POST['invalid_name']){
					$invalidActionValidator[]=$a['action_id'];
				}
			}
		}
	}
	
	$correctUserName=SqlQ('SELECT user_id,CONCAT(name," ",surname) AS user_name_txt FROM c_user WHERE user_id='.$correctUserId);
	
	$answer='';
	writeCorrectedAnswer($answer,$invalidRidHolder,'rid','holder',$correctUserId,$correctUserName['user_name_txt']);
	writeCorrectedAnswer($answer,$invalidActionHolder,'action','holder',$correctUserId,$correctUserName['user_name_txt']);
	writeCorrectedAnswer($answer,$invalidActionValidator,'action','validator',$correctUserId,$correctUserName['user_name_txt']);
	
	if($newUserCreated==1){
		$SESSION['user_list'][$correctUserName['user_id']]=$correctUserName['user_name_txt'];
}
	
	echo 'OK|||';
	if(is_array($answer)){
		echo implode('&&&',$answer);
	}
}storeSession($SESSION);
?>