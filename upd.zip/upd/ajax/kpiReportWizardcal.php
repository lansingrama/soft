<?php
/*
 * US#91 - Improvement:Extra all design reviews
 * Get the Program, Coe and MSN based on the area selection
 * Version: 4.4
 * Created by: Infosys Limited
 */
 
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$POST = cleanArray($_GET);

if (!empty($POST['areaId'])) {
    $programList = SqlLi('SELECT DISTINCT program_id,program FROM c_program WHERE area=' . $POST['areaId'] . ' AND program_hidden=0');
    $coeList = SqlLi('SELECT coe_id,coe FROM c_coe WHERE area=' . $POST['areaId'] . ' AND coe_hidden=0');
    $programData = array();
    $CoeData = array();

    foreach ($programList as $pgm) {
        $programData[] = $pgm['program_id'] . '+' . $pgm['program'];
    }

    foreach ($coeList as $coe) {
        $CoeData[] = $coe['coe_id'] . '+' . $coe['coe'];
    }
    $result = implode(',', $programData) . '@' . implode(',', $CoeData);
}

if (!empty($POST['nextBox'])) {
    $programOut = '';
    if (!empty($POST['areaId'])) {
        $pgmIdList = SqlLi('SELECT DISTINCT program_id FROM c_program WHERE area=' . $POST['areaId'] . ' AND program_hidden=0');
        foreach ($pgmIdList as $programId) {
            $programOut .= $programId['program_id'] . ',';
        }
    } else {
        $programOut .= $POST['pgmId'];
    }

    switch ($POST['nextBox']) {
        case 'msn':
            if ($programOut != ',') {
                $msnList = SqlLi('SELECT DISTINCT msn_id,msn FROM c_msn where program IN(' . trim($programOut, ",") . ') AND msn_hidden=0 ORDER BY msn ASC');
            }
            $msnData = array();
            foreach ($msnList as $msn) {
                $msnData[] = $msn['msn_id'] . '+' . $msn['msn'];
            }
            $result = implode(',', $msnData);
            break;
    }
}
echo 'OK|||',$result;
//End of US#91
?>