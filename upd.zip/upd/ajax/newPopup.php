<?php 
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET=cleanArray($_GET);

?>OK|||<?php 

if(checkPermission('review_profile_id','view',$GET['review'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','view',0,'check',$SESSION)==1)
{

		?><img id="ac40" name="ac40" onMouseOut="nd();" onMouseOver="overlib('All Actions', ABOVE, CENTER, BORDER, 1, WRAP);" 		style="position:absolute; top:0; left:0;" 		src="../common/img/newPopUp/ac40.png"><?php 		//Actions
		?><img id="ch40" name="ch40" onMouseOut="nd();" onMouseOver="overlib('View / Edit Review', ABOVE, CENTER, BORDER, 1, WRAP);" 	style="position:absolute; top:0; left:45px;" 	src="../common/img/newPopUp/ch40.png"><?php 	//View/Edit
		?><img id="pt40" name="pt40" onMouseOut="nd();" onMouseOver="overlib('Generate PowerPoint', ABOVE, CENTER, BORDER, 1, WRAP);" style="position:absolute; top:0; right:0;" 		src="../common/img/newPopUp/pt40.png"><?php 		//PPTX Download
		?><img id="xx40" name="xx40" onMouseOut="nd();" onMouseOver="overlib('Something else', ABOVE, CENTER, BORDER, 1, WRAP);" 	style="position:absolute; top:45px; left:0;" 	src="../common/img/x30.png"><?php
		?><img id="a040" name="a040" onMouseOut="nd();" onMouseOver="overlib('Generate Review Report', ABOVE, CENTER, BORDER, 1, WRAP);" 		style="position:absolute; top:45px; right:0;" 	src="../common/img/newPopUp/a040.png"><?php 	//A0 Download

		/*?><div style="padding-bottom:10px;" onClick="openReviewForm('<?=$GET['review']?>','ca');openSideElement('<?=$GET['ca']?>','rev');closeMenu('overDivCriteriaStatus');">View / Edit Review</div><?php

		?><div onClick="openForm('list','list_name=action&ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('overDivCriteriaStatus');">All Actions for this Review</div><?php
		?><div onClick="openForm('list','list_name=evd&ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('overDivCriteriaStatus');">All Evidences for this Review</div><?php //JFM 28_04_14

		?><div style="padding-bottom:10px;" onClick="var selectedCAs=selectedCaList(); openForm('list','list_name=evd&ca='+selectedCAs+'&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('overDivCriteriaStatus');">All Evidences for Selected CAs</div><?php //JFM 28_04_14
		?><div onClick="openForm('graphsSpecificCa','ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('overDivCriteriaStatus');">Criteria Graphs for this Review</div><?php //JFM 20_05_14
		?><div style="padding-bottom:10px;" onClick="var selectedCAs=selectedCaList(); openForm('graphsSpecificCa','ca='+selectedCAs+'&review_profile=<?=$GET['review']?>',true,'POST');closeMenu('overDivCriteriaStatus');">Criteria Graphs for Selected CAs</div><?php //JFM 11_08_14

		?><div onClick="openForm('workflow','applicability=<?=$GET['ca']?>&object=<?=$SESSION['object']['review_id']?>&ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>',false,'GET'); closeMenu('overDivCriteriaStatus');">View Review Workflow</div><?php

		?><div onClick="window.open('support/pptxDownload.php?ca=<?=$GET['ca']?>&review_profile=<?=$GET['review']?>','_self');closeMenu('overDivCriteriaStatus');">Generate PowerPoint Slides</div><?php //JFM 19_01_15

		if(checkPermission('review_profile_id','export',$GET['review'],'check',$SESSION)==1)
		{
			?><div onClick="checkA0Validity(<?=$GET['ca']?>,<?=$GET['review']?>);closeMenu('overDivCriteriaStatus');">Generate A0 Report</div><?php
		}*/

	}

storeSession($SESSION);
?>