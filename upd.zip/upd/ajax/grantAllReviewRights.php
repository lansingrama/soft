<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes(utf8_decode(str_replace(array('|||','&&&','%%%','###'),'_',$v)));

/*if($GET['object']==$SESSION['object']['review_profile_id'])$userAction=array('view','edit','export','upload');
elseif($GET['object']==$SESSION['object']['action_id'])$userAction=array('view','edit','create','delete','export');*/

$userAction=array('view','edit','create','delete','export','upload');
$modifiedField=array();

foreach($userAction as &$u){
	setPermission($SESSION['tool_id'],$GET['user'],$GET['object'],$SESSION['user_action'][$u],$GET['applicability'],$GET['active'],$SESSION);
	$modifiedField[]=$GET['object'].'-'.$SESSION['user_action'][$u].'-'.$GET['applicability'];
}

storeSession($SESSION);

echo 'OK|||'.implode('&&&',$modifiedField);?>