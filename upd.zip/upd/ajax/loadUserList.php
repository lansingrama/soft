<?php
require_once('../support/header.php');
require_once('../../support.php');

switch ($_GET['v']) //JFM 02_10_14
{
	case 'grams':
		$userList=SqlLi('SELECT grams_id AS user_id, grams_reference AS user FROM c_grams');
	break;

	case 'evidence':
		$userList=SqlLi('SELECT criteria_evidence_id AS user_id, file_link AS user FROM dr_criteria_evidence');
	break;

	case 'role':
		$userList=SqlLi('SELECT responsible_role_id AS user_id, responsible_role AS user FROM dr_responsible_role');
	break;

	case 'siglum': //JFM 19_07_16
		$userList=SqlLi('SELECT department_id AS user_id, siglum AS user FROM c_department');
	break;
		/*Added for US #021
		*New case added for selecting for supplier filed
		*/
        case 'supplierId':
                $userList = SqlLi('SELECT supplier_id AS user_id, supplier AS user FROM c_supplier'); 
        break;
		//End of #US021 
	default:
		$userList=SqlLi('SELECT user_id,CONCAT(surname,", ",name) AS user FROM c_user');
	break;
}

/* JFM 02_10_14
if($_GET['v']=='grams') $userList=SqlLi('SELECT grams_id AS user_id, grams_reference AS user FROM c_grams');
else if($_GET['v']=='evidence') $userList=SqlLi('SELECT criteria_evidence_id AS user_id, file_link AS user FROM dr_criteria_evidence');
else $userList=SqlLi('SELECT user_id,CONCAT(surname,", ",name) AS user FROM c_user');
*/
if(is_array($userList)){
	$firstItem=0;
	foreach($userList as $u){
		if($firstItem!=0)$answer.='&&&';
		else $firstItem=1;
		$answer.=$u['user_id'].'%%%'.$u['user'];
	}
	echo 'OK|||'.utf8_encode($answer);
	
	if($_GET['includeSuggestionTable']==1){
		?>$$$<table cellspacing="0"cellpadding="0"class="suggestTable"><?php
		for($i=0;$i<20;$i++){?><tr><td id="se<?=$i?>"onClick="clickSuggList(this,<?=$i?>);"onMouseOver="suggMOv(this,<?=$i?>);"onMouseOut="focusOff(this);"style="cursor:pointer"></td></tr><?php }
		?><tr><td align="right"width="208"><span onClick="hideSuggest()"style="cursor:pointer;text-decoration:underline;">Close</span></td></tr><?php
		?></table><?php
	}
	
}else echo 'User List could not be loaded';

?>