<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);
$status=array('Open','In progress','Closed','Fully Closed'); //JFM 27_03_14

if($SESSION['user']['view_as']!=''){
	$viewAsUserId=$SESSION['user']['view_as'];
	$senderEmailQry=SqlQ('SELECT email FROM c_user WHERE user_id="'.$viewAsUserId.'"');
	$senderEmail=$senderEmail['email'];
}else{
	$viewAsUserId=$SESSION['user']['user_id'];
	$senderEmail=$SESSION['user']['email'];
}
$viewAsUserName=$SESSION['user_list'][$viewAsUserId];

$action=SqlQ('SELECT a.action_code,a.action_description,a.action_remark,a.action_creation,a.action_completion,a.action_status,
					u.email,
					CONCAT(u.name," ",u.surname) AS user_name
				FROM dr_action AS a
					LEFT JOIN c_user AS u ON a.action_'.$GET['position'].'=u.user_id
				WHERE action_id="'.$GET['action_id'].'"');
foreach($action as $k=>$v){
	$a[$k]=rawurlencode(stripslashes(str_replace('&&&','',$v)));
}
storeSession($SESSION);
?>OK|||mailto:<?=$a['email']?>&subject=Action <?=$a['action_code']?>&body=Dear <?=$a['user_name']?>:%0D%0A%0D%0A%0D%0AYou are the <?=$GET['position']?> of the following action:%0D%0A%0D%0A
- Action code: <?=$a['action_code']?>%0D%0A
- Description: <?=$a['action_description']?>%0D%0A
- Remark: <?=$a['action_remark']?>%0D%0A
- Creation Date: <?=$a['action_creation']?>%0D%0A
- Completion Date: <?=$a['action_completion']?>%0D%0A
- Status: <?=$status[$a['action_status']]?>%0D%0A%0D%0A
%0D%0A%0D%0A%0D%0A%0D%0A%0D%0A%0D%0A
Best Regards,%0D%0A%0D%0A
<?=rawurlencode($viewAsUserName)?>%0D%0A
<?=$senderEmail?>