<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST);


$reviewID=array();
$review=array();
$caArr=array();
	/*
	* Fix for : US#019 Change workflow for creating a design review
	* Added for displaying general information page above checklist
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
$isChecklistInfo = $POST['defineReviewChklist'];
$aflag = $POST['aflag'];
if (isset($isChecklistInfo)) {
                
                $review=SqlQ('SELECT * FROM dr_review_status WHERE review_profile="'.$POST['review'].'" AND msn="'.$POST['msn'].'" AND ca="'.$POST['ca'].'"');
					if ($review['id']) {
									SqlLQ('UPDATE dr_review_status SET planned="'.$POST['planned'].'",decision_status="'.$POST['versionEngineerOpinion'].'",engineering_remarks="'.$POST['versionEngineerRemark'].'",approver_name="'.$POST['versionEngineer'].'" WHERE id='.$review['id']);
					} else {
									SqlLQ('INSERT INTO dr_review_status (review_profile,ca,msn,planned,status,decision_status,engineering_remarks,approver_name) VALUES ("'.$POST['review'].'","'.$POST['ca'].'","'.$POST['msn'].'","'.$POST['planned'].'","'.$aflag.'","'.$POST['versionEngineerOpinion'].'","'.$POST['versionEngineerRemark'].'","'.$POST['versionEngineer'].'")');
					}
                
                $reviewDefined=SqlQ('SELECT r.review_id as id FROM dr_review AS r INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id WHERE ra.ca = "'.$POST['ca'].'" AND r.msn="'.$POST['msn'].'" AND r.review_profile="'.$POST['review'].'"');
					if ($reviewDefined['id']) {
									SqlLQ('UPDATE dr_review SET planned="'.$POST['planned'].'",cabin_ve_status="'.$POST['versionEngineerOpinion'].'",cabin_ve_remarks="'.$POST['versionEngineerRemark'].'",cabin_ve_name="'.$POST['versionEngineer'].'" WHERE review_id='.$reviewDefined['id']);
					}
	/*
	* Fix for : US#019.1 Change workflow for creating a design review
	* Added for displaying general information page above checklist
	* Version: 4.3
	* Fixed By: Infosys Limited
	*/
							$nameArray=array();
							$referenceArray=array();
							$linkArray=array();
																
							foreach ($POST as $arrayName=>$arrayValue)
							{
											$foundname=strpos($arrayName,"nameinputID");
											if($foundname===0) array_push($nameArray,$arrayValue);

											$foundreference=strpos($arrayName,"referenceinputID");
											if($foundreference===0) array_push($referenceArray,$arrayValue);

											$foundlink=strpos($arrayName,"linkinputID");
											if($foundlink===0) array_push($linkArray,$arrayValue);
							}

					SqlLQ('DELETE FROM dr_review_links WHERE review="'.$POST['review'].'"');

							for ($i=0; $i < count($nameArray); $i++) 
							{ 
							if($nameArray[$i] != '' || $referenceArray[$i] != '' || $linkArray[$i] != '')
							SqlLQ('INSERT INTO dr_review_links (review, name, reference, link) VALUES ("'.$POST['review'].'", "'.$nameArray[$i].'", "'.$referenceArray[$i].'", "'.$linkArray[$i].'")');
							}
} 
else 
{
if(!empty($POST['defineReviewRadio'])) //JFM 22_10_13 - Defining brand new review.
{              
                foreach ($POST as $arrayName=>$arrayValue)
                {
                                $foundCas=strpos($arrayName,"applicable_ca_");
                                if($foundCas===0 && $arrayValue==1) array_push($caArr,substr($arrayName,14));
                }

                if(!empty($POST['reviewID'])) //JFM 18_03_14
                {
                                //JFM 18_03_14
                                SqlLQ('DELETE FROM dr_review_applicability
                                                                WHERE review='.$POST['reviewID']);

                                $reviewID['reviewID']=$POST['reviewID'];

                                SqlLQ('UPDATE dr_review
                                                                SET validation_complete=0, planned="0000-00-00", review_date="0000-00-00", review_done=0, delta="0000-00-00", delta_done=0, review_status=0, remark="", inherited=0, validation_date="9999-12-31 00:00:00"
                                                                WHERE review_id='.$POST['reviewID']);
                }            
}
else 
{
                $caArr=explode(',',$POST['ca']);
                
                $reviewIDs=SqlSLi('SELECT review_id FROM dr_review AS r
                                                                                                INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
                                                                                WHERE ca IN ('.implode(',',$caArr).') AND msn="'.$POST['msn'].'" AND review_profile="'.$POST['review'].'"','review_id');
                                                                                
                $allCas=SqlSLi('SELECT ca FROM dr_review_applicability WHERE review IN ('.implode(',',$reviewIDs).')','ca');
                
                $caArr=$allCas;
}
$existingCa=array();
$qry=formToQuery($POST,$SESSION['table']['review_planning']['review'],$SESSION);

$reviewMlt=SqlAsLi('SELECT * 
                                                                                FROM dr_review AS r
                                                                                                INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
                                                                                WHERE ca IN ('.implode(',',$caArr).') AND msn="'.$POST['msn'].'" AND review_profile="'.$POST['review'].'"','ca');

if(!empty($reviewMlt)){
                foreach($reviewMlt as $reviewCa=>$reviewDetails){
                                $existingCa[]=$reviewCa;
                }
}

$alreadyInsertedReviewID=0;

foreach($caArr as $c)
{
                if(!in_array($c,$existingCa))
                {
                                if(!$alreadyInsertedReviewID && empty($POST['reviewID'])) //JFM 18_03_14
                                {              
                                                SqlLQ('INSERT INTO dr_review (msn,review_profile,validation_date) VALUES ("'.$POST['msn'].'","'.$POST['review'].'","9999-12-31")');
                                                $reviewID=SqlQ('SELECT LAST_INSERT_ID() AS reviewID');
													/*
													* Fix for : US#019, US#019.1 Change workflow for creating a design review
													* Added for displaying general information page above checklist
													* Version: 4.3
													* Fixed By: Infosys Limited
													*/
                                                $reviewDefined=SqlQ('SELECT planned FROM dr_review_status WHERE ca="'.$c.'" AND msn="'.$POST['msn'].'" AND review_profile="'.$POST['review'].'"');
                                                if(isset($reviewDefined['planned']) || !empty($reviewDefined['versionEngineerOpinion']) || !empty($reviewDefined['versionEngineerRemark']) || !empty($reviewDefined['versionEngineer']))
                                                {
                                                                SqlLQ('UPDATE dr_review SET planned="'.$reviewDefined['planned'].'",cabin_ve_status="'.$reviewDefined['versionEngineerOpinion'].'",cabin_ve_remarks="'.$reviewDefined['versionEngineerRemark'].'",cabin_ve_name="'.$reviewDefined['versionEngineer'].'" WHERE review_id='.$reviewID['reviewID']);
                                                } 
												
												
												$responsibleDefined=SqlLi('SELECT * FROM responsible WHERE ca="'.$c.'" AND review="'.$POST['review'].'"');
												if (!empty($responsibleDefined)) {
													 foreach ($responsibleDefined as $responsible) 
													{ 
														
														SqlLQ('INSERT INTO dr_responsible (review, role, responsible, position) VALUES ('.$reviewID['reviewID'].', '.$responsible['role'].',"'.$responsible['responsible'].'", '.$responsible['position'].')');
													} 
												}
												$attendeeDefined=SqlLi('SELECT * FROM attendee WHERE ca="'.$c.'" AND review="'.$POST['review'].'"');
												if(!empty($attendeeDefined)){
													foreach ($attendeeDefined as $attendee) 
													{ 	
													SqlLQ('INSERT INTO dr_responsible_attendee (responsible_attendee, review) VALUES ("'.$attendee['responsible_attendee'].'",'.$reviewID['reviewID'].')');
													} 
												}
														//End of US#019, US#019.1 
                                                $alreadyInsertedReviewID=1;
                                }
                                
                                SqlLQ('INSERT INTO dr_review_applicability (review,ca) VALUES ("'.$reviewID['reviewID'].'","'.$c.'")');
                                
                                $review=SqlQ('SELECT * 
                                                                                                FROM dr_review AS r
                                                                                                                INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
                                                                                                WHERE ca="'.$c.'" AND msn="'.$POST['msn'].'" AND review_profile="'.$POST['review'].'"');
                                                                                                
                                createLog('dr_log','review_id','create',$review['review_id'],'','',$SESSION);
                }
                else 
                {
                                $review['review_id']=$reviewMlt[$c]['review_id'];
                }
                
             $updateArray=getFormUpdate($qry,$reviewMlt[$c],'review_planning','review',$review['review_id'],$SESSION);

                if(!empty($updateArray))
                {
                                SqlLQ('UPDATE dr_review AS r
                                                                INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
                                                                SET '.implode(',',$updateArray).' WHERE ca="'.$c.'" AND msn="'.$POST['msn'].'" AND review_profile="'.$POST['review'].'"'); //JFM 07_04_14
                }

                if(!empty($POST['versionEngineerOpinion']))
                {
                                SqlLQ('UPDATE dr_review AS r
                                                                INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
                                                                SET r.cabin_ve_status = '.$POST['versionEngineerOpinion'].', r.cabin_ve_remarks = "'.$POST['versionEngineerRemark'].'", r.cabin_ve_name = "'.$POST['versionEngineer'].'"
                                                                WHERE ca="'.$c.'" AND msn="'.$POST['msn'].'" AND review_profile="'.$POST['review'].'"');
                }

                //JFM 13_05_16
                $nameArray=array();
                $referenceArray=array();
                $linkArray=array();
                                                                
                foreach ($POST as $arrayName=>$arrayValue)
                {
                                $foundname=strpos($arrayName,"nameinputID");
                                if($foundname===0) array_push($nameArray,$arrayValue);

                                $foundreference=strpos($arrayName,"referenceinputID");
                                if($foundreference===0) array_push($referenceArray,$arrayValue);

                                $foundlink=strpos($arrayName,"linkinputID");
                                if($foundlink===0) array_push($linkArray,$arrayValue);
                }

                SqlLQ('DELETE FROM dr_review_links WHERE review="'.$review['review_id'].'"');

                for ($i=0; $i < count($nameArray); $i++) 
                { 
                                if($nameArray[$i] != '' || $referenceArray[$i] != '' || $linkArray[$i] != '')
                                                SqlLQ('INSERT INTO dr_review_links (review, name, reference, link) VALUES ('.$review['review_id'].', "'.$nameArray[$i].'", "'.$referenceArray[$i].'", "'.$linkArray[$i].'")');
                }
}

if($POST['defineReviewRadio']=='master')
{
                //Get all the criteria from the master review and insert it into dr_review_configuration.
                $masterCriteria=SqlLi('SELECT rc.review_criterion_id, rch.criterion_position
                                                                                                                FROM dr_review_criterion AS rc
                                                                                                                                INNER JOIN dr_review_criterion_history AS rch ON rc.review_criterion_id=rch.criterion
                                                                                                                                INNER JOIN dr_review_master AS rm ON rc.review_criterion_id=rm.criterion
                                                                                                                                INNER JOIN dr_review_master_history  AS rmh                 ON rm.review_master_id=rmh.review_master
                                                                                                                                INNER JOIN dr_review_type AS rt ON rm.review_type=rt.review_type_id
                                                                                                                                INNER JOIN dr_review_profile AS rp ON rt.review_type_id=rp.review_type
                                                                                                                WHERE rp.review_profile_id='.$POST['review'].'
                                                                                                                AND rch.criterion_valid_to="0000-00-00 00:00:00"
                                                                                                                AND rmh.review_master_valid_to="0000-00-00 00:00:00"');
                
                foreach($masterCriteria as $oneMasterCriteria)
                {
                                SqlLQ('INSERT INTO dr_review_configuration (review, criterion, position, disabled) VALUES ("'.$reviewID['reviewID'].'","'.$oneMasterCriteria['review_criterion_id'].'","'.$oneMasterCriteria['criterion_position'].'",0)');
                }
}

else if($POST['defineReviewRadio']=='fromCa')
{
                //Get all the criteria from the ca and insert it into dr_review_configuration. JFM 28_10_15            
                
                $splitArray = split('_',$POST['caInfoBox']);

                $reviewIDQry=SqlLi('SELECT review_id
                                                                                                FROM dr_review AS r
                                                                                                                INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
                                                                                                                INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
                                                                                                WHERE ra.ca = '.$splitArray[0].'
                                                                                                AND rp.review_type = '.$splitArray[1]);
                
			/* 	$masterListCriteria = SqlLi('SELECT rconf.review, rconf.criterion, rconf.position FROM dr_review_criterion_history AS rch INNER JOIN dr_review_criterion AS rc ON rch.criterion=rc.review_criterion_id INNER JOIN dr_review_group AS rg ON rg.group_id=rc.review_group INNER JOIN dr_review_group_history AS rgh ON rgh.review_group=rg.group_id INNER JOIN dr_review_configuration AS rconf ON rc.review_criterion_id = rconf.criterion INNER JOIN dr_review AS r ON r.review_id=rconf.review INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review INNER JOIN dr_review_profile AS rp ON rp.review_profile_id=r.review_profile LEFT JOIN dr_review_criterion_applicability 
				AS rca ON rc.review_criterion_id=rca.criterion WHERE r.review_profile=6107 AND ra.ca =2515 ORDER BY `criterion_validity_id` DESC');
             */  

						/*
							* Fix for : US#113.1 Adding new criteria from Masterlist 
							* Adding new criteria and hightlight the newly added criteria
							* Version: 4.6
							* Fixed By: Infosys Limited
						*/			 
			 	$masterListCriteria = SqlLi('SELECT  rch.criterion,position FROM dr_review_criterion_history AS rch 
							INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
							INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
							INNER JOIN dr_review_group_history 	AS rgh 		ON rgh.review_group=rg.group_id
							INNER JOIN dr_review_master			AS rm		ON rc.review_criterion_id=rm.criterion
							INNER JOIN dr_review_master_history	AS rmh		ON rm.review_master_id=rmh.review_master
							INNER JOIN dr_review_profile		AS rp 		ON rp.review_type=rm.review_type
							LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion AND rca.review_criterion_applicability_valid_from != "0000-00-00 00:00:00"
						WHERE rm.review_type='.$splitArray[1].'
						AND rch.criterion_valid_from != "0000-00-00 00:00:00"
						AND rgh.review_group_valid_to ="0000-00-00 00:00:00"
						AND rmh.review_master_valid_to ="0000-00-00 00:00:00" AND rp.review_type='.$splitArray[1].'
						GROUP BY rch.criterion_validity_id');
             
			 $reviewCriteria=SqlLi('SELECT review, criterion, position
                                                                                                                FROM dr_review_configuration
                                                                                                                WHERE review='.$reviewIDQry[0]['review_id']);
 
                if(!empty($masterListCriteria ))
                {
                                foreach($masterListCriteria as $oneReviewCriteria)
                                {
                                                SqlLQ('INSERT INTO dr_review_configuration (review, criterion, position, disabled) VALUES ("'.$reviewID['reviewID'].'","'.$oneReviewCriteria['criterion'].'","'.$oneReviewCriteria['position'].'",0)');
                                }
                }

                SqlLQ('UPDATE dr_review SET inherited = '.$reviewIDQry[0]['review_id'].' WHERE review_id = '.$reviewID['reviewID']); //JFM 19_07_16
}
/// End of # US 113.1

else if($POST['defineReviewRadio']=='na')  //JFM 02_10_14
{
                SqlLQ('UPDATE dr_review SET review_status=4 WHERE review_id='.$reviewID['reviewID']);
}

//JFM 22_10_13 $reviewMlt=SqlAsLi('SELECT * FROM dr_review WHERE ca IN ('.$POST['ca'].') AND msn="'.$POST['msn'].'" AND review_profile="'.$POST['review'].'"','ca');
if(empty($POST['defineReviewRadio'])) //JFM 22_10_13
{
                $reviewMlt=SqlAsLi('SELECT * 
                                                                                                FROM dr_review AS r
                                                                                                                INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
                                                                                                WHERE ca IN ('.implode(',',$caArr).') AND msn="'.$POST['msn'].'" AND review_profile="'.$POST['review'].'"','ca');

                $answer='';
                if(is_array($reviewMlt)){
                                $firstItem=0;
                                foreach($reviewMlt as $reviewCa=>&$reviewDetails)
                                {
                                generateSaveResponse($answer,$firstItem,$SESSION['table']['review_planning']['review'],$POST,$reviewDetails,'_'.$reviewCa.'_'.$POST['review']);
                                }
                                $answer.='&&&bigReviewStatus%%%img%%%'.$POST['review_status'].'100.jpg';
                }
}
}
//file_put_contents('../img/ca/data.txt', $answer); //JFM 31_10_14

echo 'OK|||'.$answer;
storeSession($SESSION);
?>
