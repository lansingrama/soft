<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

if($GET['main_table_tutorial']==1)
{
	if(getFilter('last_login','view',0,$SESSION)=='')
	{
		modifyFilter('last_login','view',0,date("Y-m-d"),$SESSION,1);
		echo 'OK|||main_table_tutorial';
	}
	else if(strtotime(date("Y-m-d")) > strtotime("+1 month", strtotime(getFilter('last_login','view',0,$SESSION))))
	{
		modifyFilter('last_login','view',0,date("Y-m-d"),$SESSION,1);
		echo 'OK|||main_table_tutorial';
	}
	else
	{
		modifyFilter('last_login','view',0,date("Y-m-d"),$SESSION,1);
		echo 'OK|||no_show';
	}
}
else
{
	if(getFilter('last_login','view',0,$SESSION)=='')
	{
		echo 'OK|||first_login';
	}
	else if(strtotime(date("Y-m-d")) > strtotime("+1 month", strtotime(getFilter('last_login','view',0,$SESSION))))
	{
		echo 'OK|||first_login';
	}
	else
	{
		modifyFilter('last_login','view',0,date("Y-m-d"),$SESSION,1);
		echo 'OK|||no_show';
	}
}

/* JFM 15_09_15
$lastChangeLog=SqlQ('SELECT change_log_id FROM c_change_log ORDER BY change_log_id DESC LIMIT 1');
if(getFilter('last_change_log_displayed','view',0,$SESSION)=='')
{
	if(getFilter('program','filter',0,$SESSION)!='' && getFilter('coe','filter',0,$SESSION)!='' && getFilter('msn','filter',0,$SESSION)!='')
	{
		modifyFilter('last_change_log_displayed','view',0,$lastChangeLog['change_log_id'],$SESSION,1);
		$reviewProfileList=allowedSimpleObject('review_profile','review_type',$SESSION,'dr_','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION));
		if(is_array($reviewProfileList) && count($reviewProfileList)>1)
		{
			echo 'OK|||first_login';
		}
		else echo 'OK|||no_show';
	}
	else echo 'OK|||no_show';
}
else
{
	if($lastChangeLog['change_log_id']>getFilter('last_change_log_displayed','view',0,$SESSION))
	{
		$lastChangeLogId=getFilter('last_change_log_displayed','view',0,$SESSION);
		modifyFilter('last_change_log_displayed','view',0,$lastChangeLog['change_log_id'],$SESSION,1);
		echo 'OK|||show&&&',$lastChangeLogId;
	}
	else if(getFilter('display_really_important_message','view',0,$SESSION)=='' || getFilter('display_really_important_message','view',0,$SESSION)==0)
	{
		modifyFilter('display_really_important_message','view',0,1,$SESSION,1);
		echo 'OK|||display_really_important_message';
	}
	else echo 'OK|||no_show';
}*/
storeSession($SESSION);
?>