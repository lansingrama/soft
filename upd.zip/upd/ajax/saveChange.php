<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$POST=cleanArray($_POST);

if($POST['change_id']!=''){
	if($POST['change_id']=='new'){
		$POST['list_name']='change';
		$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
		
		SqlLQ('INSERT INTO dr_change (change_status,change_type,change_description,change_creation,change_created_by)
					VALUES(0,"'.$POST['change_type'].'","'.$POST['change_description'].'",NOW(),"'.$viewAsUserId.'")');
		
		require_once('list.php');
	}else{
		SqlLQ('UPDATE dr_change SET change_description="'.$POST['change_description'].'" WHERE change_id="'.$POST['change_id'].'"');

		$change=SqlQ('SELECT chg.change_id,chg.change_status,chg.change_description,chg.change_creation,
							COUNT(chs.change_screenshot_id) AS change_screenshot,
							CONCAT(u.surname,", ",u.name) AS change_created_by
						FROM dr_change AS chg
							INNER JOIN dr_change_screenshot		AS chs	ON chg.change_id=chs.change
							INNER JOIN c_user					AS u	ON chg.change_created_by=u.user_id
						WHERE chg.change_id="'.$POST['change_id'].'"');
		
		$answer='';

		if($change){
			$firstItem=0;
			$addLocation='_'.$POST['change_id'];
			generateSaveResponse($answer,$firstItem,$SESSION['table']['change']['change'],$POST,$change,$addLocation);
			echo 'OK|||'.$answer;
		}else{
			?>OK|||error|||Invalid ID<?php
		}
	}
}else{
	?>OK|||error|||Missing ID<?php
}
storeSession($SESSION);
?>