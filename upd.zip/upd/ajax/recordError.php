<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/mail.php');

$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
if(!empty($viewAsUserId))
{
	SqlLQ('INSERT INTO c_error_log (time_stamp,tool,user,error_log) VALUES (NOW(),"'.$SESSION['tool_id'].'","'.$viewAsUserId.'","'.addslashes(utf8_decode($_POST['error'])).'")');
	sendErrorReportToAdmin(addslashes(utf8_decode($_POST['error'])), addslashes(utf8_decode($_POST['request'])), $viewAsUserId); //JFM 15_09_15 - JFM 12_01_16
	storeSession($SESSION);
}
?>OK|||OK