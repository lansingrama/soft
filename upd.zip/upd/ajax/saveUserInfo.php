<?php
require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');

$POST=cleanArray($_POST);

/* Added for US#021.1 - Siglum/Company Name
 * To create/edit Supplier field in user management
 */
$supplier = SqlQ('SELECT supplier FROM c_supplier WHERE supplier="'.$POST['supplierName'].'"');

/*
	US#021.2-Siglum/Company Name
	To Autocheck perimeter linked to the supplier in user management
	Fixed By - Infosys Limited
	Version: V 4.6
	*/
$perimeterCheck = SqlAsLi('SELECT c.perimeter_id FROM `c_perimeter` c inner join dr_perimeter_supplier_map d on c.perimeter_id=d.perimeter inner join c_supplier s on s.supplier_id = d.supplier where s.supplier="'.$POST['supplierName'].'"','perimeter_id');

//JFM 19_07_16
if(!empty($POST['siglum']))
{
	$siglum=SqlQ('SELECT department_id FROM c_department WHERE siglum="'.$POST['siglum'].'"');

	if(empty($siglum))
	{
		SqlLQ('INSERT INTO c_department (siglum) VALUES ("'.$POST['siglum'].'")');
		$newSiglumId = SqlQ('SELECT LAST_INSERT_ID()');
		$POST['department'] = $newSiglumId['LAST_INSERT_ID()'];
	}
	else
	{
		$POST['department']=$siglum['department_id'];
	}
}

if(empty($POST['user'])) //Creating New User
{
        if($POST['supplierName'] != '' && !$supplier) {
            SqlLQ('INSERT INTO c_supplier (supplier) VALUES("'.$POST['supplierName'].'")');
        }
        if($POST['externalUser'] != 1) {
            $POST['externalUser'] = 0;
            //Added for US #021 - To assign the default supplier (AIRBUS) value to the internal users
            $POST['supplierName'] = 'AIRBUS';
        }
		
	//Added for US #048.1 - To assign the supplier value to the external users
	$supplierAdmin = SqlLi('SELECT supplier,type FROM c_user WHERE user_id='.$SESSION['user']['user_id']);
	if($supplierAdmin[0]['type'] == 1 && $userSupplier != 'AIRBUS'){
		$POST['supplierName'] = $supplierAdmin[0]['supplier'];
		$POST['externalUser'] = 1;
	}
	SqlLQ('INSERT INTO c_user (login,name,surname,email,department,company,supplier,confirmed,allow_emails,type) VALUES 
			("'.$POST['login'].'","'.$POST['nameUserMainDataForm'].'","'.$POST['surnameUserMainDataForm'].'","'.$POST['emailUserMainDataForm'].'","'.$POST['department'].'","'.$POST['company'].'","'.$POST['supplierName'].'",0,"'.$POST['allowEmails'].'","'.$POST['externalUser'].'")');

	$userId=SqlQ('SELECT LAST_INSERT_ID() AS user_id');

	$md5Keys=SqlSLi('SELECT user_key FROM c_user','user_id');
	$ok=0;
	while($ok==0)
	{
		$md5Str=md5($userId.microtime(true).rand());
		if(!in_array($md5Str,$md5Keys))
		{
			SqlLQ('UPDATE c_user SET user_key="'.$md5Str.'" WHERE user_id="'.$userId['user_id'].'"');
			$ok=1;
		}
	}

	SqlLQ('INSERT INTO c_permission (user, tool, object, action, applicability, active) VALUES ('.$userId['user_id'].',1,92,1,1,1)');
	$SESSION['edit_user']['active_permission']=1;
	$SESSION['edit_user']['user_invited']=0;
	checkSendInvitation($userId['user_id'],$SESSION);
	/*
		US#021.2-Siglum/Company Name
		To Autocheck perimeter linked to the supplier in user management
		Fixed By - Infosys Limited
		Version: V 4.6 
		*/
		
		if($POST['externalUser'] == 1 && $POST['supplierName'] != '') 
		{
			
			$actionval=array(1,2,6);
			
			$objectId = SqlQ('SELECT object_id FROM c_object WHERE object = "perimeter_id"');
			
            foreach($perimeterCheck as $perimeterVal)
			{
				
				foreach($actionval as $action)
				{
					$permissionFound=SqlQ('SELECT permission_id,active FROM c_permission WHERE user='.$userId['user_id'].' AND object='.$objectId['object_id'].' AND action='.$action.' AND applicability='.$perimeterVal['perimeter_id'].''); 
				
					if($permissionFound['permission_id']!='')
					{
						SqlLQ('UPDATE c_permission SET active = 1 WHERE permission_id IN ("'.$permissionFound['permission_id'].'")'); 
					}
					else
					{
						SqlLQ('INSERT INTO c_permission (user,tool,object,action,applicability,active) VALUES ("'.$userId['user_id'].'",1,"'.$objectId['object_id'].'","'.$action.'","'.$perimeterVal['perimeter_id'].'",1)');
					}
				}
			}
			 
		}
		/*
		US#021.2-Siglum/Company Name
		To Autocheck perimeter linked to the supplier in user management
		Fixed By - Infosys Limited
		Version: V 4.6
		*/
	echo 'OK|||'.$userId['user_id'];
}
else //Editing User
{
		
        // To check the Supplier value is not empty and not exist already
        if($POST['supplierName'] != '' && !$supplier) {
            SqlLQ('INSERT INTO c_supplier (supplier) VALUES("'.$POST['supplierName'].'")');
        }
        // End - US#021.1
	$login=SqlQ('SELECT login FROM c_user WHERE user_id="'.$POST['user'].'"');
        if($POST['externalUser'] != 1) {
            $POST['externalUser'] = 0;
            //Added for US #021
            $POST['supplierName'] = 'AIRBUS';
        }
		/*
		US109-General Information not editable by supplier
		Revoke edit,create and delete access
		Fixed By - Infosys Limited
		Version: V 4.5
		*/
		if($POST['externalUser'] == 1) {
			$object = SqlQ('SELECT object_id FROM c_object WHERE object = "review_profile_id"');
			$resetExternalUserAccess = SqlLQ('UPDATE c_permission SET active = 0 
				WHERE user='.$POST['user'].' AND object='.$object['object_id'].' 
				AND action IN (2,3,4)');
		}
		/* End for US109 */
		/*
		US#021.2-Siglum/Company Name
		To Autocheck perimeter linked to the supplier in user management
		Fixed By - Infosys Limited
		Version: V 4.6
		*/
		if($POST['externalUser'] == 1 && $POST['supplierName'] != '') 
		{
			$actionval=array(1,2,6);
			$objectId = SqlQ('SELECT object_id FROM c_object WHERE object = "perimeter_id"');
            foreach($perimeterCheck as $perimeterVal)
			{
				foreach($actionval as $action)
				{
					$permissionFound=SqlQ('SELECT permission_id,active FROM c_permission WHERE user='.$POST['user'].' AND object='.$objectId['object_id'].' AND action='.$action.' AND applicability='.$perimeterVal['perimeter_id'].''); 
					if($permissionFound['permission_id']!='')
					{
						SqlLQ('UPDATE c_permission SET active = 1 WHERE permission_id IN ("'.$permissionFound['permission_id'].'")'); 
					}
					else
					{
						SqlLQ('INSERT INTO c_permission (user,tool,object,action,applicability,active) VALUES ("'.$POST['user'].'",1,"'.$objectId['object_id'].'","'.$action.'","'.$perimeterVal['perimeter_id'].'",1)');
					}
				}
			}
			 
		}
		/*
		US#021.2-Siglum/Company Name
		To Autocheck perimeter linked to the supplier in user management
		Fixed By - Infosys Limited
		Version: V 4.6
		*/
	$userSaved=SqlLQ('UPDATE c_user
		SET 
			login="'.$POST['login'].'",
			name="'.$POST['nameUserMainDataForm'].'",
			surname="'.$POST['surnameUserMainDataForm'].'",
			email="'.$POST['emailUserMainDataForm'].'",
			department="'.$POST['department'].'",
			company="'.$POST['company'].'",
                        supplier="'.$POST['supplierName'].'",
			allow_emails="'.$POST['allowEmails'].'",
                        type="'.$POST['externalUser'].'"
		WHERE user_id="'.$POST['user'].'"');
        // End - US#021
	if($userSaved)
	{
		$userResult=SqlQ('SELECT name,surname FROM c_user WHERE user_id="'.$POST['user'].'"');
		foreach($userResult as $k=>$v)
		{
			$userResult[$k]=utf8_encode($v);
		}
		echo 'OK|||userElement_',$POST['user'],'%%%listElement%%%',$userResult['surname'],', ',$userResult['name'],'###',$POST['user'],'###0',
				'&&&userTitle%%%text%%%',$userResult['name'],' ',$userResult['surname'];
	}
	else
	{
		echo 'There was an error in the Query and it could not be performed.';
	}
}
storeSession($SESSION);
?>