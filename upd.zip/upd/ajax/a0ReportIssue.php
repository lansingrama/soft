<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

$a0ReportIssue=SqlQ('SELECT a0_report_issue
						FROM dr_a0_report
						WHERE msn='.getFilter('msn','filter',0,$SESSION).'
							AND object='.$object.'
							AND applicability='.$applicability.'
						ORDER BY a0_report_creation DESC
						LIMIT 1');

echo 'OK|||',$a0ReportIssue,'&&&';
storeSession($SESSION);
?>