<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
//require_once('../common.php');
require_once('../support/localSupport.php');
foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);
//$c=$_GET['c'];
$hide=$SESSION['user_action']['hide'];

$filterId='sf-'.$GET['app'].'-'.$GET['fld'];

$srt=getFilter($GET['fld'],'sort',$GET['app'],$SESSION);
$srtTxt=($srt=='')?array('NO'=>'checked'):array($srt=>'checked');

?>OK|||<form id="<?=$filterId?>-form" method="post" name="<?=$filterId?>-form"><?php
	?><table class="fltTable"><?php
		?><tr><td style="text-align:right;"><img alt="Close this Window" onClick="$('<?=$filterId?>').style.display='none';$('<?=$filterId?>').innerHTML='';fltOn=false;"src="../common/img/x.png"style="cursor:pointer;"></td></tr><?php
		if($GET['fld']!='ca' && $GET['fld']!='wp')?><tr><td align="center"><input class="stdBtn" onClick="<?php if($GET['fltType']=='date'){?>$('<?=$filterId?>_AdCal').style.display='none';$('<?=$filterId?>_BdCal').style.display='none';<?php }?>processing=true;waitTd.innerHTML='Processing...';ajaxRequest('ajax/setDisplayedColumn.php?location=cfc-<?=$SESSION['object'][$GET['fld']],'-',$hide,'-',$GET['app']?>&value=1&redrawTable=1','redrawTable',true,'GET');fltOn=false;"type="button"value="Hide Column &#9658;"></td></tr><?php
		?><tr><td><strong>Sort <?=$GET['sfTxt']?>:</strong></td></tr><?php
		?><tr><td nowrap><?php
			?><input <?=$srtTxt['ASC']?> id="<?=$filterId?>-sort-a"name="<?=$filterId?>-sort"type="radio"value="ASC">Asc<?php
			?><input <?=$srtTxt['DESC']?> id="<?=$filterId?>-sort-d"name="<?=$filterId?>-sort"type="radio"value="DESC">Desc<?php
			?><input <?=$srtTxt['NO']?> id="<?=$filterId?>-sort-n"name="<?=$filterId?>-sort"type="radio"value="">None<?php
		?></td></tr><?php
		?><tr><td>&nbsp;</td></tr><?php
		switch($GET['fltType']){
			case 'action':
				?><tr><td><?php
				?><input <?php if(getFilter($GET['fld'],'show_with_actions',$GET['app'],$SESSION)==1)echo'checked'?> name="<?=$filterId?>-show_with_actions"type="checkbox"><b> Show only &gt; 0</b><?php
				?></td></tr><?php
			break;
			case 'date':
				$adArr=array();
				$bdArr=array();
				$afterDate=getFilter($GET['fld'],'show_after',$GET['app'],$SESSION);
				$beforeDate=getFilter($GET['fld'],'show_before',$GET['app'],$SESSION);
				$adArr=explode('-',$afterDate);
				$bdArr=explode('-',$beforeDate);
				if($SESSION['filter'][$GET['fld']]['ev'])$disDate='disabled';
				?><tr><td><strong>View after than:</strong></td></tr><?php
				?><tr><td><?php
					?><input class="thinBorders"<?=$disDate?> id="<?=$filterId?>-show_afterY"maxlength="4"size="4"type="text"value="<?=$adArr[0]?>"> -<?php
					?><input class="thinBorders"<?=$disDate?> id="<?=$filterId?>-show_afterM"maxlength="2"size="2"type="text"value="<?=$adArr[1]?>"> -<?php
					?><input class="thinBorders"<?=$disDate?> id="<?=$filterId?>-show_afterD"maxlength="2"size="2"type="text"value="<?=$adArr[2]?>"><?php
					?><input id="<?=$filterId?>-show_after" name="<?=$filterId?>-show_after" type="hidden" value="<?=$afterDate?>"><?php
					?><img onClick="getCal('calTable','<?=$filterId?>_AdCal','<?=$filterId?>-show_after','<?=$filterId?>-show_before','<?=date('m',time())?>','<?=date('Y',time())?>','','put',true,true);"src="../common/img/calendar.jpg"style="cursor:pointer"><div class="calendar"id="<?=$filterId?>_AdCal"style="position:relative"></div><?php
				?></td></tr><?php
				?><tr><td><strong>View before than:</strong></td></tr><?php
				?><tr><td><?php
					?><input class="thinBorders"<?=$disDate?> id="<?=$filterId?>-show_beforeY"maxlength="4"size="4"type="text"value="<?=$bdArr[0]?>"> -<?php
					?><input class="thinBorders"<?=$disDate?> id="<?=$filterId?>-show_beforeM"maxlength="2"size="2"type="text"value="<?=$bdArr[1]?>"> -<?php
					?><input class="thinBorders"<?=$disDate?> id="<?=$filterId?>-show_beforeD"maxlength="2"size="2"type="text"value="<?=$bdArr[2]?>"><?php
					?><input id="<?=$filterId?>-show_before" name="<?=$filterId?>-show_before" type="hidden" value="<?=$beforeDate?>"><?php
					?><img onClick="getCal('calTable','<?=$filterId?>_BdCal','<?=$filterId?>-show_before','<?=$filterId?>-show_after','<?=date('m',time())?>','<?=date('Y',time())?>','<?=$filterId?>-show_after','put',true,true);"src="../common/img/calendar.jpg"style="cursor:pointer"><div class="calendar"id="<?=$filterId?>_BdCal"style="position:relative"></div><?php
				?></td></tr><?php
				?><tr><td>&nbsp;</td></tr><?php
				?><tr><td><input <?php if(getFilter($GET['fld'],'show_only_empty',$GET['app'],$SESSION)!='')echo'checked'?> name="<?=$filterId?>-show_only_empty"onClick="evDis('<?=$filterId?>',this.checked);"type="checkbox"><b> Only empty values</b></td></tr><?php
			break;
			case 'status':
				?><tr><td><strong>Filter by status:</strong></td></tr><?php
				?><tr><td nowrap><?php
					?><input <?php if(getFilter($GET['fld'],'hide_red',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_red"name="<?=$filterId?>-hide_red"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"><img src="../common/img/r20.png">&nbsp;<?php
					?><input <?php if(getFilter($GET['fld'],'hide_amber',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_amber"name="<?=$filterId?>-hide_amber"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"><img src="../common/img/a20.png">&nbsp;<?php
					?><input <?php if(getFilter($GET['fld'],'hide_green',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_green"name="<?=$filterId?>-hide_green"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"><img src="../common/img/g20.png">&nbsp;<?php
					?><input <?php if(getFilter($GET['fld'],'hide_no_status',$GET['app'],$SESSION)!=1)echo'checked'?> id="<?=$filterId?>-hide_no_status"name="<?=$filterId?>-hide_no_status"onClick="chkMinSel('<?=$filterId?>-hide_',this);"type="checkbox"><img src="../common/img/b20.png">&nbsp;<?php
				?></td></tr><?php
			break;
			case 'text':
				?><tr><td><strong>Must Contain:</strong></td></tr><?php
				?><tr><td><input class="thinBorders" id="<?=$GET['fld']?>-filter"name="<?=$filterId?>-filter"type="text" value="<?=getFilter($GET['fld'],'filter',$GET['app'],$SESSION)?>"></td></tr><?php
			break;
		}
		?><tr><td id="waitTd" style="text-align:right;">&nbsp;</td></tr><?php
		?><tr><td align="right" nowrap style="text-align:right;"><?php
			?><input class="stdBtn" onClick="<?php if($GET['fltType']=='date'){?>storeDates(filterDates,'<?=$filterId?>');$('<?=$filterId?>_AdCal').style.display='none';$('<?=$filterId?>_BdCal').style.display='none';<?php }?>processing=true;waitTd.innerHTML='Processing...';sendAjaxForm('<?=$filterId?>-form','ajax/showTable.php?m=add&o=<?=$filterId?>','showTable','');fltOn=false;" type="button" value="Filter &#9658;"><?php
			?><input class="stdBtn" onClick="<?php if($GET['fltType']=='date'){?>$('<?=$filterId?>_AdCal').style.display='none';$('<?=$filterId?>_BdCal').style.display='none';<?php }?>processing=true;waitTd.innerHTML='Processing...';ajaxRequest('ajax/showTable.php?m=reset&o=<?=$filterId?>','showTable',true,'POST');fltOn=false;" type="button" value="Reset &#9658;"><?php
			?><input class="stdBtn" onClick="$('<?=$filterId?>').style.display='none';$('<?=$filterId?>').innerHTML='';fltOn=false;" type="button" value="Cancel &#9658;"><?php
		?></td></tr><?php
	?></table><?php
?></form><?php
storeSession($SESSION);
?>