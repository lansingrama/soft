<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
foreach($_GET as $k=>&$v) $GET[$k]=addslashes($v);

$revConfigId=SqlQ('SELECT review_configuration_id FROM dr_review_configuration WHERE review_configuration_profile="'.$GET['profile'].'" AND criteria="'.$GET['criteria'].'"');

if($revConfigId) SqlLQ('UPDATE dr_review_configuration SET review_configuration="'.$GET['newValue'].'" WHERE review_configuration_profile="'.$GET['profile'].'" AND criteria="'.$GET['criteria'].'"');
else SqlLQ('INSERT INTO dr_review_configuration (review_configuration_profile,criteria,review_configuration) VALUES ("'.$GET['profile'].'","'.$GET['criteria'].'","'.$GET['newValue'].'")');

echo 'OK|||'.$GET['group'].'&&&'.$GET['criteria'].'&&&'.$GET['newValue'];
storeSession($SESSION);
?>