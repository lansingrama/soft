<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

extract($_GET);
if($SESSION['Level']!=1 && $SESSION['Level']!=2 && $SESSION['Level']!=3)header("Location: ../security/accExp.php");
$msn=$_SESSION['filter']['msn']['n'];
$dateArr=array('PDRPl','PDRDate','PDRDelta','CDRPl','CDRDate','CDRDelta','preFDADate','FDAPl','FDADate','FDADelta','assStart','KODD');
$revDataArr=array('PDRPerf','PDRDeltaPerf','PDRStat','PDRLink','CDRPerf','CDRDeltaPerf','CDRStat','CDRLink','preFDAPerf','FDAPerf','FDADeltaPerf','FDAStat','FDALink','assStartPerf','KODDPerf');
$cawpDataArr=array('perim','ca','wp','caName','desComp','desTeam','desDept','desResp','desQua','manComp','manTeam','manDept','manResp','manQua','caa');

$caWpArr=explode('|',$cawp);
$logArr=array();
$condArr=array();
foreach($caWpArr as &$cwa){
	$cw=explode('%',$cwa);
	$caCode=($cw[0])?$cw[0]:'N/A';
	$wpCode=($cw[1])?$cw[1]:'N/A';
	$logArr[]="CA:$caCode / WP:$wpCode";
	$condArr[]="c.ca='$cw[0]'";
}
$condStr=implode(' OR ',$condArr);
$logStr=implode(', ',$logArr);

$firstMod=true;
$connString='';
$cawpModsString='';
foreach($cawpDataArr as &$cDA)
	if(isset($$cDA)){
		$$cDA=str_replace('%26','&',$$cDA);
		$cawpModsString.=$connString.$cDA."='".$$cDA."'";
		$jsString[$cDA]=($$cDA=='')?'_*no*_':$$cDA;
		if($firstMod==true){
			$connString.=',';
			$firstMod=false;
		}	
	}
$firstCawp=explode('%',$caWpArr[0]);
$dateFill=SqlQ("SELECT PDRPl,PDRDate,PDRDelta,CDRPl,CDRDate,CDRDelta,preFDADate,FDAPl,FDADate,FDADelta,assStart,KODD FROM dqrp_rev WHERE MSN='$msn' AND ca='$firstCawp[0]'");
$firstMod=true;
$connString='';
$revsModsString='';
foreach($dateArr as &$d){
	$dY=$d.'Y';
	$dM=$d.'M';
	$dD=$d.'D';
	if(isset($$dY)||isset($$dM)||isset($$dD)){
		if($$dY=='' && $$dM=='' && $$dD==''){
			$revsModsString.=$connString.$d."='0000-00-00'";
			$jsString[$d]='0000-00-00';
		}else{
			$dFA[$d]=explode('-',$dateFill[$d]);
			if($$dY==''||$$dY=='****')$$dY=$dFA[$d][0];
			if($$dM==''||$$dM=='**')$$dM=$dFA[$d][1];
			if($$dD==''||$$dD=='**')$$dD=$dFA[$d][2];
			if(checkdate($$dM,$$dD,$$dY)){
				$$d=$$dY.'-'.$$dM.'-'.$$dD;
				$revsModsString.=$connString.$d."='".$$d."'";
				$jsString[$d]=$$d;
			}else $jsString[$d]='_*no*_';
		}
		if($firstMod==true){
			$connString.=',';
			$firstMod=false;
		}
	}
}
foreach($revDataArr as &$nDA)
	if(isset($$nDA)){
		$revsModsString.=$connString.$nDA."='".str_replace('%26','&',$$nDA)."'";
		$jsString[$nDA]=$$nDA;
		if($firstMod==true){
			$connString.=',';
			$firstMod=false;
		}	
	}

if($cawpModsString!='')SqlLQ("UPDATE cawp c SET $cawpModsString WHERE $condStr");
if($revsModsString!='')SqlLQ("UPDATE dqrp_rev c SET $revsModsString WHERE MSN='$msn' AND ($condStr)");

$sqlData=SqlLi("SELECT c.ca,c.wp,c.caName,c.perim,r.assStart,r.assStartPerf,r.KODD,r.KODDPerf,
				r.PDRPl,r.PDRDate,r.PDRPerf,r.PDRDelta,r.PDRDeltaPerf,r.PDRStat,r.PDRLink,
				r.CDRPl,r.CDRDate,r.CDRPerf,r.CDRDelta,r.CDRDeltaPerf,r.CDRStat,r.CDRLink,r.preFDADate,r.preFDAPerf,
				r.FDAPl,r.FDADate,r.FDAPerf,r.FDADelta,r.FDADeltaPerf,r.FDAStat,r.FDALink FROM cawp c JOIN dqrp_rev r WHERE MSN='$msn' AND c.ca=r.ca AND ($condStr)");
$idArr=explode('|',$id);
$i=0;
echo $id,'§';
$colArr=array('r','a','g');
foreach($sqlData as &$s){
	if($s['KODD']!='0000-00-00'){
		$FAIDate=strtotime($s['KODD']." -2 week");
		$dWeek=date("w",$FAIDate);
		if($dWeek==0)$dWeek=7;
		if($dWeek>4)$FAIDate=$FAIDate-(($dWeek-4)*24*60*60);
		$FAI=date("Y-m-d",$FAIDate);
	}
	if($i!=0)echo'*?';
	$PDRStat=($s['PDRPerf']=='1')?$colArr[$s['PDRStat']]:'b';
	$CDRStat=($s['CDRPerf']=='1')?$colArr[$s['CDRStat']]:'b';
	$FDAStat=($s['FDAPerf']=='1')?$colArr[$s['FDAStat']]:'b';
	echo $s['ca'],'#',$s['wp'],'#',$s['caName'],'#',$s['perim'],'#',$s['assStart'],'#',$s['assStartPerf'],'#',$FAI,'#',$s['KODD'],'#',$s['KODDPerf'],
	'#',$s['PDRPl'],'#',$s['PDRDate'],'#',$s['PDRPerf'],'#',$s['PDRDelta'],'#',$s['PDRDeltaPerf'],'#',$PDRStat,'#',$s['PDRLink'],
	'#',$s['CDRPl'],'#',$s['CDRDate'],'#',$s['CDRPerf'],'#',$s['CDRDelta'],'#',$s['CDRDeltaPerf'],'#',$CDRStat,'#',$s['CDRLink'],'#',$s['preFDADate'],'#',$s['preFDAPerf'],
	'#',$s['FDAPl'],'#',$s['FDADate'],'#',$s['FDAPerf'],'#',$s['FDADelta'],'#',$s['FDADeltaPerf'],'#',$FDAStat,'#',$s['FDALink'];
	
	$i++;
}
if($cawpModsString && $revsModsString)$cawpModsString.=', ';
Create_Log($logStr.' MSN: '.$msn.'. Modifications: '.$cawpModsString.$revsModsString,'CA/WP/Reviews Modified','dqrp_log');
?>