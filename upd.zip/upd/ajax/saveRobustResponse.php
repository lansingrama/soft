<?php
/*
* US#134 - New section inside the Design Review information, to manage robustness assessment.
* Version: V 4.7
* To save added questions for Robustness Assessment page
* Fixed by: Infosys Limited
*/ 

require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$POST=cleanArray($_POST);
//$question_ids= SqlLi('SELECT question_id from dr_assessment_questions where question_hidden = 0');
foreach($POST as $key => $val) {
	//echo 'Field name : '.$key .', Value : '.$val.'<br>';
	//echo "for"."<br>";
	//if (isset($POST['']) && !empty($POST['"answer_".'question''])) {
	 SqlLQ('INSERT INTO dr_question_response(user_id,question_id,question_response) VALUES ("'.$SESSION['user']['user_id'].'","'.$key.'","'.$val.'")');						
	
	
	//}

}

echo 'OK|||';
?>
