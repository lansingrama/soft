<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

if($action['criteria']==''){
	$action['criteria']=$_GET['review_criteria_id'];
}

$msn=getFilter('msn','filter',0,$SESSION);

if(!empty($GET['msn'])) //JFM 09_04_14
{
	$msn=$GET['msn'];
	$action['criteria']=$GET['review_criteria_id'];
}
/*
	* US #054
	* Version :2.0
	* Fixed by : Infosys Limited 
	* pie chart condittion
*/
if (!empty($msn)) {
	$reviewID=SqlLi('SELECT review_id, validation_date
					FROM dr_review AS r
						INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
					AND ra.ca IN ('.$GET['ca'].')
					AND r.msn='.$msn);
}
						
$criteriaColumn=SqlQ('SELECT DISTINCT rch.criterion_user_id,rch.criterion_name,rgh.review_group_description, rch.criterion_valid_from, rch.criterion_description, rch.criterion_moc,
						GROUP_CONCAT(g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS criterion_reference
						FROM dr_review_criterion_history AS rch
							INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
							INNER JOIN dr_review_group_history AS rgh ON rc.review_group=rgh.review_group
							LEFT  JOIN dr_review_criterion_applicability AS rca ON rc.review_criterion_id=rca.criterion
							LEFT  JOIN c_grams AS g	ON	rca.applicability=g.grams_id
												AND	rca.object='.$SESSION['object']['grams_id'].'
												AND rca.review_criterion_applicability_valid_from <= "'.$reviewID[0]['validation_date'].'"
						WHERE review_criterion_id="'.$action['criteria'].'"
						AND rch.criterion_valid_from <= "'.$reviewID[0]['validation_date'].'"
						AND rch.criterion_valid_from != "0000-00-00 00:00:00"
						GROUP BY rch.criterion_validity_id ORDER BY criterion_group ASC');
//print_r($criteriaColumn);
						
if($action['criteria']!='' && $msn!='' && $GET['ca']!=''){
	$criteriaStatus=SqlQ('SELECT criteria_status,criteria_focal_point,criteria_comments
							FROM dr_criteria_status
							WHERE msn="'.$msn.'"
								AND ca IN('.$GET['ca'].')
								AND review_criteria="'.$action['criteria'].'"');
}

?><div class="elementDetailsContainer"style="width:600px;" align="left"><?php
	?><table class="criteriaTable"style="width:600px;" cellpadding="0" cellspacing="0"><?php //JFM 09_04_14
		?><tr class="tableGroup prmRow"><?php
			?><td colspan="4">Criteria</td><?php
		?></tr><?php

		?><tr class="infoRow"><?php
			?><td class="paramDef" width="60px">ID</td><?php
			?><td><?=$criteriaColumn['criterion_user_id']?></td><?php	
			?><td class="paramDef">Criteria</td><?php
			?><td><?=$criteriaColumn['criterion_name']?></td><?php //JFM 11_11_13
		?></tr><?php

		?><tr class="tableGroup prmRow"><?php
			?><td id="moreInfo" colspan="4" style="text-align:center;" onclick="colapseSidebar('criteriaTableMoreInfo')">&#9660; More Info &#9660;</td><?php //JFM 17_11_15
		?></tr><?php

		?></table><?php

		?><table id="criteriaTableMoreInfo" class="criteriaTable"style="width:350px;display:none;" cellpadding="0" cellspacing="0"><?php

		?><tr class="infoRow"><?php
			?><td style="width:60px;" class="paramDef">Group</td><?php
			?><td colspan="3"><?=$criteriaColumn['review_group_description']?></td><?php	
		?></tr><?php

		?><tr class="infoRow"><?php
			?><td class="paramDef">Description</td><?php
			?><td colspan="3"><?=$criteriaColumn['criterion_description']?></td><?php //JFM 25_11_13
		?></tr><?php
		
		?><tr class="infoRow"><?php
			?><td class="paramDef">MOC</td><?php
			?><td colspan="3"><?=$criteriaColumn['criterion_moc']?></td><?php //JFM 25_11_13
		?></tr><?php
		
		?><tr class="infoRow"><?php
			?><td class="paramDef">Reference</td><?php
			?><td colspan="3"><?php //JFM 11_11_13
			
			$array1=explode(", ",$criteriaColumn['criterion_reference']);
					
			$criteriaColumn['criterion_reference']='';
		
			foreach($array1 as $a1)
			{
				$array2=explode("---",$a1);

				if($array2[1]=='0000-00-00 00:00:01' && $criteriaColumn['criterion_valid_from']=="0000-00-00 00:00:00") continue;
				if($array2[2]=='0000-00-00 00:00:00' && $criteriaColumn['criterion_valid_from']!="0000-00-00 00:00:00") continue;
				if($reviewID[0]['validation_date']=="9999-12-31 00:00:00" && $array2[1]!='0000-00-00 00:00:00'  && $array2[1]!='0000-00-00 00:00:01') continue;
				else 
				{
					if(empty($criteriaColumn['criterion_reference'])) $criteriaColumn['criterion_reference']=$array2[0];
					else $criteriaColumn['criterion_reference']=$criteriaColumn['criterion_reference'].', '.$array2[0];
				}
			}
			
			echo $criteriaColumn['criterion_reference'];
			?></td><?php
		?></tr><?php

		?><tr class="infoRow"><?php
			?><td class="paramDef">Comments</td><?php
			?><td colspan="3"><?=txtBox($criteriaStatus['criteria_comments'],'',62,5)?></td><?php
		?></tr><?php

		?><tr class="infoRow"><?php
			$status=array('r','a','g','x'); // JFM 27_03_14
			$statusImg=($criteriaStatus['criteria_status']=='')?'r':$status[$criteriaStatus['criteria_status']];
			?><td style="width:80px;" class="paramDef">Status</td><?php
			?><td><img src="../common/img/<?=$statusImg?>20.png"></td><?php
		?></tr><?php

		?><tr class="infoRow"><?php
			?><td class="paramDef"nowrap>Focal Point</td><?php
			?><td><?=$criteriaStatus['criteria_focal_point']?></td><?php
		?></tr><?php

	?></table><?php
?></div><?php
storeSession($SESSION);
?>