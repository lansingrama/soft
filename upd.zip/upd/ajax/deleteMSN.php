<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$msnDel=$_GET['msnDel'];
if($SESSION['Level']!=2 && $SESSION['Level']!=3)header("Location: ../security/accExp.php");
$prog=$SESSION['filter']['prog']['n'];
$coe=$SESSION['filter']['coe']['n'];
SqlLQ("DELETE FROM dqrp_msn WHERE MSN='$msnDel' AND prog='$prog' AND coe='$coe'");
SqlLQ("DELETE FROM dqrp_rev WHERE MSN='$msnDel' AND prog='$prog' AND coe='$coe'");
Create_Log('Program: '.$prog.', CoE: '.$coe.', MSN: '.$msnDel,'MSN Deleted','dqrp_log');
$_SESSION['filter']['msn']['n']='';
echo $msnDel;
storeSession($SESSION);
?>