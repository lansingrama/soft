<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../support/mail.php');

$userId=addslashes($_GET['element']);

function drawSpecPerm($title,$object,$array,$right,$SESSION){
	?><tr class="tableGroup prmRow"><?php
		?><td style="width:180px;"><?=$title?></td><td>View</td><td>Edit</td><td>Create</td><td>Delete</td><td>Export</td><td>Upload</td><?php
	?></tr><?php
	foreach($array as $k=>$v){
		drawPermissions($v,$object,$k,1,1,0,0,1,0,$right,$SESSION);
	}
}

$user=SqlQ('SELECT name,surname,confirmed FROM c_user WHERE user_id="'.$userId.'"');
$userName=utf8_encode($user['name'].' '.$user['surname']);

$rightsQry=mysql_query('SELECT object,action,applicability FROM c_permission WHERE user='.$userId.' AND tool='.$SESSION['tool_id'].' AND active=1',$p12) or die(mysql_error());
while($r=mysql_fetch_assoc($rightsQry)){
	$right[$r['object']][$r['action']][$r['applicability']]=1;
}

$area=SqlAsArr('SELECT area_id,area FROM c_area','area_id','area');
$program=SqlAsArr('SELECT program_id,program FROM c_program','program_id','program');
$coe=SqlAsArr('SELECT coe_id,coe FROM c_coe','coe_id','coe');
$perimeter=SqlAsArr('SELECT CONCAT(prg.program," - ",prm.perimeter) as prg_prm,prm.perimeter_id
						FROM c_perimeter AS prm
							INNER JOIN c_program AS prg ON prm.program=prg.program_id
							ORDER BY prg.program','perimeter_id','prg_prm');

$reviewsQry=mysql_query('
	SELECT rp.program,rp.coe,rp.review_profile_id,rt.review_type, rt.area
	FROM dr_review_profile AS rp
		INNER JOIN dr_review_type AS rt ON rp.review_type=rt.review_type_id',$p12) or die(mysql_error());
while($r=mysql_fetch_assoc($reviewsQry)){
	$review[$r['area']][$r['program']][$r['coe']][$r['review_profile_id']]=$r['review_type'];
}

$activePermission=SqlQ('SELECT permission_id FROM c_permission WHERE user="'.$userId.'" AND tool="'.$SESSION['tool_id'].'" AND active=1 LIMIT 1');
$SESSION['edit_user']['active_permission']=($activePermission['permission_id']!='')?1:0;

if($user['confirmed']==1){
	$SESSION['edit_user']['user_invited']=1;
}else{
	$userInvited=SqlQ('SELECT user_invitation_id FROM c_user_invitation WHERE user="'.$userId.'" LIMIT 1');
	$SESSION['edit_user']['user_invited']=($userInvited['user_invitation_id']!='')?1:0;
}

?>OK|||<div class="formHeaderInfo"id="userDetailsTitle"style="clear:left;position:relative;"><?php
	if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 && $user['confirmed']==1){
		?><input class="popUpBtn"onClick="popUpOpt('ttl',['usr','<?=$userId?>','<?=$userName?>']);"type="button"value="&#8801;"><?php
		?><div class="popUpMenu"id="popUpTtlDiv_usr"></div>&nbsp;<?php
	}
	?><div id="userTitle"style="display:inline;vertical-align:middle;"><?php
		echo $userName;
		if($user['confirmed']==0 && $user['name']!='New' && $user['surname']!='User' && $SESSION['edit_user']['user_invited']==1){
			?> (Pending of Confirmation)<?php
		}
	?></div><?php
?></div><?php
?><div class="sp"></div><?php
?><div class="elementDetailsContainer"><?php

//echo $user['confirmed'],'###',$user['name']!='New','###',$user['surname']!='User','###',$SESSION['edit_user']['user_invited'];

if($user['confirmed']==0 && $user['name']!='New' && $user['surname']!='User' && $SESSION['edit_user']['user_invited']==1)
{
	$lastInvitation=SqlLi('SELECT uin.invitation_date,
								CONCAT(u.name," ",u.surname) AS invitation_sender
							FROM c_user_invitation AS uin
								INNER JOIN c_user AS u ON uin.invited_by=u.user_id
							WHERE uin.user="'.$userId.'"
							ORDER BY invitation_date DESC');
	
	$lastInvitation=utf8enc($lastInvitation);
	
	?><input id="permissionUserId"name="user"type="hidden"value="<?=$userId?>"><?php
	
	?><div class="elementDetailsContainer"><?php
		?><div class="elementInfo"><?php
			?><div class="tableTitle">Last invitations sent:</div><?php
				?><table class="criteriaTable"style="width:703px;" cellpadding="0" cellspacing="0"><?php
					?><tr class="tableGroup prmRow"style="text-align:center;"><td style="width:351px;">Invitation sent on</td><td style="width:351px;">Sent by</td></tr><?php
					if(is_array($lastInvitation)){
						foreach($lastInvitation as $l){
							?><tr class="infoRow"><td><?=$l['invitation_date']?></td><td><?=$l['invitation_sender']?></td></tr><?php
						}
					}else{
						?><tr><td class="emptyTable"colspan="2">No invitations have been registered yet</td></tr><?php
					}
				?></table><?php
		?></div><?php
		?><div class="elementInfo" style="width:703px;"><?php
			?><div class="save"><input class="stdBtn"onClick="sendInvitation(this,'<?=$userId?>');"type="button"value="Send Invitation again"></div><?php
		?></div><?php
	
}
else
{
	include('../usr/userMainDataForm.php');
}
	
$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
if(($userId!=$viewAsUserId || checkPermission('superadmin','superadmin',0,'check',$SESSION)==1) && $SESSION['edit_user']['user_invited']){

	?></div><?php

	if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 || checkPermission('c_user_general','edit',0,'check',$SESSION)==1)
	{
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer" style="z-index:100;"><?php
			?><div class="elementInfo">
				<div class="tableTitle">Copy User Permissions:</div>
					<table class="criteriaTable" style="width:288px;" cellpadding="0" cellspacing="0"><?php
						?><tr class="tableGroup prmRow"><?php
							?><td colspan="2">User</td><?php
						?></tr><?php
						?><tr><?php
							?><form action="#"enctype="multipart/form-data"id="userPermissionCopy"method="post"style="display:inline;"><?php
								?><input id="userId"name="userId"type="hidden"value="<?=$userId?>"><?php
								?><input id="permissionCopy"name="permissionCopy"type="hidden"value="1"><?php
								drawUserField('suggestion_user_permission_copy','user_permission_copy','','','',1);
								?><td><input class="stdBtn"id="applyUserChanges"onClick="sendAjaxForm('userPermissionCopy','ajax/setPermission.php','reloadSideElement',false,'GET');"type="button"value="Submit &#9658;"></td><?php
							?></form><?php
						?></tr><?php
					
					?></table>
			</div><?php
		?></div><?php
	}

	if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo"><?php
				?><div class="tableTitle"style="width:100%;">Chuck Norris Mode:</div><?php
					?><table class="criteriaTable" style="width:288px;" cellpadding="0" cellspacing="0"><?php
						?><tr class="tableGroup prmRow"><?php
							?><td></td><td>Chuck Norris Mode</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:180px;">Chuck Norris Mode</td><?php
							?><td class="chk"><?php
								$disableGrantChuckNorris=($userId!=$viewAsUserId)?0:1;
								drawInteractiveCheck(105,5,0,$right,'prm',0,$disableGrantChuckNorris);
							?></td><?php
						?></tr><?php
					?></table>
			</div><?php
		?></div><?php
	}
	
	if($userId!=$viewAsUserId && $SESSION['edit_user']['user_invited']){
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo"><?php
				?><div class="tableTitle">General Permissions:</div><?php
					?><table class="criteriaTable" style="width:703px;" cellpadding="0" cellspacing="0"><?php
						?><tr class="tableGroup prmRow"style="text-align:center;"><?php
							?><td></td><td>View</td><td>Edit</td><td>Create</td><td>Delete</td><td>Export</td><td>Upload</td><?php
						?></tr><?php
						drawPermissions('Tool',							'c_tool_general',						$SESSION['tool_id'],1,0,0,0,0,0,$right,$SESSION,0,0);
						drawPermissions('Area',							'c_area_general',						0,1,1,1,0,0,0,$right,$SESSION,0,0);						
						drawPermissions('Program',						'c_program_general',					0,1,1,1,0,0,0,$right,$SESSION,0,0);
						drawPermissions('CoE',							'c_coe_general',						0,1,1,1,0,0,0,$right,$SESSION,0,0);
						drawPermissions('Perimeter',					'c_perimeter_general',					0,1,1,1,0,0,0,$right,$SESSION,0,0);
						drawPermissions('MSN',							'c_msn_general',						0,0,1,1,1,0,0,$right,$SESSION,0,0);
						drawPermissions('CA',							'c_ca_general',							0,0,1,1,1,0,0,$right,$SESSION,0,0);
						drawPermissions('Review Profile',				'dr_review_profile_general',			0,1,1,1,1,0,0,$right,$SESSION,0,0);
						drawPermissions('Responsible Configuration',	'dr_responsible_configuration_general',	0,0,1,0,0,0,0,$right,$SESSION,0,0);
						drawPermissions('Log',							'dr_log_general',						0,1,0,0,0,1,0,$right,$SESSION,0,0);
						drawPermissions('User',							'c_user_general',						0,1,1,1,0,0,0,$right,$SESSION,0,0);
						drawPermissions('Company',						'c_company_general',					0,1,1,1,1,0,0,$right,$SESSION,0,0);
						drawPermissions('Department',					'c_department_general',					0,1,1,1,1,0,0,$right,$SESSION,0,0);
						drawPermissions('Continuous Assessment',		'continuous_assessment',				0,0,0,1,0,0,0,$right,$SESSION,0,0);
					?></table><?php
			?></div><?php
		?></div><?php
		
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo">
				<div class="tableTitle">Specific Permissions:</div>
					<table class="criteriaTable" style="width:703px;" cellpadding="0" cellspacing="0"><?php
						drawSpecPerm('Area','area_id',$area,$right,$SESSION);
						drawSpecPerm('Program','program_id',$program,$right,$SESSION);
						drawSpecPerm('CoE','coe_id',$coe,$right,$SESSION);
						drawSpecPerm('Perimeter','perimeter_id',$perimeter,$right,$SESSION);
					?></table>
			</div><?php
		?></div><?php
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo"><?php
				?><div class="tableTitle">Review Specific Permissions:</div><?php
				?><table id="reviewSpecificPermissionsTable" class="criteriaTable"style="width:703px;" cellpadding="0" cellspacing="0"><?php
					foreach($review as $areaId=>$a)
					{
						foreach($a as $programId=>$r)
						{
							foreach($r as $coeId=>$c)
							{
								if(empty($coe[$coeId])) continue;
								$rowId=$programId.'_'.$coeId;
								?><tr class="tableGroup prmRow" onclick="expandGraphTableReview('reviewSpecificPermissionsTable','<?=$rowId?>');"><?php
									?><td style="width:180px;"><?=$area[$areaId]?><br /><?=$program[$programId]?><br /><?=$coe[$coeId]?></td><?php
									?><td>View</td><td>Edit</td><td>Create</td><td>Delete</td><td>Export</td><td>Upload</td><?php
								?></tr><?php
								foreach($c as $reviewId=>$reviewName)
								{
									drawPermissions($reviewName,'review_profile_id',$reviewId,1,1,1,1,1,1,$right,$SESSION,$userId,1,$rowId);
								}
							}
						}
					}
			?></table><?php
		?></div><?php
		?><div class="sp"></div><?php
	}
}
?><div style="position:relative;height:150px;"></div><?php
storeSession($SESSION);

?>