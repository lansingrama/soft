<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);
$program=getFilter('program','filter',0,$SESSION);

///$responsibles=getResponsibles($GET['element'],$SESSION);
//print_r($responsibles);


//JFM 19_07_16
$perimetersAllowed=allowedSimpleObject('perimeter','perimeter',$SESSION,'c_');

//JFM 19_07_16
$reviewType = SqlQ('SELECT review_type_id 
					FROM dr_review_type AS rt
					INNER JOIN dr_review_profile AS rp ON rp.review_type = rt.review_type_id
					INNER JOIN dr_review AS r ON r.review_profile = rp.review_profile_id
					WHERE r.review_id = '.$GET['element']);

//JFM 19_07_16
$caName=SqlLi('SELECT DISTINCT ca.ca_id, ca.ca, coe.coe, pro.program, msn.msn, rt.review_type_id, r.review_id, rt.review_type, per.perimeter, wp.wp
					FROM c_ca AS ca
						INNER JOIN dr_review_applicability 	AS 	ra 	ON 	ra.ca				=	ca.ca_id
						INNER JOIN dr_review				AS	r	ON 	r.review_id			=	ra.review
						INNER JOIN dr_review_profile		AS	rp	ON	rp.review_profile_id=	r.review_profile
						INNER JOIN dr_review_type 			AS  rt 	ON  rt.review_type_id   =   rp.review_type
						INNER JOIN c_coe 					AS  coe ON  coe.coe_id 			= 	rp.coe
						INNER JOIN c_program 				AS 	pro ON 	pro.program_id 		= 	rp.program
						INNER JOIN c_msn 					AS 	msn ON 	msn.msn_id  		= 	r.msn
						INNER JOIN dr_responsible 			AS  rs	ON  rs.review 			=   r.review_id
						INNER JOIN c_perimeter 				AS  per ON  per.perimeter_id 	=   ca.perimeter
						INNER JOIN c_cawp 					AS  caw ON  caw.ca				=   ca.ca_id
						INNER JOIN c_wp 					AS  wp  ON  wp.wp_id 			= 	caw.wp
					WHERE r.validation_complete!=-1
					AND r.review_status!=4
					AND coe.area = '.getFilter('area','filter',0,$SESSION).'
					AND pro.area = '.getFilter('area','filter',0,$SESSION).'
					AND r.review_id != '.$GET['element'].'
					AND ca.perimeter IN ("'.implode('","', array_keys($perimetersAllowed)).'")
					ORDER BY pro.program, coe.coe, msn.msn, ca.ca ASC');

$editableCa=0;
 /**
    US #058
    Role Management - Edit
    Fixed By - Infosys Limited
    Version - 2
*/
$currentArea = getFilter('area','filter',0,$SESSION);
$responsibles=getResponsibles($GET['element'],$SESSION);
$role_sql = SqlLi('SELECT role.responsible_role_id as rid, role.responsible_role as role FROM dr_role_assigned_area as ass_role JOIN dr_responsible_role as role ON ass_role.responsible_role_id = role.responsible_role_id WHERE area = '.$currentArea);
/* End for US #058*/

 /**
    US #19.1 - Change Workflow
	Bug fix for View/Edit responsible button should be enabled
    Fixed By - Infosys Limited
    Version - 4.3
*/
if(!empty($GET['reviewCa']) && !empty($GET['reviewProfile']) && $GET['reviewCa'] != "" && $GET['reviewProfile'] != "")
{
	$responsibles=SqlLi('SELECT r.*, rr.*
							FROM responsible AS r
							INNER JOIN dr_responsible_role AS rr ON rr.responsible_role_id=r.role
							WHERE r.review='.$GET['reviewProfile'].' AND r.ca='.$GET['reviewCa'].'
							ORDER BY position ASC');
	$attendees=SqlLi('SELECT *
				FROM attendee AS ra
				WHERE review='.$GET['reviewProfile'].' AND ca='.$GET['reviewCa'].'');
}
else
{
	$responsibles=getResponsibles($GET['element'],$SESSION);
	$attendees=SqlLi('SELECT *
				FROM dr_responsible_attendee AS ra
				WHERE review ='.$GET['element']);
}
/* End for US #19.1*/
if(checkPermission('dr_responsible_configuration_general','edit',0,'check',$SESSION)==1) $editableCa=1;

?>OK|||<div class="formStdContainer"><?php
	?><div class="formHeader"><?php
		?><div class="formHeaderInfo">CA Responsibles</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="leftInfoBox" style="width:840px; margin-top:70px;"><?php
		/*?><div class="tableTitle">Responsibles:</div><?php*/
		?><form action="#" enctype="multipart/form-data" id="responsibleFrm" method="post" style="display:inline;"><?php
			?><input id="reviewId" name="reviewId" type="hidden" value="<?=$GET['element']?>"><?php	
			?><input id="reviewProfile" name="reviewProfile" type="hidden" value="<?=$GET['reviewProfile']?>"><?php
			?><input id="reviewCa" name="reviewCa" type="hidden" value="<?=$GET['reviewCa']?>"><?php
			?><input type="hidden" id="resArr" value="<?php echo htmlspecialchars(json_encode($responsibles)) ?>"><?php
			?><div><span id="checkRoleResponse" style="display:none;font-size: 12px;color: red;">Role and Responsible already exists.<span></div><?php
			if($editableCa==1)
			{
				?><div class="save"><span class="saveResponse"id="responsible_saveResponse">Changes were applied</span><input class="stdBtn"onClick="sendAjaxForm('responsibleFrm','ajax/saveResponsible.php','updateData','responsible_saveResponse');closeLastForm();" type="button"value="Apply Changes &#9658;"></div><?php
			}			
			?><table class="criteriaTable" id="responsibleTable" cellpadding="5" cellspacing="0"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="5">Review Panel</td><?php
				?></tr><?php
				?><tr class="tableGroup"><?php
					?><td>Role</td><?php
					?><td>Responsible</td><?php
					?><td>Add Row Below</td><?php
					?><td>Remove Row</td><?php
/**
    US #058
    User Management - Edit
    Fixed By - Infosys Limited
    Version - 2
*/
					if (!empty($responsibles)) {
                    ?><td>Edit Row</td><?php
                    }
/* End for US #058 */					
				?></tr><?php
				$i=0;
				if(!empty($responsibles))
				{
					foreach($responsibles as $responsible)
					{
						?><tr id="rowResponsible<?=$i?>"><?php
							?><td width="35%" height="18px;" valign="top"><?php
								/*?><div class="suggestion"id="roledivID<?=$i?>"style="width:159px;"></div><?php
								?><input <?php if(!$editableCa) echo 'disabled'; ?> class="textareaWhite" id="roleinputID<?=$i?>"name="roleinputID<?=$i?>" value="<?=utf8_encode($responsible['responsible_role'])?>" onFocus="loadUserSuggestion(this,'roledivID<?=$i?>','roleinputID<?=$i?>','','rolesuggestionID<?=$i?>','role');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php*/
								//US #058User Management - Edit
								?><input <?php if(!$editableCa) echo 'disabled'; ?> disabled="true" class="textareaWhite" id="roleinputID<?=$i?>"name="roleinputID<?=$i?>" value="<?=utf8_encode($responsible['responsible_role'])?>" size="28"type="text"><?php
							?></td><?php
							?><td width="35%" height="18px;" valign="top"><?php
								/*?><div class="suggestion"id="responsibledivID<?=$i?>"style="width:159px;"></div><?php
								?><input <?php if(!$editableCa) echo 'disabled'; ?> class="textareaWhite" id="responsibleinputID<?=$i?>"name="responsibleinputID<?=$i?>" value="<?=utf8_encode($responsible['responsible'])?>" onFocus="loadUserSuggestion(this,'responsibledivID<?=$i?>','responsibleinputID<?=$i?>','','responsiblesuggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php*/
								//US #058User Management - Edit
								?><input <?php if(!$editableCa) echo 'disabled'; ?> disabled="true" class="textareaWhite" id="responsibleinputID<?=$i?>"name="responsibleinputID<?=$i?>" value="<?=utf8_encode($responsible['responsible'])?>" size="28"type="text"><?php
							?></td><?php
							?><td style="text-align:center;"><?php
								?><input class="xRemove" style="font-size:18px;" onClick="sendRolesArr(<?php echo htmlspecialchars(json_encode($role_sql))?>);createRowWithNameSuggestionForResponsibles(this);" type="button" value="&#8626;"/><?php
							?></td><?php
							?><td style="text-align:center;"><?php
								?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
							?></td><?php
							//US #058User Management - Edit
							?><td style="text-align:center;"><?php
								?><input class="xRemove" onClick="closeLastForm();openForm('../ajax/editRole','element=<?=$GET['element']?>&role=<?=utf8_encode($responsible['responsible_role'])?>&resposible=<?=utf8_encode($responsible['responsible'])?>&rid=<?=utf8_encode($responsible['responsible_id'])?>&edit=<?=$i?>&reviewProfile=<?=$GET['reviewProfile']?>&reviewCa=<?=$GET['reviewCa']?>',false,'GET');" type="button" value="Edit"/><?php
							?></td><?php
						?></tr><?php
						$i++;
					}
				}

				?><tr id="rowResponsible<?=$i?>"><?php
					?><td width="35%" height="18px;" valign="top"><?php
						/*?><div class="suggestion"id="roledivID<?=$i?>"style="width:159px;"></div><?php
						?><input <?php if(!$editableCa) echo 'disabled'; ?> class="textareaWhite" id="roleinputID<?=$i?>"name="roleinputID<?=$i?>" onFocus="loadUserSuggestion(this,'roledivID<?=$i?>','roleinputID<?=$i?>','','rolesuggestionID<?=$i?>','role');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php*/
						//US #058User Management - Edit
						?><select id="roleinputID<?=$i?>" name="roleinputID<?=$i?>" class="showRole" style="min-width: 100%;"><?php   
                                ?><option value=""></option><?php               
                                    foreach($role_sql as $row){?>
                                        <option><?php echo $row['role']; ?></option>
                                <?php }
                        ?></select><?php
					?></td><?php
					?><td width="35%" height="18px;" valign="top"><?php
						?><div class="suggestion"id="responsibledivID<?=$i?>"style="width:159px;"></div><?php
						?><input <?php if(!$editableCa) echo 'disabled'; ?> class="textareaWhite" id="responsibleinputID<?=$i?>"name="responsibleinputID<?=$i?>" onFocus="loadUserSuggestion(this,'responsibledivID<?=$i?>','responsibleinputID<?=$i?>','','responsiblesuggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
					?></td><?php
					?><td style="text-align:center;"><?php
						?><input class="xRemove" style="font-size:18px;" onClick="sendRolesArr(<?php echo htmlspecialchars(json_encode($role_sql))?>);createRowWithNameSuggestionForResponsibles(this);" type="button" value="&#8626;"/><?php
					?></td><?php
					?><td style="text-align:center;"><?php
						?><input class="xRemove" onClick="this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);" type="button" value="&#10008;"/><?php
					?></td><?php
				?></tr><?php
				
			?></table><?php


			//-------------------------------------------------------------------------------------


			?><br /><?php
			?><table class="criteriaTable" id="attendeeTable" align="left" cellspacing="0" width="250px;"><?php
				?><tr class="tableGroup"><?php
					?><td>Attendees</td><?php
				?></tr><?php
				
					$i=0;
					if(!empty($attendees))
					{
						foreach($attendees as $attendee)
						{
							?><tr id="rowelephantTigerBeehiveinputID<?=$i?>"><?php
								?><td valign="top"><?php
									?><div class="suggestion"id="divID<?=$i?>"style="width:159px;"></div><?php
									?><input <?php if(!$editableCa) echo 'disabled'; ?>  class="textareaWhite" id="elephantTigerBeehiveinputID<?=$i?>"name="elephantTigerBeehiveinputID<?=$i?>" value="<?=utf8_encode($attendee['responsible_attendee'])?>" onKeyDown="removeOrCreateNameSuggestion(this,'attendeeTable','divID','elephantTigerBeehiveinputID','suggestionID');" onFocus="loadUserSuggestion(this,'divID<?=$i?>','elephantTigerBeehiveinputID<?=$i?>','','suggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
									
									if($editableCa)
									{
										?><input class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehiveinputID<?=$i?>','attendeeTable');" type="button" value="&#10008;"/><?php
									}
								?></td><?php
							?></tr><?php
							$i++;
						}
					}
				
				if($editableCa)
				{
					?><tr id="rowelephantTigerBeehiveinputID<?=$i?>"><?php
						?><td width="35%" valign="top"><?php
							?><div class="suggestion"id="divID<?=$i?>"style="width:159px;"></div><?php
							?><input class="textareaWhite" id="elephantTigerBeehiveinputID<?=$i?>"name="elephantTigerBeehiveinputID<?=$i?>" onKeyDown="removeOrCreateNameSuggestion(this,'attendeeTable','divID','elephantTigerBeehiveinputID','suggestionID');" onFocus="loadUserSuggestion(this,'divID<?=$i?>','elephantTigerBeehiveinputID<?=$i?>','','suggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
							?><input class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehiveinputID<?=$i?>','attendeeTable');" type="button" value="&#10008;"/><?php
						?></td><?php
					?></tr><?php
				}

			?></table><?php

			//JFM 19_07_16
			if(!empty($caName))
			{
				?><div style="clear:both; float:left; margin-top:30px; text-align:left;">Import Responsibles From:<br /><select id="caInfoBox" name="caInfoBox" style="width:auto;"><?php

					?><option value=""></option><?php

					foreach($caName as $oneCaName)
					{
						?><option value="<?=$oneCaName['review_id']?>"><?=$oneCaName['program']?> - <?=$oneCaName['coe']?> - <?=$oneCaName['msn']?> - <?=$oneCaName['perimeter']?> - <?=$oneCaName['wp']?> - <?=$oneCaName['ca']?> - <?=$oneCaName['review_type']?></option><?php
					}
					
				?></select></div><?php
			}

		?></form><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>