<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/mail.php');

$GET=cleanArray($_GET);

if($GET['permissionCopy'])
{
	$nameSplit=explode(", ",$GET['user_permission_copy']);

	$userPermissionsQry=SqlLi('SELECT user, tool, object, action, applicability
								FROM c_permission AS per
								WHERE user=(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'")
								AND active=1');

	$currentPermissionsQry=SqlLi('SELECT user, tool, object, action, applicability
								FROM c_permission AS per
								WHERE user='.$GET['userId'].'
								AND active=1');

	if(!empty($userPermissionsQry))
	{
		foreach($userPermissionsQry as $userPermission)
		{
			$found=false;

			if(!empty($currentPermissionsQry))
			{
				foreach($currentPermissionsQry as $currentPermission)
				{
					if($currentPermission['tool']==$userPermission['tool'] && $currentPermission['object']==$userPermission['object'] && $currentPermission['action']==$userPermission['action'] && $currentPermission['applicability']==$userPermission['applicability'])
					{
						$found=true;
						break;
					}
				}
			}

			if(!$found && $SESSION['permission'][$userPermission['object']][$userPermission['action']][$userPermission['applicability']]!=1) 
			{
				if(checkPermission('superadmin','superadmin',0,'check',$SESSION)!=1) $found=true;
			}

			if(!$found) SqlLQ('INSERT INTO c_permission (user, tool, object, action, applicability, active) VALUES ('.$GET['userId'].','.$userPermission['tool'].','.$userPermission['object'].','.$userPermission['action'].','.$userPermission['applicability'].',1)');
		}
	}

	echo 'OK|||';
}
else
{
	$location=split('-',$GET['location']);
	/*
		US109-General Information not editable by supplier
		For showing alert to user
		Fixed By - Infosys Limited
		Version: V 4.5
	*/
	$utype = SqlQ('SELECT type FROM c_user WHERE user_id = '.$GET['user']);
	$rsp = SqlQ('SELECT object_id  FROM c_object WHERE object = "review_profile_id"');
	
	if ($utype['type'] == 1 && $rsp['object_id'] == $location[1]) {
		if ($GET['value'] == 1 && ($location[2] == 2 || $location[2] == 3 || $location[2] == 4)) {
			echo 'OK|||showalert';
			exit;
		}
		
	}  
	/* End for US109 */

	setPermission($SESSION['tool_id'],$GET['user'],$location[1],$location[2],$location[3],$GET['value'],$SESSION);

	//if($GET['value']==1 && $SESSION['edit_user']['active_permission']==0) $SESSION['edit_user']['active_permission']=1;

	//$userWasInvited=($SESSION['edit_user']['user_invited']==0)?0:1;

	//JFM 16_01_15 checkSendInvitation($GET['user'],$SESSION);

	echo 'OK|||',$location[1],'-',$location[2],'-',$location[3];

	if($SESSION['edit_user']['user_invited']==1 && $userWasInvited==0) echo '&&&reloadSideElementNeeded';
}

storeSession($SESSION);
?>