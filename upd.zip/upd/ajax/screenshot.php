<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

$screenshot=SqlQ('SELECT change_image_file,change_screenshot_creation,change_screenshot_created_by,change_screenshot_description
					FROM dr_change_screenshot
					WHERE change_screenshot_id="'.$GET['element'].'"');

$screenshot=utf8Enc($screenshot);

$imageProperty=getimagesize('../img/changeScreenshot/'.$screenshot['change_image_file']);

$imageWidth=($imageProperty[0]>716)?716:$imageProperty[0];

?>OK|||<?php
/*?><div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;"><?php
	echo 'Screenshot';
?></div><?php*/
?><div style="position:relative;height:50px;"></div><?php

?><div class="elementDetailsContainer"><?php
	?><div class="elementInfo"><?php
		?><div class="tableTitle"style="width:716px;"><?=utf8_encode($SESSION['user_list'][$screenshot['change_screenshot_created_by']])?> on <?=$screenshot['change_screenshot_creation']?>:</div><?php
		?><div style="position:relative;height:75px;"></div><?php
		?><div style="width:716px;"><?=$screenshot['change_screenshot_description']?></div><?php
		?><div style="position:relative;height:75px;"></div><?php
		?><div><img src="img/changeScreenshot/<?=$screenshot['change_image_file']?>"width="<?=$imageWidth?>"></div><?php
	?></div><?php
?></div><?php

?><div style="position:relative;height:150px;"></div><?php
storeSession($SESSION);

?>