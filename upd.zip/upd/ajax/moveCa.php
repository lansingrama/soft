<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
$pathLevel=2;
require_once('../support/localSupport.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
if(checkPermission('c_ca_general','edit',0,'check',$SESSION)==1){
	SqlLQ('UPDATE c_cawp SET wp='.$GET['wp_id'].' WHERE cawp_id='.$GET['cawp']);
	echo 'OK|||1';
}else{
	echo 'OK|||no_rights';
}
storeSession($SESSION);
?>