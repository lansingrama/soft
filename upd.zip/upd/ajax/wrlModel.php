<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST);
$reviewTypesSession=getFilter('review_type_filter','filter',0,$SESSION);

if(!getFilter('area','filter',0,$SESSION) || !getFilter('program','filter',0,$SESSION) || !getFilter('msn','filter',0,$SESSION) || !getFilter('coe','filter',0,$SESSION))
{
	?>OK|||no_program_coe_msn<?php
}
else
{
	/*$reviewInfo=SqlLi('SELECT r.review_status, ca.ca
						FROM dr_review AS r
							INNER JOIN dr_review_applicability	AS ra ON ra.review=r.review_id
							INNER JOIN c_ca 					AS ca ON ca.ca_id=ra.ca
							INNER JOIN c_program 				AS pg ON pg.program_id=ca.program
							INNER JOIN dr_review_profile 		AS rp ON rp.review_profile_id=r.review_profile
																	  AND rp.program=pg.program_id
							INNER JOIN dr_review_type 			AS rt ON rt.review_type_id=rp.review_type
						WHERE pg.program_id='.getFilter('program','filter',0,$SESSION).'
						AND   pg.area='.getFilter('area','filter',0,$SESSION).'
						AND   r.msn='.getFilter('msn','filter',0,$SESSION).'
						AND   rt.review_type="CDR"');

	$color=array(	0 => '[0.9372549019607843,0.2039215686274510,0.2470588235294118]', 
					1 => '[0.9725490196078431,0.8431372549019608,0.0274509803921569]', 
					2 => '[0.5058823529411765,0.7647058823529412,0.2549019607843137]');

	$file_data			='';
	$trailingEdgeColor	='[0.800000,0.800000,0.898039];';
	$midboxColor		='[0.800000,0.800000,0.898039];';
	$leadingEdgeColor	='[0.800000,0.800000,0.898039];';

	if(is_file('../output/3dviewA350900.js')) unlink('../output/3dviewA350900.js');

	foreach($reviewInfo as $key=>$value)
	{
		$foundTrailingEdge=strpos($value['ca'], 'Trailing Edge');
		$foundMidbox=strpos($value['ca'],'Midbo');
		if($foundMidbox===false) $foundMidbox=strpos($value['ca'],'Top Covers');
		$foundLeadingEdge=strpos($value['ca'],'Leading Edge');

		if($foundTrailingEdge!==false)
		{
			$trailingEdgeColor=$color[$value['review_status']];
		}
		if($foundMidbox!==false)
		{
			$midboxColor=$color[$value['review_status']];
		}
		if($foundLeadingEdge!==false)
		{
			$leadingEdgeColor=$color[$value['review_status']];
		}
	}

	if(!empty($trailingEdgeColor)) $file_data .= "var trailingEdgeArray=".$trailingEdgeColor.";\n\n";
	if(!empty($midboxColor)) $file_data .= "var midboxArray=".$midboxColor.";\n\n";
	if(!empty($leadingEdgeColor)) $file_data .= "var leadingEdgeArray=".$leadingEdgeColor.";\n\n";
	$file_data .= file_get_contents('../js/3dview.js');
	file_put_contents('../output/3dviewA350900.js', $file_data);*/

	?>OK|||trl&&&<?php

	?><div id="3dxmlContainerDisplay" onclick="load3dxml();">Show 3dxml</div><?php
	?><div id="3dxmlContainer"></div><?php
	?><textarea align="left" class="textarea" id="3dxmlTrace" name="3dxmlTrace" rows="5"></textarea><?php


	/*?><object classid="CLSID:86A88967-7A20-11d2-8EDA-00600818EDB1" width="1000px" height="500px" style="z-index:1;" id="objectThis"><?php
		?>To view this model you need <b>Cortona3D</b> Installed. It is available to download via PC Services.<?php
		?><param name="Scene" value="archive/A350-900_no_shiny.wrz"><?php
	?></object><?php*/
/*	?><object width="630" height="450" data="archive/A350-900_no_shiny.pdf#toolbar=0&scrollbar=0&navpanes=0&statusbar=0" type="application/pdf"/><?php
*/
/*	?><input id="mainTableCacheId"type="hidden"value="<?=$tableCacheId?>"><?php
*/}
storeSession($SESSION);

?>