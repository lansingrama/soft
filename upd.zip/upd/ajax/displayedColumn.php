<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);

$_o_=$SESSION['object'];
$hide=$SESSION['user_action']['hide'];
$filter=$SESSION['filter'];

echo 'OK|||';

switch($GET['element']){
	case'ca':
		?><div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;">Displayed CA Description Columns</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable" style="width:227px;" cellspacing="0" cellpadding="5">
				<tr class="tableGroup prmRow">
					<td style="width:150px;">Column</td><td>Displayed</td>
				</tr><?php
        $check = checkExternal($SESSION);
				foreach($SESSION['table']['review_planning']['ca'] as $columnName=>$columnDetails){
					if($columnName!='ca' && $columnName!='wp'){
          if($check!=1){
						drawSimpleCheck($_o_[$columnName],$hide,0,$filter,'cfc',1,$columnDetails['title']); //JFM 13_05_16
					}
          else
                                                {
                                                    if($columnName!='progress_trend' && $columnName!='risk_red' && $columnName!='risk_amber' && $columnName!='risk_green' && $columnName!='risk_blue' )
                                                        drawSimpleCheck($_o_[$columnName],$hide,0,$filter,'cfc',1,$columnDetails['title']);
                                                }
                                        }
				}
			?></table><?php
		?></div><?php
	break;
	case'review':
                $reviewclick = $GET['element'];
                // Added Hidden flag to show the reviews based on Review type visibility - US#110 (Possibility to delete Review type, L1, L2 and L3
		if(checkPermission('dr_review_profile_general','view',0,'check',$SESSION)==1)
		{
			$reviewProfileList=SqlAsArr('SELECT review_profile_id,review_type FROM dr_review_profile WHERE program="'.$GET['program'].'" AND coe="'.$GET['coe'].'" AND rp_hidden=0 ORDER BY review_profile_order ASC','review_profile_id','review_type');
		}
		else
		{
			$reviewProfileList=allowedSimpleObject('review_profile','review_type',$SESSION,'dr_','program='.$GET['program'].' AND coe='.$GET['coe'].' AND rp_hidden=0');
		}
		if(is_array($reviewProfileList))
		{
			foreach($reviewProfileList as $reviewId=>&$reviewType) $allReviewIds[]=$reviewId; //JFM 25_11_13
			?><div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;">Displayed Reviews Columns</div><?php
			?><div style="position:relative;height:50px;"></div><?php
			?><div class="elementDetailsContainer"><?php
				?><table class="criteriaTable" id="reviewTableId" cellspacing="0" cellpadding="5"><?php
					?><tr class="tableGroup"><?php
						?><td nowrap rowspan="2"><?php //JFM 25_11_13
							?><span style="cursor:pointer;" onClick="checkGroup('cfc',this,1,[<?=implode(',',$allReviewIds)?>],1)">Check All &#9658;<br /><br /></span><?php //JFM 15_09_15
							?><span style="cursor:pointer;" onClick="checkGroup('cfc',this,0,[<?=implode(',',$allReviewIds)?>],1)">Uncheck All &#9658;</span><?php
						?></td><?php
						?><td rowspan="2">Review</td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Initial Review Status');" rowspan="2">Initial<br />Stat.</td><?php //JFM 13_05_16
						?><td onMouseOut="nd();" onMouseOver="overlib('Review Status');" rowspan="2">Stat.</td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Review Planned Date');" rowspan="2">Pl.</td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Review Date');" rowspan="2">Date</td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Review Planned Delta');" rowspan="2">Pl. Delta</td><?php //JFM 08_06_16
						?><td onMouseOut="nd();" onMouseOver="overlib('Review Delta');" rowspan="2">Delta</td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Review Remarks');" rowspan="2">Rem.</td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Review Link');" rowspan="2">Link</td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of RIDs in red, amber and green for this Review');" colspan="4">RIDs</td><?php //JFM 27_03_14
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of Actions in red, amber and green for this Review');" colspan="4">Actions</td><?php //JFM 27_03_14
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of RIDs in red for this Review');"><img src="../common/img/r20.png"></td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of RIDs in amber for this Review');"><img src="../common/img/a20.png"></td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of RIDs in green for this Review');"><img src="../common/img/g20.png"></td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of RIDs in blue for this Review');"><img src="../common/img/x20.png"></td><?php//JFM 27_03_14
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of Actions in red for this Review');"><img src="../common/img/r20.png"></td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of Actions in amber for this Review');"><img src="../common/img/a20.png"></td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of Actions in green for this Review');"><img src="../common/img/g20.png"></td><?php
						?><td onMouseOut="nd();" onMouseOver="overlib('Amount of Actions in blue for this Review');"><img src="../common/img/x20.png"></td><?php//JFM 27_03_14
					?></tr><?php

					//JFM 19_07_16
                                        /**
                                         * Fix for: Bug-10
                                         * Check/Uncheck hide columns
                                         * Version: 4.2
                                         * Fixed By: Infosys Limited
                                         */
					?><tr class="tableGroup"><td></td><td></td><?php
						foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
						{
							if($columnName!='criteria_status') 
							{
								?><td onClick="<?php
									foreach($reviewProfileList as $reviewId=>&$reviewType)
									{
										$something = 'cfc-'.$_o_[$columnName].'-'.$hide.'-'.$reviewId;
										?>checkReview('<?=$something?>','cfc',1);<?php
									}
								?>">Check Column &#9658;</td><?php
							}
						}
					?></tr><?php
                                        // Added button to uncheck the column
                                        ?><tr class="tableGroup"><td></td><td></td><?php
						foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
						{
							if($columnName!='criteria_status') 
							{
								?><td onClick="<?php
									foreach($reviewProfileList as $reviewId=>&$reviewType)
									{
										$something = 'cfc-'.$_o_[$columnName].'-'.$hide.'-'.$reviewId;
										?>checkReview('<?=$something?>','cfc',0);<?php
									}
								?>">Uncheck Column &#9658;</td><?php
							}
						}
					?></tr><?php
                                        // End of Bug-10
                                        foreach($reviewProfileList as $reviewId=>&$reviewType)
					{
						?><tr class="infoRow"><?php
							?><td nowrap class="paramDef"><?php
                                                                ?><span style="cursor:pointer;" onClick="checkGroup('cfc',this,1,[<?=$reviewId?>],0)">Check Row &#9658;<br /></span><?php //JFM 15_09_15
								?><span style="cursor:pointer;" onClick="checkGroup('cfc',this,0,[<?=$reviewId?>],0)">Uncheck Row &#9658;</span><?php
							?></td><?php 
                                  
							?><td class="paramDef"><?=$SESSION['review_type'][$reviewId]?></td><?php
                  
							foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails){
								//JFM 27_03_14
								if($columnName!='criteria_status') {
   
                                                                    /*?><td class="chk"><?php drawInteractiveCheck($_o_[$columnName],$hide,$reviewId,$filter,'cfc',1,$reviewclick);?></td><?php*/
                                                                    ?><td class="chk"><?php drawInteractiveCheck($_o_[$columnName],$hide,$reviewId,$filter,'cfc',1,$reviewclick);?></td><?php
                                                                }
							}
						?></tr><?php
					}
                                        /**
                                         * Bug-11 Added Button to save the changes
                                         */
                                        ?><tr><td>
                                                <input class="stdBtn" id="applyUserChanges" name="applychanges" onclick="saveChanges('<?=$reviewclick?>')" type="button" value="Apply Changes ►" />
                                        </td></tr><?php   
                                        //End of Bug 11
				?></table><?php
			?></div><?php

		}else{?><div class="sideContainerEmpty" style="color:#000000;">No available Reviews</div><?php }
	break;
	case'action':
		?><div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;">Displayed Action Tracking Columns</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable" style="width:248px;" cellspacing="0" cellpadding="5">
				<tr class="tableGroup prmRow">
					<td style="width:150px;">Column</td><td>Displayed</td>
				</tr><?php
				foreach($SESSION['table']['action']['action'] as $columnName=>$columnDetails){
					drawSimpleCheck($_o_[$columnName],$hide,0,$filter,'cfc',1,$columnDetails['filter']);
				}
			?></table><?php
		?></div><?php
	break;	
	case'rid':
		?><div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;">Displayed Action Tracking Columns</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable" style="width:248px;" cellspacing="0" cellpadding="5">
				<tr class="tableGroup prmRow">
					<td style="width:150px;">Column</td><td>Displayed</td>
				</tr><?php
				foreach($SESSION['table']['rid']['rid'] as $columnName=>$columnDetails){
					drawSimpleCheck($_o_[$columnName],$hide,0,$filter,'cfc',1,$columnDetails['filter']);
				}
			?></table><?php
		?></div><?php
	break;
	case'cat': //JFM 02_12_13
		?><div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;">Displayed Criteria List Columns</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable" style="width:248px;" cellspacing="0" cellpadding="5">
				<tr class="tableGroup prmRow">
					<td style="width:150px;">Column</td><td>Displayed</td>
				</tr><?php
				foreach($SESSION['table']['cat']['cat'] as $columnName=>$columnDetails){
					drawSimpleCheck($_o_[$columnName],$hide,0,$filter,'cfc',1,$columnDetails['title']); //JFM 13_05_16
				}
			?></table><?php
		?></div><?php
	break;	
	case'evd': //JFM 28_04_14
		?><div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;">Displayed Evidence List Columns</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable" style="width:248px;" cellspacing="0" cellpadding="5">
				<tr class="tableGroup prmRow">
					<td style="width:150px;">Column</td><td>Displayed</td>
				</tr><?php
				foreach($SESSION['table']['evd']['evd'] as $columnName=>$columnDetails){
					drawSimpleCheck($_o_[$columnName],$hide,0,$filter,'cfc',1,$columnDetails['filter']);
				}
			?></table><?php
		?></div><?php
	break;	
}
storeSession($SESSION);
?>