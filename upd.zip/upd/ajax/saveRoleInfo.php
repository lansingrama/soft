<?php
require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$POST=cleanArray($_POST);
$getAreas = $POST['screen'];
$values = explode(',', $getAreas);
$roleQry= mysql_query('SELECT count(*) FROM dr_responsible_role WHERE responsible_role="'.$POST['roleName'].'"');
			 $countQry=mysql_result($roleQry, 0);
if(is_numeric($POST['responsible_role_id']))
{
	$getAreas = $POST['screen'];
	$editGetAreas = $POST['screen_value'];
	$getAreas = explode(',',$getAreas);
	$editGetAreas = explode(',',$editGetAreas);
	$getAreas_data = array_unique(array_merge($getAreas,$editGetAreas), SORT_REGULAR);
	 	 SqlLQ('DELETE FROM dr_role_assigned_area WHERE responsible_role_id ="'.$POST['responsible_role_id'].'"');
			 SqlLQ('UPDATE dr_responsible_role SET responsible_role ="'.$POST['roleName'].'" WHERE responsible_role_id ="'.$POST['responsible_role_id'].'"');
		 		foreach($getAreas_data as $value){		
				SqlLQ('INSERT INTO dr_role_assigned_area (responsible_role_id,area) VALUES ("'.$POST['responsible_role_id'].'","'.$value.'")');
			}

}
else 
{
	/*
	* For Role name Validation
	*/
	 if (isset($POST['roleName']) && !empty($POST['roleName'])) {

			  SqlLQ('INSERT INTO dr_responsible_role(responsible_role) VALUES ("'.$POST['roleName'].'")');
			  $last_id = mysql_insert_id();
			
						foreach($values as $value){		
							SqlLQ('INSERT INTO dr_role_assigned_area (responsible_role_id,area) VALUES ("'.$last_id.'","'.$value.'")');
						}
				
				
	}
}
echo 'OK|||',$roleQry;
?>
