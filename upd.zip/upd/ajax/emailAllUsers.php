<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/mail.php');

$POST=cleanArray($_POST);

$email=SqlSLi('SELECT DISTINCT u.email FROM c_user AS u
					INNER JOIN c_permission AS pms ON u.user_id=pms.user
					WHERE u.email!=""
						AND u.confirmed=1
						AND pms.tool="'.$SESSION['tool_id'].'"
						AND (
							(
								pms.object="'.$SESSION['object']['c_tool_general'].'"
								AND pms.action="'.$SESSION['user_action']['view'].'"
							)
							OR (
								pms.object="'.$SESSION['object']['superadmin'].'"
								AND pms.action="'.$SESSION['user_action']['superadmin'].'"
							)
						)
						AND pms.active=1','email');


$parsedSubject=parseText($POST['subject']);

$subject='Airbus Review Tool - Message from the Administrators: '.$parsedSubject;

$message=mailMessageBox('Message from the Administrators',$parsedSubject,parseText($POST['message']));

if(is_array($email)){
	mail('',$subject,$message,mailHeader('',implode(',',$email)));
	
	?>OK|||The message has been sent to <?=count($email)?> users<?php
}else{
	?>OK|||error|||Invalid Email list<?php
}
storeSession($SESSION);
?>