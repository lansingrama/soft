<?php
if($included!=1)
{
	require_once('../support/header.php');
	require_once('../security/checkExpiredSession.php');
	require_once('../../support.php');
	require_once('../support/form.php');
	require_once('../support/localSupport.php');
	$GET = cleanArray($_GET);	
	$currentArea = getFilter('area','filter',0,$SESSION);
	$areaList=allowedSimpleObject('area','area',$SESSION,'c_');
}

$currentColumnTranslations=SqlAsLi('SELECT * FROM dr_column_translation WHERE area = '.$currentArea, 'column_');
$currentDisabledStatuses=$SESSION['disabled_statues'];

$statuses=array('r','a','g','x');
$statusesObjects=array('r' => 0,'a' => 1,'g' => 2,'x' => 3);
$statusTypes=array('InitialReview', 'Review', 'Criteria', 'Action', 'RID', 'Risk');
$statusTypesObjects=array('InitialReview' => 'initial_review_status', 'Review' => 'review_status', 'Criteria' => 'criteria_status', 'Action' => 'action_status', 'RID' => 'rid_status', 'Risk' => 'risk_status');

if($included!=1)
{
	echo 'OK|||';
}

?><div><input class="stdBtn" style="float: left;" onClick="if(checkAreaManagment('<?=$areaList[$currentArea]?>')) {sendAjaxForm('areaFrm','ajax/saveAreaManagement.php','updateData','area_saveResponse'); refreshSession();}" type="button" value="Apply Changes &#9658;"><span class="saveResponse" id="area_saveResponse">Changes were applied</span></div><?php

?><br /><?php

?><form action="#" enctype="multipart/form-data" id="areaFrm" method="post" style="display:inline;"><?php
	?><input id="areaId" name="areaId" type="hidden" value="<?=$currentArea?>"><?php	

	?><div class="tableTitle">Customise Columns</div><hr style="float:left; width:60%" /><?php

	?><table class="criteriaTable" id="areaManagementTable_MainTableLeft" style="width:800px;" cellspacing="0" cellpadding="5"><?php
		?><tr class="tableGroup prmRow"><?php
			?><td colspan="3">Main Table Headers - Left</td><?php
		?></tr><?php
		?><tr class="tableGroup prmRow"><?php
			?><td>Default Name</td><?php
			?><td>Area Custom Name</td><?php
			?><td>Area Custom Position</td><?php
		?></tr><?php

		foreach($SESSION['table']['review_planning']['ca'] as $columnName=>$columnDetails)
		{
			?><tr><?php
				?><td><?=$columnDetails['default_title']?></td><?php
				?><td><input class="textareaWhite" id="areaCustomName_<?=$columnDetails['column_id']?>" name="areaCustomName_<?=$columnDetails['column_id']?>" value="<?=$currentColumnTranslations[$columnDetails['column_id']]['title']?>" size="28" type="text"></td><?php
				?><td><input class="textareaWhite" id="areaCustomPosition_<?=$columnDetails['column_id']?>" name="areaCustomPosition_<?=$columnDetails['column_id']?>" value="<?=(empty($currentColumnTranslations[$columnDetails['column_id']]['position']))?$columnDetails['column_position']:$currentColumnTranslations[$columnDetails['column_id']]['position']?>" size="28" type="text"></td><?php
			?></tr><?php
		}

		?></table><?php

		?><br /><br /><?php

		?><table class="criteriaTable" id="areaManagementTable_MainTableRight" style="width:800px;" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup prmRow"><?php
				?><td colspan="3">Main Table Headers - Review</td><?php
			?></tr><?php
			?><tr class="tableGroup prmRow"><?php
				?><td>Default Name</td><?php
				?><td>Area Custom Name</td><?php
				?><td>Area Custom Position</td><?php
			?></tr><?php

		foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
		{
			if($columnName!='criteria_status')
			{
				?><tr><?php
					?><td><?=$columnDetails['default_title']?></td><?php
					?><td><input class="textareaWhite" id="areaCustomName_<?=$columnDetails['column_id']?>" name="areaCustomName_<?=$columnDetails['column_id']?>" value="<?=$currentColumnTranslations[$columnDetails['column_id']]['title']?>" size="28" type="text"></td><?php
					?><td><input class="textareaWhite" id="areaCustomPosition_<?=$columnDetails['column_id']?>" name="areaCustomPosition_<?=$columnDetails['column_id']?>" value="<?=(empty($currentColumnTranslations[$columnDetails['column_id']]['position']))?$columnDetails['column_position']:$currentColumnTranslations[$columnDetails['column_id']]['position']?>" size="28" type="text"></td><?php
				?></tr><?php
			}
		}

	?></table><?php

	?><br /><br /><?php

	?><table class="criteriaTable" id="areaManagementTable_CriteriaTable" style="width:800px;" cellspacing="0" cellpadding="5"><?php
		?><tr class="tableGroup prmRow"><?php
			?><td colspan="3">Criteria Table</td><?php
		?></tr><?php
		?><tr class="tableGroup prmRow"><?php
			?><td>Default Name</td><?php
			?><td>Area Custom Name</td><?php
			?><td>Area Custom Position</td><?php
		?></tr><?php

		foreach($SESSION['table']['cat']['cat'] as $columnName=>$columnDetails)
		{
			?><tr><?php
				?><td><?=$columnDetails['default_title']?></td><?php
				?><td><input class="textareaWhite" id="areaCustomName_<?=$columnDetails['column_id']?>" name="areaCustomName_<?=$columnDetails['column_id']?>" value="<?=$currentColumnTranslations[$columnDetails['column_id']]['title']?>" size="28" type="text"></td><?php
				?><td><input class="textareaWhite" id="areaCustomPosition_<?=$columnDetails['column_id']?>" name="areaCustomPosition_<?=$columnDetails['column_id']?>" value="<?=(empty($currentColumnTranslations[$columnDetails['column_id']]['position']))?$columnDetails['column_position']:$currentColumnTranslations[$columnDetails['column_id']]['position']?>" size="28" type="text"></td><?php
			?></tr><?php
		}

	?></table><?php

	?><br /><br /><?php

	//JFM 19_07_16
	?><table class="criteriaTable" id="areaManagementTable_ActionTable" style="width:800px;" cellspacing="0" cellpadding="5"><?php
		?><tr class="tableGroup prmRow"><?php
			?><td colspan="3">Action Table</td><?php
		?></tr><?php
		?><tr class="tableGroup prmRow"><?php
			?><td>Default Name</td><?php
			?><td>Area Custom Name</td><?php
			?><td>Area Custom Position</td><?php
		?></tr><?php

		foreach($SESSION['table']['action']['action'] as $columnName=>$columnDetails)
		{
			?><tr><?php
				?><td><?=$columnDetails['default_title']?></td><?php
				?><td><input class="textareaWhite" id="areaCustomName_<?=$columnDetails['column_id']?>" name="areaCustomName_<?=$columnDetails['column_id']?>" value="<?=$currentColumnTranslations[$columnDetails['column_id']]['title']?>" size="28" type="text"></td><?php
				?><td><input class="textareaWhite" id="areaCustomPosition_<?=$columnDetails['column_id']?>" name="areaCustomPosition_<?=$columnDetails['column_id']?>" value="<?=(empty($currentColumnTranslations[$columnDetails['column_id']]['position']))?$columnDetails['column_position']:$currentColumnTranslations[$columnDetails['column_id']]['position']?>" size="28" type="text"></td><?php
			?></tr><?php
		}

	?></table><?php

	//-------------------------------------------------------------------------------------

	?><br /><div class="tableTitle">Customise Statuses</div><hr style="float:left; width:60%; clear:both;" /><br /><?php

	foreach ($statusTypes as $statusType) 
	{
		?><table class="criteriaTable" id="areaManagementTable_<?=$statusType?>Status" style="display:inline; width:200px; padding-right:30px;" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup prmRow"><?php
				?><td colspan="2"><?=$statusType?> Status</td><?php
			?></tr><?php
			?><tr class="tableGroup prmRow"><?php
				?><td style="width:20px;">Status</td><?php
				?><td>Enabled / Disabled</td><?php
			?></tr><?php

			foreach ($statuses as $status) 
			{
				$checked = true;

				if($currentDisabledStatuses[$SESSION['object'][$statusTypesObjects[$statusType]]][$statusesObjects[$status]] == 1) $checked = false;

				?><tr><?php
					?><td><img src="../common/img/<?=$status?>20.png"></td><?php
					?><td><?php
						?><select id="areaCustom<?=$statusType?>Status_<?=$status?>" name="areaCustom<?=$statusType?>Status_<?=$status?>"><?php
							?><option value="enabled" <?=($checked)?'selected':''?>>Enabled</option><?php
							?><option value="disabled" <?=(!$checked)?'selected':''?>>Disabled</option><?php
						?></select><?php
					?></td><?php
				?></tr><?php
			}

		?></table><?php
	}

?></form><?php

?>