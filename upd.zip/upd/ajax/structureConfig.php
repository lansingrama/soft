<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/revMan.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
$_o_=$SESSION['object'];
$hide=$SESSION['user_action']['hide'];
$filter=$SESSION['filter'];

echo 'OK|||';

switch($GET['element']){
	case'area': //JFM 03_06_14
		$validArea=allowedSimpleObject('area','area',$SESSION,'c_');
		$properties=SqlAsLi('SELECT * FROM c_area','area');
		?><div class="formHeaderInfo"id="userDetailsTitle">Area Configuration</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable"style="width:230px;" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup prmRow"><?php
					?><td style="width:25px;padding-left:10px;"><?php
						if(checkPermission('c_area_general','create',0,'check',$SESSION)==1){
							?><input class="popUpBtnBlue"onClick="popUpOpt('are',['new']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpAreaDiv_new"></div><?php
						}
					?></td><?php
					?><td>Area</td><?php
					?><td>Level 1</td><?php //JFM 08_06_16
					?><td>Level 2</td><?php
					?><td>Level 3</td><?php
					?><td>Criteria Validation</td><?php
					?><td>Review Validation</td><?php
					?><td>Evidence Validation</td><?php
				?></tr><?php
				foreach($validArea as $areaId=>$area){
					?><tr class="infoRow"><?php
						?><td class="paramDef"><?php
							if(checkPermission('c_area_general','edit',0,'check',$SESSION)==1){
								?><input class="popUpBtn"onClick="popUpOpt('are',[<?=$areaId?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpAreaDiv_<?=$areaId?>"></div><?php
							}
						?></td><?php
						?><td><?=$area?></td><?php
						?><td style="color:#<?=($properties[$area]['need_program']==1)?'00AA':'FF00';?>00;text-align:center;"><?=($properties[$area]['need_program']==1)?'&#10003;':'&#10008;';?></td><?php
						?><td style="color:#<?=($properties[$area]['need_coe']==1)?'00AA':'FF00';?>00;text-align:center;"><?=($properties[$area]['need_coe']==1)?'&#10003;':'&#10008;';?></td><?php
						?><td style="color:#<?=($properties[$area]['need_msn']==1)?'00AA':'FF00';?>00;text-align:center;"><?=($properties[$area]['need_msn']==1)?'&#10003;':'&#10008;';?></td><?php
						?><td style="color:#<?=($properties[$area]['need_criteria_validation']==1)?'00AA':'FF00';?>00;text-align:center;"><?=($properties[$area]['need_criteria_validation']==1)?'&#10003;':'&#10008;';?></td><?php
						?><td style="color:#<?=($properties[$area]['need_review_validation']==1)?'00AA':'FF00';?>00;text-align:center;"><?=($properties[$area]['need_review_validation']==1)?'&#10003;':'&#10008;';?></td><?php
						?><td style="color:#<?=($properties[$area]['need_evidence_validation']==1)?'00AA':'FF00';?>00;text-align:center;"><?=($properties[$area]['need_evidence_validation']==1)?'&#10003;':'&#10008;';?></td><?php
					?></tr><?php
				}
			?></table><?php
		?></div><?php
	break;
	case'program':
		if($GET['area']==0 || $GET['area']=='') //JFM 03_06_14
		{
			?><div class="sideContainerEmpty"style="color:#000000;">Please select a Area</div><?php
		}
		else
		{
			$neededItems=SqlQ('SELECT * FROM c_area WHERE area_id='.$GET['area']);
			if($neededItems['need_program']!=1)
			{
				?><div class="sideContainerEmpty"style="color:#000000;">No Level 1 Needed For This Area</div><?php //JMF 08_06_16
			}
			else
			{
				$validProgram=allowedSimpleObject('program','program',$SESSION,'c_','area='.$GET['area'].' AND program_hidden=0');
				$military=SqlAsArr('SELECT program_id,military FROM c_program','program_id','military');
				$code=SqlAsArr('SELECT program_id,program_code FROM c_program','program_id','program_code'); //JFM 23_10_15
				?><div class="formHeaderInfo"id="userDetailsTitle">Level 1 Configuration</div><?php
				?><div style="position:relative;height:50px;"></div><?php
				?><div class="elementDetailsContainer"><?php
					?><table class="criteriaTable"style="width:230px;" cellspacing="0" cellpadding="5"><?php
						?><tr class="tableGroup prmRow"><?php
							?><td style="width:25px;padding-left:10px;"><?php
								if(checkPermission('c_program_general','create',0,'check',$SESSION)==1){
									?><input class="popUpBtnBlue"onClick="popUpOpt('prg',['new',<?=$GET['area']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpProgDiv_new"></div><?php //JFM 03_06_14
								}
							?></td><?php
							?><td style="width:130px;">Level 1 Name</td><?php
							?><td style="width:130px;">Level 1 Code</td><?php //JFM 23_10_15 - JFM 08_06_16
							?><td style="text-align:center;">Military</td><?php
						?></tr><?php
						foreach($validProgram as $programId=>$program){
							?><tr class="infoRow"><?php
								?><td class="paramDef"><?php
									if(checkPermission('c_program_general','edit',0,'check',$SESSION)==1){
										?><input class="popUpBtn"onClick="popUpOpt('prg',[<?=$programId?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpProgDiv_<?=$programId?>"></div><?php
									}
								?></td><?php
								?><td><?=$program?></td><?php
								?><td><?=$code[$programId]?></td><?php //JFM 23_10_15
								?><td style="color:#<?=($military[$programId]==1)?'00AA':'FF00';?>00;text-align:center;"><?=($military[$programId]==1)?'&#10003;':'&#10008;';?></td><?php
							?></tr><?php
						}
					?></table><?php
				?></div><?php
			}
		}
	break;
	case'coe':
		if($GET['area']==0 || $GET['area']=='') //JFM 03_06_14
		{
			?><div class="sideContainerEmpty"style="color:#000000;">Please select an Area</div><?php
		}
		else
		{
			$neededItems=SqlQ('SELECT * FROM c_area WHERE area_id='.$GET['area']);
			if($neededItems['need_coe']!=1)
			{
				?><div class="sideContainerEmpty"style="color:#000000;">No Level 2 Needed For This Area</div><?php //JFM 08_06_16
			}
			else
			{
				$coeList=allowedSimpleObject('coe','coe',$SESSION,'c_','area='.$GET['area'].' AND coe_hidden=0');
				?><div class="formHeaderInfo"id="userDetailsTitle">Level 2 Configuration</div><?php
				?><div style="position:relative;height:50px;"></div><?php
				?><div class="elementDetailsContainer"><?php
					?><table class="criteriaTable"style="width:230px;" cellspacing="0" cellpadding="5"><?php
						?><tr class="tableGroup prmRow"><?php
							?><td style="width:25px;padding-left:10px;"><?php
								if(checkPermission('c_coe_general','create',0,'check',$SESSION)==1){
									?><input class="popUpBtnBlue"onClick="popUpOpt('coe',['new',<?=$GET['area']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCoeDiv_new"></div></td><?php //JFM 03_06_14
								}
							?><td style="width:130px;">Name</td><?php  //JFM 08_06_16
						?></tr><?php
						foreach($coeList as $coeId=>$coe){
							?><tr class="infoRow"><?php
								?><td class="paramDef"><?php
									if(checkPermission('c_coe_general','edit',0,'check',$SESSION)==1){
										?><input class="popUpBtn"onClick="popUpOpt('coe',[<?=$coeId?>,<?=$GET['area']?>,<?=$GET['program']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCoeDiv_<?=$coeId?>"></div></td><?php
									}
								?><td><?=$coe?></td><?php
							?></tr><?php
						}
					?></table><?php
				?></div><?php
			}
		}
	break;
	case'perimeter':
		if($GET['program']==0 || $GET['program']==''){
			?><div class="sideContainerEmpty"style="color:#000000;">Please select a Level 1 value.</div><?php
		}else{
//			$perimeterList=allowedSimpleObject('perimeter','perimeter',$SESSION,'c_','program='.$GET['program']);
                        // US#021.1 - To dispaly the selected User Suppliers with comma sepeated
			$perimeterList=SqlLi('SELECT DISTINCT perimeter_id,perimeter FROM c_perimeter WHERE program='.$GET['program']);
                        
			//$perimeter=SqlAsLi('SELECT perimeter_id,perimeter FROM c_perimeter WHERE program="'.$GET['program'].'"','perimeter_id');
			?><div class="formHeaderInfo"id="userDetailsTitle"><?=$SESSION['table']['review_planning']['ca']['perimeter']['title']?> Configuration</div><?php  //JFM 08_06_16
			?><div style="position:relative;height:50px;"></div><?php
			?><div class="elementDetailsContainer"><?php
				?><table class="criteriaTable"style="width:500px;" cellspacing="0" cellpadding="5"><?php
					?><tr class="tableGroup prmRow"><?php
						?><td style="width:5%;padding-left:10px;"><?php
						if(checkPermission('c_perimeter_general','create',0,'check',$SESSION)==1){
							?><input class="popUpBtnBlue"onClick="popUpOpt('prm',[<?=$GET['program']?>,'new']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpPrmDiv_new"></div></td><?php
						}
						?><td style="width:40%;"><?=$SESSION['table']['review_planning']['ca']['perimeter']['title']?> Name</td><?php //JFM 08_06_16
                                                ?><td style="width:110px;">User Supplier</td><?php
					?></tr><?php
					if(is_array($perimeterList)){
						foreach($perimeterList as $perimeterId=>$perimeterVal){
							?><tr class="infoRow"><?php
								?><td class="paramDef"><?php
                                                                        if(checkPermission('perimeter_id','view',$perimeterVal['perimeter_id'],'check',$SESSION,0)==1 || 
                                                                            checkPermission('c_perimeter_general','view',0,'check',$SESSION,0)==1){
                                                                                $perimeter=$perimeterVal['perimeter'];
                                                                        }
									if(checkPermission('c_perimeter_general','edit',0,'check',$SESSION)==1 || checkPermission('c_perimeter_general','delete',0,'check',$SESSION)==1){
                                                                            ?><input class="popUpBtn"onClick="popUpOpt('prm',[<?=$GET['program']?>,<?=$perimeterVal['perimeter_id']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpPrmDiv_<?=$perimeterVal['perimeter_id']?>"></div></td><?php
									}
								?><td><?=$perimeter?></td><?php
                                                                ?><td style="width:70%;"><?php
                                                                    $supplierNames = SqlLi('SELECT cs.supplier FROM `dr_perimeter_supplier_map` AS dp  JOIN `c_supplier` AS cs ON dp.supplier = cs.supplier_id WHERE dp.perimeter='.$perimeterVal['perimeter_id']);
                                                                    $supArr = array();
                                                                    foreach ($supplierNames as $supplier) {
                                                                        $supArr[] = $supplier['supplier'];
                                                                    }
                                                                    $supList = implode(',', $supArr);
                                                                    echo $supList; 
                                                               ?></td><?php
							?></tr><?php
                                                        // End of US#021.1
						}
					}else{
						?><tr class="infoRow"><?php
							?><td class="paramDef"></td><?php
							?><td style="font-style:italic; ">No <?=$SESSION['table']['review_planning']['ca']['perimeter']['title']?> yet</td><?php //JFM 08_06_16
						?></tr><?php
					}
				?></table><?php
			?></div><?php
		}
	break;
	case'msn':
		if($GET['program']==0 || $GET['program']=='')
		{
			?><div class="sideContainerEmpty"style="color:#000000;">Please select a Level 1 value.</div><?php //JFM 08_06_16
		}
		else
		{
			$neededItems=SqlQ('SELECT * FROM c_area WHERE area_id='.$GET['area']);
			if($neededItems['need_msn']!=1)
			{
				?><div class="sideContainerEmpty"style="color:#000000;">No Level 3 Needed For This Area</div><?php //JFM 08_06_16
			}
			else
			{
                                //To restrict the copy of Level3 to all Level2's for New Development
                                $program = SqlQ('SELECT pr.program FROM c_program as pr INNER JOIN c_msn as ms ON pr.program_id = ms.program WHERE pr.program_id='. $GET['program'] .' LIMIT 1');
                                
                                if($program['program'] == 'New Development') {
                                    $msn=SqlAsLi('SELECT msn_id,msn FROM c_msn WHERE program="'.$GET['program'].'" AND coe="'.$GET['coe'].'" AND msn_hidden=0','msn_id');
                                }
                                else {
                                    $msn=SqlAsLi('SELECT msn_id,msn FROM c_msn WHERE program="'.$GET['program'].'" AND msn_hidden=0','msn_id');
                                }
				
				?><div class="formHeaderInfo"id="userDetailsTitle">Level 3 Configuration</div><?php //JFM 08_06_16
				?><div style="position:relative;height:50px;"></div><?php
				?><div class="elementDetailsContainer"><?php
					?><table class="criteriaTable"style="width:170px;" cellspacing="0" cellpadding="5"><?php
						?><tr class="tableGroup prmRow"><?php
							?><td style="width:25px;padding-left:10px;"><?php
							if(checkPermission('c_msn_general','create',0,'check',$SESSION)==1){
								?><input class="popUpBtnBlue"onClick="popUpOpt('msn',[<?=$GET['program']?>,'new',<?=$GET['coe']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpMsnDiv_new"></div></td><?php
							}
							?><td style="width:110px;">Level 3 Name</td><?php //JFM 08_06_16
						?></tr><?php
						if(is_array($msn)){
							foreach($msn as $m){
								?><tr class="infoRow"><?php
									?><td class="paramDef"><?php
										if(checkPermission('c_msn_general','edit',0,'check',$SESSION)==1 || checkPermission('c_msn_general','delete',0,'check',$SESSION)==1){
											?><input class="popUpBtn"onClick="popUpOpt('msn',[<?=$GET['program']?>,<?=$m['msn_id']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpMsnDiv_<?=$m['msn_id']?>"></div></td><?php
										}
									?><td><?=$m['msn']?></td><?php
								?></tr><?php
							}
						}else{
							?><tr class="infoRow"><?php
								?><td class="paramDef"></td><?php
								?><td style="font-style:italic; ">No Level 3 yet</td><?php //JFM 08_06_16
							?></tr><?php
						}
					?></table><?php
				?></div><?php
			}
		}
	break;	
	case'cawp':
		if($GET['program']==0 || $GET['program']==''){
			?><div class="sideContainerEmpty"style="color:#000000;">Please select a Level 1 value</div><?php //JFM 08_06_16
		}elseif($GET['coe']==0 || $GET['coe']==''){
			?><div class="sideContainerEmpty"style="color:#000000;">Please select a Level 2 value</div><?php //JFM 08_06_16
		}elseif($GET['perimeter']==0 || $GET['perimeter']==''){
			?><div class="sideContainerEmpty"style="color:#000000;">Please select a <?=$SESSION['table']['review_planning']['ca']['perimeter']['title']?></div><?php //JFM 08_06_16
		}elseif($GET['msn']==0 || $GET['msn']==''){
			?><div class="sideContainerEmpty"style="color:#000000;">Please select a Level 3 value</div><?php //JFM 08_06_16
		}else{                    
			$cawp=SqlAsLi('SELECT c.ca,cw.cawp_id,cw.cawp_disabled AS element_disabled,w.wp_id,w.wp
								FROM c_ca AS c
									INNER JOIN c_cawp AS cw ON c.ca_id=cw.ca
									INNER JOIN c_wp AS w ON cw.wp=w.wp_id
								WHERE c.program="'.$GET['program'].'"
									AND c.coe="'.$GET['coe'].'"
									AND c.perimeter="'.$GET['perimeter'].'"
									AND cw.msn="'.$GET['msn'].'"
								ORDER BY w.wp_id,c.ca
								','cawp_id');                        
			$caWpLocation=$GET['program'].','.$GET['coe'].','.$GET['perimeter'].','.$GET['msn'];                        
                        $caWpDisabledIn[1]='<span style="color:#CCC;">';
			$caWpDisabledOut[1]='</span>';
			if($GET['included']!=1) //JFM 12_01_16
			{
				?><div class="formHeaderInfo"id="userDetailsTitle"><?=$SESSION['table']['review_planning']['ca']['wp']['title']?> - <?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Configuration</div><?php
				?><div style="position:relative;height:50px;"></div><?php
				?><div class="elementDetailsContainer"><?php
			}
				?><table class="criteriaTable"style="width:170px;" cellspacing="0" cellpadding="5"><?php
					?><tr class="tableGroup prmRow"><?php
						?><td style="width:25px;padding-left:10px;"><?php
						if(checkPermission('c_ca_general','create',0,'check',$SESSION)==1)
						{
							if($GET['included']!=1) //JFM 12_01_16
							{
								?><input class="popUpBtnBlue"onClick="popUpOpt('cwp',['new','',<?=$GET['program']?>,<?=$GET['coe']?>,<?=$GET['perimeter']?>,<?=$GET['msn']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCwpDiv_new"></div></td><?php
							}
						}
						?><td style="width:80px;"><?=$SESSION['table']['review_planning']['ca']['wp']['title']?></td><?php
						?><td style="width:80px;"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?></td><?php
					?></tr><?php
					if(is_array($cawp))
					{
						foreach($cawp as $c)
						{ //JFM 25_11_13
							$wpCount[$c['wp_id']]++;
						}
						$lastWp='';
						$b=0;
						foreach($cawp as $c)
						{
							?><tr class="infoRow"><?php
								?><td class="paramDef"><?php
									if(checkPermission('c_ca_general','edit',0,'check',$SESSION)==1 || checkPermission('c_ca_general','delete',0,'check',$SESSION)==1)
									{
										if($GET['included']!=1)
										{
											?><input class="popUpBtn"onClick="popUpOpt('cwp',[<?=$c['cawp_id']?>,<?=$c['element_disabled']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCwpDiv_<?=$c['cawp_id']?>"></div></td><?php                                                                                       
										}
										else
										{
											?><input type="radio" name="wizardEdit" id="<?=$c['cawp_id']?>"><?php
										}
									}
									if($lastWp!=$c['wp_id'])
									{
										?><td rowspan="<?=$wpCount[$c['wp_id']]?>"<?php if($b==1){?> style="background-color:#E5E5E5;"<?php }?>><?=$c['wp']?></td><?php
										$lastWp=$c['wp_id'];
										$b=($b==1)?0:1;
									}

									?><td><?=$caWpDisabledIn[$c['element_disabled']].$c['ca'].$caWpDisabledOut[$c['element_disabled']]?></td><?php
							?></tr><?php
						}
					}
					else
					{
						?><tr class="infoRow"><?php
							?><td class="paramDef"></td><?php
							?><td style="font-style:italic;" colspan="2">No <?=$SESSION['table']['review_planning']['ca']['wp']['title']?> or <?=$SESSION['table']['review_planning']['ca']['ca']['title']?> yet</td><?php
						?></tr><?php
					}
				?></table><?php
			if($GET['included']!=1) //JFM 12_01_16
			{
				?></div><?php
			}
		}
	break;

	case'review': //JFM 11_11_13
	if($GET['area']==0 || $GET['area']=='') //JFM 03_06_14
	{
		?><div class="sideContainerEmpty"style="color:#000000;">Please select a Area</div><?php
	}
	else if($GET['program']==0 || $GET['program']=='')
	{
		?><div class="sideContainerEmpty"style="color:#000000;">Please select a Level 1</div><?php
	}
	else if($GET['coe']==0 || $GET['coe']=='')
	{
		?><div class="sideContainerEmpty"style="color:#000000;">Please select a Level 2</div><?php
	}
	else
	{       /***
                * POC for : Bug-5 
                * Version :4.2
                * Fixed by : Infosys Limited 
                * Retreived mater review positin based on area
                */
		$review=SqlLi('SELECT DISTINCT p.review_profile_id,t.review_type,t.review_type_description,t.review_type_code, p.review_profile_order,t.master_review_profile_id
							FROM dr_review_profile AS p
							INNER JOIN dr_review_type AS t ON p.review_type=t.review_type_id
							INNER JOIN c_coe AS coe ON coe.coe_id=p.coe
							WHERE p.program="'.$GET['program'].'"
							AND p.coe="'.$GET['coe'].'"
							AND coe.area="'.$GET['area'].'"
                                                        AND t.review_type_hidden=0
							ORDER BY p.review_profile_order, t.review_type ASC'); //JFM 03_06_14 - JFM 19_07_16

		?><div class="formHeaderInfo"id="userDetailsTitle">Review Configuration</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable"style="width:530px;" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup prmRow"><?php
					?><td style="width:25px;padding-left:10px;"><?php
						if(checkPermission('dr_review_profile_general','create',0,'check',$SESSION)==1){
							?><input class="popUpBtnBlue"onClick="popUpOpt('ttl',['rvw',<?=$GET['area']?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpTtlDiv_rvw"></div><?php
						}
					?></td><?php
					?><td style="width:130px;">Review Name</td><?php
					?><td style="width:130px;">Review Description</td><?php
					?><td style="width:50px;">Review Code</td><?php
					?><td style="width:50px;">Review Position</td><?php //JFM 19_07_16
                                        //Start of Bug 5 for new column Master review postion
                                        ?><td style="width:50px;">Master Review Position</td><?php 
                                        //End of Bug  5
				?></tr><?php
				if(!empty($review))
				{
					foreach($review as $v=>$m){
						?><tr class="infoRow"><?php
							?><td class="paramDef"><?php
								if(checkPermission('dr_review_profile_general','edit',0,'check',$SESSION)==1)
								{
									//JFM 19_07_16
									?><input class="popUpBtn"onClick="popUpOpt('cat',['Review_<?=$m['review_profile_id']?>','<?=$m['review_profile_id']?>','<?=$m['review_type']?>','<?=$GET['area']?>']);"type="button"value="&#8801;"><div class="popUpMenu" id="popUpCatDiv_Review_<?=$m['review_profile_id']?>" ></div><?php
								}
							?></td><?php
							?><td><?=$m['review_type']?></td><?php
							?><td><?=$m['review_type_description']?></td><?php
							?><td><?=$m['review_type_code']?></td><?php
							?><td><?=$m['review_profile_order']?></td><?php //JFM 19_07_16
                                                        //Start of Bug 5 for display the values in Master review postion column
                                                        ?><td><?=$m['master_review_profile_id']?></td><?php
                                                        //End of Bug 5
						?></tr><?php
					}
				}
			?></table><?php
		?></div><?php
	}
	break;
	
	/* JFM 02_10_14
	case'responsible':
		$responsible=getResponsibles($GET['program'],$SESSION,1);
		//print_r($responsible);
		?><div class="formHeaderInfo"id="userDetailsTitle">Responsible Configuration</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable" style="width:350px;" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td style="width:25px;"></td><?php
					?><td style="width:80px;">Group</td><?php
					?><td style="width:200px;">Role</td><?php
				?></tr><?php
				$b=0;
				foreach($responsible['group'] as $groupPosition=>$group){
					?><tr class="infoRow"><?php
						?><td class="paramDef"><?php
							if(checkPermission('dr_responsible_configuration_general','edit',0,'check',$SESSION)==1){
								?><input class="popUpBtn"onClick="popUpOpt('rsp',[<?=$GET['program']?>,<?=$groupPosition?>,1]);"type="button"value="&#8801;"><?php
							}
							?><div class="popUpMenu"id="popUpRspDiv_<?=$groupPosition?>_1"></div></td><?php
						?><td class="infoRow"rowspan="<?=$responsible['group_count'][$groupPosition]?>"<?php if($b==1){?> style="background-color:#E5E5E5;"<?php }?>><?=$group?></td><?php
						$repeatedGroup=0;
						foreach($responsible['role'][$groupPosition] as $rolePosition=>&$role){
							if($repeatedGroup==1){
								?></tr><tr class="infoRow"><?php
								?><td class="paramDef"><?php
									if(checkPermission('dr_responsible_configuration_general','edit',0,'check',$SESSION)==1){
										?><input class="popUpBtn"onClick="popUpOpt('rsp',[<?=$GET['program']?>,<?=$groupPosition?>,<?=$rolePosition?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpRspDiv_<?=$groupPosition?>_<?=$rolePosition?>"></div></td><?php
									}
							}else $repeatedGroup=1;
							?><td class="infoRow"><?=$role?></td><?php
						}
						$b=($b==1)?0:1;
					?></tr><?php
				}
			?></table><?php
		?></div><?php
	break;*/
	case 'company':
		$company=SqlAsArr('SELECT company_id,company FROM c_company','company_id','company');
		?><div class="formHeaderInfo"id="userDetailsTitle">Company Configuration</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable"style="width:180px;" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup prmRow"><?php
					?><td style="width:25px;padding-left:10px;"><?php
						if(checkPermission('c_company_general','create',0,'check',$SESSION)==1){
							?><input class="popUpBtnBlue"onClick="popUpOpt('std',['Cmp','new']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCmpDiv_new"></div><?php
						}
					?></td><?php
					?><td style="width:150px;">Company</td><?php
				?></tr><?php
				foreach($company as $companyId=>$companyDetail){
					?><tr class="infoRow"><?php
						?><td class="paramDef"><?php
							if(checkPermission('c_department_general','edit',0,'check',$SESSION)==1 || checkPermission('c_department_general','delete',0,'check',$SESSION)==1){
								?><input class="popUpBtn"onClick="popUpOpt('std',['Cmp',<?=$companyId?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCmpDiv_<?=$companyId?>"></div><?php
							}
						?></td><?php
						?><td><?=$companyDetail?></td><?php
					?></tr><?php
				}
			?></table><?php
		?></div><?php
	break;
	case 'department':
		$department=SqlAsLi('SELECT department_id,siglum,department_description FROM c_department','department_id');
		?><div class="formHeaderInfo"id="userDetailsTitle">Department Configuration</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable"style="width:400px;" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup prmRow"><?php
					?><td style="width:25px;padding-left:10px;"><?php
						if(checkPermission('c_department_general','create',0,'check',$SESSION)==1){
							?><input class="popUpBtnBlue"onClick="popUpOpt('std',['Dpt','new']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpDptDiv_new"></div><?php
						}
					?></td><?php
					?><td style="width:50px;">Siglum</td><?php
					?><td style="text-align:center;">Description</td><?php
				?></tr><?php
				foreach($department as $departmentId=>$departmentDetail){
					?><tr class="infoRow"><?php
						?><td class="paramDef"><?php
							if(checkPermission('c_department_general','edit',0,'check',$SESSION)==1 || checkPermission('c_department_general','delete',0,'check',$SESSION)==1){
								?><input class="popUpBtn"onClick="popUpOpt('std',['Dpt',<?=$departmentId?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpDptDiv_<?=$departmentId?>"></div><?php
							}
						?></td><?php
						?><td><?=$departmentDetail['siglum']?></td><?php
						?><td><?=$departmentDetail['department_description']?></td><?php
					?></tr><?php
				}
			?></table><?php
		?></div><?php
	break;
	case 'grams': //JFM 03_12_13
		$aiGrams=SqlLi('SELECT grams_id AS criterion_validity_id, grams_reference FROM c_grams ORDER BY grams_reference');
		$i=0;
		foreach($aiGrams as $q=>$z)
		{
			if(stripos($z['grams_reference'],':')) $offset=(stripos($z['grams_reference'],':')+1);
			else $offset=0;
		
			if(is_numeric(substr($z['grams_reference'],$offset+0,1)))			$aiGrams[$q]['criterion_group']=substr($z['grams_reference'],$offset+0,1).'.'.substr($z['grams_reference'],$offset+1,1);
			else if(substr($z['grams_reference'],$offset+0,1)=='L')				$aiGrams[$q]['criterion_group']=substr($z['grams_reference'],$offset+1,1).'.'.substr($z['grams_reference'],$offset+2,1);
			else if(substr($z['grams_reference'],$offset+0,10)=='AI-GRAMS-L')	$aiGrams[$q]['criterion_group']=substr($z['grams_reference'],$offset+10,1).'.'.substr($z['grams_reference'],$offset+11,1);
			else if(substr($z['grams_reference'],$offset+0,9)=='AI-GRAMS-')		$aiGrams[$q]['criterion_group']=substr($z['grams_reference'],$offset+9,1).'.'.substr($z['grams_reference'],$offset+10,1);
			else if(stripos($z['grams_reference'],'neo'))						$aiGrams[$q]['criterion_group']='neo';
			else 																$aiGrams[$q]['criterion_group']=substr($z['grams_reference'],$offset+0,3);
		}
		foreach($aiGrams as $q=>$z)
		{
			$groupSort[$q] 		= $z['criterion_group'];
			$referenceSort[$q] 	= $z['grams_reference'];
		}
		
		array_multisort($groupSort,SORT_ASC,$referenceSort,SORT_ASC,$aiGrams);
		//print_r($aiGrams);
		
		$aiGrams=subVersion($aiGrams,$GET['expand']);

		?><div class="formHeaderInfo"id="userDetailsTitle">Reference Configuration</div><?php
		?><div style="position:relative;height:50px;"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><table class="criteriaTable" style="width:350px;" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td style="width:80px;"><?php
					if(checkPermission('c_program_general','create',0,'check',$SESSION)==1)
					{
						?><input class="popUpBtnBlue"onClick="popUpOpt('ttl',['grams','new']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpTtlDiv_grams"></div><?php
					}
					?>&nbsp;&nbsp;Module</td><?php
					?><td style="width:200px;">Reference</td><?php
					?><td style="width:200px;">Expand</td><?php
				?></tr><?php
				
				foreach($aiGrams as $q=>$z)
				{
					if($z['criterion_group_reference']=="Click to Contract" || $z['criterion_group_reference']=="^<br />|<br />|<br />") $bgColor='B5C6DD';	//FFE069 - Sort of orangey-ish - too bright.87A3C9
					else $bgColor=($bgColor=='E5E5E5')?'FFFFFF':'E5E5E5';
					
					?><tr class="infoRow" bgcolor="#<?=$bgColor?>"><?php
						?><td><center><?=$z['criterion_group']?></center></td><?php
						?><td><?=$z['grams_reference']?></td><?php
						?><td><center><?php
						
						if($z['criterion_group_reference']=="Click to Expand")
						{
							?><span class="dropDown" onClick="openSideElement('grams','str','empty&expand=<?=$z['criterion_group']?>');">Click to Expand</span><?php
						}
						else if($z['criterion_group_reference']=="Click to Contract")
						{
							?><span class="dropDown" onClick="openSideElement('grams','str');">Click to Contract</span><?php
						}
						else
						{
							echo $z['criterion_group_reference'];
						}
						
						?></center></td><?php
					?></tr><?php
				}
	
			?></table><?php
		?></div><?php
	break;
}
storeSession($SESSION);
?>