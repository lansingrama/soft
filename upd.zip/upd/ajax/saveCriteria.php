<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST);

$fullName='';
$email='';
$chID;


if($POST['criteriaShowStopper'] == '') $POST['criteriaShowStopper'] = 0;
if($POST['criterionPosition'] == '') $POST['criterionPosition'] = 0;

if($POST['copy']==1) //JFM 30_10_14
{
	$criterionPosition=SqlQ('SELECT MAX(criterion_position) AS critpos
								FROM dr_review_criterion_history AS rch
									INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
								WHERE rc.review_group='.$POST['groupBox']);
								
	SqlLQ('INSERT INTO dr_criterion_group (criterion_group_reference) VALUES ("Default")');
	
	$criterionGroupID=SqlQ('SELECT LAST_INSERT_ID() AS criterionGroupID');
	
	SqlLQ('INSERT INTO dr_review_criterion (review_group, criterion_group) VALUES ('.$POST['groupBox'].', '.$criterionGroupID['criterionGroupID'].')');
	
	$criterionID=SqlQ('SELECT LAST_INSERT_ID() AS criterionID');

	$criteriaToBeCopied=SqlQ('SELECT * FROM dr_review_criterion_history WHERE criterion='.$POST['criteria']);
	
	SqlLQ('INSERT INTO dr_review_criterion_history (		criterion,						criterion_user_id,				criterion_name,				criterion_description, 			criterion_position,					criterion_showstopper,				criterion_moc, criterion_valid_from, criterion_valid_to) VALUES 
													("'.$criterionID['criterionID'].'","'.$criteriaToBeCopied['criterion_user_id'].'","'.$criteriaToBeCopied['criterion_name'].'","'.$criteriaToBeCopied['criterion_description'].'","'.($criterionPosition['critpos']+1).'","'.$criteriaToBeCopied['criterion_showstopper'].'","'.$criteriaToBeCopied['criterion_moc'].'","'.$criteriaToBeCopied['criterion_valid_from'].'","'.$criteriaToBeCopied['criterion_valid_to'].'")');													

	$criterionHistoryID=SqlQ('SELECT LAST_INSERT_ID() AS criterionHistoryID');

	$allValidationLoop=SqlLi('SELECT * FROM dr_validation_loop
								WHERE object='.$SESSION['object']['criterion_validity_id'].'
								AND applicability='.$POST['criteria'].'
								ORDER BY validation_loop_id ASC');

	if(!empty($allValidationLoop))
	{
		foreach ($allValidationLoop as $validationLoop) 
		{
			SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
					VALUES ('.$SESSION['object']['criterion_validity_id'].',"'.$criterionHistoryID['criterionHistoryID'].'","'.$validationLoop['validator'].'","'.$validationLoop['validation_loop_step'].'","'.$validationLoop['received_on'].'","'.$validationLoop['action_taken'].'","'.$validationLoop['action_taken_on'].'")');
		}
	}
}

//JFM 19_07_16
else if($POST['force']==1)
{
	//
	//If creating a subversion of the criteria.
	//
	if($POST['subVersion'] == 1)
	{	
		//
		// Select review_group, criterion_group and criterion_position of the edited criteria.
		//
		
		$previousCriterionVersionInfo=SqlQ('SELECT MAX(criterion_position) AS critpos, review_group, criterion_group
											FROM dr_review_criterion_history AS rch
												INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
											WHERE rc.review_criterion_id='.$POST['criteriaID'].'
											GROUP BY review_group');
											
		SqlLQ('INSERT INTO dr_review_criterion (review_group, criterion_group) VALUES ('.$previousCriterionVersionInfo['review_group'].', '.$previousCriterionVersionInfo['criterion_group'].')');
		
		$criterionID=SqlQ('SELECT LAST_INSERT_ID() AS criterionID');
		
		SqlLQ('INSERT INTO dr_review_criterion_history (		criterion,						criterion_user_id,				criterion_name,				criterion_description, 			criterion_position,					criterion_showstopper,				criterion_moc) VALUES 
														("'.$criterionID['criterionID'].'","'.$POST['criteriaUserID'].'","'.$POST['criterionName'].'","'.$POST['criteriaDescription'].'","'.$previousCriterionVersionInfo['critpos'].'","'.$POST['criteriaShowStopper'].'","'.$POST['criteriaMOC'].'")');
														
		$criterionHistoryID=SqlQ('SELECT LAST_INSERT_ID() AS criterionHistoryID');
	}
	
	//
	//If adding a new criteria.
	//
	else
	{
		$criterionPosition=SqlQ('SELECT MAX(criterion_position) AS critpos
								FROM dr_review_criterion_history AS rch
									INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
								WHERE rc.review_group='.$POST['groupBox']);
								
		SqlLQ('INSERT INTO dr_criterion_group (criterion_group_reference) VALUES ("Default")');
		
		$criterionGroupID=SqlQ('SELECT LAST_INSERT_ID() AS criterionGroupID');
		
		SqlLQ('INSERT INTO dr_review_criterion (review_group, criterion_group) VALUES ('.$POST['groupBox'].', '.$criterionGroupID['criterionGroupID'].')');
		
		$criterionID=SqlQ('SELECT LAST_INSERT_ID() AS criterionID');
		
		SqlLQ('INSERT INTO dr_review_criterion_history (		criterion,						criterion_user_id,				criterion_name,				criterion_description, 			criterion_position,					criterion_showstopper,				criterion_moc) VALUES 
														("'.$criterionID['criterionID'].'","'.$POST['criteriaUserID'].'","'.$POST['criterionName'].'","'.$POST['criteriaDescription'].'","'.($criterionPosition['critpos']+1).'","'.$POST['criteriaShowStopper'].'","'.$POST['criteriaMOC'].'")');
														
		$criterionHistoryID=SqlQ('SELECT LAST_INSERT_ID() AS criterionHistoryID');
	}
	
	$gramsArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundGrams=strpos($arrayName,"gramsinputID");
		if($foundGrams===0) array_push($gramsArray,$arrayName);

	}
	
	//
	// Check if any GRAMS have been added and insert them into review_criterion_applicability_valid_to.
	//
	foreach($gramsArray as $gramsIDUsed)
	{		
		if($POST[$gramsIDUsed]=='') continue;
				
		SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
				VALUES ('.$criterionID['criterionID'].',(SELECT grams_id FROM c_grams WHERE grams_reference="'.$POST[$gramsIDUsed].'" ORDER BY grams_id DESC LIMIT 1),(SELECT object_id FROM c_object WHERE object="grams_id"))');
	}
	
	//
	// Insert new row into dr_review_criterion_applicability with the new application level.
	//

	$applicationLevelArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundApplicationLevel=strpos($arrayName,"application_level_");
		if($foundApplicationLevel===0 && $arrayValue!='') array_push($applicationLevelArray,substr($arrayName,18));
		
	}
	
	foreach($applicationLevelArray as $applicationLevelUsed)
	{					
		SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
				VALUES ('.$criterionID['criterionID'].',(SELECT application_level_id FROM c_application_level WHERE application_level="'.$applicationLevelUsed.'"),(SELECT object_id FROM c_object WHERE object="application_level"))');		
	}
	
	//
	// Insert new row into dr_review_criterion_applicability with the new Discipline.
	//

	$disciplineArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundDiscipline=strpos($arrayName,"discipline_");
		if($foundDiscipline===0 && $arrayValue!='') array_push($disciplineArray,substr($arrayName,11));
		
	}
	
	foreach($disciplineArray as $disciplineUsed)
	{					
		SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
				VALUES ('.$criterionID['criterionID'].',(SELECT discipline_id FROM c_discipline WHERE discipline="'.$disciplineUsed.'"),(SELECT object_id FROM c_object WHERE object="discipline"))');		
	}

	$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];

	if($POST['forceComments']=='')
	{
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
					VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$criterionHistoryID['criterionHistoryID'].'",'.$viewAsUserId.',0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="validated"),SYSDATE())');
	}
	else
	{
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on, validator_comment) 
					VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$criterionHistoryID['criterionHistoryID'].'",'.$viewAsUserId.',0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="validated"),SYSDATE(),"'.$POST['forceComments'].'")');
	}

	SqlLQ('UPDATE dr_review_criterion_history  
			SET criterion_valid_from=SYSDATE() 
			WHERE criterion_validity_id='.$criterionHistoryID['criterionHistoryID']);

	SqlLQ('UPDATE dr_review_criterion_applicability 
			SET review_criterion_applicability_valid_from=SYSDATE()
			WHERE criterion='.$criterionID['criterionID'].'
			AND review_criterion_applicability_valid_from="0000-00-00 00:00:00"');
}

//
// Cancelling a criteria modification.
//

else if($POST['cancel'] == 1) //JFM 21_10_13
{
	$criteriaNewqry=SqlLi('SELECT criterion_validity_id, criterion
							FROM dr_review_criterion_history 
							WHERE criterion='.$POST['criteriaID'].'
							AND criterion_valid_from="0000-00-00 00:00:00"
							AND criterion_valid_to="0000-00-00 00:00:00"');
							
	SqlLQ('UPDATE dr_review_criterion_applicability 
			SET review_criterion_applicability_valid_to="0000-00-00 00:00:00"
			WHERE criterion='.$POST['criteriaID'].'
			AND review_criterion_applicability_valid_to="0000-00-00 00:00:01"');
	
	SqlLQ('DELETE FROM dr_review_criterion_applicability
			WHERE criterion='.$POST['criteriaID'].' 
			AND review_criterion_applicability_valid_from="0000-00-00 00:00:00"');
	
	SqlLQ('UPDATE dr_review_criterion_history  
			SET criterion_valid_from="9999-12-31 23:59:59",
				criterion_valid_to="9999-12-31 00:00:00"
			WHERE criterion_validity_id='.$criteriaNewqry[0]['criterion_validity_id']);
					
	SqlLQ('UPDATE dr_validation_loop
			SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="cancelled"),
			action_taken_on=SYSDATE()
			WHERE validation_loop_id='.$POST['maxValidationLoopID']);
}


//
//If adding a new criteria OR creating a sub-version
//
else if($POST['criteriaID'] == 'Generated On Submit...' || $POST['subVersion'] == 1)
{
	//
	//If creating a subversion of the criteria.
	//
	if($POST['subVersion'] == 1)
	{	
		//
		// Select review_group, criterion_group and criterion_position of the edited criteria.
		//
		
		$previousCriterionVersionInfo=SqlQ('SELECT MAX(criterion_position) AS critpos, review_group, criterion_group
											FROM dr_review_criterion_history AS rch
												INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
											WHERE rc.review_criterion_id='.$POST['criteriaID'].'
											GROUP BY review_group');
											
		SqlLQ('INSERT INTO dr_review_criterion (review_group, criterion_group) VALUES ('.$previousCriterionVersionInfo['review_group'].', '.$previousCriterionVersionInfo['criterion_group'].')');
		
		$criterionID=SqlQ('SELECT LAST_INSERT_ID() AS criterionID');
		
		SqlLQ('INSERT INTO dr_review_criterion_history (		criterion,						criterion_user_id,				criterion_name,				criterion_description, 			criterion_position,					criterion_showstopper,				criterion_moc) VALUES 
														("'.$criterionID['criterionID'].'","'.$POST['criteriaUserID'].'","'.$POST['criterionName'].'","'.$POST['criteriaDescription'].'","'.$previousCriterionVersionInfo['critpos'].'","'.$POST['criteriaShowStopper'].'","'.$POST['criteriaMOC'].'")');
														
		$criterionHistoryID=SqlQ('SELECT LAST_INSERT_ID() AS criterionHistoryID');
	}
	
	//
	//If adding a new criteria.
	//
	else
	{
		$criterionPosition=SqlQ('SELECT MAX(criterion_position) AS critpos
								FROM dr_review_criterion_history AS rch
									INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
								WHERE rc.review_group='.$POST['groupBox']);
								
		SqlLQ('INSERT INTO dr_criterion_group (criterion_group_reference) VALUES ("Default")');
		
		$criterionGroupID=SqlQ('SELECT LAST_INSERT_ID() AS criterionGroupID');
		
		SqlLQ('INSERT INTO dr_review_criterion (review_group, criterion_group) VALUES ('.$POST['groupBox'].', '.$criterionGroupID['criterionGroupID'].')');
		
		$criterionID=SqlQ('SELECT LAST_INSERT_ID() AS criterionID');
		
		SqlLQ('INSERT INTO dr_review_criterion_history (		criterion,						criterion_user_id,				criterion_name,				criterion_description, 			criterion_position,					criterion_showstopper,				criterion_moc) VALUES 
														("'.$criterionID['criterionID'].'","'.$POST['criteriaUserID'].'","'.$POST['criterionName'].'","'.$POST['criteriaDescription'].'","'.($criterionPosition['critpos']+1).'","'.$POST['criteriaShowStopper'].'","'.$POST['criteriaMOC'].'")');
														
		$criterionHistoryID=SqlQ('SELECT LAST_INSERT_ID() AS criterionHistoryID');
	}
	
	$gramsArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundGrams=strpos($arrayName,"gramsinputID");
		if($foundGrams===0) array_push($gramsArray,$arrayName);

	}
	
	//
	// Check if any GRAMS have been added and insert them into review_criterion_applicability_valid_to.
	//
	foreach($gramsArray as $gramsIDUsed)
	{		
		if($POST[$gramsIDUsed]=='') continue;
				
		SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
				VALUES ('.$criterionID['criterionID'].',(SELECT grams_id FROM c_grams WHERE grams_reference="'.$POST[$gramsIDUsed].'" ORDER BY grams_id DESC LIMIT 1),(SELECT object_id FROM c_object WHERE object="grams_id"))');
	}
	
	//
	// Insert new row into dr_review_criterion_applicability with the new application level.
	//

	$applicationLevelArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundApplicationLevel=strpos($arrayName,"application_level_");
		if($foundApplicationLevel===0 && $arrayValue!='') array_push($applicationLevelArray,substr($arrayName,18));
		
	}
	
	foreach($applicationLevelArray as $applicationLevelUsed)
	{					
		SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
				VALUES ('.$criterionID['criterionID'].',(SELECT application_level_id FROM c_application_level WHERE application_level="'.$applicationLevelUsed.'"),(SELECT object_id FROM c_object WHERE object="application_level"))');		
	}
	
	//
	// Insert new row into dr_review_criterion_applicability with the new Discipline.
	//

	$disciplineArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundDiscipline=strpos($arrayName,"discipline_");
		if($foundDiscipline===0 && $arrayValue!='') array_push($disciplineArray,substr($arrayName,11));
		
	}
	
	foreach($disciplineArray as $disciplineUsed)
	{					
		SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
				VALUES ('.$criterionID['criterionID'].',(SELECT discipline_id FROM c_discipline WHERE discipline="'.$disciplineUsed.'"),(SELECT object_id FROM c_object WHERE object="discipline"))');		
	}
	
	//
	// Add all entered names into the validation loop.
	// -------------------------------------------------------------------------------------------------------------------------------------------------------
	$validationArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundValidation=strpos($arrayName,"elephantTigerBeehiveinputID");
		if($foundValidation===0 && $arrayValue!='') array_push($validationArray,$arrayValue);
	}

	SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
			VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$criterionHistoryID['criterionHistoryID'].'","'.$SESSION['user']['user_id'].'",0)');
			
	SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
			VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$criterionHistoryID['criterionHistoryID'].'","'.$SESSION['user']['user_id'].'",0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="originated"),SYSDATE())');
			
	$i=1;
			
	foreach($validationArray as $validationUsed)
	{
		$nameSplit=explode(", ",$validationUsed);

		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$criterionHistoryID['criterionHistoryID'].'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.')');
		
		if($i==1)
		{
			SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
					VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$criterionHistoryID['criterionHistoryID'].'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.',SYSDATE())');
			
			$fullName=$nameSplit[1].' '.$nameSplit[0];
			$email=SqlQ('SELECT email, allow_emails FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"');
		}
				
		$i++;
	}
}

//
//If editing an existing criteria
//
else
{
	//
	// If the criteria has been rejected and then modified - Update the stuff that's already there
	//
	if($POST['modify']==1)
	{
		SqlLQ('UPDATE dr_review_criterion_history 
					SET criterion_user_id="'.$POST['criteriaUserID'].'",
						criterion_name="'.$POST['criterionName'].'",
						criterion_description="'.$POST['criteriaDescription'].'",
						criterion_position="'.$POST['criterionPosition'].'",
						criterion_showstopper="'.$POST['criteriaShowStopper'].'",
						criterion_moc="'.$POST['criteriaMOC'].'"
					WHERE criterion_validity_id='.$POST['criterionValidityId']);
		$criterionHistoryID=$POST['criterionValidityId'];
	}
	
	//
	// Otherwise insert new row into dr_review_criterion_history with given criterion ID and a criterion_valid_from date of "0000-00-00 00:00:00"
	//
	else
	{
	
		SqlLQ('INSERT INTO dr_review_criterion_history (		criterion,						criterion_user_id,				criterion_name,				criterion_description, 			criterion_position,				criterion_showstopper,				criterion_moc) VALUES 
															("'.$POST['criteriaID'].'","'.$POST['criteriaUserID'].'","'.$POST['criterionName'].'","'.$POST['criteriaDescription'].'","'.$POST['criterionPosition'].'","'.$POST['criteriaShowStopper'].'","'.$POST['criteriaMOC'].'")');
												
		$criterionHistoryID=SqlQ('SELECT LAST_INSERT_ID() AS criterionHistoryID');
	}
	
	//
	// Check if GRAMS has been changed and update dr_review_criterion_applicability accordingly.
	// -------------------------------------------------------------------------------------------------------------------------------------------------------
	
	$gramsArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundGrams=strpos($arrayName,"gramsinputID");
		if($foundGrams===0) array_push($gramsArray,$arrayName);

	}

	$gramsQry=SqlLi('SELECT g.grams_reference, g.grams_id, rca.review_criterion_applicability_valid_from
						FROM c_grams AS g
						INNER JOIN dr_review_criterion_applicability as rca ON g.grams_id=rca.applicability
						WHERE rca.object=(SELECT object_id FROM c_object WHERE object="grams_id")
						AND criterion='.$POST['criteriaID'].'
						AND review_criterion_applicability_valid_to="0000-00-00 00:00:00"');
				

	//
	// Check if any GRAMS have been deleted and set their review_criterion_applicability_valid_to to a holding date.
	//
	if(!empty($gramsQry))
	{
		foreach($gramsQry as $gram)
		{
			$found=false;

			foreach($gramsArray as $gramsIDUsed)
			{
				if($gram['grams_reference']==$POST[$gramsIDUsed])
				{
					$found=true;
					break;
				}
			}
			
			if(!$found)
			{			
				//
				// If a GRAMS has been deleted and it is set to the holding date, it means you are modifying the criteria and it can just be removed from the database instead of being set to a holding date.
				//
				if($gram['review_criterion_applicability_valid_from']=="0000-00-00 00:00:00")
				{
					SqlLQ('DELETE FROM dr_review_criterion_applicability
							WHERE criterion='.$POST['criteriaID'].' 
							AND applicability='.$gram['grams_id'].' 
							AND object=(SELECT object_id FROM c_object WHERE object="grams_id")');
				}
				else
				{
					SqlLQ('UPDATE dr_review_criterion_applicability 
							SET review_criterion_applicability_valid_to="0000-00-00 00:00:01" 
							WHERE criterion='.$POST['criteriaID'].' 
							AND applicability='.$gram['grams_id'].' 
							AND object=(SELECT object_id FROM c_object WHERE object="grams_id")');
				}
			}
		}
	}

	//
	// Check if any GRAMS have been added and insert them into review_criterion_applicability_valid_to.
	//
	foreach($gramsArray as $gramsIDUsed)
	{		
		if($POST[$gramsIDUsed]=='') continue;
		
		$found=false;
		
		foreach($gramsQry as $gram)
		{
			if($gram['grams_reference']==$POST[$gramsIDUsed])
			{
				$found=true;
				break;
			}
		}
		
		if(!$found)
		{		
			SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
					VALUES ('.$POST['criteriaID'].',(SELECT grams_id FROM c_grams WHERE grams_reference="'.$POST[$gramsIDUsed].'"),(SELECT object_id FROM c_object WHERE object="grams_id"))');

		}
	}
	
	
	
	
	//
	// Check if Application Level has been changed and update dr_review_criterion_applicability accordingly.
	// -------------------------------------------------------------------------------------------------------------------------------------------------------
	
	/* JFM 04_03_14
	$applicationLevelQry=SqlLi('SELECT a.application_level_id, a.application_level, rca.review_criterion_applicability_valid_from, rca.review_criterion_applicability_valid_to
								FROM c_application_level AS a
									INNER JOIN dr_review_criterion_applicability as rca ON a.application_level_id=rca.applicability
								WHERE rca.object=(SELECT object_id FROM c_object WHERE object="application_level")
								AND criterion='.$POST['criteriaID'].'
								AND (review_criterion_applicability_valid_to="0000-00-00 00:00:00"
								OR review_criterion_applicability_valid_to="0000-00-00 00:00:01")
								ORDER BY review_criterion_discipline_applicability_id ASC');
				
	//
	// If the criteria no longer has an application level
	//
	if($POST['applicationLevelBox']=='None')
	{
		//
		// If it use to have an application level but now no longer does, set its dates to a holding date.
		//
		if(!empty($applicationLevelQry))
		{
		
			if($applicationLevelQry[0]['review_criterion_applicability_valid_from']=="0000-00-00 00:00:00")
			{
				SqlLQ('DELETE FROM dr_review_criterion_applicability
						WHERE criterion='.$POST['criteriaID'].' 
						AND applicability='.$applicationLevelQry[0]['application_level_id'].' 
						AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
			}
			else
			{
				SqlLQ('UPDATE dr_review_criterion_applicability 
						SET review_criterion_applicability_valid_to="0000-00-00 00:00:01" 
						WHERE criterion='.$POST['criteriaID'].' 
						AND applicability='.$applicationLevelQry[0]['application_level_id'].' 
						AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
						
				if(!empty($applicationLevelQry[1]['application_level_id']))
				{
					SqlLQ('DELETE FROM dr_review_criterion_applicability
							WHERE criterion='.$POST['criteriaID'].' 
							AND applicability='.$applicationLevelQry[1]['application_level_id'].' 
							AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
				}
			}
		}
	}
	
	//
	// If an application level has been set.
	//
	else
	{
		if(!empty($applicationLevelQry))
		{
			//
			// If the application level are different.
			//
			if($applicationLevelQry[0]['application_level']!=$POST['applicationLevelBox'])
			{
				//s->a->?
				if(!empty($applicationLevelQry[1]['application_level_id']))
				{
					if($applicationLevelQry[1]['review_criterion_applicability_valid_from']=="0000-00-00 00:00:00")
					{
						SqlLQ('DELETE FROM dr_review_criterion_applicability
								WHERE criterion='.$POST['criteriaID'].' 
								AND applicability='.$applicationLevelQry[1]['application_level_id'].' 
								AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
					}
				}
				else if($applicationLevelQry[0]['review_criterion_applicability_valid_from']=="0000-00-00 00:00:00")
				{
					SqlLQ('DELETE FROM dr_review_criterion_applicability
							WHERE criterion='.$POST['criteriaID'].' 
							AND applicability='.$applicationLevelQry[0]['application_level_id'].' 
							AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
				}
				else
				{
					SqlLQ('UPDATE dr_review_criterion_applicability 
						SET review_criterion_applicability_valid_to="0000-00-00 00:00:01" 
						WHERE criterion='.$POST['criteriaID'].' 
						AND applicability='.$applicationLevelQry[0]['application_level_id'].' 
						AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
				}

				SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
						VALUES ('.$POST['criteriaID'].',(SELECT application_level_id FROM c_application_level WHERE application_level="'.$POST['applicationLevelBox'].'"),(SELECT object_id FROM c_object WHERE object="application_level"))');
			}
			
			else if($applicationLevelQry[0]['review_criterion_applicability_valid_to']=="0000-00-00 00:00:01")
			{
				SqlLQ('UPDATE dr_review_criterion_applicability 
						SET review_criterion_applicability_valid_to="0000-00-00 00:00:00" 
						WHERE criterion='.$POST['criteriaID'].' 
						AND applicability='.$applicationLevelQry[0]['application_level_id'].' 
						AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
						
				if(!empty($applicationLevelQry[1]['application_level_id']))
				{
					SqlLQ('DELETE FROM dr_review_criterion_applicability
							WHERE criterion='.$POST['criteriaID'].' 
							AND applicability='.$applicationLevelQry[1]['application_level_id'].' 
							AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
				}
			}
			
		}
		else
		{
			//
			// Insert new row into dr_review_criterion_applicability with the new application level.
			//
	
			SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
					VALUES ('.$POST['criteriaID'].',(SELECT application_level_id FROM c_application_level WHERE application_level="'.$POST['applicationLevelBox'].'"),(SELECT object_id FROM c_object WHERE object="application_level"))');
		}
	}

	*/

	$applicationLevelArray=array();

	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundApplicationLevel=strpos($arrayName,"application_level_");
		if($foundApplicationLevel===0 && $arrayValue!='') array_push($applicationLevelArray,substr($arrayName,18));
		
	}

	$applicationLevelQry=SqlLi('SELECT a.application_level_id, a.application_level, rca.review_criterion_applicability_valid_from
								FROM c_application_level AS a
									INNER JOIN dr_review_criterion_applicability as rca ON a.application_level_id=rca.applicability
								WHERE rca.object=(SELECT object_id FROM c_object WHERE object="application_level")
								AND criterion='.$POST['criteriaID'].'
								AND review_criterion_applicability_valid_to="0000-00-00 00:00:00"');
		
	if(!empty($applicationLevelQry))
	{			
		foreach($applicationLevelQry as $applicationLevel)
		{
			$found=false;

			foreach($applicationLevelArray as $applicationLevelUsed)
			{
				if($applicationLevel['application_level']==$applicationLevelUsed)
				{
					$found=true;
					break;
				}
			}
			
			if(!$found)
			{			
				if($applicationLevel['review_criterion_applicability_valid_from']=="0000-00-00 00:00:00")
				{
					SqlLQ('DELETE FROM dr_review_criterion_applicability
							WHERE criterion='.$POST['criteriaID'].' 
							AND applicability='.$applicationLevel['application_level_id'].' 
							AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
				}
				else
				{
					SqlLQ('UPDATE dr_review_criterion_applicability 
							SET review_criterion_applicability_valid_to="0000-00-00 00:00:01" 
							WHERE criterion='.$POST['criteriaID'].' 
							AND applicability='.$applicationLevel['application_level_id'].' 
							AND object=(SELECT object_id FROM c_object WHERE object="application_level")');
				}
			}
		}
	}
	
	foreach($applicationLevelArray as $applicationLevelUsed)
	{				
		$found=false;
		
		foreach($applicationLevelQry as $applicationLevel)
		{
			if($applicationLevel['application_level']==$applicationLevelUsed)
			{
				$found=true;
				break;
			}
		}
		
		if(!$found)
		{		
			SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
					VALUES ('.$POST['criteriaID'].',(SELECT application_level_id FROM c_application_level WHERE application_level="'.$applicationLevelUsed.'"),(SELECT object_id FROM c_object WHERE object="application_level"))');
			
		}
	}
	
	
	
	
	
	//
	// Check if Discipline has been changed and update dr_review_criterion_applicability accordingly.
	// -------------------------------------------------------------------------------------------------------------------------------------------------------
	
	$disciplineArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundDiscipline=strpos($arrayName,"discipline_");
		if($foundDiscipline===0 && $arrayValue!='') array_push($disciplineArray,substr($arrayName,11));
		
	}

	$disciplineQry=SqlLi('SELECT d.discipline_id, d.discipline, rca.review_criterion_applicability_valid_from
							FROM c_discipline AS d
								INNER JOIN dr_review_criterion_applicability as rca ON d.discipline_id=rca.applicability
							WHERE rca.object=(SELECT object_id FROM c_object WHERE object="discipline")
							AND criterion='.$POST['criteriaID'].'
							AND review_criterion_applicability_valid_to="0000-00-00 00:00:00"');
				
	if(!empty($disciplineQry))
	{			
		foreach($disciplineQry as $discipline)
		{
			$found=false;

			foreach($disciplineArray as $disciplineUsed)
			{
				if($discipline['discipline']==$disciplineUsed)
				{
					$found=true;
					break;
				}
			}
			
			if(!$found)
			{			
				if($discipline['review_criterion_applicability_valid_from']=="0000-00-00 00:00:00")
				{
					SqlLQ('DELETE FROM dr_review_criterion_applicability
							WHERE criterion='.$POST['criteriaID'].' 
							AND applicability='.$discipline['discipline_id'].' 
							AND object=(SELECT object_id FROM c_object WHERE object="discipline")');
				}
				else
				{
					SqlLQ('UPDATE dr_review_criterion_applicability 
							SET review_criterion_applicability_valid_to="0000-00-00 00:00:01" 
							WHERE criterion='.$POST['criteriaID'].' 
							AND applicability='.$discipline['discipline_id'].' 
							AND object=(SELECT object_id FROM c_object WHERE object="discipline")');
				}
			}
		}
	}
	
	foreach($disciplineArray as $disciplineUsed)
	{				
		$found=false;
		
		foreach($disciplineQry as $discipline)
		{
			if($discipline['discipline']==$disciplineUsed)
			{
				$found=true;
				break;
			}
		}
		
		if(!$found)
		{		
			SqlLQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
					VALUES ('.$POST['criteriaID'].',(SELECT discipline_id FROM c_discipline WHERE discipline="'.$disciplineUsed.'"),(SELECT object_id FROM c_object WHERE object="discipline"))');
			
		}
	}
		
	
	//
	// Add all entered names into the validation loop.
	// -------------------------------------------------------------------------------------------------------------------------------------------------------
	$validationArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundValidation=strpos($arrayName,"elephantTigerBeehiveinputID");
		if($foundValidation===0 && $arrayValue!='') array_push($validationArray,$arrayValue);
	}

	if($POST['modify']!=1)
	{
		$chID=$criterionHistoryID['criterionHistoryID'];
		
		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$chID.'","'.$SESSION['user']['user_id'].'",0)');
				
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
				VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$chID.'","'.$SESSION['user']['user_id'].'",0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="originated"),SYSDATE())');				
	}
	else //JFM 03_12_13
	{
		$chID=$criterionHistoryID;
		
		SqlLQ('DELETE FROM dr_validation_loop_structure WHERE object=(SELECT object_id FROM c_object WHERE object="criterion_validity_id") AND applicability="'.$chID.'"');
		
		SqlLQ('UPDATE dr_validation_loop
				SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="modified"),
				action_taken_on=SYSDATE()
				WHERE object=(SELECT object_id FROM c_object WHERE object="criterion_validity_id")
				AND applicability="'.$chID.'"
				AND validator='.$SESSION['user']['user_id'].'
				AND action_taken=0');
		
		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$chID.'","'.$SESSION['user']['user_id'].'",0)');
	}
	
	$i=1;
			
	foreach($validationArray as $validationUsed)
	{
		$nameSplit=explode(", ",$validationUsed);

		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$chID.'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.')');
		
		if($i==1)
		{
			SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
					VALUES ((SELECT object_id FROM c_object WHERE object="criterion_validity_id"),"'.$chID.'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.',SYSDATE())');
		
			$fullName=$nameSplit[1].' '.$nameSplit[0];
			$email=SqlQ('SELECT email, allow_emails FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"');
		}
				
		$i++;
	}
}


if(!empty($fullName)) 
{
	if(is_array($criterionHistoryID)) $chID = $criterionHistoryID['criterionHistoryID']; //JFM 28_10_15
	else $chID = $criterionHistoryID;

	$criterionID=SqlLi('SELECT rch.criterion, rch.criterion_user_id, rt.review_type
										FROM dr_review_criterion_history AS rch
											INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
											INNER JOIN dr_review_group AS rg ON rg.group_id=rc.review_group
											INNER JOIN dr_review_type AS rt ON rt.review_type_id=rg.review_type
										WHERE criterion_validity_id='.$chID);

				$headers="MIME-Version: 1.0\r\n";
				$headers.="Content-type: text/html; charset=utf-8\r\n";
				$headers.="From: Airbus No Reply <noreply@airbus.com>\r\n"; 
				$headers.="Reply-To: noreply@airbus.com\r\n"; 
				$headers.="Return-path: noreply@airbus.com\r\n";
				$headers.="Cc: \r\n";
				$headers.="Bcc: \r\n";

	$mailBody='
				<html>
				<head>
					<title>Criteria Validation</title>
				</head>
				<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
					<div style="width: 100%; height: 300px; cellSpacing=1; cellPadding=0; border=0;">
					<table align="center">
					  <tr>
						<td style="background-color:#C3CDDC;color:#565C6A;font-family:Verdana,Arial,Helvetica,sans-serif;font-size:11px;font-weight:bold;padding-left:10px;">
							Criteria Validation
						</td>	
					</tr>
					<tr>
						<td style="	border-style:solid; border-color:#CCCCCC; border-width:1px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; padding-left:10px;">
							<strong>Dear '.$fullName.',</strong><br>
							<p>
							This is an automatic email to inform you a criteria requires your validation.<br><br>
							This criteria is for <strong>'.$criterionID[0]['review_type'].'</strong> reviews.
							</p>
							Click the link below to login and validate the criteria:<br>
							<a http://art-int.eu.airbus.corp/1V55">
							http://art-int.eu.airbus.corp/1V55</a><br><br>
							Please, do not reply to this message.<br>
							<br><br><br>
							Best regards,<br><br>
							Design Reviews Team.
						</td>
					  </tr>
					</table>
				</div>
				</body>
				</html>';

	if($email['allow_emails']!=1) mail($email['email'],'Design Review Tool - Criteria Validation',$mailBody,$headers);
}

echo 'OK|||'.$answer;
storeSession($SESSION);
?>