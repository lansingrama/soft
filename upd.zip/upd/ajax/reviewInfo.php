<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');

$GET=cleanArray($_GET);
$status=array('r','a','g','x'); //JFM 27_03_14

$reviewProfile=$GET['review_profile'];
$msn=getFilter('msn','filter',0,$SESSION);

$allCAsInThisReview=SqlLi('SELECT DISTINCT ca.ca_id, ca.ca 
							FROM c_ca AS ca
								INNER JOIN dr_review_applicability 	AS 	ra 	ON 	ra.ca = ca.ca_id
							WHERE ra.review IN (SELECT review FROM dr_review_applicability WHERE ca="'.$GET['ca'].'")
							ORDER BY ca.ca ASC');

$reviewID=SqlLi('SELECT review_id, validation_date
						FROM dr_review AS r
							INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
							INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
						WHERE rp.review_profile_id='.$reviewProfile.'
						AND ra.ca IN ('.$GET['ca'].')
						AND r.msn='.$msn);
						
$totalCriteria=SqlLi('SELECT * FROM dr_review_configuration WHERE review='.$reviewID[0]['review_id']);
					
$criteriaStatusQry=mysql_query('SELECT DISTINCT s.review_criteria,s.ca,s.criteria_status_id,s.criteria_status,s.criteria_focal_point,s.review_criteria,s.criteria_comments
								FROM c_ca AS ca
									LEFT JOIN dr_criteria_status AS s ON ca.ca_id=s.ca
									INNER JOIN dr_review_configuration AS c ON s.review_criteria=c.criterion
									INNER JOIN dr_review AS g ON c.review=g.review_id
								WHERE s.msn="'.$msn.'"
								AND ca.ca_id IN('.$GET['ca'].')
								AND g.review_profile="'.$reviewProfile.'"',$p12) or die(mysql_error());

$criteriaStatus=Array();

while($c=mysql_fetch_assoc($criteriaStatusQry))
{
	foreach($c as $k=>$v)
	{
		if($k=='criteria_status') $criteriaStatus[$v]++;
	}
}

$totalCriteriaLeft = count($totalCriteria)-$criteriaStatus['0']-$criteriaStatus['1']-$criteriaStatus['2']-$criteriaStatus['3']; //JFM 27_03_14

?>OK|||<div class="olHeader">Review Details</div><?php
?><div class="olSpT"></div><?php
?><div class="elementDetailsContainer"style="width:420px;"><?php
	?><table class="criteriaTable"style="width:400px;"><?php
		?><tr class="tableGroup prmRow"><?php
			?><td style="padding-left:10px;width:84px;">Field</td><?php
			?><td style="text-align:center;">Red</td><?php
			?><td style="text-align:center;">Amber</td><?php
			?><td style="text-align:center;">Green</td><?php
			?><td style="text-align:center;">No Status</td><?php 
		?></tr><?php
		?><tr class="infoRow"><?php
			?><td class="paramDef">Criteria</td><?php
			?><td class="reviewAction"style="color:#900;text-align:center;"><?=($criteriaStatus['0']=='')?0:$criteriaStatus['0']?></td><?php
			?><td class="reviewAction"style="color:#CC0;text-align:center;"><?=($criteriaStatus['1']=='')?0:$criteriaStatus['1']?></td><?php
			?><td class="reviewAction"style="color:#060;text-align:center;"><?=($criteriaStatus['2']=='')?0:$criteriaStatus['2']?></td><?php
			?><td class="reviewAction"style="color:#060;text-align:center;"><?=($criteriaStatus['3']=='')?0:$criteriaStatus['3']?></td><?php //JFM 27_03_14
			?><td class="reviewAction"style="text-align:center;"><?=($totalCriteriaLeft=='')?0:$totalCriteriaLeft?></td><?php
		?></tr><?php
		?><tr class="infoRow"><?php	//JFM 25_11_13
			?><td class="paramDef">Applicable CAs</td><?php
			?><td colspan="5"><?php
				foreach($allCAsInThisReview as $oneCAInThisReview) $allCAsInThisReviewAsString=$allCAsInThisReviewAsString.$oneCAInThisReview['ca'].', ';
				$allCAsInThisReviewAsString=rtrim($allCAsInThisReviewAsString, ", ");
				echo $allCAsInThisReviewAsString;
			?></td><?php
		?></tr><?php	
	?></table><?php
?></div><?php
?><div class="olSpB"></div><?php
storeSession($SESSION);
?>