<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$GET = cleanArray($_GET);

$programIds = SqlAsLi('SELECT DISTINCT program_id FROM c_program WHERE program LIKE "'.$GET['program'].'"','program_id');
$reviewTypesAllowed=allowedSimpleObject('review_profile','review_type',$SESSION,'dr_','');

if(!empty($programIds) && !empty($reviewTypesAllowed))
{
	$reviewQry = SqlLi('SELECT DISTINCT r.review_id, r.review_status, r.review_done, r.planned, rt.review_type, coe.coe
						FROM dr_review AS r
						INNER JOIN dr_review_applicability 		AS app 		ON  app.review=r.review_id
						INNER JOIN c_ca 						AS ca 		ON  ca.ca_id=app.ca
						INNER JOIN dr_review_profile			AS rp 		ON  rp.review_profile_id=r.review_profile
																			AND rp.program=ca.program
						INNER JOIN dr_review_type 				AS rt 		ON  rt.review_type_id=rp.review_type
						INNER JOIN c_coe 						AS coe 		ON  coe.coe_id=rp.coe
																			AND coe.coe_id=ca.coe
						INNER JOIN c_cawp 						AS cawp 	ON  cawp.ca=ca.ca_id
						WHERE r.validation_complete = 2
						AND   r.review_status != 4
						AND   cawp.cawp_disabled = 0
						AND   ca.program IN ('.implode(',', (array_keys($programIds))).')
						AND   rt.review_type_id IN ('.implode(',', $reviewTypesAllowed).')');
}

$reviewCount=Array();

$graphStackedBar=array();
$biggestBarStackedBar=0;

if(!empty($reviewQry))
{
	foreach ($reviewQry as $uselessKey => $usefulValue) 
	{
		$reviewCount['totals'][$usefulValue['review_done']]++;

		if($usefulValue['review_done']==1)
		{
			$reviewCount['types_done']['total']++;
			$reviewCount['types_done'][$usefulValue['review_type']][$usefulValue['review_status']]++;

			$graphStackedBar[$usefulValue['review_type']]['name']=$usefulValue['review_type'];
			$graphStackedBar[$usefulValue['review_type']]['criteria_status'][$usefulValue['review_status']]++;
			if(array_sum($graphStackedBar[$usefulValue['review_type']]['criteria_status']) > $biggestBarStackedBar) $biggestBarStackedBar=array_sum($graphStackedBar[$usefulValue['review_type']]['criteria_status']);

		}
		else if($usefulValue['review_done']==0 && $usefulValue['planned']!='0000-00-00')
		{
			$reviewCount['types_planned']['total']++;
			$reviewCount['types_planned'][$usefulValue['review_type']][$usefulValue['review_status']]++;
			$graphStackedBar[$usefulValue['review_type']]['criteria_status'][4]++;
			if(array_sum($graphStackedBar[$usefulValue['review_type']]['criteria_status']) > $biggestBarStackedBar) $biggestBarStackedBar=array_sum($graphStackedBar[$usefulValue['review_type']]['criteria_status']);
		}
	}
}

//CSA
$actionRawData1=SqlLi('SELECT DISTINCT ac.action_id, ac.action_status, rd.rid_id, rd.rid_status, rt.review_type
					FROM dr_action								AS ac
						INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
						INNER JOIN dr_action_applicability		AS ap2	ON ap2.action=ac.action_id
						INNER JOIN c_ca							AS ca	ON ap2.ca=ca.ca_id 
						INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
						INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
						INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND ac.msn=m.msn_id)
						INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
						INNER JOIN dr_review_criterion 			AS cr 	ON ac.criteria=cr.review_criterion_id 
						INNER JOIN dr_review_criterion_history 	AS crh 	ON cr.review_criterion_id=crh.criterion
						INNER JOIN dr_review_group				AS rg 	ON cr.review_group=rg.group_id
						INNER JOIN dr_review_group_history 		AS gr 	ON rg.group_id=gr.review_group 
						INNER JOIN dr_review_type 				AS rt 	ON rg.review_type=rt.review_type_id
						INNER JOIN dr_review_profile			AS rp 	ON rt.review_type_id=rp.review_type
						INNER JOIN c_cawp 						AS cawp ON cawp.ca=ca.ca_id
						LEFT JOIN  dr_rid 						AS rd 	ON ac.rid=rd.rid_id
						WHERE cawp.cawp_disabled = 0
						AND   ca.program IN ('.implode(',', (array_keys($programIds))).')
						AND   rt.review_type_id IN ('.implode(',', $reviewTypesAllowed).')');

//NCSA
$actionRawData2=SqlLi('SELECT DISTINCT ac.action_id, ac.action_status, rt.review_type
					FROM dr_action								AS ac
						INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
						INNER JOIN dr_action_applicability		AS ap2	ON ap2.action=ac.action_id
						INNER JOIN c_ca							AS ca	ON ap2.ca=ca.ca_id 
						INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
						INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
						INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND ac.msn=m.msn_id)
						INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
						INNER JOIN dr_review 					AS r 	ON ac.review=r.review_id
						INNER JOIN dr_review_profile			AS rp   ON r.review_profile=rp.review_profile_id
						INNER JOIN dr_review_type 				AS rt 	ON rp.review_type=rt.review_type_id
						INNER JOIN c_cawp 						AS cawp ON cawp.ca=ca.ca_id
						WHERE cawp.cawp_disabled = 0
						AND   ca.program IN ('.implode(',', (array_keys($programIds))).')
						AND   rt.review_type_id IN ('.implode(',', $reviewTypesAllowed).')');

if(!empty($actionRawData1) && !empty($actionRawData2)) $actionRawData=array_merge($actionRawData1, $actionRawData2);
else if (!empty($actionRawData1)) $actionRawData=$actionRawData1;
else if (!empty($actionRawData2)) $actionRawData=$actionRawData2;

$actionCount=Array();
$ridCount=Array();

$graphStackedBarAction=array();
$biggestBarStackedBarAction=0;
$graphStackedBarRid=array();
$biggestBarStackedBarRid=0;

if(!empty($actionRawData))
{
	foreach ($actionRawData as $uselessKey => $usefulValue) 
	{
		$actionCount['totals']['total_raised']++;

		if($usefulValue['action_status']==0)
			$actionCount['not_done']['late']++;
		else if($usefulValue['action_status']==1)
			$actionCount['not_done']['ongoing']++;

		$graphStackedBarAction[$usefulValue['review_type']]['name']=$usefulValue['review_type'];
		$graphStackedBarAction[$usefulValue['review_type']]['criteria_status'][$usefulValue['action_status']]++;
		if(array_sum($graphStackedBarAction[$usefulValue['review_type']]['criteria_status']) > $biggestBarStackedBarAction) $biggestBarStackedBarAction=array_sum($graphStackedBarAction[$usefulValue['review_type']]['criteria_status']);
	
		if(!empty($usefulValue['rid_id']))
		{
			$ridCount['totals']['total_raised']++;

			if($usefulValue['action_status']==0)
				$ridCount['not_done']['late']++;
			else if($usefulValue['action_status']==1)
				$ridCount['not_done']['ongoing']++;

			$graphStackedBarRid[$usefulValue['review_type']]['name']=$usefulValue['review_type'];
			$graphStackedBarRid[$usefulValue['review_type']]['criteria_status'][$usefulValue['action_status']]++;
			if(array_sum($graphStackedBarRid[$usefulValue['review_type']]['criteria_status']) > $biggestBarStackedBarRid) $biggestBarStackedBarRid=array_sum($graphStackedBarRid[$usefulValue['review_type']]['criteria_status']);
		}

	}
}

if(empty($reviewCount['types_done']['total'])) $reviewCount['types_done']['total']=0;
if(empty($reviewCount['types_planned']['total'])) $reviewCount['types_planned']['total']=0;
if(empty($actionCount['totals']['total_raised'])) $actionCount['totals']['total_raised']=0;
if(empty($actionCount['not_done']['late'])) $actionCount['not_done']['late']=0;
if(empty($actionCount['not_done']['ongoing'])) $actionCount['not_done']['ongoing']=0;
if(empty($ridCount['totals']['total_raised'])) $ridCount['totals']['total_raised']=0;
if(empty($ridCount['not_done']['late'])) $ridCount['not_done']['late']=0;
if(empty($ridCount['not_done']['ongoing'])) $ridCount['not_done']['ongoing']=0;

$answer='';

?>OK|||overview&&&<?php

//Reviews
?><div style="font-size:24px; margin-top:30px;"><span style="font-size:36px;"><?=$reviewCount['types_done']['total']?></span> <?=($reviewCount['types_done']['total']==1)?'review':'reviews'?> done. <span style="font-size:36px;"><?=$reviewCount['types_planned']['total']?></span> <?=($reviewCount['types_planned']['total']==1)?'review':'reviews'?> planned.</div><?php
if(!empty($graphStackedBar))
{
	$answer.='&&&test---'.json_encode($graphStackedBar).'---stackedBarOverview---'.$biggestBarStackedBar.'---'.count($graphStackedBar).'---reviewGroups';
	?><div id="reviewGroups" name="reviewGroups"></div><?php
	?><div style="font-size:10px;font-weight:bold;">Review Passed:<br /><?php
		?><span style="font-size:12px; color:#ef343f;">&#9632</span> - Red <?php
		?><span style="font-size:12px; color:#f8d707;">&#9632</span> - Amber <?php
		?><span style="font-size:12px; color:#81c314;">&#9632</span> - Green <?php
		?><span style="font-size:12px; color:#8400b5;">&#9632</span> - Planned <?php
	?></div><?php
}

//Actions
?><div style="font-size:24px; margin-top:30px;"><span style="font-size:36px;"><?=$actionCount['totals']['total_raised']?></span> <?=($actionCount['totals']['total_raised']==1)?'action':'actions'?> raised. <span style="font-size:36px;"><?=$actionCount['not_done']['ongoing']?></span> <?=($actionCount['not_done']['ongoing']==1)?'action':'actions'?> ongoing. <span style="font-size:36px;"><?=$actionCount['not_done']['late']?></span> <?=($actionCount['not_done']['late']==1)?'action':'actions'?> overdue.</div><?php
if(!empty($graphStackedBarAction))
{
	$answer.='&&&test2---'.json_encode($graphStackedBarAction).'---stackedBarOverview---'.$biggestBarStackedBarAction.'---'.count($graphStackedBarAction).'---actionGroups';
	?><div id="actionGroups" name="actionGroups"></div><?php
	?><div style="font-size:10px;font-weight:bold;">Action Status:<br /><?php
		?><span style="font-size:12px; color:#ef343f;">&#9632</span> - Red <?php
		?><span style="font-size:12px; color:#f8d707;">&#9632</span> - Amber <?php
		?><span style="font-size:12px; color:#81c314;">&#9632</span> - Green <?php
		?><span style="font-size:12px; color:#0088cf;">&#9632</span> - Blue <?php
	?></div><?php
}

//RIDs
?><div style="font-size:24px; margin-top:30px;"><span style="font-size:36px;"><?=$ridCount['totals']['total_raised']?></span> <?=($ridCount['totals']['total_raised']==1)?'RID':'RIDs'?> raised. <span style="font-size:36px;"><?=$ridCount['not_done']['ongoing']?></span> <?=($ridCount['not_done']['ongoing']==1)?'RID':'RIDs'?> ongoing. <span style="font-size:36px;"><?=$ridCount['not_done']['late']?></span> <?=($ridCount['not_done']['late']==1)?'RID':'RIDs'?> overdue.</div><?php
if(!empty($graphStackedBarRid))
{
	$answer.='&&&test3---'.json_encode($graphStackedBarRid).'---stackedBarOverview---'.$biggestBarStackedBarRid.'---'.count($graphStackedBarRid).'---ridGroups';
	?><div id="ridGroups" name="ridGroups"></div><?php
	?><div style="font-size:10px;font-weight:bold;">RID Status:<br /><?php
		?><span style="font-size:12px; color:#ef343f;">&#9632</span> - Red <?php
		?><span style="font-size:12px; color:#f8d707;">&#9632</span> - Amber <?php
		?><span style="font-size:12px; color:#81c314;">&#9632</span> - Green <?php
		?><span style="font-size:12px; color:#0088cf;">&#9632</span> - Blue <?php
	?></div><?php
}

echo $answer;

storeSession($SESSION);

?>