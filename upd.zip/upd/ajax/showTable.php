<?php
//echo "maintable view";
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

//JFM 28_10_15
//foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
//foreach($_POST as $k=>&$v)$POST[$k]=addslashes($v);

$GET = cleanArray($_GET);
$POST = cleanArray($_POST);
$check = checkExternal($SESSION);
//maheswari
if(!getFilter('program','filter',0,$SESSION)){
	?>OK|||area_only<?php
}
//JFM 03_06_14
else if(!getFilter('area','filter',0,$SESSION) || !getFilter('program','filter',0,$SESSION) || !getFilter('msn','filter',0,$SESSION) || !getFilter('coe','filter',0,$SESSION)){
	?>OK|||no_program_coe_msn<?php
}else{
    
	$included=1;
	require_once('../../common/php/common.php');
        
	require_once('../../support.php');
	require_once('../support/revMan.php');
        
	require_once('../ajax/removeTableCache.php');
        
	function drawHeader($mainHeader,&$SESSION,$editableCaC,$reviewProfileList,$colCount,$reviewType,$reviewCounter,$responsible,$criteriaStructure,$criteriaCount)
	{	
            
       $check = checkExternal($SESSION);
		?><thead class="mainTableHead" style="position: fixed;z-index: 100;margin-top: -10px;"><?php
		//JFM 15_09_15 - START!
		//This post-processes a whole load of stuff so the table looks nice.
		
		$countLeft = 0;
		$countRight = 0;
                
                //file_put_contents('filename.txt', print_r($SESSION, true));by shreya
                //print_r($SESSION['table']);
                //print_r($SESSION['table']['review_planning']['ca']);
		foreach($SESSION['table']['review_planning']['ca'] as $k=>$v) //Count how many colmuns are displayed for WP/CA side.
		{//file_put_contents('cardfoul.txt', print_r($v, true));
//code for displaying menus as per user type!
            if($check==1 && ($k == 'progress_trend' ||$k == 'risk_red' || $k == 'risk_green' ||  $k == 'risk_blue' || $k == 'risk_amber' ))
                        continue;
      if(getFilter($k,'hide',0,$SESSION)!=1)
			{
				//JFM 08_06_16
				if(
					($k=='risk_red'   && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][0]==1) ||
					($k=='risk_amber' && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][1]==1) ||
					($k=='risk_green' && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][2]==1) ||
					($k=='risk_blue'  && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][3]==1)
					)
				{
					
				}
				else
					$countLeft++;
			}
		}

		if($colCount)
		{
			foreach ($colCount as $key => $value) //Count how many columns there are for all the review type columns.
			{
				$countRight+=$value;
			}
		}

		$countRight+=count($reviewProfileList);
                      
		/*?><div class="outer_flask"><?php*/
		?><tr class="dqrpHead"><?php
			?><td style="padding-top:5px;padding-left:5px;"><?php
				?><ul class="top-level-main"><?php

				?><li onMouseOver="$('tools_main_table').src='../common/img/xtools.png';" onMouseOut="$('tools_main_table').src='../common/img/tools.png';"><?php
					?><img id="tools_main_table" width="20px" src="../common/img/tools.png" /><?php

					?><ul class="second-level-main"><?php
						?><li onclick="openForm('columnConfig','',false,'GET');openSideElement('review','cfc');">Hide & Display Columns</li><?php
						?><li onclick="ajaxRequest('ajax/setView.php?filterName=dates_cw&value=<?=(getFilter('dates_cw','filter',0,$SESSION)==1)?0:1?>','restartMainTable',true,'GET');">Toggle dates as CW</li><?php
					?></ul><?php
				?></li><?php
				?></ul><?php
			?></td><?php


			/*?><td style="text-align:left;padding-top:5px;padding-left:5px;" onclick="openForm('columnConfig','',false,'GET');openSideElement('review','cfc');"><img onMouseOut="nd();" onMouseOver="overlib('Customise Table', ABOVE);" style="height:16px; cursor:pointer;" src="../common/img/tools.png"></td><?php*/
			?><td colspan="<?=$countLeft?>" style="text-align:left;">&#x2190; <u><i>Customise this table!</i></u></td><?php
			?><td style="border-left:1px solid #FFFFFF;"></td><?php
			?><td colspan="<?=$countRight?>" style="font-weight:bold;text-align:left;border-bottom:1px solid #FFFFFF;height:18px;">Review Types</td><?php
		?></tr><?php

		//JFM 15_09_15 - END!

		?><tr class="dqrpHead"><?php
			?><td class="dqrpHead"rowspan="<?=($mainHeader==1)?4:3?>"valign="bottom"><?php
				if($mainHeader==1)
				{
					?><input class="popUpBtnBlue"id="popUpBtn_0_0" onClick="popUpOpt('tbl',[0,0]);" type="button" value="&#8801;"><div class="popUpMenu"id="popUpDiv_0_0"></div><?php
				}
			?></td><?php
			$riskColCount=0;
			$statusMappingArray=array("review_red_action" => 0, "review_amber_action" => 1, "review_green_action" => 2, "review_blue_action" => 3,
									  "review_red_rid" => 0, "review_amber_rid" => 1, "review_green_rid" => 2, "review_blue_rid" => 3,
									  "risk_red" => 0, "risk_amber" => 1, "risk_green" => 2, "risk_blue" => 3);

			foreach($SESSION['table']['review_planning']['ca'] as $k=>$v)
			{
                                 if($check == 1 && ($k == 'progress_trend' ||$k == 'risk_red' || $k == 'risk_green' ||  $k == 'risk_blue' || $k == 'risk_amber' ))
                                {
                                    continue;
                                }
                                else
                                {
				if(getFilter($k,'hide',0,$SESSION)!=1)
				{
					switch($k)
					{
						case 'risk_red':
						case 'risk_amber':
						case 'risk_green':
						case 'risk_blue': //JFM 27_03_14
							if($SESSION['disabled_statues'][$SESSION['object']['risk_status']][$statusMappingArray[$k]] != 1) //JFM 13_05_16
							{
								$riskColCount++;
							}
						break;
						default:
							?><td rowspan="3"><?=$v['title']?></td><?php
						break;
					}
				}
      }
			}
                        //header risks-addedbyshreya
			if($riskColCount>0){?><td colspan="<?=$riskColCount?>">Risks</td><?php }
			if(is_array($reviewProfileList))
			{
				foreach($reviewProfileList as $k=>$v)
				{
					if($colCount[$k]>0 && $reviewType[$v]['review_type_hidden']==0)
					{
						?><td colspan="<?=$colCount[$k]+$criteriaCount[$k]+1?>" style="font-weight:bold;border-left:1px solid #FFFFFF;"><?=$reviewType[$v]['review_type']?></td><?php //JFM 15_09_15
					}
				}
			}
		?></tr><?php

		?><tr class="dqrpHead"><?php
                
		if($check != 1){
			if(getFilter('risk_red'		,'hide',0,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][0] != 1){	?><td rowspan="2"><img src="../common/img/r20.png"></td><?php }
			if(getFilter('risk_amber'	,'hide',0,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][1] != 1){	?><td rowspan="2"><img src="../common/img/a20.png"></td><?php }
			if(getFilter('risk_green'	,'hide',0,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][2] != 1){	?><td rowspan="2"><img src="../common/img/g20.png"></td><?php }
			if(getFilter('risk_blue'	,'hide',0,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][3] != 1){	?><td rowspan="2"><img src="../common/img/x20.png"></td><?php }}

			if(is_array($reviewProfileList))
			{
				foreach($reviewProfileList as $reviewId=>$reviewTypeId)
				{
					if($colCount[$reviewId]>0 && $reviewType[$reviewTypeId]['review_type_hidden']==0)
					{

						/*?><td rowspan="2" valign="bottom" style="border-left:1px solid #FFFFFF;"><input class="popUpBtnBlue"id="popUpBtn_0_<?=$reviewId?>" onClick="popUpOpt('tbl',[0,<?=$reviewId?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpDiv_0_<?=$reviewId?>"></div></td><?php*/ //JFM 15_09_15

						$compress=true;
						foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
						{
							if(getFilter($columnName,'hide',$reviewId,$SESSION)==1 && $columnName!='criteria_status')
							{
								$compress=false;
								break;
							}
						}
						//JFM 28_10_15
						?><td rowspan="2" valign="bottom" style="border-left:1px solid #FFFFFF;"><?php
							if($compress)
							{
								?><input class="popUpBtnBlue" style="text-align:center; cursor:pointer; font-size:22px;" onClick="nd(); displayReview('<?=$reviewId?>',1);" onMouseOut="nd();" onMouseOver="overlib('Compress <?=$reviewType[$reviewTypeId]['review_type']?> Columns', ABOVE, WRAP);" value="&#8612;" type="button"><?php //Compress
							}
							else
							{
								?><input class="popUpBtnBlue" style="text-align:center; cursor:pointer; font-size:22px;" onClick="nd(); displayReview('<?=$reviewId?>',0);" onMouseOut="nd();" onMouseOver="overlib('Expand <?=$reviewType[$reviewTypeId]['review_type']?> Columns', ABOVE, WRAP);" value="&#8614;" type="button"><?php //Expand
							}
						?></td><?php

						$actColCount=0;
						$ridColCount=0;
						$statusMappingArray=array("review_red_action" => 0, "review_amber_action" => 1, "review_green_action" => 2, "review_blue_action" => 3,
												  "review_red_rid" => 0, "review_amber_rid" => 1, "review_green_rid" => 2, "review_blue_rid" => 3,
												  "risk_red" => 0, "risk_amber" => 1, "risk_green" => 2, "risk_blue" => 3); //JFM 13_05_16

						foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
						{
							if(getFilter($columnName,'hide',$reviewId,$SESSION)!=1 && $columnName!='criteria_status')
							{ //JFM 18_03_14
								switch($columnName)
								{
									case 'review_red_action':
									case 'review_amber_action':
									case 'review_green_action':
									case 'review_blue_action': //JFM 27_03_14
										if($SESSION['disabled_statues'][$SESSION['object']['action_status']][$statusMappingArray[$columnName]] != 1) //JFM 13_05_16
										{
											$actColCount++;
										}
									break;
									case 'review_red_rid':
									case 'review_amber_rid':
									case 'review_green_rid':
									case 'review_blue_rid': //JFM 27_03_14
										if($SESSION['disabled_statues'][$SESSION['object']['rid_status']][$statusMappingArray[$columnName]] != 1) //JFM 13_05_16
										{
											$ridColCount++;
										}
									break;
									default:
										//JFM 13_05_16
										if(isset($SESSION['disabled_statues'][$SESSION['object'][$columnName]]))
										{
											if($SESSION['disabled_statues'][$SESSION['object'][$columnName]][0]==1 &&
												$SESSION['disabled_statues'][$SESSION['object'][$columnName]][1]==1 &&
												$SESSION['disabled_statues'][$SESSION['object'][$columnName]][2]==1 &&
												$SESSION['disabled_statues'][$SESSION['object'][$columnName]][3]==1)
											{
												
											}
											else
											{
												?><td rowspan="2"><?=$columnDetails['title']?></td><?php
											}
										}
										else
										{
											?><td rowspan="2"><?=$columnDetails['title']?></td><?php
										}
									break;
								}
							} 
						}
						if($ridColCount>0){?><td colspan="<?=$ridColCount?>">RIDs</td><?php }
						if($actColCount>0){?><td colspan="<?=$actColCount?>">Actions</td><?php }
					}
				}
			}
		?></tr><?php

		?><tr class="dqrpHead"><?php
			if(is_array($reviewProfileList))
			{
				foreach($reviewProfileList as $reviewId=>$reviewTypeId)
				{
                                    if($reviewType[$reviewTypeId]['review_type_hidden'] == 0) {
					$groupColor='#FFFFFF';
					if(is_array($criteriaStructure[$reviewId]))
					{
						foreach($criteriaStructure[$reviewId] as $groupId=>$group)
						{
							foreach($group as $criteriaPosition=>$criteriaId)
							{
								?><td style="background-color:<?=$groupColor?>;cursor:pointer;"><?=$criteriaPosition?></td><?php
							}
							$groupColor=($groupColor=='#FFFFFF')?'#E5E5E5':'#FFFFFF';
						}
					}
					
					if(getFilter('review_red_rid'		,'hide',$reviewId,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['rid_status']][0] != 1){		?><td><img src="../common/img/r20.png"></td><?php }
					if(getFilter('review_amber_rid'		,'hide',$reviewId,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['rid_status']][1] != 1){		?><td><img src="../common/img/a20.png"></td><?php }
					if(getFilter('review_green_rid'		,'hide',$reviewId,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['rid_status']][2] != 1){		?><td><img src="../common/img/g20.png"></td><?php }
					if(getFilter('review_blue_rid'		,'hide',$reviewId,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['rid_status']][3] != 1){		?><td><img src="../common/img/x20.png"></td><?php } //JFM 27_03_14
					if(getFilter('review_red_action'	,'hide',$reviewId,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['action_status']][0] != 1){	?><td><img src="../common/img/r20.png"></td><?php }
					if(getFilter('review_amber_action'	,'hide',$reviewId,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['action_status']][1] != 1){	?><td><img src="../common/img/a20.png"></td><?php }
					if(getFilter('review_green_action'	,'hide',$reviewId,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['action_status']][2] != 1){	?><td><img src="../common/img/g20.png"></td><?php }
					if(getFilter('review_blue_action'	,'hide',$reviewId,$SESSION)!=1 && $SESSION['disabled_statues'][$SESSION['object']['action_status']][3] != 1){	?><td><img src="../common/img/x20.png"></td><?php } //JFM 27_03_14
                                    }
				}
			}
		?></tr><?php
               
	}
        
	/*?><div class="outer"><?php*/
        
	function drawReviews(&$v,&$reviewProfileList,&$reviewType,&$caId,&$status,&$colCount,$criteriaStructure,&$i,&$b,&$SESSION,&$today,$criteriaCount)
	{
		$acitonStatusMappingArray=array("review_red_action" => 0, "review_amber_action" => 1, "review_green_action" => 2, "review_blue_action" => 3);
		$ridStatusMappingArray=array("review_red_rid" => 0, "review_amber_rid" => 1, "review_green_rid" => 2, "review_blue_rid" => 3); //JFM 13_05_16

		if(is_array($reviewProfileList))
		{
			foreach($reviewProfileList as $reviewId=>&$rp)
			{
				if($colCount[$reviewId]>0 && $reviewType[$rp]['review_type_hidden'] == 0)
				{
					$rTxt='review_'.$reviewId;
                                        /*for the three lined icon before a review and vertical striaghtline is due to border -left :1px;*/
					?></div><?php
                                      
                                        ?><td  style="border-left:1px solid #e7e7e8;"><?php //JFM 15_09_15
                                          
						if($v['element_disabled']==0)
						{
							$fav = getFilter('fav','filter','fav_'.$caId.'_'.$reviewId,$SESSION);
							?><input class="popUpBtn"id="popUpBtn_<?=$caId?>_<?=$reviewId?>"onClick="popUpOpt('tbl',[<?=$caId?>,<?=$reviewId?>]); "type="button"value="&#8801;"><div class="popUpMenu"id="popUpDiv_<?=$caId?>_<?=$reviewId?>"></div><?php
							?><div class="favStar" id="fav_<?=$caId?>_<?=$reviewId?>" style="<?=($fav==1)?'':'display:none;'?>" onClick="popUpOpt('tbl',[<?=$caId?>,<?=$reviewId?>]);">&#9733;</div><?php //JFM 12_01_16
							/*?><span onclick="statusPopUpMenu('<?=$caId?>','<?=$reviewId?>');">TEST</span><?php*/
						}
						else
						{
							?><input class="popUpBtnD"type="button"value=""><?php
						}
					?></td><?php
					/*?></div><?php*/
					//JFM 30_09_13 - 11_03_14 - START!
					$found=false;
					$valid=false;
					$validationCompleteQry;
					//print_r($v);
					foreach ($v as $arrayName=>$arrayValue)
					{
						$foundReviewProfile=strpos($arrayName,$rTxt);
						if($foundReviewProfile===0)
						{
							$validationCompleteQry=SqlLi('SELECT validation_complete
															FROM dr_review AS r
																INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
																INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
															WHERE rp.review_profile_id='.$reviewId.'
															AND ra.ca = '.$v['ca_id'].'
															AND r.msn='.getFilter('msn','filter',0,$SESSION));
															
							if($validationCompleteQry[0]['validation_complete']==2) $valid=true;
							
							$found=true;
							break;
						}
					}
					
					if($found && $valid && $v['element_disabled']!=1) //JFM 15_09_15
					{
						foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
						{
							if(getFilter($columnName,'hide',$reviewId,$SESSION)!=1 && $columnName!='criteria_status') //JFM 18_03_14
							{
								//JFM 13_05_16
								if((isset($acitonStatusMappingArray[$columnName]) && $SESSION['disabled_statues'][$SESSION['object']['action_status']][$acitonStatusMappingArray[$columnName]] == 1)
									|| (isset($ridStatusMappingArray[$columnName]) && $SESSION['disabled_statues'][$SESSION['object']['rid_status']][$ridStatusMappingArray[$columnName]] == 1)) //JFM 13_05_16
								{
									//Honestly, I don't know if it's because i'm really tired but my brain cannot figure out how else to write this if statement.
								}
								else if(isset($SESSION['disabled_statues'][$SESSION['object'][$columnName]]))
								{
									if($SESSION['disabled_statues'][$SESSION['object'][$columnName]][0]==1 &&
										$SESSION['disabled_statues'][$SESSION['object'][$columnName]][1]==1 &&
										$SESSION['disabled_statues'][$SESSION['object'][$columnName]][2]==1 &&
										$SESSION['disabled_statues'][$SESSION['object'][$columnName]][3]==1)
									{
										
									}
									else
										drawReviewElement($v,$caId,$columnName,$columnDetails,$reviewId,$i,$SESSION,$today,$status,$criteriaStructure);
								}
								else
									drawReviewElement($v,$caId,$columnName,$columnDetails,$reviewId,$i,$SESSION,$today,$status,$criteriaStructure);
							}
						}
					}
					else
					{
						$countColumnsDisplayed=0;
						
						foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
						{
							if(getFilter($columnName,'hide',$reviewId,$SESSION)!=1 && $columnName!='criteria_status') 
							{
								//JFM 13_05_16
								if((isset($acitonStatusMappingArray[$columnName]) && $SESSION['disabled_statues'][$SESSION['object']['action_status']][$acitonStatusMappingArray[$columnName]] == 1)
								|| (isset($ridStatusMappingArray[$columnName]) && $SESSION['disabled_statues'][$SESSION['object']['rid_status']][$ridStatusMappingArray[$columnName]] == 1)) //JFM 13_05_16
								{
									//Honestly, I don't know if it's because i'm really tired but my brain cannot figure out how else to write this if statement.
								}
								else if(isset($SESSION['disabled_statues'][$SESSION['object'][$columnName]]))
								{
									if($SESSION['disabled_statues'][$SESSION['object'][$columnName]][0]==1 &&
										$SESSION['disabled_statues'][$SESSION['object'][$columnName]][1]==1 &&
										$SESSION['disabled_statues'][$SESSION['object'][$columnName]][2]==1 &&
										$SESSION['disabled_statues'][$SESSION['object'][$columnName]][3]==1)
									{
										
									}
									else
										$countColumnsDisplayed++;
								}
								else
									$countColumnsDisplayed++; //JFM 18_03_14
							}
						}

						if($v['review_'.$reviewId.'_review_status']==4 && $v['element_disabled']!=1)  //JFM 02_10_14 - JFM 15_09_15
						{ 
							?><td><img height="20" src="../common/img/na20.png"></td><?php
							if($colCount[$reviewId]>1)
							{
								?><td style="color:#e7e7e8; cursor:pointer;" colspan="<?=($countColumnsDisplayed+$criteriaCount[$reviewId]-1)?>" onClick="openReviewForm('<?=$reviewId?>','ca');openSideElement('<?=$v['ca_id']?>','rev');">Review Not Applicable</td><?php
							}
						}
						else 
						{
									/*
									* Fix for : US #19 - Change workflow for creating a design review 
									* Added for general information above checklist
									* Version: 4.3
									* Fixed By: Infosys Limited
									*/
							$message='';
						$statusInfo = SqlLi('SELECT planned FROM dr_review_status WHERE review_profile='.$reviewId.' AND ca = '.$v['ca_id'].' AND msn='.getFilter('msn','filter',0,$SESSION));
							//JFM 28_10_15
							
							if($v['element_disabled']==1) $message='WP/CA Not Applicable';
                                        else if($found && $validationCompleteQry[0]['validation_complete']==1) {
                                           if($statusInfo[0]['planned'] == '0000-00-00') $message=' No Review Planned - Checklist Validation Commencing';
										   elseif($statusInfo[0]['planned']) $message=' Review Planned - Checklist Validation Commencing';
                                                                                                                                else $message=' No Review Planned - Checklist Validation Commencing';
                                                                                                                }
                                                                                                                else if ($found) {
                                                                                                                                if($statusInfo[0]['planned'] == '0000-00-00') $message=' No Review Planned - Checklist Customization commencing';
                                                                                                                                elseif($statusInfo[0]['planned']) $message=' Review Planned - Checklist Customization commencing';
																																else $message='  No Review Planned - Checklist Customization commencing';
                                                                                                                }
                                                                                                                else        {
                                                                                                                                if ($statusInfo[0]['planned'] == '0000-00-00') $message=' No Review Planned - No Checklist Defined';
																																elseif($statusInfo[0]['planned']) $message=' Review Planned - No Checklist Defined';
                                                                                                                                else $message=' No Review Planned - No Checklist Defined';
                                                                                                                }

                                                        /*?><div class="inner"<?php*/
							?><td style="color:<?=($v['element_disabled']==1)?'#e7e7e8':'grey'?>; cursor:pointer;" <?=($message!='WP/CA Not Applicable')?'onClick="openReviewForm(\''.$reviewId.'\',\'ca\');openSideElement(\''.$v['ca_id'].'\',\'rev\');"':''?> colspan="<?=($countColumnsDisplayed+$criteriaCount[$reviewId])?>"><?=$message?></td><?php
                                                        /*?></div><?php*/
                                                        
                                                }
					}
					//JFM 30_09_13 - 11_03_14 - END!
				}
			}
		}
	}
	/*?></div><?php*/
	//*************************************************************************************************************************************
	
	function listTable(&$SESSION,$GET,$POST,$p12,&$reviewType)
	{	
		$reviewProfileList=allowedReviews($SESSION,'view','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION));
		$editablePerimeter=perimeterPermission($SESSION,'edit');
                //what all perimeters are allowed to view in structure management msn till msn 0124
		$check = checkExternal($SESSION);
		$reviewCounter=0;
		$criteriaStatusCounter=0;
		$acitonStatusMappingArray=array("review_red_action" => 0, "review_amber_action" => 1, "review_green_action" => 2, "review_blue_action" => 3);
		$ridStatusMappingArray=array("review_red_rid" => 0, "review_amber_rid" => 1, "review_green_rid" => 2, "review_blue_rid" => 3); //JFM 13_05_16

		if(is_array($reviewProfileList))
		{
			foreach($reviewProfileList as $reviewId=>$v)
			{
				foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
				{
					if(getFilter($columnName,'hide',$reviewId,$SESSION)!=1 && $columnName!='criteria_status') //JFM 18_03_14
					{
						//JFM 13_05_16
						if((isset($acitonStatusMappingArray[$columnName]) && $SESSION['disabled_statues'][$SESSION['object']['action_status']][$acitonStatusMappingArray[$columnName]] == 1)
						|| (isset($ridStatusMappingArray[$columnName]) && $SESSION['disabled_statues'][$SESSION['object']['rid_status']][$ridStatusMappingArray[$columnName]] == 1)) //JFM 13_05_16
						{
							//Honestly, I don't know if it's because i'm really tired but my brain cannot figure out how else to write this if statement.
						}
						else if(isset($SESSION['disabled_statues'][$SESSION['object'][$columnName]]))
						{
							if($SESSION['disabled_statues'][$SESSION['object'][$columnName]][0]==1 &&
								$SESSION['disabled_statues'][$SESSION['object'][$columnName]][1]==1 &&
								$SESSION['disabled_statues'][$SESSION['object'][$columnName]][2]==1 &&
								$SESSION['disabled_statues'][$SESSION['object'][$columnName]][3]==1)
							{
								
							}
							else
								$colCount[$reviewId]++;
						}
						else
							$colCount[$reviewId]++;
					}
				}
				if($colCount[$k]>0)$reviewCounter++;
			}
		}

		$srchStart=microtime(true);
		
		$editableCa=array();
		$perimeterList=allowedSimpleObject('perimeter','perimeter',$SESSION,'c_','program='.getFilter('program','filter',0,$SESSION));
                //print_r($perimeterList);perimeter list
               // print_r($perimeterList);
                //file_put_contents('D:\XAMMP\htdocs\art\design_reviews\dr_report\ajax\grab.txt',$perimeterList);
		if(is_array($perimeterList))
		{
			foreach($perimeterList as $k=>$v)
			{
				if(checkPermission('ca_id','edit',$k,'check',$SESSION)==1)
					$editableCa[$k]=1;
			}
		}
		$editableCaC=count($editableCa);
			
		$reviewType=SqlAsLi('SELECT review_type_id,review_type,review_type_description,review_type_hidden FROM dr_review_type','review_type_id');
		//print_r($reviewType);
                //file_put_contents('D:\XAMMP\htdocs\art\design_reviews\dr_report\ajax\grab1.txt',$reviewType);
                 //file_put_contents('D:\XAMMP\htdocs\art\design_reviews\dr_report\support\grab1.txt',$reviewType);
		?>OK|||<?php
		
		$status=array('r','a','g','x'); //JFM 27_03_14

		fltUpd($POST,$SESSION,1); //Filter Update from GET & Save in DB	

		if($POST['table_cache_id']=='' || !cacheExists($POST['table_cache_id']))
		{
			$first=1;
			$i=0;
			$tableCacheId=newTableCacheId($SESSION);

			getRevData($status,$caInfo,$reviewProfileList,$SESSION,$responsible,$validCriteriaStatus);
			
			storeCache('csv',$tableCacheId,$caInfo);
                        ?><div class="outer"><?php
                        
                        
			?><table class="mainTable" id="table_<?=$tableCacheId?>" cellspacing="1"><?php
                        
			drawHeader(1,$SESSION,$editableCaC,$reviewProfileList,$colCount,$reviewType,$reviewCounter,$responsible,$criteriaStructure,$criteriaCount);
		}
		else
		{
			$first=0;
			$tableCacheId=$POST['table_cache_id'];
			$i=$SESSION['table_total_row'][$tableCacheId];
			$caInfo=loadCache('html',$tableCacheId);
			?><table><?php
		}
		
		//Write Sort & Filter icons VV
		if($first==1)
		{
			?><tr><?php
			foreach($SESSION['table']['review_planning']['ca'] as $k=>&$v)
			{
                                     if($check == 1 && ($k == 'progress_trend' ||$k == 'risk_red' || $k == 'risk_green' ||  $k == 'risk_blue' || $k == 'risk_amber' ))
                                {
                                    continue;
                                }
				if(getFilter($k,'hide',0,$SESSION)!=1)
				{
					//JFM 08_06_16
					if(
						($k=='risk_red'   && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][0]==1) ||
						($k=='risk_amber' && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][1]==1) ||
						($k=='risk_green' && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][2]==1) ||
						($k=='risk_blue'  && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][3]==1)
						)
					{
						
					}
					else
						drawFilterIcon('review_planning','ca',$k,0,$SESSION);
				}
			}
			
			if(is_array($reviewProfileList))
			{
				foreach($reviewProfileList as $reviewId=>&$reviewTypeId)
				{
					if($colCount[$reviewId]>0 && $reviewType[$reviewTypeId]['review_type_hidden'] == 0)
					{
						?><td class="flt"nowrap style="border-left:1px solid #FFFFFF;"></td><?php //JFM 15_09_15
					}
					foreach($SESSION['table']['review_planning']['review'] as $columnName=>&$columnDetails)
					{
						if(getFilter($columnName,'hide',$reviewId,$SESSION)!=1 && $columnName!='criteria_status') //JFM 18_03_14
						{
							//JFM 13_05_16
							if((isset($acitonStatusMappingArray[$columnName]) && $SESSION['disabled_statues'][$SESSION['object']['action_status']][$acitonStatusMappingArray[$columnName]] == 1)
							|| (isset($ridStatusMappingArray[$columnName]) && $SESSION['disabled_statues'][$SESSION['object']['rid_status']][$ridStatusMappingArray[$columnName]] == 1)) //JFM 13_05_16
							{
								//Honestly, I don't know if it's because i'm really tired but my brain cannot figure out how else to write this if statement.
							}
							else if(isset($SESSION['disabled_statues'][$SESSION['object'][$columnName]]))
							{
								if($SESSION['disabled_statues'][$SESSION['object'][$columnName]][0]==1 &&
									$SESSION['disabled_statues'][$SESSION['object'][$columnName]][1]==1 &&
									$SESSION['disabled_statues'][$SESSION['object'][$columnName]][2]==1 &&
									$SESSION['disabled_statues'][$SESSION['object'][$columnName]][3]==1)
								{
									
								}
								else
								{
									$colSpan=($columnName=='criteria_status')?$criteriaCount[$reviewId]:'';
                                                                        if($reviewType[$reviewTypeId]['review_type_hidden'] == 0) {
                                                                            drawFilterIcon('review_planning','review',$columnName,$reviewId,$SESSION,'',$colSpan,$reviewType[$reviewTypeId]['review_type'].' '.$columnDetails['filter']);
                                                                        }									
								}
							}
							else
							{
                                                            $colSpan=($columnName=='criteria_status')?$criteriaCount[$reviewId]:'';
                                                            if($reviewType[$reviewTypeId]['review_type_hidden'] == 0) {								
								drawFilterIcon('review_planning','review',$columnName,$reviewId,$SESSION,'',$colSpan,$reviewType[$reviewTypeId]['review_type'].' '.$columnDetails['filter']);
                                                            }
							}
						}
					}
				}
			}
			
			?></tr><?php
			?></thead><?php
		}
		//Write Sort & Filter icons ^^
		 
		//Write data VV
		if($caInfo)
		{//print_r($caInfo);
                //$avghy=var_dump($caInfo);
                 //file_put_contents('D:\XAMMP\htdocs\art\design_reviews\dr_report\ajax\grab.txt',$avghy);
                    //file_put_contents('D:\XAMMP\htdocs\art\design_reviews\dr_report\ajax\garve.txt',$caInfo);
                   // file_put_contents('D:\XAMMP\htdocs\art\design_reviews\dr_report\support\grab.txt', print_r($caInfo, true));
			
                    ?><tbody class="mainTableBody" style="padding-top: 90px !important;position: relative;display: table-cell;"><?php
			$today=date("Y-m-d");
			$maxResults=getFilter('max_results','view',0,$SESSION);
			$rowSubCounter=0;
			$b=false;
			unset($ca);
			unset($v); // PHP Bug #29992
			foreach($caInfo as $ca=>$v)
			{ //print_r($v);
                           // file_put_contents('D:\XAMMP\htdocs\art\design_reviews\dr_report\support\grab.txt', print_r($caInfo, true));
				if($rowSubCounter<$maxResults)
				{
					if(getFilter('repeat_header','view',0,$SESSION)==1 && $i%getFilter('header_frequency','view',0,$SESSION)==0 && $i!=0)
					{
						flush();
						drawHeader(0,$SESSION,$editableCaC,$reviewProfileList,$colCount,$reviewType,$reviewCounter,$responsible,$criteriaStructure,$criteriaCount);
					}
					
					$ca=$v['ca'];
					$caId=$v['ca_id'];
					if($b){
                                           
                                            ?><tr onMouseOver="setRowColour(this,'#e7e7ff');" onMouseOut="setRowColour(this,'#ffffff');" class="criteriaRow"bgcolor="#FFFFFF"id="sr_<?=$i?>"><?php 
                                            
                                        }
					else{
                                            ?><tr onMouseOver="setRowColour(this,'#e7e7ff');" onMouseOut="setRowColour(this,'#ffffff');" class="criteriaRow"bgcolor="#FFFFFF"id="sr_<?=$i?>"><?php
                                            
                                            
                                        }
						
						?><td  class="fix" align="left"id="e_<?=$i?>"nowrap style="padding:0px 5px 0px 5px; background-color:#6f95ab;"><?php //JFM 08_06_16
						/*this is for the checkbox*/	
                             ?><input id="caChk-<?=$i?>"onClick="selectCaElement('<?=$i?>');"type="checkbox"><?php
							if($v['element_disabled']==1 && $editablePerimeter[$v['perimeter_id']]!=1)
							{//echo "inside table";
								?><input id="h_<?=$caId?>_0"type="hidden"><?php
							}
							else
							{
								/* JFM 28_10_15 ?><input class="popUpBtnBlue"id="popUpBtn_<?=$caId?>_0" onClick="popUpOpt('tbl',[<?=$caId?>,0,<?=$v['cawp_id']?>,<?=$v['element_disabled']?>,<?=$editablePerimeter[$v['perimeter_id']]?>]);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpDiv_<?=$caId?>_0"></div><?php*/
								?><input id="h_<?=$caId?>_0"type="hidden"><?php
							}
						?></td><?php
                                                //this is for displaying permiter wp and ca
                                               // print_r($SESSION['table']['review_planning']['ca']);
						foreach($SESSION['table']['review_planning']['ca'] as $columnName=>&$columnDetails)
						{       if($check==1 && ($columnName == 'progress_trend' || $columnName == 'risk_red'  || $columnName == 'risk_green' || $columnName == 'risk_blue' || $columnName == 'risk_amber'))
                                                            continue;
							if(getFilter($columnName,'hide',0,$SESSION)!=1)
							{
								//JFM 08_06_16
								if(
									($columnName=='risk_red'   && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][0]==1) ||
									($columnName=='risk_amber' && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][1]==1) ||
									($columnName=='risk_green' && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][2]==1) ||
									($columnName=='risk_blue'  && $SESSION['disabled_statues'][$SESSION['object']['risk_status']][3]==1)
									)
								{
									
								}
								else
								
                                                                    drawReviewElement($v,$caId,$columnName,$columnDetails,0,$i,$SESSION,$today,$status);
                                                                   
							}
						}
	
						drawReviews($v,$reviewProfileList,$reviewType,$caId,$status,$colCount,$criteriaStructure,$i,$b,$SESSION,$today,$criteriaCount);
	
						?><input id="cawp_<?=$i?>"type="hidden"value="<?=$ca.'%'.$v['wp']?>"><?php
                                              
					?></tr><?php
					$i++;
					$rowSubCounter++;
					$b=($b)?false:true;
				}
			}
			$SESSION['table_total_row'][$tableCacheId]=$i;
			?></tbody><?php
		}
		else
		{
			?><tr class="criteriaRow"bgcolor="#FFFFFF"><td align="center" class="actRow" colspan="30">No results found for the specified criterias</td></tr><?php
		}
		
		if(is_array($caInfo))
		{
			$j=0;
			foreach($caInfo as $k=>&$v){
				if($j<$maxResults){
					unset($caInfo[$k]);
				}
				$j++;
			}
			storeCache('html',$tableCacheId,$caInfo);
		}

		if($first==1)
		{
			?><tr id="notFoundHead" style="display:none;"><?php
				?><td class="titleLogin" colspan="6" align="center">&nbsp;</td><?php
			?></tr><?php
			?><tr id="notFound" style="display:none;"><?php
				?><td class="stdRow" colspan="6" align="center"><font color="#999999">No Documents Found</font></td><?php
			?></tr><?php
			?></table><?php
                        ?></div><?php
                        
                        /*end of the table*/
			$resultCount=count($caInfo);
			$SESSION['table_result_count'][$tableCacheId]=($resultCount==0)?$i:$resultCount+$maxResults;
			
			nextResultButton($resultCount,$tableCacheId,'showTable','review_planning',$displayedResults,$SESSION);
			
			?><div id="ajaxOut"></div><?php
			
			$srchEnd=number_format(microtime(true)-$srchStart,2);
			
			?><input id="mainTableCacheId"type="hidden"value="<?=$tableCacheId?>"><?php
			?><input id="result_count"type="hidden"value="<?=number_format($SESSION['table_result_count'][$tableCacheId],0,'','.')?>"><?php
			?><input id="processing_time"type="hidden"value="<?=($srchEnd<0)?1+$srchEnd:$srchEnd?>"><?php
		}
		else
		{
			?></table><?php
		}
               
	}

	if($POST['removeTableCache']!=''){
		removeCache($POST['removeTableCache']);
		echo 'OK|||';
	}

	//$listTableStart=microtime(true);
	listTable($SESSION,$GET,$POST,$p12,$reviewType);
	//echo 'Total Time List Table: '.(microtime(true)-$listTableStart);

}
 
storeSession($SESSION);

?>