<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);

$currentFilter = getFilter('fav','filter','fav_'.$GET['ca'].'_'.$GET['reviewProfile'],$SESSION);

if($currentFilter == 1) $currentFilter = 0;
else $currentFilter = 1;

modifyFilter('fav','filter','fav_'.$GET['ca'].'_'.$GET['reviewProfile'],$currentFilter,$SESSION,1);

$answer = 'fav_'.$GET['ca'].'_'.$GET['reviewProfile'].'&&&'.$currentFilter;

storeSession($SESSION);
echo 'OK|||'.$answer;
?>