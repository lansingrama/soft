<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

function fillActionRidCalanderArray(&$array,$involvement,$dateType,$actionCode,$date,$description,$area,$programId,$coeId,$msnId,$actionId,$caId)
{
	$array[$involvement][$dateType][$actionCode]['date']=$date;
	$array[$involvement][$dateType][$actionCode]['description']=$description;
	$array[$involvement][$dateType][$actionCode]['area']='msn_'.$msnId.'_coe_'.$coeId.'_program_'.$programId.'_area_'.$area;
	$array[$involvement][$dateType][$actionCode]['action_id']=$actionId;
	$array[$involvement][$dateType][$actionCode]['ca_id']=$caId;
}

$viewAsUserId		=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
$calandarDates		=array('No Date', 'Overdue', 'Last 7 Days', 'Today', 'Tomorrow', 'This Week', 'This Month', 'Next Month');

$today				=strtotime(date("Y-m-d"));
$tomorrow			=strtotime("tomorrow");
$nextMonday			=strtotime("next monday");
$lastDayOfThisMonth	=date('U', mktime(-1, 0, 0, date("m", strtotime("next month")), 1, date("Y",strtotime("next month"))));
$lastDayOfNextMonth	=date('U', mktime(-1, 0, 0, date("m", strtotime("+2 month")), 1, date("Y",strtotime("+2 month"))));

//Actions
//---------------------------------------------------------------
$actionsArray=array();
$actionsTotal=array();
$actionsOther=array();
$actionsOther['holder']['total']=0;
$actionsOther['holder']['immediateAction']=0;
$actionsOther['validator']=0;

$siglumQry = SqlQ('SELECT department FROM c_user WHERE user_id = '.$viewAsUserId);
$siglum = $siglumQry['department'];


$actionQry1=SqlLi('SELECT DISTINCT
							act.action_id, act.action_holder, act.action_validator, act.action_completion, act.action_description, act.action_code, act.action_status,
							rid.rid_id, rid.rid_holder, rid.rid_validator, rid.rid_completion, rid.rid_title, rid.rid_code, rid.rid_status,
							rp.program, rp.coe, cmn.msn_id, rt.review_type_id, rp.review_profile_id, ca.ca_id, coe.area,
							u1.department AS action_holder_siglum, u2.department AS action_validator_siglum, u3.department AS rid_holder_siglum, u4.department AS rid_validator_siglum
						FROM dr_action 			AS act 
							INNER JOIN c_msn					AS cmn 	ON 	cmn.msn_id=act.msn
							INNER JOIN dr_action_applicability	AS app 	ON 	act.action_id=app.action
							INNER JOIN c_ca 					AS ca  	ON 	app.ca=ca.ca_id
							INNER JOIN c_coe 					AS coe 	ON 	ca.coe=coe.coe_id
							INNER JOIN dr_review_criterion		AS rc 	ON 	act.criteria=rc.review_criterion_id
							INNER JOIN dr_review_group 			AS rg 	ON 	rc.review_group=rg.group_id
							INNER JOIN dr_review_type 			AS rt 	ON 	rg.review_type=rt.review_type_id
							INNER JOIN dr_review_profile		AS rp   ON 	rp.program=cmn.program
																		AND rp.coe=coe.coe_id
																		AND rp.review_type=rt.review_type_id
							INNER JOIN c_cawp					AS cw	ON 	ca.ca_id=cw.ca
																		AND cmn.msn_id=cw.msn
							LEFT  JOIN dr_rid					AS rid 	ON 	act.rid=rid.rid_id
							LEFT  JOIN c_user 					AS u1 	on  u1.user_id = act.action_holder
							LEFT  JOIN c_user 					AS u2 	on  u2.user_id = act.action_validator
							LEFT  JOIN c_user 					AS u3 	on  u3.user_id = rid.rid_holder
							LEFT  JOIN c_user 					AS u4 	on  u4.user_id = rid.rid_validator
						WHERE (act.action_holder='.$viewAsUserId.' OR act.action_validator='.$viewAsUserId.' OR rid.rid_holder='.$viewAsUserId.' OR rid.rid_validator='.$viewAsUserId.'
								OR u1.department = '.$siglum.' OR u2.department = '.$siglum.' OR u3.department = '.$siglum.' OR u4.department = '.$siglum.')
						AND cawp_disabled=0');

$actionQry2=SqlLi('SELECT DISTINCT
							act.action_id, act.action_holder, act.action_validator, act.action_completion, act.action_description, act.action_code, act.action_status,
							rid.rid_id, rid.rid_holder, rid.rid_validator, rid.rid_completion, rid.rid_title, rid.rid_code, rid.rid_status,
							rp.program, rp.coe, cmn.msn_id, rt.review_type_id, rp.review_profile_id, ca.ca_id, coe.area,
							u1.department AS action_holder_siglum, u2.department AS action_validator_siglum, u3.department AS rid_holder_siglum, u4.department AS rid_validator_siglum
						FROM dr_action 			AS act 
							INNER JOIN c_msn					AS cmn 	ON 	cmn.msn_id=act.msn
							INNER JOIN dr_action_applicability	AS app 	ON 	act.action_id=app.action
							INNER JOIN c_ca 					AS ca  	ON 	app.ca=ca.ca_id
							INNER JOIN c_coe 					AS coe 	ON 	ca.coe=coe.coe_id
							INNER JOIN dr_review 				AS r 	ON 	act.review=r.review_id
							INNER JOIN dr_review_profile		AS rp   ON 	rp.program=cmn.program
																		AND rp.coe=coe.coe_id
																		AND r.review_profile=rp.review_profile_id
							INNER JOIN dr_review_type 			AS rt 	ON 	rp.review_type=rt.review_type_id
							INNER JOIN c_cawp					AS cw	ON 	ca.ca_id=cw.ca
																		AND cmn.msn_id=cw.msn
							LEFT  JOIN dr_rid					AS rid 	ON 	act.rid=rid.rid_id
							LEFT  JOIN c_user 					AS u1 	on  u1.user_id = act.action_holder
							LEFT  JOIN c_user 					AS u2 	on  u2.user_id = act.action_validator
							LEFT  JOIN c_user 					AS u3 	on  u3.user_id = rid.rid_holder
							LEFT  JOIN c_user 					AS u4 	on  u4.user_id = rid.rid_validator
						WHERE (act.action_holder='.$viewAsUserId.' OR act.action_validator='.$viewAsUserId.' OR rid.rid_holder='.$viewAsUserId.' OR rid.rid_validator='.$viewAsUserId.' 
								OR u1.department = '.$siglum.' OR u2.department = '.$siglum.' OR u3.department = '.$siglum.' OR u4.department = '.$siglum.')
						AND cawp_disabled=0');

$actions=array();

if(!empty($actionQry1) && !empty($actionQry2)) $actions=array_merge($actionQry1, $actionQry2);
else if (!empty($actionQry1)) $actions=$actionQry1;
else if (!empty($actionQry2)) $actions=$actionQry2;


if(!empty($actions))
{
	foreach ($actions as $action) 
	{
		$involvement='';
		/* $actionsTotal['total']++;

		switch ($action['action_status']) 
		{
			case 0:
				$actionsTotal['red']++;
			break;
			case 1:
				$actionsTotal['amber']++;
			break;
			case 2:
				$actionsTotal['green']++;
			break;
			case 3:
				$actionsTotal['blue']++;
			break;
		}  */

		$showGreenActions = 2;
		if(getFilter('greenAct','filter',0,$SESSION)) $showGreenActions = 3;

		if($action['action_status'] < $showGreenActions)
		{
			$actionCompletion=strtotime($action['action_completion']);

			if($action['action_holder']==$viewAsUserId)
			{
				$involvement='holder';
				$actionsOther['holder']['total']++;
				if($actionCompletion < $today) $actionsOther['holder']['immediateAction']++;
			}
			else if($action['action_validator']==$viewAsUserId)
			{
				$involvement='validator';
				$actionsOther['validator']++;
			}
			else if($action['action_holder_siglum']==$siglum || $action['action_validator_siglum']==$siglum)
			{
				$involvement='siglum';
				$actionsOther['siglum']++;
			}

			if($action['action_completion']=="0000-00-00") 												fillActionRidCalanderArray($actionsArray,$involvement,'No Date',$action['action_code'],$action['action_completion'],$action['action_description'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($actionCompletion<$today) 															fillActionRidCalanderArray($actionsArray,$involvement,'Overdue',$action['action_code'],$action['action_completion'],$action['action_description'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($actionCompletion==$today) 															fillActionRidCalanderArray($actionsArray,$involvement,'Today',$action['action_code'],$action['action_completion'],$action['action_description'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($actionCompletion==$tomorrow) 														fillActionRidCalanderArray($actionsArray,$involvement,'Tomorrow',$action['action_code'],$action['action_completion'],$action['action_description'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($actionCompletion<$nextMonday && $actionCompletion>$tomorrow) 						fillActionRidCalanderArray($actionsArray,$involvement,'This Week',$action['action_code'],$action['action_completion'],$action['action_description'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($actionCompletion<=$lastDayOfThisMonth && $actionCompletion>$nextMonday) 			fillActionRidCalanderArray($actionsArray,$involvement,'This Month',$action['action_code'],$action['action_completion'],$action['action_description'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($actionCompletion<=$lastDayOfNextMonth && $actionCompletion>$lastDayOfThisMonth) 	fillActionRidCalanderArray($actionsArray,$involvement,'Next Month',$action['action_code'],$action['action_completion'],$action['action_description'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
		}
		//RIDs
		//----------------------------
		if($action['rid_status']<2)
		{
			$ridCompletion=strtotime($action['rid_completion']);

			if($action['rid_holder']==$viewAsUserId) //JFM 30_10_14
			{
				$involvement='holder';
				$actionsOther['holder']['total']++;
			}
			else if($action['rid_validator']==$viewAsUserId)
			{
				$involvement='validator';
				$actionsOther['validator']++;
			}
			else if($action['rid_holder_siglum']==$siglum || $action['rid_validator_siglum']==$siglum)
			{
				$involvement='siglum';
				$actionsOther['siglum']++;
			}

			if($action['rid_completion']=="") continue;
			else if($action['rid_completion']=="0000-00-00")											fillActionRidCalanderArray($actionsArray,$involvement,'No Date',$action['rid_code'],$action['rid_completion'],$action['rid_title'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($ridCompletion<$today) 																fillActionRidCalanderArray($actionsArray,$involvement,'Overdue',$action['rid_code'],$action['rid_completion'],$action['rid_title'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($ridCompletion==$today) 															fillActionRidCalanderArray($actionsArray,$involvement,'Today',$action['rid_code'],$action['rid_completion'],$action['rid_title'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($ridCompletion==$tomorrow)															fillActionRidCalanderArray($actionsArray,$involvement,'Tomorrow',$action['rid_code'],$action['rid_completion'],$action['rid_title'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($ridCompletion<$nextMonday && $ridCompletion>$tomorrow)								fillActionRidCalanderArray($actionsArray,$involvement,'This Week',$action['rid_code'],$action['rid_completion'],$action['rid_title'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($ridCompletion<=$lastDayOfThisMonth && $ridCompletion>$nextMonday)					fillActionRidCalanderArray($actionsArray,$involvement,'This Month',$action['rid_code'],$action['rid_completion'],$action['rid_title'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
			else if($ridCompletion<=$lastDayOfNextMonth && $ridCompletion>$lastDayOfThisMonth)			fillActionRidCalanderArray($actionsArray,$involvement,'Next Month',$action['rid_code'],$action['rid_completion'],$action['rid_title'],$action['area'],$action['program'],$action['coe'],$action['msn_id'],$action['action_id'],$action['ca_id']);
		}
	}
}

/*
US: FIX for #054 My Tasks: Count on pie giagram
pie diagram count part
Fixed By - Infosys Limited
Version: V 4.4
*/

if(!empty($viewAsUserId))
{
	$specificFilter[]='(ac.action_holder='.$viewAsUserId.' OR ac.action_validator='.$viewAsUserId.')';
}
if(checkPermission('c_perimeter_general','view',0,'check',$SESSION)!=1){
	$validPerimeter=perimeterPermission($SESSION,'view');	
	if(is_array($validPerimeter)){
		foreach($validPerimeter as $k=>$v){
			$perimeter[]=$k;
		}
	}else{
		$perimeter=array();
	}
	if (!empty($perimeter)) { 
		$specificFilter[]='ca.perimeter IN('.implode(',',$perimeter).')';
	}
}
if(count($specificFilter)>0){
	$qryFilter = '  WHERE '.implode(' AND ',$specificFilter);
}
			$actionRawData1=SqlLi('SELECT DISTINCT ac.action_id,ac.action_status
									FROM dr_action								AS ac
									INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
									INNER JOIN c_ca 						AS ca	ON ap.ca=ca.ca_id 
									INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
									INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
									INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND ac.msn=m.msn_id)
									INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
									INNER JOIN dr_review_criterion 			AS cr 	ON ac.criteria=cr.review_criterion_id 
									INNER JOIN dr_review_criterion_history 	AS crh 	ON cr.review_criterion_id=crh.criterion
									INNER JOIN dr_review_group				AS rg 	ON cr.review_group=rg.group_id
									INNER JOIN dr_review_group_history 		AS gr 	ON rg.group_id=gr.review_group 
									INNER JOIN dr_review_type 				AS rt 	ON rg.review_type=rt.review_type_id
									INNER JOIN dr_review_profile			AS rp 	ON rt.review_type_id=rp.review_type
									LEFT JOIN  dr_rid 						AS rd 	ON ac.rid=rd.rid_id'
									 .$qryFilter.' AND ac.action_status IN(0,1,2,3)');
			
			$actionRawData2=SqlLi('SELECT DISTINCT ac.action_id, ac.action_status
								FROM dr_action								AS ac
									INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
									INNER JOIN c_ca 						AS ca	ON ap.ca=ca.ca_id
									INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
									INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
									INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND ac.msn=m.msn_id)
									INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
									INNER JOIN dr_review 					AS r 	ON ac.review=r.review_id
									INNER JOIN dr_review_profile			AS rp   ON r.review_profile=rp.review_profile_id
									INNER JOIN dr_review_type 				AS rt 	ON rp.review_type=rt.review_type_id
									LEFT JOIN  dr_rid 						AS rd 	ON ac.rid=rd.rid_id '
									.$qryFilter.' AND ac.action_status IN(0,1,2,3)');

			if(!empty($actionRawData1) && !empty($actionRawData2)) $actionRawData=array_merge($actionRawData1, $actionRawData2);
			else if (!empty($actionRawData1)) $actionRawData=$actionRawData1;
			else if (!empty($actionRawData2)) $actionRawData=$actionRawData2;
			
			if (!empty($actionRawData)) {
				foreach ($actionRawData as $actionData) {
					$actionsTotal['total']++;

					switch ($actionData['action_status']) 
					{
						case 0:
							$actionsTotal['red']++;
						break;
						case 1:
							$actionsTotal['amber']++;
						break;
						case 2:
							$actionsTotal['green']++;
						break;
						case 3:
							$actionsTotal['blue']++;
						break;
					} 
				}
			}
						
// End for US: FIX for #054 My Tasks: Count on pie giagram

//Upcoming Reviews
//---------------------------------------------------------------

$upcomingReviewsArray=array();
$reviewProfileList=allowedReviews($SESSION,'view');

$allowedProgramList=allowedSimpleObject('program','program',$SESSION,'c_','','view','ASC');

$allowedAreaList=allowedSimpleObject('area','area',$SESSION,'c_','','view','ASC'); //JFM 08_06_16

if(!empty($reviewProfileList) && !empty($allowedProgramList))
{
	//JFM 08_06_16
	$upcomingReviews=SqlLi('SELECT DISTINCT r.review_id,
											r.planned,
											ca.ca,
											wp.wp,
											per.perimeter,
											pro.program,
											coe.coe,
											rt.review_type
							FROM dr_review 						AS r
							INNER JOIN dr_review_profile 		AS rp  ON rp.review_profile_id=r.review_profile
							INNER JOIN dr_review_type			AS rt  ON rt.review_type_id=rp.review_type
							INNER JOIN dr_review_applicability 	AS ra  ON ra.review=r.review_id
							INNER JOIN c_ca 					AS ca  ON ca.ca_id=ra.ca
							INNER JOIN c_cawp 					AS cw  ON cw.ca=ca.ca_id
							INNER JOIN c_wp 					AS wp  ON wp.wp_id=cw.wp
							INNER JOIN c_program				AS pro ON pro.program_id=rp.program
                            INNER JOIN c_perimeter              AS per ON per.perimeter_id=ca.perimeter
							INNER JOIN c_coe 					AS coe ON coe.coe_id=rp.coe
							WHERE r.planned != "0000-00-00"
							AND r.planned >= SUBDATE(SYSDATE(), INTERVAL 1 WEEK) 
							AND rp.review_profile_id IN ('.implode(',', array_keys($reviewProfileList)).')
							AND rp.program IN ('.implode(',', array_keys($allowedProgramList)).')
							AND rt.area IN ('.implode(',', array_keys($allowedAreaList)).')
							AND cw.cawp_disabled=0
							ORDER BY r.planned ASC ');
	if(!empty($upcomingReviews))
	{
		foreach ($upcomingReviews as $upcomingReview) 
		{
			if(strtotime($upcomingReview['planned'])<$today) 
			{
				$upcomingReviewsArray['Last 7 Days'][$upcomingReview['review_id']]['date']=$upcomingReview['planned'];
				$upcomingReviewsArray['Last 7 Days'][$upcomingReview['review_id']]['program']=$upcomingReview['program'];
				$upcomingReviewsArray['Last 7 Days'][$upcomingReview['review_id']]['coe']=$upcomingReview['coe'];
				$upcomingReviewsArray['Last 7 Days'][$upcomingReview['review_id']]['review_type']=$upcomingReview['review_type'];
				$upcomingReviewsArray['Last 7 Days'][$upcomingReview['review_id']]['perimeter']=$upcomingReview['perimeter'];
				$upcomingReviewsArray['Last 7 Days'][$upcomingReview['review_id']]['ca']=$upcomingReview['ca'];
				$upcomingReviewsArray['Last 7 Days'][$upcomingReview['review_id']]['wp']=$upcomingReview['wp'];
			}
			else if(strtotime($upcomingReview['planned'])==$today) 
			{
				$upcomingReviewsArray['Today'][$upcomingReview['review_id']]['date']=$upcomingReview['planned'];
				$upcomingReviewsArray['Today'][$upcomingReview['review_id']]['program']=$upcomingReview['program'];
				$upcomingReviewsArray['Today'][$upcomingReview['review_id']]['coe']=$upcomingReview['coe'];
				$upcomingReviewsArray['Today'][$upcomingReview['review_id']]['review_type']=$upcomingReview['review_type'];
				$upcomingReviewsArray['Today'][$upcomingReview['review_id']]['perimeter']=$upcomingReview['perimeter'];
				$upcomingReviewsArray['Today'][$upcomingReview['review_id']]['ca']=$upcomingReview['ca'];
				$upcomingReviewsArray['Today'][$upcomingReview['review_id']]['wp']=$upcomingReview['wp'];
			}
			else if(strtotime($upcomingReview['planned'])==$tomorrow)
			{
				$upcomingReviewsArray['Tomorrow'][$upcomingReview['review_id']]['date']=$upcomingReview['planned'];
				$upcomingReviewsArray['Tomorrow'][$upcomingReview['review_id']]['program']=$upcomingReview['program'];
				$upcomingReviewsArray['Tomorrow'][$upcomingReview['review_id']]['coe']=$upcomingReview['coe'];
				$upcomingReviewsArray['Tomorrow'][$upcomingReview['review_id']]['review_type']=$upcomingReview['review_type'];
				$upcomingReviewsArray['Tomorrow'][$upcomingReview['review_id']]['perimeter']=$upcomingReview['perimeter'];
				$upcomingReviewsArray['Tomorrow'][$upcomingReview['review_id']]['ca']=$upcomingReview['ca'];
				$upcomingReviewsArray['Tomorrow'][$upcomingReview['review_id']]['wp']=$upcomingReview['wp'];
			}
			else if(strtotime($upcomingReview['planned'])<$nextMonday && strtotime($upcomingReview['planned'])>$tomorrow)
			{
				$upcomingReviewsArray['This Week'][$upcomingReview['review_id']]['date']=$upcomingReview['planned'];
				$upcomingReviewsArray['This Week'][$upcomingReview['review_id']]['program']=$upcomingReview['program'];
				$upcomingReviewsArray['This Week'][$upcomingReview['review_id']]['coe']=$upcomingReview['coe'];
				$upcomingReviewsArray['This Week'][$upcomingReview['review_id']]['review_type']=$upcomingReview['review_type'];
				$upcomingReviewsArray['This Week'][$upcomingReview['review_id']]['perimeter']=$upcomingReview['perimeter'];
				$upcomingReviewsArray['This Week'][$upcomingReview['review_id']]['ca']=$upcomingReview['ca'];
				$upcomingReviewsArray['This Week'][$upcomingReview['review_id']]['wp']=$upcomingReview['wp'];
			}
			else if(strtotime($upcomingReview['planned'])<=$lastDayOfThisMonth && strtotime($upcomingReview['planned'])>=$nextMonday)
			{
				$upcomingReviewsArray['This Month'][$upcomingReview['review_id']]['date']=$upcomingReview['planned'];
				$upcomingReviewsArray['This Month'][$upcomingReview['review_id']]['program']=$upcomingReview['program'];
				$upcomingReviewsArray['This Month'][$upcomingReview['review_id']]['coe']=$upcomingReview['coe'];
				$upcomingReviewsArray['This Month'][$upcomingReview['review_id']]['review_type']=$upcomingReview['review_type'];
				$upcomingReviewsArray['This Month'][$upcomingReview['review_id']]['perimeter']=$upcomingReview['perimeter'];
				$upcomingReviewsArray['This Month'][$upcomingReview['review_id']]['ca']=$upcomingReview['ca'];
				$upcomingReviewsArray['This Month'][$upcomingReview['review_id']]['wp']=$upcomingReview['wp'];
			}
			else if(strtotime($upcomingReview['planned'])<=$lastDayOfNextMonth && strtotime($upcomingReview['planned'])>$lastDayOfThisMonth)
			{
				$upcomingReviewsArray['Next Month'][$upcomingReview['review_id']]['date']=$upcomingReview['planned'];
				$upcomingReviewsArray['Next Month'][$upcomingReview['review_id']]['program']=$upcomingReview['program'];
				$upcomingReviewsArray['Next Month'][$upcomingReview['review_id']]['coe']=$upcomingReview['coe'];
				$upcomingReviewsArray['Next Month'][$upcomingReview['review_id']]['review_type']=$upcomingReview['review_type'];
				$upcomingReviewsArray['Next Month'][$upcomingReview['review_id']]['perimeter']=$upcomingReview['perimeter'];
				$upcomingReviewsArray['Next Month'][$upcomingReview['review_id']]['ca']=$upcomingReview['ca'];
				$upcomingReviewsArray['Next Month'][$upcomingReview['review_id']]['wp']=$upcomingReview['wp'];
			}
		}
	}
}

//Continuous Assessment
//---------------------------------------------------------------

$capArray=array();
$caInfoInANiceArraySoSidebarWorksCorrectly=array();

$capProviders=SqlLi('SELECT DISTINCT cs.criteria_status, cs.criteria_status_id,
									ca.ca_id, ca.ca,
									pro.program_id, pro.program,
									coe.coe_id, coe.coe, coe.area,
									msn.msn_id, msn.msn,
									rp.review_profile_id,
									rt.review_type
					FROM dr_criteria_status_provider 	AS csp
					INNER JOIN dr_criteria_status 		AS cs  ON  cs.criteria_status_id=csp.criteria_status
					INNER JOIN c_ca 					AS ca  ON  ca.ca_id=cs.ca
					INNER JOIN c_program				AS pro ON  pro.program_id=ca.program
					INNER JOIN c_coe 					AS coe ON  coe.coe_id=ca.coe
					INNER JOIN c_msn 					AS msn ON  msn.msn_id=cs.msn
					INNER JOIN dr_review_criterion 		AS rc  ON  rc.review_criterion_id=cs.review_criteria
					INNER JOIN dr_review_group 			AS rg  ON  rg.group_id=rc.review_group
					INNER JOIN dr_review_type 			AS rt  ON  rt.review_type_id=rg.review_type
					INNER JOIN dr_review_profile 		AS rp  ON  rp.program=pro.program_id
															   AND rp.coe=coe.coe_id
															   AND rp.review_type=rt.review_type_id
					WHERE csp.provider='.$viewAsUserId);

$capArray['total_criteria']['total']=0;
$capArray['total_criteria']['total_needed']=0;
$capArray['total_criteria']['total_done']=0;
$capArray['total_criteria']['total_ongoing']=0;

if(!empty($capProviders))
{
	foreach ($capProviders as $capProvider)
	{
		$capArray['total_criteria']['total']++;
		if($capProvider['criteria_status']<2) $capArray['total_criteria']['total_needed']++;
		else if($capProvider['criteria_status']==3) $capArray['total_criteria']['total_done']++;
		else $capArray['total_criteria']['total_ongoing']++;

		if($capProvider['criteria_status']<2)
		{
			$capArray['areas'][$capProvider['program']][$capProvider['coe']][$capProvider['msn']][$capProvider['ca']]++;
			$capArray['ca_only']['msn_'.$capProvider['msn_id'].'_coe_'.$capProvider['coe_id'].'_program_'.$capProvider['program_id'].'_area_'.$capProvider['area']][$capProvider['ca'].'_!_'.$capProvider['ca_id'].'_!_'.$capProvider['review_profile_id'].'_!_'.$capProvider['program'].'_!_'.$capProvider['coe'].'_!_'.$capProvider['review_type']]++;
		}
	}
}

//Validation loop table
//-------------------------------------------------------------------------------------
$allCriteriaInValidationLoop=SqlLi('SELECT * 
									 FROM dr_validation_loop
									 WHERE validator='.$SESSION['user']['user_id'].'
									 AND action_taken_on ="0000-00-00 00:00:00"
									 AND object='.$SESSION['object']['criterion_validity_id']);
									 
$allReviewsInValidationLoop=SqlLi('SELECT * 
									FROM dr_validation_loop
									WHERE validator='.$SESSION['user']['user_id'].'
									AND action_taken_on ="0000-00-00 00:00:00"
									AND object='.$SESSION['object']['review_id']);

$allEvidencesInValidationLoop=SqlLi('SELECT DISTINCT vl1.* 
									FROM dr_validation_loop AS vl1
									LEFT JOIN dr_criteria_status_provider AS csp 
										ON vl1.applicability=csp.criteria_status
										AND vl1.object="'.$SESSION['object']['criteria_status_id'].'"
									WHERE 
									(
										vl1.validator='.$SESSION['user']['user_id'].' 
										OR 
										(
											vl1.validator=0
											AND csp.provider='.$SESSION['user']['user_id'].'
										)
									)
									AND vl1.action_taken_on ="0000-00-00 00:00:00"
									AND vl1.object='.$SESSION['object']['criteria_status_id']);

$allActionsInValidationLoop=SqlLi('SELECT * 
									FROM dr_validation_loop
									WHERE validator='.$SESSION['user']['user_id'].'
									AND action_taken_on ="0000-00-00 00:00:00"
									AND object='.$SESSION['object']['action_id']);

$allThingsCurrentlyOngoing=SqlLi('SELECT DISTINCT vl1.object, vl1.applicability FROM dr_validation_loop AS vl1
											INNER JOIN dr_validation_loop AS vl2 
												ON vl1.object=vl2.object
												AND vl1.applicability=vl2.applicability
												AND vl2.action_taken=0
											LEFT JOIN dr_criteria_status_provider AS csp 
												ON vl1.applicability=csp.criteria_status
												AND vl1.object="'.$SESSION['object']['criteria_status_id'].'"
											WHERE 
											(
												vl1.validator='.$SESSION['user']['user_id'].' 
												OR 
												(
													vl1.validator=0
													AND csp.provider='.$SESSION['user']['user_id'].'
												)
											)
											AND vl1.validation_loop_step=0
											AND vl1.action_taken!=0');

//Bookmarked Reviews
//-------------------------------------------------------------------------------------

$reviewProfile=Array();
$cas=Array();
$keys=Array();

if(!empty($SESSION['filter'][$SESSION['object']['fav']]))
{
	foreach ($SESSION['filter'][$SESSION['object']['fav']] as $uselessKey => $filterArray) 
	{
		foreach ($filterArray as $caReviewProfile => $enabled) 
		{
			if($enabled)
			{
				$caReviewProfileSplit = split('_', $caReviewProfile);
				if(!in_array($caReviewProfile, $keys)) 					$keys[] = $caReviewProfile;
				if(!in_array($caReviewProfileSplit[1], $cas)) 			$cas[] = $caReviewProfileSplit[1];
				if(!in_array($caReviewProfileSplit[2], $reviewProfile))	$reviewProfile[] = $caReviewProfileSplit[2];
			}
		}
	}
}

if(!empty($reviewProfile) && !empty($cas))
{
	$favouriteReviews=SqlLi('SELECT DISTINCT r.review_id, r.planned, r.review_status, r.review_profile, r.validation_complete,
												ca.ca,
												pro.program, pro.program_id,
												coe.coe, coe.coe_id,
												rt.review_type,
												are.area, are.area_id,
												msn.msn, msn.msn_id,
												ra.review_applicability_id, ra.review, ca.ca_id
								FROM dr_review_profile 		    	AS rp
								LEFT JOIN  dr_review 				AS r   ON rp.review_profile_id=r.review_profile
								INNER JOIN dr_review_type			AS rt  ON rt.review_type_id=rp.review_type
								INNER JOIN dr_review_applicability 	AS ra  ON ra.review=r.review_id
								INNER JOIN c_ca 					AS ca  ON  ca.ca_id=ra.ca
								INNER JOIN c_program				AS pro ON  pro.program_id=ca.program
								INNER JOIN c_coe 					AS coe ON  coe.coe_id=ca.coe
								INNER JOIN c_msn 					AS msn ON  msn.msn_id=r.msn
								INNER JOIN c_area 					AS are ON  are.area_id=coe.area
																		   AND are.area_id=pro.area
								WHERE rp.review_profile_id IN ('.implode(',', $reviewProfile).')
								AND ca.ca_id IN ('.implode(',', $cas).')
								ORDER BY r.planned ASC');
}

$status=array('r','a','g','x','b','m'); // JFM 27_03_14

$reviewValidation=array('No checklist');

$tableCacheId=newTableCacheId($SESSION);
storeCache('csv',$tableCacheId,$caInfoInANiceArraySoSidebarWorksCorrectly);

$timeArray=localtime(time(),true);

?>OK|||dashboard_view&&&<?php

?><div style="background-color:#FFFFFF; width:100%;"><?php
	?><div class="formHeader" style="position:relative;"><?php
		?><div class="formHeaderInfo" style="top:6px;">Good <?=($timeArray['tm_hour']<12)?'Morning':'Afternoon'?>, <?=$SESSION['user']['name']?></div><?php
		?><div class="xDiv" style="top:16px;"><?=date("l, j F Y")?></div><?php
	?></div><?php
	
	?><div style="padding:5px; padding-top:10px;"><?php

		?><div class="leftSidebar" style="float:left; width:65%;"><?php  //START LEFT SIDEBAR

			//Bookmarked Reviews
			//-------------------------------------------------------

			?><table class="criteriaTable" style="clear:none; width:100%;" align="top" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="999">Bookmarked Reviews</td><?php
				?></tr><?php
				?><tr class="infoRow"><?php
					?><td class="paramDef"></td><?php
					?><td class="paramDef">Area</td><?php
					?><td class="paramDef">Program</td><?php
					?><td class="paramDef">CoE</td><?php
					?><td class="paramDef">MSN</td><?php
					?><td class="paramDef">Review Type</td><?php
					?><td class="paramDef">CA</td><?php
					?><td class="paramDef">Status</td><?php
				?></tr><?php

				if(!empty($favouriteReviews))
				{
					foreach ($favouriteReviews as $uselessKey => $values) 
					{
						if(in_array('fav_'.$values['ca_id'].'_'.$values['review_profile'], $keys))
						{
							?><tr class="infoRow" id="fav_<?=$values['ca_id']?>_<?=$values['review_profile']?>"><?php
								?><td><input class="popUpBtn"id="popUpBtn_<?=$values['ca_id']?>_<?=$values['review_profile']?>"onClick="expandSummaryView('msn_<?=$values['msn_id']?>_coe_<?=$values['coe_id']?>_program_<?=$values['program_id']?>_area_<?=$values['area_id']?>'); popUpOpt('tbl',[<?=$values['ca_id']?>,<?=$values['review_profile']?>]); "type="button"value="&#8801;"><div class="popUpMenu"id="popUpDiv_<?=$values['ca_id']?>_<?=$values['review_profile']?>"></td><?php
								?><td><?=$values['area']?></td><?php
								?><td><?=$values['program']?></td><?php
								?><td><?=$values['coe']?></td><?php
								?><td><?=$values['msn']?></td><?php
								?><td><?=$values['review_type']?></td><?php
								?><td><?=$values['ca']?></td><?php
								?><td><img height="20" width="20" src="../common/img/<?=$status[$values['review_status']]?>20.png"></td><?php
							?></tr><?php
						}
					}
				}
				else
				{
					?><tr class="infoRow"><?php
						?><td colspan="7" style="color:#bbbcbc; text-align:center;">No bookmarked reviews.<br /><br />To bookmark a review; select '&#8801;' &#8594; 'Bookmark Review' from the Main Table.</td><?php
					?></tr><?php
				}
			?></table><?php

			?><div class="sp"></div><?php

			?><div style="font-size:10px; margin-bottom:5px; margin-top:-5px;" align="left"><input id="green_actions_check" onclick="checkChange(this,'greenAct');" type="checkbox" value="1" <?php if(getFilter('greenAct','filter',0,$SESSION))echo' checked="checked"'?>/> - Display Green Actions</div><?php //JFM 12_05_15


			//Upcoming Actions
			//----------------------------------------------
			
			?><table class="criteriaTable" style="float:left; clear:none; width:100%;" align="top" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="3">Your Open Actions & RIDs</td><?php
					?><td colspan="1">GoTo Action</td><?php
				?></tr><?php

				if($actionsOther['holder']['total']>0)
				{
					foreach ($calandarDates as $dateType) 
					{
						if(!empty($actionsArray['holder'][$dateType]))
						{
							?><tr class="infoRow"><?php
								?><td class="paramDef" width="10%" colspan="4" style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$dateType?></td><?php
							?></tr><?php
							foreach ($actionsArray['holder'][$dateType] as $actionCode => $actionValue) 
							{
								if(substr($actionCode,0,3)=="RID") $actionCode='<b>'.substr($actionCode,0,3).'</b>'.substr($actionCode,3);

								?><tr class="infoRow" style="cursor:pointer;" onclick="expandSummaryView('<?=$actionValue['area']?>'); openForm('action','action=<?=$actionValue['action_id']?>&criteria_ca=<?=$actionValue['ca_id']?>',true,'GET'); mainRestartNeeded=1;"><?php
									?><td width="10%" style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$actionValue['date']?></td><?php
									?><td width="20%" style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$actionCode?></td><?php
									?><td width="35%;"style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$actionValue['description']?></td><?php
									?><td width="5%"style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top; text-align:center;">&#9658;</td><?php
								?></tr><?php
							}
						}
					}
				}
				else
				{
					?><tr class="infoRow"><?php
						?><td colspan="4" style="color:#bbbcbc; text-align:center;">No upcoming actions require your attention.</td><?php
					?></tr><?php
				}

			?></table><?php

			?><div class="sp"></div><?php

			//Validator Actions
			//----------------------------------------------
			
			?><table class="criteriaTable" style="float:left; clear:none; width:100%;" align="top" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="3">Open Actions & RIDs You Are A Validator For</td><?php
					?><td colspan="1">GoTo Action</td><?php
				?></tr><?php

				if($actionsOther['validator']>0)
				{
					foreach ($calandarDates as $dateType) 
					{
						if(!empty($actionsArray['validator'][$dateType]))
						{
							?><tr class="infoRow"><?php
								?><td class="paramDef" width="10%;" colspan="4" style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$dateType?></td><?php
							?></tr><?php
							foreach ($actionsArray['validator'][$dateType] as $actionCode => $actionValue) 
							{
								if(substr($actionCode,0,3)=="RID") $actionCode='<b>'.substr($actionCode,0,3).'</b>'.substr($actionCode,3);

								?><tr class="infoRow" style="cursor:pointer;" onclick="expandSummaryView('<?=$actionValue['area']?>'); openForm('action','action=<?=$actionValue['action_id']?>&criteria_ca=<?=$actionValue['ca_id']?>',true,'GET'); mainRestartNeeded=1;"><?php
									?><td width="10%;" style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$actionValue['date']?></td><?php
									?><td width="20%;" style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$actionCode?></td><?php
									?><td width="35%;"style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$actionValue['description']?></td><?php
									?><td width="5%;"style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top; text-align:center;">&#9658;</td><?php
								?></tr><?php
							}
						}
					}
				}
				else
				{
					?><tr class="infoRow"><?php
						?><td colspan="4" style="color:#bbbcbc; text-align:center;">No actions require your attention.</td><?php
					?></tr><?php
				}

			?></table><?php


			?><div class="sp"></div><?php

			//Siglum
			//----------------------------------------------
			
			?><table class="criteriaTable" style="float:left; clear:none; width:100%;" align="top" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="3">Open Actions & RIDs In Your Department</td><?php
					?><td colspan="1">GoTo Action</td><?php
				?></tr><?php

				if($actionsOther['siglum']>0)
				{
					foreach ($calandarDates as $dateType) 
					{
						if(!empty($actionsArray['siglum'][$dateType]))
						{
							?><tr class="infoRow"><?php
								?><td class="paramDef" width="10%;" colspan="4" style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$dateType?></td><?php
							?></tr><?php
							foreach ($actionsArray['siglum'][$dateType] as $actionCode => $actionValue) 
							{
								if(substr($actionCode,0,3)=="RID") $actionCode='<b>'.substr($actionCode,0,3).'</b>'.substr($actionCode,3);

								?><tr class="infoRow" style="cursor:pointer;" onclick="expandSummaryView('<?=$actionValue['area']?>'); openForm('action','action=<?=$actionValue['action_id']?>&criteria_ca=<?=$actionValue['ca_id']?>',true,'GET'); mainRestartNeeded=1;"><?php
									?><td width="10%;" style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$actionValue['date']?></td><?php
									?><td width="20%;" style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$actionCode?></td><?php
									?><td width="35%;"style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top;"><?=$actionValue['description']?></td><?php
									?><td width="5%;"style="color:<?=($dateType=='Overdue')?'#ef343f':''?>; vertical-align: top; text-align:center;">&#9658;</td><?php
								?></tr><?php
							}
						}
					}
				}
				else
				{
					?><tr class="infoRow"><?php
						?><td colspan="4" style="color:#bbbcbc; text-align:center;">No actions require your attention.</td><?php
					?></tr><?php
				}

			?></table><?php



			?><div class="sp"></div><?php
			?><div id="graphHolder" name="graphHolder" style="width:0px;margin-left:-30px;"></div><?php
			?><div id="downloadGraphHolder" name="downloadGraphHolder" style="display:none;"></div><?php

		?></div><?php //END LEFT SIDEBAR


//						LEFT
//========================================================================
//						RIGHT


		?><div style="float:right; width:34%;"><?php  //START RIGHT SIDEBAR

			//Upcoming Reviews
			//-------------------------------------------------------

			?><table class="criteriaTable" style="clear:none; width:100%;" align="top" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="7">Upcoming Reviews</td><?php
				?></tr><?php

				if(!empty($upcomingReviewsArray))
				{
					foreach ($calandarDates as $dateType) 
					{
						if(!empty($upcomingReviewsArray[$dateType]))
						{
							?><tr class="infoRow"><?php
								?><td class="paramDef" colspan="7" style="vertical-align: top;"><?=$dateType?></td><?php
							?></tr><?php
							foreach ($upcomingReviewsArray[$dateType] as $upcomingReviewKey => $upcomingReviewValue) 
							{
								if($upcomingReviewValue['coe'] == 'NA')
									$upcomingReviewValue['coe'] = '';

								?><tr class="infoRow"><?php
									?><td width="80px"><?=$upcomingReviewValue['date']?></td><?php
									?><td><?=$upcomingReviewValue['program']?></td><?php
									?><td><?=$upcomingReviewValue['coe']?></td><?php
									?><td><?=$upcomingReviewValue['perimeter']?></td><?php
									?><td><?=$upcomingReviewValue['wp']?></td><?php
									?><td><?=$upcomingReviewValue['ca']?></td><?php
									?><td><?=$upcomingReviewValue['review_type']?></td><?php
								?></tr><?php
							}
						}
					}
				}
				else
				{
					?><tr class="infoRow"><?php
						?><td colspan="5" style="color:#bbbcbc; text-align:center;">No upcoming reviews.</td><?php
					?></tr><?php
				}
			?></table><?php

			//Validation Loop Items - JFM 28_10_15
			//-------------------------------------------------------------

			?><table class="criteriaTable" style="clear:none; width:100%; margin-top: 20px;" align="top" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="2">Validation Loop</td><?php
				?></tr><?php

				?><tr style="cursor:pointer;" onClick="openForm('validation','object=<?=$allCriteriaInValidationLoop[0]['object']?>',false,'GET');hideMenu();"><?php
					?><td class="paramDef" width="200px"><?=(count($allCriteriaInValidationLoop)==1)?'Criterion':'Criteria'?></td><?php 
					?><td align="center" style="font-weight:bold;<?=(count($allCriteriaInValidationLoop)>0)?'color:#ef343f;':''?>"><?=count($allCriteriaInValidationLoop)?></td><?php
				?></tr><?php
				?><tr style="cursor:pointer;" onClick="openForm('validation','object=<?=$allReviewsInValidationLoop[0]['object']?>',false,'GET');hideMenu();"><?php
					?><td class="paramDef">Review Checklist<?=(count($allReviewsInValidationLoop)==1)?'':'s'?></td><?php
					?><td align="center" style="font-weight:bold;<?=(count($allReviewsInValidationLoop)>0)?'color:#ef343f;':''?>"><?=count($allReviewsInValidationLoop)?></td><?php
				?></tr><?php
				?><tr style="cursor:pointer;" onClick="openForm('validation','object=<?=$allEvidencesInValidationLoop[0]['object']?>',false,'GET');hideMenu();"><?php
					?><td class="paramDef">Evidence<?=(count($allEvidencesInValidationLoop)==1)?'':'s'?></td><?php
					?><td align="center" style="font-weight:bold;<?=(count($allEvidencesInValidationLoop)>0)?'color:#ef343f;':''?>"><?=count($allEvidencesInValidationLoop)?></td><?php
				?></tr><?php
				?><tr style="cursor:pointer;" onClick="openForm('validation','object=<?=$allActionsInValidationLoop[0]['object']?>',false,'GET');hideMenu();"><?php
					?><td class="paramDef">Action<?=(count($allActionsInValidationLoop)==1)?'':'s'?></td><?php
					?><td align="center" style="font-weight:bold;<?=(count($allActionsInValidationLoop)>0)?'color:#ef343f;':''?>"><?=count($allActionsInValidationLoop)?></td><?php
				?></tr><?php
				?><tr style="cursor:pointer;" onClick="openForm('validation','object=All',false,'GET');hideMenu();"><?php
					?><td class="paramDef">My ongoing workflow<?=(count($allThingsCurrentlyOngoing)==1)?'':'s'?></td><?php
					?><td align="center" style="font-weight:bold;"><?=count($allThingsCurrentlyOngoing)?></td><?php
				?></tr><?php
				
			?></table><?php

			//Continuous Assessment
			//-------------------------------------------------------------

			if(!empty($capArray['total_criteria']['total']))
			{
				?><table class="criteriaTable" style="clear:none; width:100%; margin-top: 20px;" cellspacing="0" cellpadding="5"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="5">Your Continuous Assessment Information</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td colspan="3" class="paramDef">Criteria you are a provider for</td><?php
						?><td colspan="2" align="center" style="font-weight:bold;"><?=$capArray['total_criteria']['total']?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td colspan="3" class="paramDef">Criteria validated</td><?php
						?><td colspan="2" align="center" style="font-weight:bold; color:#0088cf;"><?=$capArray['total_criteria']['total_done']?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td colspan="3" class="paramDef">Criteria in validation loop</td><?php
						?><td colspan="2" align="center" style="font-weight:bold; color:#81c341;"><?=$capArray['total_criteria']['total_ongoing']?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td colspan="3" class="paramDef">Criteria outstanding</td><?php
						?><td colspan="2" align="center" style="font-weight:bold; color:#f8d707;"><?=$capArray['total_criteria']['total_needed']?></td><?php
					?></tr><?php

					if(!empty($capArray['ca_only']))
					{
						?><tr class="tableGroup"><?php
							?><td colspan="3">Criteria Outstanding Details</td><?php
							?><td rowspan="2"># of Criteria</td><?php
							?><td rowspan="2">GoTo Review</td><?php
						?></tr><?php

						?><tr class="tableGroup"><?php
							?><td>Location</td><?php
							?><td>CA</td><?php
							?><td>Type</td><?php
						?></tr><?php

						foreach ($capArray['ca_only'] as $area => $ca) 
						{
							foreach ($ca as $carpValue => $caCriteriaCount)
							{
								$carpSplit			=explode('_!_', $carpValue);
								$caValue			=$carpSplit[0];
								$caidValue			=$carpSplit[1];
								$rpidValue			=$carpSplit[2];
								$programValue		=$carpSplit[3];
								$coeValue			=$carpSplit[4];
								$reviewTypeValue	=$carpSplit[5];

								?><tr class="infoRow" style="cursor:pointer;" onclick="expandSummaryView('<?=$area?>'); openReviewForm('<?=$rpidValue?>','ca'); openSideElement('<?=$caidValue?>','rev'); mainRestartNeeded=1;"><?php
									?><td class="paramDef"><?=$programValue?> -> <?=$coeValue?></td><?php
									?><td class="paramDef"><?=$caValue?></td><?php
									?><td class="paramDef"><?=$reviewTypeValue?></td><?php
									?><td align="center"><?=$caCriteriaCount?></td><?php
									?><td align="center">&#9658;</td><?php
								?></tr><?php
							}
						}
					}
				?></table><?php
			}

		?></div><?php //END RIGHT SIDEBAR;

		?><div style="text-align:left; clear:both;">&nbsp;</div><?php
	?></div><?php

	?><input id="mainTableCacheId"type="hidden"value="<?=$tableCacheId?>"><?php

?></div><?php

$graphMeArray=Array('My Action \nInvolvement Statuses',$actionsTotal['total'],$actionsTotal['red'],$actionsTotal['amber'],$actionsTotal['green'],$actionsTotal['blue']);
$answer='&&&my_actions---'.implode(',',$graphMeArray).'---action---msn---coe---msn---0---0---'.getFilter('area','filter',0,$SESSION).'---program---'.$viewAsUserId;

echo $answer;

storeSession($SESSION);

?>