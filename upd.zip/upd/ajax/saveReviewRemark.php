<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$POST=cleanArray($_POST);

$numberOfUndosStored=count($SESSION['undo'][$POST['reviewID']]);

if($POST['undo']==1 && $numberOfUndosStored!=1)
{
	$POST['review_remark']=$SESSION['undo'][$POST['reviewID']][($numberOfUndosStored-2)];
	unset($SESSION['undo'][$POST['reviewID']][($numberOfUndosStored-1)]);
}
else
{
	$SESSION['undo'][$POST['reviewID']][($numberOfUndosStored)]=$POST['review_remark'];
}

SqlLQ('UPDATE dr_review SET remark="'.$POST['review_remark'].'" WHERE review_id="'.$POST['reviewID'].'"');

echo 'OK|||'.$POST['review_remark'];
storeSession($SESSION);
?>