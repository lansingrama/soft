<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$tableCacheId=$_GET['tableCacheId'];
$cachedResults=loadCache('html',$tableCacheId);
$resultCount=$SESSION['table_result_count'][$tableCacheId];
if($resultCount!='' && $cachedResults['displayed_results']!=''){
	$availableResults=$resultCount-$cachedResults['displayed_results'];
}elseif(is_array($cachedResults)){
	$availableResults=count($cachedResults);
}else $availableResults=0;
echo 'OK|||',$resultCount,'&&&',$availableResults;
storeSession($SESSION);

?>