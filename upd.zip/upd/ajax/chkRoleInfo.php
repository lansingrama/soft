<?php
require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$POST=cleanArray($_GET);
//print_r($POST);
//ECHO 'SELECT count(*) FROM dr_responsible_role WHERE responsible_role="'.$POST['roleName'].'"';
$roleQry= mysql_query('SELECT count(*) FROM dr_responsible_role WHERE responsible_role="'.$POST['roleName'].'"');
$countQry=mysql_result($roleQry, 0);
/* if($countQry){
	$resultCount=$countQry;
} */
//echo $countQry;
echo 'OK|||',$countQry;
?>
