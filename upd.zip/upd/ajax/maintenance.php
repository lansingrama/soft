<?php
/*require_once('../../support.php');

if(is_file('../output/test.sql')) unlink('../output/test.sql');

$query = '';
$database='app075';

$tables = @mysql_list_tables($database);
while ($row = @mysql_fetch_row($tables)) { $table_list[] = $row[0]; }

for ($i = 0; $i < @count($table_list); $i++) 
{
	$results = mysql_query('DESCRIBE ' . $database . '.' . $table_list[$i]);

	$query .= 'DROP TABLE IF EXISTS `' . $database . '.' . $table_list[$i] . '`;' . '---&&&!!!';
	$query .= '---&&&!!!' . 'CREATE TABLE `' . $database . '.' . $table_list[$i] . '` (' . '---&&&!!!';

	$tmp = '';

	while ($row = @mysql_fetch_assoc($results)) 
	{
		$query .= '`' . $row['Field'] . '` ' . $row['Type'];

		if ($row['Null'] != 'YES') { $query .= ' NOT NULL'; }
		if ($row['Default'] != '') { $query .= ' DEFAULT \'' . $row['Default'] . '\''; }
		if ($row['Extra']) { $query .= ' ' . strtoupper($row['Extra']); }
		if ($row['Key'] == 'PRI') { $tmp = 'primary key(' . $row['Field'] . ')'; }

		$query .= ','. '---&&&!!!';
	}

	$query .= $tmp . '---&&&!!!' . ');' . str_repeat('---&&&!!!', 2);

	$results = mysql_query('SELECT * FROM ' . $database . '.' . $table_list[$i]);

	while ($row = @mysql_fetch_assoc($results)) 
	{

		$query .= 'INSERT INTO `' . $database . '.' . $table_list[$i] .'` (';
		$data = Array();

		while (list($key, $value) = @each($row)) { $data['keys'][] = $key; $data['values'][] = addslashes($value); }

		$query .= join($data['keys'], ', ') . ')' . '---&&&!!!' . 'VALUES (\'' . join($data['values'], '\', \'') . '\');' . '---&&&!!!';

	}

	$query .= str_repeat('---&&&!!!', 2);
}

$queryArray=explode('---&&&!!!', $query);

$fp=fopen('../output/test.sql','w');
fwrite($fp,print_r($queryArray, true));
fclose($fp);*/

require_once(dirname(__FILE__).'/../../common/php/maintenance.php');

dbBackup('DR');
dbBackup('C'); //JFM 24_03_14
removeOldFiles('dr_report');

?>OK|||OK