<?php 
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET=cleanArray($_GET);

$caQry=SqlLi('SELECT DISTINCT 	ca.ca_id, ca.ca, 
								pro.program, 
								coe.coe, 
								msn.msn, 
								rt.review_type
				FROM dr_review_applicability 	AS ra
				INNER JOIN dr_review 			AS r 	ON r.review_id=ra.review
				INNER JOIN dr_review_profile	AS rp	ON rp.review_profile_id=r.review_profile
				INNER JOIN c_ca 				AS ca 	ON ca.ca_id=ra.ca
				INNER JOIN c_program 			AS pro 	ON pro.program_id=rp.program
				INNER JOIN c_coe 				AS coe 	ON coe.coe_id=rp.coe
				INNER JOIN c_msn 				AS msn 	ON msn.msn_id=r.msn
				INNER JOIN dr_review_type 		AS rt 	ON rt.review_type_id=rp.review_type
				WHERE 	rp.program='.$GET['program'].'
				AND 	rp.coe='.$GET['coe'].'
				AND 	rp.review_type='.$GET['review_type'].'
				AND 	r.msn='.$GET['msn'].'
				AND r.validation_complete=2');

?>OK|||<?php 
?><div class="xDiv"style="text-align:right;position:relative;right:10px;"><img alt="Close this Window"onClick="closeMenu('overDivCriteriaStatus');"src="../common/img/x.png"style="cursor:pointer;"></div><?php
?><div class="olHeader">Select Graphs...</div><?php
?><div class="olSpT"></div><?php

?><div class="elementDetailsContainer"style="width:420px; height:400px; overflow:auto;" align="center"><?php
	if(!empty($caQry))
	{
		?><table id="graph_table_overDiv" style="border-style:solid; border-width:1px; border-color:black; width:95%"><?php

			?><tr><?php
				?><td colspan="2" style="background-color:#C3CDDC; color:#565C6A; font-weight:bold; text-align:center;"><?php
					echo $caQry[0]['program'].' - '.$caQry[0]['coe'].' - '.$caQry[0]['msn'].' - '.$caQry[0]['review_type'];
				?></td><?php
			?></tr><?php
			?><tr><?php
				?><td style="background-color:#C3CDDC; color:#565C6A; font-weight:bold; text-align:center; width:50%;"><?php
					echo 'CA';
				?></td><?php
				?><td style="background-color:#C3CDDC; color:#565C6A; font-weight:bold; text-align:center; width:50%;"><?php
					echo 'Show Graph';
				?></td><?php
			?></tr><?php

			foreach ($caQry as $x => $y) 
			{
				?><tr><?php
					?><td align="centre" bgcolor="#E5E5E5" style="color:#565C6A; font-weight:bold;"><?php
						echo $y['ca'];
					?></td><?php
					?><td><?php
						?><input id="total_<?=$GET['item']?>_<?=$GET['coe']?>_<?=$GET['msn']?>_<?=$y['review_type']?>_<?=$y['ca_id']?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$GET['item'].'_'.$GET['coe'].'_'.$GET['msn'].'_'.$y['review_type'].'_'.$y['ca_id'].'_check',$SESSION))echo' checked="checked"'?>/><?php
					?></td><?php
				?></tr><?php
			}

		?></table><?php
	}
	else
	{
		?>No reviews validated.<?php
	}
?></div><?php
?><div class="olSpB"></div><?php
storeSession($SESSION);
?>