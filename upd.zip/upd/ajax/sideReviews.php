<?php
if($included!=1){
	require_once('../support/header.php');
	require_once('../security/checkExpiredSession.php');
	require_once('../../support.php');
	$GET=$_GET;
        $area = addslashes($GET['area']);
	$program=addslashes($GET['program']);
	$coe=addslashes($GET['coe']);
}

/* JFM 30_09_13 - Replaced with below.
 $review=SqlAsArr('SELECT p.review_profile_id,t.review_type
					FROM dr_review_profile AS p
						INNER JOIN dr_review_type AS t ON p.review_type=t.review_type_id
					WHERE p.program="'.$program.'"
						AND p.coe="'.$coe.'"',
					'review_profile_id','review_type');*/

// Added Hidden flag to show the Review type in Master List Management based on their visibility - US#110 (Possibility to delete Review type, L1, L2 and L3
if (!$program && !$coe) {
    $review=SqlAsArr('SELECT p.review_profile_id,t.review_type
					FROM dr_review_profile AS p
					INNER JOIN dr_review_type AS t ON p.review_type=t.review_type_id
					WHERE p.program="'.$area.'"
                                        AND t.review_type_hidden=0 
					ORDER BY review_type',
					'review_profile_id','review_type');
} else {
    $review=SqlAsArr('SELECT p.review_profile_id,t.review_type
					FROM dr_review_profile AS p
					INNER JOIN dr_review_type AS t ON p.review_type=t.review_type_id
					WHERE p.program="'.$program.'"
                                        AND p.coe="'.$coe.'"
                                        AND t.review_type_hidden=0
					ORDER BY review_type',
					'review_profile_id','review_type');     //JFM 30_09_13
}

if($included!=1)echo'OK|||';
if(is_array($review)){
	foreach($review as $k=>$v){
		?><div class="sideElement"id="reviewElement_<?=$k?>"onClick="oldCrTxt='';openSideElement('<?=$k?>','rvm');"><?=utf8_encode($v)?></div><?php
	}
}else{?><div class="sideElementEmpty"id="reviewElement_noResults"style="display:block;">No Results</div><?php }
storeSession($SESSION);
?>