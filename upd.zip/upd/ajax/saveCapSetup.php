<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST);

$applicableCriteriaStatusArray=array();

//print_r($POST);

//
// Add all overriders.
// -------------------------------------------------------------------------------------------------------------------------------------------------------

$overriderArray=array();
$allCriteriaStatusIds=explode(',', $POST['all_criteria_status_ids']);
				
foreach ($POST as $arrayName=>$arrayValue)
{
	$foundoverrider=strpos($arrayName,"overridersinputID");
	if($foundoverrider===0 && $arrayValue!='') array_push($overriderArray,$arrayValue);
}

if(!empty($overriderArray) && !empty($allCriteriaStatusIds))
{
	foreach($allCriteriaStatusIds as $criteriaStatusId)
	{
		SqlLQ('DELETE FROM dr_validation_loop_override WHERE object='.$SESSION['object']['criteria_status_id'].' AND applicability='.$criteriaStatusId);
		foreach($overriderArray as $overriderUsed)
		{
			$nameSplit=explode(", ",$overriderUsed);

			SqlLQ('INSERT INTO dr_validation_loop_override (user, object, applicability) VALUES ((SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$SESSION['object']['criteria_status_id'].','.$criteriaStatusId.')');				
		}
	}
}

foreach ($POST as $arrayName=>$arrayValue)
{
	$foundProvider=strpos($arrayName,"checkbox_");
	if($foundProvider===0 && $arrayValue!='') array_push($applicableCriteriaStatusArray,substr($arrayName, 9));
}

if(!empty($applicableCriteriaStatusArray))
{
	foreach($applicableCriteriaStatusArray as $chID)
	{

		//
		// Add all providers.
		// -------------------------------------------------------------------------------------------------------------------------------------------------------

		$providerArray=array();
						
		foreach ($POST as $arrayName=>$arrayValue)
		{
			$foundProvider=strpos($arrayName,"providersinputID");
			if($foundProvider===0 && $arrayValue!='') array_push($providerArray,$arrayValue);
		}

		if(!empty($providerArray))
		{
			SqlLQ('DELETE FROM dr_criteria_status_provider WHERE criteria_status="'.$chID.'"');

			foreach($providerArray as $providerUsed)
			{
				$nameSplit=explode(", ",$providerUsed);

				SqlLQ('INSERT INTO dr_criteria_status_provider (criteria_status, provider) VALUES ("'.$chID.'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"))');				
			}
		}

		//
		// Add all entered names into the validation loop.
		// -------------------------------------------------------------------------------------------------------------------------------------------------------

		$validationArray=array();
		
		foreach ($POST as $arrayName=>$arrayValue)
		{
			$foundValidation=strpos($arrayName,"elephantTigerBeehiveinputID");
			if($foundValidation===0 && $arrayValue!='') array_push($validationArray,$arrayValue);
		}
			
		if(!empty($validationArray))
		{
			SqlLQ('DELETE FROM dr_validation_loop_structure WHERE object="'.$SESSION['object']['criteria_status_id'].'" AND applicability="'.$chID.'"');

			$i=1;

			foreach($validationArray as $validationUsed)
			{
				$nameSplit=explode(", ",$validationUsed);
				
				SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
						VALUES ("'.$SESSION['object']['criteria_status_id'].'","'.$chID.'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.')');
				
				$i++;
			}
		}

	}
}

//print_r($applicableCriteriaStatusArray);

echo 'OK|||';
storeSession($SESSION);
?>