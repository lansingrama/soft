<?php

/*
 * To get the List of Coe, MSN
 * Created by : Infosys Limited
 * Version : 4.4.2
 * @author: Maheswari
 */
require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$POST = cleanArray($_GET);
$reviewProfile = $POST['review'];
if ($POST['program_id']) {
	$reviewType = SqlQ('SELECT review_type_id FROM dr_review_type AS rt 
											INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id 
											WHERE rp.review_profile_id='.$reviewProfile);
    $ListOfCoes = SqlLi('SELECT DISTINCT coe.coe_id, coe.coe
					FROM c_ca AS ca
						INNER JOIN dr_review_applicability 	AS 	ra 	ON 	ra.ca				=	ca.ca_id
						INNER JOIN dr_review				AS	r	ON 	r.review_id			=	ra.review
						INNER JOIN dr_review_profile		AS	rp	ON	rp.review_profile_id=	r.review_profile
						INNER JOIN dr_review_type 			AS  rt 	ON  rt.review_type_id   =   rp.review_type
						INNER JOIN c_coe 					AS  coe ON  coe.coe_id 			= 	rp.coe
						INNER JOIN c_program 				AS 	pro ON 	pro.program_id 		= 	rp.program
						INNER JOIN c_msn 					AS 	msn ON 	msn.msn_id  		= 	r.msn
					WHERE rp.rp_hidden=0 AND pro.program_hidden=0 AND pro.program_id = '.$POST['program_id'].' AND r.validation_complete!=-1
					AND r.review_status!=4
					AND coe.area = '.getFilter('area','filter',0,$SESSION).'
					AND pro.area = '.getFilter('area','filter',0,$SESSION).'
					AND rp.review_type = '.$reviewType['review_type_id'].'
					ORDER BY pro.program, coe.coe, msn.msn, ca.ca ASC');
					$coeData = array();
					foreach ($ListOfCoes as $coe)
					{
						$coeData[] = $POST['program_id'].'-'.$coe['coe_id'] . '-'. $coe['coe'];
					} 	
					$getData = implode(',',$coeData);	
}	
else if ($POST['coe_id']) {
	$data = explode('_',$POST['coe_id']);
	$coe_id = $data[1];
	$program_id = $data[0];
	$reviewType = SqlQ('SELECT review_type_id FROM dr_review_type AS rt 
											INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id 
											WHERE rp.review_profile_id='.$reviewProfile);
    $ListOfMsns = SqlLi('SELECT DISTINCT ca.ca_id, ca.ca, msn.msn,rt.review_type_id
					FROM c_ca AS ca
						INNER JOIN dr_review_applicability 	AS 	ra 	ON 	ra.ca				=	ca.ca_id
						INNER JOIN dr_review				AS	r	ON 	r.review_id			=	ra.review
						INNER JOIN dr_review_profile		AS	rp	ON	rp.review_profile_id=	r.review_profile
						INNER JOIN dr_review_type 			AS  rt 	ON  rt.review_type_id   =   rp.review_type
						INNER JOIN c_coe 					AS  coe ON  coe.coe_id 			= 	rp.coe
						INNER JOIN c_program 				AS 	pro ON 	pro.program_id 		= 	rp.program
						INNER JOIN c_msn 					AS 	msn ON 	msn.msn_id  		= 	r.msn
					WHERE rp.rp_hidden=0 AND pro.program_hidden=0 AND pro.program_id = '.$program_id.' AND coe.coe_id = '.$coe_id.' AND r.validation_complete!=-1
					AND r.review_status!=4
					AND coe.area = '.getFilter('area','filter',0,$SESSION).'
					AND pro.area = '.getFilter('area','filter',0,$SESSION).'
					AND rp.review_type = '.$reviewType['review_type_id'].'
					ORDER BY pro.program, coe.coe, msn.msn, ca.ca ASC');
					$msnData = array();
					foreach ($ListOfMsns as $msn)
					{
						$msnData[] = $msn['ca_id'] . '-'. $msn['review_type_id']. '-'. $msn['msn']. '-'. $msn['ca'];
					} 	
					$getData = implode(',',$msnData);						
}			
echo 'OK|||', $getData;
?>
