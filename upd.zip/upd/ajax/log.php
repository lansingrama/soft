<?php
if($included!=1){
	require_once('../support/header.php');
	require_once('../security/checkExpiredSession.php');
}
require_once('../support/localSupport.php');
require_once('../support/log.php');
require_once('../../common/php/common.php');


$_a_=$SESSION['user_action'];
$_o_=$SESSION['object'];
$_t_=$SESSION['object_table'];

if(!$GET)$GET=cleanArray($_GET);

$logCondition=array();
if($GET['source']!='' && $GET['applicability']!=''){
	$logCondition[]='o.source="'.$_t_[$GET['source']].'" AND l.applicability="'.$GET['applicability'].'"';
}
if($GET['user']!=''){
	$logCondition[]='l.user="'.$GET['user'].'"';
}
if($logCondition[0]!=''){
	$logWhereQry=' WHERE '.implode(' AND ',$logCondition);
}

if($GET['table_cache_id']=='' || !cacheExists($GET['table_cache_id'])){
	$first=1;

	$logCount=SqlQ('SELECT COUNT(*) FROM dr_log AS l LEFT JOIN c_object AS o ON o.object_id = l.object '.$logWhereQry);
	
	if($logCount['COUNT(*)']!=0){
		$data['table_result_count']=$logCount['COUNT(*)'];
		$data['displayed_results']=0;
		
		storeCache('html',$tableCacheId,$data);
		storeCache('csv',$tableCacheId,$data);
		$SESSION['table_result_count'][$tableCacheId]=$data['table_result_count'];
		
		?><table class="criteriaTable"id="table_<?=$tableCacheId?>"style="width:960px;" cellspacing="0" cellpadding="5"><?php //JFM 25_06_14
			?><tr class="tableGroup"><td style="width:124px;">Date</td><td style="width:828px;">Event</td></tr><?php
	}else{
		?><table class="criteriaTable"id="table_<?=$tableCacheId?>"style="width:960px;"><?php
			?><tr class="tableGroup"><td>No Log Found</td></tr><?php
			?><tr><td class="emptyTable">No Log registries found for this element.</td></tr><?php
	}
	
}else{
	$first=0;
	$tableCacheId=$GET['table_cache_id'];
	$data=loadCache('html',$tableCacheId);
	?>OK|||<table><?php
}

if(($first==1 && $logCount['COUNT(*)']!=0) || $first==0){

	$maxResults=getFilter('max_results','view',0,$SESSION);
		
	$log=retrieveLogData($GET['user'],$GET['source'],$GET['applicability'],$data,$maxResults,$SESSION,1);
	
	foreach($log as $l){
		?><tr><?php
			?><td><?=$l['date']?></td><?php
			?><td><?=$l['event']?></td><?php
		?><tr><?php
	}
	?></table><?php
	
	if($first==1){
		$resultCount=$data['table_result_count']-$data['displayed_results'];
		
		nextResultButton($resultCount,$tableCacheId,'log','log',$displayedResults,$SESSION,'GET',arrayToUrl($GET,array('user','source','applicability')));
		
		?></div><?php
	}
	storeCache('html',$tableCacheId,$data);
}
storeSession($SESSION);
?>