<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST);
$reviewTypesSession=getFilter('review_type_filter','filter',0,$SESSION);

if(!getFilter('area','filter',0,$SESSION) || !getFilter('program','filter',0,$SESSION) || !getFilter('msn','filter',0,$SESSION) || !getFilter('coe','filter',0,$SESSION))
{
	?>OK|||no_program_coe_msn<?php
}
else
{
	?>OK|||trl&&&<?php

	function drawLargeDfqgList($largeTitle,$largeTitleColour,$largeTitleBgColour,$smallDfqgList)
	{
		?><table id="<?=$largeTitle?>" class="dfqlTableLarge" bgcolor="#<?=$largeTitleBgColour?>" cellpadding="0" cellspacing="0"><?php
			?><tr style="color:#<?=$largeTitleColour?>"><?php
				?><td><?=$largeTitle?></td><?php
			?></tr><?php
			foreach ($smallDfqgList as $number => $values) 
			{
				?><tr><?php
					?><td><?php
						drawSmallDfqgList($values['title'],$values['titleColour'],$values['titleBgColour']);
						if(is_array($values['msnInfo']))
						{
							drawMsnList($values['msnInfo'][0],$values['msnInfo'][1],$values['msnInfo'][2],$values['msnInfo'][3]);
						}
					?></td><?php
					if(is_array($values['linkInfo']))
					{
						?><td><?php
							drawLink($values['linkInfo'][0],$values['linkInfo'][1],$values['linkInfo'][2],$values['linkInfo'][3]);
						?></td><?php
					}
				?></tr><?php
			}
		?></table><?php

		?><div style="height:10; clear:both;"></div><?php
	}

	function drawSmallDfqgList($title,$titleColour,$titleBgColour)
	{
		?><table id="<?=$title?>" class="dfqlTableSmall" cellpadding="5" cellspacing="0"><?php
			?><tr style="color:#<?=$titleColour?>"><?php
				?><td bgcolor="#<?=$titleBgColour?>"><?=$title?></td><?php
			?></tr><?php
		?></table><?php
	}

	function drawMsnList($msnLetter,$msnColours,$msnNewest,$msnText='')
	{
		?><table id="<?=$title?>_MSNs" class="dfqlTableMsn" cellpadding="5" cellspacing="0"><?php
			?><tr style="color:#000000"><?php
				?><tr><?php
					if(empty($msnText))
					{
						foreach ($msnColours as $colour) 
						{ 
							?><td bgcolor="#<?=$colour?>"><?=$msnLetter?></td><?php
						}

						?></tr><?php
						?><tr><?php

						$i=0;

						foreach ($msnColours as $colour)
						{
							?><td bgcolor="#<?=$colour?>"><?=($msnNewest-$i)?></td><?php
							$i++;
						}
					}
					else
					{
						?><td bgcolor="#FFFFFF"><?=$msnText?></td><?php
					}
				?></tr><?php
			?></tr><?php
		?></table><?php

		?><div style="height:10; clear:both;">&nbsp;</div><?php
	}

	function drawLink($size,$direction,$above,$below)
	{
		?><table class="dfqlTableLink<?=$size?>" cellpadding="0" cellspacing="0"><?php
			?><tr><?php
				?><td style="border-bottom:#000000 1px inset;<?=($above)?'border-right:#000000 1px inset':''?>;">&nbsp;</td><?php
				?><td style="<?=($direction=='right')?'border-bottom:#000000 1px inset':''?>;<?=($above)?'border-left:#000000 1px inset':''?>;">&nbsp;</td><?php
			?></tr><?php
			?><tr><?php
				?><td style="border-top:#000000 1px inset;<?=($below)?'border-right:#000000 1px inset':''?>;">&nbsp;</td><?php
				?><td style="<?=($direction=='right')?'border-top:#000000 1px inset':''?>;<?=($below)?'border-left:#000000 1px inset':''?>;">&nbsp;</td><?php
			?></tr><?php
		?></table><?php
	}




	?><div style="margin-left:auto; margin-right:auto; width:2000px;"><?php

		?><div id="level_1" style="width:350px; float:left;"><?php

			drawSmallDfqgList('S13/14 - PAG','000000','FFFFFF');
			drawMsnList('R',array('81c341','81c341','81c341','81c341'),'15');

			drawSmallDfqgList('PAX & Cargo Doors - EC DE','000000','FFFFFF');
			drawMsnList('R',array('ef343f','ef343f','f8d707','ef343f'),'12');

			drawSmallDfqgList('ESI / Harnesses - Labinal','000000','FFFFFF');
			drawMsnList('','','','Process requirement "green QG" leads to late deliveries.');

			drawSmallDfqgList('Primary Insulation Installation - Turnip','000000','FFFFFF');
			drawMsnList('R',array('ef343f','ef343f','ef343f','ef343f'),'12');

		?></div><?php

		?><div id="level_1_links" style="width:100px; float:left;"><?php
			drawLink('Small','right',0,1);
			drawLink('Small','upOrDown',1,1);
			drawLink('Small','upOrDown',1,1);
			drawLink('Small','upOrDown',1,0);
		?></div><?php

		?><div id="level_2" style="width:350px; float:left"><?php
			
			$hamburg=array();
			$hamburg[0]['title']='Pre-FAL Equipping';
			$hamburg[0]['titleColour']='000000';
			$hamburg[0]['titleBgColour']='FFFFFF';
			$hamburg[0]['msnInfo']=array('S',array('ef343f','ef343f','ef343f','ef343f'),'10');

			drawLargeDfqgList('Hamburg S13/14','FFFFFF','6f95ab', $hamburg);

			drawSmallDfqgList('PAX Doors - EC DE','000000','FFFFFF');
			drawMsnList('R',array('ef343f','FFFFFF','ef343f','f8d707'),'7');

			$aerolia=array();
			$aerolia[0]['title']='S11 - Aerolia';
			$aerolia[0]['titleColour']='000000';
			$aerolia[0]['titleBgColour']='FFFFFF';
			$aerolia[0]['msnInfo']=array('R',array('ef343f','ef343f','ef343f','ef343f'),'14');

			$aerolia[1]['title']='S12 - Aerolia';
			$aerolia[1]['titleColour']='000000';
			$aerolia[1]['titleBgColour']='FFFFFF';
			$aerolia[1]['msnInfo']=array('R',array('ef343f','ef343f','ef343f','ef343f'),'14');

			$aerolia[2]['title']='Lower Unit - Aerolia';
			$aerolia[2]['titleColour']='000000';
			$aerolia[2]['titleBgColour']='FFFFFF';
			$aerolia[2]['msnInfo']=array('R',array('ef343f','ef343f','ef343f','ef343f'),'14');

			$aerolia[3]['title']='Nose Fairing - Aerolia';
			$aerolia[3]['titleColour']='000000';
			$aerolia[3]['titleBgColour']='FFFFFF';
			$aerolia[3]['msnInfo']=array('R',array('ef343f','ef343f','ef343f','ef343f'),'14');

			drawLargeDfqgList('Aerolia Méaulte','FFFFFF','6f95ab', $aerolia);

			drawSmallDfqgList('Harnesses - Labinal','000000','FFFFFF');
			drawMsnList('R',array('f8d707','f8d707','81c341','f8d707'),'11');

			$dzo=array();
			$dzo[0]['title']='Main Instrument Panel';
			$dzo[0]['titleColour']='000000';
			$dzo[0]['titleBgColour']='FFFFFF';
			$dzo[0]['msnInfo']=array('S',array('FFFFFF','FFFFFF','FFFFFF','FFFFFF'),'0');

			drawLargeDfqgList('DZO','FFFFFF','6f95ab', $dzo);
			
		?></div><?php

		?><div id="level_2_links" style="width:100px; float:left;"><?php
			drawLink('Large','right',0,1);
			drawLink('Small','upOrDown',1,1);
			drawLink('Large','upOrDown',1,1);
			drawLink('Small','upOrDown',1,1);
			drawLink('Small','upOrDown',1,1);
			drawLink('Large','upOrDown',1,1);
			drawLink('Small','upOrDown',1,1);
			drawLink('Large','upOrDown',1,0);

		?></div><?php

		?><div id="level_3" style="width:600px; float:left"><?php

			$stNazaire=array();
			$stNazaire[0]['title']='Polaris S11/12 Assy';
			$stNazaire[0]['titleColour']='000000';
			$stNazaire[0]['titleBgColour']='FFFFFF';
			$stNazaire[0]['msnInfo']=array('S',array('FFFFFF','FFFFFF','FFFFFF','FFFFFF'),'0');
			$stNazaire[0]['linkInfo']=array('Small','upOrDown',0,1);

			$stNazaire[1]['title']='Comete 4 S11/12 Syst Inst';
			$stNazaire[1]['titleColour']='000000';
			$stNazaire[1]['titleBgColour']='FFFFFF';
			$stNazaire[1]['linkInfo']=array('Small','upOrDown',1,1);

			$stNazaire[2]['title']='Polaris S11/14 Junction';
			$stNazaire[2]['titleColour']='000000';
			$stNazaire[2]['titleBgColour']='FFFFFF';
			$stNazaire[2]['msnInfo']=array('S',array('FFFFFF','FFFFFF','FFFFFF','FFFFFF'),'0');
			$stNazaire[2]['linkInfo']=array('Small','upOrDown',1,1);

			$stNazaire[3]['title']='Comete 4 S11/14 Syst Inst';
			$stNazaire[3]['titleColour']='000000';
			$stNazaire[3]['titleBgColour']='FFFFFF';
			$stNazaire[3]['linkInfo']=array('Small','upOrDown',1,0);

			drawLargeDfqgList('Saint-Nazaire S11/14','FFFFFF','6f95ab', $stNazaire);

		?></div><?php

	?></div><?php

	?><input id="mainTableCacheId"type="hidden"value="<?=$tableCacheId?>"><?php
}
storeSession($SESSION);

?>