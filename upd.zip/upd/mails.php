<?php
function Return_Headers(){
	$headers = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From: Design Quality Review Planning <noreply@airbus.com>\r\n"; 
	$headers .= "Reply-To: noreply@airbus.com\r\n"; 
	$headers .= "Return-path: noreply@airbus.com\r\n";
	$headers .= "Cc: \r\n";
	$headers .= "Bcc: \r\n";
	
	return $headers;
}
function Send_Mail_Recover_Password($Name,$Surname,$Email,$New_Password){
	$headers=Return_Headers();

	$Mail_Body='
	<html>
	<head>
		<title>Password recovery</title>
	</head>
	<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
		<div style="width: 100%; height: 300px; cellSpacing=1; cellPadding=0; border=0;">
		<table align="center">
		  <tr>
			<td style="	background-color:#7D94CA; color:#FFFFFF; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; font-weight:bold; padding-left:10px;">
				Password Recovery
			</td>	
		</tr>
		<tr>
			<td style="	border-style:solid; border-color:#CCCCCC; border-width:1px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; padding-left:10px;">
				<strong>Dear '.$Name.' '.$Surname.',</strong><br>
				<p>
				this is an automatic Email to recover your password.<br><br>
				Your new password is <strong>'.$New_Password.'</strong>. 
				</p>
				Please, change this password as soon as possible.<br><br>
				To access to the Interface, just click on this link:<br>
				<a http://art-int.eu.airbus.corp/1V55">
				http://art-int.eu.airbus.corp/1V55</a><br><br>
				Remember that in the Login Area the Password is case sensitive.<br><br>
				Please, do not reply to this message.<br>
				<br><br><br>
				Best regards,<br><br>
				Design Reviews Team.
			</td>
		  </tr>
		</table>
	</div>
	</body>
	</html>';
	
	mail($Email,'Password Recovery',$Mail_Body,$headers);
}?>