<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
$included=1;
if(!$POST)$POST=cleanArray($_POST);
if(!$POST)$POST=cleanArray($GET);
if(!$POST)$POST=cleanArray($_GET);
$listTitle=array('action'=>'Action List','rid'=>'RID List','change'=>'Bugs / Improvements List', 'cat'=>'Criteria Catalogue Management', 'evd'=>'Evidence List', 'usr'=>'User Management', 'risk'=>'Risk List');//JFM 21_08_13 - JFM 28_04_14 - JFM 16_01_15 - JFM 08_06_16

$tableCacheId=newTableCacheId($SESSION);
//Added for Edit bulk user
$SESSION['bulkEdit']['users'] = $POST['bulkEdit']; 
//JFM 11_03_14
if(!in_array('msn',$POST))
{
	if($POST['msn']==0) $msnTxt=SqlQ('SELECT msn FROM c_msn WHERE msn_id="'.getFilter('msn','filter',0,$SESSION).'"');
	else 				$msnTxt['msn']=$POST['msn'];
	$SESSION['filter'][$SESSION['object']['msn_txt']][$SESSION['user_action']['filter']][0]=$msnTxt['msn'];
	$msnTxtPadded=str_pad($msnTxt['msn'], 4, "0", STR_PAD_LEFT);
	$SESSION['filter'][$SESSION['object']['rid_code']][$SESSION['user_action']['filter']][0]=$msnTxtPadded;
}
else
{
	unset($SESSION['filter'][$SESSION['object']['msn_txt']][$SESSION['user_action']['filter']][0]);
	unset($SESSION['filter'][$SESSION['object']['rid_code']][$SESSION['user_action']['filter']][0]);
}


?>OK|||<?php

?><div id="<?=$POST['list_name']?>ListContainer"style="padding-right:10px;"><?php
        /*
         * US#21.1 - Siglum/Company Name
         * Added condtion for User Management Refresh
         * Version - 4.3
         * Added By: Infosys Limited
         */
        if($POST['list_name'] =='usr')
	{
		formUerMan('',$listTitle[$POST['list_name']],$POST['list_name'].'ListContainer',$tableCacheId,array('lst',$POST['list_name'],$POST['list_name'],$tableCacheId,'',$POST['ca']),$POST['list_name']); //JFM 28_04_14
		?><div class="sp"></div><?php
	}
	else if($POST['list_name']!='cat') //JFM 23_09_13
	{
		formTitle('',$listTitle[$POST['list_name']],$POST['list_name'].'ListContainer',$tableCacheId,array('lst',$POST['list_name'],$POST['list_name'],$tableCacheId,'',$POST['ca']),$POST['list_name']); //JFM 28_04_14
		?><div class="sp"></div><?php
	}
		require_once('../ajax/list.php');
	?><div class="sp"></div><?php
?></div><?php
storeSession($SESSION);

?>