<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

?>OK|||<?php

// To select all the available sections from database
$helpSections = SqlLi('SELECT section_id,section_name FROM c_help_sections');

?><div id="help_faq"style="padding-right:10px; padding-left:10px;"><?php
	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo">Help, FAQs & About</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="sp"></div><?php

	?><div style="font-size:14px;" align="left"><?php

		?><div class="tableTitle">Help:</div><?php 

		//--------------------------------------0-------------------------------------
                ?><div id="help_0"><?php
                    ?><table class="criteriaTable" style="text-align:center; border:0; width:100%;" align="left" cellspacing="0" cellpadding="5"><?php
                        foreach($helpSections as $sectionId => $section) {
                            $allDocuments = SqlLi('SELECT document_name,document_path FROM c_help_docs WHERE section='.$section['section_id']);
                            
                            ?><tr class="tableGroup"><?php
					?><td colspan="100"><?=$section['section_name']?></td><?php
                            ?></tr><?php
                            
                            ?><tr><?php
                                foreach($allDocuments as $docId => $document) {
                                    $docType = end((explode(".", $document['document_path'])));
                                    if($docType == 'pdf') {
                                        $docIcon = "../common/img/pdf.png";
                                    }
                                    else if($docType == 'pptx') {
                                        $docIcon = "../common/img/ppt.png";
                                    }
                                    else if($docType == 'mp4') {
                                        $docIcon = "../common/img/video_icon.png";
                                    }
                                
                                    if($docType == 'mp4') {
                                        ?><td style="width:5%" class="paramDef"><a href="<?=$document['document_path']?>" target="_blank"><img width="75" alt="Click to download..." src="<?=$docIcon?>"style="cursor:pointer;"></a></td><?php
                                    } else {
                                        ?><td style="width:5%" class="paramDef"><a href="<?=$document['document_path']?>" target="_blank"><img alt="Click to download..." src="<?=$docIcon?>"style="cursor:pointer;"></a></td><?php
                                    }
                                    
                                } 
                            ?></tr><?php
                            ?><tr><?php
                                foreach($allDocuments as $doc => $documentName) {
                                    ?><td><?=$documentName['document_name']?></td><?php
                                }
                            ?></tr><?php
                        }
                    ?></table><?php
                ?></div><?php
                
                //----------------------------------------------------------------------------
		/*?><div id="help_0"><?php
			?><table class="criteriaTable" style="text-align:center; border:0; width:100%;" align="left" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="100">Download Documents</td><?php
				?></tr><?php

				?><tr><?php
					/*
					Sprint3 - Additional Task
					Videos has been added
					Version: 4.3
					Fixed By: Infosys Limited
					*/
					/*?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_Engineering.pdf" target="_blank"><img alt="Click to download..." src="../common/img/pdf.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_Quality_admin.pdf" target="_blank"><img alt="Click to download..." src="../common/img/pdf.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Design_Review_Tool_V4_User_Guide.pptx" target="_blank">				<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_V4.5_Lead _Engineers_Guide.pptx" target="_blank">	<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_V4.5_Secretary_Guide.pptx" target="_blank">		<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_V4.5_Viewer_Guide.pptx" target="_blank">			<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_V4_2_EL_Lead_Engineers_Guide.pptx" target="_blank"><img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_V4_2_EL_Secretary_Guide.pptx" target="_blank">		<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_V4_2_EL_Viewer_Guide.pptx" target="_blank">		<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Design_Review_Tool_V3_4_CA_Providers_Guide.pptx" target="_blank">		<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Design_Review_Tool_V3_4_CA_Stakeholder_Guide.pptx" target="_blank">	<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/M2933_0.pdf" target="_blank">											<img alt="Click to download..." src="../common/img/pdf.png"style="cursor:pointer;"></a></td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/AP2604_0.pdf" target="_blank">										<img alt="Click to download..." src="../common/img/pdf.png"style="cursor:pointer;"></a></td><?php
				?></tr><?php

				?><tr><?php
				/*
					Sprint3 - Additional Task
					Videos has been added download option
					Version: 4.3
					Fixed By: Infosys Limited
				*/
				/*	?><td>Airbus Review Tool Engineering</td><?php
					?><td>Airbus Review Tool Quality Admin</td><?php
					?><td>V4 End-2-End User Guide</td><?php
					?><td>V4.5 Lead Engineer Guide</td><?php
					?><td>V4.5 Secretary Guide</td><?php
					?><td>V4.5 Viewer Guide</td><?php
					?><td>V4.5 Landing Gear Lead Engineer Guide</td><?php
					?><td>V4.5 Landing Gear Secretary Guide</td><?php
					?><td>V4.5 Landing Gear Viewer Guide</td><?php
					?><td>V3.4 CAP Provider Guide</td><?php
					?><td>V3.4 CAP Stakeholder Guide</td><?php
					?><td>Design Reviews Manual</td><?php
					?><td>Management of Design Reviews</td><?php
				?></tr><?php
				/*
					Sprint3 - Additional Task
					Videos has been added and download option
					Version: 4.3
					Fixed By: Infosys Limited
				*/
               /* ?><tr class="tableGroup"><?php
                    ?><td colspan="100">Training Videos</td><?php
				?></tr><?php
					
				?><tr><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Introduction.mp4" target="_blank"><img width="75" alt="Click to download..." src="archive/video_icon.png" style="cursor:pointer;"></a> </td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Navigation.mp4" target="_blank"><img width="75" alt="Click to download..." src="archive/video_icon.png" style="cursor:pointer;"></a> </td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Edit_BRAG_and_PPT.mp4" target="_blank"><img width="75" alt="Click to download..." src="archive/video_icon.png" style="cursor:pointer;"></a> </td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Actions_and_RIDs.mp4" target="_blank"><img width="75" alt="Click to download..." src="archive/video_icon.png" style="cursor:pointer;"></a> </td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Remarks_and_RAG.mp4" target="_blank"><img width="75" alt="Click to download..." src="archive/video_icon.png" style="cursor:pointer;"></a> </td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/Adding_documents_links.mp4" target="_blank"><img width="75" alt="Click to download..." src="archive/video_icon.png" style="cursor:pointer;"></a> </td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/A0_report.mp4" target="_blank"><img width="75" alt="Click to download..." src="archive/video_icon.png" style="cursor:pointer;"></a> </td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/My_task_tab.mp4" target="_blank"><img width="75" alt="Click to download..." src="archive/video_icon.png" style="cursor:pointer;"></a> </td><?php
					?><td style="width:5%" class="paramDef"><a href="archive/KPIs.mp4" target="_blank"><img width="75" alt="Click to download..." src="archive/video_icon.png" style="cursor:pointer;"></a> </td><?php
				?></tr><?php
					
				?><tr><?php
					?><td>Introduction</td><?php
					?><td>Navigation</td><?php
					?><td>Edit BRAG and PPT</td><?php
					?><td>Actions and RIDs</td><?php
					?><td>Remarks and RAG</td><?php
					?><td>Documents Links</td><?php
					?><td>Review Report</td><?php
					?><td>My Task Tab</td><?php
					?><td>KPIs</td><?php
				?></tr><?php
				/* End for additional task*/
					
                                /* Fix for Bug-8
                                 * Help, FAQ's & About - Cabin Guides Missing
                                 * Fixed By - Infosys Limited
                                 * Version - 4.2
                                 */
                           /*     ?><tr class="tableGroup"><?php
                                    ?><td colspan="100">Cabin and Cargo Documents</td><?php
								?></tr><?php
                                
                                ?><tr><?php
                                    ?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_V5_1_EC_Lead _Engineers_Guide.pptx" target="_blank">		<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
                                    ?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_V5_1_EC_External_Supplier_Guide.pptx" target="_blank">		<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
                                    ?><td style="width:5%" class="paramDef"><a href="archive/Airbus_Review_Tool_V5_1_EC_Viewer_Guide.pptx" target="_blank">		<img alt="Click to download..." src="../common/img/ppt.png"style="cursor:pointer;"></a></td><?php
                                ?></tr><?php
                                
                                ?><tr><?php
                                    ?><td>V5.1 Cabin Engineer Guide</td><?php
                                    ?><td>V5.1 Cabin Supplier Guide</td><?php
                                    ?><td>V5.1 Cabin Viewer Guide</td><?php
                                ?></tr><?php
                                // End of Bug-8
			?></table><?php
		?></div><?php */
		
		?><div id="help_5" style="margin-top:10px;"><?php
			?><table class="criteriaTable" style="text-align:left; border:0; width:50%;" align="left" cellpadding="5" cellspacing="0"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="6">Re-Run First Login Tutorial</td><?php
				?></tr><?php
				?><tr><?php
					?><td class="paramDef"><?php
						?><input class="stdBtn" type="button" style="width:200px;" onclick="ajaxRequest('ajax/rerunTutorial.php','refreshOrReloadEntirePage',false,'GET');" value="Click Here to Re-Run Tutorial &#9658;"><?php 
					?></td><?php
				?></tr><?php
			?></table><?php
		?></div><?php		

		?><div class="sp"></div><?php

	?></div><?php

?></div><?php
storeSession($SESSION);

?>