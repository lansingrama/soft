<?php
/*
* US#107 - User Log for Reviews
* Version: V 4.4
* To display the log data for specific review
* Created by : Infosys Limited
*/
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');
if(!$GET)cleanArray($_GET);
if(!$POST)$POST=cleanArray($_POST);
$_SESSION['review_profile']=$POST['review_profile'];
$_SESSION['ca']=$POST['ca'];
$tableCacheId=newTableCacheId($SESSION);
$included=1;
?>OK|||<div id="logContainer"style="text-align:center;width:960px;"><?php
		 	?><div class="formHeader"><?php 
		?><div class="formHeaderInfo">Review Log</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="sp"></div><?php

	?><div class="wideFormTable" id="reviewCriteriaList"><?php
		require_once('../ajax/reviewLog.php');
	?></div><?php
storeSession($SESSION);
?>