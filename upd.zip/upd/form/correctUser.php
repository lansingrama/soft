<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$invalidName=array();

$review=allowedReviews($SESSION,'edit','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION));
$perimeter=perimeterPermission($SESSION,'view');

/* JFM 04_09_13
$invalidActionRidName=SqlLi('SELECT DISTINCT act.action_holder_name,act.action_validator_name,
								rid.rid_holder_name
							FROM dr_action AS act
								INNER JOIN dr_review_criteria		AS rcr	ON act.criteria=rcr.review_criteria_id
								INNER JOIN dr_review_group			AS rgr	ON rcr.review_group=rgr.review_group_id
								INNER JOIN dr_action_applicability	AS aap	ON act.action_id=aap.action
								INNER JOIN c_ca						AS c	ON aap.ca=c.ca_id
								LEFT JOIN dr_rid					AS rid	ON (rid.rid_id=act.rid AND rid.rid_holder!=0 AND rid.rid_holder_name!="")
							WHERE rgr.review_profile IN('.implode(',',array_keys($review)).')
								AND c.perimeter IN('.implode(',',array_keys($perimeter)).')
								AND(
									(act.action_holder=0 AND act.action_holder_name!="")
										OR (act.action_validator=0 AND act.action_validator_name!="")
								)');*/
								
$invalidActionRidName=SqlLi('SELECT DISTINCT act.action_holder_name,act.action_validator_name,
								rid.rid_holder_name
							FROM dr_action AS act
								INNER JOIN dr_review_criterion		AS rcr	ON act.criteria=rcr.review_criterion_id
								INNER JOIN dr_review_group			AS rgr	ON rcr.review_group=rgr.group_id
								INNER JOIN dr_review_profile		AS rp	ON rgr.review_type=rp.review_type
								INNER JOIN dr_action_applicability	AS aap	ON act.action_id=aap.action
								INNER JOIN c_ca						AS c	ON aap.ca=c.ca_id
								LEFT JOIN dr_rid					AS rid	ON (rid.rid_id=act.rid AND rid.rid_holder!=0 AND rid.rid_holder_name!="")
							WHERE rp.review_profile_id IN('.implode(',',array_keys($review)).')
								AND c.perimeter IN('.implode(',',array_keys($perimeter)).')
								AND(
									(act.action_holder=0 AND act.action_holder_name!="")
										OR (act.action_validator=0 AND act.action_validator_name!="")
								)');

if(is_array($invalidActionRidName)){
	foreach($invalidActionRidName as $i){
		if($i['action_holder_name']!=''){
			$invalidName[$i['action_holder_name']]=1;
		}
		if($i['action_validator_name']!=''){
			$invalidName[$i['action_validator_name']]=1;
		}
		if($i['rid_holder_name']!=''){
			$invalidName[$i['rid_holder_name']]=1;
		}
	}
}

?>OK|||<div id="correctUserContainer"style="text-align:center;width:960px;"><?php

	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo">Correct User</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	
	?><div class="searchListContainer"><?php
		?><input class="searchField"id="searchInvalidUser"onBlur="txtBlr(this,'Search');"onFocus="txtOF(this,'Search');"onKeyUp="wek=window.event.keyCode;if(searchCount<=searchMax||wek==13||wek==27)searchDivList(this.value,'rmInvalidUserSearchImg','searchInvalidUser','invalidUserNotFound',2);"size="28"type="text"value="Search"><?php
		?><img id="rmInvalidUserSearchImg"src="../common/img/searchBlank.png"style="padding-left:3px;"><?php
		?><img alt="Click to search"onClick="searchDivList($('searchInvalidUser').value,'rmInvalidUserSearchImg','searchInvalidUser','invalidUserNotFound',2);" src="../common/img/search.png" style="cursor:pointer;"><?php
	?></div><?php

	?><div class="sideList"id="invalidUserList" style="top:100px;"><?php
		if(is_array($invalidName)){
			$invalidNameCount=0;
			foreach($invalidName as $name=>$n){
				?><div class="sideElement"id="invalidNameElement_<?=$invalidNameCount?>"onClick="openSideElement('<?=$invalidNameCount?>','inn','<?=$name?>');"><?=utf8_encode($name)?></div><?php
				$invalidNameCount++;
			}
		}
		?><div class="sideElementEmpty"id="invalidUserNotFound">User Not Found</div><?php
	?></div><?php
	
	?><div class="sideDetailsContainer"id="sideInvalidNameContainer"><?php
		?><div class="sideContainerEmpty">Select a User from the list.</div><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>