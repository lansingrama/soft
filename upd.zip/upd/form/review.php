<?php
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');
$GET=cleanArray($_GET);
$mainTableCacheId=$GET['main_table_cache_id'];
$target=$GET['target'];
$included=1;

if($target==''){
	$target='ca';
}
$targetRd[$target]='checked';

if(checkPermission('dr_review_profile_general','view',0,'check',$SESSION)==1){
	$reviewProfileList=SqlAsArr('SELECT review_profile_id,review_type FROM dr_review_profile WHERE program="'.getFilter('program','filter',0,$SESSION).'" AND coe="'.getFilter('coe','filter',0,$SESSION).'"','review_profile_id','review_type');
}else{
	$reviewProfileList=allowedSimpleObject('review_profile','review_type',$SESSION,'dr_','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION));
}

if(is_array($reviewProfileList)){
	foreach($reviewProfileList as $k=>$v){
		$validReviewProfile[$k]=$SESSION['review_type'][$k];
	}
	
	?>OK|||<?php
		?><div class="formHeader"><?php
			?><div class="formHeaderInfo">Review - <?php
				drawddList('rvmDdRevType',$validReviewProfile,$GET['review'],'','changeReviewProfile();',1);
			?></div><?php
									/**
									* Fix for : US#19 Change workflow for creating a design review  
									* Added for displaying general information data to main table
									* Version: 4.3
									* Fixed By: Infosys Limited
									*/
								
			?>	<!-- Refreshing main table content using javascript -->
			<div class="xDiv" onclick="refreshMainTable();">&#9668; Back</div><?php
		?></div><?php

		/*?><div class="locationSideContainer" style="text-align:left; z-index:10; width:200px; left:10px;" id="idontknow"><?php
			?><div>Review type:</div><?php
			?><div><?php
				drawddList('rvmDdRevType',$validReviewProfile,$GET['review'],'','changeReviewProfile();',1);
			?></div><?php
		?></div><?php*/
		
		?><div class="sideList" id="colapseSidebar" style="z-index:9; cursor:pointer; color:#FFFFFF;left:0; width:10px;top:48px;background-color:#6f95ab;overflow:hidden;text-align:center;font-size:10px;padding-top:200px;" onclick="colapseSidebar('reviewSideBar');">&#9658;<br /><br />E<br />x<br />p<br />a<br />n<br />d<br /><br />S<br />i<br />d<br />e<br />b<br />a<br />r<br /><br />&#9658;</div><?php //JFM 17_08_15
		
		?><div id="reviewSideBar" class="locationSideContainer"style="width:50px;display:none;"><?php
/*			?><div class="ddSpace"></div><?php
			?><div class="ddSpace"></div><?php*/
			?><div class="searchListContainer"style="width:170px; top:5px;"><?php
				?><input class="searchField <?php if(!$mainFilter)echo'inactive'?>"id="searchReviewCaWp"onBlur="txtBlr(this,'Search');"onFocus="txtOF(this,'Search');"onKeyUp="wek=window.event.keyCode;if(searchCount<=searchMax||wek==13||wek==27)searchDivList(this.value,'rmReviewCaWpSearchImg','searchReviewCaWp','reviewCaWpNotFound',1);"size="15"type="text"value="Search"><?php
				?><img id="rmReviewCaWpSearchImg"src="../common/img/searchBlank.png"style="padding-left:3px;"><?php
				?><img alt="Click to search"onClick="searchDivList($('searchUser').value,'rmUserSearchImg','searchUser','userNotFound',1);" src="../common/img/search.png" style="cursor:pointer;"><?php
			?></div><?php
		?></div><?php

		?><div class="sideList"id="reviewCaWpList"style="top:80px;display:none;"><?php
			require_once('../ajax/sideCaWp.php');
		?></div><?php
	
		?><div class="sideDetailsContainer"id="sideReviewContainer" style="left:25px;"><?php
			?><div class="formStdContainer"id="subFormReviewReportContainer"><div class="noMainTableShown" style="margin-top:100px;"><span style="font-size:36px;">Please wait...</span></div></div><?php
		?></div><?php
}
storeSession($SESSION);?>