<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$totalRows=0;
$totalRowsDone=0;

$GET=cleanArray($_GET);
if($included!=1)
{
	$criterionId=$GET['criterionId'];
	$criterionValidityId=$GET['criterionValidityId'];
	$reviewProfile=$GET['reviewProfile'];
}

$criteriaEdit=0;
$alreadyInValidationLoop=0;

if(!empty($criterionId))
{
	$alreadyInValidationLoopQry=SqlLi('SELECT 1
										FROM dr_review_criterion_history 
										WHERE criterion='.$criterionId.'
										AND criterion_valid_from="0000-00-00 00:00:00"');
	
	$criterionQry=SqlLi('SELECT criterion_user_id, criterion_name, criterion_description,criterion_showstopper,criterion_position,criterion_moc
							FROM dr_review_criterion_history 
							WHERE criterion='.$criterionId.'
							AND criterion_validity_id='.$criterionValidityId);

	$disciplineQry=SqlLi('SELECT applicability
							FROM dr_review_criterion_applicability
							WHERE object IN (SELECT object_id FROM c_object WHERE object LIKE "discipline")
							AND criterion='.$criterionId.'
							AND review_criterion_applicability_valid_to="0000-00-00 00:00:00"');
							
	$applicationLevelQry=SqlLi('SELECT applicability
								FROM dr_review_criterion_applicability
								WHERE object IN (SELECT object_id FROM c_object WHERE object LIKE "application_level")
								AND criterion='.$criterionId.'
								AND review_criterion_applicability_valid_to="0000-00-00 00:00:00"');
	
	$gramsQry=SqlLi('SELECT g.grams_reference
						FROM c_grams AS g
							INNER JOIN dr_review_criterion_applicability as rca ON g.grams_id=rca.applicability
						WHERE rca.object=(SELECT object_id FROM c_object WHERE object="grams_id")
						AND criterion='.$criterionId.'
						AND review_criterion_applicability_valid_to="0000-00-00 00:00:00"');

	$reviewArea=SqlLi('SELECT DISTINCT rt.area 
						FROM dr_review_type AS rt 
							INNER JOIN dr_review_group AS rg ON rg.review_type = rt.review_type_id
							INNER JOIN dr_review_criterion AS rc ON rc.review_group = rg.group_id
							WHERE rc.review_criterion_id='.$criterionId); //JFM 08_06_16

	if($modifying==1) //JFM 03_12_13
	{
		$validatorsQry=SqlLi('SELECT CONCAT(u.surname,\', \',u.name) AS validator_full_name
								FROM c_user as u 
									INNER JOIN dr_validation_loop_structure	AS vls ON u.user_id=vls.validator
								WHERE vls.object=(SELECT object_id FROM c_object WHERE object="criterion_validity_id")
								AND vls.applicability='.$criterionValidityId.'
								AND vls.validation_loop_structure_step!=0
								AND vls.validator_removed=0
								ORDER BY validation_loop_structure_id ASC');
	}
													
	$criterionUserID=$criterionQry[0]['criterion_user_id'];
	$criterionName=$criterionQry[0]['criterion_name'];
	$criterionDescription=$criterionQry[0]['criterion_description'];
	$criterionShowstopper=$criterionQry[0]['criterion_showstopper'];	
	$criterionPosition=$criterionQry[0]['criterion_position'];	
	$criterionMoc=$criterionQry[0]['criterion_moc'];	
	
	if(!$GET['subVersion']) $criteriaEdit=1;
	if(!empty($alreadyInValidationLoopQry)) $alreadyInValidationLoop=1;
}
else
{
	$criterionId = 'Generated On Submit...';
}

$allDisciplines=SqlLi('SELECT discipline_id, discipline FROM c_discipline');
$allApplicationLevels=SqlLi('SELECT application_level_id, application_level FROM c_application_level');
$allGrams=SqlLi('SELECT grams_id, grams_reference FROM c_grams');
$allReviewGroups=SqlLi('SELECT rgh.review_group_description, rg.group_id
						FROM dr_review_group_history		AS rgh
							INNER JOIN dr_review_group		AS rg ON rgh.review_group=rg.group_id
							INNER JOIN dr_review_profile	AS rp ON rg.review_type=rp.review_type
						WHERE rp.review_profile_id="'.$reviewProfile.'"
						AND rgh.review_group_valid_to="0000-00-00 00:00:00"');

$reviewType=SqlLi('SELECT rt.review_type
					FROM dr_review_type AS rt
					INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id
					WHERE rp.review_profile_id='.$reviewProfile);
				
					
$hoverCreate='On this screen you can create a brand new Criteria. Please fill out the form below and when complete press submit.<br /><br /><b>ID</b><br />- The criteria ID number will be automatically generated when you submit the criteria for approval.';
$hoverEdit;
$hoverAll='<br /><br /><b>Description</b><br />- All new criteria must have a valid description.<br /><br /><b>Criteria Validators</b></br>- These are the names of people who will review this criteria and approve or reject it.<br />- You must have at least one criteria validator.<br />- You cannot name yourself as a criteria validator.<br />- A criteria cannot be used unless all the validators have approved it.';

if($included!=1)
{
	?>OK|||<?php
}
?><div id="criteriaCreateContainer" style="text-align:center; width:960px; margin: 0 auto;"><?php
	if($included!=1)
	{
		?><div class="formHeader"><?php
			?><div class="formHeaderInfo"><?=($criteriaEdit==1)?'Edit':'Create';?> Criteria <?=($GET['subVersion'])?'Sub-Version':'';?></div><?php
			?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
			?><img style="padding-right:10px; float:right; margin-top:60px;" id="help" onMouseOut="nd();" onMouseOver="overlib('<?=$hoverCreate.$hoverAll?>', LEFT, CAPTION,'Criteria Help');"src="../common/img/xhelp.png"><?php //JFM 06_02_14
		?></div><?php
		?><div class="sp"></div><?php
	}

	?><div class="formStdContainer"><?php
	
		if($alreadyInValidationLoop==1 && $included!=1) 
		{
			?><div id="alreadyInValidationLoopResponse" style="font-size:14px; font-weight:bold; color:#FF0000">
											You cannot edit this criteria.<br />This criteria has already been edited and is in the process of being validated.</div><?php
		}
	
		?><form action="#" enctype="multipart/form-data" id="criteriaForm" name="criteriaForm" method="post" style="display:inline;"><?php
			?><input id="editCriteria" name="editCriteria" style="display:none;" value="<?=$criteriaEdit?>" disabled /><?php
			?><input id="criterionPosition" name="criterionPosition" style="display:none;" value="<?=$criterionPosition?>" disabled /><?php
			?><input id="criterionValidityId" name="criterionValidityId" style="display:none;" value="<?=$criterionValidityId?>" disabled /><?php
			?><input id="criteriaID" name="criteriaID" type="text" style="display:none;" value="<?=$criterionId?>" disabled /><?php
			?><input id="subVersion" name="subVersion" type="text" style="display:none;" value="<?=$GET['subVersion']?>" disabled /><?php
		
			//-----------------------------------------------------------EVERYTHING ELSE START------------------------------------------------------------
			?><table class="criteriaTable" id="criteriaTable" style="width:100%; border-bottom:0px;" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td colspan="4">Main Criterion Details</td><?php
				?></tr><?php
				
				?><tr class="infoRow"><?php
					?><td class="paramDef" width="25%">ID:<div id="criteriaUserIDResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
					?><td width="25%"><input class="textareaWhite" style="width:95%" id="criteriaUserID" name="criteriaUserID" type="text" value="<?=$criterionUserID?>" /></td><?php
					?><td class="paramDef" width="25%">Show Stopper:</td><?php
					?><td width="25%"><input type="checkbox" name="criteriaShowStopper" id="criteriaShowStopper" <?php if($criterionShowstopper != 0) echo 'checked'; ?> />It is a Show Stopper</td><?php
				?></tr><?php
				
				?><tr class="infoRow"><?php
					?><td colspan="1" rowspan="2" class="paramDef">Name:<div id="criteriaNameResponse" style="visibility:hidden;" >&zwnj;</div></td></td><?php
				?></tr><?php		
				?><tr><?php
					?><td colspan="3"><textarea class="textareaWhite" style="width:100%" rows="5" id="criterionName" name="criterionName"><?=$criterionName?></textarea></td><?php
				?></tr><?php
				
				?><tr class="infoRow"><?php
					?><td colspan="1" rowspan="2" class="paramDef">Description:<div id="criteriaDescriptionResponse" style="visibility:hidden;" >&zwnj;</div></td></td><?php
				?></tr><?php		
				?><tr><?php
					?><td colspan="3"><textarea class="textareaWhite" style="width:100%" rows="5" id="criteriaDescription" name="criteriaDescription"><?=$criterionDescription?></textarea></td><?php
				?></tr><?php
				
				?><tr class="infoRow"><?php
					?><td colspan="1" rowspan="2" class="paramDef"><?=$SESSION['table']['cat']['cat']['criterion_moc']['title']?>:</td><?php //JFM 08_06_16
				?></tr><?php
				?><tr style="display:<?=((getFilter('area','filter',0,$SESSION)==8 && $alreadyInValidationLoop!=1) || ($reviewArea[0]['area']==8 && $alreadyInValidationLoop==1))?'':'none'?>;"><?php
					?><td colspan="3"><?php
					?><select id="ecBox" name="ecBox" style="width:100%" onchange="$('criteriaMOC').innerHTML=this.value;"><?php
						?><option value="Low" <?=($criterionMoc=='Low')?'selected':''?> >1 - Low</option><?php
						?><option value="Medium" <?=($criterionMoc=='Medium')?'selected':''?> >2 - Medium</option><?php
						?><option value="High" <?=($criterionMoc=='High')?'selected':''?> >3 - High</option><?php
					?></select><?php		
					?></td><?php
				?></tr><?php
				?><tr style="display:<?=((getFilter('area','filter',0,$SESSION)==8 && $alreadyInValidationLoop!=1) || ($reviewArea[0]['area']==8 && $alreadyInValidationLoop==1))?'none':''?>;"><?php
					?><td colspan="3"><textarea class="textareaWhite" style="width:100%" rows="5" id="criteriaMOC" name="criteriaMOC"><?=$criterionMoc?></textarea></td><?php
				?></tr><?php
				
				if($criterionId == "Generated On Submit...")
				{
					?><tr class="infoRow"><?php
						?><td class="paramDef" width="200px">Criteria Group:<div id="criteriaGroupBoxResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
						?><td width="25%"><?php
							?><select id="groupBox" name="groupBox" style="width:100%"><?php
								?><option value="None" disabled selected>Please select a value...</option><?php
								foreach($allReviewGroups as $oneReviewGroup)
								{
									?><option value="<?=$oneReviewGroup['group_id']?>"><?=$oneReviewGroup['review_group_description']?></option><?php
								}
								
							?></select><?php
						?></td><?php
					?></tr><?php
				}
				
			?></table><?php

			if(getFilter('area','filter',0,$SESSION)==1) //JFM 08_06_16
			{
				?><table class="criteriaTable" id="criteriaTable" style="width:100%; border-top:0px; border-bottom:0px;" cellspacing="0" cellpadding="5"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="4">Applicability</td><?php
					?></tr><?php
				?></table><?php
				
				//
				// Discipline List
				//
				?><table class="criteriaTable" id="criteriaDisciplinesTable" style="width:100%;float:left; border-top:0px; border-bottom:0px;" cellspacing="0" cellpadding="5"><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" rowspan="100" width="15%">Disciplines:</td><?php

						?><td width="35%"><?php
						
							foreach($allDisciplines as $oneDiscipline)
							{
								?><input type="checkbox" name="discipline_<?=$oneDiscipline['discipline']?>" id="discipline_<?=$oneDiscipline['discipline']?>" <?php
								if(!empty($disciplineQry))
								{
									foreach($disciplineQry as $applicability)
									{
										if($oneDiscipline['discipline_id']==$applicability['applicability']) echo 'checked';
									}
								}
								?> /><?php 
								echo $oneDiscipline['discipline'].'<br />';
							}
							
						?></td><?php

						//
						// Application Level List
						//
						?><td class="paramDef" rowspan="100" width="15%">Application Level:</td><?php

						?><td width="35%"><?php		
						
							foreach($allApplicationLevels as $oneApplicationLevel)
							{
								?><input type="checkbox" name="application_level_<?=$oneApplicationLevel['application_level']?>" id="program_<?=$oneProgram['program']?>" <?php
									if(!empty($applicationLevelQry))
									{
										foreach($applicationLevelQry as $applicability)
										{
											if($oneApplicationLevel['application_level_id']==$applicability['applicability']) echo 'checked';
										}
									}
								?> /><?php 
								echo $oneApplicationLevel['application_level'].'<br />';
							}
							
						?></td><?php
					?></tr><?php			
				?></table><?php
			}
			
			//-----------------------------------------------------------EVERYTHING ELSE  END ------------------------------------------------------------
			
			?><table class="criteriaTable" id="criteriaTable" style="width:100%; border-top:0px; border-bottom:0px;" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><?php
					?><td width="50%">Validation Loop</td><?php
					?><td width="50%">References</td><?php
				?></tr><?php
			?></table><?php

			//
			// Validation List
			//
			
			?><table class="criteriaTable" id="criteriaValidatorsTable" style="width:50%;float:left; border-top:0px; border-right:0px;" cellspacing="0" cellpadding="5"><?php
				?><tr class="infoRow"><?php
					?><td class="paramDef" rowspan="100" width="15%">Criteria Validators:<div id="inputIDResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
				?></tr><?php
				
					$i=0;
					if(!empty($validatorsQry)) //JFM 03_12_13
					{
						foreach($validatorsQry as $validator)
						{
							?><tr id="rowelephantTigerBeehiveinputID<?=$i?>"><?php
								?><td width="35%" valign="top"><?php
									?><div class="suggestion"id="divID<?=$i?>"style="width:175px;"></div><?php
									?><input class="textareaWhite" id="elephantTigerBeehiveinputID<?=$i?> "name="elephantTigerBeehiveinputID<?=$i?>" value="<?=utf8_encode($validator['validator_full_name'])?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaValidatorsTable','divID','elephantTigerBeehiveinputID','suggestionID');" onFocus="loadUserSuggestion(this,'divID<?=$i?>','elephantTigerBeehiveinputID<?=$i?>','','suggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
									?><input class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehiveinputID<?=$i?>','criteriaValidatorsTable');" type="button" value="&#10008;"/><?php
								?></td><?php
							?></tr><?php
							$i++;
						}
					}
				
				?><tr id="rowelephantTigerBeehiveinputID<?=$i?>"><?php
					?><td width="35%" valign="top"><?php
						?><div class="suggestion"id="divID<?=$i?>"style="width:175px;"></div><?php
						?><input class="textareaWhite" id="elephantTigerBeehiveinputID<?=$i?>"name="elephantTigerBeehiveinputID<?=$i?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaValidatorsTable','divID','elephantTigerBeehiveinputID','suggestionID');" onFocus="loadUserSuggestion(this,'divID<?=$i?>','elephantTigerBeehiveinputID<?=$i?>','','suggestionID<?=$i?>');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
						?><input class="xRemove" onClick="deleteRowByInputID('elephantTigerBeehiveinputID<?=$i?>','criteriaValidatorsTable');" type="button" value="&#10008;"/><?php
					?></td><?php
				?></tr><?php
			?></table><?php
			
			//
			// Grams List
			//
			
			?><table class="criteriaTable" id="criteriaGramsTable" style="width:50%;float:right; border-top:0px; border-left:0px; clear:none;" cellspacing="0" cellpadding="5"><?php
				?><tr class="infoRow"><?php
					//JFM 19_07_16
					?><td class="paramDef" rowspan="100" width="15%">References:<div id="gramsResponse" style="visibility:hidden;">&zwnj;</div></td><?php
				?></tr><?php
				$i=0;
				if(!empty($gramsQry))
				{
					foreach($gramsQry as $gram)
					{
						?><tr id="rowgramsinputID<?=$i?>"><?php
							?><td width="35%" valign="top"><?php
								?><div class="suggestion"id="gramsdivID<?=$i?>"style="width:175px;"></div><?php
								?><input class="textareaWhite" id="gramsinputID<?=$i?>"name="gramsinputID<?=$i?>" value="<?=$gram['grams_reference']?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaGramsTable','gramsdivID','gramsinputID','gramssuggestionID','grams');" onFocus="loadUserSuggestion(this,'gramsdivID<?=$i?>','gramsinputID<?=$i?>','','gramssuggestionID<?=$i?>','grams');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
								?><input class="xRemove" onClick="deleteRowByInputID('gramsinputID<?=$i?>','criteriaGramsTable');" type="button" value="&#10008;"/><?php
							?></td><?php
						?></tr><?php
						$i++;
					}
				}
				
				?><tr id="rowgramsinputID<?=$i?>"><?php
					?><td width="35%" valign="top"><?php
						?><div class="suggestion"id="gramsdivID<?=$i?>"style="width:175px;"></div><?php
						?><input class="textareaWhite" id="gramsinputID<?=$i?>"name="gramsinputID<?=$i?>" onKeyDown="removeOrCreateNameSuggestion(this,'criteriaGramsTable','gramsdivID','gramsinputID','gramssuggestionID','grams');" onFocus="loadUserSuggestion(this,'gramsdivID<?=$i?>','gramsinputID<?=$i?>','','gramssuggestionID<?=$i?>','grams');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
						?><input class="xRemove" onClick="deleteRowByInputID('gramsinputID<?=$i?>','criteriaGramsTable');" type="button" value="&#10008;"/><?php
					?></td><?php
				?></tr><?php
				
			?></table><?php
			
			?><div style="width:100%;height:1px;"></div><?php
			
			?><div id="createCriteriaSubmitResponse" style="font-size:12px; font-weight:bold;">&zwnj;</div><?php
			
			if($included!=1)
			{
				//JFM 19_07_16
				if($alreadyInValidationLoop!=1 && $criteriaEdit!=1 && $modifying!=1 && (checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 || checkPermission('force_validation','create',0,'check',$SESSION)==1)) //JFM 12_01_16
				{
					?><table class="criteriaTable" id="criteriaGramsTable" style="width:50%;float:left; border-top:0px; border-left:0px; clear:both;" cellspacing="0" cellpadding="5"><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" width="30%">Force Validation</td><?php
							?><td style="text-align:center;"><?php
								?><textarea class="textareaWhite" style="width:98%;" rows="4" id="forceComments" name="forceComments"></textarea><?php
								?><input style="display:none;" id="force_criteria" name="force" type="text" size="50" value="0" disabled /><?php
								?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(validateCriteria('<?=utf8_encode($SESSION['user']['name'])?>','<?=utf8_encode($SESSION['user']['surname'])?>',0,1)) {$('force_criteria').setAttribute('value',1); sendAjaxForm('criteriaForm','ajax/saveCriteria.php','doNothing','criteria_saveResponse'); closeLastForm();}" type="button" value="Force Validation &#9658;"><?php
							?></td><?php
						?></tr><?php
					?></table><?php
				}

				?><div class="save"><?php
					?><span class="saveResponse"id="criteria_saveResponse">Changes were applied</span><?php
					?><input class="stdBtn" id="createCriteriaSubmit" <?=($alreadyInValidationLoop==1)?'disabled':'';?> onClick="if(validateCriteria('<?=utf8_encode($SESSION['user']['name'])?>','<?=utf8_encode($SESSION['user']['surname'])?>')) {sendAjaxForm('criteriaForm','ajax/saveCriteria.php','doNothing','criteria_saveResponse','POST',false); closeLastForm(); openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$reviewProfile?>&reviewTypeName=<?=$reviewType[0]['review_type']?>&reviewID=<?=$GET['reviewID']?>'); }"type="button"value="<?=($criteriaEdit==1)?'Edit':'Create';?> Criteria &#9658;"><?php
						
					/*if($alreadyInValidationLoop==1)
					{
						?><input class="textareaWhite" id="force" name="force" type="text" size="50" value="1" disabled /><?php
						?><input class="stdBtn" id="createCriteriaSubmit" onClick="sendAjaxForm('criteriaForm','ajax/saveCriteria.php','updateData','criteria_saveResponse'); closeLastForm();"type="button"value="FORCE VALIDATION"><?php
					}*/
				?></div><?php
			}
			if($modifying==1) //JFM 14_10_13
			{
				?><div style="clear:both;"><?php
					?><input class="textareaWhite" id="modify" name="modify" type="text" value="1" style="display:none;" disabled /><?php
					?><input class="textareaWhite" id="cancel" name="cancel" type="text" value="0" style="display:none;" disabled /><?php
					?><span class="saveResponse"id="criteria_saveResponse">Changes were applied</span><?php
					?><input class="textareaWhite" id="maxValidationLoopID" name="maxValidationLoopID" type="text" size="50" value="<?=$maxValidationLoopID?>" style="display:none;" disabled /><?php
					?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(validateCriteria('<?=utf8_encode($SESSION['user']['name'])?>','<?=utf8_encode($SESSION['user']['surname'])?>',1)) {sendAjaxForm('criteriaForm','ajax/saveCriteria.php','doNothing','criteria_saveResponse','POST',false); clock(); clock(); sideValidation(<?=$GET['object']?>); }"type="button"value="Modify Criteria &#9658;"><?php
					?><input class="stdBtn" id="createCriteriaSubmit" onClick="if(confirm('This will cancel the proposed criteria and remove it from the database.\nAre you sure you wish to continue?')){ $('cancel').value=1; sendAjaxForm('criteriaForm','ajax/saveCriteria.php','doNothing','criteria_saveResponse','POST',false); mainRestartNeeded=1; clock(); clock(); sideValidation(<?=$GET['object']?>);}"type="button"value="Cancel Criteria &#9658;"><?php //JFM 21_10_13
				?></div><?php
			}
			
			?><div style="width:100%;height:10px;"></div><?php
		?></form><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>