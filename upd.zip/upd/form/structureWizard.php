<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET=cleanArray($_GET);

$included=1;

?>OK|||<div id="structureContainer"><?php

	?><div class="formHeader" style="height:150px;"><?php
		?><div id="stepNumber" style="position:absolute; width:100%; text-align: center; top:40px; font-weight:bold;">Step 1</div><?php
		?><div id="stepDesc" style="position:absolute; width:100%; text-align: center; top:80px;">What would you like to do?</div><?php
	?></div><?php

	?><div class="sideDetailsContainer"id="structureWizardContainer" style="left:0px; top:125px; background-color:transparent; overflow:hidden;"><?php
		
		if($GET['wizard'] == 'report')
		{
			require_once("../ajax/reportWizardSteps.php");
		}
		else if($GET['wizard'] == 'structure')
		{
			require_once("../ajax/structureWizardSteps.php");
		}
		else
		{
			?>You don't appear to have permission to do anything on this page. Sorry! :(<?php
		}

	?></div><?php
?></div><?php
storeSession($SESSION);
?>