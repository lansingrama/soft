<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
/*$startTime=microtime(true);
echo(microtime(true)-$startTime)*1000,' ms to process<br>';*/
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);

$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
if(checkPermission('c_user_general','view',0,'check',$SESSION)==1){
	$userQry=SqlAsLi('SELECT user_id,CONCAT(surname,", ",name) AS user_name,confirmed
						FROM c_user
						ORDER BY user_id
						','user_id');
}else{
	if($SESSION['user']['view_as']==''){
		$userQry[$viewAsUserId]=array('user_name'=>$SESSION['user']['surname'].', '.$SESSION['user']['name'],'confirmed'=>1);
	}else{
		$viewAsUser=SqlQ('SELECT CONCAT(surname,", ",name) AS user_name FROM c_user WHERE user_id="'.$SESSION['user']['view_as'].'"');
		$userQry[$viewAsUserId]=array('user_name'=>$viewAsUser['user_name'],'confirmed'=>1);
	}
}

?>OK|||<div id="userManagementContainer"style="text-align:center;width:960px;"><?php
	?><div class="formHeader"><?php
		?><div class="formHeaderInfo">User Management</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	
	?><div class="userOptions"><?php
		?><div style="float:left;position:relative;"><?php
			if(checkPermission('c_user_general','create',0,'check',$SESSION))
			{
				?><input class="stdBtn"onClick="newSideElement(0,'User, New','userList','userElement','usr','newUser','');"type="button"value="New User &#9658;"><?php
			}
		?></div><?php
		?><div style="float:right;position:relative;"><input class="stdBtn"onClick="openSideElement('<?=$viewAsUserId?>','usr');"type="button"value="Edit my Account &#9658;"></div><?php
	?></div><?php
	
	?><div class="searchListContainer" style="top:80px;"><?php
		?><input class="searchField <?php if(!$mainFilter)echo'inactive'?>"id="searchUser"onBlur="txtBlr(this,'Search');"onFocus="txtOF(this,'Search');"onKeyUp="wek=window.event.keyCode;if(searchCount<=searchMax||wek==13||wek==27)searchDivList(this.value,'rmUserSearchImg','searchUser','userNotFound');"size="28"type="text"value="Search"><?php
		?><img id="rmUserSearchImg"src="../common/img/searchBlank.png"style="padding-left:3px;"><?php
		?><img alt="Click to search"onClick="searchDivList($('searchUser').value,'rmUserSearchImg','searchUser','userNotFound');" src="../common/img/search.png" style="cursor:pointer;"><?php
	?></div><?php

	?><div class="sideList"id="userList" style="top:100px;"><?php
		$searchCount=0;
		foreach($userQry as $userId=>$user){
			if($user['user_name']!='User, New'){
				?><div class="sideElement<?php if($user['confirmed']!=1)echo' notConfirmed'?>"id="userElement_<?=$userId?>"onClick="openSideElement('<?=$userId?>','usr');"><?=utf8_encode($user['user_name'])?></div><?php
				$searchCount++;
			}
		}
		?><div class="sideElementEmpty"id="userNotFound">User Not Found</div><?php
	?></div><?php
	
	?><div class="sideDetailsContainer"id="userRightsContainer"><?php
		?><div class="sideContainerEmpty">Select an Element from the list.</div><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>