<?php

/*
* US#134 - New section inside the Design Review information, to manage robustness assessment.
* Version: V 4.7
* To display the list of questions in Robustness Assessment page
* Fixed by: Infosys Limited
*/

require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');
$GET=cleanArray($_GET);
$ids=[];



$question_name= SqlLi('SELECT question_id,question_name from dr_assessment_questions where question_hidden = 0');

?>OK|||<div id="roleContainer" class="sideContainer"><?php
?><div class="formHeader"><?php
?><div class="formHeaderInfo">Robustness Assessment</div><?php
?><div class="xDiv" onclick="closeLastForm();">&#9668;◄ Back</div><?php
		?><div class="sp"></div>
	<form action="#" enctype="multipart/form-data" id="robust_saveResponse" name="robust_saveResponse" method="POST" style="display:inline;" onsubmit="return valRobustForm();">
	<div class="prompt" style="float:left;width:60%;padding-bottom:10px;z-index:100">
		<div class="save" >
		<span class="saveResponse"id="role_saveResponse">Changes were applied</span>
				<input class="stdBtn" id="applyRobustChanges" onClick="sendAjaxForm('robust_saveResponse','ajax/saveRobustResponse.php','saveRobust','');" type="button" value="Apply Changes &#9658;">
				<input class="stdBtn"onClick="closeLastForm();" xtype="button"value="Cancel &#9658;">
		</div>
	</div>
	<div class="elementDetailsContainer">

		<?php
			?><table class="criteriaTable" style="width:100%;" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup">
			<?php if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){
			?><td style="width:5%;"><input class="popUpBtnBlue"onClick="popUpOpt('robust',['new'],'robustElement');"type="button"value="&#8801;"><div class="popUpMenu"id="popUpRobustDiv_new"></div></td>
			<?php } else { ?>
                    <td></td>
                <?php }

					?><td style="width:100%;">Questions</td><?php
				?></tr><?php
				
				foreach($question_name as $question){
					array_push($ids,$question);
				?><tr class="" style="margin-bottom:1px solid #ccc"><?php
				?><td style="width:5%;" class="paramDef">
				<?php if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)
				{ ?>
					<input class="popUpBtn"onClick="popUpOpt('robust',['<?=$question['question_id'];?>','<?=$question['question_name'];?>','robustElement']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpRobustDiv_<?=$question['question_id']?>"></div>
					<?php } ?>								
					<td style="width:25%;"><?php echo $question['question_name']; ?></br>
					<input type="radio"  id = "answerYes_<?php echo $question['question_id']; ?>" name="<?php echo $question['question_id']; ?>" value="yes"> Yes
					
					<input type="radio"  id = "answerNo_<?php echo $question['question_id']; ?>" name="<?php echo $question['question_id']; ?>" value="no"> No<br>

					<!-- <input type="hidden"  id = "answerNo_<?php echo $question['question_id']; ?>" name="id" value="<?php echo $question['question_id']; ?>"><br> -->
			 
					<?php
			?></tr> <?php }	
			?>  <?php
			?></table>
			</form><?php
		?></div><?php
			?><div class="sideDetailsContainer"id="sideRoleManagementContainer"><?php
		?><div class="sideContainerEmpty">Select an Element from the list.</div><?php
	?></div><?php
?></div><?php
?>

<!-- <script LANGUAGE="JavaScript">
function ValidateForm(form){
	for(i=0;i<ids.length;i++){
		ErrorText= "";
		if ( ( form.<?php echo $ids[i]?>[0].checked == false ) && ( form.<?php echo $ids[i]?>[1].checked == false ) ){
			alert ( "Please choose appropriate answers" );
			return false;
			}
		if (ErrorText= "") { 
			return true; 
			}
		}
	}

</script> -->
<?php
?></div><?php

		




storeSession($SESSION);
 ?>

