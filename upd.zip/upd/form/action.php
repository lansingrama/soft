<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

//JFM 30_10_14 foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);
if($included!=1) $GET=cleanArray($_GET);
$status=array('r','a','g','x'); //JFM 27_03_14
$action=array();

if($GET['action']=='new')
{					
	$action['review_profile_id']=$GET['review_profile'];
	$action['criteria']=$GET['review_criteria_id'];
	$action['review']=$GET['review_id'];
	$action['action_status']=1;
	$action['rid_status']=1;
	$applicability=array();
}
else
{					
	//JFM 28_10_15
	$action=SqlQ('SELECT ac.criteria, ac.msn, ac.review,ac.rid,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_status,ac.action_holder,ac.action_holder_name,ac.action_validator,ac.action_validator_name, ac.validation_loop,
						rd.rid_code,rd.rid_title,rd.rid_status,rd.rid_holder,rd.rid_holder_name,rd.rid_creation,rd.rid_completion,rd.rid_showstopper,rd.rid_action_plan, rd.rid_change_note, rd.rid_validator,rd.rid_validator_name,
						CONCAT(uah.surname,", ",uah.name) AS action_holder_txt,CONCAT(uav.surname,", ",uav.name) AS action_validator_txt,CONCAT(urh.surname,", ",urh.name) AS rid_holder_txt,CONCAT(urv.surname,", ",urv.name) AS rid_validator_txt,
						uah.email AS action_holder_email, uav.email AS action_validator_email, urh.email AS rid_holder_email, urv.email AS rid_validator_email,
						rp.review_profile_id
					FROM dr_action AS ac
						LEFT JOIN dr_review_criterion	 AS cr	ON ac.criteria=		cr.review_criterion_id
						LEFT JOIN dr_review_group		 AS gr	ON cr.review_group=	gr.group_id
						LEFT JOIN dr_review 				 AS r 	ON r.review_id=ac.review
						LEFT JOIN dr_review_profile		 AS rp	ON gr.review_type=	rp.review_type
														 			OR r.review_profile= rp.review_profile_id
						LEFT JOIN dr_action_applicability AS app ON app.action=ac.action_id
						LEFT JOIN c_ca 					 AS ca  ON ca.ca_id=app.ca
															 		AND rp.program=ca.program
															 		AND rp.coe=ca.coe
						LEFT JOIN dr_rid AS rd	ON ac.rid=			rd.rid_id
						LEFT JOIN c_user AS uah	ON uah.user_id=		ac.action_holder
						LEFT JOIN c_user AS uav	ON uav.user_id=		ac.action_validator
						LEFT JOIN c_user AS urh	ON urh.user_id=		rd.rid_holder
						LEFT JOIN c_user AS urv	ON urv.user_id=		rd.rid_validator
					WHERE ac.action_id="'.$GET['action'].'"');
					
	$action=utf8enc($action,1);
	
	$applicability=SqlSLi('SELECT ca FROM dr_action_applicability WHERE action="'.$GET['action'].'"','ca');
	
	if(is_array($applicability)){
		$GET['ca']=implode(',',$applicability);
	}
	
	if($action['rid']!=0){
		$actionInRid=SqlQ('SELECT COUNT(*) FROM dr_action WHERE rid='.$action['rid']);
	}

	$alreadyInValidationLoop=SqlQ('SELECT count(*) AS count FROM dr_validation_loop WHERE applicability="'.$GET['action'].'" AND object='.$SESSION['object']['action_id']);		
}
/*
* US #054
* Version :2.0
* Fixed by : Infosys Limited 
* pie chart condittion
*/
$msn_id = getFilter('msn','filter',0,$SESSION);
if (!empty($msn_id)) { 
	$wp=implode(',',SqlSLi('SELECT wp FROM c_cawp WHERE msn="'.getFilter('msn','filter',0,$SESSION).'" AND ca IN ('.$GET['ca'].')','wp'));
}

//JFM 13_12_13
$ca=SqlAsLi('SELECT ca.ca_id, ca.ca,w.wp_id,w.wp
				FROM c_ca AS ca
					INNER JOIN c_cawp	AS cw	ON ca.ca_id=cw.ca
					INNER JOIN c_wp		AS w	ON cw.wp=w.wp_id
					INNER JOIN dr_review_applicability 	AS 	ra 	ON 	ra.ca = ca.ca_id
				WHERE ra.review IN (SELECT review FROM dr_review_applicability WHERE ca="'.$GET['ca'].'")
				ORDER BY ca.ca ASC','ca_id');

$caCounter=0;
$caTxtArray=array();
if(is_array($ca)){
	foreach($ca as $c){
		$caCounter++;
		if($caCounter<4){
			$caTxtArray[]=$c['ca'];
		}
	}

	$perimeters=perimeterPermission($SESSION,'edit'); //JFM 04_03_14
	if(!empty($perimeters))
	{
		if(!empty($wp))
		{
			$wpLeft=SqlAsArr('SELECT w.wp_id,w.wp
								FROM c_wp AS w
									INNER JOIN c_cawp AS cw	ON w.wp_id=cw.wp
									INNER JOIN c_ca AS c	ON cw.ca=c.ca_id
								WHERE wp_id NOT IN ('.$wp.')
									AND c.program='.getFilter('program','filter',0,$SESSION).'
									AND c.coe='.getFilter('coe','filter',0,$SESSION).'
									AND c.perimeter IN('.implode(',',array_keys($perimeters)).')
								ORDER BY wp ASC','wp_id','wp');
		}
	}

	$caTxt=$caTxtArray[0];

}
$ridList=SqlAsLi('SELECT DISTINCT r.rid_id,r.rid_code,r.rid_title
					FROM dr_rid AS r
						INNER JOIN dr_action AS a ON r.rid_id=a.rid
					WHERE (a.msn="'.$action['msn'].'" OR a.msn="'.getFilter('msn','filter',0,$SESSION).'") AND a.criteria="'.$action['criteria'].'"','rid_id');

if($action['validation_loop']==1 && $action['action_status']>1)	
	$editableAction=0; //JFM 30_10_14
else if(checkPermission('review_profile_id','edit',$action['review_profile_id'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','edit',0,'check',$SESSION)==1) 
	$editableAction=1;
else if ($action['action_holder']==$SESSION['user']['user_id'] || $action['action_validator']==$SESSION['user']['user_id'])
	$editableAction=1; //JFM 12_01_16
else $editableAction=0; 

if(($action['validation_loop']==1 && $action['action_status']<2 && $action['holder']==$SESSION['user']['user_id']) || $modifying==1) $limtedEditableAction=1; //JFM 30_10_14
else $limtedEditableAction=0;

$ncsa='';
if($action['criteria']==0) $ncsa='Non-Criteria Specific ';

if($included!=1)
{
?>OK|||<?php
	?><div id="editActionContainer"style="text-align:center;width:600px; margin-left:10px;"><?php
		?><div class="formHeader"><?php //JFM 25_06_14
			?><div class="formHeaderInfo"><?=($GET['action']=='new')?'New '.$ncsa.'Action for '.$SESSION['table']['review_planning']['ca']['ca']['title'].' '.$caTxt:'Edit Action '.$action['action_code']?></div><?php
			?><div class="xDiv" onclick="checkFormChanges('actionFrm');">&#9668; Back</div><?php //JFM 02_10_24
		?></div><?php
		?><div class="sp" style="height:50px;"></div><?php

		if(!empty($alreadyInValidationLoop['count']) && $alreadyInValidationLoop['count']!="0")
		{
			$textColour=($action['action_status']==3)?'green':'#FF0000';
			?><div align="center" style="font-size:14px; font-weight:bold; color:<?=$textColour?>;"><?php
				if($action['action_status']==3) echo 'Action has been validated.';
				else echo 'Action has been submitted and is in the process of being validated.';
			?><br /><br /></div><?php
		}
}
	?><div class="formStdContainer"><?php
		?><form action="#"enctype="multipart/form-data"id="actionFrm"method="post"style="display:inline;"><?php
			?><input id="msn"name="msn"type="hidden"value="<?=getFilter('msn','filter',0,$SESSION)?>"><?php
			?><input id="wp"name="wp"type="hidden"value="<?=$wp?>"><?php
			if($GET['criteria_ca']){?><input id="criteria_ca"name="criteria_ca"type="hidden"value="<?=$GET['criteria_ca']?>"><?php }
			else {?><input id="criteria_ca"name="criteria_ca"type="hidden"value="<?=$GET['ca']?>"><?php }	//JFM 25_11_13
			?><input id="criteria"name="criteria"type="hidden"value="<?=$action['criteria']?>"><?php
			?><input id="review_id"name="review_id"type="hidden"value="<?=$action['review']?>"><?php
			?><input id="action_id"name="action_id"type="hidden"value="<?=$GET['action']?>"><?php
			?><input id="action_code"name="action_code"type="hidden"value="<?=$action['action_code']?>"><?php
			?><input id="action_status"name="action_status"type="hidden" value="<?=$status[$action['action_status']]?>"><?php
			/*?><input id="applicable_ca"name="applicable_ca"type="hidden"value="<?=implode(',',array_keys($ca))?>"><?php*/
			?><input id="action_holder"name="action_holder"type="hidden"value="<?=$action['action_holder']?>"><?php
			?><input id="action_validator"name="action_validator"type="hidden"value="<?=$action['action_validator']?>"><?php
			/*?><input id="rid_id"name="rid_id"type="hidden"value="<?=$action['rid']?>"><?php*/
			?><input id="rid_status"name="rid_status"type="hidden"value="<?=$status[$action['rid_status']]?>"><?php
			?><input id="rid_holder"name="rid_holder"type="hidden"value="<?=$action['rid_holder']?>"><?php
			?><input id="rid_validator"name="rid_validator"type="hidden"value="<?=$action['rid_validator']?>"><?php

			if($included!=1) //JFM 30_10_14
			{
				$margin=0;
				
				if($action['criteria']!=0) //JFM 09_04_14
				{
					?><div class="reviewCaList" style="display:none;"><?php //JFM 17_08_15

						?><div class="tableTitle" style="text-align:left;">Action Location:</div><?php
						//require_once('../ajax/criteriaColumnTable.php');

						?><div class="tableTitle" style="text-align:left; margin-top:20px;">Applicability:</div><?php
						?><table id="action_applicability_table"class="criteriaTable"style="width:140px;" cellpadding="0" cellspacing="0"><?php
							?><tr class="tableGroup"><?php
								?><td align="center"><?php
									if($editableAction==1){
										?><input checked onClick="this.checked=true;selectAll('applicable_ca');"type="checkbox"><?php
									}
								?></td><?php
								?><td>WP</td><?php
								?><td>CA</td><?php
							?></tr><?php
							foreach($ca as $caId=>$caDetails){
								?><tr class="infoRow"><?php
									?><td class="chkList"><input<?php if($editableAction!=1){?> disabled<?php }?> id="applicable_ca_<?=$caId?>"name="applicable_ca_<?=$caId?>"<?php if(in_array($caId,$applicability) || ($GET['action']=='new' && $caId==$GET['ca']))echo'checked '?>type="checkbox"></td><?php
									?><td><?=$caDetails['wp']?></td><?php
									?><td><?=$caDetails['ca']?></td><?php
								?></tr><?php
							}
							if($editableAction==1){
								?><tr><?php
									?><td colspan="3"><?php
									?></td><?php
								?></tr><?php
							}
						?></table><?php
						?><div style="margin-top:10px;"><?php
							?>Add WP: <?php
							drawddList('add_wp',$wpLeft,'',75,'addWpApplicability(this);',1);
						?></div><?php
					?></div><?php
					$margin=50;
				}
				else
				{
					?><input disabled id="applicable_ca_<?=$GET['ca']?>" name="applicable_ca_<?=$GET['ca']?>" type="hidden" checked value="1"></td><?php
				}
			}

			?><div class="leftInfoBox" style="width:600px"><?php

				//JFM 17_08_15
				if($action['criteria']!=0)
				{
					?><div class="tableTitle" style="text-align:left;"><?php
						?>Associated Criteria:<?php
						if($editableAction==1 && $included!=1)
						{
							?><div style="display:inline; float:right; margin-top:3px;"><?php
								?><input class="stdBtn"onClick="if(validateActionRidCreation()){sendAjaxForm('actionFrm','ajax/saveAction.php','updateData','action_saveResponse', 'POST', false); getAllElementsOfFormAndStoreInString('actionFrm',1);}"type="button"value="Apply Changes &#9658;"><?php 
							?></div><?php
						}
					?></div><?php
					require_once('../ajax/criteriaColumnTable.php');
				}

				?><div class="tableTitle" style="text-align:left;margin-top:25px;">Action Information:</div><?php
				?><table class="criteriaTable" style="width:600px;" cellpadding="0" cellspacing="0"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="4">Main Information</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef"style="width:55px;">Status</td><?php
						?><td id="actionStatusHide" style="width:175px;"><?php
							drawStatus('action_status','actionStatus',$action['action_status'],$editableAction,$SESSION); //JFM 13_05_16
						?></td><?php
						?><td class="paramDef">Complete By</td><?php
						?><td><?php
							drawDate('action_completion','completionDateCal',$action['action_completion'],false,$editableAction);
						?></td><?php
					?></tr><?php

					?><tr class="tableGroup"><?php
						?><td colspan="2">Responsible</td><?php
						?><td colspan="2">Misc.</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php 
						?><td class="paramDef">Holder<br /><?php
							if(!empty($action['action_holder_email'])) //JFM 02_10_14
							{
								?><img style="cursor:pointer;" alt="Open Contact Card" onclick="showOOUI('<?=$action['action_holder_email']?>');" onmouseout="hideOOUI();" src="../common/img/info.png"><?php
							}
						?></td><?php
						drawUserField('suggestion_action_holder','action_holder_name','action_holder',$action['action_holder_txt'],$action['action_holder_name'],$editableAction);
						
						?><td class="paramDef">Use Validation Loop</td><?php
						?><td><?php
							?><input type="radio" id="validationCheckYes" name="validationCheck" onclick="if($('startValidation')) $('startValidation').style.visibility='visible';" value="1" <?=($editableAction)?'':'disabled'?> <?=($action['validation_loop']==1)?'checked="checked"':''?>>Yes<?php
							?><input type="radio" id="validationCheckNo" name="validationCheck" onclick="if($('startValidation')) $('startValidation').style.visibility='hidden';"  value="0" <?=($editableAction)?'':'disabled'?> <?=($action['validation_loop']==0 || empty($action['validation_loop']))?'checked="checked"':''?>>No<?php
							?><input class="stdBtn" onClick="openForm('workflow','applicability=<?=$GET['action']?>&object=<?=$SESSION['object']['action_id']?>',false,'GET');" type="button"value="View Workflow &#9658;"><?php
						
						?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Validator<br /><?php
							if(!empty($action['action_validator_email'])) //JFM 02_10_14
							{
								?><img style="cursor:pointer;" alt="Open Contact Card" onclick="showOOUI('<?=$action['action_validator_email']?>');" onmouseout="hideOOUI();" src="../common/img/info.png"><?php
							}
						?></td><?php
						drawUserField('suggestion_action_validator','action_validator_name','action_validator',$action['action_validator_txt'],$action['action_validator_name'],$editableAction);
						?><td class="paramDef">Action History</td><?php
						?><td style="text-align:center;"><?php
							?><input class="stdBtn" onClick="openForm('log','source=dr_action&applicability=<?=$GET['action']?>',false,'GET');" type="button"value="View Action History &#9658;"><?php
						?></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="4">Notes</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:55px;">Description</td><?php
						?><td colspan="3"><textarea class="textareaWhite"cols="80"id="action_description_action_form"name="action_description"<?php if($editableAction!=1){?>readonly <?php }?>rows="7"style="overflow-x:hidden;"><?=$action['action_description']?></textarea></td><?php
					?></tr><?php
					?><tr class="infoRow" ><?php
						?><td class="paramDef">Remarks</td><?php //JFM 06_02_14
						?><td colspan="3"><textarea class="textareaWhite"cols="80"id="action_remark_action_form"name="action_remark"<?php if($editableAction!=1 && $limtedEditableAction!=1){?>readonly <?php }?>rows="8"style="overflow-x:hidden;"><?=$action['action_remark']?></textarea></td><?php
					?></tr><?php
				?></table><?php
		?></div><?php

		?><div class="leftInfoBox" style="margin-top:25px;width:600px"><?php
			if($action['criteria']!=0) //JFM 09_04_14
			{
				if($action['rid_validator']==$SESSION['user']['user_id'] && $included!=1) $editableAction=1; //JMF 31_10_14

				?><div class="tableTitle" style="text-align:left;">RID:</div><?php

					?><table class="criteriaTable" style="width:600px;" cellpadding="0" cellspacing="0"><?php
						?><tr class="tableGroup"><?php
							?><td colspan="4">RID Code</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;">Code</td><?php
							?><td colspan="3"><?php
								?><select <?php if($editableAction!=1 || $actionInRid['COUNT(*)']==1){?>disabled <?php }?>id="rid"name="rid"onChange="changeRidSelect(this,'<?=$wp?>','<?=$action['criteria']?>');" style="width:500px;"><?php
									?><option value="0">No RID</option><?php
									?><option value="new">New RID...</option><?php
									foreach($ridList as $k=>$v){
										if(strlen($v['rid_title'])>80){
											$ridTitleCut=substr($v['rid_title'],0,80).'...';
										}else{
											$ridTitleCut=$v['rid_title'];
										}
										?><option<?php if($action['rid']==$k)echo' selected'?> value="<?=$k?>"><?=$v['rid_code'],': ',$ridTitleCut?></option><?php 
									}
								?></select><?php
							?></td><?php
						?></tr><?php
					?></table><?php

					?><table class="criteriaTable" id="disabledRid" style="width:600px; <?php if($action['rid']==0){?>display:none;<?php }?>" cellpadding="0" cellspacing="0"><?php //JFM 30_10_14
						?><tr class="tableGroup"><?php
							?><td colspan="4">Main Information</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;">Status</td><?php
							?><td style="width:55px;"><?php
								drawStatus('rid_status','ridStatus',$action['rid_status'],$editableAction,$SESSION); //JFM 13_05_16
							?></td><?php
							?><td class="paramDef" style="width:55px;">Complete By</td><?php
							?><td><?php
								drawDate('rid_completion','ridCompletionDateCal',$action['rid_completion'],false,$editableAction);
							?></td><?php
						?></tr><?php
						?><tr class="tableGroup"><?php
							?><td colspan="4">Responsible</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;">Holder<br /><?php
							if(!empty($action['rid_holder_email'])) //JFM 02_10_14
							{
								?><img style="cursor:pointer;" alt="Open Contact Card" onclick="showOOUI('<?=$action['rid_holder_email']?>');" onmouseout="hideOOUI();" src="../common/img/info.png"><?php
							}
							?></td><?php
							drawUserField('suggestion_rid_holder','rid_holder_name','rid_holder',$action['rid_holder_txt'],$action['rid_holder_name'],$editableAction);
						
							?><td class="paramDef" style="width:55px;">Showstopper</td><?php
							?><td><input id="rid_showstopper" value="1" <?php if($action['rid_showstopper']==1) echo' checked="checked"'; if($editableAction!=1) echo 'disabled="disabled"';?> type="checkbox" name="rid_showstopper"></td><?php

						?></tr><?php

						?><tr class="infoRow"><?php //JFM 31_10_14
							?><td class="paramDef" style="width:55px;">Validator<br /><?php
							if(!empty($action['rid_validator_email'])) 
							{
								?><img style="cursor:pointer;" alt="Open Contact Card" onclick="showOOUI('<?=$action['rid_validator_email']?>');" onmouseout="hideOOUI();" src="../common/img/info.png"><?php
							}
							?></td><?php
							drawUserField('suggestion_rid_validator','rid_validator_name','rid_validator',$action['rid_validator_txt'],$action['rid_validator_name'],$editableAction);
							
							?><td class="paramDef" style="width:55px;">Action Plan</td><?php
							?><td><input id="rid_action_plan" value="1" <?php if($action['rid_action_plan']==1) echo' checked="checked"'; if($editableAction!=1) echo 'disabled="disabled"';?> type="checkbox" name="rid_action_plan"></td><?php

						?></tr><?php

						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;"></td><?php
							?><td></td><?php
							?><td class="paramDef" style="width:55px;">Change Note</td><?php
							?><td><input id="rid_change_note" value="1" <?php if($action['rid_change_note']==1) echo' checked="checked"'; if($editableAction!=1) echo 'disabled="disabled"';?> type="checkbox" name="rid_change_note"></td><?php
						?></tr><?php
						
						?><tr class="tableGroup"><?php
							?><td colspan="4">Notes</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:55px;">Title</td><?php
							?><td colspan="3"><textarea class="textareaWhite" cols="80"id="rid_title"name="rid_title"<?php if($editableAction!=1){?>readonly <?php }?>rows="7"style="overflow-x:hidden;"><?=$action['rid_title']?></textarea></td><?php
						?></tr><?php

					?></table><?php
				}
		
				?><div class="save"><span class="saveResponse"id="action_saveResponse" style="display:inline; ">Changes were applied</span><?php
					if(($action['validation_loop']==1 && $action['action_holder']==$SESSION['user']['user_id'] && $editableAction && $action['action_status']<2) || $modifying==1) //JFM 30_10_14
					{
						?><input id="start_validation"name="start_validation"type="hidden"value="0"><?php
						?><input id="modifying"name="modifying"type="hidden"value="0"><?php
						?><input id="startValidation" class="stdBtn"onClick="if(validateActionRidCreation(1)){<?=(!$modifying)?'$(\'start_validation\')':'$(\'modifying\')'?>.value=1; sendAjaxForm('actionFrm','ajax/saveAction.php','doNothing','','POST',false); <?=(!$modifying)?'closeLastForm();':'sideValidation('.$SESSION['object']['action_id'].');'?>}"type="button"value="Start Validation &#9658;"><?php 
					}

					if($editableAction==1 && $included!=1)
					{
						?><input class="stdBtn"onClick="if(validateActionRidCreation()){sendAjaxForm('actionFrm','ajax/saveAction.php','updateData','action_saveResponse','POST',false); getAllElementsOfFormAndStoreInString('actionFrm',1);}"type="button"value="Apply Changes &#9658;"><?php 
					}

				?></div><?php

			?></div><?php
		?></form><?php
	if($included!=1) //JFM 30_10_14
	{
		?></div><?php
		?><div class="sp"></div><?php
	}
storeSession($SESSION);
?>