<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET=cleanArray($_GET);

$riskId = $GET['riskId'];

$statusNumber=array(0=>'r',1=>'a',2=>'g',3=>'x');

$rpn = 1;

$riskQry = SqlQ('SELECT rsk.*, CONCAT(u.surname,", ",u.name) AS risk_holder_txt FROM dr_risk AS rsk 
					LEFT JOIN c_user AS u ON u.user_id = rsk.risk_holder
					 WHERE rsk.risk_id="'.$riskId.'"');

if(empty($riskQry['risk_id'])) 
{
	$riskQry['risk_id']='new';
	$riskQry['risk_status']=1;
}
else
	$rpn = $riskQry['severity'] * $riskQry['occurrence'] * $riskQry['detection'];

$editableRisk=0;

if(checkPermission('c_ca_general','edit',0,'check',$SESSION)==1) 
	$editableRisk=1;
else if ($riskQry['risk_holder']==$SESSION['user']['user_id'])
	$editableRisk=1;

$caId = $GET['ca'];

if(empty($caId))
	$caId = $riskQry['ca'];

$caQry=SqlQ('SELECT ca.ca_id, ca.ca,w.wp_id,w.wp, per.perimeter_id, per.perimeter
				FROM c_ca AS ca
					INNER JOIN c_cawp	AS cw	ON ca.ca_id=cw.ca
					INNER JOIN c_wp		AS w	ON cw.wp=w.wp_id
					INNER JOIN c_perimeter AS per ON per.perimeter_id=ca.perimeter
				WHERE ca.ca_id='.$caId.'
				ORDER BY ca.ca ASC');


$title = '"'.$caQry['perimeter'].' - '.$caQry['wp'].' - '.$caQry['ca'].'"';

?>OK|||<?php
?><div id="editRiskContainer" style="text-align:center;width:600px; margin-left:10px;"><?php
	?><div class="formHeader"><?php
		?><div id="formRiskTitle" class="formHeaderInfo"><?=($riskQry['risk_id']=='new')?'New Risk for '.$SESSION['table']['review_planning']['ca']['ca']['title'].' '.$title:'Edit Risk '.$riskQry['risk_code']?></div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="sp" style="height:50px;"></div><?php

	?><div class="formStdContainer"><?php
		?><form action="#" enctype="multipart/form-data" id="riskFrm" method="post" style="display:inline;"><?php
			
			?><input id="ca" name="ca" type="hidden" value="<?=$caId?>"><?php
			?><input id="wp" name="wp" type="hidden" value="<?=$caQry['wp_id']?>"><?php
			?><input id="risk_id" name="risk_id" type="hidden" value="<?=$riskQry['risk_id']?>"><?php
			?><input id="risk_code" name="risk_code" type="hidden" value="<?=$riskQry['risk_code']?>"><?php
			?><input id="risk_status" name="risk_status" type="hidden" value="<?=$statusNumber[$riskQry['risk_status']]?>"><?php
			?><input id="risk_description" name="risk_description" type="hidden" value="<?=$riskQry['risk_description']?>"><?php
			?><input id="risk_action" name="risk_action" type="hidden" value="<?=$riskQry['risk_action']?>"><?php
			?><input id="risk_remarks" name="risk_remarks" type="hidden" value="<?=$riskQry['risk_remarks']?>"><?php
			?><input id="date_opened" name="date_opened" type="hidden" value="<?=$riskQry['date_opened']?>"><?php
			?><input id="date_closed" name="date_closed" type="hidden" value="<?=$riskQry['date_closed']?>"><?php
			?><input id="severity" name="severity" type="hidden" value="<?=$riskQry['severity']?>"><?php
			?><input id="occurrence" name="occurrence" type="hidden" value="<?=$riskQry['occurrence']?>"><?php
			?><input id="detection" name="detection" type="hidden" value="<?=$riskQry['detection']?>"><?php
			?><input id="risk_holder" name="risk_holder" type="hidden" value="<?=$riskQry['risk_holder']?>"><?php

			?><div class="leftInfoBox" style="width:600px"><?php

				?><div class="tableTitle" style="text-align:left;"><?php
					if($editableRisk==1)
					{
						?><div style="display:inline; float:right; margin-top:3px;"><?php
							?><div class="save"><span class="saveResponse" id="risk_saveResponse" style="display:inline; float:left;">Changes were applied</span><?php
							/*?><input class="stdBtn" onClick="if(validateActionRidCreation()){sendAjaxForm('actionFrm','ajax/saveAction.php','updateData','action_saveResponse', 'POST', false); getAllElementsOfFormAndStoreInString('actionFrm',1);}"type="button"value="Apply Changes &#9658;"><?php */
							?><input class="stdBtn" onClick="if(validateRiskCreation()){sendAjaxForm('riskFrm','ajax/saveRisk.php','updateData','risk_saveResponse', 'POST', false);}" type="button" value="Apply Changes &#9658;"><?php 
						?></div><?php
					}
				?></div><?php

				?><div class="tableTitle" style="text-align:left;margin-top:25px;">Risk Information:</div><?php
				?><table class="criteriaTable" style="width:600px;" cellpadding="0" cellspacing="0"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Main Information</td><?php
						?><td colspan="2">Responsible</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef"style="width:55px;">Status</td><?php
						?><td id="actionStatusHide" style="width:175px;"><?php
							drawStatus('risk_status','riskStatus',$riskQry['risk_status'],$editableRisk,$SESSION);
						?></td><?php
						?><td class="paramDef">Holder<br /><?php
							if(!empty($action['action_holder_email']))
							{
								?><img style="cursor:pointer;" alt="Open Contact Card" onclick="showOOUI('<?=$action['action_holder_email']?>');" onmouseout="hideOOUI();" src="../common/img/info.png"><?php
							}
						?></td><?php
						drawUserField('suggestion_risk_holder','risk_holder_name','risk_holder',$riskQry['risk_holder_txt'],$riskQry['risk_holder_name'],$editableRisk);	
	
					?></tr><?php

					?><tr class="tableGroup"><?php
						?><td colspan="2">FMEA</td><?php
						?><td colspan="2">Misc.</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php 
						?><td class="paramDef">Severity</td><?php
						?><td><?php
							?><select id="severityDropDown" name="severity" onchange="calculateRPN();"><?php
								for ($i=1; $i < 11; $i++) 
								{ 
									?><option <?=($riskQry['severity']==$i)?'selected':''?> value="<?=$i?>"><?=$i?></option><?php
								}
							?></select><?php
						?></td><?php
					
						?><td class="paramDef">FMEA Documentation</td><?php
						?><td style="text-align:center;"><?php
							?><input class="stdBtn" onClick="window.open('http://ecm.eu.airbus.corp:1080/WorkplaceDMS/ECMLogicalURL?ECMObjectStore=Airbus&ECMSearch=EDSStandardSearch2&Ref=M1086.0&Status=Released&DocFormat=02');" type="button" value="View Documentation &#9658;"><?php
						?></td><?php
					?></tr><?php

					?><tr class="infoRow"><?php 
						?><td class="paramDef">Occurrence</td><?php
						?><td><?php
							?><select id="occurrenceDropDown" name="occurrence" onchange="calculateRPN();"><?php
								for ($i=1; $i < 11; $i++) 
								{ 
									?><option <?=($riskQry['occurrence']==$i)?'selected':''?> value="<?=$i?>"><?=$i?></option><?php
								}
							?></select><?php
						?></td><?php

						?><td class="paramDef">Risk History</td><?php
						?><td style="text-align:center;"><?php
							?><input class="stdBtn" onClick="openForm('log','source=dr_risk&applicability=<?=$riskId?>',false,'GET');" type="button" value="View Risk History &#9658;"><?php
						?></td><?php
					?></tr><?php

					?><tr class="infoRow"><?php 
						?><td class="paramDef">Detection</td><?php
						?><td><?php
							?><select id="detectionDropDown" name="detection" onchange="calculateRPN();"><?php
								for ($i=1; $i < 11; $i++) 
								{ 
									?><option <?=($riskQry['detection']==$i)?'selected':''?> value="<?=$i?>"><?=$i?></option><?php
								}
							?></select><?php
						?></td><?php
					?></tr><?php

					?><tr class="infoRow"><?php 
						?><td class="paramDef">Risk Priority Number</td><?php
						?><td id="rpn"><?php
							?><?=$rpn?><?php
						?></td><?php
					?></tr><?php

					?><tr class="tableGroup"><?php
						?><td colspan="4">Notes</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:55px;">Description</td><?php
						?><td colspan="3"><textarea class="textareaWhite" cols="80" id="risk_description_risk_form" name="risk_description" rows="7" style="overflow-x:hidden;" <?=($editableRisk!=1)?'readonly':''?>><?=$riskQry['risk_description']?></textarea></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:55px;">Action</td><?php
						?><td colspan="3"><textarea class="textareaWhite" cols="80" id="risk_action_risk_form" name="risk_action" rows="7" style="overflow-x:hidden;" <?=($editableRisk!=1)?'readonly':''?>><?=$riskQry['risk_action']?></textarea></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:55px;">Remarks</td><?php
						?><td colspan="3"><textarea class="textareaWhite" cols="80" id="risk_remarks_risk_form" name="risk_remarks" rows="7" style="overflow-x:hidden;" <?=($editableRisk!=1)?'readonly':''?>><?=$riskQry['risk_remarks']?></textarea></td><?php
					?></tr><?php
				?></table><?php
			?></div><?php
		?></form><?php

	?></div><?php
?></div><?php

?><div class="sp"></div><?php
storeSession($SESSION);
?>