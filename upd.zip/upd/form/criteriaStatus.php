<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
/*$startTime=microtime(true);
echo(microtime(true)-$startTime)*1000,' ms to process<br>';*/
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET=cleanArray($_GET);
$GET['list_name']='action';
$caArray=explode(',',$GET['ca']);
$caCount=count($caArray);

$status=array('r','a','g','x','b','m'); //JFM 27_03_14
$included=1;

/*JFM 04_09_13
$criteriaMlt=SqlLi('SELECT s.criteria_status,s.criteria_focal_point,s.criteria_comments
					FROM dr_criteria_status AS s
						INNER JOIN dr_review_criteria AS c ON s.review_criteria=c.review_criteria_id
					WHERE s.msn="'.$GET['msn'].'"
						AND s.ca IN('.$GET['ca'].')
						AND c.review_criteria_id="'.$GET['review_criteria_id'].'"');*/

$criteriaMlt=SqlLi('SELECT s.criteria_status,s.criteria_focal_point,s.criteria_comments
					FROM dr_criteria_status AS s
						INNER JOIN dr_review_criterion AS c ON s.review_criteria=c.review_criterion_id
					WHERE s.msn="'.$GET['msn'].'"
						AND s.ca IN('.$GET['ca'].')
						AND c.review_criterion_id="'.$GET['review_criteria_id'].'"');
						
/*foreach($caArray){
	
}*/

$criteriaMlt=addMissingResults($criteriaMlt,$caCount);

$criteria['criteria_status']=combinedResult($criteriaMlt,'criteria_status','status',$SESSION,$caCount);
$criteria['criteria_focal_point']=combinedResult($criteriaMlt,'criteria_focal_point','text',$SESSION,$caCount);
$criteria['criteria_comments']=combinedResult($criteriaMlt,'criteria_comments','text',$SESSION,$caCount);

$activeStatus=pictureStatus($criteria['criteria_status']);

?>OK|||<div id="criteriaStatusContainer"style="text-align:center;padding-right:10px;"><?php
	?><div class="formStdContainer"><?php
		?><div class="xDiv"style="text-align:right;"><img alt="Close this Window"onClick="closeLastForm();"src="../common/img/x.png"style="cursor:pointer;"></div><?php
		?><div class="formHeaderInfo">Criteria Status</div><?php
		?><div class="reviewStatus"><img id="bigCriteriaStatus"src="../common/img/<?=$status[$criteria['criteria_status']]?>100.jpg"></div><?php
	?></div><?php
	?><div style="position:relative;height:150px;"></div><?php
	?><div class="formStdContainer" style="width:960px;"><?php
		?><div class="criteriaLocation"><?php
			?><div class="tableTitle" style="padding-left:12px;">Location:</div><?php
			require_once('../ajax/criteriaColumnTable.php');
		?></div><?php
	
		?><div class="leftInfoBox"><?php
			?><div class="tableTitle">Criteria Information:</div><?php
			?><form action="#"enctype="multipart/form-data"id="criteriaStatusFrm"method="post"style="display:inline;"><?php
				?><input id="ca"name="ca"type="hidden"value="<?=$GET['ca']?>"><?php
				?><input id="review_criteria_id"name="review_criteria_id"type="hidden"value="<?=$GET['review_criteria_id']?>"><?php
				?><input id="criteria_status"name="criteria_status"type="hidden" value="<?=$status[$criteria['criteria_status']]?>"><?php
				?><table class="criteriaTable" style="width:350px;"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="3">Criteria Status</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:55px;">Status</td><?php
						?><td colspan="2"><?php
							?><img id="criteriaStatus_r"onMouseOver="setStatusFocus(this,'criteria_status')"src="../common/img/r<?=$activeStatus[0]?>30.png"style="cursor:pointer;"><span style="cursor:default;padding-right:10px;"></span><?php
							?><img id="criteriaStatus_a"onMouseOver="setStatusFocus(this,'criteria_status')"src="../common/img/a<?=$activeStatus[1]?>30.png"style="cursor:pointer;"><span style="cursor:default;padding-right:10px;"></span><?php
							?><img id="criteriaStatus_g"onMouseOver="setStatusFocus(this,'criteria_status')"src="../common/img/g<?=$activeStatus[2]?>30.png"style="cursor:pointer;"><span style="cursor:default;padding-right:10px;"></span><?php //JFM 27_03_14
							?><img id="criteriaStatus_x"onMouseOver="setStatusFocus(this,'criteria_status')"src="../common/img/x<?=$activeStatus[3]?>30.png"style="cursor:pointer;"><?php //JFM 27_03_14
							if($criteria['criteria_status']=='4'){?><span style="cursor:default;padding-right:10px;"></span><img id="criteriaStatus_m"onMouseOver="setStatusFocus(this,'criteria_status')"src="../common/img/m<?=$activeStatus[4]?>30.png"style="cursor:pointer;"><?php }
						?></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="3">Details</td><?php
					?></tr><?php
					drawStdField('Focal Point','criteria_focal_point',$criteria['criteria_focal_point'],42);
					?><tr class="infoRow"><?php
						?><td class="paramDef">Comments<?php
							?><br /><br /><img style="padding-left:25px; cursor:pointer;" id="help" onMouseOut="nd();" onMouseOver="overlib('A comment MUST be entered for the criteria status to change on the main review window.', ABOVE, CAPTION,'Please Note:');"src="../common/img/help.png"><?php //JFM 06_02_14
						?></td><?php
						?><td colspan="2"><textarea cols="44"id="criteria_comments"name="criteria_comments"onMouseOver="setInputFocus(this);"rows="6"style="overflow-x:hidden;"><?=$criteria['criteria_comments']?></textarea></td><?php
					?></tr><?php
				?></table><?php
				?><div class="save"><span class="saveResponse"id="criteriaStatus_saveResponse">Changes were applied</span><input class="stdBtn"onClick="sendAjaxForm('criteriaStatusFrm','ajax/saveCriteriaStatus.php','updateData','criteriaStatus_saveResponse');"type="button"value="Apply Changes"></div><?php
			?></form><?php
		?></div><?php
	?></div><?php
	?><div class="sp"></div><?php
	?><div class="wideFormTable"id="reviewCriteriaReportList"><?php
	?><div class="tableTitle" style="width:960px; clear:both;">Action List:</div><br><?php
		unset($GET['msn']);
		include('../ajax/list.php');
	?></div><?php
	?><div style="position:relative;height:50px;"></div><?php
?></div><?php
storeSession($SESSION);
?>