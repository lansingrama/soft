<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
/*$startTime=microtime(true);
echo(microtime(true)-$startTime)*1000,' ms to process<br>';*/
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);
$included=1;

//JFM 08_06_16 $review=array('area'=>'Area','program'=>'Program (%Ar)','coe'=>'CoE (%Ar)','perimeter'=>'Perimeter (%Ar,%Pr)','msn'=>'MSN (%Ar,%Pr)','cawp'=>'CA - WP (%Ar,%Pr,%C,%Pm,%M)','review'=>'Review (%Ar,%Pr,%C)',/*'responsible'=>'Responsible (%Pr)',*/'company'=>'Company','department'=>'Department','grams'=>'References');
//JFM 08_06_16 $sideHelp=array('%Ar'=>'Area', '%Pr'=>'Program','%C'=>'CoE','%Pm'=>'Perimeter','%M'=>'MSN',);
$review=array('area'=>'Area','program'=>'Level 1 (%Ar)','coe'=>'Level 2 (%Ar)','msn'=>'Level 3 (%Ar,%L1)','perimeter'=>$SESSION['table']['review_planning']['ca']['perimeter']['title'].' (%Ar,%L1,%L2)','cawp'=>$SESSION['table']['review_planning']['ca']['wp']['title'].' - '.$SESSION['table']['review_planning']['ca']['ca']['title'].' (%Ar,%L1,%L2,%L3,%Pm)','review'=>'Review Type (%Ar,%L1,%L2)','grams'=>'References');
$sideHelp=array('%Ar'=>'Area', '%L1'=>'Level 1','%L2'=>'Level 2', '%L3'=>'Level 3','%Pm'=>$SESSION['table']['review_planning']['ca']['perimeter']['title']);

?>OK|||<div id="structureContainer"><?php

	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo" onclick="changeStrLoc('area');">Structure Management</div><?php
                // Calling function to refresh the main table data when a level has been deleted from Structure Management - US#110
		?><div class="xDiv" onclick="refreshMainPage();">&#9668; Back</div><?php
	?></div><?php
	?><div class="locationSideContainer"><?php //JFM 03_06_14
		?><div style="float:left;">Area</div><?php
		?><div style="float:right;"><?php
			$areaList=allowedSimpleObject('area','area',$SESSION,'c_');
			drawddList('strDdArea',$areaList,getFilter('area','filter',0,$SESSION),'','changeStrLoc(\'area\');',0);
		?></div><?php
		?><div class="ddSpace"></div><?php
		/*JFM 08_06_16 ?><div style="float:left;">Program</div><?php*/
		?><div style="float:left;">Level 1</div><?php //JFM 08_06_16
		?><div style="float:right;"><?php
                        // Added new column program_hidden for US#110 - Possibility to delete ReviewType, L1, L2 and L3
			$programList=allowedSimpleObject('program','program',$SESSION,'c_','area='.getFilter('area','filter',0,$SESSION).' AND program_hidden=0'); //JFM 03_06_14
			drawddList('strDdProgram',$programList,getFilter('program','filter',0,$SESSION),'','changeStrLoc(\'program\');',0);
		?></div><?php
		?><div class="ddSpace"></div><?php
		/*?><div style="float:left;">CoE</div><?php*/
		?><div style="float:left;">Level 2</div><?php //JFM 08_06_16
		?><div style="float:right;"><?php
                        // Added new column coe_hidden for US#110 - Possibility to delete ReviewType, L1, L2 and L3
			$coeList=allowedSimpleObject('coe','coe',$SESSION,'c_','area='.getFilter('area','filter',0,$SESSION).' AND coe_hidden=0'); //JFM 03_06_14
			drawddList('strDdCoe',$coeList,getFilter('coe','filter',0,$SESSION),'','changeStrLoc(\'coe\');',0);
		?></div><?php
		?><div class="ddSpace"></div><?php
		/*?><div style="float:left;">MSN</div><?php*/
		?><div style="float:left;">Level 3</div><?php
		?><div style="float:right;"><?php
			$msnList=allowedMsn($SESSION);
			drawddList('strDdMsn',$msnList,getFilter('msn','filter',0,$SESSION),'','changeStrLoc(\'msn\');',0);
		?></div><?php
		?><div class="ddSpace"></div><?php
		/*JFM 08_06_16 ?><div style="float:left;">Perimeter</div><?php*/
		?><div style="float:left;"><?=$SESSION['table']['review_planning']['ca']['perimeter']['title']?></div><?php
		?><div style="float:right;"><?php
			$msnList=allowedSimpleObject('perimeter','perimeter',$SESSION,'c_','program='.getFilter('program','filter',0,$SESSION));
			/*Instructure managemnet the msn dropdown is because of following code*/
                        drawddList('strDdPerimeter',$msnList,'','','changeStrLoc(\'perimeter\');',0);
		?></div><?php
	?></div><?php

	?><div class="sideList"id="reviewList"style="top:200px;"><?php
		foreach($review as $k=>$v){
			$v=utf8_encode($v);
			foreach($sideHelp as $shortName=>$longName){
				$v=str_replace($shortName,'<span class="structureHelp"onMouseOut="nd();"onMouseOver="overlib(\''.$longName.' is needed\');">'.substr($shortName,1).'</span>',$v);
			}
			?><div class="sideElement"id="structureElement_<?=$k?>"onClick="openSideElement('<?=$k?>','str');"><?=$v?></div><?php
		}
	?></div><?php

	?><div class="sideDetailsContainer"id="sideStructureContainer"><?php
		?><div class="sideContainerEmpty">Select an Element from the list.</div><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>