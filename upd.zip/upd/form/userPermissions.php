<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../support/mail.php');

$userId=addslashes($_GET['element']);

function drawSpecPerm($title,$object,$array,$right,$SESSION,$oldArray,$areas) //JFM 16_01_15
{
	$previousRight=array('area_id' => 'area_id', 'program_id' => 'area_id', 'coe_id' => 'area_id', 'perimeter_id' => 'program_id');
	$idCodes=array('program_id' => 'PRO_', 'coe_id' => 'COE_', 'perimeter_id' => 'PRE_');

	?><tr class="tableGroup prmRow"><?php
		?><td style="width:220px;"><?=$title?></td><td>View</td><td>Edit</td><td>Create</td><td>Delete</td><td>Export</td><td>Upload</td><?php
	?></tr><?php

	$draw=array();

	foreach ($oldArray as $k=>$v) 
	{
		if($right[$SESSION['object'][$previousRight[$object]]][1][$k]==1) $draw[]=$k;
	}

	$drawn=false;

	foreach($array as $k=>$v)
	{
		foreach ($areas as $key => $value) 
		{
			if($object=='area_id' || (in_array($value[$previousRight[$object]], $draw) && $value[$object]==$k))
			{//here the programs are coming
				$rowsId=($object=='area_id')?'SP_TOP_'.$v:'SP_'.$idCodes[$object].substr($v, 0, strpos($v, ' -'));
				drawPermissions($v,$object,$k,1,1,0,0,1,0,$right,$SESSION,'','',$rowsId);
				$drawn=true;
				break;
			}
		}
		
		if(!$drawn) drawPermissions($v,$object,$k,1,1,0,0,1,0,$right,$SESSION,'',1,'SP_'.$idCodes[$object].substr($v, 0, strpos($v, ' -')));

		$drawn=false;
	}
}

$user=SqlQ('SELECT name,surname,confirmed FROM c_user WHERE user_id="'.$userId.'"');
$userName=utf8_encode($user['name'].' '.$user['surname']);

$rightsQry=mysql_query('SELECT object,action,applicability FROM c_permission WHERE user='.$userId.' AND tool='.$SESSION['tool_id'].' AND active=1',$p12) or die(mysql_error());
while($r=mysql_fetch_assoc($rightsQry)){
	$right[$r['object']][$r['action']][$r['applicability']]=1;
}

$area=SqlAsArr('SELECT area_id,area FROM c_area','area_id','area');

// Added program_id & coe_hidden flag to check if the review is active - US#110
$program=SqlAsArr('SELECT CONCAT(a.area," - ",pro.program) as a_pro, program_id 
					FROM c_program AS pro
						INNER JOIN c_area AS a ON a.area_id=pro.area WHERE pro.program_hidden=0','program_id','a_pro');

$coe=SqlAsArr('SELECT CONCAT(a.area," - ",coe.coe) as a_coe, coe_id 
				FROM c_coe AS coe
					INNER JOIN c_area AS a ON a.area_id=coe.area WHERE coe.coe_hidden=0','coe_id','a_coe');

$perimeter=SqlAsArr('SELECT CONCAT(a.area," - ",prg.program," - ",prm.perimeter) as prg_prm,prm.perimeter_id
						FROM c_perimeter AS prm
							INNER JOIN c_program AS prg ON prm.program=prg.program_id
							INNER JOIN c_area AS a ON a.area_id=prg.area','perimeter_id','prg_prm');

$areas=SqlLi('SELECT DISTINCT a.area_id, pro.program_id, coe.coe_id, pr.perimeter_id
				FROM c_area AS a
				INNER JOIN c_program AS pro ON pro.area=a.area_id
				INNER JOIN c_coe AS coe ON coe.area=a.area_id
				INNER JOIN c_perimeter AS pr ON pr.program=pro.program_id');
				
/*
	US109-General Information not editable by supplier
	Disabled edit,create and delete
	Fixed By - Infosys Limited
	Version: V 4.5
*/
	$externalUser = SqlQ('SELECT type from c_user WHERE user_id = '.$userId);
/* End for US109 */
				
// Added review_type_hidden flag to check if the review is active
$reviewsQry=mysql_query('
	SELECT rp.program,rp.coe,rp.review_profile_id,rt.review_type, rt.area
	FROM dr_review_profile AS rp
		INNER JOIN dr_review_type AS rt ON rp.review_type=rt.review_type_id WHERE review_type_hidden=0',$p12) or die(mysql_error());
while($r=mysql_fetch_assoc($reviewsQry)){
	$review[$r['area']][$r['program']][$r['coe']][$r['review_profile_id']]=$r['review_type'];
}

$activePermission=SqlQ('SELECT permission_id FROM c_permission WHERE user="'.$userId.'" AND tool="'.$SESSION['tool_id'].'" AND active=1 LIMIT 1');
$SESSION['edit_user']['active_permission']=($activePermission['permission_id']!='')?1:0;

if($user['confirmed']==1){
	$SESSION['edit_user']['user_invited']=1;
}else{
	$userInvited=SqlQ('SELECT user_invitation_id FROM c_user_invitation WHERE user="'.$userId.'" LIMIT 1');
	$SESSION['edit_user']['user_invited']=($userInvited['user_invitation_id']!='')?1:0;
}

?>OK|||<?php
	?><div class="formHeader"><?php
		?><div class="formHeaderInfo"><?php
			if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 && $user['confirmed']==1)
			{
				?><input class="popUpBtnBlue"onClick="popUpOpt('ttl',['usr','<?=$userId?>','<?=$userName?>']);"type="button"value="&#8801;"><?php
				?><div class="popUpMenu"id="popUpTtlDiv_usr"></div>&nbsp;<?php
			}

			?>Edit <?=$userName?><?php

			if($user['confirmed']==0 && $user['name']!='New' && $user['surname']!='User' && $SESSION['edit_user']['user_invited']==1)
			{
				?> (Pending of Confirmation)<?php
			}
		?></div><?php
                // To refresh the User Management page on click of back button on Edit user page
		?><div class="xDiv" onclick="refreshUserMan();openForm('list','list_name=usr',false,'GET');hideMenu();">&#9668; Back</div><?php
	?></div><?php

?><div class="sp"></div><?php
?><div class="elementDetailsContainer"><?php

//echo $user['confirmed'],'###',$user['name']!='New','###',$user['surname']!='User','###',$SESSION['edit_user']['user_invited'];
if($SESSION['edit_user']['user_invited']==1)
{
	$lastInvitation=SqlLi('SELECT uin.invitation_date,
								CONCAT(u.name," ",u.surname) AS invitation_sender
							FROM c_user_invitation AS uin
								INNER JOIN c_user AS u ON uin.invited_by=u.user_id
							WHERE uin.user="'.$userId.'"
							ORDER BY invitation_date DESC');
	
	$lastInvitation=utf8enc($lastInvitation);
	
	?><input id="permissionUserId"name="user"type="hidden"value="<?=$userId?>"><?php
	
	?><div class="elementDetailsContainer"><?php
		?><div class="elementInfo"><?php
			?><div class="tableTitle">Last invitations sent:</div><?php
				?><table class="criteriaTable"style="width:703px;" cellpadding="0" cellspacing="0"><?php
					?><tr class="tableGroup prmRow"style="text-align:center;"><td style="width:351px;">Invitation sent on</td><td style="width:351px;">Sent by</td></tr><?php
					if(is_array($lastInvitation)){
						foreach($lastInvitation as $l){
							?><tr class="infoRow"><td><?=$l['invitation_date']?></td><td><?=$l['invitation_sender']?></td></tr><?php
						}
					}else{
						?><tr><td class="emptyTable"colspan="2">No invitations have been logged as sent.</td></tr><?php
					}
				?></table><?php
		?></div><?php
		if($user['confirmed']==0)
		{
			?><div class="elementInfo" style="width:703px;"><?php
				?><div class="save"><input class="stdBtn"onClick="sendInvitation(this,'<?=$userId?>');"type="button"value="Send Invitation Again &#9658;"></div><?php
			?></div><?php
		}
}

include('../usr/userMainDataForm.php');

	
$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
if(($userId!=$viewAsUserId || checkPermission('superadmin','superadmin',0,'check',$SESSION)==1) && $SESSION['edit_user']['user_invited']){

	?></div><?php

	if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1 || checkPermission('c_user_general','edit',0,'check',$SESSION)==1)
	{
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer" style="z-index:100;"><?php
			?><div class="elementInfo"><?php
				?><div class="tableTitle">Copy User Permissions:</div><?php
					?><form action="#" enctype="multipart/form-data" id="userPermissionCopy" name="userPermissionCopy" method="post" style="display:inline;"><?php
						?><input id="userId"name="userId"type="hidden"value="<?=$userId?>"><?php
						?><input id="permissionCopy"name="permissionCopy"type="hidden"value="1"><?php
						?><table class="criteriaTable" style="width:288px;" cellpadding="0" cellspacing="0"><?php
							?><tr class="tableGroup prmRow"><?php
								?><td colspan="2">User</td><?php
							?></tr><?php
							?><tr><?php
								drawUserField('suggestion_user_permission_copy','user_permission_copy','','','',1);
								?><td><input class="stdBtn"id="applyUserChanges"onClick="sendAjaxForm('userPermissionCopy','ajax/setPermission.php','saveRowConfig',false,'GET');closeLastForm();"type="button"value="Submit &#9658;"></td><?php
							?></tr><?php
						?></table><?php
					?></form><?php
			?></div><?php
		?></div><?php
	}

	if(checkPermission('superadmin','superadmin',0,'check',$SESSION)==1){
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo"><?php
				?><div class="tableTitle"style="width:100%;">Chuck Norris Mode:</div><?php
					?><table class="criteriaTable" style="width:288px;" cellpadding="0" cellspacing="0"><?php
						?><tr class="tableGroup prmRow"><?php
							?><td></td><td>Chuck Norris Mode</td><?php
						?></tr><?php
						?><tr class="infoRow"><?php
							?><td class="paramDef" style="width:180px;">Chuck Norris Mode</td><?php
							?><td class="chk"><?php
								$disableGrantChuckNorris=($userId!=$viewAsUserId)?0:1;
								drawInteractiveCheck(105,5,0,$right,'prm',0,$disableGrantChuckNorris);
							?></td><?php
						?></tr><?php
					?></table>
			</div><?php
		?></div><?php
	}
	
	if($userId!=$viewAsUserId && $SESSION['edit_user']['user_invited']){
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo"><?php
				?><div class="tableTitle">General Permissions:</div><?php
					?><table class="criteriaTable" style="width:703px;" cellpadding="0" cellspacing="0"><?php
						?><tr class="tableGroup prmRow"style="text-align:center;"><?php
							?><td></td><td>View</td><td>Edit</td><td>Create</td><td>Delete</td><td>Export</td><td>Upload</td><?php
						?></tr><?php
						drawPermissions('Tool','c_tool_general',$SESSION['tool_id'],1,0,0,0,0,0,$right,$SESSION,0,0);
						drawPermissions('Area','c_area_general',0,1,1,1,0,0,0,$right,$SESSION,0,0);						
						drawPermissions('Program','c_program_general',0,1,1,1,0,0,0,$right,$SESSION,0,0);
						drawPermissions('CoE','c_coe_general',0,1,1,1,0,0,0,$right,$SESSION,0,0);
						drawPermissions('Perimeter','c_perimeter_general',0,1,1,1,0,0,0,$right,$SESSION,0,0);
						drawPermissions('MSN','c_msn_general',0,0,1,1,1,0,0,$right,$SESSION,0,0);
						drawPermissions('CA','c_ca_general',0,0,1,1,1,0,0,$right,$SESSION,0,0);
						/*
							US109-General Information not editable by supplier
							Disabled edit,create and delete for review profile
							Fixed By - Infosys Limited
							Version: V 4.5
						*/
						if ($externalUser['type'] == 1) {
							drawPermissions('Review Profile','dr_review_profile_general',0,1,0,0,0,0,0,$right,$SESSION,0,0);
						} else {
							drawPermissions('Review Profile','dr_review_profile_general',0,1,1,1,1,0,0,$right,$SESSION,0,0);
						}
						/* End for US109*/
						drawPermissions('Responsible Configuration','dr_responsible_configuration_general',	0,0,1,0,0,0,0,$right,$SESSION,0,0);
						drawPermissions('Log','dr_log_general',0,1,0,0,0,1,0,$right,$SESSION,0,0);
						drawPermissions('User','c_user_general',0,1,1,1,0,0,0,$right,$SESSION,0,0);
						drawPermissions('Company','c_company_general',0,1,1,1,1,0,0,$right,$SESSION,0,0);
						drawPermissions('Department','c_department_general',0,1,1,1,1,0,0,$right,$SESSION,0,0);
						drawPermissions('Continuous Assessment','continuous_assessment',0,0,0,1,0,0,0,$right,$SESSION,0,0);
						drawPermissions('Force Review Validation','force_validation',0,0,0,1,0,0,0,$right,$SESSION,0,0); //JFM 12_01_16
					?></table><?php
			?></div><?php
		?></div><?php
		
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo">
				<div class="tableTitle">Specific Permissions:</div>
					<table class="criteriaTable" id="specificPermissionsTable" style="width:703px;" cellpadding="0" cellspacing="0"><?php //JFM 16_01_15
						drawSpecPerm('Area','area_id',$area,$right,$SESSION,$area,$areas);
						drawSpecPerm('Program','program_id',$program,$right,$SESSION,$area,$areas);
						drawSpecPerm('CoE','coe_id',$coe,$right,$SESSION,$area,$areas);
						drawSpecPerm('Perimeter','perimeter_id',$perimeter,$right,$SESSION,$program,$areas);
					?></table>
			</div><?php
		?></div><?php
		?><div class="sp"></div><?php
		?><div class="elementDetailsContainer"><?php
			?><div class="elementInfo"><?php
				?><div class="tableTitle">Review Specific Permissions:</div><?php
				?><table id="reviewSpecificPermissionsTable" class="criteriaTable"style="width:703px;" cellpadding="0" cellspacing="0"><?php
					foreach($review as $areaId=>$a)
					{
						foreach($a as $programId=>$r)
						{
							foreach($r as $coeId=>$c)
							{
								if(empty($coe[$coeId])) continue;
								$rowId=$programId.'_'.$coeId;

								$display='none';

								if( $right[$SESSION['object']['area_id']][1][$areaId]==1 && 
									$right[$SESSION['object']['program_id']][1][$programId]==1 && 
									$right[$SESSION['object']['coe_id']][1][$coeId]==1)
								{
									$display='';
								}

								$rspRowId='RSP-'.$program[$programId].'-'.$coe[$coeId];

								?><tr  class="tableGroup prmRow" id="<?=$rspRowId?>" style="display:<?=$display?>" onclick="expandGraphTableReview('reviewSpecificPermissionsTable','<?=$rowId?>');"><?php
									?><td style="width:180px;"><?=$area[$areaId]?><br /><?=$program[$programId]?><br /><?=$coe[$coeId]?></td><?php
									?><td>View</td><td>Edit</td><td>Create</td><td>Delete</td><td>Export</td><td>Upload</td><?php
								?></tr><?php
								foreach($c as $reviewId=>$reviewName)
								{	
									/*
										US109-General Information not editable by supplier
										Disabled edit,create and delete
										Fixed By - Infosys Limited
										Version: V 4.5
									*/
									if ($externalUser['type'] == 1) {
										drawPermissions($reviewName,'review_profile_id',$reviewId,1,0,0,0,1,1,$right,$SESSION,$userId,1,$rowId);
									} else {
										drawPermissions($reviewName,'review_profile_id',$reviewId,1,1,1,1,1,1,$right,$SESSION,$userId,1,$rowId);
									}
									/* End for US109 */

								}
							}
						}
					}
			?></table><?php
		?></div><?php
		?><div class="sp"></div><?php
	}
}
?><div style="position:relative;height:150px;"></div><?php
storeSession($SESSION);

?>