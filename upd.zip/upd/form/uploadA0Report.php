<?php

require_once('../support/header.php');

require_once('../support/form.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);

//$headerRepetition=(getFilter(''))?:;

?>OK|||<div id="uploadA0ReportContainer"style="text-align:center;"style="width:380px;"><?php

	formTitle(380,'Upload Review Report','uploadA0ReportContainer');

	?><div class="sp"></div><?php

	?><form action="home.php"enctype="multipart/form-data"id="uploadCaPictureFrm"method="post"onsubmit="if($('newCaPicture').value.length)$('loadingPictureImg').style.display='inline'"><?php

		?><div class="prompt"><?php

			?><input class="stdBtn"id="a0ReportFile"type="file"name="newCaPicture"size="31"> <?php

			?><input class="stdBtn"id="loadA0Report" onClick="$('uploadCaPictureFrm').submit();closeLastForm();"type="button"value="Load file">&nbsp;<?php

			?><img id="loadingPictureImg"src="?LOADING"width="16"height="16"style="display:none;"> <?php

		?></div><?php

	?></form><?php

?></div>