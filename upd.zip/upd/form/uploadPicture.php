<?php
require_once('../support/header.php');
require_once('../support/form.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);

//$headerRepetition=(getFilter(''))?:;

?>OK|||<div id="uploadPictureContainer"style="text-align:center;"style="width:380px;"><?php
	?><div class="formStdContainer"style="width:380px;">
		<div class="xDiv"><img alt="Close this Window" onClick="closeLastForm();"src="../common/img/x.png"style="cursor:pointer;"></div><?php
		?><div class="formHeaderInfo">Upload Picture</div><?php
	?></div><?php
	?><div class="sp"></div><?php
	?><form action="home.php"enctype="multipart/form-data"id="uploadCaPictureFrm"method="post"onsubmit="if($('newCaPicture').value.length)$('loadingPictureImg').style.display='inline'"target="hiFr"><?php
		?><input name="ca"type="hidden"value="<?=$GET['ca']?>"><?php
		?><div class="prompt"><?php
			?><input class="stdBtn"id="newCaPicture"type="file"name="newCaPicture"size="31"> <?php
			?><input class="stdBtn"id="loadCaPicture" onClick="$('uploadCaPictureFrm').submit();closeLastForm();"type="button"value="Load file">&nbsp;<?php
			?><img id="loadingPictureImg"src="?LOADING"width="16"height="16"style="display:none;"> <?php
		?></div><?php
	?></form><?php
?></div>