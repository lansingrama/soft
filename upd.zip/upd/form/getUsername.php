<?php

/*
 * File to display the selected users
 * Fix for: #033.2 - Bulk user upload (Suggested by ICT) - Display the selected Users to be modified  
 * Created By: Infosys Ltd
 * Version: 4.3
 */

require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../support/mail.php');

$GET=cleanArray($_GET);
$users = explode(',', $GET['sessionUserId']);
$getUsernameFromId = array();
$DisplayUsername = array();
foreach($users as $userId)
{
	$getUsernameFromId = SqlLi('SELECT CONCAT(name," ",surname) AS userfullname , user_id AS userID FROM c_user WHERE user_id= "'.$userId.'"');
	if(is_array($getUsernameFromId)){
		foreach($getUsernameFromId as $u){
			$DisplayUsername[] = $u['userfullname'];
			$DisplayUserID[] = $u['userID'];
		}
	}

}
$DisplayUsername = implode(',',$DisplayUsername);

echo 'OK|||';
 

?><div class="formHeader"><?php
		?><div class="formHeaderInfo"><?php		
			?>Selected User For Editing Permission<?php
		?></div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="sp"></div><?php
	?><div class="elementDetailsContainer"><?php
	?><div class="tableTitle" style="padding-top:20px;">List of selected users:</div><?php 
	?><table class="criteriaTable" cellspacing="0" cellpadding="10"><?php
		?><tr class="tableGroup"><?php
			?><td>User ID</td><?php
			?><td>User Name</td><?php
		?></tr>
	<div>

<?php
foreach($users as $userId)
{
    ?><tr> <td><?php echo $userId;?> </td><?php
    $getUsernameFromId = SqlLi('SELECT CONCAT(name," ",surname) AS userfullname , user_id AS userID FROM c_user WHERE user_id= "'.$userId.'"');
    if(is_array($getUsernameFromId)){
	//For displaying users name
	foreach($getUsernameFromId as $u){ ?>
		<td><?php echo $u['userfullname'];?></td>
	<?php }
    }
} ?>
</tr> </table></div><?php

        ?><input class="stdBtn" id="getLdapInfo" style="float:left;"onClick="openForm('editBulkUserPermissions', 'userID=<?=$GET['sessionUserId']?>&action=<?=$GET['action']?>',false,'GET');closeMenu('<?=$windowId?>');" type="button" value="Proceed &#9658;"><?php	
	?><input class="stdBtn" id="getLdapInfo" style="float:left;"onClick="closeLastForm();" type="button" value="Modify Users &#9658;"><?php
?>