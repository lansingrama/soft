<?php
error_reporting(0);
if($included!=1){
	require_once('../support/header.php');
	require_once('../security/checkExpiredSession.php');
	require_once('../../support.php');
	require_once('../support/form.php');
	require_once('../support/localSupport.php');
	foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
	//$included=1;
}

//JFM 08_06_16 $formTitle=array('area'=>'Area','program'=>'Program','coe'=>'CoE','perimeter'=>'Perimeter','msn'=>'MSN','cawp'=>'CA - WP',/*'responsible'=>'Responsible',*/'review'=>'Review','review_configuration_profile'=>'Configuration Profile','company'=>'Company','department'=>'Department','cat'=>'Criteria Group','grams'=>'Reference'); //JFM 11_11_13

$formTitle=array('area'=>'Area','program'=>'Level 1','coe'=>'Level 2','perimeter'=>$SESSION['table']['review_planning']['ca']['perimeter']['title'],'msn'=>'Level 3','cawp'=>$SESSION['table']['review_planning']['ca']['wp']['title'].' - '.$SESSION['table']['review_planning']['ca']['ca']['title'],'review'=>'Review','review_configuration_profile'=>'Configuration Profile','company'=>'Company','department'=>'Department','cat'=>'Criteria Group','grams'=>'Reference'); //JFM 11_11_13


if($GET['objectTxt']=='review' && $GET['applicability']=='new')
{
	$newReview='new_';
}
else
{
	$newReview='';
}

/*$inputField=array('program'=>'[[\'program\',\'invalid_field_input_1\',\'Program Name\'],[\'program_code\',\'invalid_field_input_2\',\'Program Code\']]',
					'coe'=>'[[\'coe\',\'invalid_field_input_1\',\'CoE\']]',
					'area'=>'[[\'area\',\'invalid_field_input_1\',\'Area\']]',
					'perimeter'=>'[[\'perimeter\',\'invalid_field_input_1\',\'Perimeter\']]',
					'msn'=>'[[\'msn\',\'invalid_field_input_1\',\'MSN\']]',
					'cawp'=>'[[\'wp\',\'invalid_field_input_2\',\'New WP\'],[\'ca\',\'invalid_field_input_1\',\'New CA\']]',
					/*'responsible'=>'[[\'role_name\',\'invalid_field_input_2\',\'Role name\'],[\'group_name\',\'invalid_field_input_1\',\'Group name\']]',
					'review'=>'[[\''.$newReview.'review_type\',\'invalid_field_input_1\',\'New Review Type\']]',
					'review_configuration_profile'=>'[[\'review_configuration_profile\',\'invalid_field_input_1\',\'Review Profile\']]',
					'company'=>'[[\'company\',\'invalid_field_input_1\',\'Company\']]',
					'department'=>'[[\'siglum\',\'invalid_field_input_1\',\'Siglum\'],[\'department_description\',\'invalid_field_input_2\',\'Department Description\']]',
					'cat'=>'[[\'review_group_name\',\'Criteria Group Name\']]',
					'grams'=>'[[\'grams_reference_value\',\'invalid_field_input_1\',\'Reference ID\']]');*/ //JFM 02_12_13 - JFM 03_12_13

$inputField=array('program'=>'[[\'program\',\'invalid_field_input_1\',\'Name\'],[\'program_code\',\'invalid_field_input_2\',\'Code\']]',
					'coe'=>'[[\'coe\',\'invalid_field_input_1\',\'Level 2\']]',
					'area'=>'[[\'area\',\'invalid_field_input_1\',\'Area\']]',
					'perimeter'=>'[[\'perimeter\',\'invalid_field_input_1\',\''.$SESSION['table']['review_planning']['ca']['perimeter']['title'].'\']]',
					'msn'=>'[[\'msn\',\'invalid_field_input_1\',\'Level 3\']]',
					'cawp'=>'[[\'wp\',\'invalid_field_input_2\',\'New '.$SESSION['table']['review_planning']['ca']['wp']['title'].'\'],[\'ca\',\'invalid_field_input_1\',\'New '.$SESSION['table']['review_planning']['ca']['ca']['title'].'\']]',
					'review'=>'[[\''.$newReview.'review_type\',\'invalid_field_input_1\',\'New Review Type\']]',
					'review_configuration_profile'=>'[[\'review_configuration_profile\',\'invalid_field_input_1\',\'Review Profile\']]',
					'company'=>'[[\'company\',\'invalid_field_input_1\',\'Company\']]',
					'department'=>'[[\'siglum\',\'invalid_field_input_1\',\'Siglum\'],[\'department_description\',\'invalid_field_input_2\',\'Department Description\']]',
					'cat'=>'[[\'review_group_name\',\'Criteria Group Name\']]',
					'grams'=>'[[\'grams_reference_value\',\'invalid_field_input_1\',\'Reference ID\']]');

switch($GET['objectTxt']){
	case 'area':
		$areaQry=SqlAsLi('SELECT area_id,area FROM c_area','area_id');
		foreach($areaQry as $areaId=>$areaValue){
			if($areaId==$GET['applicability']){
				$area=$areaValue['area'];
			}else{
				$invalidFieldInput1[]=$areaValue['area'];
			}
		}
	break;
	case 'program':
		$programQry=SqlAsLi('SELECT program_id,program,program_code,military FROM c_program','program_id');
		foreach($programQry as $programId=>$programValue){
			if($programId==$GET['applicability']){
				$programName=$programValue['program'];
				$programCode=$programValue['program_code'];
				$military=$programValue['military'];
			}else{
				$invalidFieldInput1[]=$programValue['program'];
				$invalidFieldInput2[]=$programValue['program_code'];
			}
		}
		/* JFM 02_10_14
		if($GET['applicability']=='new'){
			$availableResponsibleConfiguration=SqlAsArr('SELECT DISTINCT p.program_id,p.program
														FROM c_program AS p
															INNER JOIN dr_responsible_configuration AS r ON p.program_id=r.program
														','program_id','program');
		}*/
	break;
	case 'coe':
		$coeQry=SqlAsLi('SELECT coe_id,coe FROM c_coe','coe_id');
		foreach($coeQry as $coeId=>$coeValue){
			if($coeId==$GET['applicability']){
				$coe=$coeValue['coe'];
			}else{
				$invalidFieldInput1[]=$coeValue['coe'];
			}
		}
	break;
	case 'perimeter':
		$perimeterQry=SqlAsLi('SELECT perimeter_id,perimeter FROM c_perimeter WHERE program='.$GET['program'],'perimeter_id');
		if(is_array($perimeterQry)){
			foreach($perimeterQry as $perimeterId=>$perimeterValue){
				if($perimeterId==$GET['applicability']){
					$perimeter = $perimeterValue['perimeter'];
                                        $prmId = $perimeterValue['perimeter_id'];
				}else{
					$invalidFieldInput1[]=$perimeterValue['perimeter'];
				}
			}
		}
	break;
	case 'msn':
		$msnQry=SqlAsLi('SELECT msn_id,msn FROM c_msn WHERE program='.$GET['program'],'msn_id');
		if(is_array($msnQry)){
			foreach($msnQry as $msnId=>$msnValue){
				if($msnId==$GET['applicability']){
					$msn=$msnValue['msn'];
				}else{
					$invalidFieldInput1[]=$msnValue['msn'];
					$caWpSource[$msnId]=$msnValue['msn'];
				}
			}
		}
	break;
	case 'cawp':
		if($GET['applicability']!='new')
		{
			$cawpLocation=SqlQ('SELECT cw.msn,cw.ca,cw.wp,
									ca.program,ca.coe,ca.perimeter,ca.ca AS ca_txt,
									wp.wp AS wp_txt
								FROM c_cawp AS cw
									INNER JOIN c_ca AS ca ON cw.ca=ca.ca_id
									INNER JOIN c_wp AS wp ON cw.wp=wp.wp_id
								WHERE cw.cawp_id='.$GET['applicability']);
		}
		else
		{
			$cawpLocation=$GET;
		}
		$caWpTitle=array('addWp'=>'add a '.$SESSION['table']['review_planning']['ca']['wp']['title'],
						'addCa'=>'Add a '.$SESSION['table']['review_planning']['ca']['ca']['title'].' into selected '.$SESSION['table']['review_planning']['ca']['wp']['title'],
						'editCaWpName'=>'Edit '.$SESSION['table']['review_planning']['ca']['wp']['title'].' / '.$SESSION['table']['review_planning']['ca']['ca']['title'].' Name');
		if($GET['mode']=='addWp' || $GET['mode']=='editCaWpName')
		{
			$wpToAvoid=($cawpLocation['wp']!='')?' AND wp_id!='.$cawpLocation['wp']:'';
			$invalidFieldInput2=SqlAsArr('SELECT wp_id,wp FROM c_wp WHERE program="'.$cawpLocation['program'].'" AND coe="'.$cawpLocation['coe'].'"'.$wpToAvoid,'wp_id','wp');
			//$msn=($GET['mode']=='addWp')?$GET['msn']:$cawpLocation['msn'];
			$existingWp=SqlAsArr('SELECT wp.wp_id,wp.wp
								FROM c_wp AS wp
								WHERE wp.wp_id NOT IN(
									SELECT wp
									FROM c_cawp AS cw
									WHERE wp.wp_id=cw.wp
										AND msn='.$cawpLocation['msn'].'
								)
								AND wp.program="'.$cawpLocation['program'].'"
								AND wp.coe="'.$cawpLocation['coe'].'"','wp_id','wp');
		}
		
		$caToAvoid=($cawpLocation['ca']!='')?' AND ca_id!='.$cawpLocation['ca']:'';
		$invalidFieldInput1=SqlAsArr('SELECT ca_id,ca FROM c_ca WHERE program='.$cawpLocation['program'].' AND coe='.$cawpLocation['coe'].' AND perimeter='.$cawpLocation['perimeter'].$caToAvoid,'ca_id','ca');
                /***
                 * Fix for : Bug-2
                 * Version :4.1
                 * Fixed by : Infosys Limited
                 * Existing product dropdown displays with the product values which are not mapped for other MSN
                 */
		/*$existingCa=SqlAsArr('SELECT c.ca_id,c.ca
							FROM c_ca AS c
								INNER JOIN c_cawp AS cw ON c.ca_id=cw.ca
							WHERE c.ca_id NOT IN(
								SELECT cw.ca
								FROM c_cawp AS cw
									INNER JOIN c_ca AS c ON cw.ca=c.ca_id
									WHERE msn='.$cawpLocation['msn'].'
							)
							AND c.coe="'.$cawpLocation['coe'].'"
							AND c.perimeter="'.$cawpLocation['perimeter'].'"','ca_id','ca');*/
                $existingCa=SqlAsArr('SELECT c.ca_id,c.ca
                                                        FROM c_ca AS c
                                                        WHERE c.ca_id NOT IN(
                                                        SELECT cw.ca
                                                        FROM c_cawp AS cw
                                                        WHERE msn='.$cawpLocation['msn'].'
                                                        )
                                                        AND c.coe="'.$cawpLocation['coe'].'" 
                                                        AND c.program="'.$cawpLocation['program'].'" 
                                                        AND c.perimeter="'.$cawpLocation['perimeter'].'"','ca_id','ca');
                /*End of modifictaion for Bug-2*/
	break;
	case 'review':
		if($GET['applicability']=='' || $GET['applicability']=='0')
		{
			echo 'error|||Not enough parameters to continue with the operation (Error Case 1)';
		}
		else
		{
			if($GET['applicability']!='new')
			{
				//JFM 19_07_16
				$reviewLocation=SqlQ('SELECT rt.*, rp.program,rp.coe, rp.review_profile_order FROM dr_review_profile AS rp
										INNER JOIN dr_review_type AS rt ON rt.review_type_id = rp.review_type
										 WHERE rp.review_profile_id="'.$GET['applicability'].'"
										 AND area = '.$GET['area']);
				$GET['program']=$reviewLocation['program'];
				$GET['coe']=$reviewLocation['coe'];
				$GET['review_type_id'] = $reviewLocation['review_type_id'];
				$GET['review_profile_order'] = $reviewLocation['review_profile_order'];
                                //Start of bug -5 for display the master review position while editing the review information
                                $GET['master_review_profile_id'] = $reviewLocation['master_review_profile_id'];
                                //End of Bug 5 
			}
			if($GET['applicability']=='new' || $reviewLocation)
			{
				
				if($GET['applicability']!='new')
				{
					$excludeReview=' AND rpr.review_profile_id!="'.$GET['applicability'].'"';
				}
				else
				{
					$excludeReview='';
				}
				
				$invalidFieldInput1=SqlSLi('SELECT rt.review_type
												FROM dr_review_type AS rt
													INNER JOIN dr_review_profile AS rpr ON rt.review_type_id=rpr.review_type
												WHERE rpr.program="'.$GET['program'].'"
													AND rpr.coe="'.$GET['coe'].'"'.$excludeReview,'review_type');
				
				if($GET['applicability']=='new')
				{
					$validReview=allowedReviews($SESSION,'view','program!="" OR coe!=""');
					if(is_array($validReview))
					{
						$review=SqlAsArr('SELECT rpr.review_profile_id,
											CONCAT(rt.review_type," (",prg.program," | ",coe.coe," )") AS review_profile_details
										FROM dr_review_profile AS rpr
											INNER JOIN c_program AS prg ON rpr.program=prg.program_id
											INNER JOIN c_coe AS coe ON rpr.coe=coe.coe_id
											INNER JOIN dr_review_type AS rt ON rpr.review_type=rt.review_type_id
										WHERE review_profile_id IN ('.implode(',',array_keys($validReview)).')','review_profile_id','review_profile_details');
					}
				}
			}
			else
			{
				echo 'error|||Not enough parameters to continue with the operation (Error Case 2)';
			}
		}
	break;
	case 'review_configuration_profile':
		$revConfigQry=SqlAsArr('SELECT review_configuration_profile_id,review_configuration_profile FROM dr_review_configuration_profile WHERE review_profile="'.$GET['review_profile'].'"','review_configuration_profile_id','review_configuration_profile');
		if(is_array($revConfigQry)){
			foreach($revConfigQry as $k=>$v){
				if($k==$GET['applicability']){
					$reviewConfigurationProfileTxt=$v;
				}else{
					$invalidFieldInput1[]=$v;
				}
			}
		}
	break;
	case 'company':
		$companyQry=SqlAsArr('SELECT company_id,company FROM c_company','company_id','company');
		foreach($companyQry as $companyId=>$companyValue){
			if($companyId==$GET['applicability']){
				$company=$companyValue;
			}else{
				$invalidFieldInput1[]=$companyValue;
			}
		}
	break;
	case 'department':
		$departmentQry=SqlAsLi('SELECT department_id,siglum,department_description FROM c_department','department_id');
		foreach($departmentQry as $departmentId=>$departmentValue){
			if($departmentId==$GET['applicability']){
				$siglum=$departmentValue['siglum'];
				$departmentDescription=$departmentValue['department_description'];
			}else{
				$invalidFieldInput1[]=$departmentValue['siglum'];
				$invalidFieldInput2[]=$departmentValue['department_description'];
			}
		}
	break;
	case 'cat': //JFM 11_11_13
		$reviewType=SqlQ('SELECT rt.review_type_id, rt.review_type
							FROM dr_review_type AS rt
								INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id
							WHERE rp.review_profile_id='.$GET['reviewProfile']);
				
		$allReviewGroupsForThisReviewType=SqlAsArr('SELECT review_group_position, CONCAT(\'After - \', review_group_description) AS review_group_description
													FROM dr_review_group_history AS rgh
														INNER JOIN dr_review_group AS rg ON rg.group_id=rgh.review_group
													WHERE rg.review_type='.$reviewType['review_type_id'].'
													AND review_group_valid_to="0000-00-00 00:00:00"
													ORDER BY review_group_position',
													'review_group_position','review_group_description');
													
		if($allReviewGroupsForThisReviewType) array_unshift($allReviewGroupsForThisReviewType,'Start');
		else $allReviewGroupsForThisReviewType = array('0' => 'Start');
		
		if($GET['applicability']=='new')
		{				
			$groupQry=SqlQ('SELECT MAX(review_group_position) AS groupPos
							FROM dr_review_group_history AS rgh
								INNER JOIN dr_review_group AS rg ON rg.group_id=rgh.review_group
							WHERE rg.review_type='.$reviewType['review_type_id'].'
							AND review_group_valid_to="0000-00-00 00:00:00"');
		}
		else
		{
			$groupQry=SqlQ('SELECT review_group_description, review_group_position AS groupPos FROM dr_review_group_history WHERE review_group='.$GET['groupID'].' AND review_group_valid_to="0000-00-00 00:00:00"');
			
			foreach($allReviewGroupsForThisReviewType as $reviewGroupPosition=>$reviewGroupDescription)
			{
				if($groupQry['groupPos']==$reviewGroupPosition) 
				{
					unset($allReviewGroupsForThisReviewType[$reviewGroupPosition]);
					break;
				}
			}
		}
	break;
	case 'grams':  //JFM 03_12_13
		$gramsQry=SqlAsArr('SELECT grams_id,grams_reference FROM c_grams','grams_id','grams_reference');
		foreach($gramsQry as $gramsID=>$gramsValue)
		{
			$invalidFieldInput1[]=$gramsValue;
		}
	break;
}

if($included!=1){
	?>OK|||<?php
}
?><div id="<?=$GET['objectTxt']?>_editStructureContainer"style="text-align:center;width:380px;"><?php
	if($included!=1 && $GET['included'] != 1){
		?><div class="formStdContainer"style="width:380px;"><?php
			?><div class="formHeader"><?php //JFM 25_06_14
				?><div class="formHeaderInfo"><?php
					if($GET['objectTxt']=='cawp') echo $caWpTitle[$GET['mode']];
					else
					{
						echo ($GET['applicability']=='new')?'New ':'Edit ';
						echo $formTitle[$GET['objectTxt']];
						if($GET['applicability']!='new') echo ' ',$element['element_name'];
					}
				?></div><?php
				?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
		?></div><?php
		?><div class="sp"></div><?php
	}else{
		switch($GET['objectTxt'])
		{
			case 'review':
				?><div class="tableTitle" id="editReviewConfigTitle">Review Type (valid for all <?=$type['review_type']?> Reviews):</div><?php
			break;
		}
	}
	
	?><form action="" enctype="multipart/form-data" id="<?=$GET['objectTxt']?>_editStructureFrm" method="post" style="display:inline;" onsubmit="return false;"><?php
		?><input id="objectTxt" name="objectTxt" type="hidden" value="<?=$GET['objectTxt']?>"><?php
		?><input id="applicability" name="applicability" type="hidden" value="<?=$GET['applicability']?>"><?php
		?><input id="invalid_field_input_1" type="hidden" value="<?=implode(',',$invalidFieldInput1)?>"><?php
		if(is_array($invalidFieldInput2)){
			?><input id="invalid_field_input_2" type="hidden" value="<?=implode(',',$invalidFieldInput2)?>"><?php
		}
		switch($GET['objectTxt']){
			case 'program': //JFM 03_06_14
			case 'coe':
				?><input id="area" name="area" type="hidden" value="<?=$GET['area']?>"><?php
			break;
			case 'cawp':
				?><input id="mode" name="mode" type="hidden" value="<?=$GET['mode']?>"><?php
				?><input id="program" name="program" type="hidden" value="<?=$cawpLocation['program']?>"><?php
				?><input id="coe" name="coe" type="hidden" value="<?=$cawpLocation['coe']?>"><?php
				?><input id="perimeter" name="perimeter" type="hidden" value="<?=$cawpLocation['perimeter']?>"><?php
				?><input id="msn" name="msn" type="hidden" value="<?=$cawpLocation['msn']?>"><?php
				if($GET['included']==1)
				{
					?><input id="fromWizard" name="fromWizard" type="hidden" value="1"><?php
				}
			break;
			case 'perimeter':
			case 'msn':
				?><input id="program" name="program" type="hidden" value="<?=$GET['program']?>"><?php
                                ?><input id="coe" name="coe" type="hidden" value="<?=$GET['coe']?>"><?php
			break;
			case 'review': //JFM 03_06_14
				?><input id="program" name="program" type="hidden" value="<?=$GET['program']?>"><?php
				?><input id="coe" name="coe" type="hidden" value="<?=$GET['coe']?>"><?php
				?><input id="review_type_id" name="review_type_id" type="hidden" value="<?=$GET['review_type_id']?>"><?php //JFM 19_07_16
				?><input id="area" name="area" type="hidden" value="<?=$GET['area']?>"><?php
			break;
			case 'review_configuration_profile':
				?><input id="review_profile" name="review_profile" type="hidden" value="<?=$GET['review_profile']?>"><?php
			break;
			case 'cat':
				?><input id="review_type" name="review_type" type="hidden" value="<?=$reviewType['review_type_id'];?>"><?php
				?><input id="applicability" name="applicability" type="hidden" value="<?=$GET['applicability'];?>"><?php
				?><input id="groupID" name="groupID" type="hidden" value="<?=$GET['groupID'];?>"><?php
				?><input id="reviewProfile" name="reviewProfile" type="hidden" value="<?=$GET['reviewProfile'];?>"><?php
			break;
		}
		?><div class="prompt"onKeyUp="checkExistingInput(<?=$inputField[$GET['objectTxt']]?>,'editStructure');"><?php
			?><table class="criteriaTable" style="width:<?=($GET['included'] != 1)?(($included==1)?703:380):800?>px;" cellspacing="0" cellpadding="5"><?php
				if($GET['included'] != 1)
				{
					?><tr class="tableGroup prmRow"><?php
						?><td></td><td<?php if($included==1){?> style="width:350px;"<?php }?>><?=$formTitle[$GET['objectTxt']]?> Details</td><?php
					?></tr><?php
				}
				switch($GET['objectTxt']){
					case 'area':
						drawStdField('Area Name','area',$area,40,'','',0);
						drawStdCheck('Need Level 1','need_program','',1,'',0,0);
						drawStdCheck('Need Level 2','need_coe','',1,'',0,0);
						drawStdCheck('Need Level 3','need_msn','',1,'',0,0);
						drawStdCheck('Need Criteria Validation','need_criteria_validation','',1,'',0,0);
						drawStdCheck('Need Review Validation','need_review_validation','',1,'',0,0);
						drawStdCheck('Need Evidence Validation','need_evidence_validation','',1,'',0,0);
					break;
					case 'program':
						drawStdField('Name','program',$programName,40,'','',0);
						drawStdField('Code','program_code',$programCode,1,'','',1);
						drawStdCheck('Military','military',$military,1);
						/* JFM 02_10_14
						if($GET['applicability']=='new'){
							drawDdListBox('Imp Resp Config','import_responsible_configuration','',$availableResponsibleConfiguration,100,'','','',0);
						}*/
					break;
					case 'coe':
						drawStdField('Name','coe',$coe,40,'','',0);
					break;
					case 'perimeter':
						drawStdField($SESSION['table']['review_planning']['ca']['perimeter']['title'].' Name','perimeter',$perimeter,40,'','',0);
                                                drawPrmListBox($prmId);
					break;
					case 'msn':
						drawStdField('Name','msn',$msn,40,'','',0);
						if(is_array($caWpSource) && $GET['applicability']=='new')
						{
							drawDdListBox($SESSION['table']['review_planning']['ca']['wp']['title'].'/'.$SESSION['table']['review_planning']['ca']['ca']['title'].' Applic. from Level 3','msn_applicability','',$caWpSource,100,'','','',1);
						}
					break;
					case 'cawp':
						if($GET['mode']=='addWp' && $GET['included']!=1)
						{
							$disabledExistingWp=(!is_array($existingWp))?1:'';
							drawDdListBox('Existing '.$SESSION['table']['review_planning']['ca']['wp']['title'],'existingWp','',$existingWp,100,'','','',1,$disabledExistingWp);
						}
						if($GET['mode']=='addWp' || $GET['mode']=='editCaWpName')
						{
							drawStdField('New '.$SESSION['table']['review_planning']['ca']['wp']['title'],'wp',$cawpLocation['wp_txt'],40,'','',0);
						}
						if(($GET['mode']=='addWp' || $GET['mode']=='addCa') && $GET['included']!=1)
						{
							$disabledExistingCa=(!is_array($existingCa))?1:'';
							drawDdListBox('Existing '.$SESSION['table']['review_planning']['ca']['ca']['title'],'existingCa','',$existingCa,100,'','','',1,$disabledExistingCa);
						}
						$caTxt=($GET['mode']=='addWp' || $GET['mode']=='addCa')?'':$cawpLocation['ca_txt'];
						drawStdField('New '.$SESSION['table']['review_planning']['ca']['ca']['title'],'ca',$caTxt,40,'','',0);
					break;
					/* JFM 02_10_14
					case 'responsible':
						drawStdField('Group','responsible_group',$groupName,40,'','',0);
						drawStdField('Role','responsible_role',$roleName,40,'','',0);
					break;*/
					case 'review':
						$fieldSize=($GET['applicability']=='new')?34:98;
						//$fieldSize=($GET['applicability']=='new')?34:98;
						//JFM 16_01_15 drawStdField('New Review Type',$newReview.'review_type',$type['review_type'],$fieldSize,'','',0,'checkExistingReviewType(this.value,\''.$newReview.'\');','','Write here the Review Type. It means: CR, PDR, CDR, FDA, SDA...');
						//JFM 19_07_16
						drawStdField('Review Type Name',$newReview.'review_type',$reviewLocation['review_type'],$fieldSize,'','',0,'','','Write here the Review Type. It means: CR, PDR, CDR, FDA, SDA...');						
						drawStdField('Description',$newReview.'review_type_description',$reviewLocation['review_type_description'],$fieldSize,'','',0,'','',"Here comes the description. For example, for CDR you can write \'Critical Design Review\'");
						drawStdField('Review Code',$newReview.'review_type_code',$reviewLocation['review_type_code'],3,'','',3,'','','It is the code user for identifying the actions. They must be 3 unique characters.');
						drawStdField('Review Position',$newReview.'review_profile_order',$reviewLocation['review_profile_order'],2,'','',2,'','','The order in which the reviews are displayed on the main table. They must maximum 2 digits.');
                                                //Start of Bug 5 - adding a new textbox for master review position
                                                drawStdField('Master Review Position',$newReview.'master_review_profile_id',$reviewLocation['master_review_profile_id'],2,'','',2,'','','The order in which the reviews are displayed on the main table. They must maximum 2 digits.');
                                                //End of Bug 5
						/* JFM 11_11_13
						if($GET['applicability']=='new'){
							$reviewSourceDisabled=(is_array($review))?0:1;
							drawDdListBox('Import Criteria','review_profile_copy_source','',$review,207,'','','$(\'import_review_configuration\').disabled=(ddSelectedValue(this.id)==\'\')?true:false;',1,$reviewSourceDisabled);
							drawStdCheck('Configurations','import_review_configuration',0,1,'',0,1,'Import Configurations');
						}*/
					break;
					case 'review_configuration_profile':
						drawStdField('New Profile','review_configuration_profile',$reviewConfigurationProfileTxt,40,'','',0);
					break;
					case 'company':
						drawStdField('Company Name','company',$company,40,'','',0);
					break;
					case 'department':
						drawStdField('Siglum','siglum',$siglum,40,'','',0);
						drawStdField('Description','department_description',$departmentDescription,40,'','',0);
					break;
					case 'cat':
						drawStdField('Group Name','review_group_name',$groupQry['review_group_description'],40,'','',0);
						drawDdListBox('Group Position','review_group_position','',$allReviewGroupsForThisReviewType,235,'','','',0);
					break;
					case 'grams': //JFM 03_12_13
						drawStdField('Reference ID','grams_reference_value','',40,'','',0);
					break;
				}
			?></table><?php
		?></div><?php
		/*?><div class="save" style="border:#FF0000 1px solid;"><?php*/
		?><div class="save"<?php if($included==1){?> style="width:703px;"<?php }?>><span class="saveResponse"id="editStructure_saveResponse"style="color:#FF0000;"></span><?php
			if($GET['included']!=1)
			{
				if($included==1)
				{
					?><input class="stdBtn"id="btnSaveStructureElement"onClick="<?php
						switch($GET['objectTxt']){
							case 'review':
								?>if(confirm('WARNING:\n\nThis information is valid for all reviews with the same name. <?php
										?>It means that if, for example, you edit the description of the FDA in your Program/CoE and there is another FDA in another Program/CoE, this will be modified too.\n\n<?php
										?>If you change the name for another review type which does not exist yet, it will be automatically created.\n\n<?php
										?>Click on \'Accept\' if you want to continue. Otherwise, click on \'Cancel\' to cancel.')){<?php
									?>sendAjaxForm('<?=$GET['objectTxt']?>_editStructureFrm','ajax/saveStructure.php','updateData','editStructure_saveResponse');<?php
								?>}<?php
							break;
						}
					?>"type="button"value="Apply Changes"> <?php
				}
				else
				{ 
                                    // Added for Bug-#027 (Data Structure)
                                    ?><span id="newDev" style="display:none; color: rgb(255, 0, 0);width: 105%;padding-bottom: 10px;">WARNING!! Please select the Level3 which belongs to selected Level2</span><?php
					?><input class="stdBtn"id="btnSaveStructureElement"onClick=" <?php
                                       
						switch($GET['objectTxt']){
							case 'review':
								?>if(checkExistingInput(<?=$inputField[$GET['objectTxt']]?>,'editStructure')){ sendAjaxForm('<?=$GET['objectTxt']?>_editStructureFrm','ajax/saveStructure.php','reloadSideElement',''); closeLastForm();}<?php
							break;
							case 'review_configuration_profile':
								?>sendAjaxForm('<?=$GET['objectTxt']?>_editStructureFrm','ajax/saveStructure.php','editReviewConfigurationProfile','');<?php
							break;
							case 'cat': //JFM 02_12_13
								?>if(checkExistingInput(<?=$inputField[$GET['objectTxt']]?>,'editStructure')){sendAjaxForm('<?=$GET['objectTxt']?>_editStructureFrm','ajax/saveStructure.php','updateData',''); closeLastForm(); clock(); sideCriteriaGroups('<?=$GET['reviewProfile']?>','<?=$reviewType['review_type']?>','<?=$GET['reviewID']?>'); openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$GET['reviewProfile']?>&reviewTypeName=<?=$reviewType['review_type']?>&reviewID=<?=$GET['reviewID']?>'); }<?php
							break;
							case 'grams': //JFM 03_12_13
								?>sendAjaxForm('<?=$GET['objectTxt']?>_editStructureFrm','ajax/saveStructure.php','reloadSideElement',''); closeLastForm();<?php
							break;
                                                        /***
                                                         *Fix for : Bug-9
                                                         *Version :4.1
                                                         *Fixed by : Infosys Limited
                                                         * Validation for perimeter textbox
                                                         */
                                                        case 'perimeter':  
                                                     
								?>if(checkExistingInput(<?=$inputField[$GET['objectTxt']]?>,'editStructure')){ sendAjaxForm('<?=$GET['objectTxt']?>_editStructureFrm','ajax/saveStructure.php','reloadSideElement',''); closeLastForm();}<?php
                                                               
							break;
							default:
								?>sendAjaxForm('<?=$GET['objectTxt']?>_editStructureFrm','ajax/saveStructure.php','saveStructure','');<?php
							break;
						}
					?> pageRestartNeeded=1;"type="button"value="OK &#9658;"> <?php
					?><input class="stdBtn"onClick="closeLastForm();"type="button"value="Cancel &#9658;"><?php
				}
			}
		?></div><?php
	?></form><?php
?></div><?php
storeSession($SESSION);
?>