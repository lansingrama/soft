<?php
/*
#012-Action Tracking
Generate Email popoUp design
Fixed By - Infosys Limited
Version - 2
*/

require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');
$GET=cleanArray($_GET);
$status=array('Open','In progress','Closed','Fully Closed');

if (!empty($GET['actionId'])) {
$action = SqlQ('SELECT action_code,criteria,action_description,action_remark,action_creation,action_completion,action_status
				FROM dr_action WHERE action_id='.$GET['actionId'].''); 
	
}
if (!empty($action['criteria'])) {
	$criteria = SqlQ('SELECT criterion_name, criterion_description FROM dr_review_criterion_history WHERE criterion = '.$action['criteria'].'');
}

$areaId = getFilter('area','filter',0,$SESSION);
$pId = getFilter('program','filter',0,$SESSION);
$coeId = getFilter('coe','filter',0,$SESSION);
$msnId = getFilter('msn','filter',0,$SESSION);
if (!empty($areaId)) {
	$area = SqlQ('SELECT area FROM c_area WHERE area_id = '.$areaId.'');
}
if (!empty($pId)) {
	$program = SqlQ('SELECT program FROM c_program WHERE program_id = '.$pId.'');
}
if (!empty($coeId)) {
	$coe = SqlQ('SELECT coe FROM c_coe WHERE coe_id = '.$coeId.'');
}
if (!empty($msnId)) {
	$msn = SqlQ('SELECT msn FROM c_msn WHERE msn_id = '.$msnId.'');
}

if (!empty($GET['criteria_ca']) && $msnId) {
	$caMlt=SqlQ('SELECT c.ca_id,c.ca,c.ca_description,
					p.perimeter_id,p.perimeter,
					w.wp_id,w.wp,w.wp_description FROM c_ca AS c
					INNER JOIN	c_perimeter 	AS p 	ON c.perimeter=p.perimeter_id
					INNER JOIN	c_cawp 			AS cw	ON c.ca_id=cw.ca
					INNER JOIN	c_wp 			AS w 	ON cw.wp=w.wp_id
					WHERE c.ca_id IN ('.$GET['criteria_ca'].')
					AND cw.msn='.$msnId.'');
}
if (empty($caMlt)) {
	$caMlt=SqlQ('SELECT DISTINCT c.ca_id,c.ca,c.ca_description,c.caa,c.ca_image_file,
					p.perimeter_id,p.perimeter,
					w.wp_id,w.wp,w.wp_description,w.wp_image_file FROM c_ca AS c
					INNER JOIN	c_perimeter 	AS p 	ON c.perimeter=p.perimeter_id
					INNER JOIN	c_cawp 			AS cw	ON c.ca_id=cw.ca
					INNER JOIN	c_wp 			AS w 	ON cw.wp=w.wp_id
					WHERE c.ca_id IN ('.$GET['criteria_ca'].')');
} 

?>OK|||<div id="changeContainer"style="float:left;text-align:left;width:800px;"><?php
	formTitle('','Generate e-mail','changeContainer','',$popUpParameter='');
	?><div class="formStdContainer"><?php
		?><form action="#" enctype="multipart/form-data" id="generateEmail" method="post" style="display:inline;"><?php
			?><div class="leftInfoBox"style="margin-top:50px;"><?php
				?><table class="criteriaTable"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2" style="padding:6px;font-size:12px;">Email Content</td><?php
						?><input type="hidden" name="caId" value="<?=$GET['criteria_ca']?>"><?php
						?><input type="hidden" name="actionId" value="<?=$GET['actionId']?>"><?php
						?><input type="hidden" name="holderEmail" value="<?=$GET['holderEmail']?>"><?php
						?><input type="hidden" name="validatorEmail" value="<?=$GET['validatorEmail']?>"><?php
					?></tr><?php
					?><tr><?php
						?><td class="paramDef generateEmail">To</td><?php
						?><td><input class="textareaWhite generateEmail generateContent" disabled="" id="to" name="to" size="100" type="text" value="<?=$SESSION['user']['email'];?>"></td><?php
					?></tr><?php
					?><tr><?php
						?><td class="paramDef generateEmail">Subject</td><?php
						?><td><input class="textareaWhite generateEmail generateContent" disabled="" id="subject" name="subject" size="100" type="text" value="Action <?=$action['action_code']?>"></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef generateEmail">Body</td><?php
						$body = "Action Details"."\n\n";
						if (empty($GET['holderEmail'])) $GET['holderEmail'] = "N/A";
						$body  .= "Holder Email: ".$GET['holderEmail']."\n";
						
						if (empty($GET['validatorEmail'])) $GET['validatorEmail'] = "N/A";
						$body .= 'Validator Email: '.$GET['validatorEmail']."\n";
						
						if (empty($action['action_description'])) $action['action_description'] = "N/A";
						$body .= 'Description: '.$action['action_description']."\n";
						
						if (empty($action['action_remark'])) $action['action_remark'] = "N/A";
						$body .= 'Remark: '.$action['action_remark']."\n";
					
						if (empty($action['action_creation'])) $action['action_creation'] = "N/A";
							$body .= 'Creation Date: '.$action['action_creation']."\n";
						
						if (empty($action['action_completion'])) $action['action_completion'] = "N/A";
							$body .= 'Completion Date: '.$action['action_completion']."\n";
						
						$body .= 'Status: '.$status[$action['action_status']]."\n";
						
						$body .= "\nCriteria Details"."\n\n";
						if (empty($criteria['criterion_name'])) $criteria['criterion_name'] = "N/A";
							$body .= "Criteria Name: ".$criteria['criterion_name']."\n";
						
						if (empty($criteria['criterion_description'])) $criteria['criterion_description'] = "N/A";
							$body .= "Criteria Description: ".$criteria['criterion_description']."\n";
						
						
						if (empty($area['area'])) $area['area'] = "N/A";
							$body .= "\nArea: ".$area['area']."\n";
						
						if (empty($program['program'])) $program['program'] = "N/A";
							$body .= "Level1: ".$program['program']."\n";
						
						if (empty($coe['coe'])) $coe['coe'] = "N/A";
							$body .= "Level2: ".$coe['coe']."\n";
						
						if (empty($msn['msn'])) $msn['msn'] = "N/A";
							$body .= "Level3: ".$msn['msn']."\n";
						
						if (empty($caMlt['perimeter'])) $caMlt['perimeter'] = "N/A";
							$body .= "Supplier: ".$caMlt['perimeter']."\n";
						
						if (empty($caMlt['wp'])) $caMlt['wp'] = "N/A";
							$body .= "Group: ".$caMlt['wp']."\n";
						
						if (empty($caMlt['wp_description'])) $msn['wp_description'] = "N/A";
							$body .= "Group Description: ".$msn['wp_description']."\n";
						
						if (empty($caMlt['ca'])) $caMlt['ca'] = "N/A";
							$body .= "Product: ".$caMlt['ca']."\n";
						
						if (empty($caMlt['ca_description'])) $caMlt['ca_description'] = "N/A";
							$body .= "Product Description: ".$caMlt['ca_description']."\n";
						
						?><td><textarea class="textareaWhite generateEmail generateContent" cols="100" id="message" name="message" disabled="" onMouseOver="setInputFocus(this);"rows="25"style="overflow-x:hidden;"><?php echo $body;?></textarea></td><?php
					?></tr><?php
				?></table><?php
				?><div class="save"><?php
					?><input class="stdBtn" style="background-color:#6f95ab;color:white;fonr-size:12px;width:70px;" onClick="sendAjaxForm('generateEmail','ajax/generateEmail.php','showMessage','');closeLastForm();"type="button"value="Send"><?php
				?></div><?php
			?></div><?php
		?></form><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>