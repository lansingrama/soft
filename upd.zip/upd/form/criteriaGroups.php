<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$POST=$_POST;
//print_r($POST);
$casAsString;
$oneCa;

if($POST['reviewID'])
{
	$caIDs=SqlLi('SELECT ca.ca,ca.ca_id 
					FROM c_ca AS ca
					INNER JOIN dr_review_applicability AS ra ON ra.ca=ca.ca_id
					WHERE ra.review="'.$POST['reviewID'].'"');
	
	if($caIDs)
	{
		foreach($caIDs as $ca)
		{
			if(empty($casAsString)) $casAsString=$ca['ca'];
			else $casAsString=$casAsString.', '.$ca['ca'];
		}
		
		$oneCa=$caIDs[0]['ca_id'];
		if(strlen($casAsString) > 25) $casAsStringShort = substr($casAsString,0,22).'...'; //JFM 09_04_14
		else $casAsStringShort=$casAsString;
	}
					
}

$included=1;

?>OK|||<?php
?><div class="formHeader"><?php
	?><div class="formHeaderInfo"><?php
		?><input class="popUpBtnBlue"onClick="popUpOpt('ttl',['lst','<?=$POST['list_name']?>','<?=$POST['list_name']?>','<?=$POST['review_profile']?>','<?=$POST['reviewID']?>','<?=$POST['table_cache_id']?>']);"type="button"value="&#8801;"><?php //JFM 14_11_13	
		?><div class="popUpMenu"id="popUpTtlDiv_lst" style="z-index:100"></div>&nbsp;<?php
		//JFM 09_04_14
		?><div style="display:inline;" <?php
		if(strlen($casAsString)>25){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($casAsString))?>');"<?php }
		?>><?php
			?>Criteria Catalogue Management for <?=$POST['reviewTypeName']?> <?php
			if(!empty($casAsStringShort)) echo '('.$casAsStringShort.')';
			else if($POST['reviewID']=='M') echo '- Master List';
		?></div><?php
	?></div><?php

	if($POST['reviewID']=='M')  																		{ ?><div class="xDiv" onClick="closeLastForm(); changeActiveSideContainer('reviewConfigContainer');" style="cursor:pointer;">&#9668; Back</div><?php }
	else if($POST['comingFromValidationWindow'] && $POST['comingFromValidationWindow']!='undefined')	{ ?><div class="xDiv" onClick="closeLastForm(); changeActiveSideContainer('sideValidationContainer');" style="cursor:pointer;">&#9668; Back</div><?php }
	else if($POST['reviewID'] && $POST['reviewID']!='undefined')										{ ?><div class="xDiv" onClick="closeLastForm(); changeActiveSideContainer('sideReviewContainer');" style="cursor:pointer;">&#9668; Back</div><?php }
	else				 																				{ ?><div class="xDiv" onClick="closeLastForm();" style="cursor:pointer;">&#9668; Back</div><?php }

?></div><?php

?><div class="sideList" id="catContainer" style="top:70px;"><?php
	
	include('../ajax/sideCriteriaGroups.php');
	
?></div><?php
?><div class="sideDetailsContainer" style="" id="sideCatContainer"><?php
	?><div class="sideContainerEmpty">Please Wait...</div><?php
?></div><?php
storeSession($SESSION);
?>