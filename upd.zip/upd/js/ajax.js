function ajaxReqPr(rt,rq,asyncMode){
	if(rt=='_!exit!_'){
		window.location='index.php?error=session_expired';
		return false;
	}
	rt=checkAjaxResponse(rt,rq); //JGM 15_09_15
	if(rt!='KO'){
		switch(rq){
			case 'actionsInCriteria':
				rta=rt.split('&&&');
				l=rta[0].split('%%%');
				actionCount=parseInt(rta[1]);
				target=(l[1]==0)?'group':'criteria';
				switch(l[2]){
					case 'edit':
						if(rta[2]=='' || confirm('The '+target+' you are trying to edit contains '+rta[1]+' actions. Here there is a list of '+((actionCount>10)?'the first 10':'all of them')+':\n\n'+rta[2]+'\n\nAre you sure you want to edit this '+target+'?')){
							editCriteria(l[0],l[1],'edit');
						}
					break;
					case 'delete':
						if(rta[2]==''){
							if(confirm('Are you sure you want to remove this '+target+'?\n\nTHIS ACTION WILL DELETE THE CRITERIA AND ITS STATUS\n\nTHIS CANNOT BE UNDONE')){
								deleteCriteria(l[0],l[1]);
							}
						}else{
							if(confirm('WARNING\n\nThe '+target+' you are trying to DELETE contains '+rta[1]+' actions. Here there is a list of '+((actionCount>10)?'the first 10':'all of them')+':\n\n'+rta[2]+
											'\n\nAre you sure you want to DELETE this '+target+'?\n\nTHIS ACTION WILL DELETE THE CRITERIA, ITS STATUS AND ITS ACTIONS\n\nTHIS CANNOT BE UNDONE')){
								deleteCriteria(l[0],l[1]);
							}
						}
					break;
				}
			break;
			case 'checkAvailableResults':
				b=$('requestNextResult_'+tableCacheId);
				if(b){
					r=rt.split('&&&');
					if(r[1]==0){
						b.style.visibility='hidden';
					}else{
						cachedResults=parseInt(r[1]);
						displayedResults=(cachedResults>maxResults)?maxResults:cachedResults;
						b.value='\u25BC \u25BC Show next '+number_format(displayedResults,0,'','.')+' Results out of '+number_format(cachedResults,0,'','.')+' left ('+number_format(r[0],0,'','.')+' in total) \u25BC \u25BC';
						b.disabled=false;
					}
				}
			break;
			case 'checkExistingReviewType':
				d=$('review_type_description');
				c=$('review_type_code');
				if(rt=='no_review_type'){
					d.disabled=false;
					c.disabled=false;
					if(lastReviewTypeCheckedExists==1){
						d.value='';
						c.value='';
					}
					lastReviewTypeCheckedExists=0;
				}else{
					d.disabled=true;
					c.disabled=true;
					rtDetails=rt.split('&&&');
					d.value=rtDetails[0];
					c.value=rtDetails[1];
					lastReviewTypeCheckedExists=1;
				}
			break;
			case 'checkNewChangeLog':
				rta=rt.split('&&&');
				switch(rta[0]){
					case 'first_login':
						if(firstLoginWindowShown==0)
						{
							ajaxRequest('ajax/tutorial.php','showTutorial',false,'GET');

							firstLoginWindowShown=1;
						}
					break;
					case 'main_table_tutorial':
						if(mainTableTutorialDelayed == 0) ajaxRequest('ajax/mainTableTutorial.php','showTutorial',false,'GET');
					break;
				}

				changeLogChecked=1;// JFM 28_10_15

			break;
			case 'checkOk':
				field=rt.split('&&&');
				for(var i in field)
				{
					if(field[i]=='reloadSideElementNeeded')
					{
						reloadSideElementNeeded=1;
					}
					else
					{
						c='chk_'+field[i];

						if($(lastCheck+'-'+field[i]))
						{
							if(indirectChkChange==1)
							{
								$(lastCheck+'-'+field[i]).checked=indirectChkValue;
							}
							if(!$(c))
							{
								var e=document.createElement('span');
								e.setAttribute('id','chk_'+field[i]);
								$(lastCheck+'-'+field[i]).parentNode.appendChild(e);
								$(c).innerHTML='&#10003;';
								$(c).className='chkOk';
							}
                                                        
							if(lastCheck=='prm' || lastCheck=='bulkEdit') //JFM 16_01_15
							{
								var thisRow=$(lastCheck+'-'+field[i]).parentNode.parentNode;
								var rowId=$(lastCheck+'-'+field[i]).parentNode.parentNode.id

								if(rowId.substring(0,3)=='SP_')
								{
									var chkDisplay='';
									if(chkValue==1) chkDisplay='';
									else chkDisplay='none';

									var showOrHideMe='';
									if(rowId.substring(3,7)=='TOP_') 
									{
										showOrHideMe=rowId.substring(7,rowId.length);

										var specificPermissionsTable = $('specificPermissionsTable');
										for (var j = 0, specificPermissionsRow; specificPermissionsRow = specificPermissionsTable.rows[j]; j++)
										{
											if(specificPermissionsRow.id.substring(7,rowId.length)==showOrHideMe && specificPermissionsRow.id.substring(3,7)!='TOP_'  && specificPermissionsRow.id.substring(3,7)!='PRE_') specificPermissionsRow.style.display=chkDisplay;
										}
									}
									else if(rowId.substring(3,7)=='PRO_') 
									{
										if(chkValue==1) chkDisplay='';
										else chkDisplay='none';

										showOrHideMe=rowId.substring(7,rowId.length);
										var specificPermissionsTable = $('specificPermissionsTable');
										for (var j = 0, specificPermissionsRow; specificPermissionsRow = specificPermissionsTable.rows[j]; j++)
										{
											if(specificPermissionsRow.id.substring(3,specificPermissionsRow.id.length)=='COE_'+showOrHideMe) 
											{										
												if(specificPermissionsRow.cells[1].getElementsByTagName("input")[0].checked || (!chkValue && !specificPermissionsRow.cells[1].getElementsByTagName("input")[0].checked))
												{
													if($('RSP-'+thisRow.cells[0].innerHTML+'-'+specificPermissionsRow.cells[0].innerHTML))
													{
														$('RSP-'+thisRow.cells[0].innerHTML+'-'+specificPermissionsRow.cells[0].innerHTML).style.display=chkDisplay;
													}
												}
											}
											if(specificPermissionsRow.id.substring(3,specificPermissionsRow.id.length)=='PRE_'+showOrHideMe) 
											{
												if(thisRow.cells[0].innerHTML==specificPermissionsRow.cells[0].innerHTML.substring(0,thisRow.cells[0].innerHTML.length))
												{
													specificPermissionsRow.style.display=chkDisplay;
												}
											}
										}
									}
									else if(rowId.substring(3,7)=='COE_') 
									{
										if(chkValue==1) chkDisplay='';
										else chkDisplay='none';

										showOrHideMe=rowId.substring(7,rowId.length);
										var specificPermissionsTable = $('specificPermissionsTable');
										for (var j = 0, specificPermissionsRow; specificPermissionsRow = specificPermissionsTable.rows[j]; j++)
										{
											if(specificPermissionsRow.id.substring(3,specificPermissionsRow.id.length)=='PRO_'+showOrHideMe)
											{										
												if(specificPermissionsRow.cells[1].getElementsByTagName("input")[0].checked || (!chkValue && !specificPermissionsRow.cells[1].getElementsByTagName("input")[0].checked))
												{
													if($('RSP-'+specificPermissionsRow.cells[0].innerHTML+'-'+thisRow.cells[0].innerHTML))
													{
														$('RSP-'+specificPermissionsRow.cells[0].innerHTML+'-'+thisRow.cells[0].innerHTML).style.display=chkDisplay;
													}
												}
											}
										}
									}
								}
							}
						}
						showSaveResponse(c);
					}
				}
			break;
			// Added for #032 Bulk user upload (Suggested by ICT)
                        case 'bulkEdit': 
                            field=rt.split('&&&');
				for(var i in field)
				{
					if(field[i]=='reloadSideElementNeeded')
					{
						reloadSideElementNeeded=1;
					}
					else
					{
						c='chk_'+field[i];

						if($(lastCheck+'-'+field[i]))
						{
							if(indirectChkChange==1)
							{
								$(lastCheck+'-'+field[i]).checked=indirectChkValue;
							}
							if(!$(c))
							{
								var e=document.createElement('span');
								e.setAttribute('id','chk_'+field[i]);
								$(lastCheck+'-'+field[i]).parentNode.appendChild(e);
//								$(c).innerHTML='&#10003;';
//								$(c).className='chkOk';
							}
                                                        
							if(lastCheck=='prm' || lastCheck=='bulkEdit') //JFM 16_01_15
							{
								var thisRow=$(lastCheck+'-'+field[i]).parentNode.parentNode;
								var rowId=$(lastCheck+'-'+field[i]).parentNode.parentNode.id

								if(rowId.substring(0,3)=='SP_')
								{
									var chkDisplay='';
									if(chkValue==1) chkDisplay='';
									else chkDisplay='none';

									var showOrHideMe='';
									if(rowId.substring(3,7)=='TOP_') 
									{
										showOrHideMe=rowId.substring(7,rowId.length);

										var specificPermissionsTable = $('specificPermissionsTable');
										for (var j = 0, specificPermissionsRow; specificPermissionsRow = specificPermissionsTable.rows[j]; j++)
										{
											if(specificPermissionsRow.id.substring(7,rowId.length)==showOrHideMe && specificPermissionsRow.id.substring(3,7)!='TOP_'  && specificPermissionsRow.id.substring(3,7)!='PRE_') specificPermissionsRow.style.display=chkDisplay;
										}
									}
									else if(rowId.substring(3,7)=='PRO_') 
									{
										if(chkValue==1) chkDisplay='';
										else chkDisplay='none';

										showOrHideMe=rowId.substring(7,rowId.length);
										var specificPermissionsTable = $('specificPermissionsTable');
										for (var j = 0, specificPermissionsRow; specificPermissionsRow = specificPermissionsTable.rows[j]; j++)
										{
											if(specificPermissionsRow.id.substring(3,specificPermissionsRow.id.length)=='COE_'+showOrHideMe) 
											{										
												if(specificPermissionsRow.cells[1].getElementsByTagName("input")[0].checked || (!chkValue && !specificPermissionsRow.cells[1].getElementsByTagName("input")[0].checked))
												{
													if($('RSP-'+thisRow.cells[0].innerHTML+'-'+specificPermissionsRow.cells[0].innerHTML))
													{
														$('RSP-'+thisRow.cells[0].innerHTML+'-'+specificPermissionsRow.cells[0].innerHTML).style.display=chkDisplay;
													}
												}
											}
											if(specificPermissionsRow.id.substring(3,specificPermissionsRow.id.length)=='PRE_'+showOrHideMe) 
											{
												if(thisRow.cells[0].innerHTML==specificPermissionsRow.cells[0].innerHTML.substring(0,thisRow.cells[0].innerHTML.length))
												{
													specificPermissionsRow.style.display=chkDisplay;
												}
											}
										}
									}
									else if(rowId.substring(3,7)=='COE_') 
									{
										if(chkValue==1) chkDisplay='';
										else chkDisplay='none';

										showOrHideMe=rowId.substring(7,rowId.length);
										var specificPermissionsTable = $('specificPermissionsTable');
										for (var j = 0, specificPermissionsRow; specificPermissionsRow = specificPermissionsTable.rows[j]; j++)
										{
											if(specificPermissionsRow.id.substring(3,specificPermissionsRow.id.length)=='PRO_'+showOrHideMe)
											{										
												if(specificPermissionsRow.cells[1].getElementsByTagName("input")[0].checked || (!chkValue && !specificPermissionsRow.cells[1].getElementsByTagName("input")[0].checked))
												{
													if($('RSP-'+specificPermissionsRow.cells[0].innerHTML+'-'+thisRow.cells[0].innerHTML))
													{
														$('RSP-'+specificPermissionsRow.cells[0].innerHTML+'-'+thisRow.cells[0].innerHTML).style.display=chkDisplay;
													}
												}
											}
										}
									}
								}
							}
						}
						showSaveResponse(c);
					}
				}
			break;
			// End of add for #032 Bulk user upload (Suggested by ICT)
                        //improvement 6 (toggle include all criteria)
                        case 'checkOkAll':
                            field=rt.split(',');
                            for(var i in field){
                            var d =  field[i].split('&&&');
				if($('criterion_included_'+d[0]))
				{
					switch(d[1]){
						case 'NO':
							$('criterion_included_'+d[0]).innerHTML='<span class="r boolean">No</span>';
						break;

						case 'YES':
							$('criterion_included_'+d[0]).innerHTML='<span class="g boolean">Yes</span>';
						break;
					}
				}
                            }
                            break;
			case 'ddFill':
				ddFill(rt);
			break;
			case 'editReviewConfigurationProfile':
				if(rt!=''){
					var rta=rt.split('%%%');
					var id=$('review_configuration_profile_list');
					if(rta[0]=='new'){
						ddAdd(id,rta[1],rta[2],1);
					}else if(rta[0]=='delete'){
						id.selectedIndex=0;
					}
					changeRevConfigProfile(id,'reviewCriteriaManagementList','','',rta[3]);
					if(rta[0]!='delete'){
						closeLastForm();
					}
				}
			break;
			case 'forgotPassword':
				switch(rt){
					case 'not_found':
						alert('The combination of User and Email was not found. Please, check if they are correct.');
					break;
					case '1':
						alert('Password recovery successfully. An email has been sent to you with your new password.\n\nPlease, remember to change it at soon as possible.');
						closeLastForm();
					break;
				}
			break;
			case 'getLdapInfo': //JFM 09_04_14
				rtArr=rt.split('&&&');
				$('nameUserMainDataForm').value=rtArr[0];
				$('surnameUserMainDataForm').value=rtArr[1];
				$('emailUserMainDataForm').value=rtArr[2];
				$('siglum').value=rtArr[3]; //JFM 19_07_16
			break;
			case 'headerMenu':
				var rta=rt.split('###');
				$(rta[0]+'_m').innerHTML=rta[1];
			break;
			case 'loadReviewTypeDetails':
				var rta=rt.split('&&&');
				reviewTypeDetails=Array();
				for(var i in rta){
					rtd=rta[i].split('%%%');
					reviewTypeDetails[i]=Array(rtd[0],rtd[1].toUpperCase(),rtd[2],rtd[3]);
				}
				reviewTypeDetailsLoaded=1;
			break;
			case 'loadUserList':
				suggestArr=rt.split('$$$');
				var userArr=suggestArr[0].split('&&&');
				searchElId[0]=new Array();
				searchName[0]=new Array();
				for(var i in userArr){
					var userItem=userArr[i].split('%%%');
					searchElId[0][i]=userItem[0];
					searchName[0][i]=userItem[1];
				}
				if(suggestArr.length>1){
					$(contDiv).innerHTML=suggestArr[1];
					userCount=userArr.length;
				}
				userListLoaded=1;
			break;
			case 'nextResult':
				attachRowToTable(rt,'table_'+tableCacheId);
				checkAvailableResults();
			break;
			case 'newRid':
				$('rid').options[1].text='New RID... (Provisory: '+rt+')';
				$('disabledRid').style.display='none';
			break;
			case 'newSideElement':
				if(rt!=''){
					var e=document.createElement('div');
					divId=newSideElDivId+'_'+rt;
					if(exists(searchDivId[newSideSearchId]) && (exists(newSideSearchId) || newSideSearchId==0)){
						searchLength=searchDivId[newSideSearchId].length;
						searchDivId[newSideSearchId][searchLength]=divId;
						searchName[newSideSearchId][searchLength]=newSideElText;
						searchElId[newSideSearchId][searchLength]=rt;
					}
					e.className='sideElement';
					e.id=divId;
					e.onclick=function(){
						openSideElement(rt,newSideElType);
					};
					e.innerHTML=newSideElText;
					$(newSideElContainer).appendChild(e);
					var nr=$(newSideElDivId+'_noResults');
					if(nr){
						nr.style.display='none';
					}
					openSideElement(rt,newSideElType);
				}
			break;
			case 'ol':return overlib(rt);break;
			case 'olsticky': //JFM 24_03_14 - JFM 09_04_14
				if(oldCol!='overDivCriteriaStatus') closeMenu(oldCol);
				oldCol=activeCol;
				overlibGlobalDivId='overDivCriteriaStatus';
				overlib(rt, STICKY, LEFT, ABOVE);
				overlibGlobalDivId='';
				break;
			case 'olstickyNewPopup': //JFM 15_09_15
				if(oldCol!='overDivCriteriaStatus') closeMenu(oldCol);
				oldCol=activeCol;
				overlibGlobalDivId='overDivCriteriaStatus';
				overlib(rt, STICKY, CENTER, VCENTER, WIDTH, 130, HEIGHT, 130, BORDER, 0, FGCOLOR, '', BGCOLOR, '');
				overlibGlobalDivId='';
				break;
			case 'openForm':
				var d=new Date();
				var uniqueId=d.getTime();
				var e=document.createElement('div');
				formZIndex+=2;
				e.id='formObject_'+uniqueId;
				e.innerHTML='<div class="whiteBG"id="whiteBG_'+uniqueId+'" onClick="closeLastForm();"></div><div class="popUpForm"id="formAjax_'+uniqueId+'">'+rt+'</div>';
				wId=e.firstChild;
				faId=e.lastChild;
				wId.style.zIndex=formZIndex;
				faId.style.zIndex=formZIndex+1;
				if(formHeight!=0)
				{
					if(formHeight=='100%')
					{
						faId.style.height=formHeight;
					}
					else
					{
						faId.style.height=formHeight+'px';
						faId.style.marginTop='-'+(formHeight/2)+'px';
						faId.style.top='50%';
					}
				}

				if(formWidth!=0 && formWidth!='max') 
				{
					if(typeof formWidth === 'string' && formWidth.slice(-1)=='%') //JFM 17_08_15
						faId.style.marginLeft=formWidth;
					else
						faId.style.marginLeft=formWidth+'px';
				}
				$('formContainer').appendChild(e);
				document.documentElement.style.overflow='hidden';

				$('formAjax_'+uniqueId).style.left='50px'; //JFM 12_01_16
				whiteBg[formCount]=uniqueId;
				if(formCount>0)
				{
					for (var i = 1; i <= formCount; i++)
					{
						$('whiteBG_'+whiteBg[formCount-i]).style.display='none'; //JFM 12_01_16
					}
				}
				formCount++;
				checkAvailableResults();
				if(document.forms[0]) //JFM 02_10_14
				{
					for (var i = 0; i < document.forms.length; i++) 
					{
						getAllElementsOfFormAndStoreInString(document.forms[i].id);
					}
				}
			break;
			case 'openSideElement':
				$(activeSideContainer).innerHTML=rt;
			break;
			case 'prevSel':
				if(rt=='show')restartMainTable();
				else ddFill(rt);
			break;
			case 'putInDiv':
				if(rt.substring(0,15)=='!!!ATTENTION!!!') alert(rt); //JFM 30_10_14
				else if(rt.substring(0,8)=='overview') //JFM 02_12_15
				{
					rtArr=rt.split('&&&');
					if($(containerDiv)) $(containerDiv).innerHTML=rtArr[1];
					for(i=2; i<rtArr.length; i++)
					{
						rtGraphArr=rtArr[i].split('---');
						graphThis(rtGraphArr[0], rtGraphArr[1], rtGraphArr[2], rtGraphArr[3], rtGraphArr[4], rtGraphArr[5]);
					}
				}
				else if($(containerDiv)) $(containerDiv).innerHTML=rt;
			break;
			case 'putInDivClock':
				rtArr=rt.split('&&&');
				$('validNumber').style.marginLeft=rtArr[0];
				$('validNumber').innerHTML=rtArr[1];
				$('validImg').src='../common/img/'+rtArr[2]+'.png';

				//if($('validMenuNumber')) $('validMenuNumber').innerHTML=rt;
			break;
			case 'putInReviewRemark':
				if($('review_remark')) $('review_remark').innerHTML=rt;
			break;
			case 'recordError':
			break;
			case 'reloadSideElement':
				reloadSideElement();
			break;
			case 'removeCaWpPicture':
				if(rt=='OK'){
					$('caWpImg').style.display='none';
					$('inf').style.display='block';
				}
			break;
			case 'removeElement':
				switch(removeCase){
					case 'action':
						var rta=rt.split('&&&');
						if(rta[0]!='' && rta[1]!='' && rta[2]!='' && rta[3]!='' && rta[4]!=''){
							ca=rta[4].split(',');
							for(var i in ca){
								alterCounter('review_'+statusTxt[rta[3]]+'_action_'+ca[i]+'_'+rta[1],-1);
								alterCounter('criteria_'+statusTxt[rta[3]]+'_action_'+ca[i]+'_'+rta[2],-1);
								alterCounter('criteria_total_action_'+ca[i]+'_'+rta[2],-1);
							}
							$('action_status_'+rta[0]).parentNode.removeNode(true);
						}
					break;
				}
			break;
			case 'removeReviewProfile':
				var t='';
				switch(rt){
					case 'no_empty_review':				t='Reviews';			break;
					case 'no_empty_criteria_status':	t='Criteria Status';	break;
					case 'no_empty_action':				t='Actions';			break;
					case 'no_empty_rid':				t='RIDs';				break;
				}
				if(t==''){
					sideReviews();
					mainRestartNeeded=1;
				}else{
					alert('The Review Profile you are trying to delete contains '+t+' which are not empty.\n\nThis action will be not performed until this issue is solved.');
				}
			break;
			case 'restartMainTable':
				restartMainTable();
			break;
			case 'saveCriteriaConfig':
				r=rt.split('&&&');
				if(r.length==3)editCriteria(r[0],r[1],'update',r[2]);
				else editCriteria(r[0],r[1],'update',r[2],r[3]);
			break;
			case 'setRevConfigValue':
				r=rt.split('&&&');
				$('criteriaRow-'+r[0]+'-'+r[1]).style.backgroundColor=revConfigColor[r[2]];
			break;
			case 'saveRowConfig':
				closeLastForm();
			break;
			case 'saveStructure':
				if(rt=='reload_main_table')
				{
					//window.location='home.php';
					window.location='index.php';
				}
				else if (rt=='wizardOK')
				{
					mainRestartNeeded = 1;
					wizardStepCalculate(1);
				}
				else
				{
					if(rt.indexOf('%%%')!=-1){
						ddEl=rt.split('&&&');
						for(i in ddEl){
							dd=ddEl[i].split('%%%');
							if(i==0){
								var applicability=dd[0];
								var objectTxt=dd[1];
							}else{
								if(applicability=='new'){
									ddAdd($(dd[0]),dd[1],dd[2],1);
								}
							}
						}
					}
					if(exists(objectTxt)){
						changeStrLoc(objectTxt);
					}
					reloadSideElement(1);
				}
			break;
			case 'sendEmail':
				window.location=rt;
			break;
			case 'showCal':
				$(divId).innerHTML=rt;
				showCal(calId,divId,dispId,hideId,M,Y,lowId,onClkEv,past,fut);
			break;
			case 'showFilter':
				closeMenu(oldCol); //JFM 02_09_13
				if($(oldCol))destroyInnerHTML($(oldCol));
				oldCol=activeCol;
				var c=$(activeCol);
				c.innerHTML=rt;
				//c.style.zIndex=formZIndex+2;
				c.style.display='block';
				if(popUpType=='filter'){
					storeInitialValues(activeCol+'-form');
				}
				
				//changePopUpButtonColor(activeCol); //JFM 03_06_14

				//c.scrollIntoView(); JFM 18_03_14 - JFM 02_03_14
			break;
			case 'showMessage':
				//alert(rt);
			break;
			case 'showTable':
				var skipStatusUpdate=false;
				rtArraySplit=rt.split('&&&');
				if(activeTable=='review_planning')
				{
					destroyInnerHTML($('review_planning-tableContainer'));
					chkBoxSel=Array();
					mainTableWaitMessage();
				}
				if(rtArraySplit[0]!='too_many_columns' && changeLogChecked==0)
				{
					checkNewChangeLog();
				}
				switch(rtArraySplit[0])
				{
					case 'no_program_coe_msn':
						noProgramCoeMsn(1,1,1); //JFM 03_06_14
					break;
					case 'too_many_columns':
						alert('WARNING\n\n\n- Number of reviews displaying the criteria status: '+rtArraySplit[1]+'.\n- Maximum allowed: 1\n\nNow you will be redirected to the \'Displayed Columns\' area. Then:\n\n'+
								'- Leave selected maximum 1 of the elements in the \'Criteria\' column.\n- Unselect all non-desired elements.\n- Close the window (changes are automatically applied).');
						openForm('columnConfig','',false,'GET');
						openSideElement('review','cfc');
					break;
					case 'dashboard_view': //JFM 13_12_14
						skipStatusUpdate=true;
						$(activeTable+'-tableContainer').innerHTML=rtArraySplit[1];
						for(i=2; i<rtArraySplit.length; i++)
						{
							graphArr									=rtArraySplit[i].split('---');
							graphOnClick								=graphArr[2];
							graphOnClickMsn								=graphArr[3];
							graphOnClickCoe								=graphArr[4];
							graphOnClickMsnID							=graphArr[5];
							graphOnClickReviewProfile					=graphArr[6]; //JFM 24_03_14
							graphOnClickCa								=graphArr[7];
							graphOnClickArea							=graphArr[8];
							graphOnClickProgram							=graphArr[9];
							if(graphArr[10]) graphOnClickUser			=graphArr[10];
							else graphOnClickUser						='';
							if(graphArr[11] == 'burn_up')
								graphThis(graphArr[0],JSON.parse(graphArr[1]),'burnDown',graphArr[12],graphArr[13],graphArr[14],graphArr[15],graphArr[16]);
							else
								graphThis(graphArr[0],graphArr[1].split(','),'pie'); //JFM 20_05_14
						}
					break;
					case 'trl': //JFM 03_06_14
						skipStatusUpdate=true;
						$(activeTable+'-tableContainer').innerHTML=rtArraySplit[1];
					break;
					case 'overview': //JFM 02_12_15
						skipStatusUpdate=true;
						$(activeTable+'-tableContainer').innerHTML=rtArraySplit[1];
						if(rtArraySplit[2])
						{
							containerDiv='inTheMiddle';
							ajaxRequest('ajax/overviewCalculate.php?program='+rtArraySplit[2],'putInDiv',false,'GET');
						}
					break;
					default:
						$(activeTable+'-tableContainer').innerHTML=rt;
						if($('tutorialHolder').style.display != 'block') checkNewChangeLog(1);
						else mainTableTutorialDelayed = 1;
					break;
				}
				if(!skipStatusUpdate) updateResultsStatistics();
				processing=false;
				if(fromIndex)
				{
					if($('loginContainerForm')) destroyNode($('loginContainerForm'));
					if($('announcement')) destroyNode($('announcement'));
					if($('help')) destroyNode($('help'));
					if($('indexError')) destroyNode($('indexError'));
					$('processingLogin').style.display='none';
					$('processingLogin').style.opacity=1;

					$('login').style.zIndex = '3';
					$('login').style.top = '0px';
					$('login').style.left = '0px';
					$('login').style.position = 'fixed';
					$('login').style.margin = '0px';
					$('login').style.padding = '0px';
					$('login').style.width = '100%';
					$('login').style.height = '48px';

					$('loginLogo').style.clear='both';
					$('loginLogo').style.pointer='cursor';
					$('loginLogo').style.float='left';
					$('loginLogo').style.paddingLeft='10px';
					$('loginLogo').style.paddingTop='10px';

					//$('loadBackground').style.zIndex = '2';
					$('loadBackground').style.bottom = '0';

					if (typeof $('loadBackground').addEventListener != "undefined") 
					{ 
						$('loadBackground').addEventListener('transitionend', function(event) { setTimeout(function(){var html=[]; html.push($('loadbody').innerHTML); destroyInnerHTML($('loadbody')); document.body.innerHTML=html.join('');},25); }, false );
					}
					else
					{
						document.body.innerHTML=$('loadbody').innerHTML;
					}
					fromIndex=false;
				}
			break;
			case 'updateData':
				updateData(rt);
			break;
			case 'viewAs':
				if(rt==1){
					//JFM 12_01_15 window.location='home.php';
					window.location='index.php';
				}
			break;
			case 'updateBooleanValue':
				rta=rt.split('&&&');
				if($('criterion_included_'+rta[0]))
				{
					switch(rta[1]){
						case 'NO':
							$('criterion_included_'+rta[0]).innerHTML='<span class="r boolean">No</span>';
						break;

						case 'YES':
							$('criterion_included_'+rta[0]).innerHTML='<span class="g boolean">Yes</span>';
						break;
					}
				}
			break;
			case 'showTutorial':
				$('tutorialHolder').style.display='block';
				$('tutorialHolder').innerHTML=rt;
			break;
			case 'refreshOrReloadEntirePage':
				//window.location='home.php';
				window.location='index.php';
			break;
			case 'removeRowById':
				if($(rt))
				{
					var row = $(rt);
   					row.parentNode.removeChild(row);
   				}
			break;
			case 'doNothing':
			break;
			case 'createNewUser': //JFM 16_01_15
				rta=rt.split('&&&');
				userListLoaded=0;
				closeLastForm();
				openForm('userPermissions', 'element='+rta[0],false,'GET'); //JFM 28_10_15
			break;
			case 'setFav': //JFM 12_01_16
				rta=rt.split('&&&');
				if($(rta[0]))
				{
					if(rta[1] == 1)
						$(rta[0]).style.display='';
					else
						$(rta[0]).style.display='none';
				}
			break;
			case 'newLogin': //JFM 12_01_16
				rta=rt.split('&&&');
				switch(rta[0])
				{
					case 'home':
						$('indexError').style.marginTop='60px';
						setTimeout(function(){$('indexError').style.display='none';},500);
						$('nameIndex').innerHTML = '<b>Welcome '+ unescape(rta[1]) + '</b>';
						$('pleaseWaitIndex').innerHTML = 'Login Success!';
						ajaxRequest('home.php','putInBody',true,'GET');
					break;

					default:
						$('indexError').style.marginTop='132px';
						setTimeout(function(){$('processingLogin').style.display='none';},1000);
						$('processingLogin').style.opacity=0;
						$('usrName').focus();
						$('password').value='';
						$('login').className = 'loginError';
						$('indexError').className = 'indexErrorAnimation';
						setTimeout(function(){$('login').className = 'login';$('indexError').className = 'indexError';},600);

						switch(rt)
						{
							case 'maintenance':
								$('indexError').innerHTML='ART is currently undergoing<br /> scheduled maintenance. Please stand by.';
							break;

							case 'invalid_login':
								$('indexError').innerHTML='Invalid user name or password.';
							break;

							case 'session_expired':
								$('indexError').innerHTML='Session expired.<br />Please log in again.';
							break;

							case 'not_registered':
								$('indexError').innerHTML='Your login has not been given access.<br />To request access <a href="mailto:john.marsh.external@airbus.com">click here</a>.';
							break;

							case 'no_ldap':
								$('indexError').innerHTML='Cannot connect to login server.<br />Please try again later.';
							break;

							case 'illegal_access':
								window.location='../index.php';
							break;

							case 'unknown':
							default:
								$('indexError').innerHTML='An unknown error as occurred.<br />The administrator has been notified.';
							break;
						}
					break;
				}
			break;
			case 'putInBody': //JFM 12_01_16
				fromIndex=true;
				$('loadbody').innerHTML=rt;
				$('pleaseWaitIndex').innerHTML = 'Loading Content...';
				bodyLoad();
			break;
			case 'updateA0Report': //JFM 08_06_16
				$('A0_'+rt).innerHTML = 'Done!';
			break;
                        case 'updateCsvReport':
                                $('csv_'+rt).innerHTML = 'Done!';
                        break;
			case 'pptxDownload':
                        
				reportWizardStepCalculate(1);
				reportWizardFileDownloadGlobal=rt;
				var sentence = '<br /><div onclick="window.location(\'output/'+reportWizardFileDownloadGlobal+'.pptx\');" style="background-color:#f47922; width:120px; height:50px; text-align:center; color:#FFFFFF; font-size:16px; cursor:pointer; margin-left:290px; margin-top:20px;">';
				sentence += '<div id="downloadButton" style="padding-top:15px;">Download &#9196;</div>';
				sentence += '</div>';
				$('box5').innerHTML+=sentence;
			break;
            case 'csvdownload':   
				reportWizardStepCalculate(1);
				reportWizardFileDownloadGlobal=rt;
				var sentence = '<br /><div onclick="window.location(\'output/'+reportWizardFileDownloadGlobal+'.xls\');" style="background-color:#f47922; width:120px; height:50px; text-align:center; color:#FFFFFF; font-size:16px; cursor:pointer; margin-left:290px; margin-top:20px;">';
				sentence += '<div id="downloadButton" style="padding-top:15px;">Download &#9196;</div>';
				sentence += '</div>';
				$('box5').innerHTML+=sentence;
			break;
            // Added for US#091 - To enable the download link for DR excel extract
            case 'exceldownload':
                reportWizardFileDownloadGlobal = rt;
                $('box5').innerHTML = '';
                var sentence = '<br /><p>Completed !!</p><a href="output/' + reportWizardFileDownloadGlobal + '.xls">Download DR Report</a>';
                $('box5').innerHTML += sentence;
                document.getElementById("box5").style.display = "block";
            break;
            // Added for US#091 - To enable the download link for Criteria excel extract
            case 'criteriaReport':
                reportWizardFileDownloadGlobal = rt;
                $('criteriaKpi').innerHTML = '';
                var sentence = '<br /><p>Completed !!</p><a href="output/' + reportWizardFileDownloadGlobal + '.xls">Download Criteria Report</a>';
                $('criteriaKpi').innerHTML += sentence;
                document.getElementById("criteriaKpi").style.display = "block";
            break;
            // Added for US#091 - To enable the download link for Actions excel extract
            case 'actionReport':
                reportWizardFileDownloadGlobal = rt;
                $('actionKpi').innerHTML = '';
                var sentence = '<br /><p>Completed !!</p><a href="output/' + reportWizardFileDownloadGlobal + '.xls">Download Action Report</a>';
                $('actionKpi').innerHTML += sentence;
                document.getElementById("actionKpi").style.display = "block";
            break;  
                
		}
		if(reloadSideElementNeeded==1){
			reloadSideElement();
		}
		if(disableAllFormElementsNeeded==1){
			disableAllFormElements();
		}
	}
/*
	US109-General Information not editable by supplier
	For showing alert to user
	Fixed By - Infosys Limited
	Version: V 4.5
*/
if (rt == 'showalert') {
	alert("Edit, create and delete access will not be applicable for external users");
	closeLastForm();
}
/* End for US109 */
	if(asyncMode==true) //JFM 12_01_16
	{
		if($('loadingMsgText')) $('loadingMsg').style.display='none';
		if($('loadingMsgText')) $('loadingMsgPercent').style.width='100%';
		if($('loadingMsgText')) $('loadingMsgText').style.opacity=0;
		//clearTimeout(cancelMe);
		//$('loadingMsgTextLong').style.display='none';
		setTimeout(function(){if($('loadingMsgText')) $('loadingMsgPercent').style.width='0%'; if($('loadingMsgText')) $('loadingMsgText').style.display='none';},400);
	}

}

/*
 * Modified for US #032 for passing the type of information
 * type : To define the general/specific permission in edit multiple user permission screen
 */
function ajaxRequest(url,reqCase,asyncMode,method,type) //JFM 13_12_13
{
	//alert(asyncMode + '!!!' + reqCase);


	if(asyncMode==true && reqCase != 'showFilter' && reqCase != 'newLogin' && reqCase != 'putInBody' && reqCase != 'headerMenu') //JFM 14_01_14
	{
		//JFM 12_01_16
		if($('loadingMsgText')) $('loadingMsg').style.display='block';
		if($('loadingMsgText')) $('loadingMsgText').style.display='block';
		if($('loadingMsgText')) $('loadingMsgText').style.opacity=1;
		//cancelMe = setTimeout(function() {$('loadingMsgTextLong').style.opacity=1; $('loadingMsgTextLong').style.display='block';}, 3000);
		// Added for #032 Bulk user upload (Suggested by ICT),For displaying the changes applied for general and specific permission section
                if(reqCase == 'bulkEdit' && type == 'generalInfo') {
                    document.getElementById('bulkUsersGenSpan').style.display = 'block';
                } else if(reqCase == 'bulkEdit' && type == 'specific') {
                    document.getElementById('bulkUsersSpecSpan').style.display = 'block';
                }
		// End of add for #032 Bulk user upload (Suggested by ICT)
		ajaxRequestExecute(url,reqCase,asyncMode,method);
	}
	else
	{
		switch(reqCase)
		{
			case 'checkOk':
			case 'openSideElement':
			case 'olsticky':
				//JFM 12_01_16
				asyncMode=true;
				$('loadingMsg').style.display='block';
				$('loadingMsgText').style.display='block';
				$('loadingMsgText').style.opacity=1;
				//cancelMe = setTimeout(function() {$('loadingMsgTextLong').style.opacity=1; $('loadingMsgTextLong').style.display='block';}, 3000);
				ajaxRequestExecute(url,reqCase,asyncMode,method);
			break;

			case 'newLogin':
			case 'putInBody':
				$('processingLogin').style.display='block';
				$('processingLogin').style.opacity=1;
				$('loadingContainer').innerHTML='<div class="loadingMsg" id="loadingMsg"></div><div class="loadingMsgTextNew" id="loadingMsgText"><div class="loadingMsgProgressBar" id="loadingMsgPercent"></div></div>';
				ajaxRequestExecute(url,reqCase,asyncMode,method);
			break;
                        case 'checkOkAll':
				asyncMode=true;
				$('loadingMsg').style.display='block';
				$('loadingMsgText').style.display='block';
				$('loadingMsgText').style.opacity=1;
				ajaxRequestExecute(url,reqCase,asyncMode,method);
			break;
			default:
				ajaxRequestExecute(url,reqCase,asyncMode,method);
			break;
		}
	}
}

function ajaxRequestExecute(url,reqCase,asyncMode,method) //JFM 13_12_13
{
	if(!exists(method)){
	method='GET';
	}
	ajaxR=(window.XMLHttpRequest)?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP");
	ajaxR.onreadystatechange=showContent;
	var d=new Date();
	rand=(Math.random()*99999)+'-'+d.getTime();
	urlConnector=(url.indexOf('?')==-1)?'?':'&';
	switch(method){
		case 'GET':
			//alert(url+urlConnector+'rand='+rand,asyncMode);
			ajaxR.open('GET',url+urlConnector+'rand='+rand,asyncMode);
			ajaxR.send(null);
		break;
		case 'POST':
			var postData=url.split('?');
			if(postData[1].charAt(0)=='&')postData[1]=postData[1].substring(1, postData[1].length);
			postData[1]=postData[1].replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g,'');
			//alert(postData[0]+'?rand='+rand);
			ajaxR.open('POST',postData[0]+'?rand='+rand,asyncMode);
			ajaxR.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
			ajaxR.send(postData[1]);
		break;
	}
	function showContent(){
		if(ajaxR.readyState==1) if($('loadingMsgPercent')) $('loadingMsgPercent').style.width='25%';
		if(ajaxR.readyState==2) if($('loadingMsgPercent')) $('loadingMsgPercent').style.width='50%';
		if(ajaxR.readyState==3) if($('loadingMsgPercent')) $('loadingMsgPercent').style.width='75%';
		if(ajaxR.readyState==4 && ajaxR.status==200) ajaxReqPr(ajaxR.responseText,reqCase,asyncMode);
	}
}

function checkAjaxResponse(rt,rq)
{ //JFM 15_09_15
	rtArr=rt.split('|||');
	if(rtArr[0]=='OK')
	{
		switch(rtArr[1])
		{
			case 'different_review_profile':
				alert('The selected CAs contain different review configurations.\n\nPlease, apply to all selected CAs the same configuration.');
			break;
			case 'error':
				alert('There has been an error while processing the request:\n\n'+rtArr[2]+'\n\nPlease, contact the administrator to solve the issue.');
			break;
			case 'no_review_found':
				alert('Incorrect parameter (Review Profile) provided by the tool. The operation has not been performed.');
			break;
			case 'no_rights':
				alert('You do not have enough rights to perform the operation.');
			break;
			default:
				return rtArr[1];
			break;
		}
	}
	else
	{
		if(exists($('debug_mode')) && $('debug_mode').value==1)
		{
			alert('There has been an error. The server answered:\n\n\n'+rt);
			$('ajaxTest').innerHTML=rt;
		}
		else
		{
			ajaxRequest('ajax/recordError.php?error='+rt.slice(0,400)+'&request='+rq,'recordError',true,'POST'); //JFM 15_09_15
			alert('There has been an error. A message has been sent to the administrator to solve the problem as soon as possible.\n'+rt);
			$('ajaxTest').innerHTML=rt;
		}
		return 'KO';
	}
}

/*
 * Function to make ajax request using POST method - Improvement 2(minor)
 * @param {String} url
 * @param {String} reqCase
 * @param {Boolean} asyncMode
 * @param {String} method
 * @param {Object} csvArray
 * @param {array} removeArray
 */
function ajaxRequestExecutePost(url,reqCase,asyncMode,method,csvObj,criterion_validity,removeArray)
{	
	ajaxR=(window.XMLHttpRequest)?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP");
	ajaxR.onreadystatechange=showContent;
	var d=new Date();
	rand=(Math.random()*99999)+'-'+d.getTime();
	
        if(method == 'POST') {       
            var postData=JSON.stringify(csvObj);
            ajaxR.open('POST',url+'?rand='+rand+'&remove='+removeArray,asyncMode);
            ajaxR.setRequestHeader('Content-Type','application/json');
            ajaxR.send(postData);
	    
            function showContent(){
		if(ajaxR.readyState==1) if($('loadingMsgPercent')) $('loadingMsgPercent').style.width='25%';
		if(ajaxR.readyState==2) if($('loadingMsgPercent')) $('loadingMsgPercent').style.width='50%';
		if(ajaxR.readyState==3) if($('loadingMsgPercent')) $('loadingMsgPercent').style.width='75%';
		if(ajaxR.readyState==4 && ajaxR.status==200) ajaxReqPr(ajaxR.responseText,reqCase,asyncMode);
            }
        }
        
        // To disable the 'Keep value in ART' button(s) when the 'Import value from ART' button is clicked
        for(var i=0; i<criterion_validity.length; i++) {
            document.getElementById(criterion_validity[i]).disabled = true;
            document.getElementById(criterion_validity[i]).style.color = "#808080";
        }
        document.getElementById("importCSV").style.color = "#808080";
        alert("Data has been uploaded successfully");        
}
