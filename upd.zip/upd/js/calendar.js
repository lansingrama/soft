function closeCalendar(){
	if(typeof divId !== 'undefined')
	{
		if($(divId)) //JFM 19_07_16
		{
			$(divId).style.display='none';
			$(divId).innerHTML='';
		}
	}
}
function getCal(calIdT,divIdT,dispIdT,hideIdT,MT,YT,lowIdT,onClkEvT,pastT,futT){
	closeCalendar();
	calId=calIdT;
	divId=divIdT;
	dispId=dispIdT;
	hideId=hideIdT;
	M=MT;
	Y=YT;
	lowId=lowIdT;
	onClkEv=onClkEvT;
	past=pastT;
	fut=futT;
	ajaxRequest('ajax/showCal.php','showCal',true);
}
function showCal(calId,divId,dispId,hideId,M,Y,lowId,onClkEv,past,fut){
	Actual_Month=parseInt(M,10);
	Actual_Year=parseInt(Y,10);
	if($(dispId+'D'))bdrColor=$(dispId+'D').style.borderColor;
	//if($(dispId+'CalDiv'))$(dispId+'CalDiv').innerHTML=$(divId).innerHTML;
	if($(dispId+'D') && onClkEv=='put'){
		$(dispId+'D').disabled=false;
		$(dispId+'D').style.borderColor=bdrColor;
		$(dispId+'M').disabled=false;
		$(dispId+'M').style.borderColor=bdrColor;
		$(dispId+'Y').disabled=false;
		$(dispId+'Y').style.borderColor=bdrColor;
	}
	if(hideId){
		hideIdA=hideId.split('|');
		hideIdAL=hideIdA.length;
		for(i=0;i<hideIdAL;i++){
			$(hideIdA[i]+'D').disabled=true;
			$(hideIdA[i]+'D').style.borderColor='#999999';
			$(hideIdA[i]+'M').disabled=true;
			$(hideIdA[i]+'M').style.borderColor='#999999';
			$(hideIdA[i]+'Y').disabled=true;
			$(hideIdA[i]+'Y').style.borderColor='#999999';
		}
	}
	var D=new Date();
	var Today=new Date();
	TD=undefined;
	D.setDate(1);
	D.setMonth(Actual_Month-1);
	D.setFullYear(Actual_Year);
	
	if(lowId)
	{
		maxDate=new Date();
		maxDate.setFullYear(1970);
		lowIdA=lowId.split('|');
		lowIdAL=lowIdA.length;
		for(i=0;i<lowIdAL;i++)
		{
			TD=new Date();
			TD.setDate(parseInt($(lowIdA[i]+'D').value,10));
			TD.setMonth(parseInt($(lowIdA[i]+'M').value-1,10));
			TD.setFullYear(parseInt($(lowIdA[i]+'Y').value,10));
			if(TD>maxDate)maxDate=TD;
		}
		limitDate=maxDate.getTime()+86400000;
	}
	$('Link_Prev_Month').ondblclick=$('Link_Prev_Month').onclick=(Actual_Month==1)?function(){showCal(calId,divId,dispId,hideId,12,Actual_Year-1,lowId,onClkEv);}:function(){showCal(calId,divId,dispId,hideId,Actual_Month-1,Y,lowId,onClkEv);};
	$('Link_Next_Month').ondblclick=$('Link_Next_Month').onclick=(Actual_Month==12)?function(){showCal(calId,divId,dispId,hideId,1,Actual_Year+1,lowId,onClkEv);}:function(){showCal(calId,divId,dispId,hideId,Actual_Month+1,Y,lowId,onClkEv);};
	$('Link_Prev_Year').ondblclick=$('Link_Prev_Year').onclick=function(){showCal(calId,divId,dispId,hideId,M,Actual_Year-1,lowId,onClkEv);};
	$('Link_Next_Year').ondblclick=$('Link_Next_Year').onclick=function(){showCal(calId,divId,dispId,hideId,M,Actual_Year+1,lowId,onClkEv);};


	$(divId).style.display='block';
	$(calId).style.display='block';
	
	//So this entire calender works on a grid based system. As there will always be 7 columns and less than 6 rows, the maximum number of items to displays is 42. (7*6)
	//This is why the for loop goes through to 42. The problem is then adding the calendar week is a complete pain as we now have 8 rows. However this hack
	//between ../ajax/showCal.php and this for loop stops anything bad from happening. 
	
	var Month=new Array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	var Days_In_Month=new Array(31,28,31,30,31,30,31,31,30,31,30,31);
	if(D.getFullYear()%4==0) Days_In_Month[1]=29;
	Short_Year=Actual_Year.toString();
	Main_Date.innerHTML=Month[D.getMonth()]+' '+Short_Year.substr(2,2);
	First_Day=D.getDay()-(D.getDate()-1)%7-1;
	if(First_Day<0)First_Day+=7;
	for(i=0;i<42;i++)
	{
		Month_Day=i+1;
		Month_Day='D'+Month_Day;
		//alert(Month_Day);
		if(!$(Month_Day))alert(Month_Day);
		MD=$(Month_Day);
		var Day_In_Calendar=i-First_Day+1;

		//JFM 13_05_16
		Calendar_Week='CW'+(i+2);
		if($(Calendar_Week))
		{
			if(i < 37 || (i>36 && $('D36').innerHTML!=''))
			{
				var calendarWeekCalculateDate=new Date();
				calendarWeekCalculateDate.setDate(D.getDate());
				calendarWeekCalculateDate.setMonth(D.getMonth());
				calendarWeekCalculateDate.setFullYear(D.getFullYear());
				
				$(Calendar_Week).innerHTML=getCalendarWeek(calendarWeekCalculateDate);
				$(Calendar_Week).style.borderLeft='1px solid #999999';
			}
			else
			{
				$(Calendar_Week).innerHTML='';
				$(Calendar_Week).style.borderLeft='';
			}
		}

		if(i<First_Day)MD.innerHTML='';
		else if(i<Days_In_Month[D.getMonth()]+First_Day)
		{
			MD.innerHTML=Day_In_Calendar;
			if((i-5)%7!=0 && (i-6)%7!=0)
			{
				D.setDate(Day_In_Calendar);
				if((past==false && D<Today)||(typeof(TD)!='undefined' && D<limitDate)||(fut==false && D>Today))
				{
					MD.style.color='#999999';
					MD.onclick=function(){return false;}
				}
				else
				{
					MD.style.color='#000000';
					MD.onclick=(onClkEv=='put')?function(){Insert_Date(dispId,this.innerHTML,Actual_Month,Actual_Year,hideId,calId,divId);}:function(){window.location=dispId+Actual_Year+'-'+((Actual_Month<=9)?'0'+Actual_Month:Actual_Month)+'-'+((this.innerHTML<=9)?'0'+this.innerHTML:this.innerHTML);};
				}
			}
			MD.style.fontWeight=(D.getFullYear()==Today.getFullYear() && D.getMonth()==Today.getMonth() && Day_In_Calendar==Today.getDate())?'bold':'100';
		}
		else
		{
			MD.innerHTML='';
		}
	}
}
function Insert_Date(Selected_Date,Actual_Day,Actual_Month,Actual_Year,hideId,calId,divId){
	if(hideId)
	{
		hideIdA=hideId.split('|');
		hideIdAL=hideIdA.length;
		for(i=0;i<hideIdAL;i++)
		{
			$(hideIdA[i]+'D').disabled=false;
			$(hideIdA[i]+'D').style.borderColor=bdrColor;
			$(hideIdA[i]+'M').disabled=false;
			$(hideIdA[i]+'M').style.borderColor=bdrColor;
			$(hideIdA[i]+'Y').disabled=false;
			$(hideIdA[i]+'Y').style.borderColor=bdrColor;
		}
	}
	if($(Selected_Date+'D'))
	{
		$(Selected_Date+'D').value=(Actual_Day<10)?'0'+Actual_Day:Actual_Day;
		$(Selected_Date+'M').value=(Actual_Month<10)?'0'+Actual_Month:Actual_Month;
		$(Selected_Date+'Y').value=Actual_Year;
	}
	else if($(Selected_Date))
	{
		complDate=Actual_Year+'-';
		complDate+=(Actual_Month<10)?'0'+Actual_Month:Actual_Month;
		complDate+='-';
		complDate+=(Actual_Day<10)?'0'+Actual_Day:Actual_Day;
		$(Selected_Date).value=complDate;
	}
	$(divId).style.display='none';
	$(divId).innerHTML='';
}

function getCalendarWeek(date)
{
	date.setHours(0,0,0,0);
	date.setDate(date.getDate()+3 - (date.getDay() + 6) % 7);
	var week1 = new Date(date.getFullYear(),0,4);

	return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
}