<?php
require_once('support/header.php');
require_once('../support.php');
require_once('../common/php/common.php');
//session_start();
//$SESSION = array();
function killSession()
{	
	session_start();
	destroySession();
	session_unset();
	session_destroy();
	setcookie(session_name(),'',0,'/');
	session_regenerate_id(true);
}

$GET=cleanArray($_GET);
$ssoSuccess = true;
$alreadyLoggedIn=false;
//if(isset($SESSION['tool_id']) || isset($SESSION['user']['user_id']) ){
if($SESSION['tool_id']=='' || $SESSION['user']['user_id']=='')
{	//echo "<script> alert('in laert'); </script>";
	session_start();
	$sessionFilePath=dirname(__FILE__).'/session/'.session_id().'.session';

	//Already logged in, go to home via indexIsLoaded in body.
	if(file_exists($sessionFilePath))
	{
		$SESSION=unserialize(file_get_contents($sessionFilePath));
		$alreadyLoggedIn=true;
	}
	else
	{
		//If not logged out because of error, try single sign on.
		if(empty($GET))
		{//echo "<script> alert('in laert 1'); </script>";
			require_once('security/sso.php'); //JFM 09_04_14
		}

		//If SSO did not work, kill any current session to prevent session hijacking
		if(!$ssoSuccess)
		{
			killSession();
		}
		//Otherwise if it did work and a session file was created, log the user in.
		else if(file_exists($sessionFilePath))
		{       
			$SESSION=unserialize(file_get_contents($sessionFilePath));
		}
		//Otherwise if something went wrong during the SSO process, kill any stored session and have them login manually.
		else
		{
			killSession();
		}
	}
}
//}

$errorMessage=array('invalid_login'=>'Invalid user name or password.',
					'session_expired'=>'Session expired.<br />Please log in again.',
					'maintenance'=>'ART is currently undergoing<br />maintenance. Please stand by.',
					'not_registered'=>'Your login has not been given access.<br />For access contact Airbus Service Desk.',
					'no_ldap'=>'Cannot connect to login server.<br />Please try again later.',
					'unknown'=>'An unknown error as occurred.<br />The administrator has been notified.');

$maintenance=false;
$announce=false;
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><?php
?><html><?php
?><head><?php
	?><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><?php
	?><meta http-equiv="X-UA-Compatible" content="IE=8,11"><?php //JFM 12_01_16
	?><link rel="stylesheet" href="main.css" media="screen" type="text/css"><?php
	/*?><link rel="icon" href="../common/img/favicon.ico" type="image/x-icon"/><?php
	?><link rel="shortcut icon" href="../common/img/favicon.ico" type="image/x-icon"/><?php
	/*?><link title="ART RSS" href="drt.xml" rel="alternate" type="application/rss+xml"/><?php*/
	?><title>Airbus | Review Tool</title><?php
	?><script language="javascript" type="text/javascript" src="js/excanvas.js"></script><?php //JFM 14_01_14
	?><script language="javascript" type="text/javascript" src="js/overlib.js"><!-- overLIB (c) Erik Bosrup --></script><?php
	?><script language="javascript" type="text/javascript" src="js/canvas2svg.js"></script><?php //JFM 12_01_16
	?><script language="javascript" type="text/javascript" src="../common/js/common.js"></script><?php
	?><script language="javascript" type="text/javascript" src="js/home.js"></script><?php
	?><script language="javascript" type="text/javascript" src="js/ajax.js"></script><?php
	?><script language="javascript" type="text/javascript" src="js/calendar.js"></script><?php
	?><script language="javascript" type="text/javascript" src="js/validation.js"></script><?php
	?><script language="javascript" type="text/javascript" src="js/suggest.js"></script><?php
	?><script language="javascript" type="text/javascript" src="js/login.js"></script><?php
	?><script type="text/javascript">preloadImages();</script><?php
flush();

//$browser=getBrowser();

?><div id="loadbody" style="display:none;"></div><?php 
?><div id="loadBackground" class="loadBackground"></div><?php 

$blockingTime=getBlockingTime();

if($blockingTime==0)
{
	?><div><div id="loadingContainer"><?php
		?><div class="loadingMsg" id="loadingMsg"></div><?php //JFM 13_12_13
		?><div class="loadingMsgText" id="loadingMsgText" style="background-color:#6b92aa;"><?php
			?><img src="../common/img/logo_white.png"><?php
			?><img style="padding-top:25px;" src="../common/img/loading.gif"><?php
			?><div id="pleaseWaitIndex" style="position:absolute; color:#FFFFFF; font-size:16px; bottom:10px; width:100%;"><?php
				?>Performing daily tasks.<br />This will take ~5 minutes.<br />Please Wait...<br /><?php
			?></div><?php
			?><div class="loadingMsgProgressBar" id="loadingMsgPercent"></div><?php
		?></div><?php //JFM 12_01_16
	?></div></div><?php
	
	?><div id="formContainer"></div><?php
	?><body onLoad="indexIsLoaded(<?=$alreadyLoggedIn?>);"><?php
	?><div id="bg" class="bg"></div><?php

/*	?><div class="fullscreen-bg"><?php
		?><video loop muted autoplay poster="img/videoframe.jpg" class="fullscreen-bg__video"><?php
			?><source src="../common/img/video.mp4" type="video/mp4"><?php
		?></video><?php
	?></div><?php*/

	?><div id="homeContainer" style="position:fixed; top:0; left:0;"></div><?php

	?><div id="processingLogin" class="processingLogin" style="background-color:#6b92aa;"><?php
		?><img src="../common/img/logo_white.png"><?php
		?><img style="padding-top:25px;" src="../common/img/loading.gif"><?php
		?><div id="nameIndex" style="position:absolute; color:#FFFFFF; font-size:16px; bottom:50px; width:100%;"><?php
			if($SESSION['tool_id']!='' || $SESSION['user']['user_id']!='')
			{
				?><b>Welcome <?=utf8_encode($SESSION['user']['name'])?></b><?php
			}
		?></div><?php
		?><div id="pleaseWaitIndex" style="position:absolute; color:#FFFFFF; font-size:16px; bottom:10px; width:100%;"><?php
			?>Please wait...<?php
		?></div><?php
	?></div><?php

	?><div id="announcement" class="help" style="display:<?=($announce)?'block':'none'?>; height:auto; z-index:0; margin-top: -127px;"><?php
		?><table style="width:100%; text-align:left;" align="center" cellspacing="0" cellpadding="5"><?php
			?><tr><td bgcolor="#ef343f" style="font-weight:bold; height:20px;">Announcement - 26th November 2015</td></tr><?php
			?><tr><?php
				?><td><?php
					?><b>ART V4.5 Update.</b><?php
					?><br /><br /><?php
					?>ART will be <b>offline</b> between <b>17:00 - 19:00 GMT (18:00 - 20:00 CET)</b> while it is updated to V4.5.<?php
					?><br /><br /><?php
					?>This update will bring the following improvements:<?php
					?><ul style="padding-left:15px;"><?php
						?><li>Updated the look of the Main Table & Review Checklist Definition window.</li><?php
						?><li>Improved the way emails are sent to users.</li><?php
						?><li>Implemented a new "Review Statistics" PowerPoint.</li><?php
						?><li>Added the validation menu to the My Task tab.</li><?php
						?><li>Added Main Table Interactive tutorial.</li><?php
						?><li>Improved the display of the current interactive tutorial.</li><?php
						?><li>General bug fixes and performance improvements.</li><?php
					?></ul><?php
				?></td><?php
			?></tr><?php
		?></table><?php
	?></div><?php

	?><div id="help" class="help" style="display:none;"><?php
		?><table style="width:100%; text-align:left;" align="center" cellspacing="0" cellpadding="5"><?php
			?><tr><td bgcolor="#f47922" style="font-weight:bold; height:20px;">Login Help</td></tr><?php
			?><tr><?php
				?><td><?php
					?><ul style="padding:0px; margin:12px; margin-top:0px;"><?php
						?><li>User logins are managed by the Airbus LDAP system.</li><?php
						?><li>Please login using your <b>Airbus Windows Username & Password.</b></li><?php
						?><li>If you are having difficulty logging in, please contact a member of the ART team by mailing Airbus Service Desk.</li><?php
					?></ul><?php
				?></td><?php
			?></tr><?php
		?></table><?php
	?></div><?php

	?><div id="login" class="login" style="background-color:#6b92aa"><?php
		?><div id="loginLogo"><img src="../common/img/logo_white.png"></div><?php

		?><div id="loginContainerForm"><?php
			?><div style="height:20px;"></div><?php

			if(!$ssoSuccess)
			{
			/*	?><form name="usrInput" enctype="multipart/form-data" id="usrInput" method="post" action="javascript:sendAjaxForm('usrInput','security/accessControl_force_login.php','newLogin','','POST',true);" style="margin:0px;"><?php
					if(!$alreadyLoggedIn)
					{
						?><table align="center" cellspacing="0" cellpadding="0"><?php
							?><tr><?php
								?><td bgcolor="#f47922" style="width:40px; height:40px; text-align:center"><img src="../common/img/username.png"></td><?php
								?><td width="10px" bgcolor="#FFFFFF"></td><?php
								?><td bgcolor="#FFFFFF" style="height:40px;"><input class="inactive" style="font-size:16px; border:0px;" id="usrName" type="text" name="User_Name" onBlur="txtBlr(this,'Username');" onFocus="txtBlr(this,'Username');" onkeydown="txtOF(this,'Username');" value="Username"></td><?php
							?></tr><?php
							?><tr><td style="height:15px;"></td></tr><?php
							?><tr><?php
								?><td bgcolor="#f47922" style="width:40px; height:40px; text-align:center"><img src="../common/img/password.png"></td><?php
								?><td width="10px" bgcolor="#FFFFFF"></td><?php
								?><td bgcolor="#FFFFFF" style="height:40px;"><input class="inactive" style="font-size:16px; border:0px;" id="password" type="password" name="Password" onBlur="txtBlr(this,'Password');" onFocus="txtOF(this,'Password');" value="Password"></td><?php
							?></tr><?php
							?><tr><td colspan="3" style="height:25px;"><hr noshade style="width:150px; border-color:#FFFFFF;" /></td></tr><?php
						?></table><?php
						?><table align="center" cellspacing="0" cellpadding="0"><?php
							?><tr><?php
								?><td bgcolor="#f47922" style="width:105px; height:40px; text-align:center; color:#FFFFFF; font-size:16px; cursor:pointer;" onclick="$('help').style.display='block'; $('announcement').style.display='none';">Help</td><?php
								?><td width="10px" bgcolor="#6f95ab"></td><?php
								?><td bgcolor="#f47922" style="width:105px; height:40px; text-align:center;"><input style="color:#FFFFFF; font-size:16px; background-color: transparent; border:0px solid black; cursor:pointer;" type="submit"name="Send_Password"value="Login &#9658;"></td><?php
							?></tr><?php
							?><tr><td style="height:10px;"></td></tr><?php
							?><tr><td colspan="3" style="color:#FFFFFF; cursor:pointer;" onclick="window.open('more_info.html');">New to ART? Click here.</td></tr><?php
						?></table><?php
					}
				?></form><?php*/
			}
			else
			{
				?><table align="center" cellspacing="0" cellpadding="0"><?php
					?><tr><?php
						?><td style="height:40px; font-size:20px; color:white;">Single Sign-On Success!</td><?php
					?></tr><?php
					?><tr><td colspan="3" style="height:25px;"><hr noshade style="width:150px; border-color:#FFFFFF;" /></td></tr><?php
				?></table><?php
				?><table align="center" cellspacing="0" cellpadding="0"><?php
					?><tr><?php
						?><?php
                                            /*    ?><form name="usrInput" enctype="multipart/form-data" id="usrInput" method="post" action="javascript:sendAjaxForm('usrInput','security/accessControl_force_login.php','newLogin','','POST',true);" style="margin:0px;"><?php*/
                                                        ?><td bgcolor="#f47922" style="width:105px; height:40px; text-align:center; color:#FFFFFF; font-size:16px; border:0px solid black; cursor:pointer;" onclick="window.location = 'index.php';">Enter &#9658;</td><?php
                                            /*    ?><td bgcolor="#f47922" style="width:105px; height:40px; text-align:center; color:#FFFFFF; font-size:16px; border:0px solid black; cursor:pointer;"> <input style="color:#FFFFFF; font-size:16px; background-color: transparent; border:0px solid black; cursor:pointer;" type="submit"name="Send_Password"value="Enter &#9658;"> </td><?php*/
					?></tr><?php
					?><tr><td style="height:10px;"></td></tr><?php
					?><tr><td colspan="3" style="color:#FFFFFF; cursor:pointer;" onclick="window.open('more_info.html');">New to ART? Click here.</td></tr><?php
				?></table><?php
			}

		?></div><?php

	?></div><?php

	?><div id="indexError" class="indexError" style="<?=($GET['error']!='')?'margin-top:132px;':''?>"><?=$errorMessage[$GET['error']]?></div><?php	
	

	?><iframe id="garbageCollector"name="garbageCollector"width="1"height="1"style="visibility:hidden"></iframe><?php
}
else
{
	$minutes=str_pad(floor($blockingTime/60),2,0,STR_PAD_LEFT);
	$seconds=str_pad($blockingTime%60,2,0,STR_PAD_LEFT);
	?><body onLoad="setBlockingTime(<?=$blockingTime?>);"><?php
	?><div class="noMainTableShown"style="color:#FF0000;padding-top:100px;"><?php
		?>Too many login attempts!<br><br><?php
		?><span style="font-size:26px;">As your have entered your password incorrectly too many times, you have be temporarily prevented from doing so again.<br /><br />Please Wait <span id="blockingTime"><?=$minutes?>:<?=$seconds?></span> to try again.</span><?php
	?></div><?php
}

/*?><div class="startLabel">Airbus Reviews</div><?php*/ //JFM 03_06_14
?></div><?php
?></body><?php
?></html>