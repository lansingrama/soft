<?php
function addLogName($userId,$userName,$html){
	return($html==1)?'<span class="logLink"onClick="openForm(\'userManagement\',\'\',false,\'GET\');openSideElement(\''.$userId.'\',\'usr\');">'.$userName.'</span>':$userName;
}
function caLocation($caLocation,$caId,$html=1){
	$caLocationTxt='CA '.$caLocation[$caId]['ca'].' ('.$caLocation[$caId]['program'].' - '.$caLocation[$caId]['coe'].' - '.$caLocation[$caId]['perimeter'].')';
	if($html==1){
		return '<span class="logLink"onClick="openForm(\'ca\',\'ca='.$caId.'\',false,\'GET\');">'.$caLocationTxt.'</span>';
	}else return $caLocationTxt;
}
function retrieveLogData($user,$source,$applicability,&$data,$maxResults,$SESSION,$html=1){
	$_a_=$SESSION['user_action'];
	$_o_=$SESSION['object'];
	$_t_=$SESSION['object_table'];
	$status=array('Red','Amber','Green','Blue'); //JFM 27_03_14
	
	$generalPermission=array(	$_o_['c_tool_general']							=>'this Tool',
								$_o_['c_program_general']						=>'all Programs in this tool',
								$_o_['c_coe_general']							=>'all CoEs in this tool',
								$_o_['c_perimeter_general']						=>'all Perimeters in this tool',
								$_o_['c_msn_general']							=>'all MSNs in this tool',
								$_o_['c_ca_general']							=>'all CAs in this tool',
								$_o_['dr_review_profile_general']				=>'all Review Profiles in this tool',
								$_o_['dr_responsible_configuration_general']	=>'all Configuration about Responsible People in this tool',
								$_o_['dr_log_general']							=>'all Logs in this tool',
								$_o_['c_user_general']							=>'all Users in this tool');
	
	$logCondition=array();
	if($source!='' && $applicability!=''){
		$logCondition[]='o.source="'.$_t_[$source].'" AND l.applicability="'.$applicability.'"';
	}
	if($user!=''){
		$logCondition[]='l.user="'.$user.'"';
	}
	
	if($logCondition[0]!=''){
		$logWhereQry='WHERE '.implode(' AND ',$logCondition);
	}
	
	$limitQry=(is_array($data) && $maxResults!='')?'LIMIT '.$data['displayed_results'].','.$maxResults:'';

	$log=SqlLi('SELECT l.log_date,l.user,l.object AS object_id,l.action,l.applicability,l.old_value,l.new_value
				FROM dr_log AS l
				LEFT JOIN c_object AS o ON o.object_id = l.object
				'.$logWhereQry.'
				ORDER BY log_id DESC
				'.$limitQry);
	
	$objectDetails=SqlAsLi('SELECT object_id,object,source,object_description FROM c_object','object_id');
	
	foreach($log as $k=>$v){
		$o=$objectDetails[$v['object_id']];
		$log[$k]['object']=$o['object'];
		$log[$k]['source']=$o['source'];
		$log[$k]['object_description']=$o['object_description'];
		$log[$k]['user_name']=$SESSION['user_list'][$v['user']];
	}
	foreach($log as $l){
		switch($l['source']){
			case $_t_['c_ca']:
			case $_t_['c_perimeter']:
			case $_t_['dr_ca_status']:
				$caLocationId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['c_permission']:
				$cPermissionId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['dr_review']:
				$drReviewId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['c_cawp']:
				if($log['object']==$_o_['cawp_disable']){
					$cawpId[$l['applicability']]=$l['applicability'];
				}
			break;
			case $_t_['dr_criteria_status']:
				$drCriteriaStatusId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['dr_a0_report']:
				$a0ReportId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['dr_action']:
				$drActionId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['dr_rid']:
				$drRidId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['dr_risk']: //JFM 08_06_16
				$drRiskId[$l['applicability']]=$l['applicability'];
			break;
		}
	}
	
	if(is_array($cawpId)){
		$caFromCawp=SqlAsLi('SELECT cawp_id,ca,msn FROM c_cawp WHERE cawp_id IN ('.implode(',',$cawpId).')','cawp_id');
		if(is_array($caFromCawp)){
			foreach($caFromCawp as &$c){
				$caLocationId[$c['ca']]=$c['ca'];
			}
		}
	}
	
	if(is_array($caLocationId)){
		$caLocation=SqlAsLi('SELECT ca.ca_id,ca.ca,prg.program,coe.coe,prm.perimeter
								FROM c_ca AS ca
									INNER JOIN c_program	AS prg ON ca.program=prg.program_id
									INNER JOIN c_coe		AS coe ON ca.coe=coe.coe_id
									INNER JOIN c_perimeter	AS prm ON ca.perimeter=prm.perimeter_id
								WHERE ca.ca_id IN('.implode(',',$caLocationId).')','ca_id');
	}
	if(is_array($cPermissionId)){
		$cPermission=SqlAsLi('SELECT p.permission_id,p.object,p.applicability,
										o.source,o.object_description,
										a.user_action_id,a.user_action,
										u.user_id,CONCAT(u.name," ",u.surname) AS user_name
									FROM c_permission 				AS p
										INNER JOIN c_object			AS o ON p.object=o.object_id
										INNER JOIN c_user_action	AS a ON p.action=a.user_action_id
										INNER JOIN c_user			AS u ON p.user=u.user_id
								WHERE p.permission_id IN("'.implode('","',$cPermissionId).'")
								','permission_id');
		if(is_array($cPermission)){
			foreach($cPermission as $p){
				switch($p['object']){
					case $_o_['program_id']:
						$permissionProgramId[$p['applicability']]=$p['applicability'];
					break;
					case $_o_['coe_id']:
						$permissionCoeId[$p['applicability']]=$p['applicability'];
					break;
					case $_o_['perimeter_id']:
						$permissionPerimeterId[$p['applicability']]=$p['applicability'];
					break;
					case $_o_['review_profile_id']:
						$permissionReviewProfileId[$p['applicability']]=$p['applicability'];
					break;
				}
			}
		}
		if(is_array($permissionProgramId)){
			$permissionProgram=SqlAsArr('SELECT program_id,program FROM c_program WHERE program_id IN('.implode(',',$permissionProgramId).')','program_id','program');
		}
		if(is_array($permissionCoeId)){
			$permissionCoe=SqlAsArr('SELECT coe_id,coe FROM c_coe WHERE coe_id IN('.implode(',',$permissionCoeId).')','coe_id','coe');
		}
		if(is_array($permissionPerimeterId)){
			$permissionPerimeter=SqlAsArr('SELECT perimeter_id,perimeter FROM c_perimeter WHERE perimeter_id IN('.implode(',',$permissionPerimeterId).')','perimeter_id','perimeter');
		}
		if(is_array($permissionReviewProfileId)){
			$permissionReviewProfile=SqlAsLi('SELECT r.review_profile_id,p.program,c.coe,t.review_type
												FROM dr_review_profile			AS r
													INNER JOIN c_program		AS p ON r.program=p.program_id
													INNER JOIN c_coe			AS c ON r.coe=c.coe_id
													INNER JOIN dr_review_type	AS t ON r.review_type=t.review_type_id
												WHERE review_profile_id IN('.implode(',',$permissionReviewProfileId).')','review_profile_id');
		}
	}
	if(is_array($drReviewId))
	{
								
		$drReview=SqlAsLi('SELECT DISTINCT r.review_id,
											c.ca_id,c.ca,
											m.msn_id,m.msn,
											r.review_profile,
											rt.review_type,
											pro.program_id, pro.program,
											coe.coe_id, coe.coe
								FROM dr_review AS r
									INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
									INNER JOIN c_ca AS c ON ra.ca=c.ca_id
									INNER JOIN c_msn AS m ON r.msn=m.msn_id
									INNER JOIN c_program as pro ON pro.program_id=m.program
									INNER JOIN c_coe AS coe ON coe.coe_id=c.coe
									INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
									INNER JOIN dr_review_type AS rt ON rp.review_type=rt.review_type_id
								WHERE r.review_id IN("'.implode('","',$drReviewId).'")
								','review_id');
	}
	if(is_array($drCriteriaStatusId))
	{				
		$drCriteriaStatus=SqlAsLi('SELECT DISTINCT s.criteria_status,
													pro.program_id, pro.program,
													coe.coe_id, coe.coe,
													msn.msn_id, msn.msn,
													ca.ca,
													rt.review_type,
													rch.criterion_user_id,
													rch.criterion,
													s.criteria_status_id
									FROM c_ca AS ca
										INNER JOIN dr_criteria_status AS s ON ca.ca_id=s.ca
										INNER JOIN dr_review_configuration AS c ON s.review_criteria=c.criterion
										INNER JOIN dr_review_criterion_history AS rch ON c.criterion=rch.criterion
										INNER JOIN dr_review AS g ON c.review=g.review_id
										INNER JOIN c_msn AS msn ON msn.msn_id=s.msn
										INNER JOIN c_program AS pro ON pro.program_id=msn.program
										INNER JOIN c_coe AS coe ON coe.coe_id=ca.coe
										INNER JOIN dr_review_profile AS rp ON g.review_profile=rp.review_profile_id
										INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
									WHERE s.criteria_status_id IN("'.implode('","',$drCriteriaStatusId).'")','criteria_status_id');
	}
	if(is_array($a0ReportId))
	{				
		$a0Report=SqlAsLi('SELECT DISTINCT s.a0_report_id,
											pro.program_id, pro.program,
											coe.coe_id, coe.coe,
											msn.msn_id, msn.msn,
											ca.ca,
											rt.review_type
									FROM c_ca AS ca
										INNER JOIN dr_a0_report AS s ON ca.ca_id=s.ca
										INNER JOIN c_msn AS msn ON msn.msn_id=s.msn
										INNER JOIN c_program AS pro ON pro.program_id=msn.program
										INNER JOIN c_coe AS coe ON coe.coe_id=ca.coe
										INNER JOIN dr_review_profile AS rp ON s.review_profile=rp.review_profile_id
										INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
									WHERE s.a0_report_id IN("'.implode('","',$a0ReportId).'")','a0_report_id');
	}
	if(is_array($drActionId))
	{	
		$drAction=SqlAsLi('SELECT DISTINCT act.action_id, act.action_code
									FROM dr_action AS act
									WHERE act.action_id IN("'.implode('","',$drActionId).'")','action_id');
	}
	if(is_array($drRidId))
	{	
		$drRid=SqlAsLi('SELECT DISTINCT rid.rid_id, rid.rid_code
									FROM dr_rid AS rid
									WHERE rid.rid_id IN("'.implode('","',$drRidId).'")','rid_id');
	}

	if(is_array($drRiskId)) //JFM 08_06_16
	{	
		$drRisk=SqlAsLi('SELECT DISTINCT rsk.risk_id, rsk.risk_code
									FROM dr_risk AS rsk
									WHERE rsk.risk_id IN("'.implode('","',$drRiskId).'")','risk_id');
	}
	
	$i=0;
	foreach($log as $l){
		$l=utf8enc($l,1);
		$logTxt[$i]['date']=$l['log_date'];
		$event='';
		$event.=addLogName($l['user'],$l['user_name'],$html).' ';
		switch($l['source']){
			case $_t_['c_cawp']:
				switch ($l['object']){
					case 'cawp_disabled':
						$event.=($l['new_value']==1)?' enabled ':' disabled';
						$event.=' the ';
						$displayLink=($caFromCawp[$l['applicability']]['msn']==getFilter('msn','filter',0,$SESSION))?1:0;
						$event.=caLocation($caLocation,$caFromCawp[$l['applicability']]['ca'],$displayLink);
					break;
				}
			break;
			case $_t_['c_tool']:
				$event.='logged into the tool';
			break;
			case $_t_['c_permission']:
					$event.=($l['new_value']==1)?' granted ':' denied ';
					$event.=addLogName($cPermission[$l['applicability']]['user_id'],$cPermission[$l['applicability']]['user_name'],$html);
					$event.=($cPermission[$l['applicability']]['user_action_id']==$_a_['superadmin'])?' the Super Administrator right':' the right to '.$cPermission[$l['applicability']]['user_action'];
					$event.=' ';
				if($generalPermission[$cPermission[$l['applicability']]['object']]!=''){
					$event.=$generalPermission[$cPermission[$l['applicability']]['object']];
				}else{
					switch($cPermission[$l['applicability']]['object']){
						case $_o_['program_id']:
							$event.='the elements within the Program '.$permissionProgram[$permissionProgramId[$cPermission[$l['applicability']]['applicability']]];
						break;
						case $_o_['coe_id']:
							$event.='the elements within the CoE '.$permissionCoe[$permissionCoeId[$cPermission[$l['applicability']]['applicability']]];
						break;
						case $_o_['perimeter_id']:
							$event.='the elements within the Perimeter '.$permissionPerimeter[$permissionPerimeterId[$cPermission[$l['applicability']]['applicability']]];
						break;
						case $_o_['review_profile_id']:
							$event.='the '.$permissionReviewProfile[$cPermission[$l['applicability']]['applicability']]['review_type'].' Review of '.
								$permissionReviewProfile[$cPermission[$l['applicability']]['applicability']]['program']
								.' / '.$permissionReviewProfile[$cPermission[$l['applicability']]['applicability']]['coe'];
						break;
					}
				}
			break;
			case $_t_['c_ca']:
			case $_t_['c_perimeter']:
			case $_t_['c_wp']:
			case $_t_['dr_action']:
			case $_t_['dr_ca_status']:
			case $_t_['dr_criteria_status']:
			case $_t_['dr_review']:
			case $_t_['dr_rid']:
			case $_t_['dr_risk']: //JFM 08_06_16
				$event.='modified the '.$l['object_description'].' of the ';
				switch($l['source'])
				{
					case $_t_['c_ca']:
					case $_t_['c_perimeter']:
					case $_t_['dr_ca_status']:
						$event.=caLocation($caLocation,$l['applicability'],1);
					break;
					case $_t_['dr_review']:
						//$reviewTxt=' '.$drReview[$l['applicability']]['review_type'].' Review for MSN '.$drReview[$l['applicability']]['msn'].' and CA '.$drReview[$l['applicability']]['ca'];
						$reviewTxt=$drReview[$l['applicability']]['program'].' - '.$drReview[$l['applicability']]['coe'].' - '.$drReview[$l['applicability']]['msn'].' - '.$drReview[$l['applicability']]['ca'].' - '.$drReview[$l['applicability']]['review_type'];
						$event.=($html==1)?'<span class="logLink" onClick="changeDropDownWhenGraphOptionSelected('.$drReview[$l['applicability']]['coe_id'].','.$drReview[$l['applicability']]['msn_id'].','.$drReview[$l['applicability']]['program_id'].',\''.$drReview[$l['applicability']]['ca'].'\');">'.$reviewTxt.'</span>':$reviewTxt;
					break;
					case $_t_['dr_criteria_status']:
						$reviewTxt=$drCriteriaStatus[$l['applicability']]['program'].' - '.$drCriteriaStatus[$l['applicability']]['coe'].' - '.$drCriteriaStatus[$l['applicability']]['msn'].' - '.$drCriteriaStatus[$l['applicability']]['ca'].' - '.$drCriteriaStatus[$l['applicability']]['review_type'].' - '.$drCriteriaStatus[$l['applicability']]['criterion_user_id'].' (actual id '.$drCriteriaStatus[$l['applicability']]['criterion'].') ';
						$event.=($html==1)?'<span class="logLink" onClick="changeDropDownWhenGraphOptionSelected('.$drCriteriaStatus[$l['applicability']]['coe_id'].','.$drCriteriaStatus[$l['applicability']]['msn_id'].','.$drCriteriaStatus[$l['applicability']]['program_id'].',\''.$drCriteriaStatus[$l['applicability']]['ca'].'\');">'.$reviewTxt.'</span>':$reviewTxt;
					break;
					case $_t_['dr_action']:
						$reviewTxt=$drAction[$l['applicability']]['action_code'];
						$event.=($html==1)?'<span class="logLink" onClick="">'.$reviewTxt.'</span>':$reviewTxt;
					break;
					case $_t_['dr_rid']:
						$reviewTxt=$drRid[$l['applicability']]['rid_code'];
						$event.=($html==1)?'<span class="logLink" onClick="">'.$reviewTxt.'</span>':$reviewTxt;
					break;
					case $_t_['dr_risk']:
						$reviewTxt=$drRisk[$l['applicability']]['risk_code'];
						$event.=($html==1)?'<span class="logLink" onClick="">'.$reviewTxt.'</span>':$reviewTxt;
					break;
				}
				if($l['old_value']!=$l['new_value'])
				{
					$event.=' <b>from</b>';
					switch($l['object_id'])
					{
						case $_o_['review_status']:
						case $_o_['action_status']:
						case $_o_['rid_status']:
						case $_o_['risk_status']: //JFM 08_06_16
						case $_o_['criteria_status']:
							$event.=' '.$status[$l['old_value']].' <b>to</b> '.$status[$l['new_value']];
						break;
						case $_o_['action_holder']:
						case $_o_['action_validator']:
						case $_o_['risk_holder']: //JFM 08_06_16
							if($l['old_value']) $userOld=SqlQ('SELECT CONCAT(name, " ", surname) AS fullname FROM c_user WHERE user_id='.$l['old_value']);
							if($l['new_value']) $userNew=SqlQ('SELECT CONCAT(name, " ", surname) AS fullname FROM c_user WHERE user_id='.$l['new_value']);
							$event.=' '.$userOld['fullname'].' ('.$l['old_value'].') <b>to</b> '.$userNew['fullname'].' ('.$l['new_value'].')';
						break;
						default:
							$oldValue=($l['old_value'] && $l['old_value']!='0000-00-00')?$l['old_value']:'nothing';
							$newValue=($l['new_value'] && $l['new_value']!='0000-00-00')?$l['new_value']:'nothing';
							$event.=' '.$oldValue.' <b>to</b> '.$newValue;
					}
				}
			break;

			case $_t_['dr_a0_report']:
				if($_a_['create']==$l['action']) $event.='generated a Review report for ';
				else if($_a_['upload']==$l['action']) $event.='uploaded a Review report for ';
				$reviewTxt=$a0Report[$l['applicability']]['program'].' - '.$a0Report[$l['applicability']]['coe'].' - '.$a0Report[$l['applicability']]['msn'].' - '.$a0Report[$l['applicability']]['ca'].' - '.$a0Report[$l['applicability']]['review_type'];
				$event.=($html==1)?'<span class="logLink" onClick="changeDropDownWhenGraphOptionSelected('.$a0Report[$l['applicability']]['coe_id'].','.$a0Report[$l['applicability']]['msn_id'].','.$a0Report[$l['applicability']]['program_id'].',\''.$a0Report[$l['applicability']]['ca'].'\');">'.$reviewTxt.'</span>':$reviewTxt;
			break;

		}
		$logTxt[$i]['event']=$event;
		if(is_array($data)){
			$data['displayed_results']++;
		}
		$i++;
	}
	return $logTxt;
}

?>