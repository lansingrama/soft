<?php

if(empty($POST['filename'])) //JFM 11_08_14
{
	require_once('../security/checkExpiredSession.php');
	require_once('../../support.php');
	require_once('../../common/php/common.php');
	require_once('localSupport.php');
	require_once('form.php');
	require_once('zipfile.php');

	$POST=cleanArray($_POST);

	function forLoop($array, &$string)
	{
		for ($i=0; $i < count($array); $i++) 
		{
			$string.='<c:pt idx="'.$i.'"><c:v>'.$array[$i].'</c:v></c:pt>';
		}
	}
}

foreach($POST as $k => $l)
{
	if($l=='null') $POST[$k]=0;
}

$group	=explode(',', $POST['group']);
$purple	=explode(',', $POST['purple']);
$red	=explode(',', $POST['red']);
$amber	=explode(',', $POST['amber']);
$green	=explode(',', $POST['green']);
$blue	=explode(',', $POST['blue']);

if(is_file('../output/sharedStrings.xml')) unlink('../output/sharedStrings.xml');
if(is_file('../output/sheet1.xml')) unlink('../output/sheet1.xml');
if(is_file('../output/chart1.xml')) unlink('../output/chart1.xml');
if(is_file('../output/Book3.zip')) unlink('../output/Book3.zip');
if(is_file('../output/Book3.xlsx')) unlink('../output/Book3.xlsx');

$sharedStringsxml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="'.(count($group)+1).'" uniqueCount="'.(count($group)+1).'">';

for ($i=0; $i < count($group); $i++) 
{ 
	$sharedStringsxml.='<si><t>'.$group[$i].'</t></si>';
}

$sharedStringsxml.='<si><t>Group</t></si><si><t>Evidence assessed as showstopper</t></si><si><t>Evidence assessed as risk</t></si><si><t>Evidence Not Supplied</t></si><si><t>Evidence supplied - to be assessed</t></si><si><t>Criteria Accepted</t></si></sst>';

$sheet1xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" mc:Ignorable="x14ac" xmlns:x14ac="http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac"><dimension ref="A1:F'.count($group).'"/><sheetViews><sheetView tabSelected="1" workbookViewId="0"><selection activeCell="F26" sqref="F26"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="14.25" x14ac:dyDescent="0.2"/><sheetData>';
$sheet1xml.='<row r="1" spans="1:6" x14ac:dyDescent="0.2"><c r="A1" t="s"><v>'.(count($group)).'</v></c><c r="B1" t="s"><v>'.(count($group)+1).'</v></c><c r="C1" t="s"><v>'.(count($group)+2).'</v></c><c r="D1" t="s"><v>'.(count($group)+3).'</v></c><c r="E1" t="s"><v>'.(count($group)+4).'</v></c><c r="F1" t="s"><v>'.(count($group)+5).'</v></c></row>';

for ($i=0; $i < count($group); $i++) 
{ 
	$j=$i+2;
	$sheet1xml.='<row r="'.$j.'" spans="1:6" x14ac:dyDescent="0.2"><c r="A'.$j.'" t="s"><v>'.$i.'</v></c><c r="B'.$j.'"><v>'.$purple[$i].'</v></c><c r="C'.$j.'"><v>'.$red[$i].'</v></c><c r="D'.$j.'"><v>'.$amber[$i].'</v></c><c r="E'.$j.'"><v>'.$green[$i].'</v></c><c r="F'.$j.'"><v>'.$blue[$i].'</v></c></row>';
}

$sheet1xml.='</sheetData><pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/><drawing r:id="rId1"/></worksheet>';


$chart1xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><c:date1904 val="0"/><c:lang val="en-GB"/><c:roundedCorners val="0"/><mc:AlternateContent xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"><mc:Choice Requires="c14" xmlns:c14="http://schemas.microsoft.com/office/drawing/2007/8/2/chart"><c14:style val="102"/></mc:Choice><mc:Fallback><c:style val="2"/></mc:Fallback></mc:AlternateContent><c:chart><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="2000"/></a:pPr><a:r><a:rPr lang="en-GB"/><a:t>'.$POST['title'].'</a:t></a:r><a:endParaRPr lang="en-GB"/></a:p></c:rich></c:tx><c:layout/><c:overlay val="0"/></c:title><c:autoTitleDeleted val="0"/><c:plotArea><c:layout/><c:barChart><c:barDir val="col"/><c:grouping val="stacked"/><c:varyColors val="0"/><c:ser><c:idx val="0"/><c:order val="0"/><c:tx><c:strRef><c:f>Sheet1!$B$1</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>Evidence assessed as showstopper</c:v></c:pt></c:strCache></c:strRef></c:tx><c:spPr><a:solidFill><a:srgbClr val="7030A0"/></a:solidFill></c:spPr><c:invertIfNegative val="0"/><c:cat><c:strRef><c:f>Sheet1!$A$2:$A$'.(count($group)+1).'</c:f><c:strCache><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($group, $chart1xml);

$chart1xml.='</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$B$2:$B$'.(count($group)+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($purple, $chart1xml);

$chart1xml.='</c:numCache></c:numRef></c:val></c:ser><c:ser><c:idx val="1"/><c:order val="1"/><c:tx><c:strRef><c:f>Sheet1!$C$1</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>Evidence assessed as risk</c:v></c:pt></c:strCache></c:strRef></c:tx><c:spPr><a:solidFill><a:srgbClr val="FF0000"/></a:solidFill></c:spPr><c:invertIfNegative val="0"/><c:cat><c:strRef><c:f>Sheet1!$A$2:$A$'.(count($group)+1).'</c:f><c:strCache><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($group, $chart1xml);

$chart1xml.='</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$C$2:$C$'.(count($group)+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($red, $chart1xml);

$chart1xml.='</c:numCache></c:numRef></c:val></c:ser><c:ser><c:idx val="2"/><c:order val="2"/><c:tx><c:strRef><c:f>Sheet1!$D$1</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>Evidence Not Supplied</c:v></c:pt></c:strCache></c:strRef></c:tx><c:spPr><a:solidFill><a:srgbClr val="FFC000"/></a:solidFill></c:spPr><c:invertIfNegative val="0"/><c:cat><c:strRef><c:f>Sheet1!$A$2:$A$'.(count($group)+1).'</c:f><c:strCache><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($group, $chart1xml);

$chart1xml.='</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$D$2:$D$'.(count($group)+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($amber, $chart1xml);

$chart1xml.='</c:numCache></c:numRef></c:val></c:ser><c:ser><c:idx val="3"/><c:order val="3"/><c:tx><c:strRef><c:f>Sheet1!$E$1</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>Evidence supplied - to be assessed</c:v></c:pt></c:strCache></c:strRef></c:tx><c:spPr><a:solidFill><a:srgbClr val="00B050"/></a:solidFill></c:spPr><c:invertIfNegative val="0"/><c:cat><c:strRef><c:f>Sheet1!$A$2:$A$'.(count($group)+1).'</c:f><c:strCache><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($group, $chart1xml);

$chart1xml.='</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$E$2:$E$'.(count($group)+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($green, $chart1xml);

$chart1xml.='</c:numCache></c:numRef></c:val></c:ser><c:ser><c:idx val="4"/><c:order val="4"/><c:tx><c:strRef><c:f>Sheet1!$F$1</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>Criteria Accepted</c:v></c:pt></c:strCache></c:strRef></c:tx><c:spPr><a:solidFill><a:srgbClr val="0070C0"/></a:solidFill></c:spPr><c:invertIfNegative val="0"/><c:cat><c:strRef><c:f>Sheet1!$A$2:$A$'.(count($group)+1).'</c:f><c:strCache><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($group, $chart1xml);

$chart1xml.='</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$F$2:$F$'.(count($group)+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.(count($group)-1).'"/>';

forLoop($blue, $chart1xml);

$chart1xml.='</c:numCache></c:numRef></c:val></c:ser><c:dLbls><c:showLegendKey val="0"/><c:showVal val="0"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/><c:showBubbleSize val="0"/></c:dLbls><c:gapWidth val="300"/><c:overlap val="100"/><c:serLines><c:spPr><a:ln><a:noFill/></a:ln></c:spPr></c:serLines><c:axId val="100134272"/><c:axId val="100800000"/></c:barChart><c:catAx><c:axId val="100134272"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr b="0"/></a:pPr><a:r><a:rPr lang="en-GB" sz="2000" b="0"/><a:t>Sub-Chapter</a:t></a:r></a:p></c:rich></c:tx><c:layout/><c:overlay val="0"/></c:title><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:crossAx val="100800000"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx><c:valAx><c:axId val="100800000"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="l"/><c:majorGridlines/><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="2000" b="0"/></a:pPr><a:r><a:rPr lang="en-GB" sz="2000" b="0"/><a:t>Number of Criteria</a:t></a:r></a:p></c:rich></c:tx><c:layout/><c:overlay val="0"/></c:title><c:numFmt formatCode="General" sourceLinked="1"/><c:majorTickMark val="out"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:crossAx val="100134272"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx></c:plotArea><c:legend><c:legendPos val="r"/><c:layout/><c:overlay val="0"/></c:legend><c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/><c:showDLblsOverMax val="0"/></c:chart><c:printSettings><c:headerFooter/><c:pageMargins b="0.75" l="0.7" r="0.7" t="0.75" header="0.3" footer="0.3"/><c:pageSetup/></c:printSettings></c:chartSpace>';


$fp=fopen('../output/sharedStrings.xml','w');
fwrite($fp,$sharedStringsxml);
fclose($fp);

$fp=fopen('../output/sheet1.xml','w');
fwrite($fp,$sheet1xml);
fclose($fp);

$fp=fopen('../output/chart1.xml','w');
fwrite($fp,$chart1xml);
fclose($fp);


$zip = new ZipArchive();

$zip->open('../output/Book3.zip', ZipArchive::CREATE);

$source=str_replace('\\', '/', realpath('../archive/Book3/'));
$flag=basename($source).'/';

$files= new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source),RecursiveIteratorIterator::SELF_FIRST);

foreach($files as $file)
{
	$file=str_replace('\\', '/', realpath($file));
	
	if(is_dir($file)===true)
	{
		$zip->addEmptyDir(str_replace($source.'/', '', $file));
	}
	else if(is_file($file))
	{
		if(strpos($file, 'sharedStrings')  && !strpos($file, 'rels')) 
		{
			$fileNew='../output/sharedStrings.xml';
		}
		else if(strpos($file, 'sheet1') && !strpos($file, 'rels')) 
		{
			$fileNew='../output/sheet1.xml';
		}
		else if(strpos($file, 'chart1')  && !strpos($file, 'rels')) 
		{
			$fileNew='../output/chart1.xml';
		}
		else $fileNew=$file;

		$zip->addFromString(str_replace($source.'/', '', $file), file_get_contents($fileNew));
	}
}

$zip->close();

storeSession($SESSION);

if(empty($POST['filename'])) //JFM 11_08_14
{
	rename("../output/Book3.zip", "../output/Book3.xlsx");

	if(is_file('../output/sharedStrings.xml')) unlink('../output/sharedStrings.xml');
	if(is_file('../output/sheet1.xml')) unlink('../output/sheet1.xml');
	if(is_file('../output/chart1.xml')) unlink('../output/chart1.xml');

	header('Content-type: application/octet-stream');
	header('Content-Disposition: attachment; filename=Book3.xlsx');
	header("Cache-Control: private");
	header("Pragma: private");
	readfile('../output/Book3.xlsx');
}
else
{
	rename("../output/Book3.zip", "../output/".$POST['filename'].".xlsx");

	if(is_file('../output/sharedStrings.xml')) unlink('../output/sharedStrings.xml');
	if(is_file('../output/sheet1.xml')) unlink('../output/sheet1.xml');
	if(is_file('../output/chart1.xml')) unlink('../output/chart1.xml');
}

?>