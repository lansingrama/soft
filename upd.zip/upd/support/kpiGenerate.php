<?php
/*
 * File to generate the KPI excel file - US#91
 * Version: 4.4
 * Created By: Infosys Limited
 */
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../../common/php/zip.lib.php');
require_once('localSupport.php');
require_once('form.php');
require_once ('../../common/php/PHPExcel1/Classes/PHPExcel.php');
require_once ('../../common/php/PHPExcel1/Classes/PHPExcel/IOFactory.php');

$POST = cleanArray($_POST);
$kpiArr = json_decode( html_entity_decode( stripslashes ($POST['kpiData'] ) ) );
$type = $POST['type'];

$area = array();
$program = array();
$coe = array();
$msn = array();
$specificFilter = array();

foreach($kpiArr as $kpiDetails) {
    if(!empty($kpiDetails)) {
        array_push($area,$kpiDetails->area);
        array_push($program,$kpiDetails->program);
        array_push($coe,$kpiDetails->coe);
        array_push($msn,$kpiDetails->msn);
    }    
}

$area = implode(',', array_unique($area));
$program = implode(',', $program);
$coe = implode(',', $coe);
$msn = implode(',', $msn);

$programArr = explode(',', $program);
$coeArr = explode(',', $coe);
$msnArr = explode(',', $msn);

// To remove the duplicates in Program, coe and msn
$program = implode(',', array_unique($programArr));
$coe = implode(',', array_unique($coeArr));
$msn = implode(',', array_unique($msnArr));

$statusWordMap = array(0 => 'RED', 1 => 'AMBER', 2 => 'GREEN', 3 => 'BLUE');
$radioValue = array(0 => 'No', 1 => 'Yes');

if ($program && $coe) {
$ca = SqlSLi('SELECT ca_id FROM c_ca 
		WHERE program IN (' . $program . ')
		AND coe IN (' . $coe . ')', 'ca_id');

$ca = implode(',', $ca);

$reviewProfileQry = SqlSLi('SELECT review_profile_id FROM dr_review_profile 
                WHERE program IN (' . $program . ')
                AND coe IN (' . $coe . ') AND rp_hidden=0', 'review_profile_id');

$reviewProfile = implode(',', $reviewProfileQry);
}

$specificFilter = array();

if ($msn) {
	$specificFilter[] = 'r.msn IN(' . $msn . ')';
}

if ($ca) {
	$specificFilter[] = 'ra.ca IN('. $ca .')';
}

if ($reviewProfile) {
	$specificFilter[] = 'r.review_profile IN(' . $reviewProfile . ')';
}
if (!empty($POST['from'])) {
    $specificFilter[] = 'r.planned >= "' . $POST['from'] . '"';
}
if (!empty($POST['to'])) {
    $specificFilter[] = 'r.planned <= "' . $POST['to'] . '"';
}
if(count($specificFilter)>0){
	$qryFilter = '  WHERE '.implode(' AND ',$specificFilter);
}

$filter = array();
if ($msn) {
	$filter[] = 'rs.msn IN(' . $msn . ')';
}
if ($ca) {
    $filter[] = 'rs.ca IN(' . $ca . ')';
}
if ($reviewProfile) {
	$filter[] = 'rs.review_profile IN(' . $reviewProfile . ')';
}
if (!empty($POST['from'])) {
    $filter[] = 'rs.planned >= "' . $POST['from'] . '"';
}
if (!empty($POST['to'])) {
    $filter[] = 'rs.planned <= "' . $POST['to'] . '"';
}
if (count($specificFilter) > 0) {
    $pfilter = '  WHERE ' . implode(' AND ', $filter);
}

// Query to select all the DRs for the selected Area and Levels
$review = SqlLi('SELECT msn.msn,ca.ca,ca.ca_description,pro.program,coe.coe,area.area,per.perimeter,wp.wp,wp.wp_description,
    r.review_id, r.planned,r.review_date, r.review_done,r.delta_planned,r.delta,r.delta_done,r.review_status,r.validation_complete,r.validation_date, r.continuous_assessment,r.initial_review_status,rt.review_type
            FROM dr_review AS r 
                    INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id 
                    INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
                    INNER JOIN dr_review_type AS rt ON rp.review_type=rt.review_type_id
                    INNER JOIN c_ca as ca ON ra.ca=ca.ca_id
                    INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
                    INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND r.msn=m.msn_id)
                    INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
                    INNER JOIN c_msn as msn ON r.msn=msn.msn_id
                    INNER JOIN c_perimeter AS per ON ca.perimeter=per.perimeter_id
                    INNER JOIN c_program AS pro ON ca.program=pro.program_id
                    INNER JOIN c_coe AS coe ON ca.coe=coe.coe_id
                    INNER JOIN c_area AS area ON coe.area=area.area_id
					'.$qryFilter.'
					AND r.planned > "0000-00-00"');
					
$reviewPlanned = SqlLi('SELECT r.review_id, rs.planned,r.review_date, r.review_done,r.delta_planned,r.delta,r.delta_done,r.review_status,r.validation_complete,r.validation_date, r.continuous_assessment,r.initial_review_status, rt.review_type,msn.msn,ca.ca,ca.ca_description,pro.program,coe.coe,area.area,per.perimeter,wp.wp,wp.wp_description
	FROM dr_review_status as rs LEFT JOIN dr_review as r ON rs.review_profile=r.review_profile 
	INNER JOIN dr_review_profile as rp ON rs.review_profile=rp.review_profile_id
	INNER JOIN dr_review_type AS rt ON rp.review_type=rt.review_type_id
	INNER JOIN c_ca as ca ON rs.ca=ca.ca_id
	INNER JOIN c_cawp AS cw	ON rs.ca=cw.ca
	INNER JOIN c_wp As wp ON cw.wp=wp.wp_id
	INNER JOIN c_msn AS msn ON rs.msn=msn.msn_id
	INNER JOIN c_perimeter as per ON ca.perimeter=per.perimeter_id
	INNER  JOIN c_coe as coe ON ca.coe=coe.coe_id
	INNER JOIN c_program as pro ON ca.program=pro.program_id
	INNER JOIN c_area as area ON pro.area=area.area_id
	'.$pfilter.'
	AND rs.planned > "0000-00-00" AND r.review_id IS NULL
GROUP BY rs.id'); 

foreach($reviewPlanned as $item) {
    array_push($review, $item);
}

if(!empty($review)) {
    $review_id = array();
    foreach($review as $reviewID) {
        if($reviewID['review_id']) {
            array_push($review_id,$reviewID['review_id']);
        }
    }
    $drIds = implode(',', $review_id);
    // Criteria Extract
    $criteria = SqlLi('SELECT rc.review,ch.criterion,ch.criterion_user_id,ch.criterion_name,ch.criterion_description,ch.criterion_showstopper,ch.criterion_moc,cs.criteria_status
            FROM dr_review_configuration as rc 
                INNER JOIN dr_review_criterion_history as ch ON rc.criterion=ch.criterion
                INNER JOIN dr_criteria_status as cs ON rc.criterion=cs.review_criteria
            WHERE rc.review IN ('.$drIds.') 
            Group BY rc.criterion');
    
    // Action Extract
    $action = SqlLi('SELECT r.review_id,act.criteria,act.action_id,act.action_code,act.action_description,
        act.action_remark,act.action_creation,act.action_completion,
        act.action_closure,act.action_status,act.action_holder,act.action_holder_name,
        CONCAT(u1.surname,", ",u1.name) as user_holder,act.action_validator,act.action_validator_name,
        CONCAT(u2.surname,", ",u2.name) as user_validator,
        rid.rid_id, rid.rid_code, rid.rid_code,rid.rid_title,rid.rid_status,rid.rid_holder_name,rid.rid_creation,
        rid.rid_completion,rid.rid_closure,rid.rid_showstopper,rid.rid_validator_name
        FROM dr_action AS act
                INNER JOIN dr_action_applicability AS aap ON act.action_id=aap.action
                INNER JOIN dr_review_configuration AS rconf ON rconf.criterion=act.criteria
                INNER JOIN dr_review as r ON r.review_id=rconf.review
                LEFT JOIN dr_rid as rid ON act.rid=rid.rid_id
                INNER JOIN c_user AS u1 ON act.action_holder=u1.user_id
                INNER JOIN c_user AS u2 ON act.action_validator=u2.user_id 
        WHERE act.msn IN ('.$msn.')
            AND aap.ca IN (' . $ca . ')
            AND r.review_profile IN (' . $reviewProfile . ')
            AND r.review_id IN ('.$drIds.')
        GROUP BY act.criteria,act.action_status');
}

switch ($type) {
    case 'review': generateReview($review,$statusWordMap,$radioValue);
    break;
    case 'criteria': generateCriteria($criteria,$statusWordMap,$radioValue);
    break;
    case 'action': generateAction($action,$statusWordMap);
    break;
}

function generateReview($review,$statusWordMap,$radioValue) {
    // Create PHPExcel object and export all the DR details to it
    $objPHPExcel = new PHPExcel();
    $objPHPExcel->setActiveSheetIndex(0);
    $row = 2;

    foreach ($review as $data) {
        if($data['continuous_assessment'] == 1) {
            $data['continuous_assessment'] = 'Active';
        } else {
            $data['continuous_assessment'] = 'Inactive';
        }
        
        if($data['validation_complete'] == 1) {
            $data['validation_complete'] = 'Commencing';
        } else if($data['validation_complete'] == 2) {
            $data['validation_complete'] = 'Completed';
        } else {
            $data['validation_complete'] = 'Not Validated';
        }
        
        $objPHPExcel->getActiveSheet()
                ->setCellValue('A' . $row, $data['area'])
                ->setCellValue('B' . $row, $data['program'])
                ->setCellValue('C' . $row, $data['coe'])
                ->setCellValue('D' . $row, $data['msn'])
                ->setCellValue('E' . $row, $data['perimeter'])
                ->setCellValue('F' . $row, $data['ca'])
                ->setCellValue('G' . $row, $data['ca_description'])
                ->setCellValue('H' . $row, $data['wp'])
                ->setCellValue('I' . $row, $data['wp_description'])
                ->setCellValue('J' . $row, $data['review_type'])
                ->setCellValue('K' . $row, $data['review_id'])
                ->setCellValue('L' . $row, $data['planned'])
                ->setCellValue('M' . $row, $data['review_date'])
                ->setCellValue('N' . $row, $radioValue[$data['review_done']])
                ->setCellValue('O' . $row, $data['delta_planned'])
                ->setCellValue('P' . $row, $data['delta'])
                ->setCellValue('Q' . $row, $radioValue[$data['delta_done']])
                ->setCellValue('R' . $row, $statusWordMap[$data['review_status']])
                ->setCellValue('S' . $row, $data['validation_complete'])
                ->setCellValue('T' . $row, $data['continuous_assessment'])
                ->setCellValue('U' . $row, $statusWordMap[$data['initial_review_status']]);
        $row++;
    }

    $objPHPExcel->getActiveSheet()
            ->setCellValue('A1', 'Area')
            ->setCellValue('B1', 'Program')
            ->setCellValue('C1', 'Coe')
            ->setCellValue('D1', 'Msn')
            ->setCellValue('E1', 'Perimeter')
            ->setCellValue('F1', 'CA')
            ->setCellValue('G1', 'CA Description')
            ->setCellValue('H1', 'WP')
            ->setCellValue('I1', 'WP Description')
            ->setCellValue('J1', 'Review Type')
            ->setCellValue('K1', 'Review ID')
            ->setCellValue('L1', 'Review Planned')
            ->setCellValue('M1', 'Review Date')
            ->setCellValue('N1', 'Review Done')
            ->setCellValue('O1', 'Delta Planned')
            ->setCellValue('P1', 'Delta')
            ->setCellValue('Q1', 'Delta Done')
            ->setCellValue('R1', 'Review Status')
            ->setCellValue('S1', 'Validation Complete')
            ->setCellValue('T1', 'Continuous Assessment')
            ->setCellValue('U1', 'Initial Review Status');

    $objPHPExcel->getActiveSheet()->getStyle('A1:U1')->applyFromArray(
            array(
                'font' => array(
                    'bold' => true
                )
            )
    );

    header('Content-Type: application/vnd.vnd.ms-excel');
    header('Content-Disposition: attachment');
    header('Cache-Control: max-age=0');
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $filename = "art_design_review_extract_" . date('Y_m_d_H_i_s');
    $objWriter->save('../output/' . $filename . '.xls');
    $objPHPExcel->disconnectWorksheets();
    unset($objWriter, $objPHPExcel);
    echo 'OK|||' . $filename;
}

function generateCriteria($criteria,$statusWordMap,$radioValue) {
    // Create PHPExcel object and export all the Creteria details to it
    $objPHPExcel = new PHPExcel();
    $objPHPExcel->setActiveSheetIndex(0);
    $row = 2;

    foreach ($criteria as $data) {       
        $objPHPExcel->getActiveSheet()
                ->setCellValue('A' . $row, $data['review'])
                ->setCellValue('B' . $row, $data['criterion'])
                ->setCellValue('C' . $row, $data['criterion_user_id'])
                ->setCellValue('D' . $row, $data['criterion_name'])
                ->setCellValue('E' . $row, $data['criterion_description'])
                ->setCellValue('F' . $row, $radioValue[$data['criterion_showstopper']])
                ->setCellValue('G' . $row, $radioValue[$data['criterion_moc']])
                ->setCellValue('H' . $row, $statusWordMap[$data['criteria_status']]);
        $row++;
    }

    $objPHPExcel->getActiveSheet()
            ->setCellValue('A1', 'Review ID')
            ->setCellValue('B1', 'Criterion ID')
            ->setCellValue('C1', 'Criterion User ID')
            ->setCellValue('D1', 'Criterion Name')
            ->setCellValue('E1', 'Criterion Description')
            ->setCellValue('F1', 'Criterion Showstopper')
            ->setCellValue('G1', 'Criterion MOC')
            ->setCellValue('H1', 'Criteria Status');

    $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray(
            array(
                'font' => array(
                    'bold' => true
                )
            )
    );

    header('Content-Type: application/vnd.vnd.ms-excel');
    header('Content-Disposition: attachment');
    header('Cache-Control: max-age=0');
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $filename = "art_review_criteria_extract_" . date('Y_m_d_H_i_s');
    $objWriter->save('../output/' . $filename . '.xls');
    $objPHPExcel->disconnectWorksheets();
    unset($objWriter, $objPHPExcel);
    echo 'OK|||' . $filename;
}

function generateAction($action,$statusWordMap) {
    // Create PHPExcel object and export all the Action & RID details to it
    $objPHPExcel = new PHPExcel();
    $objPHPExcel->setActiveSheetIndex(0);
    $row = 2;

    foreach ($action as $data) {
        if($data['action_holder_name']) {
            $holder = $data['action_holder_name'];
        } else {
            $holder = $data['user_holder'];
        }
        
        if($data['action_validator_name']) {
            $validator = $data['action_validator_name'];
        } else {
            $validator = $data['user_validator'];
        }
        
        if($data['rid_showstopper'] == 1) {
            $data['rid_showstopper'] = 'Yes';
        }
        
        $objPHPExcel->getActiveSheet()
                ->setCellValue('A' . $row, $data['review_id'])
                ->setCellValue('B' . $row, $data['criteria'])
                ->setCellValue('C' . $row, $data['action_id'])
                ->setCellValue('D' . $row, $data['action_code'])
                ->setCellValue('E' . $row, $data['action_description'])
                ->setCellValue('F' . $row, $data['action_remark'])
                ->setCellValue('G' . $row, $data['action_creation'])
                ->setCellValue('H' . $row, $data['action_completion'])
                ->setCellValue('I' . $row, $data['action_closure'])
                ->setCellValue('J' . $row, $statusWordMap[$data['action_status']])
                ->setCellValue('K' . $row, $holder)
                ->setCellValue('L' . $row, $validator)
                ->setCellValue('M' . $row, $data['rid_id'])
                ->setCellValue('N' . $row, $data['rid_code'])
                ->setCellValue('O' . $row, $data['rid_title'])
                ->setCellValue('P' . $row, $data['rid_holder_name'])
                ->setCellValue('Q' . $row, $statusWordMap[$data['rid_status']])
                ->setCellValue('R' . $row, $data['rid_creation'])                
                ->setCellValue('S' . $row, $data['rid_completion'])
                ->setCellValue('T' . $row, $data['rid_closure'])
                ->setCellValue('U' . $row, $data['rid_showstopper'])
                ->setCellValue('V' . $row, $data['rid_validator_name']);
        $row++;
    }

    $objPHPExcel->getActiveSheet()
            ->setCellValue('A1', 'Review ID')
            ->setCellValue('B1', 'Criteria ID')
            ->setCellValue('C1', 'Action ID')
            ->setCellValue('D1', 'Action Code')
            ->setCellValue('E1', 'Action Description')
            ->setCellValue('F1', 'Action Remark')
            ->setCellValue('G1', 'Action Creation')
            ->setCellValue('H1', 'Action Completion')
            ->setCellValue('I1', 'Action Closure')
            ->setCellValue('J1', 'Action Status')
            ->setCellValue('K1', 'Action Holder Name')
            ->setCellValue('L1', 'Action Validator Name')
            ->setCellValue('M1', 'Rid ID')
            ->setCellValue('N1', 'Rid Code')
            ->setCellValue('O1', 'Rid Title')
            ->setCellValue('P1', 'Rid Holder Name')
            ->setCellValue('Q1', 'Rid Status')
            ->setCellValue('R1', 'Rid Creation')
            ->setCellValue('S1', 'Rid Completion')
            ->setCellValue('T1', 'Rid Closure')
            ->setCellValue('U1', 'Rid Showstopper')
            ->setCellValue('V1', 'Rid Validator Name');

    $objPHPExcel->getActiveSheet()->getStyle('A1:V1')->applyFromArray(
            array(
                'font' => array(
                    'bold' => true
                )
            )
    );

    header('Content-Type: application/vnd.vnd.ms-excel');
    header('Content-Disposition: attachment');
    header('Cache-Control: max-age=0');
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $filename = "art_review_action_extract" . date('Y_m_d_H_i_s');
    $objWriter->save('../output/' . $filename . '.xls');
    $objPHPExcel->disconnectWorksheets();
    unset($objWriter, $objPHPExcel);
    echo 'OK|||' . $filename;
}