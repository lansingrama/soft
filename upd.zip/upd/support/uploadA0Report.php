<?php
require_once('header.php');
require_once('../security/checkExpiredSession.php');
require_once('localSupport.php');
require_once('form.php');

/*
	USEFUL DEBUG!!!!!!!
	---------------------------------------
	?><script>alert('<?=json_encode($action['WPCAApp']);?>-----<?=json_encode($a0Config['a0_ca']);?>-----<?=json_encode($action);?>-----<?=json_encode($actionApplicability);?>');</script><?php
	?><script>alert('<?=json_encode($stuff);?>');</script><?php

*/

function actionCheckerLauncher($rid,&$a0Config,$SESSION){
	$actionsInRid=$rid['action'];
	unset($rid['action']);

	if($actionsInRid['action_id']!='' || $actionsInRid['action_a0_id']!=''){
		checkAction($rid,$actionsInRid,$a0Config,$SESSION);
	}elseif($actionsInRid[0]['action_id']!='' || $actionsInRid[0]['action_a0_id']!=''){
		foreach($actionsInRid as $a){
			checkAction($rid,$a,$a0Config,$SESSION);
		}
	}
}

function allFieldsFilled($array,$fieldsToIgnore){
	if(is_array($array)){
		if($fieldsToIgnore==''){
			$fieldsToIgnore=array();
		}
		foreach($array as $k=>$v){
			if(is_array($v) && !in_array($k,$fieldsToIgnore)){
				return 0;
			}
		}
		return 1;
	}else{
		return 0;
	}
}

function checkAction($rid,$action,&$a0Config,$SESSION){
	if(allFieldsFilled($action,array('action_a0_id','WPCAApp'))==1){

		if(is_array($action['action_a0_id'])){
			$action['action_a0_id']='';
		}
		
		if(is_array($action['WPCAApp']))
		{
			if($action['WPCAApp']['value']=="All CA") //JFM 11_03_14
			{
				$action['WPCAApp']['value']=$a0Config['a0_ca'];
			}
			if(is_array($action['WPCAApp']['value']))
			{
				foreach($action['WPCAApp']['value'] as $a)
				{
					getActionApplicability($a,$a0Config,$actionApplicability);
				}
			}
			else
			{
				getActionApplicability($action['WPCAApp']['value'],$a0Config,$actionApplicability);
			}
		}

		if(is_array($actionApplicability))
		{
			$actionApplicability=array_unique($actionApplicability);
			
			if($action['action_id']!='' || $action['action_a0_id']!='')
			{
				if($action['actionholderid']=='' || $action['actionholderid']==0)
				{
					$nameSplit=explode(", ",$action['actionholder']);

					$userID=SqlQ('SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"');

					if(!empty($userID['user_id']))
					{
						$action['actionholderid']=$userID['user_id'];
						$actionHolderName='';
					}
					else
					{
						$actionHolderName=$action['actionholder'];
					}
				}
				else
				{
					$actionHolderName='';
				}
				$newAction=0;

				$inValidationLoop = false; //JFM 12_01_16

				if($a0Config['action_a0_id'][$action['action_a0_id']]=='' && $action['action_id']=='')
				{
					$newAction=1;

					SqlLQ('INSERT INTO dr_action
											(msn,criteria,action_code,action_description,action_creation,action_completion,action_closure,action_status,action_holder,action_holder_name,action_a0_id)
										VALUES
											("'.$a0Config['msn'].'","'.$a0Config['criteria_id'].'","'.newCode($a0Config['wp'],$a0Config['criteria_id'],$SESSION,'action').'","'.$action['actiondescription'].'","'.$action['actioncreationdate'].'","'.$action['actionduedate'].'","'.$action['actionclosuredate'].'","'.$a0Config['a0_status_translation'][$action['act_status']].'","'.$action['actionholderid'].'","'.$actionHolderName.'","'.$action['action_a0_id'].'")');
					$actionIdQry=SqlQ('SELECT LAST_INSERT_ID()');
					$actionId=$actionIdQry['LAST_INSERT_ID()'];
					$appToAdd=$actionApplicability;
					$a0Config['action_a0_id'][$action['action_a0_id']]=$actionId;

					//JFM 12_01_16
					$fakeLogArrayOld = array();
					$fakeLogArrayOld['action_status'] = 0;
					$fakeLogArrayOld['action_description'] = "";
					$fakeLogArrayOld['action_remark'] = "";
					$fakeLogArrayOld['action_completion'] = "0000-00-00";
					$fakeLogArrayOld['action_holder'] = 0;

					$fakeLogArrayNew = array();
					$fakeLogArrayNew['action_status'] = $a0Config['a0_status_translation'][$action['act_status']];
					$fakeLogArrayNew['wp'] = $a0Config['wp'];
					$fakeLogArrayNew['action_description'] = $action['actiondescription'];
					$fakeLogArrayNew['action_remark'] = "";
					$fakeLogArrayNew['action_completion'] = $action['actionduedate'];
					$fakeLogArrayNew['action_holder'] = $action['actionholderid'];

					createLog('dr_log','action_id','create',$actionId,'','',$SESSION);

					$actionUpdateString=getFormUpdate($fakeLogArrayNew,$fakeLogArrayOld,'action','action',$actionId,$SESSION,array('action_code','wp'));


				}
				else
				{
					if($action['action_id']=='')
					{
						$actionId=$a0Config['action_a0_id'][$action['action_a0_id']];
					}
					else
					{
						$actionId=$action['action_id'];
					}

					$actionQryForLog=SqlQ('SELECT * FROM dr_action WHERE action_id="'.$actionId.'"');

					if($actionQryForLog['validation_loop'] == 0)
					{
						//JFM 12_01_16
						$fakeLogArrayNew = array();
						$fakeLogArrayNew['action_status'] = $a0Config['a0_status_translation'][$action['act_status']];
						$fakeLogArrayNew['wp'] = $a0Config['wp'];
						$fakeLogArrayNew['action_description'] = $action['actiondescription'];
						$fakeLogArrayNew['action_completion'] = $action['actionduedate'];
						$fakeLogArrayNew['action_holder'] = $action['actionholderid'];

						$actionUpdateString=getFormUpdate($fakeLogArrayNew,$actionQryForLog,'action','action',$actionQryForLog['action_id'],$SESSION,array('action_code','wp'));

						SqlLQ('UPDATE dr_action
								SET action_description="'.$action['actiondescription'].'",action_creation="'.$action['actioncreationdate'].'",action_completion="'.$action['actionduedate'].'",action_closure="'.$action['actionclosuredate'].'",action_status="'.$a0Config['a0_status_translation'][$action['act_status']].'",action_holder="'.$action['actionholderid'].'",action_holder_name="'.$actionHolderName.'",action_a0_id="'.$action['action_a0_id'].'"
								WHERE action_id="'.$actionId.'"');

						$oldActionApplicability=SqlSLi('SELECT ca FROM dr_action_applicability WHERE action="'.$actionId.'"','ca');
						
						if(is_array($oldActionApplicability)){
							foreach($actionApplicability as $a){
								if(!in_array($a,$oldActionApplicability)){
									$appToAdd[]=$a;
								}
							}
						
							foreach($oldActionApplicability as $o){
								if(!in_array($o,$actionApplicability)){
									$appToRemove[]=$o;
								}
							}
						}
					}
					else //JFM 12_01_16
					{
						$inValidationLoop = true;
					}
				}
				
				if(!$inValidationLoop) //JFM 12_01_16
				{
					if(is_array($appToAdd)){
						foreach($appToAdd as $a){

							SqlLQ('INSERT INTO dr_action_applicability (action,ca) VALUES ("'.$actionId.'","'.$a.'")');
						}
					}
					
					if(is_array($appToRemove)){
						foreach($appToRemove as $a){
							SqlLQ('DELETE FROM dr_action_applicability WHERE action="'.$actionId.'" AND ca="'.$a.'"');
						}
					}
				}
				
				if(is_array($rid['ridstatus'])){
					$rid['ridstatus']=2;
				}
				
				if(allFieldsFilled($rid,array('ridid','ridcode'))==1){
					if($rid['ridid']!='' || $rid['rid_a0_id']!=''){
						if($rid['ridholderid']=='' || $rid['ridholderid']==0)
						{
							$nameSplit=explode(", ",$rid['ridholder']);

							$userID=SqlQ('SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"');

							if(!empty($userID['user_id']))
							{
								$rid['ridholderid']=$userID['user_id'];
								$ridHolderName='';
							}
							else
							{
								$ridHolderName=$rid['ridholder'];
							}
						}
						else
						{
							$ridHolderName='';
						}
						//$ridHolderName=($rid['ridholderid']=='' || $rid['ridholderid']==0)?$rid['ridholder']:'';
						$newRid=0;
						if($a0Config['rid_a0_id'][$rid['rid_a0_id']]=='' && $rid['ridid']==''){
							$newRid=1;
							SqlLQ('INSERT INTO dr_rid
										(criteria,rid_code,rid_title,rid_status,rid_holder,rid_holder_name,rid_creation,rid_completion,rid_closure,rid_showstopper,rid_action_plan,rid_a0_id)
									VALUES
										("'.$a0Config['criteria_id'].'","'.newCode($a0Config['wp'],$a0Config['criteria_id'],$SESSION,'rid').'","'.$rid['ridtitle'].'","'.$a0Config['a0_status_translation'][$rid['ridstatus']].'","'.$rid['ridholderid'].'","'.$ridHolderName.'","'.$rid['rid_creation_date'].'","'.$rid['rid_completion_date'].'","'.$rid['rid_closure_date'].'","'.$rid['ridshowstopper'].'","'.$rid['ridactionplan'].'","'.$rid['rid_a0_id'].'")');
							
							$ridIdQry=SqlQ('SELECT LAST_INSERT_ID()');
							$ridId=$ridIdQry['LAST_INSERT_ID()'];
							$a0Config['rid_a0_id'][$rid['rid_a0_id']]=$ridId;
						}else{
							if($rid['ridid']==''){
								$ridId=$a0Config['rid_a0_id'][$rid['rid_a0_id']];
							}else{
								$ridId=$rid['ridid'];
							}
							if($ridId!=''){
								if($a0Config['rid_inserted'][$ridId]!=1){
									SqlLQ('UPDATE dr_rid
											SET rid_title="'.$rid['ridtitle'].'",rid_status="'.$a0Config['a0_status_translation'][$rid['ridstatus']].'",rid_holder="'.$rid['ridholderid'].'",rid_holder_name="'.$ridHolderName.'",rid_creation="'.$rid['rid_creation_date'].'",rid_completion="'.$rid['rid_completion_date'].'",rid_closure="'.$rid['rid_closure_date'].'",rid_showstopper="'.$rid['ridshowstopper'].'",rid_action_plan="'.$rid['ridactionplan'].'",rid_a0_id="'.$rid['rid_a0_id'].'"
											WHERE rid_id="'.$ridId.'"');
									$a0Config['rid_inserted'][$ridId]=1;
								}
							}
						}
						if($actionId!='' && $actionId!=0 && $ridId!='' && $ridId!=0 && !$inValidationLoop) //JFM 12_01_16
						{
							SqlLQ('UPDATE dr_action SET rid="'.$ridId.'" WHERE action_id="'.$actionId.'"');
						}
					}
				}
			}
		}
	}
}

function checkCriteria($criteria,&$a0Config,$SESSION){
	if($criteria['status']==''){
		$criteria['status']=0;
	}

	if(is_array($a0Config['db_criteria_status'][$a0Config['ca']][$criteria['criteria_id']])){
		SqlLQ('UPDATE dr_criteria_status SET criteria_status="'.$a0Config['a0_status_translation'][$criteria['status']].'",criteria_focal_point="'.$criteria['action_by'].'",criteria_comments="'.$criteria['comment'].'"
					WHERE msn="'.$a0Config['msn'].'" AND ca="'.$a0Config['ca'].'" AND review_criteria="'.$criteria['criteria_id'].'"');
	}else{
		SqlLQ('INSERT INTO dr_criteria_status (msn,ca,review_criteria,criteria_status,criteria_focal_point,criteria_comments)
					VALUES ("'.$a0Config['msn'].'","'.$a0Config['ca'].'","'.$criteria['criteria_id'].'","'.$a0Config['a0_status_translation'][$criteria['status']].'","'.$criteria['action_by'].'","'.$criteria['comment'].'")');
	}
	if($a0Config['actions_inserted']==0){
		$rid=$criteria['rid'];
		$a0Config['criteria_id']=$criteria['criteria_id'];
		if(isset($rid['ridcode']) || isset($rid['rid_a0_id'])){
			actionCheckerLauncher($rid,$a0Config,$SESSION);
		}elseif(isset($rid[0]['ridcode']) || isset($rid[0]['rid_a0_id'])){
			foreach($rid as $r){
				actionCheckerLauncher($r,$a0Config,$SESSION);
			}
		}
	}
}

function cleanXmlString($nodeName,$nodeValue){
	if($nodeName!='comment' && $nodeName!='actiondescription' && $nodeName!='ridtitle'){
		$nodeValue=str_replace(array('\r\n','\n\r','\n','\r','
'),'',$nodeValue);
	}
	return utf8_decode(addslashes(trim($nodeValue)));
}

function dom_to_array($root){
	$result=array();
	if ($root->hasAttributes()){
		$attrs=$root->attributes;
		foreach($attrs as $i=>$attr){
			$result[$attr->name]=cleanXmlString('',$attr->value);
		}
	}
	$children=$root->childNodes;
	if ($children->length==1){
		$child=$children->item(0);
		if ($child->nodeType==XML_TEXT_NODE){
			$result['_value']=$child->nodeValue;
			if(count($result)==1){
				return cleanXmlString($child->nodeName,$result['_value']);
			}else{
				return cleanXmlString($child->nodeName,$result);
			}
		}
	}
	$group=array();
	for($i=0;$i<$children->length;$i++){
		$child=$children->item($i);
		if (!isset($result[$child->nodeName])){
			$result[$child->nodeName]=dom_to_array($child);
		}else{
			if(!isset($group[$child->nodeName])){
				$tmp=$result[$child->nodeName];
				$result[$child->nodeName]=array($tmp);
				$group[$child->nodeName]=1;
			}
			$result[$child->nodeName][]=dom_to_array($child);
		}
	}
	return (empty($result))?'':$result;
}

function getActionApplicability($caGroup,$a0Config,&$actionApplicability){
	if(!is_array($caGroup)){
		$caArray=explode(',',$caGroup);
		foreach($caArray as $ca){
			if(is_array($a0Config) && is_array($a0Config['ca_txt_id'])){
				$caId=$a0Config['ca_txt_id'][$ca];
			}else{
				$caId='';
			}
			if(is_numeric($ca) && $caId!=0 && $caId!=''){
				$validId='';
			}else{
				if($caId!=0 && $caId!=''){
					if($caId=='NULL'){
						$validId='';
					}else{
						$validId=$caId;
					}
				}else{
					$validId=$ca;
				}
			}
			if($validId!=''){
				$actionApplicability[]=$validId;
			}
		}
	}
}

function xmlError($errorCase){
	$errorTxt=array(	'no_rights'			=>'Not enough rights to perform the operation, or you did not upload the correct XML file (try to get the XML file by Forms=>Manage Forms=>Export Data).',
						'no_valid_key'		=>'Invalid Security Key. Maybe you are trying to upload the Report twice.',
						'missing_data'		=>'Mandatory Data is missing.',
						'incorrect_file'	=>'The file you tried to upload is not correct.\n\nYou need to upload the XML extract from the Review Report: go to the Adobe Acrobat tool and click on Forms=>Manage Forms=>Export Data.');
	
	?><script><?php
		?>alert('There has been an error while uploading the file. The server answered:\n\n<?=$errorTxt[$errorCase]?>');<?php
		/*?>parent.location='../home.php';<?php*/
		?>parent.location='../index.php';<?php
	?></script><?php
	exit();
}

$file=$_FILES['uploadedFile'];

$root=new DOMDocument();
$root->load($file['tmp_name']);
$fileArray=dom_to_array($root);

$mainInfo=$fileArray['A0Report']['part'];
$a0Version=$mainInfo['a0_version'];
$xmlKey=$mainInfo['key'];
if(is_array($mainInfo['ovStat']) || $mainInfo['ovStat']==''){
	$mainInfo['ovStat']=0;
} 

$caString=$mainInfo['ca_id'];
$caArray=explode(',',$caString);
		
$a0Config=array(
	'program'=>$mainInfo['program_id'],
	'coe'=>$mainInfo['coe_id'],
	'msn'=>$mainInfo['msn_id'],
	'wp'=>$mainInfo['wp_id'],
	'a0_ca'=>$caArray,
	'review_profile'=>$mainInfo['review_profile_id'],
	'a0_status_translation'=>array(0,2,1,3) //JFM 27_03_14
);

$a0Ids=sqlAsLi('SELECT a0_report_id
				FROM dr_a0_report
				WHERE msn='.$a0Config['msn'].'
					AND review_profile='.$a0Config['review_profile'].'
					AND ca IN ('.$caString.')','ca'); //JFM 07_04_14

if($file['error']==UPLOAD_ERR_OK && end(explode(".", $file['name']))=='xml')
{
	if(checkPermission('review_profile_id','upload',$a0Config['review_profile'],'check',$SESSION)==1)
	{
		foreach($a0Config as $k=>$v)
		{
			if($v=='')
			{
				xmlError('missing_data');
			}
		}
		
		
		if(is_array($caArray))
		{
			
			$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
			
			$caTxtId=SqlLi('SELECT c.ca_id,c.ca,
								w.wp_id,w.wp
							FROM c_ca AS c
								INNER JOIN c_cawp	AS cw	ON c.ca_id=cw.ca
								INNER JOIN c_wp		AS w	ON cw.wp=w.wp_id
							WHERE c.program="'.$a0Config['program'].'" AND c.coe="'.$a0Config['coe'].'"');
			if(is_array($caTxtId)){
				foreach($caTxtId as $c){
					if($a0Config['ca_txt_id'][$c['ca']]==''){
						$a0Config['ca_txt_id'][$c['ca']]=$c['ca_id'];
						$a0Config['wp_txt_id'][$c['wp']]=$c['wp_id'];
						$a0Config['ca_in_wp'][$c['wp_id']][]=$c['ca_id'];
					}else{
						$a0Config['ca_txt_id'][$c['ca']]='NULL';
					}
				}
			}

			$validKey=sqlAsLi('SELECT a0_report_id,ca,a0_report_upload_done
								FROM dr_a0_report
								WHERE msn='.$a0Config['msn'].'
									AND review_profile='.$a0Config['review_profile'].'
									AND xml_lock="'.$mainInfo['key'].'"
									AND user='.$viewAsUserId.'
									AND a0_report_upload_done=0','ca');
			
			if(is_array($validKey)){
				$invalidKeyFound=0;
				foreach($validKey as $v){
					if($v['a0_report_upload_done']==1){
						$invalidKeyFound=1;
					}
				}
			}else{
				$invalidKeyFound=1;
			}
			
			if($invalidKeyFound==0 || checkPermission('superadmin','superadmin',0,'check',$SESSION)==1)
			{
				
				//JFM 14_11_13
				
				//JFM 14_11_13
				$review=SqlAsLi('SELECT r.review_id,ra.ca,r.review_done,r.review_status
								FROM dr_review AS r
								INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
								WHERE ra.ca IN('.$caString.') 
								AND r.msn='.$a0Config['msn'].' 
								AND r.review_profile='.$a0Config['review_profile'],'ca');
				
				$a0Config['db_criteria_status']=SqlBDAsLi('SELECT ca,review_criteria,criteria_status,criteria_focal_point,criteria_comments FROM dr_criteria_status WHERE msn='.$a0Config['msn'].' AND ca IN('.$caString.')','ca','review_criteria',0,0);
												
				$ridActionQry=mysql_query('SELECT ac.action_id,ac.action_a0_id,rd.rid_id,rd.rid_a0_id
											FROM 			dr_action				AS ac
												INNER JOIN	dr_action_applicability	AS ap ON ac.action_id=		ap.action
												INNER JOIN	dr_review_criterion		AS cr ON ac.criteria=		cr.review_criterion_id
												INNER JOIN	dr_review_group			AS gr ON cr.review_group=	gr.group_id
												INNER JOIN	dr_review_profile		AS rp ON gr.review_type=	rp.review_type
												LEFT  JOIN	dr_rid					AS rd ON ac.rid=			rd.rid_id
											WHERE rp.review_profile_id='.$a0Config['review_profile'].'
												AND ac.msn='.$a0Config['msn'].'
												AND ap.ca IN('.$caString.')
												AND (
													ac.action_a0_id<>""
													OR rd.rid_a0_id<>""
												)
											GROUP BY ac.action_id',$p12) or die(mysql_error());
				
				while($r=mysql_fetch_assoc($ridActionQry)){
					if($r['action_a0_id']!=''){
						$a0Config['action_a0_id'][$r['action_a0_id']]=$r['action_id'];
					}
					if($r['rid_a0_id']!=''){
						$a0Config['rid_a0_id'][$r['rid_a0_id']]=$r['rid_id'];
					}
				}
				
				$a0Config['actions_inserted']=0;
				
				foreach($caArray as $ca)
				{
					
					$a0Config['ca']=$ca;
					
					if($review[$ca]['review_done']!=1 || $review[$ca]['review_status']!=$mainInfo['ovStat'])
					{
						if($review[$ca]['review_id']=='')
						{
							//JFM 14_11_13 SqlLQ('INSERT INTO dr_review (ca,msn,review_profile,review_done,review_status) VALUES ('.$ca.','.$a0Config['msn'].','.$a0Config['review_profile'].',1,'.$mainInfo['ovStat'].')');
							
							//JFM 14_11_13
							SqlLQ('INSERT INTO dr_review (msn,review_profile,review_done,review_status) VALUES ('.$a0Config['msn'].','.$a0Config['review_profile'].',1,'.$mainInfo['ovStat'].')');
							$reviewID=SqlQ('SELECT LAST_INSERT_ID() AS reviewID');
							SqlLQ('INSERT INTO dr_review_applicability (review,ca) VALUES (\''.$reviewID['reviewID'].'\',\''.$ca.'\')');
						}
						else
						{
							SqlLQ('UPDATE dr_review SET review_done=1,review_status='.$mainInfo['ovStat'].', remark="'.$mainInfo['remarks'].'" WHERE review_id='.$review[$ca]['review_id']); //JFM 27_03_14
						}
					}

					//JFM 11_03_14
					SqlLQ('UPDATE dr_review SET remark="'.$mainInfo['remarks'].'" WHERE review_id='.$review[$ca]['review_id']);
					
					$responsible=getResponsibles($a0Config['program'],$SESSION,1,$a0Config['ca'],'',1);
					foreach($responsible['config'] as $respGroup=>$r){
						foreach($r as $respRole=>$configId){
							$a0ResponsibleName=$mainInfo['responsiblegroup_'.$respGroup]['responsible_'.$respGroup.'_'.$respRole]['name'];
							if($a0ResponsibleName!=$responsible['name'][$respGroup][$respRole]){
								saveResponsible($a0Config['ca'],$responsible['config'][$respGroup][$respRole],$a0ResponsibleName,0);
							}
						}
					}
					
					$a0Topic=$fileArray['A0Report']['topic-list']['topic'];
					
					if($a0Topic['name']!=''){
						if($a0Topic['case']['criteria_id']!=''){
							checkCriteria($a0Topic['case'],$a0Config,$SESSION);
						}else{
							foreach($a0Topic['case'] as $criteria){
								checkCriteria($criteria,$a0Config,$SESSION);
							}
						}
					}else foreach($a0Topic as $crGroup){
						if($crGroup['case']['criteria_id']!=''){
							checkCriteria($crGroup['case'],$a0Config,$SESSION);
						}else{
							if(is_array($crGroup['case'])){
								foreach($crGroup['case'] as $criteria){
									checkCriteria($criteria,$a0Config,$SESSION);
								}
							}
						}
					}
					
					$a0Config['actions_inserted']=1;
				}
			}
			else
			{
				xmlError('no_valid_key');
			}
		}
		else
		{
			xmlError('missing_data');
		}
	}
	else
	{
		xmlError('no_rights');
	}

	foreach($a0Ids as $a0Id) //JFM 07_04_14
	{
		createLog('dr_log','a0_report_id','upload',$a0Id['a0_report_id'],'','',$SESSION);
	}

	?><script><?php
		?>alert('The file has been uploaded successfully. The page will now refresh.');<?php //JFM 12_01_16
		?>parent.location='../index.php';<?php //JFM 12_01_16
	?></script><?php
	//header("Location: home.php");
}else xmlError('incorrect_file');
storeSession($SESSION);
?>