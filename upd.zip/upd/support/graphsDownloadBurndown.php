<?php

if(empty($POST['filename'])) //JFM 11_08_14
{
	require_once('../security/checkExpiredSession.php');
	require_once('../../support.php');
	require_once('../../common/php/common.php');
	require_once('localSupport.php');
	require_once('form.php');
	require_once('zipfile.php');
	$POST=cleanArray($_POST);
}

foreach($POST as $k => $l)
{
	if($l=='null') $POST[$k]=0;
}

$calenderWeek=explode(',', $POST['cw']);
$actual=explode(',', $POST['actual']);
$predicted=explode(',', $POST['predicted']);
$green=explode(',', $POST['green']);


if(is_file('../output/sheet1.xml')) unlink('../output/sheet1.xml');
if(is_file('../output/chart1.xml')) unlink('../output/chart1.xml');
if(is_file('../output/Book2.zip')) unlink('../output/Book2.zip');
if(is_file('../output/Book2.xlsx')) unlink('../output/Book2.xlsx');

$sheet1xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" mc:Ignorable="x14ac" xmlns:x14ac="http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac"><dimension ref="A1:D'.count($calenderWeek).'"/><sheetViews><sheetView tabSelected="1" workbookViewId="0"><selection activeCell="B13" sqref="B13"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="14.25" x14ac:dyDescent="0.2"/><sheetData>';

for ($i=0; $i < count($calenderWeek); $i++) 
{ 
	$j=$i+1;
	$sheet1xml.='<row r="'.$j.'" spans="1:3" x14ac:dyDescent="0.2"><c r="A'.$j.'"><v>'.$calenderWeek[$i].'</v></c><c r="B'.$j.'"><v>'.$actual[$i].'</v></c><c r="C'.$j.'"><v>'.$predicted[$i].'</v></c><c r="D'.$j.'"><v>'.$green[$i].'</v></c></row>';
}


$sheet1xml.='</sheetData><pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/><drawing r:id="rId1"/></worksheet>';

$chart1xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><c:date1904 val="0"/><c:lang val="en-GB"/><c:roundedCorners val="0"/><mc:AlternateContent xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"><mc:Choice Requires="c14" xmlns:c14="http://schemas.microsoft.com/office/drawing/2007/8/2/chart"><c14:style val="102"/></mc:Choice><mc:Fallback><c:style val="2"/></mc:Fallback></mc:AlternateContent><c:clrMapOvr bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><c:chart><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr/></a:pPr><a:r><a:rPr lang="en-GB" sz="2000" b="1"/><a:t>'.$POST['title'].'</a:t></a:r></a:p></c:rich></c:tx><c:layout/><c:overlay val="1"/><c:spPr><a:noFill/><a:ln w="25400"><a:noFill/></a:ln></c:spPr></c:title><c:autoTitleDeleted val="0"/><c:plotArea><c:layout><c:manualLayout><c:layoutTarget val="inner"/><c:xMode val="edge"/><c:yMode val="edge"/><c:x val="9.603721771282446E-2"/><c:y val="0.13723008102248088"/><c:w val="0.75654290931223356"/><c:h val="0.72341004199176495"/></c:manualLayout></c:layout><c:barChart><c:barDir val="col"/><c:grouping val="stacked"/><c:varyColors val="0"/><c:ser><c:idx val="0"/><c:order val="1"/><c:tx><c:v>Actual</c:v></c:tx><c:invertIfNegative val="0"/><c:cat><c:numRef><c:f>Sheet1!$A$1:$A$'.count($calenderWeek).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.count($calenderWeek).'"/>';

for ($i=0; $i < count($calenderWeek); $i++) 
{
	$chart1xml.='<c:pt idx="'.$i.'"><c:v>'.$calenderWeek[$i].'</c:v></c:pt>';
}

$chart1xml.='</c:numCache></c:numRef></c:cat><c:val><c:numRef><c:f>Sheet1!$B$1:$B$'.count($calenderWeek).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.count($calenderWeek).'"/>';

for ($i=0; $i < count($calenderWeek); $i++) 
{
	$chart1xml.='<c:pt idx="'.$i.'"><c:v>'.$actual[$i].'</c:v></c:pt>';
}

$chart1xml.='</c:numCache></c:numRef></c:val></c:ser>';

//-----
$chart1xml.='<c:ser><c:idx val="1"/><c:order val="2"/><c:tx><c:v>Green</c:v></c:tx><c:invertIfNegative val="0"/><c:dLbls><c:showLegendKey val="0"/><c:showVal val="1"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/><c:showBubbleSize val="0"/></c:dLbls><c:val><c:numRef><c:f>Sheet1!$D$1:$D$'.count($calenderWeek).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.count($calenderWeek).'"/>';

for ($i=0; $i < count($calenderWeek); $i++) 
{
	$chart1xml.='<c:pt idx="'.$i.'"><c:v>'.$green[$i].'</c:v></c:pt>';
}

$chart1xml.='</c:numCache></c:numRef></c:val></c:ser>';
//-----

$chart1xml.='<c:dLbls><c:showLegendKey val="0"/><c:showVal val="1"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/><c:showBubbleSize val="0"/></c:dLbls><c:gapWidth val="150"/><c:overlap val="100"/><c:axId val="115080576"/><c:axId val="125565952"/></c:barChart><c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/><c:ser><c:idx val="3"/><c:order val="0"/><c:tx><c:v>Predicted</c:v></c:tx><c:spPr><a:ln w="38100"><a:solidFill><a:srgbClr val="000000"/></a:solidFill><a:prstDash val="solid"/></a:ln></c:spPr><c:marker><c:symbol val="none"/></c:marker><c:cat><c:numRef><c:f>Sheet1!$A$1:$A$'.count($calenderWeek).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.count($calenderWeek).'"/>';

for ($i=0; $i < count($calenderWeek); $i++) 
{
	$chart1xml.='<c:pt idx="'.$i.'"><c:v>'.$calenderWeek[$i].'</c:v></c:pt>';
}

$chart1xml.='</c:numCache></c:numRef></c:cat><c:val><c:numRef><c:f>Sheet1!$C$1:$C$'.count($calenderWeek).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.count($calenderWeek).'"/>';

for ($i=0; $i < count($calenderWeek); $i++) 
{
	$chart1xml.='<c:pt idx="'.$i.'"><c:v>'.$predicted[$i].'</c:v></c:pt>';
}

$chart1xml.='</c:numCache></c:numRef></c:val><c:smooth val="0"/></c:ser><c:dLbls><c:showLegendKey val="0"/><c:showVal val="1"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/><c:showBubbleSize val="0"/></c:dLbls><c:marker val="1"/><c:smooth val="0"/><c:axId val="115080576"/><c:axId val="125565952"/></c:lineChart><c:catAx><c:axId val="115080576"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr/></a:pPr><a:r><a:rPr lang="en-GB" sz="2000"/><a:t>Calender</a:t></a:r><a:r><a:rPr lang="en-GB" sz="2000" baseline="0"/><a:t> Week</a:t></a:r><a:endParaRPr lang="en-GB" sz="2000"/></a:p></c:rich></c:tx><c:layout/><c:overlay val="0"/></c:title><c:numFmt formatCode="General" sourceLinked="1"/><c:majorTickMark val="out"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:txPr><a:bodyPr rot="-2700000" vert="horz"/><a:lstStyle/><a:p><a:pPr><a:defRPr/></a:pPr><a:endParaRPr lang="en-US"/></a:p></c:txPr><c:crossAx val="125565952"/><c:crosses val="autoZero"/><c:auto val="0"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:tickLblSkip val="1"/><c:noMultiLvlLbl val="0"/></c:catAx><c:valAx><c:axId val="125565952"/><c:scaling><c:orientation val="minMax"/><c:max val="'.(($POST['max']) ? $POST['max'] : $predicted[0]).'"/><c:min val="0"/></c:scaling><c:delete val="0"/><c:axPos val="l"/><c:majorGridlines/><c:title><c:tx><c:rich><a:bodyPr rot="-5400000" vert="horz"/><a:lstStyle/><a:p><a:pPr><a:defRPr/></a:pPr><a:r><a:rPr lang="en-GB" sz="2000"/><a:t>Number of Items</a:t></a:r></a:p></c:rich></c:tx><c:layout/><c:overlay val="0"/></c:title><c:numFmt formatCode="General" sourceLinked="1"/><c:majorTickMark val="out"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:txPr><a:bodyPr rot="0" vert="horz"/><a:lstStyle/><a:p><a:pPr><a:defRPr/></a:pPr><a:endParaRPr lang="en-US"/></a:p></c:txPr><c:crossAx val="115080576"/><c:crosses val="autoZero"/><c:crossBetween val="between"/><c:minorUnit val="1"/></c:valAx></c:plotArea><c:legend><c:legendPos val="r"/><c:layout><c:manualLayout><c:xMode val="edge"/><c:yMode val="edge"/><c:x val="0.83726602298106056"/><c:y val="0.44970608239187493"/><c:w val="0.14857019479248898"/><c:h val="0.12290713226064132"/></c:manualLayout></c:layout><c:overlay val="0"/><c:spPr><a:solidFill><a:schemeClr val="bg1"/></a:solidFill></c:spPr></c:legend><c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/><c:showDLblsOverMax val="0"/></c:chart><c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="1000" b="0" i="0" u="none" strike="noStrike" baseline="0"><a:solidFill><a:srgbClr val="000000"/></a:solidFill><a:latin typeface="Calibri"/><a:ea typeface="Calibri"/><a:cs typeface="Calibri"/></a:defRPr></a:pPr><a:endParaRPr lang="en-US"/></a:p></c:txPr><c:printSettings><c:headerFooter/><c:pageMargins b="0.75000000000000122" l="0.70000000000000062" r="0.70000000000000062" t="0.75000000000000122" header="0.30000000000000032" footer="0.30000000000000032"/><c:pageSetup/></c:printSettings></c:chartSpace>';

$fp=fopen('../output/sheet1.xml','w');
fwrite($fp,$sheet1xml);
fclose($fp);

$fp=fopen('../output/chart1.xml','w');
fwrite($fp,$chart1xml);
fclose($fp);


$zip = new ZipArchive();

$zip->open('../output/Book2.zip', ZipArchive::CREATE);

$source=str_replace('\\', '/', realpath('../archive/Book2/'));
$flag=basename($source).'/';

$files= new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source),RecursiveIteratorIterator::SELF_FIRST);

foreach($files as $file)
{
	$file=str_replace('\\', '/', realpath($file));
	
	if(is_dir($file)===true)
	{
		$zip->addEmptyDir(str_replace($source.'/', '', $file));
	}
	else if(is_file($file))
	{
		if(strpos($file, 'sheet1') && !strpos($file, 'rels')) 
		{
			$fileNew='../output/sheet1.xml';
		}
		else if(strpos($file, 'chart1')  && !strpos($file, 'rels')) 
		{
			$fileNew='../output/chart1.xml';
		}
		else $fileNew=$file;

		$zip->addFromString(str_replace($source.'/', '', $file), file_get_contents($fileNew));
	}
}

$zip->close();

storeSession($SESSION);

if(empty($POST['filename'])) //JFM 11_08_14
{
	rename("../output/Book2.zip", "../output/Book2.xlsx");

	if(is_file('../output/sheet1.xml')) unlink('../output/sheet1.xml');
	if(is_file('../output/chart1.xml')) unlink('../output/chart1.xml');

	header('Content-type: application/octet-stream');
	header('Content-Disposition: attachment; filename=Book2.xlsx');
	header("Cache-Control: private");
	header("Pragma: private"); //02_10_14
	readfile('../output/Book2.xlsx');
}
else
{
	rename("../output/Book2.zip", "../output/".$POST['filename'].".xlsx");
	if(is_file('../output/sheet1.xml')) unlink('../output/sheet1.xml');
	if(is_file('../output/chart1.xml')) unlink('../output/chart1.xml');
}

?>