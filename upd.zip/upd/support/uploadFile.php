<?php
function uploadFile($FILES,$table,$imageFileField,$dir){
	$imageFile=SqlSLi('SELECT '.$imageFileField.' FROM '.$table.' WHERE '.$imageFileField.'!=""',$t.'_image_file');
	if($imageFile==''){
		$imageFile=array();
	}

	$fileArr=explode('.',$FILES['uploadedFile']['name']);
	$fileExtension=$fileArr[count($fileArr)-1];
	do{
		$fileName=randomString(16).'.'.$fileExtension;
	}while(in_array($fileName,$imageFile));
	
	//$fileName=$newFileName.'.'.$fileExtension;
	$name='../img/'.$dir.'/'.$fileName;
	$jsName='img/'.$dir.'/'.$fileName;
	
	$returnArray=array('name'=>$name,'jsName'=>$jsName,'newFileName'=>$fileName);
	
	if(move_uploaded_file($FILES['uploadedFile']['tmp_name'], $name)){
		$returnArray['upload_ok']=1;
	}
	
	return $returnArray;
}

?><script language="javascript"src="../js/overlib.js"type="text/javascript"><!-- overLIB (c) Erik Bosrup --></script><?php
/*?><script language="javascript"src="../common/js/common.js"type="text/javascript"></script><?php*/
?><script language="javascript"src="../js/home.js"type="text/javascript"></script><?php
?><script language="javascript"src="../js/upload.js"type="text/javascript"></script><?php
$FILES=$_FILES;
$uploadedFile=0;
if($FILES['uploadedFile']['size']<1024000){
	require_once('header.php');
	require_once('../security/checkExpiredSession.php');
	require_once('../../support.php');
	require_once('../../common/php/common.php');
	$POST=cleanArray($_POST);
	
	switch($POST['type']){
		case 'caPicture':
			$t=$POST['target'];
		
			$existingImage=SqlAsArr('SELECT '.$t.'_id,'.$t.'_image_file FROM c_'.$t.' WHERE '.$t.'_id IN('.$POST['target_id'].')',$t.'_id',$t.'_image_file');

			$caWpArr=explode(',',$POST['target_id']);
			$firstItem=1;
			
			foreach($caWpArr as $c){
				if($existingImage[$c]!='' && file_exists('../img/'.$t.'/'.$existingImage[$c])){
					unlink('../img/'.$t.'/'.$existingImage[$c]);
				}
				if($firstItem==1){
					$firstItem=0;
		
					$img=uploadFile($FILES,'c_'.$t,$t.'_image_file',$t);
		
					if($img['upload_ok']==1){
						$uploadedFile=1;
						$imgProp=getimagesize($img['name']);
						if($imgProp[0]>350){
							$width=350;
							$scaleRatio=$imgProp[0]/350;
							$height=$imgProp[1]/$scaleRatio;
						}else{
							$width=$imgProp[0];
							$height=$imgProp[1];
						}
						if($height>220){
							$scaleRatio=$height/220;
							$height=220;
							$width=$width/$scaleRatio;
						}
						?><script>uploadCaWpImgOK('<?=$img['jsName']?>','<?=$width?>','<?=$height?>');</script><?php
					}
				}
				
				SqlLQ('UPDATE c_'.$t.' SET '.$t.'_image_file="'.$img['newFileName'].'" WHERE '.$t.'_id="'.$c.'"');
				createLog('dr_log',''.$t.'_image_file','edit',$c,'','',$SESSION);
			}
			$uploadedFile=1;
		break;
		case 'changeScreenshot':
			$img=uploadFile($FILES,'dr_change_screenshot','change_image_file','changeScreenshot');
			
			if($img['upload_ok']==1){
				$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
				SqlLQ('INSERT INTO dr_change_screenshot (`change`,change_image_file,change_screenshot_creation,change_screenshot_created_by,change_screenshot_description)
						VALUES ("'.$POST['change_id'].'","'.$img['newFileName'].'",NOW(),"'.$viewAsUserId.'","'.$POST['change_screenshot_description'].'")');
				$screenshotId=SqlQ('SELECT LAST_INSERT_ID()');
				createLog('dr_log','change_image_file','create',$screenshotId['LAST_INSERT_ID()'],'','',$SESSION);
				$screenshotCount=SqlQ('SELECT COUNT(*) FROM dr_change_screenshot WHERE `change`="'.$POST['change_id'].'"');
				$uploadedFile=1;
				?><script>updateData('change_screenshot_<?=$POST['change_id']?>%%%screenshot%%%<?=$POST['change_id']?>###<?=$screenshotCount['COUNT(*)']?>');</script><?php
			}else{
				?><script>alert('The file was not correctly uploaded');</script><?php
			}
		break;
	}
}else{
	?><script>alert('The picture you tried to upload was too big.\n\nRemember that the upload limit is 1 MB.');</script><?php
	$uploadedFile=1;
}
if($uploadedFile==0){
	?><script>uploadCaWpImgKO();</script><?php
}
storeSession($SESSION);
?>