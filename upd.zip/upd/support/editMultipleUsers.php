<?php

/*
 * Function for Bulk Edit users
 * Fix for US #032 Bulk user upload (suggested by ICT)
 * Created by: Infosys Ltd
 * Version: 4.3
 */
function drawPermissionsBulkUsers($title,$object,$applicability,$view,$edit,$create,$delete,$export,$upload,$right,$SESSION,$user=0,$hidden=0,$rowId=0,$accessAction=''){
    
        $userAction=array('view','edit','create','delete','export','upload');
        
	?><tr class="infoRow" id="<?=$rowId?>" style="display:<?=($hidden)?'none':''?>"><?php
		?><td class="paramDef"><?php
			echo $title;
		?></td><?php
		foreach($userAction as $action){
			?><td class="chk"><?php
				if($$action==1 && checkPermission($object,$action,$applicability,'check',$SESSION)==1){
					drawInteractiveCheckBulkUsers($SESSION['object'][$object],$SESSION['user_action'][$action],$applicability,$right,'bulkEdit',0,'','',$onClick,$SESSION['bulkEdit']['users'],$accessAction);
					
				}else{?><input disabled type="checkbox"><?php }
			?></td><?php
		}
	?></tr><?php
}

/*
 * Function for Bulk Edit users
 * Fix for: Bulk user upload (suggested by ICT)
 * Created by: Infosys Ltd
 * Version: 4.3
 */
function drawInteractiveCheckBulkUsers($object,$action,$applicability,$array,$type,$inverted,$reviewclick='',$disabled='',$onClick='',$user='',$accessAction=''){

	$active=$array[$object][$action][$applicability];
        $row_name = 'cbrow-'.$applicability;
	?><input<?php
		if(($active==1 && $inverted==0)||($active==0 && $inverted==1)){
                    ?> checked<?php
		}
		if($disabled==1){
                    ?> disabled<?php
		}		
                ?> class="<?=$row_name?> EditUserCheck" name="EditUserCheck" id="<?=$type,'-',$object,'-',$action,'-',$applicability?>"onClick="<?=$onClick?>checkChange(this,'<?=$type?>','<?=$reviewclick?>');"type="checkbox" value="1"><?php
		
		if($accessAction == "provide") {
                    ?> <span class = "bkedit" name = "bkedit" id="Checkedid<?=$type,'-',$object,'-',$action,'-',$applicability?>" style="display:none;float:right;color:green;">&#10003;</span><?php
		}
		else if($accessAction == "remove") {
                    ?> <span class = "bkedit" name = "bkedit" id="Checkedid<?=$type,'-',$object,'-',$action,'-',$applicability?>" style="display:none;float:right;color:red;">&cross;</span><?php
		}
}

/*
 * Function to create General Permission section in User Mangement
 */
function drawGnInfoPermissions($title,$object,$applicability,$view,$edit,$create,$delete,$export,$upload,$right,$SESSION,$user=0,$hidden=0,$rowId=0,$accessAction=''){
        $userAction=array('view','edit','create','delete','export','upload');
	?><tr class="infoRow" id="<?=$rowId?>"><?php
		?><td class="paramDef"><?php
			echo $title;
		?></td><?php
		foreach($userAction as $action){
			?><td class="chk"><?php
				if($$action==1 && checkPermission($object,$action,$applicability,'check',$SESSION)==1){
					drawInteractiveCheckGnInfo($SESSION['object'][$object],$SESSION['user_action'][$action],$applicability,$right,'bulkEdit',0,'','',$onClick,$SESSION['bulkEdit']['users'],$accessAction);
					
				}else{?><input disabled type="checkbox"><?php }
			?></td><?php
		}
	?></tr><?php
}
//Function for defining checkbox for General permission section
function drawInteractiveCheckGnInfo($object,$action,$applicability,$array,$type,$inverted,$reviewclick='',$disabled='',$onClick='',$users=array(),$accessAction=''){
	$active=$array[$object][$action][$applicability];
        $row_name = 'cbrow-'.$applicability;
	?><input<?php
		if(($active==1 && $inverted==0)||($active==0 && $inverted==1)){
                    ?> checked<?php
		}
		if($disabled==1){
                    ?> disabled<?php
		}		
                ?> class="<?=$row_name?> EditGenUserCheck" name="EditGenUserCheck" id="gen<?=$type,'-',$object,'-',$action,'-',$applicability?>"onClick="<?=$onClick?>checkChange(this,'<?=$type?>','<?=$reviewclick?>');"type="checkbox" value="1"><?php
		
		if($accessAction == "provide") {
                    ?> <span class = "bkedit" name = "bkedit" id="Checkedidgen<?=$type,'-',$object,'-',$action,'-',$applicability?>" style="display:none;float:right;color:green;">&#10003;</span><?php
		}
		else if($accessAction == "remove") {
                    ?> <span class = "bkedit" name = "bkedit" id="Checkedidgen<?=$type,'-',$object,'-',$action,'-',$applicability?>" style="display:none;float:right;color:red;">&cross;</span><?php
		}
}

?>