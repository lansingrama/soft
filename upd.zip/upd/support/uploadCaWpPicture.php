<script language="javascript"src="../js/upload.js"type="text/javascript"></script><?php

$FILES=$_FILES;

$uploadedFile=0;

if($FILES['uploadedFile']['size']<1024000){
	require_once('header.php');
	require_once('../../support.php');
	require_once('../../common/php/common.php');

	session_start();
	$SESSION=$_SESSION;
	$POST=cleanArray($_POST);
	$t=$POST['target'];



	$imageFile=SqlSLi('SELECT '.$t.'_image_file FROM c_'.$t.' WHERE '.$t.'_image_file!=""',$t.'_image_file');
	$existingImage=SqlAsArr('SELECT '.$t.'_id,'.$t.'_image_file FROM c_'.$t.' WHERE '.$t.'_id IN('.$POST['target_id'].')',$t.'_id',$t.'_image_file');
	if($imageFile=='')$imageFile=array();
	$caWpArr=explode(',',$POST['target_id']);
	$firstItem=1;

	foreach($caWpArr as &$c)
	{
		if($existingImage[$c]!='' && file_exists('../img/'.$t.'/'.$existingImage[$c]))
		{
			unlink('../img/'.$t.'/'.$existingImage[$c]);
		}

		if($firstItem==1)
		{
			$firstItem=0;

			$fileArr=explode('.',$FILES['uploadedFile']['name']);

			$fileExtension=$fileArr[count($fileArr)-1];

			//echo $fileExtension,'<br>';

			do
			{
				$newFileName=randomString(16).'.'.$fileExtension;
			}
			while(in_array($newFileName,$imageFile));



			$fileName=$newFileName.'.'.$fileExt;
			$name='../img/'.$t.'/'.$fileName;
			$jsName='img/'.$t.'/'.$fileName;

			if(move_uploaded_file($FILES['uploadedFile']['tmp_name'], $name))
			{
				$uploadedFile=1;
				$imgProp=getimagesize($name);

				if($imgProp[0]>350)
				{
					$width=350;
					$scaleRatio=$imgProp[0]/350;
					$height=$imgProp[1]/$scaleRatio;
				}
				else
				{
					$width=$imgProp[0];
					$height=$imgProp[1];
				}

				if($height>220)
				{
					$scaleRatio=$height/220;
					$height=220;
					$width=$width/$scaleRatio;
				}

				?><script>uploadCaWpImgOK('<?=$jsName?>','<?=$width?>','<?=$height?>');</script><?php
			}
		}

		SqlLQ('UPDATE c_'.$t.' SET '.$t.'_image_file="'.$newFileName.'" WHERE '.$t.'_id="'.$c.'"');

		createLog('dr_log',''.$t.'_image_file','edit',$c,'','',$SESSION);
	}

	$uploadedFile=1;

}
else
{
	?><script>alert('The picture you tried to upload was too big.\n\nRemember that the upload limit is 1 MB.');</script><?php
	$uploadedFile=1;
}

if($uploadedFile==0)
{
	?><script>uploadCaWpImgKO();</script><?php
}

?>