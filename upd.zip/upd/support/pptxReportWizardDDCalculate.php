<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');

$POST = cleanArray($_POST);

$programOut='';
if(!empty($POST['program']))
{
	foreach ($POST['program'] as $programId) 
	{
		$programOut.=$programId.',';
	}
}

$coeOut='';
if(!empty($POST['coe']))
{
	foreach ($POST['coe'] as $coeId) 
	{
		$coeOut.=$coeId.',';
	}
}

$perimeterOut='';
if(!empty($POST['perimeter']))
{
	foreach ($POST['perimeter'] as $perimeterId) 
	{
		$perimeterOut.=$perimeterId.',';
	}
}

$msnOut='';
if(!empty($POST['msn']))
{
	foreach ($POST['msn'] as $msnId) 
	{
		$msnOut.=$msnId.',';
	}
}

switch($POST['nextBox'])
{
	case 'msn':
		if($programOut !=',')
			$ddList=allowedSimpleObject('msn','msn',$SESSION,'c_','program IN('.trim($programOut,",").')','view','','ORDER BY msn ASC');
	break;

	case 'perimeter':
		if($programOut !=',')
			$ddList=allowedSimpleObject('perimeter','perimeter',$SESSION,'c_','program IN('.trim($programOut,",").')','view','','ORDER BY perimeter ASC');
	break;

	case 'review':
		if($programOut !=',' && $coeOut !=',')
		{
			$itemsList=SqlLi('SELECT rp.review_profile_id, rt.review_type_id, rt.review_type 
								FROM dr_review_profile AS rp 
								INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
								WHERE rt.area='.getFilter('area','filter',0,$SESSION).'
								AND program IN('.trim($programOut,",").') AND coe IN ('.trim($coeOut,",").')');

			if(is_array($itemsList))
			{
				foreach($itemsList as $k=>$v)
				{
					if(checkPermission('review_profile_id','view',$v['review_profile_id'],'check',$SESSION,0)==1 || 
						checkPermission('dr_review_profile_general','view',0,'check',$SESSION,0)==1)
					{
						$ddList[$v['review_type_id']]=$v['review_type'];
					 }
				}
			}
		}
	break;

	case 'ca':
		if($programOut !=',' && $coeOut !=',' && $perimeterOut !=',' && $msnOut !=',')
		{
			$ddList=SqlAsArr('SELECT GROUP_CONCAT(ca.ca_id SEPARATOR \',\') as ca_ids, ca.ca FROM c_ca AS ca
									INNER JOIN c_cawp AS cawp ON cawp.ca = ca.ca_id
									WHERE perimeter IN ('.trim($perimeterOut,",").') 
													AND coe IN ('.trim($coeOut,",").') 
													AND program IN ('.trim($programOut,",").')
													AND cawp.msn IN ('.trim($msnOut,",").')
													AND cawp.cawp_disabled=0
													GROUP BY ca', 'ca_ids', 'ca');
		}
	break;
}

$answer='noBlank&&&';

if(is_array($ddList))
{
	$firstItem=0;
	generateSimpleResponse($answer,$firstItem,$ddList);
}

echo 'OK|||',$answer;
storeSession($SESSION);

?>