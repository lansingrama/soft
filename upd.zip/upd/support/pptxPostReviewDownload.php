<?php

//JFM 28_10_15: Side note; this file is very messy. It's kind of a mix of code from different files all smooshed together.
//				It can be optimised a hell of a lot but I simply don't have the time to do it. So whoever is reading this,
//				if you want to give it a go, go for it!

require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../../common/php/zip.lib.php');
require_once('localSupport.php');
require_once('form.php');

function formatValueForXML($string)
{
	return utf8_encode(str_replace("&#8230;", "",str_replace(">", "&gt;",str_replace("<", "&lt;",str_replace("&", "&amp;", $string)))));
}

function calculatePieCharts(&$action, &$actionOutstandingRows, &$actionRed, &$actionAmber, &$actionGreen, &$actionBlue, $SESSION, $ridFlag=0)
{
	//Action Pie charts & Actions outstanding table.
	switch ($action['status']) 
	{
		case 0:
			$actionRed++;
			
			if($action['holder']==0) $action['holder'] = formatValueForXML($action['holder_name']);
			else $action['holder'] = formatValueForXML($SESSION['user_list'][$action['holder']]);
			if($action['validator']==0) $action['validator'] = formatValueForXML($action['validator_name']);
			else $action['validator'] = formatValueForXML($SESSION['user_list'][$action['validator']]);

			if($ridFlag) $actionOptionArray=Array('RED',$action['rid_code'],formatValueForXML($action['assigned_actions']),formatValueForXML($action['rid_title']),$action['rid_showstopper'],$action['rid_creation'],$action['rid_completion'],$action['holder'],$action['validator']);
			else $actionOptionArray=Array('RED',$action['action_code'],formatValueForXML($action['criteria_position']),formatValueForXML($action['action_description']),formatValueForXML($action['action_remark']),$action['action_creation'],$action['action_completion'],$action['holder'],$action['validator']);

			$actionOutstandingRows.='<a:tr h="370840">';

			foreach ($actionOptionArray as $uselessKey => $value) 
			{
				$actionOutstandingRows.='<a:tc><a:txBody><a:bodyPr /><a:lstStyle /><a:p><a:pPr algn="ctr" /><a:r>';

				if($value == 'RED') $actionOutstandingRows.='<a:rPr lang="en-GB" sz="1050" dirty="0" smtClean="0"><a:solidFill><a:schemeClr val="accent6"/></a:solidFill></a:rPr>';
				else $actionOutstandingRows.='<a:rPr lang="en-GB" sz="1050" dirty="0" smtClean="0" />';

				$actionOutstandingRows.='<a:t>'.$value.'</a:t>';
				$actionOutstandingRows.='</a:r><a:endParaRPr lang="en-GB" sz="1050" /></a:p></a:txBody><a:tcPr /></a:tc>';
			}

			$actionOutstandingRows.='</a:tr>';
		break;
		case 1:
			$actionAmber++;

			if($action['holder']==0) $action['holder'] = formatValueForXML($action['holder_name']);
			else $action['holder'] = formatValueForXML($SESSION['user_list'][$action['holder']]);
			if($action['validator']==0) $action['validator'] = formatValueForXML($action['validator_name']);
			else $action['validator'] = formatValueForXML($SESSION['user_list'][$action['validator']]);

			if($ridFlag) $actionOptionArray=Array('AMBER',$action['rid_code'],formatValueForXML($action['assigned_actions']),formatValueForXML($action['rid_title']),$action['rid_showstopper'],$action['rid_creation'],$action['rid_completion'],$action['holder'],$action['validator']);
			else $actionOptionArray=Array('AMBER',$action['action_code'],formatValueForXML($action['criteria_position']),formatValueForXML($action['action_description']),formatValueForXML($action['action_remark']),$action['action_creation'],$action['action_completion'],$action['holder'],$action['validator']);

			$actionOutstandingRows.='<a:tr h="370840">';

			foreach ($actionOptionArray as $uselessKey => $value) 
			{
				$actionOutstandingRows.='<a:tc><a:txBody><a:bodyPr /><a:lstStyle /><a:p><a:pPr algn="ctr" /><a:r>';
				
				if($value == 'AMBER') $actionOutstandingRows.='<a:rPr lang="en-GB" sz="1050" dirty="0" smtClean="0"><a:solidFill><a:schemeClr val="accent4"/></a:solidFill></a:rPr>';
				else $actionOutstandingRows.='<a:rPr lang="en-GB" sz="1050" dirty="0" smtClean="0" />';

				$actionOutstandingRows.='<a:t>'.$value.'</a:t>';
				$actionOutstandingRows.='</a:r><a:endParaRPr lang="en-GB" sz="1050" /></a:p></a:txBody><a:tcPr /></a:tc>';
			}

			$actionOutstandingRows.='</a:tr>';

		break;
		case 2:
			$actionGreen++;
		break;
		case 3:
			$actionBlue++;
		break;
	}
}

function fillBurnDownArrays($action, &$graphBurnDown, &$graphBurnDownTotals)
{
	if(!empty($action['week_number'])) 
	{
		if($action['status']==3)
		{
			$graphBurnDown[$action['week_number']]['week_number']=$action['week_number'];
			$graphBurnDown[$action['week_number']]['total_validated']++;
			$graphBurnDownTotals['total_validated_all']++;
		}
	}
	if(!empty($action['week_number_planned'])) 
	{
		$graphBurnDown[$action['week_number_planned']]['week_number']=$action['week_number_planned'];
		$graphBurnDown[$action['week_number_planned']]['total_planned']++;
		$graphBurnDownTotals['total_planned_all']++;
	}	

	$actionsHistory=explode(',',$action['history']);

	if(!empty($actionsHistory))
	{
		$alreadyCalledWeekNumber = array();

		foreach($actionsHistory as $actionsHistoryInfo)
		{
			$actionsHistoryInfoSplit=explode("---",$actionsHistoryInfo);

			$weekNumber = date("YW", strtotime($actionsHistoryInfoSplit[0]));

			if($actionsHistoryInfoSplit[2] == 2)
			{
				$graphBurnDown[$weekNumber]['week_number']=$weekNumber;
				$graphBurnDown[$weekNumber]['total_green']++;
			}
			if($actionsHistoryInfoSplit[1] == 2)
			{
				$graphBurnDown[$weekNumber]['week_number']=$weekNumber;

				if(empty($graphBurnDown[$weekNumber]['total_green']))
					$graphBurnDown[$weekNumber]['total_green']=0;

				$graphBurnDown[$weekNumber]['total_green']--;
			}
		}
	}
}

function sortBurnDownArrays($graphBurnDown, $graphBurnDownTotals, &$burnDownWeeks, &$burnDownActual, &$burnDownPredicted, &$burnDownGreen)
{
	ksort($graphBurnDown);
	reset($graphBurnDown);
	$firstKey=key($graphBurnDown);
	end($graphBurnDown);
	$lastKey=key($graphBurnDown);

	for ($i=$firstKey; $i < $lastKey; $i++) 
	{
		if(substr($i, -2)==53) $i+=48;

		if(empty($graphBurnDown[$i])) 
		{
			$graphBurnDown[$i]['week_number']=$i;
			$graphBurnDown[$i]['total_validated']=0;
			$graphBurnDown[$i]['total_planned']=0;
			$graphBurnDown[$i]['total_green']=0;
		}
	}

	ksort($graphBurnDown);

	$totalValidated=0;
	$totalPlanned=0;
	$totalGreen=0;

	foreach ($graphBurnDown as $week => $details) 
	{
		if(date('YW') >= $week)
		{
			$totalValidated+=$graphBurnDown[$week]['total_validated'];
			$graphBurnDown[$week]['total_validated_in_order']=$totalValidated;
			$totalGreen+=$graphBurnDown[$week]['total_green'];
			$graphBurnDown[$week]['total_green_in_order']=$totalGreen;
		}
		else 
		{
			$graphBurnDown[$week]['total_validated_in_order']=0;
			$graphBurnDown[$week]['total_green_in_order']=0;
		}

		$totalPlanned+=$graphBurnDown[$week]['total_planned'];
		$graphBurnDown[$week]['total_planned_in_order']=$totalPlanned;
	}

	foreach ($graphBurnDown as $week => $details) 
	{
		$burnDownWeeks[] = substr($details['week_number'], -2);
		$burnDownActual[] =  $details['total_validated_in_order'];
		$burnDownPredicted[] = $details['total_planned_in_order'];
		$burnDownGreen[] = $details['total_green_in_order'];
	}
}

$GET=cleanArray($_GET);

//PUT FILES IN MEMORY
//---------------------------------------------------

$criteriaPieChart 		=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/charts/chart1.xml');
$criteriaStackedChart 	=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/charts/chart2.xml');
$actionPieChart 		=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/charts/chart3.xml');
$actionBrunDownChart 	=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/charts/chart4.xml');
$actionGraphSlide	 	=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/slides/slide3.xml');
$actionOutstandingTable	=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/slides/slide4.xml');
$ridPieChart 			=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/charts/chart5.xml');
$ridBurnDownChart	 	=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/charts/chart6.xml');
$ridOutstandingTable	=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/slides/slide6.xml');
$introSlide 			=file_get_contents('../archive/PPT_POST_REVIEW_TEMPLATE/ppt/slides/slide1.xml');


//CALCULATE CRITERIA
//---------------------------------------------------
$reviewProfile=$GET['review_profile'];
$ca=$GET['ca'];
$msn=getFilter('msn','filter',0,$SESSION);

if($GET['perimeter']==1) 
{
	$caNames = SqlSLi('SELECT perimeter FROM c_perimeter WHERE perimeter=(SELECT perimeter FROM c_ca WHERE ca_id='.$GET['ca'].')','perimeter');
	$allCaIds = SqlSLi('SELECT ca_id FROM c_ca WHERE perimeter=(SELECT perimeter FROM c_ca WHERE ca_id='.$GET['ca'].')','ca_id');
	$allCaNames=formatValueForXML(implode(',', $caNames));
	$ca=implode(',', $allCaIds);
}
else 
{
	$caNames=SqlSLi('SELECT ca FROM c_ca WHERE ca_id IN ('.$GET['ca'].')','ca');
	$allCaNames=formatValueForXML(implode(',', $caNames));
}

$reviewID=SqlLi('SELECT r.review_id, r.validation_date, r.continuous_assessment, msn.msn, coe.coe, pro.program, rt.review_type
						FROM dr_review AS r
							INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
							INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
							INNER JOIN c_coe AS coe ON coe.coe_id=rp.coe
							INNER JOIN c_program AS pro ON pro.program_id=rp.program
							INNER JOIN c_msn AS msn ON msn.msn_id=r.msn
							INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
						WHERE rp.review_profile_id='.$reviewProfile.'
						AND ra.ca IN ('.$ca.')
						AND r.msn='.$msn);

$query='SELECT DISTINCT rch.criterion_user_id, rch.criterion_name, rch.criterion_description, rch.criterion_moc, rch.criterion_showstopper, 
						rgh.review_group_description,
						rc.review_criterion_id,
						ra.ca,
						cs.criteria_status,
						rch.criterion_showstopper,
						rt.review_type,
						ca.ca AS ca_name,
						p.program,
						coe.coe,
						msn.msn,
						YEARWEEK(cs.criteria_planned,1) AS week_number_planned,
						GROUP_CONCAT(DISTINCT cs.criteria_status_id,\'---\',ra.ca SEPARATOR \', \') AS criteria_status_id,
						GROUP_CONCAT(DISTINCT ca.ca,\'---\',ra.ca SEPARATOR \', \') AS ca_evidence_info,
						GROUP_CONCAT(DISTINCT vl2.action_taken_on,\'---\',ra.ca SEPARATOR \', \') AS supplied,
						GROUP_CONCAT(DISTINCT g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS grams_id,
						GROUP_CONCAT(DISTINCT " ",u.name," ",u.surname,\'---\',ra.ca SEPARATOR \', \') AS provider,
						GROUP_CONCAT(DISTINCT ce.file_link,\'---\',ra.ca SEPARATOR \', \') AS file_link,
						GROUP_CONCAT(DISTINCT " ",u2.name," ",u2.surname,\'---\',ra.ca SEPARATOR \', \') AS validator,
						YEARWEEK(vl.action_taken_on,1) AS week_number
			FROM dr_review_criterion_history 				AS rch
			INNER JOIN dr_review_criterion 					AS rc 		ON  rc.review_criterion_id=rch.criterion
			INNER JOIN dr_review_configuration 				AS rconf 	ON  rconf.criterion=rc.review_criterion_id
			INNER JOIN dr_review_group 						AS gro 		ON 	gro.group_id=rc.review_group
			INNER JOIN dr_review_group_history				AS rgh 		ON  rgh.review_group=gro.group_id
			INNER JOIN dr_review_type 						AS rt 		ON 	rt.review_type_id=gro.review_type
			INNER JOIN dr_review_profile 					AS rp 		ON 	rp.review_type=rt.review_type_id
			INNER JOIN dr_review 							AS r 		ON 	r.review_profile=rp.review_profile_id
																		AND r.review_id=rconf.review
			INNER JOIN dr_review_applicability 				AS ra 		ON 	ra.review=r.review_id
			INNER JOIN c_ca 								AS ca 		ON  ca.ca_id=ra.ca
			INNER JOIN c_program 							AS p 		ON 	p.program_id=rp.program
			INNER JOIN c_coe 								AS coe 		ON 	coe.coe_id=rp.coe
			INNER JOIN c_msn 								AS msn 		ON 	msn.msn_id=r.msn
			LEFT  JOIN dr_criteria_status 					AS cs 		ON 	cs.ca=ra.ca
																		AND cs.review_criteria=rc.review_criterion_id
																		AND cs.msn=r.msn
			LEFT  JOIN dr_criteria_status_evidence 			AS cse 		ON  cse.criteria_status=cs.criteria_status_id
			LEFT  JOIN dr_criteria_evidence 				AS ce 		ON 	ce.criteria_evidence_id=cse.criteria_evidence
			LEFT  JOIN dr_criteria_status_provider 			AS csp 		ON 	csp.criteria_status=cs.criteria_status_id
			LEFT  JOIN c_user 								AS u 		ON 	u.user_id=csp.provider
			LEFT  JOIN dr_validation_loop					AS vl 		ON  vl.applicability=cs.criteria_status_id
																		AND vl.object='.$SESSION['object']['criteria_status_id'].'
																		AND vl.action_taken='.$SESSION['user_action']['validated'].'
																		AND vl.action_taken_on!="0000-00-00 00:00:00"
			LEFT  JOIN c_user 								AS u2 		ON 	u2.user_id=vl.validator
			LEFT  JOIN dr_validation_loop					AS vl2 		ON  vl2.applicability=cs.criteria_status_id
																		AND vl2.object='.$SESSION['object']['criteria_status_id'].'
																		AND vl2.action_taken='.$SESSION['user_action']['originated'].'
			LEFT  JOIN dr_review_criterion_applicability	AS rca		ON	rc.review_criterion_id=rca.criterion
			LEFT  JOIN c_grams								AS g		ON	rca.applicability=g.grams_id
																		AND	rca.object='.$SESSION['object']['grams_id'].'
																		AND (rca.review_criterion_applicability_valid_to="0000-00-00 00:00:00" OR rca.review_criterion_applicability_valid_to="0000-00-00 00:00:01")
			WHERE rp.review_profile_id='.$reviewProfile.'
			AND ra.ca IN ('.$ca.')
			AND rch.criterion_valid_from <= r.validation_date
			AND rch.criterion_valid_from != "0000-00-00 00:00:00"
			AND r.msn='.getFilter('msn','filter',0,$SESSION).'
			GROUP BY cs.criteria_status_id ORDER BY rgh.review_group_position ASC, cs.criteria_status DESC';

$rawData=SqlLi($query);

$graphStackedBar		=array();
$graphPie				=array();

$biggestBarStackedBar	=0;

$reviewTypeName			='';
$caName					=array();
$program				='';
$coe					='';
$msn					='';

if(!empty($rawData))
{
	foreach($rawData as $q=>$z)
	{
		//For stacked bar
		$name=explode(' ', $z['review_group_description']);
		$graphStackedBar[$name[0]]['name']=$name[0];
		if($z['criteria_status']==0 && $z['criterion_showstopper']==1 ) $z['criteria_status']=4;
		$graphStackedBar[$name[0]]['criteria_status'][$z['criteria_status']]++;
		if(array_sum($graphStackedBar[$name[0]]['criteria_status']) > $biggestBarStackedBar) $biggestBarStackedBar=array_sum($graphStackedBar[$name[0]]['criteria_status']);

		//For pie charts
		$graphPie[$z['criteria_status']]++;

		//For everything
		$reviewTypeName=$z['review_type'];
		if(!in_array($z['ca_name'],$caName)) array_push($caName, $z['ca_name']);
		$program=$z['program'];
		$coe=$z['coe'];
		$msn=$z['msn'];

	}
}

//This is so the stack bar XLSX download works correctly.
$stackedGroups	=array();
$stackedPurple	=array();
$stackedRed		=array();
$stackedAmber	=array();
$stackedGreen	=array();
$stackedBlue	=array();

foreach ($graphStackedBar as $group => $details) 
{
	if(empty($details['criteria_status'][4])) $details['criteria_status'][4]=0;
	if(empty($details['criteria_status'][0])) $details['criteria_status'][0]=0;
	if(empty($details['criteria_status'][1])) $details['criteria_status'][1]=0;
	if(empty($details['criteria_status'][2])) $details['criteria_status'][2]=0;
	if(empty($details['criteria_status'][3])) $details['criteria_status'][3]=0;

	array_push($stackedGroups, $details['name']);
	array_push($stackedPurple, $details['criteria_status'][4]);
	array_push($stackedRed, $details['criteria_status'][0]);
	array_push($stackedAmber, $details['criteria_status'][1]);
	array_push($stackedGreen, $details['criteria_status'][2]);
	array_push($stackedBlue, $details['criteria_status'][3]);
}

//For crtieria pie chart display
$graphPie=Array('Criteria Status Pie',($graphPie[0]+$graphPie[1]+$graphPie[2]+$graphPie[3]),$graphPie[0],$graphPie[1],$graphPie[2],$graphPie[3]);

$criteriaPieChartReplaced=str_replace("CRITERIA_PIE_CHART_TITLE", $graphPie[0], $criteriaPieChart);
$criteriaPieChartReplaced=str_replace("999", $graphPie[2], $criteriaPieChartReplaced);
$criteriaPieChartReplaced=str_replace("998", $graphPie[3], $criteriaPieChartReplaced);
$criteriaPieChartReplaced=str_replace("997", $graphPie[4], $criteriaPieChartReplaced);
$criteriaPieChartReplaced=str_replace("996", $graphPie[5], $criteriaPieChartReplaced);


//For criteria stacked bar display
$numberOfGroups=count($stackedGroups);
$idx=0;

$groupColumn = '<c:cat><c:strRef><c:f>Sheet1!$A$2:$A$'.($numberOfGroups+1).'</c:f><c:strCache><c:ptCount val="'.$numberOfGroups.'" />';

foreach ($stackedGroups as $uselessKey => $value) 
{
	$groupColumn.='<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}

$idx=0;

$groupColumn .= '</c:strCache></c:strRef></c:cat>';

$purpleColumn = '<c:val><c:numRef><c:f>Sheet1!$B$2:$B$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($stackedPurple as $uselessKey => $value) 
{
	$purpleColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$purpleColumn .= '</c:numCache></c:numRef></c:val>';


$redColumn = '<c:val><c:numRef><c:f>Sheet1!$C$2:$C$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($stackedRed as $uselessKey => $value) 
{
	$redColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$redColumn .= '</c:numCache></c:numRef></c:val>';

$amberColumn = '<c:val><c:numRef><c:f>Sheet1!$D$2:$D$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($stackedAmber as $uselessKey => $value) 
{
	$amberColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$amberColumn .= '</c:numCache></c:numRef></c:val>';

$greenColumn = '<c:val><c:numRef><c:f>Sheet1!$E$2:$E$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($stackedGreen as $uselessKey => $value) 
{
	$greenColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$greenColumn .= '</c:numCache></c:numRef></c:val>';

$blueColumn = '<c:val><c:numRef><c:f>Sheet1!$F$2:$F$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($stackedBlue as $uselessKey => $value) 
{
	$blueColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$blueColumn .= '</c:numCache></c:numRef></c:val>';


$criteriaStackedChartReplaced=str_replace("CRITERIA_STACKED_BAR_TITLE", 'Criteria Status Stacked Bar', $criteriaStackedChart);
$criteriaStackedChartReplaced=str_replace("GROUP_REPLACE", $groupColumn, $criteriaStackedChartReplaced);
$criteriaStackedChartReplaced=str_replace("PURPLE_REPLACE", $purpleColumn, $criteriaStackedChartReplaced);
$criteriaStackedChartReplaced=str_replace("RED_REPLACE", $redColumn, $criteriaStackedChartReplaced);
$criteriaStackedChartReplaced=str_replace("AMBER_REPLACE", $amberColumn, $criteriaStackedChartReplaced);
$criteriaStackedChartReplaced=str_replace("GREEN_REPLACE", $greenColumn, $criteriaStackedChartReplaced);
$criteriaStackedChartReplaced=str_replace("BLUE_REPLACE", $blueColumn, $criteriaStackedChartReplaced);

//END
//-----------------------------------------------------------

//CALCULATE ACTIONS
//-----------------------------------------------------------

//CSA
$actionRawData1=SqlLi('SELECT DISTINCT ac.action_id,ac.msn,ac.criteria,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_closure,ac.action_status AS status,ac.action_holder AS holder,ac.action_holder_name AS holder_name,ac.action_validator AS validator,ac.action_validator_name AS validator_name,
						ca.ca,
						prm.perimeter,
						m.msn AS msn_txt,
						m.msn_id,
						wp.wp,
						rd.rid_code AS rid,
						crh.criterion_name AS criteria_position,
						gr.review_group_description AS group_position,
						rp.review_profile_id,
						YEARWEEK(ac.action_completion,1) AS week_number_planned,
						YEARWEEK(ac.action_closure,1) AS week_number,
						GROUP_CONCAT(DISTINCT log.log_date,\'---\',log.old_value,\'---\',log.new_value ORDER BY log.log_date ASC) AS history							
					FROM dr_action								AS ac
						INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
						INNER JOIN dr_action_applicability		AS ap2	ON ap2.action=ac.action_id
						INNER JOIN c_ca							AS ca	ON ap2.ca=ca.ca_id 
						INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
						INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
						INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND ac.msn=m.msn_id)
						INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
						INNER JOIN dr_review_criterion 			AS cr 	ON ac.criteria=cr.review_criterion_id 
						INNER JOIN dr_review_criterion_history 	AS crh 	ON cr.review_criterion_id=crh.criterion
						INNER JOIN dr_review_group				AS rg 	ON cr.review_group=rg.group_id
						INNER JOIN dr_review_group_history 		AS gr 	ON rg.group_id=gr.review_group 
						INNER JOIN dr_review_type 				AS rt 	ON rg.review_type=rt.review_type_id
						INNER JOIN dr_review_profile			AS rp 	ON rt.review_type_id=rp.review_type
						LEFT JOIN  dr_rid 						AS rd 	ON ac.rid=rd.rid_id
						LEFT  JOIN dr_log 						AS log  ON  log.applicability=ac.action_id
																		AND log.object='.$SESSION['object']['action_status'].'
						WHERE ap.ca IN ('.$ca.') 
						AND rp.review_profile_id IN ('.$reviewProfile.') 
						AND ca.program='.getFilter('program','filter',0,$SESSION).'
						AND ca.coe='.getFilter('coe','filter',0,$SESSION).'
						GROUP BY ac.action_code,ap2.ca');

//NCSA
$actionRawData2=SqlLi('SELECT DISTINCT ac.action_id,ac.msn,ac.criteria,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_closure,ac.action_status AS status,ac.action_holder AS holder,ac.action_holder_name AS holder_name,ac.action_validator AS validator,ac.action_validator_name AS validator_name,
						ca.ca,
						prm.perimeter,
						m.msn AS msn_txt,
						m.msn_id,
						wp.wp,
						rd.rid_code AS rid,
						rp.review_profile_id,
						YEARWEEK(ac.action_completion,1) AS week_number_planned,
						YEARWEEK(ac.action_closure,1) AS week_number,
						GROUP_CONCAT(DISTINCT log.log_date,\'---\',log.old_value,\'---\',log.new_value ORDER BY log.log_date ASC) AS history
					FROM dr_action								AS ac
						INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
						INNER JOIN dr_action_applicability		AS ap2	ON ap2.action=ac.action_id
						INNER JOIN c_ca							AS ca	ON ap2.ca=ca.ca_id 
						INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
						INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
						INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND ac.msn=m.msn_id)
						INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
						INNER JOIN dr_review 					AS r 	ON ac.review=r.review_id
						INNER JOIN dr_review_profile			AS rp   ON r.review_profile=rp.review_profile_id
						INNER JOIN dr_review_type 				AS rt 	ON rp.review_type=rt.review_type_id
						LEFT  JOIN dr_rid 						AS rd 	ON ac.rid=rd.rid_id
						LEFT  JOIN dr_log 						AS log  ON  log.applicability=ac.action_id
																		AND log.object='.$SESSION['object']['action_status'].'
						WHERE ap.ca IN ('.$ca.') 
						AND rp.review_profile_id IN ('.$reviewProfile.') 
						AND ca.program='.getFilter('program','filter',0,$SESSION).'
						AND ca.coe='.getFilter('coe','filter',0,$SESSION).'
						GROUP BY ac.action_code,ap2.ca');

if(!empty($actionRawData1) && !empty($actionRawData2)) $actionRawData=array_merge($actionRawData1, $actionRawData2);
else if (!empty($actionRawData1)) $actionRawData=$actionRawData1;
else if (!empty($actionRawData2)) $actionRawData=$actionRawData2;

$actionRed=0;
$actionAmber=0;
$actionGreen=0;
$actionBlue=0;

$actionOutstandingRows='';

$graphBurnDown=Array();
$graphBurnDownTotals=Array();
$burnDownWeeks=Array();
$burnDownActual=Array();
$burnDownPredicted=Array();
$burnDownGreen=Array();

if(is_array($actionRawData))
{
	foreach($actionRawData as $action)
	{
		calculatePieCharts($action, $actionOutstandingRows, $actionRed, $actionAmber, $actionGreen, $actionBlue, $SESSION);

		fillBurnDownArrays($action, $graphBurnDown, $graphBurnDownTotals);
	}

	sortBurnDownArrays($graphBurnDown, $graphBurnDownTotals, $burnDownWeeks, $burnDownActual, $burnDownPredicted, $burnDownGreen);
}


//Action Pie Chart
$actionPieChartReplaced=str_replace("ACTION_PIE_CHART_TITLE", 'Action Status Pie', $actionPieChart);
$actionPieChartReplaced=str_replace("999", $actionRed, $actionPieChartReplaced);
$actionPieChartReplaced=str_replace("998", $actionAmber, $actionPieChartReplaced);
$actionPieChartReplaced=str_replace("997", $actionGreen, $actionPieChartReplaced);
$actionPieChartReplaced=str_replace("996", $actionBlue, $actionPieChartReplaced);

$actionGraphSlideReplaced=str_replace("XX Actions Past Due Date", $actionRed.' Actions Past Due Date', $actionGraphSlide);
$actionGraphSlideReplaced=str_replace("XX Actions Still Ongoing", $actionAmber.' Actions Ongoing', $actionGraphSlideReplaced);

//Action Burn down
$numberOfGroups=count($burnDownWeeks);
$idx=0;
$weeksColumn = '<c:cat><c:numRef><c:f>Sheet1!$A$2:$A$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($burnDownWeeks as $uselessKey => $value) 
{
	$weeksColumn.='<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$weeksColumn .= '</c:numCache></c:numRef></c:cat>';


$actualColumn = '<c:val><c:numRef><c:f>Sheet1!$B$2:$B$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($burnDownActual as $uselessKey => $value) 
{
	$actualColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$actualColumn .= '</c:numCache></c:numRef></c:val>';


$greenColumn = '<c:val><c:numRef><c:f>Sheet1!$D$2:$D$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($burnDownGreen as $uselessKey => $value) 
{
	$greenColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$greenColumn .= '</c:numCache></c:numRef></c:val>';

$predictedColumn = '<c:val><c:numRef><c:f>Sheet1!$C$2:$C$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($burnDownPredicted as $uselessKey => $value) 
{
	$predictedColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$predictedColumn .= '</c:numCache></c:numRef></c:val>';

$biggestBarBurnDown=($graphBurnDownTotals['total_planned_all'] > $graphBurnDownTotals['total_validated_all'])? $graphBurnDownTotals['total_planned_all'] : $graphBurnDownTotals['total_validated_all'];
if(empty($biggestBarBurnDown)) $biggestBarBurnDown = 1;
$actionBrunDownChartReplaced=str_replace("ACTION_BURN_UP_TITLE", 'Action Burn Up', $actionBrunDownChart);
$actionBrunDownChartReplaced=str_replace("WEEK_REPLACE", $weeksColumn, $actionBrunDownChartReplaced);
$actionBrunDownChartReplaced=str_replace("ACTUAL_REPLACE", $actualColumn, $actionBrunDownChartReplaced);
$actionBrunDownChartReplaced=str_replace("GREEN_REPLACE", $greenColumn, $actionBrunDownChartReplaced);
$actionBrunDownChartReplaced=str_replace("PREDICTED_REPLACE", $predictedColumn, $actionBrunDownChartReplaced);
$actionBrunDownChartReplaced=str_replace('<c:max val="218"/>', '<c:max val="'.$biggestBarBurnDown.'"/>', $actionBrunDownChartReplaced);

//Table Replace
$actionOutstandingTableReplaced=str_replace('ROWS_REPLACE', $actionOutstandingRows, $actionOutstandingTable);

//END
//-----------------------------------------------------------

//CALCULATE RIDs
//-----------------------------------------------------------

$ridRawData=SqlLi('SELECT rd.rid_id,rd.rid_code,rd.rid_title,rd.rid_status AS status,rd.rid_holder_name AS holder_name,rd.rid_validator_name AS validator_name,rd.rid_holder AS holder,rd.rid_validator AS validator,rd.rid_creation,rd.rid_completion,rd.rid_closure, rd.rid_showstopper,rd.rid_action_plan, rd.rid_change_note,
								ac.action_id,
								GROUP_CONCAT(DISTINCT ac.action_code) AS assigned_actions,
								CONCAT(u1.surname,", ",u1.name) AS rid_holder_txt, CONCAT(u2.surname,", ",u2.name) AS rid_validator_txt,
								YEARWEEK(rd.rid_completion,1) AS week_number_planned,
								YEARWEEK(rd.rid_closure,1) AS week_number,
								rp.review_profile_id,
								GROUP_CONCAT(DISTINCT log2.log_date,\'---\',log2.old_value,\'---\',log2.new_value ORDER BY log2.log_date ASC) AS history
							FROM dr_rid AS rd
								LEFT JOIN dr_action 					AS ac	ON  rd.rid_id=ac.rid
								LEFT JOIN c_user 						AS u1	ON  rd.rid_holder=u1.user_id
								LEFT JOIN c_user 						AS u2	ON  rd.rid_validator=u2.user_id
								INNER JOIN dr_action_applicability		AS ap	ON  ap.action=ac.action_id
								INNER JOIN c_ca							AS ca	ON  ap.ca=ca.ca_id
								INNER JOIN c_cawp						AS cw	ON  ca.ca_id=cw.ca
								INNER JOIN c_msn						AS m	ON  cw.msn=m.msn_id
								INNER JOIN c_wp							AS wp	ON  cw.wp=wp.wp_id
								INNER JOIN c_perimeter					AS prm	ON  ca.perimeter=prm.perimeter_id
								INNER JOIN dr_review_criterion 			AS cr 	ON  ac.criteria=cr.review_criterion_id 
								INNER JOIN dr_review_criterion_history 	AS crh 	ON  cr.review_criterion_id=crh.criterion
								INNER JOIN dr_review_group				AS rg 	ON  cr.review_group=rg.group_id
								INNER JOIN dr_review_group_history 		AS gr 	ON  rg.group_id=gr.review_group 
								INNER JOIN dr_review_type 				AS rt 	ON  rg.review_type=rt.review_type_id
								INNER JOIN dr_review_profile			AS rp 	ON  rt.review_type_id=rp.review_type
								LEFT  JOIN dr_log 						AS log2 ON  log2.applicability=rd.rid_id
																				AND log2.object='.$SESSION['object']['rid_status'].'
							WHERE ap.ca IN ('.$ca.') 
							AND rp.review_profile_id IN ('.$reviewProfile.') 
							AND ca.program='.getFilter('program','filter',0,$SESSION).'
							AND ca.coe='.getFilter('coe','filter',0,$SESSION).'
							GROUP BY rd.rid_code,ap.ca');

$ridRed=0;
$ridAmber=0;
$ridGreen=0;
$ridBlue=0;

$ridOutstandingRows='';

$graphBurnDown=Array();
$graphBurnDownTotals=Array();
$burnDownWeeks=Array();
$burnDownActual=Array();
$burnDownPredicted=Array();
$burnDownGreen=Array();

if(is_array($ridRawData))
{
	foreach($ridRawData as $rid)
	{
		if($rid['rid_showstopper']==0) $rid['rid_showstopper'] = 'No';
		else $rid['rid_showstopper'] = 'Yes';

		calculatePieCharts($rid, $ridOutstandingRows, $ridRed, $ridAmber, $ridGreen, $ridBlue, $SESSION, 1);

		fillBurnDownArrays($rid, $graphBurnDown, $graphBurnDownTotals);
	}

	sortBurnDownArrays($graphBurnDown, $graphBurnDownTotals, $burnDownWeeks, $burnDownActual, $burnDownPredicted, $burnDownGreen);
}

//RID Pie Chart
$ridPieChartReplaced=str_replace("RID_PIE_CHART_TITLE", 'RID Status Pie', $ridPieChart);
$ridPieChartReplaced=str_replace("999", $ridRed, $ridPieChartReplaced);
$ridPieChartReplaced=str_replace("998", $ridAmber, $ridPieChartReplaced);
$ridPieChartReplaced=str_replace("997", $ridGreen, $ridPieChartReplaced);
$ridPieChartReplaced=str_replace("996", $ridBlue, $ridPieChartReplaced);

//Table Replace
$ridOutstandingTableReplaced=str_replace('ROWS_REPLACE', $ridOutstandingRows, $ridOutstandingTable);


//RID Burn down
$numberOfGroups=count($burnDownWeeks);
$idx=0;
$weeksColumn = '<c:cat><c:numRef><c:f>Sheet1!$A$2:$A$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($burnDownWeeks as $uselessKey => $value) 
{
	$weeksColumn.='<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$weeksColumn .= '</c:numCache></c:numRef></c:cat>';


$actualColumn = '<c:val><c:numRef><c:f>Sheet1!$B$2:$B$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($burnDownActual as $uselessKey => $value) 
{
	$actualColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$actualColumn .= '</c:numCache></c:numRef></c:val>';


$greenColumn = '<c:val><c:numRef><c:f>Sheet1!$D$2:$D$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($burnDownGreen as $uselessKey => $value) 
{
	$greenColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$greenColumn .= '</c:numCache></c:numRef></c:val>';

$predictedColumn = '<c:val><c:numRef><c:f>Sheet1!$C$2:$C$'.($numberOfGroups+1).'</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'.$numberOfGroups.'" />';
foreach ($burnDownPredicted as $uselessKey => $value) 
{
	$predictedColumn .= '<c:pt idx="'.$idx.'"><c:v>'.$value.'</c:v></c:pt>';
	$idx++;
}
$idx=0;
$predictedColumn .= '</c:numCache></c:numRef></c:val>';

$biggestBarBurnDown=($graphBurnDownTotals['total_planned_all'] > $graphBurnDownTotals['total_validated_all'])? $graphBurnDownTotals['total_planned_all'] : $graphBurnDownTotals['total_validated_all'];
if(empty($biggestBarBurnDown)) $biggestBarBurnDown = 1;
$ridBurnDownChartReplaced=str_replace("RID_BURN_UP_TITLE", 'RID Burn Up', $ridBurnDownChart);
$ridBurnDownChartReplaced=str_replace("WEEK_REPLACE", $weeksColumn, $ridBurnDownChartReplaced);
$ridBurnDownChartReplaced=str_replace("ACTUAL_REPLACE", $actualColumn, $ridBurnDownChartReplaced);
$ridBurnDownChartReplaced=str_replace("GREEN_REPLACE", $greenColumn, $ridBurnDownChartReplaced);
$ridBurnDownChartReplaced=str_replace("PREDICTED_REPLACE", $predictedColumn, $ridBurnDownChartReplaced);
$ridBurnDownChartReplaced=str_replace('<c:max val="218"/>', '<c:max val="'.$biggestBarBurnDown.'"/>', $ridBurnDownChartReplaced);

//END
//-----------------------------------------------------------

//GENERATE ZIP
//------------------------------------------------------------

$slidesFolderLocation;

$zip = new zipfile();

$source=str_replace('\\', '/', realpath('../archive/PPT_POST_REVIEW_TEMPLATE/'));
$flag=basename($source).'/';

$files= new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source),RecursiveIteratorIterator::SELF_FIRST);

foreach($files as $file)
{
	$file=str_replace('\\', '/', realpath($file));
	
	if(is_dir($file)===true)
	{
		//Do nothing
	}
	else if(is_file($file))
	{
		//Criteria Status Pie
		if(strpos($file, 'chart1')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($criteriaPieChartReplaced, str_replace($source.'/', '', $file));
		}
		//Criteria Status Stacked Bar
		else if(strpos($file, 'chart2')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($criteriaStackedChartReplaced, str_replace($source.'/', '', $file));
		}
		//Action Status Pie Chart
		else if(strpos($file, 'chart3')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($actionPieChartReplaced, str_replace($source.'/', '', $file));
		}
		//Action Status Burn Down
		else if(strpos($file, 'chart4')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($actionBrunDownChartReplaced, str_replace($source.'/', '', $file));
		}
		//RID Status Pie Chart
		else if(strpos($file, 'chart5')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($ridPieChartReplaced, str_replace($source.'/', '', $file));
		}
		//RID Status Burn Down
		else if(strpos($file, 'chart6')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($ridBurnDownChartReplaced, str_replace($source.'/', '', $file));
		}
		//Action Slide text.
		else if(strpos($file, 'slide3')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($actionGraphSlideReplaced, str_replace($source.'/', '', $file));
		}
		//Actions outstanding table slide.
		else if(strpos($file, 'slide4')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($actionOutstandingTableReplaced, str_replace($source.'/', '', $file));
		}
		//RID outstanding table slide.
		else if(strpos($file, 'slide6')  && !strpos($file, 'rels')) 
		{
			$zip->addFile($ridOutstandingTableReplaced, str_replace($source.'/', '', $file));
		}
		//Slide 1.
		else if(strpos($file, 'slide1')  && !strpos($file, 'rels')) 
		{
			$introSlideChanged=str_replace("MAIN_TITLE_BOLD", $reviewID[0]['program'].' '.$reviewID[0]['coe'], $introSlide);
			$introSlideChanged=str_replace("MAIN_TITLE_LITE", $allCaNames.' '.$reviewID[0]['review_type'], $introSlideChanged);
			$introSlideChanged=str_replace("SUB_TITLE_BOLD", 'Review Statistics', $introSlideChanged);
			$introSlideChanged=str_replace("SUB_TITLE_LITE", 'Calendar Week '.date('W / Y'), $introSlideChanged);
			$zip->addFile($introSlideChanged, str_replace($source.'/', '', $file));
		}
		//Slide 1 image.
		else if(strpos($file, 'image4')  && !strpos($file, 'rels'))
		{
			$fileName=$file;
			
			switch ($reviewID[0]['program']) 
			{
				case 'A330 NEO':
					$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A330NEO.jpeg';
				break;
				case 'A350':
				case 'A350-900':
					$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A350.jpeg';
				break;
				case 'A321 NEO':
					$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A321NEO.jpeg';
				break;
				case 'A320 NEO':
					$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A320NEO.jpeg';
				break;
				case 'A350-1000':
					$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A3501000.jpeg';
				break;

			}

			$zip->addFile(file_get_contents($fileName), str_replace($source.'/', '', $file));
		}
		else $zip->addFile(file_get_contents($file), str_replace($source.'/', '', $file));
	}
}

header('Content-type: application/octet-stream');
header("Content-Disposition: attachment; filename=".$reviewID[0]['program']."_".$reviewID[0]['coe']."_".$reviewID[0]['review_type'].".pptx");
header("Content-Description: Files of an applicant");
header("Cache-Control: private");
header("Pragma: private");
echo $zip->file();

?>