<?php
/*
* US#107 - User Log for Reviews
* Version: V 4.4
* To display the log data for specific review
* Created by : Infosys Limited
*/

function addLogName($userId,$userName,$html){
	return($html==1)?'<span class="logLink"onClick="openForm(\'userManagement\',\'\',false,\'GET\');openSideElement(\''.$userId.'\',\'usr\');">'.$userName.'</span>':$userName;
}
function caLocation($caLocation,$caId,$html=1){
	$caLocationTxt='CA '.$caLocation[$caId]['ca'].' ('.$caLocation[$caId]['program'].' - '.$caLocation[$caId]['coe'].' - '.$caLocation[$caId]['perimeter'].')';
	if($html==1){
		return '<span class="logLink"onClick="openForm(\'ca\',\'ca='.$caId.'\',false,\'GET\');">'.$caLocationTxt.'</span>';
	}else return $caLocationTxt;
}
function retrieveReviewLogData($user,$source,$applicability,&$data,$maxResults,$SESSION,$html=1,$review_profile_log,$ca_log){
	$_a_=$SESSION['user_action'];
	$_o_=$SESSION['object'];
	$_t_=$SESSION['object_table'];
	$status=array('Red','Amber','Green','Blue'); //JFM 27_03_14
	$generalPermission=array(	$_o_['c_tool_general']							=>'this Tool',
								$_o_['c_program_general']						=>'all Programs in this tool',
								$_o_['c_coe_general']							=>'all CoEs in this tool',
								$_o_['c_perimeter_general']						=>'all Perimeters in this tool',
								$_o_['c_msn_general']							=>'all MSNs in this tool',
								$_o_['c_ca_general']							=>'all CAs in this tool',
								$_o_['dr_review_profile_general']				=>'all Review Profiles in this tool',
								$_o_['dr_responsible_configuration_general']	=>'all Configuration about Responsible People in this tool',
								$_o_['dr_log_general']							=>'all Logs in this tool',
								$_o_['c_user_general']							=>'all Users in this tool');
	
	$logCondition=array();
	if($source!='' && $applicability!=''){
		$logCondition[]='o.source="'.$_t_[$source].'" AND l.applicability="'.$applicability.'"';
	}
	if($user!=''){
		$logCondition[]='l.user="'.$user.'"';
	}
	
	
	if($logCondition[0]!=''){
		$logWhereQry='WHERE '.implode(' AND ',$logCondition);
		
	}
	$limitQry=(is_array($data) && $maxResults!='')?'LIMIT '.$data['displayed_results'].','.$maxResults:'';
	// Review Details
	$reviewLog=SqlLi('SELECT  l.log_date,l.user,l.object AS object_id,l.action,l.applicability,l.old_value,l.new_value
				FROM dr_log AS l
				INNER JOIN c_object AS o ON o.object_id = l.object
				INNER JOIN dr_review AS r ON r.`review_id` = l.applicability
				INNER JOIN dr_review_applicability AS dra ON r.`review_id`= dra.review
				WHERE o.object!="a0_report_id" AND o.object!="permission_id" AND dra.ca="'.$ca_log.'" AND r.review_profile="'.$review_profile_log.'"
				ORDER BY log_id DESC
				'.$limitQry); 
	// Action Details
	$actionLog=SqlLi('SELECT  DISTINCT l.log_date,l.user,l.object AS object_id,l.action,l.applicability,l.old_value,l.new_value
				FROM dr_log AS l
				INNER JOIN c_object AS o ON o.object_id = l.object
				INNER JOIN dr_action AS ac ON ac.`action_id` = l.applicability
				INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
									INNER JOIN c_ca 						AS ca	ON ap.ca=ca.ca_id 
									INNER JOIN c_perimeter					AS prm	ON ca.perimeter=prm.perimeter_id
									INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
									INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND ac.msn=m.msn_id)
									INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
									INNER JOIN dr_review_criterion 			AS cr 	ON ac.criteria=cr.review_criterion_id 
									INNER JOIN dr_review_criterion_history 	AS crh 	ON cr.review_criterion_id=crh.criterion
									INNER JOIN dr_review_group				AS rg 	ON cr.review_group=rg.group_id
									INNER JOIN dr_review_group_history 		AS gr 	ON rg.group_id=gr.review_group 
									INNER JOIN dr_review_type 				AS rt 	ON rg.review_type=rt.review_type_id
									INNER JOIN dr_review_profile			AS rp 	ON rt.review_type_id=rp.review_type
									WHERE o.object!="a0_report_id" AND o.object!="permission_id" AND ap.ca="'.$ca_log.'" AND rp.review_profile_id="'.$review_profile_log.'"
									ORDER BY log_id DESC'); 
		// A0 Report details
	 $a0ReportLog=SqlLi('SELECT  DISTINCT l.log_date,l.user,l.object AS object_id,l.action,l.applicability,l.old_value,l.new_value
				FROM dr_log AS l
				INNER JOIN c_object AS o ON o.object_id = l.object
				INNER JOIN dr_a0_report AS da ON da.`a0_report_id` = l.applicability
				WHERE o.object!="permission_id" AND da.ca="'.$ca_log.'" AND da.review_profile="'.$review_profile_log.'"
				ORDER BY log_id DESC
				'.$limitQry); 
         //ca details
      $caLog = SqlLi('SELECT  DISTINCT l.log_date,l.user,l.object AS object_id,l.action,l.applicability,l.old_value,l.new_value
				FROM dr_log AS l
				INNER JOIN c_object AS o ON o.object_id = l.object 
                                INNER JOIN c_ca as caa on l.applicability = caa.ca_id 
                                INNER JOIN c_cawp as cawp on cawp.ca = caa.ca_id 
                                INNER JOIN c_wp as wpp on wpp.wp_id = cawp.wp 
                                INNER JOIN dr_ca_status as cas on cas.ca = caa.ca_id
								WHERE  caa.ca_id="'.$ca_log.'" AND o.object!="permission_id" AND o.object!="a0_report_id" AND o.object!="action_status" AND o.object!="action_description"
				ORDER BY log_id DESC
				'.$limitQry);   
		// Non criteria details(NCSA)
	  $nonCriteriaLog = SqlLi('SELECT  DISTINCT l.log_date,l.user,l.object AS object_id,l.action,l.applicability,l.old_value,l.new_value
				FROM dr_log AS l
				INNER JOIN c_object AS o ON o.object_id = l.object
				INNER JOIN dr_action AS ac ON ac.`action_id` = l.applicability
				INNER JOIN dr_action_applicability		AS ap	ON ap.action=ac.action_id
							LEFT  JOIN dr_rid				AS rd ON ac.rid=rd.rid_id
							LEFT  JOIN dr_review 			AS r  ON r.review_id=ac.review
							INNER JOIN c_cawp				AS cw ON ap.ca=cw.ca
							WHERE  ap.ca="'.$ca_log.'" AND r.review_profile="'.$review_profile_log.'" AND o.object!="permission_id"  AND o.object!="a0_report_id"
							ORDER BY log_id DESC						
				'.$limitQry);  
      
                if(!empty($caLog) && !empty($a0ReportLog) && !empty($actionLog) && !empty($reviewLog) && !empty($nonCriteriaLog)){
					$log = array_merge($caLog,$reviewLog,$actionLog,$a0ReportLog,$nonCriteriaLog);
				} 
				elseif(!empty($caLog) && !empty($a0ReportLog) && !empty($actionLog) && !empty($reviewLog)){
					$log = array_merge($caLog,$reviewLog,$actionLog,$a0ReportLog);
				}
				elseif(!empty($caLog) && !empty($nonCriteriaLog) && !empty($actionLog) && !empty($reviewLog)){
					$log = array_merge($caLog,$reviewLog,$actionLog,$nonCriteriaLog);
				}
				elseif(!empty($caLog) && !empty($nonCriteriaLog) && !empty($reviewLog)){
					$log = array_merge($reviewLog,$nonCriteriaLog,$caLog);
				}
				elseif(!empty($a0ReportLog) && !empty($actionLog) && !empty($reviewLog)){
					$log = array_merge($reviewLog,$actionLog,$a0ReportLog);
				}
				elseif(!empty($a0ReportLog) && !empty($nonCriteriaLog) && !empty($reviewLog)){
					$log = array_merge($reviewLog,$nonCriteriaLog,$a0ReportLog);
				}
				elseif(!empty($nonCriteriaLog) && !empty($actionLog) && !empty($reviewLog)){
					$log = array_merge($reviewLog,$actionLog,$nonCriteriaLog);
				}				
				elseif(!empty($caLog) && !empty($actionLog) && !empty($reviewLog)){
					$log = array_merge($reviewLog,$actionLog,$caLog);
				} 
				elseif(!empty($actionLog) && !empty($reviewLog)){
					$log = array_merge($reviewLog,$actionLog);
				}
				elseif(!empty($caLog) && !empty($reviewLog)){
					$log = array_merge($reviewLog,$caLog);
				}
				elseif(!empty($nonCriteriaLog) && !empty($reviewLog)){
					$log = array_merge($reviewLog,$nonCriteriaLog);
				}
				elseif(!empty($reviewLog) && !empty($a0ReportLog)){
					$log = array_merge($reviewLog,$a0ReportLog);
				}
				else{
                                    $log = $reviewLog;
				}
		// to sorting the data based on log date
		foreach ($log as $key => $row) {
		$new_published[$key] = $row['log_date'];
		 }
		array_multisort($new_published, SORT_DESC,$log);
		
	$objectDetails=SqlAsLi('SELECT object_id,object,source,object_description FROM c_object','object_id');
	foreach($log as $k=>$v){
		$o=$objectDetails[$v['object_id']];
		$log[$k]['object']=$o['object'];
		$log[$k]['source']=$o['source'];
		$log[$k]['object_description']=$o['object_description'];
		$log[$k]['user_name']=$SESSION['user_list'][$v['user']];
	}

	foreach($log as $l){
		switch($l['source']){
                        case $_t_['c_ca']:
			case $_t_['c_perimeter']:
			case $_t_['dr_ca_status']:
				$caLocationId[$l['applicability']]=$l['applicability'];
                        break;
                        case $_t_['c_cawp']:
				if($log['object']==$_o_['cawp_disable']){
					$cawpId[$l['applicability']]=$l['applicability'];
				}
			break;
			case $_t_['dr_review']:
				$drReviewId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['dr_action']:
				$drActionId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['dr_rid']:
				$drRidId[$l['applicability']]=$l['applicability'];
			break;
			case $_t_['dr_a0_report']:
				$a0ReportId[$l['applicability']]=$l['applicability'];
			break;
		}
	}
	if(is_array($drReviewId))
	{			
		$drReview=SqlAsLi('SELECT DISTINCT r.review_id,
											c.ca_id,c.ca,
											m.msn_id,m.msn,
											r.review_profile,
											rt.review_type,
											pro.program_id, pro.program,
											coe.coe_id, coe.coe
								FROM dr_review AS r
									INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
									INNER JOIN c_ca AS c ON ra.ca=c.ca_id
									INNER JOIN c_msn AS m ON r.msn=m.msn_id
									INNER JOIN c_program as pro ON pro.program_id=m.program
									INNER JOIN c_coe AS coe ON coe.coe_id=c.coe
									INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
									INNER JOIN dr_review_type AS rt ON rp.review_type=rt.review_type_id
									WHERE r.review_id IN("'.implode('","',$drReviewId).'") 
								','review_id');
	}
	if(is_array($cawpId)){
		$caFromCawp=SqlAsLi('SELECT cawp_id,ca,msn FROM c_cawp WHERE cawp_id IN ('.implode(',',$cawpId).')','cawp_id');
		if(is_array($caFromCawp)){
			foreach($caFromCawp as &$c){
				$caLocationId[$c['ca']]=$c['ca'];
			}
		}
	}
	
	if(is_array($caLocationId)){
		$caLocation=SqlAsLi('SELECT ca.ca_id,ca.ca,prg.program,coe.coe,prm.perimeter
								FROM c_ca AS ca
									INNER JOIN c_program	AS prg ON ca.program=prg.program_id
									INNER JOIN c_coe		AS coe ON ca.coe=coe.coe_id
									INNER JOIN c_perimeter	AS prm ON ca.perimeter=prm.perimeter_id
								WHERE ca.ca_id IN('.implode(',',$caLocationId).')','ca_id');
	}
	if(is_array($drActionId))
	{	
		$drAction=SqlAsLi('SELECT DISTINCT act.action_id, act.action_code
									FROM dr_action AS act
									LEFT JOIN dr_action_applicability AS daa ON act.`action_id`= daa.action
									WHERE act.action_id IN("'.implode('","',$drActionId).'")','action_id');
	}
	if(is_array($drRidId))
	{
		$drRid=SqlAsLi('SELECT DISTINCT rid.rid_id, rid.rid_code
									FROM dr_rid AS rid
									WHERE rid.rid_id IN("'.implode('","',$drRidId).'")','rid_id');
	}
	if(is_array($a0ReportId))
	{				
		$a0Report=SqlAsLi('SELECT DISTINCT s.a0_report_id,
											pro.program_id, pro.program,
											coe.coe_id, coe.coe,
											msn.msn_id, msn.msn,
											ca.ca,
											rt.review_type
									FROM c_ca AS ca
										INNER JOIN dr_a0_report AS s ON ca.ca_id=s.ca
										INNER JOIN c_msn AS msn ON msn.msn_id=s.msn
										INNER JOIN c_program AS pro ON pro.program_id=msn.program
										INNER JOIN c_coe AS coe ON coe.coe_id=ca.coe
										INNER JOIN dr_review_profile AS rp ON s.review_profile=rp.review_profile_id
										INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
									WHERE s.a0_report_id IN("'.implode('","',$a0ReportId).'")','a0_report_id');
	}

	$i=0;
	foreach($log as $l){
		$l=utf8enc($l,1);
		$logTxt[$i]['date']=$l['log_date'];
		$event='';
		$event.=addLogName($l['user'],$l['user_name'],$html).' ';
		switch($l['source']){
			case $_t_['c_cawp']:
				switch ($l['object']){
					case 'cawp_disabled':
						$event.=($l['new_value']==1)?' enabled ':' disabled';
						$event.=' the ';
						$displayLink=($caFromCawp[$l['applicability']]['msn']==getFilter('msn','filter',0,$SESSION))?1:0;
						$event.=caLocation($caLocation,$caFromCawp[$l['applicability']]['ca'],$displayLink);
					break;
				}
			break;
			/* 	case $_t_['c_tool']:
				$event.='logged into the tool';
			break; 
		case $_t_['c_permission']:
					$event.=($l['new_value']==1)?' granted ':' denied ';
					$event.=addLogName($cPermission[$l['applicability']]['user_id'],$cPermission[$l['applicability']]['user_name'],$html);
					$event.=($cPermission[$l['applicability']]['user_action_id']==$_a_['superadmin'])?' the Super Administrator right':' the right to '.$cPermission[$l['applicability']]['user_action'];
					$event.=' ';
				if($generalPermission[$cPermission[$l['applicability']]['object']]!=''){
					$event.=$generalPermission[$cPermission[$l['applicability']]['object']];
				}else{
					switch($cPermission[$l['applicability']]['object']){
						case $_o_['program_id']:
							$event.='the elements within the Program '.$permissionProgram[$permissionProgramId[$cPermission[$l['applicability']]['applicability']]];
						break;
						case $_o_['coe_id']:
							$event.='the elements within the CoE '.$permissionCoe[$permissionCoeId[$cPermission[$l['applicability']]['applicability']]];
						break;
						case $_o_['perimeter_id']:
							$event.='the elements within the Perimeter '.$permissionPerimeter[$permissionPerimeterId[$cPermission[$l['applicability']]['applicability']]];
						break;
						case $_o_['review_profile_id']:
							$event.='the '.$permissionReviewProfile[$cPermission[$l['applicability']]['applicability']]['review_type'].' Review of '.
								$permissionReviewProfile[$cPermission[$l['applicability']]['applicability']]['program']
								.' / '.$permissionReviewProfile[$cPermission[$l['applicability']]['applicability']]['coe'];
						break;
					}
				}
			break; */
			case $_t_['c_ca']:
			case $_t_['c_perimeter']:
			case $_t_['c_wp']:
			case $_t_['dr_action']:
			case $_t_['dr_ca_status']:
			case $_t_['dr_criteria_status']:
			case $_t_['dr_review']:
			case $_t_['dr_rid']:
			case $_t_['dr_risk']: 
				$event.='modified the '.$l['object_description'].' of the ';
				switch($l['source'])
				{
					case $_t_['c_ca']:
					case $_t_['c_perimeter']:
					case $_t_['dr_ca_status']:
						$event.=caLocation($caLocation,$l['applicability'],1);
					break;
					case $_t_['dr_review']:
						$reviewTxt=$drReview[$l['applicability']]['program'].' - '.$drReview[$l['applicability']]['coe'].' - '.$drReview[$l['applicability']]['msn'].' - '.$drReview[$l['applicability']]['ca'].' - '.$drReview[$l['applicability']]['review_type'];
						$event.=($html==1)?'<span class="logLink" onClick="changeDropDownWhenGraphOptionSelected('.$drReview[$l['applicability']]['coe_id'].','.$drReview[$l['applicability']]['msn_id'].','.$drReview[$l['applicability']]['program_id'].',\''.$drReview[$l['applicability']]['ca'].'\');">'.$reviewTxt.'</span>':$reviewTxt;
					break;
					case $_t_['dr_criteria_status']:
						$reviewTxt=$drCriteriaStatus[$l['applicability']]['program'].' - '.$drCriteriaStatus[$l['applicability']]['coe'].' - '.$drCriteriaStatus[$l['applicability']]['msn'].' - '.$drCriteriaStatus[$l['applicability']]['ca'].' - '.$drCriteriaStatus[$l['applicability']]['review_type'].' - '.$drCriteriaStatus[$l['applicability']]['criterion_user_id'].' (actual id '.$drCriteriaStatus[$l['applicability']]['criterion'].') ';
						$event.=($html==1)?'<span class="logLink" onClick="changeDropDownWhenGraphOptionSelected('.$drCriteriaStatus[$l['applicability']]['coe_id'].','.$drCriteriaStatus[$l['applicability']]['msn_id'].','.$drCriteriaStatus[$l['applicability']]['program_id'].',\''.$drCriteriaStatus[$l['applicability']]['ca'].'\');">'.$reviewTxt.'</span>':$reviewTxt;
					break;
					case $_t_['dr_action']:
						$reviewTxt=$drAction[$l['applicability']]['action_code'];
						$event.=($html==1)?'<span class="logLink" onClick="">'.$reviewTxt.'</span>':$reviewTxt;
					break;
					case $_t_['dr_rid']:
						$reviewTxt=$drRid[$l['applicability']]['rid_code'];
						$event.=($html==1)?'<span class="logLink" onClick="">'.$reviewTxt.'</span>':$reviewTxt;
					break;
					case $_t_['dr_risk']:
						$reviewTxt=$drRisk[$l['applicability']]['risk_code'];
						$event.=($html==1)?'<span class="logLink" onClick="">'.$reviewTxt.'</span>':$reviewTxt;
					break;
				}
				if($l['old_value']!=$l['new_value'])
				{
					$event.=' <b>from</b>';
					switch($l['object_id'])
					{
						case $_o_['review_status']:
						case $_o_['action_status']:
						case $_o_['rid_status']:
						case $_o_['risk_status']: 
						case $_o_['criteria_status']:
							$event.=' '.$status[$l['old_value']].' <b>to</b> '.$status[$l['new_value']];
						break;
						case $_o_['action_holder']:
						case $_o_['action_validator']:
						case $_o_['risk_holder']: 
							if($l['old_value']) $userOld=SqlQ('SELECT CONCAT(name, " ", surname) AS fullname FROM c_user WHERE user_id='.$l['old_value']);
							if($l['new_value']) $userNew=SqlQ('SELECT CONCAT(name, " ", surname) AS fullname FROM c_user WHERE user_id='.$l['new_value']);
							$event.=' '.$userOld['fullname'].' ('.$l['old_value'].') <b>to</b> '.$userNew['fullname'].' ('.$l['new_value'].')';
						break;
						default:
							$oldValue=($l['old_value'] && $l['old_value']!='0000-00-00')?$l['old_value']:'nothing';
							$newValue=($l['new_value'] && $l['new_value']!='0000-00-00')?$l['new_value']:'nothing';
							$event.=' '.$oldValue.' <b>to</b> '.$newValue;
					}
				}
			break;

			case $_t_['dr_a0_report']:
				if($_a_['create']==$l['action']) $event.='generated an Review report for ';
				else if($_a_['upload']==$l['action']) $event.='uploaded an Review report for ';
				$reviewTxt=$a0Report[$l['applicability']]['program'].' - '.$a0Report[$l['applicability']]['coe'].' - '.$a0Report[$l['applicability']]['msn'].' - '.$a0Report[$l['applicability']]['ca'].' - '.$a0Report[$l['applicability']]['review_type'];
				$event.=($html==1)?'<span class="logLink" onClick="changeDropDownWhenGraphOptionSelected('.$a0Report[$l['applicability']]['coe_id'].','.$a0Report[$l['applicability']]['msn_id'].','.$a0Report[$l['applicability']]['program_id'].',\''.$a0Report[$l['applicability']]['ca'].'\');">'.$reviewTxt.'</span>':$reviewTxt;
			break;

		}
		$logTxt[$i]['event']=$event;
		if(is_array($data)){
			$data['displayed_results']++;
		}
		$i++;
	}
	return $logTxt;
}

?>