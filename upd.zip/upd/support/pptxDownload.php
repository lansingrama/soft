<?php
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../../common/php/zip.lib.php');
require_once('localSupport.php');
require_once('form.php');

function formatValueForXML($string)
{
	return utf8_encode(str_replace("&#8230;", "",str_replace(">", "&gt;",str_replace("<", "&lt;",str_replace("&", "&amp;", $string)))));
}

$GET=cleanArray($_GET);

//PUT FILES IN MEMORY
//---------------------------------------------------

$introSlide				=file_get_contents('../archive/PPT_TEMPLATE/ppt/slides/slide1.xml');
$introSlideRels			=file_get_contents('../archive/PPT_TEMPLATE/ppt/slides/_rels/slide1.xml.rels');
$criteriaGroupSlide		=file_get_contents('../archive/PPT_TEMPLATE/ppt/slides/slide6.xml');
$criteriaGroupSlideRels	=file_get_contents('../archive/PPT_TEMPLATE/ppt/slides/_rels/slide6.xml.rels');
$criteriaSlide			=file_get_contents('../archive/PPT_TEMPLATE/ppt/slides/slide7.xml');
$criteriaSlideRels		=file_get_contents('../archive/PPT_TEMPLATE/ppt/slides/_rels/slide7.xml.rels');
$slidesArray			=array();
$slidesRelsArray		=array();

$slide3TableRow			=file_get_contents('../archive/PPT_TEMPLATE_HELP_FILES/slide3_to_replace.xml');
$slide4TableRow			=file_get_contents('../archive/PPT_TEMPLATE_HELP_FILES/slide4_to_replace.xml');

$slidesToIgnore			=2;

$slideNumber			=6; 	//Total Slides -1
$slideId				=12;	//Highest rId from ppt\_rels\presentation.xml.rels -1
$slideUniqueId			=263;	//Highest p:sldId id from ppt\presentation.xml -1

$origionalSlideNumber	=$slideNumber;
$origionalSlideId		=$slideId;
$origionalSlideUniqueId	=$slideUniqueId;

$criteriaGroupArray		=array();

$pictureChangeArray 	=array("1", "10", "11", "12");
$pictureChangeCount		=0;

//GET CRITERIA & STATUSES
//---------------------------------------------------

$msn=getFilter('msn','filter',0,$SESSION);
$reviewProfile=$GET['review_profile'];

$caNames=SqlLi('SELECT ca FROM c_ca WHERE ca_id IN ('.$GET['ca'].')');

$reviewID=SqlLi('SELECT r.review_id, r.validation_date, r.continuous_assessment, msn.msn, coe.coe, pro.program, rt.review_type
						FROM dr_review AS r
							INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
							INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
							INNER JOIN c_coe AS coe ON coe.coe_id=rp.coe
							INNER JOIN c_program AS pro ON pro.program_id=rp.program
							INNER JOIN c_msn AS msn ON msn.msn_id=r.msn
							INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
						WHERE rp.review_profile_id='.$reviewProfile.'
						AND ra.ca IN ('.$GET['ca'].')
						AND r.msn='.$msn);
				
$criteria=SqlAsLi('SELECT DISTINCT rgh.review_group,rgh.review_group_description,rgh.review_group_position,
									rconf.disabled, rconf.position AS criterion_position,
									rc.review_criterion_id, rch.criterion_name, rch.criterion_description, rch.criterion_user_id, rch.criterion_showstopper, rch.criterion_mg_elements, rch.criterion_moc, rch.criterion_valid_from,
									GROUP_CONCAT(g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS criterion_reference
					FROM dr_review_criterion_history AS rch 
						INNER JOIN dr_review_criterion 		AS rc		ON rch.criterion=rc.review_criterion_id
						INNER JOIN dr_review_group		   	AS rg		ON rg.group_id=rc.review_group
						INNER JOIN 
									(
										SELECT review_group,review_group_description,review_group_position,review_group_valid_from 
												FROM dr_review_group_history 
												WHERE review_group_valid_from <= "'.$reviewID[0]['validation_date'].'" 
												ORDER BY review_group_valid_from DESC
									) AS rgh ON rgh.review_group=rg.group_id 
						INNER JOIN dr_review_configuration	AS rconf	ON rc.review_criterion_id = rconf.criterion
						INNER JOIN dr_review				AS r		ON r.review_id=rconf.review
						INNER JOIN dr_review_applicability	AS ra		ON r.review_id=ra.review
						INNER JOIN dr_review_profile		AS rp 		ON rp.review_profile_id=r.review_profile
						LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion
						LEFT  JOIN c_grams					AS g		ON	rca.applicability=g.grams_id
																		AND	rca.object='.$SESSION['object']['grams_id'].'
																		AND rca.review_criterion_applicability_valid_from <= "'.$reviewID[0]['validation_date'].'"
					WHERE rp.review_profile_id='.$reviewProfile.'
					AND ra.ca IN ('.$GET['ca'].')
					AND r.msn='.$msn.'
					AND rch.criterion_valid_from <= "'.$reviewID[0]['validation_date'].'"
					AND rch.criterion_valid_from != "0000-00-00 00:00:00"
					GROUP BY rch.criterion_validity_id
					ORDER BY rgh.review_group_position ASC, rconf.position ASC','review_criterion_id');

if(!empty($criteria))
{

	function item8($item) { return $item['review_id']; }
	$reviewIdsMap=array_map('item8', $reviewID);
	$allCas=SqlSLi('SELECT ca FROM dr_review_applicability WHERE review IN ('.implode(',',$reviewIdsMap).')','ca');
        
        /*
         * US#117 - Mirroring Pre-review PPT content in the review view
         * Added addtional columns for Criteria Evidence and Criteria Next Steps
         * Version: 4.4
         * Fixed by: Infosys Limited
         */
	$criteriaStatusQry=mysql_query('SELECT DISTINCT s.review_criteria,s.ca,s.criteria_status_id,s.criteria_status,s.criteria_focal_point,s.criteria_comments,s.criteria_evidence,s.criteria_next_steps, s.criteria_planned, GROUP_CONCAT(DISTINCT csp.provider) AS provider, GROUP_CONCAT(DISTINCT vl.validator) AS stakeholder
									FROM c_ca AS ca
										LEFT JOIN dr_criteria_status AS s ON ca.ca_id=s.ca
										LEFT JOIN dr_criteria_status_provider AS csp ON csp.criteria_status=s.criteria_status_id
										LEFT JOIN dr_validation_loop_structure AS vl ON vl.applicability=s.criteria_status_id
																					AND vl.object='.$SESSION['object']['criteria_status_id'].'
										INNER JOIN dr_review_configuration AS c ON s.review_criteria=c.criterion
										INNER JOIN dr_review AS g ON c.review=g.review_id
									WHERE s.msn="'.$msn.'"
									AND ca.ca_id IN('.implode(',',$allCas).')
									AND g.review_profile="'.$reviewProfile.'"
									GROUP BY review_criteria',$p12) or die(mysql_error());

	while($c=mysql_fetch_assoc($criteriaStatusQry))
	{
		foreach($c as $k=>$v)
		{
			$criteriaStatus[$c['review_criteria']][$GET['ca']][$k]=$v;
		}
	}
		
	if(is_array($criteriaStatus))
	{
		foreach($criteriaStatus as $k=>&$v)
		{
                        // Added fields criteria_evidence, criteria_next_steps - US#117
			$criteria[$k]['criteria_status_id']=combinedResult($v,'criteria_status_id','id',$SESSION);
			$criteria[$k]['criteria_status']=combinedResult($v,'criteria_status','status',$SESSION);
			$criteria[$k]['criteria_focal_point']=combinedResult($v,'criteria_focal_point','text',$SESSION);
			$criteria[$k]['criteria_comments']=combinedResult($v,'criteria_comments','text',$SESSION);
                        $criteria[$k]['criteria_evidence']=combinedResult($v,'criteria_evidence','text',$SESSION);
                        $criteria[$k]['criteria_next_steps']=combinedResult($v,'criteria_next_steps','text',$SESSION);
			$criteria[$k]['criteria_planned']=(combinedResult($v,'criteria_planned','text',$SESSION)=='0000-00-00')?'':combinedResult($v,'criteria_planned','text',$SESSION);
			$criteria[$k]['provider']=combinedResult($v,'provider','text',$SESSION);
			$criteria[$k]['stakeholder']=combinedResult($v,'stakeholder','text',$SESSION);
		}
	}

	$responsibles=getResponsibles($reviewID[0]['review_id'],$SESSION);

	$allCaNames=formatValueForXML(implode(',', $caNames[0]));

	//CREATE NEW SLIDES IN MEMORY
	//---------------------------------------------------

	if(!empty($criteria))
	{
		$lastGroup=0;
		$criteriaStatusMap=Array(0 => 'RED', 1 => 'AMBER', 2 => 'GREEN', 3 => 'BLUE', 4 => 'N/A'); //JFM 15_09_15
		$criteriaStatusColourMap=Array(0 => 'accent6', 1 => 'accent5', 2 => 'accent3', 3 => 'accent2', 4 => 'accent1'); //JFM 15_09_15

		foreach($criteria as $q=>$c)
		{
			foreach ($c as $key => $value) 
			{
				$c[$key]=formatValueForXML($value);
			}
			
			if($c['disabled']==1) $c['criteria_status']=4; //JFM 15_09_15
			else if($c['criteria_status']=='') $c['criteria_status']=0;

			if($lastGroup!=$c['review_group'])
			{
				$lastGroup=$c['review_group'];
				$replacedCriteriaGroup=str_replace("CRITERIA_GROUP_LARG_BOX_TOP", $c['review_group_description'], $criteriaGroupSlide);
				$replacedCriteriaGroup=str_replace("CRITERIA_GROUP_SMALL_BOX_TOP", $reviewID[0]['program'].' '.$allCaNames.' '.$reviewID[0]['review_type'], $replacedCriteriaGroup);
				$replacedCriteriaGroup=str_replace("CRITERIA_GROUP_LARGE_BOX_BOTTOM", $reviewID[0]['program'].' '.$allCaNames.' '.$reviewID[0]['review_type'].' Checklist', $replacedCriteriaGroup);

				$slidesArray[]=$replacedCriteriaGroup;
				$criteriaGroupArray[]=$c['review_group_description'];

				$slidesRelsArray[]=str_replace("slideLayout1", "slideLayout".$pictureChangeArray[$pictureChangeCount], $criteriaGroupSlideRels);
				if($pictureChangeCount==count($pictureChangeArray)-1) $pictureChangeCount=0;
				else $pictureChangeCount++;
			}

                        // Created mapping for criteria_evidence and criteria_next_steps values to pre-review PPT
			$replaced=str_replace("CRITERIA_USER_ID", $c['criterion_user_id'], $criteriaSlide);
			$replaced=str_replace("CRITERIA_GROUP", $c['review_group_description'], $replaced);
			$replaced=str_replace("CRITERIA_NAME", $c['criterion_name'], $replaced);
			$replaced=str_replace("CRITERIA_DESCRIPTION", $c['criterion_description'], $replaced);
			$replaced=str_replace("CRITERIA_MOC", $c['criterion_moc'], $replaced);
                        $replaced=str_replace("CRITERIA_COMMENTS", $c['criteria_comments'], $replaced);
			$replaced=str_replace("CRITERIA_EVIDENCE", $c['criteria_evidence'], $replaced);
                        $replaced=str_replace("CRITERIA_NEXT_STEPS", $c['criteria_next_steps'], $replaced);
			$replaced=str_replace("CRITERIA_STATUS", $criteriaStatusMap[$c['criteria_status']], $replaced);
			$replaced=str_replace("accent6", $criteriaStatusColourMap[$c['criteria_status']], $replaced);

			$slidesArray[]=$replaced;
			$slidesRelsArray[]=$criteriaSlideRels;
			//End of US#117
		}
	}

	$slidesFolderLocation;

	$zip = new zipfile();

	$source=str_replace('\\', '/', realpath('../archive/PPT_TEMPLATE/'));
	$flag=basename($source).'/';

	$files= new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source),RecursiveIteratorIterator::SELF_FIRST);

	foreach($files as $file)
	{
		$file=str_replace('\\', '/', realpath($file));
		
		if(is_dir($file)===true)
		{
			//Do nothing
		}
		else if(is_file($file))
		{
			if(strpos($file, 'slide'.$origionalSlideNumber) || strpos($file, 'slide'.($origionalSlideNumber+1)))
			{
				//Do nothing
			}
			else if(strpos($file, 'slide1')  && !strpos($file, 'rels')) 
			{
				$introSlideChanged=str_replace("INTRO_SMALL_BOX_TOP", $reviewID[0]['program'].' '.$reviewID[0]['coe'], $introSlide);
				$introSlideChanged=str_replace("INTRO_LARGE_BOX_TOP", $reviewID[0]['program'].' '.$allCaNames.' '.$reviewID[0]['review_type'], $introSlideChanged);
				$zip->addFile($introSlideChanged, str_replace($source.'/', '', $file));

				$slidesFolderLocation=str_replace('slide1.xml','',str_replace($source.'/', '', $file));
				
				foreach ($slidesArray as $key => $slideRaw) //Add the raw slides are new files
				{
					$zip->addFile($slideRaw, $slidesFolderLocation.'slide'.$slideNumber.'.xml');
					$zip->addFile($slidesRelsArray[$key], $slidesFolderLocation.'_rels/slide'.$slideNumber.'.xml.rels');
					$slideNumber++;
				}
				
				//For references slide
				$zip->addFile(file_get_contents('../archive/PPT_TEMPLATE_HELP_FILES/slide_8_helper.xml'), $slidesFolderLocation.'slide'.$slideNumber.'.xml');
				$zip->addFile(file_get_contents('../archive/PPT_TEMPLATE_HELP_FILES/slide_8_helper.xml.rels'), $slidesFolderLocation.'_rels/slide'.$slideNumber.'.xml.rels');

				$slideNumber=$origionalSlideNumber;
			}
			else if(strpos($file, 'slide3')  && !strpos($file, 'rels') && !empty($responsibles)) 
			{
				$slide3File=file_get_contents($file);

				$newSlidesXMLConcat='';

				foreach ($responsibles as $responsible) 
				{
					if(strtoupper($responsible['responsible_role'])=="CHAIRMAN" || strtoupper($responsible['responsible_role'])=="CHAIRPERSON")
					{
						$slide3File=str_replace("PANEL_CHAIRMAN_NAME",$responsible['responsible'],$slide3File);
					}
					else if (strtoupper($responsible['responsible_role'])=="Secretary")
					{
						$slide3File=str_replace("PANEL_SECRETARY_NAME",$responsible['responsible'],$slide3File);
					}
					else
					{
						$responsible['responsible_role']=formatValueForXML($responsible['responsible_role']);
						$responsible['responsible']=formatValueForXML($responsible['responsible']);
		
						$newSlidesXMLConcat.=str_replace('PANEL_POSITION_NAME',$responsible['responsible'],str_replace('PANEL_POSITION_TITLE',$responsible['responsible_role'],$slide3TableRow));
					}
				}

				$slide3FileAppend=str_replace($slide3TableRow,$newSlidesXMLConcat,$slide3File);
				$zip->addFile($slide3FileAppend, str_replace($source.'/', '', $file));
			}
			else if(strpos($file, 'slide4')  && !strpos($file, 'rels') && !empty($criteriaGroupArray)) 
			{
				$newSlidesXMLConcat='';

				foreach ($criteriaGroupArray as $criteriaGroupName) 
				{
					$newSlidesXMLConcat.=str_replace('AGENDA_ITEM',$criteriaGroupName,$slide4TableRow);
				}

				$slide4File=file_get_contents($file);
				$slide4FileAppend=str_replace($slide4TableRow,$newSlidesXMLConcat,$slide4File);
				$zip->addFile($slide4FileAppend, str_replace($source.'/', '', $file));
			}
			else if(strpos($file, 'presentation')  && strpos($file, 'rels'))
			{
				$newSlidesXMLConcat='';

				foreach ($slidesArray as $key => $slideRaw) //Add the relationship IDs to presentation.xml.rels
				{
					if($slideNumber < ($origionalSlideNumber+$slidesToIgnore) && $slideId < ($origionalSlideId+$slidesToIgnore))
					{
						$slideNumber++;
						$slideId++;
					}
					else
					{
						$newSlidesXMLConcat.='<Relationship Id="rId'.$slideId.'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide'.$slideNumber.'.xml" />';
						$slideNumber++;
						$slideId++;
					}
				}

				//For references slide
				$newSlidesXMLConcat.='<Relationship Id="rId'.$slideId.'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide'.$slideNumber.'.xml" />';

				$newSlidesXMLConcat.='</Relationships>';
				$slideNumber=$origionalSlideNumber;
				$slideId=$origionalSlideId;

				$presentationRelsFile=file_get_contents($file);
				$presentationRelsFileAppend=str_replace('</Relationships>',$newSlidesXMLConcat,$presentationRelsFile);
				$zip->addFile($presentationRelsFileAppend, str_replace($source.'/', '', $file));

			}
			else if(strpos($file, 'presentation')  && !strpos($file, 'rels')) //Add the relationship IDs to presentation.xml
			{
				$newSlidesXMLConcat='';

				foreach ($slidesArray as $key => $slideRaw) 
				{
					if($slideUniqueId < ($origionalSlideUniqueId+$slidesToIgnore) && $slideId < ($origionalSlideId+$slidesToIgnore))
					{
						$slideUniqueId++;
						$slideId++;
					}
					else
					{
						$newSlidesXMLConcat.='<p:sldId id="'.$slideUniqueId.'" r:id="rId'.$slideId.'" />';
						$slideUniqueId++;
						$slideId++;
					}
				}

				//For references slide
				$newSlidesXMLConcat.='<p:sldId id="'.$slideUniqueId.'" r:id="rId'.$slideId.'" />';

				$newSlidesXMLConcat.='</p:sldIdLst>';
				$slideUniqueId=$origionalSlideUniqueId;
				$slideId=$origionalSlideId;

				$presentationFile=file_get_contents($file);
				$presentationFileAppend=str_replace('</p:sldIdLst>',$newSlidesXMLConcat,$presentationFile);
				$zip->addFile($presentationFileAppend, str_replace($source.'/', '', $file));
			}
			else if(strpos($file, 'Content_Types')  && !strpos($file, 'rels'))
			{
				$newSlidesXMLConcat='';

				foreach ($slidesArray as $key => $slideRaw) 
				{
					if($slideNumber < ($origionalSlideNumber+$slidesToIgnore))
					{
						$slideNumber++;
					}
					else
					{
						$newSlidesXMLConcat.='<Override PartName="/ppt/slides/slide'.$slideNumber.'.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml" />';
						$slideNumber++;
					}
				}

				//For references slide
				$newSlidesXMLConcat.='<Override PartName="/ppt/slides/slide'.$slideNumber.'.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml" />';

				$newSlidesXMLConcat.='</Types>';
				$slideNumber=$origionalSlideNumber;

				$contentTypesFile=file_get_contents($file);
				$contentTypesFileAppend=str_replace('</Types>',$newSlidesXMLConcat,$contentTypesFile);
				$zip->addFile($contentTypesFileAppend, str_replace($source.'/', '', $file));
			}
			else if(strpos($file, 'image4')  && !strpos($file, 'rels'))
			{
				$fileName=$file;
				
				switch ($reviewID[0]['program']) 
				{
					case 'A330 NEO':
						$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A330NEO.jpeg';
					break;
					case 'A350':
					case 'A350-900':
						$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A350.jpeg';
					break;
					case 'A321 NEO':
						$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A321NEO.jpeg';
					break;
					case 'A320 NEO':
					$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A320NEO.jpeg';
					break;
					case 'A350-1000':
						$fileName='../archive/PPT_TEMPLATE_HELP_FILES/A3501000.jpeg';
					break;

				}

				$zip->addFile(file_get_contents($fileName), str_replace($source.'/', '', $file));
			}
			else $zip->addFile(file_get_contents($file), str_replace($source.'/', '', $file));
		}
	}


	header('Content-type: application/octet-stream');
	header("Content-Disposition: attachment; filename=".$reviewID[0]['program']."_".$reviewID[0]['coe']."_".implode('_', $caNames[0])."_".$reviewID[0]['review_type'].".pptx"); //JFM 15_09_15
	header("Content-Description: Files of an applicant");
	header("Cache-Control: private");
	header("Pragma: private");
	echo $zip->file();
}
else
{
	header("Location: ../index.php");
}

?>