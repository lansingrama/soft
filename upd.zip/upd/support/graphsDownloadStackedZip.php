<?php //JFM 11_08_14
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('localSupport.php');
require_once('form.php');
require_once('zipfile.php');

function forLoop($array, &$string)
{
	for ($i=0; $i < count($array); $i++) 
	{
		$string.='<c:pt idx="'.$i.'"><c:v>'.$array[$i].'</c:v></c:pt>';
	}
}

$POST=cleanArray($_POST);

$reviewProfile=$POST['review_profile'];
$caString=$POST['ca'];
$filenames=array();

$caArray=explode(',', $caString);

foreach ($caArray as $ca)
{
	$query='SELECT DISTINCT rch.criterion_user_id, rch.criterion_name, rch.criterion_description, rch.criterion_moc, rch.criterion_showstopper, 
							rgh.review_group_description,
							rc.review_criterion_id,
							ra.ca,
							cs.criteria_status,
							rch.criterion_showstopper,
							rt.review_type,
							ca.ca AS ca_name,
							p.program,
							coe.coe,
							msn.msn,
							YEARWEEK(cs.criteria_planned,1) AS week_number_planned,
							GROUP_CONCAT(DISTINCT cs.criteria_status_id,\'---\',ra.ca SEPARATOR \', \') AS criteria_status_id,
							GROUP_CONCAT(DISTINCT ca.ca,\'---\',ra.ca SEPARATOR \', \') AS ca_evidence_info,
							GROUP_CONCAT(DISTINCT vl2.action_taken_on,\'---\',ra.ca SEPARATOR \', \') AS supplied,
							GROUP_CONCAT(DISTINCT g.grams_reference,\'---\',rca.review_criterion_applicability_valid_to,\'---\',rca.review_criterion_applicability_valid_from SEPARATOR \', \') AS grams_id,
							GROUP_CONCAT(DISTINCT " ",u.name," ",u.surname,\'---\',ra.ca SEPARATOR \', \') AS provider,
							GROUP_CONCAT(DISTINCT ce.file_link,\'---\',ra.ca SEPARATOR \', \') AS file_link,
							GROUP_CONCAT(DISTINCT " ",u2.name," ",u2.surname,\'---\',ra.ca SEPARATOR \', \') AS validator,
							YEARWEEK(vl.action_taken_on,1) AS week_number
				FROM dr_review_criterion_history 				AS rch
				INNER JOIN dr_review_criterion 					AS rc 		ON  rc.review_criterion_id=rch.criterion
				INNER JOIN dr_review_configuration 				AS rconf 	ON  rconf.criterion=rc.review_criterion_id
				INNER JOIN dr_review_group 						AS gro 		ON 	gro.group_id=rc.review_group
				INNER JOIN dr_review_group_history				AS rgh 		ON  rgh.review_group=gro.group_id
				INNER JOIN dr_review_type 						AS rt 		ON 	rt.review_type_id=gro.review_type
				INNER JOIN dr_review_profile 					AS rp 		ON 	rp.review_type=rt.review_type_id
				INNER JOIN dr_review 							AS r 		ON 	r.review_profile=rp.review_profile_id
																			AND r.review_id=rconf.review
				INNER JOIN dr_review_applicability 				AS ra 		ON 	ra.review=r.review_id
				INNER JOIN c_ca 								AS ca 		ON  ca.ca_id=ra.ca
				INNER JOIN c_program 							AS p 		ON 	p.program_id=rp.program
				INNER JOIN c_coe 								AS coe 		ON 	coe.coe_id=rp.coe
				INNER JOIN c_msn 								AS msn 		ON 	msn.msn_id=r.msn
				LEFT  JOIN dr_criteria_status 					AS cs 		ON 	cs.ca=ra.ca
																			AND cs.review_criteria=rc.review_criterion_id
																			AND cs.msn=r.msn
				LEFT  JOIN dr_criteria_status_evidence 			AS cse 		ON  cse.criteria_status=cs.criteria_status_id
				LEFT  JOIN dr_criteria_evidence 				AS ce 		ON 	ce.criteria_evidence_id=cse.criteria_evidence
				LEFT  JOIN dr_criteria_status_provider 			AS csp 		ON 	csp.criteria_status=cs.criteria_status_id
				LEFT  JOIN c_user 								AS u 		ON 	u.user_id=csp.provider
				LEFT  JOIN dr_validation_loop					AS vl 		ON  vl.applicability=cs.criteria_status_id
																			AND vl.object='.$SESSION['object']['criteria_status_id'].'
																			AND vl.action_taken='.$SESSION['user_action']['validated'].'
																			AND vl.action_taken_on!="0000-00-00 00:00:00"
				LEFT  JOIN c_user 								AS u2 		ON 	u2.user_id=vl.validator
				LEFT  JOIN dr_validation_loop					AS vl2 		ON  vl2.applicability=cs.criteria_status_id
																			AND vl2.object='.$SESSION['object']['criteria_status_id'].'
																			AND vl2.action_taken='.$SESSION['user_action']['originated'].'
				LEFT  JOIN dr_review_criterion_applicability	AS rca		ON	rc.review_criterion_id=rca.criterion
				LEFT  JOIN c_grams								AS g		ON	rca.applicability=g.grams_id
																			AND	rca.object='.$SESSION['object']['grams_id'].'
																			AND (rca.review_criterion_applicability_valid_to="0000-00-00 00:00:00" OR rca.review_criterion_applicability_valid_to="0000-00-00 00:00:01")
				WHERE rp.review_profile_id='.$reviewProfile.'
				AND ra.ca IN ('.$ca.')
				AND rch.criterion_valid_from <= r.validation_date
				AND rch.criterion_valid_from != "0000-00-00 00:00:00"
				AND r.msn='.getFilter('msn','filter',0,$SESSION).'
				GROUP BY cs.criteria_status_id ORDER BY rgh.review_group_position ASC, cs.criteria_status DESC';

	$rawData=SqlLi($query);

	$graphStackedBar		=array();

	$biggestBarStackedBar	=0;

	$reviewTypeName			='';
	$caName					='';
	$program				='';
	$coe					='';
	$msn					='';

	if(!empty($rawData))
	{
		foreach($rawData as $q=>$z)
		{
			//For stacked bar
			$name=explode(' ', $z['review_group_description']);
			$graphStackedBar[$name[0]]['name']=$name[0];
			if($z['criteria_status']==0 && $z['criterion_showstopper']==1 ) $z['criteria_status']=4;
			$graphStackedBar[$name[0]]['criteria_status'][$z['criteria_status']]++;
			if(array_sum($graphStackedBar[$name[0]]['criteria_status']) > $biggestBarStackedBar) $biggestBarStackedBar=array_sum($graphStackedBar[$name[0]]['criteria_status']);

			//For everything
			$reviewTypeName=$z['review_type'];
			$caName=$z['ca_name'];
			$program=$z['program'];
			$coe=$z['coe'];
			$msn=$z['msn'];

		}
	}

	//This is so the stack bar XLSX download works correctly.
	$stackedGroups	=array();
	$stackedPurple	=array();
	$stackedRed		=array();
	$stackedAmber	=array();
	$stackedGreen	=array();
	$stackedBlue	=array();

	foreach ($graphStackedBar as $group => $details) 
	{
		if(empty($details['criteria_status'][4])) $details['criteria_status'][4]=0;
		if(empty($details['criteria_status'][0])) $details['criteria_status'][0]=0;
		if(empty($details['criteria_status'][1])) $details['criteria_status'][1]=0;
		if(empty($details['criteria_status'][2])) $details['criteria_status'][2]=0;
		if(empty($details['criteria_status'][3])) $details['criteria_status'][3]=0;

		array_push($stackedGroups, $details['name']);
		array_push($stackedPurple, $details['criteria_status'][4]);
		array_push($stackedRed, $details['criteria_status'][0]);
		array_push($stackedAmber, $details['criteria_status'][1]);
		array_push($stackedGreen, $details['criteria_status'][2]);
		array_push($stackedBlue, $details['criteria_status'][3]);
	}

	$POST['title']=$program.' - '.$coe.' - '.$msn.' - '.$reviewTypeName.' - '.$caName.' - CW '.date('W').' Stacked Bar';
	$POST['group']=implode(',', $stackedGroups);
	$POST['purple']=implode(',', $stackedPurple);
	$POST['red']=implode(',', $stackedRed);
	$POST['amber']=implode(',', $stackedAmber);
	$POST['green']=implode(',', $stackedGreen);
	$POST['blue']=implode(',', $stackedBlue);
	$POST['filename']=str_replace('/', '_', $program.'_'.$coe.'_'.$msn.'_'.$reviewTypeName.'_'.$caName.'_'.date('Y_m_d_H_i_s').'_stacked_bar');

	array_push($filenames, $POST['filename']);

	include('graphsDownloadStacked.php');
}

$graphZipFile=new zipfile();

foreach($filenames as $filename)
{
	$graphZipFile->add_file(implode("",file('../output/'.$filename.'.xlsx')),$filename.'.xlsx'); 
}

download('zip',$graphZipFile,$program.'_'.str_replace(' / ', '_', $coe).'_'.$msn.'_'.$reviewTypeName.'_stacked_bars.zip');

?>