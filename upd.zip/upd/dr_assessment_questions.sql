-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2019 at 11:32 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newart_dump`
--

-- --------------------------------------------------------

--
-- Table structure for table `dr_assessment_questions`
--

CREATE TABLE `dr_assessment_questions` (
  `question_id` int(11) NOT NULL,
  `question_name` longtext NOT NULL,
  `question_hidden` int(10) DEFAULT '0',
  `admin_modifier_id` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dr_assessment_questions`
--

INSERT INTO `dr_assessment_questions` (`question_id`, `question_name`, `question_hidden`, `admin_modifier_id`) VALUES
(1, 'Isthereanyactionispending', 0, 0),
(2, 'How may actions are completed?', 0, 0),
(3, 'How many persons are currently logged in?', 0, 0),
(4, 'How many reviews are currently Pending?', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dr_assessment_questions`
--
ALTER TABLE `dr_assessment_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dr_assessment_questions`
--
ALTER TABLE `dr_assessment_questions`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
