<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');

$GET=cleanArray($_GET);

//$title=($GET['change']=='new')?'New':'Edit';

if($GET['change_remark_id']!='new' && $GET['change_remark_id']!=''){
	$changeRemark=SqlQ('SELECT change_remark FROM dr_change_remark WHERE change_remark_id="'.$GET['change_remark_id'].'"');
}

$title=($GET['change_remark_id']=='new')?'New Remark':'Edit Remark';

?>OK|||<div id="remarkContainer"style="float:left;text-align:left;width:800px;"><?php
	formTitle('',$title,'remarkContainer','',$popUpParameter='');
	?><div class="formStdContainer"><?php
		?><form action="#"enctype="multipart/form-data"id="changeRemarkFrm"method="post"style="display:inline;"><?php
			?><input id="change_id"name="change_id"type="hidden"value="<?=$GET['change_id']?>"><?php
			?><input id="change_remark_id"name="change_remark_id"type="hidden"value="<?=$GET['change_remark_id']?>"><?php
			?><div class="leftInfoBox"style="margin-top:50px;width:800px;"><?php
				?><table class="criteriaTable"style="width:800px;"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Remark</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Remark</td><?php
						?><td><textarea class="formInput"cols="139"id="change_remark"name="change_remark"onMouseOver="setInputFocus(this);"rows="7"style="overflow-x:hidden;"><?=$changeRemark['change_remark']?></textarea></td><?php
					?></tr><?php
				?></table><?php
				?><div class="save"><?php
					?><input class="stdBtn"onClick="sendAjaxForm('changeRemarkFrm','ajax/saveChangeRemark.php','updateData','');closeLastForm();"type="button"value="Save and Close"><?php
				?></div><?php
			?></div><?php
		?></form><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>