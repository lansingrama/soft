<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$count=0;

if($include!=1) 
{
	$GET=cleanArray($_GET);
	$allHistoryIDsForThisObject;
	$title;
	
	switch($GET['object'])
	{
		case $SESSION['object']['criterion_validity_id']:
			$allHistoryIDsForThisObject=SqlLi('SELECT criterion_validity_id FROM dr_review_criterion_history WHERE criterion='.$GET['criterionID'].' ORDER BY criterion_validity_id DESC');
			$title = 'Criteria';
		break;

		case $SESSION['object']['review_id']:
			if($GET['ca'])
			{
				$allHistoryIDsForThisObject=SqlLi('SELECT review_id AS criterion_validity_id 
													FROM dr_review_applicability AS ra
													INNER JOIN dr_review AS r ON r.review_id=ra.review
													WHERE ca='.$GET['ca'].'
													AND review_profile='.$GET['review_profile']);
				$GET['applicability'] = $allHistoryIDsForThisObject[0]['criterion_validity_id'];
				$title = 'Review';
			}
			else
			{
				$allHistoryIDsForThisObject=SqlLi('SELECT review_id AS criterion_validity_id FROM dr_review WHERE review_id='.$GET['criterionID']);
			}
		break;

		case $SESSION['object']['criteria_status_id']: //JFM 09_04_14
			$allHistoryIDsForThisObject=SqlLi('SELECT criteria_status_id AS criterion_validity_id
												FROM dr_criteria_status AS ca
												WHERE criteria_status_id IN ('.$GET['applicability'].')');
			$title = 'Evidence';
		break;

		case $SESSION['object']['action_id']: //JFM 30_10_14
			if($GET['applicability'] != "new") //JFM 17_08_15
			{
				$allHistoryIDsForThisObject=SqlLi('SELECT action_id AS criterion_validity_id
													FROM dr_action
													WHERE action_id='.$GET['applicability']);
			}
			$title = 'Action';
		break;
	}
	
	$count=count($allHistoryIDsForThisObject);
}

//JFM 27_03_14 - JFM 17_08_15
if(!empty($GET['applicability']) && $GET['applicability'] != "new") $validationLoopStructure=SqlLi('SELECT * FROM dr_validation_loop_structure WHERE applicability IN ('.$GET['applicability'].') AND object='.$GET['object'].' ORDER BY validation_loop_structure_step ASC');
$previousValidator;
$maxValidationLoopID;
$maxValidationLoopStructureStep;

if($included!=1)
{
	?>OK|||<?php
	?><div class="formHeader"><?php
		?><div class="formHeaderInfo"><?=$title?> Workflow</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
}

?><div id="decisionContainer"style="text-align:center;width:960px; margin: 0 auto;"><?php
	?><div class="criteriaCreateBody"><?php
	
	if(!empty($validationLoopStructure))
	{
		foreach ($validationLoopStructure as $k=>$v)
		{				
			$user=SqlQ('SELECT name, surname FROM c_user WHERE user_id='.$v['validator']);
			$dateAndComment=SqlQ('SELECT validation_loop_id, action_taken_on, validator_comment, validator FROM dr_validation_loop WHERE applicability IN ('.$GET['applicability'].') AND validation_loop_step='.$v['validation_loop_structure_step'].' AND object='.$GET['object'].' ORDER BY validation_loop_id DESC LIMIT 1');
			if($dateAndComment['validation_loop_id']!='') $action=SqlQ('SELECT user_action FROM c_user_action WHERE user_action_id=(SELECT action_taken FROM dr_validation_loop WHERE validation_loop_id='.$dateAndComment['validation_loop_id'].')');
			
			if($dateAndComment['action_taken_on']=="0000-00-00 00:00:00")
			{
				$maxValidationLoopID=$dateAndComment['validation_loop_id'];
				$maxValidationLoopStructureStep=$v['validation_loop_structure_step'];
				$previousValidator=utf8_encode($user['name'].' '.$user['surname']);
			}
		}				
	}
	
	if(!empty($allHistoryIDsForThisObject))
	{
		foreach ($allHistoryIDsForThisObject as $k=>$v)
		{
			$validationLoop=SqlLi('SELECT * FROM dr_validation_loop WHERE applicability IN ('.$v['criterion_validity_id'].') AND object='.$GET['object'].' ORDER BY validation_loop_step ASC, validation_loop_id ASC');
			$maxMinDate=SqlLi('SELECT MAX(action_taken_on) AS atomax, MIN(action_taken_on) AS atomin FROM dr_validation_loop WHERE applicability IN ('.$v['criterion_validity_id'].') AND object='.$GET['object'].' ORDER BY validation_loop_id ASC');
			$numberOfSubloops=SqlLi('SELECT COUNT(*) AS num FROM dr_validation_loop WHERE applicability IN ('.$v['criterion_validity_id'].') AND object='.$GET['object'].' AND validation_loop_step=0');
			$validationLoopStructureIfOngoing=0;
						
			if(!empty($validationLoop))
			{
				if($maxMinDate[0]['atomin']=="0000-00-00 00:00:00")
				{
					?><div align="left" style="font-size:14px; color:#000000; margin-bottom:10px;"><br />Validation Loop <?=$count?>. On going...</div><?php
					$countValidationLoop=count($validationLoop)-1;
					$validationLoopStructureIfOngoing=SqlLi('SELECT * FROM dr_validation_loop_structure WHERE applicability IN ('.$v['criterion_validity_id'].') AND object='.$GET['object'].' AND validation_loop_structure_step > '.$validationLoop[$countValidationLoop]['validation_loop_step'].' ORDER BY validation_loop_structure_step ASC');
				}
				else
				{
					?><div align="left" style="font-size:18px; color:black;"><br />Validation Loop <?=$count?>. Start: <?=substr($maxMinDate[0]['atomin'],0,10)?> | End: <?=substr($maxMinDate[0]['atomax'],0,10)?></div><?php
				}

				?><table class="criteriaTable" id="workflowTable" style="width:100%;" cellspacing="0" cellpadding="5"><?php
					?><tr class="infoRow"><?php
						?><td bgcolor="#e7e7e8"></td><?php
						
						for($i=1;$i<=$numberOfSubloops[0]['num'];$i++)
						{
							?><td bgcolor="#e7e7e8">SubLoop <?=$i?></td><?php
						}
					?></tr><?php
					
					$addTr=true;
					$addtd=0;
					$rowNumber=0;
					$columnNumber=0;
					$blankColumn=array();
					$cancelledArray=Array(); //JFM 18_03_14
					$countCancelledArray=1;

					foreach ($validationLoop as $m=>$o)
					{
						$fullUserName='';
						if($o['validator']==0 && $o['object']==$SESSION['object']['criteria_status_id']) //JFM 09_04_14
						{
							$user=SqlLi('SELECT name, surname FROM c_user  AS u
											INNER JOIN dr_criteria_status_provider AS csp
												ON csp.provider=u.user_id
											WHERE csp.criteria_status IN ('.$o['applicability'].')');

							foreach ($user as $k=>$l)
							{
								$fullUserName.=$l['surname'].', '.$l['name'].' & ';
							}

							$fullUserName=rtrim($fullUserName, " & ");
						}
						else
						{
							$user=SqlQ('SELECT name, surname FROM c_user WHERE user_id='.$o['validator']);
							$fullUserName=$user['surname'].', '.$user['name'];
						}

						$action=SqlQ('SELECT user_action FROM c_user_action WHERE user_action_id='.$o['action_taken']);

						if($addTr)
						{
							$rowNumber++;
							$columnNumber=0;
							?><tr class="infoRow"><?php
							?><td bgcolor="#e7e7e8"><?=utf8_encode($fullUserName)?></td><?php //JFM 09_04_14
							for($i=0;$i<$addtd;$i++)
							{
								if($validationLoop[$i+1]['received_on']<$o['received_on'] && $i<($numberOfSubloops[0]['num']-1)) //JFM 02_13_13
								{
									$blankColumn[$rowNumber][$columnNumber]='blank';
									?><td></td><?php
									$columnNumber++;
								}
							}
							
							$addTr=false;
						}

						if(in_array($countCancelledArray, $cancelledArray)) //JFM 18_03_14
						{
							?><td></td><?php
							$countCancelledArray++;
						}



						$colour;
						switch($action['user_action'])
						{
							case "originated":
							case "validated":
								$colour="81c341";
								break;

							case "modified":
								$colour="81c341";
								$addtd++;
								break;
								
							case "rejected":
							case "returned": //JFM 07_04_14
								$colour="ef343f";
								$addtd++;
								break;
								
							case "cancelled":
								$colour="ef343f";
								array_push($cancelledArray, $countCancelledArray); //JFM 18_03_14
								$addtd++;
								break;
								
							case "removed":
							case "forward and never ask":
								$colour="f47922";
								break;
								
							case "forward":
								$colour="0088CF";
								break;
								
							default:
								$colour="FFFFFF";
								break;
						}

						if($o['action_taken_on']=="0000-00-00 00:00:00")
						{
							?><td style="color:#71798C; text-align:center;">Current Step.</td><?php
						}
						else
						{
							$blankColumn[$rowNumber][$columnNumber]=$action['user_action'];
							?><td bgcolor="#<?=$colour?>"><b><?=strtoupper($action['user_action'])?></b><br />(<?=$o['action_taken_on']?>)<br /><i><?=utf8_encode($o['validator_comment'])?></i></td><?php	
							$columnNumber++;
						}
						
						$previousValidator=utf8_encode($user['name'].' '.$user['surname']);
						if($o['validator']!=$validationLoop[$m+1]['validator'])
						{
							if($o['validation_loop_step']==$validationLoop[$m+1]['validation_loop_step'] && $action['user_action']=="removed") $addtd++; //JFM 03_12_13
							?></tr><?php	
							$addTr=true;
							$countCancelledArray=0;
						}
						else if($o['validator']==$validationLoop[$m+1]['validator'])
						{
							if($o['validation_loop_step']!=$validationLoop[$m+1]['validation_loop_step']) 
							{
								?></tr><?php	
								$addTr=true;
								$countCancelledArray=0;
							}
						}
						$countCancelledArray++;
					}
					
					if(!empty($validationLoopStructureIfOngoing))
					{
						foreach ($validationLoopStructureIfOngoing as $m=>$o)
						{
							$user=SqlQ('SELECT name, surname FROM c_user WHERE user_id='.$o['validator']);
							
							?><tr class="infoRow" ><?php
							?><td bgcolor="#e7e7e8"><?=utf8_encode($user['surname'])?>, <?=utf8_encode($user['name'])?></td><?php
							/*for($i=0;$i<$addtd;$i++)
							{
								?><td></td><?php
							}
							?><td style="color:#71798C; text-align:center;" bgcolor="#FFFFFF">Pending <?=$previousValidator?>'s approval...</td><?php*/
							$previousValidator=utf8_encode($user['name'].' '.$user['surname']);
							?></tr><?php
						}
					}
						
				?></table><?php

			}
			else
			{
				?><div align="left" style="font-size:18px; color:black;"><br />Validation Loop <?=$count?>. Start: ??? | End: ???</div><?php
				?><table class="criteriaTable" id="workflowTable" style="width:100%;"><?php
					
					?><tr class="infoRow" bgcolor="#FFFFFF"><?php
						?><td colspan="4" style="color:#71798C; text-align:center;">Nothing to Display!</td><?php
					?></tr><?php
					
				?></table><?php
			}
		
			$count--;
		}
	}
	else if($included!=1) //JFM 27_03_14
	{
		?><div align="left" style="font-size:18px; color:black;"><br />Validation Loop <?=$count?>. Start: ??? | End: ???</div><?php
		?><table class="criteriaTable" id="workflowTable" style="width:100%;" cellspacing="0" cellpadding="0"><?php
			
			?><tr class="infoRow" bgcolor="#FFFFFF"><?php
				?><td colspan="4" style="color:#71798C; text-align:center;">Nothing to Display!</td><?php
			?></tr><?php
			
		?></table><?php
	}
	
	?></div><?php
?></div><?php

storeSession($SESSION);
?>