<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');

?>OK|||<div id="rowConfigContainer"style="float:left;width:380px;"><?php
	formTitle(380,'Configure Rows','rowConfigContainer');
	?><div class="sp"></div><?php
	?><form action="#" enctype="multipart/form-data" id="rowConfigFrm" method="post" style="display:inline;"><?php
		?><div class="prompt" onClick="validateRowConfig();" onKeyUp="validateRowConfig();"><?php
			?><table class="criteriaTable" style="width:400px;" cellspacing="0" cellpadding="0"><?php
				?><tr class="tableGroup prmRow"><?php
					?><td></td><td>Row Configuration</td><?php
				?></tr><?php
				?><tr class="infoRow"><?php
					?><td class="paramDef">Disabled CAs</td><?php
					?><td><?php
						?><input<?php if(getFilter('disabled_ca','view',0,$SESSION)==1){?> checked<?php }?> id="disabled_ca" name="disabled_ca" type="checkbox" value="1"> Show Disabled CAs<?php
					?></td><?php
				?></tr><?php
				?><tr class="infoRow"><?php
					?><td class="paramDef">Repeat Header</td><?php
					?><td><?php
						?><input<?php if(getFilter('repeat_header','view',0,$SESSION)==1){?> checked<?php }?> id="repeat_header" name="repeat_header" type="checkbox" value="1">Rep. every <?php
						?><input class="textareaWhite" id="header_frequency" maxlength="3" name="header_frequency" size="3" style="text-align:right" type="text" value="<?=getFilter('header_frequency','view',0,$SESSION)?>"> Rows<?php
					?></td><?php
				?></tr><?php
				?><tr class="infoRow"><?php
					?><td class="paramDef">Max Results</td><?php
					?><td><?php
						?>Show Max <?php
						?><input class="textareaWhite" id="max_results" maxlength="3" name="max_results" size="3" style="text-align:right" type="text" value="<?=getFilter('max_results','view',0,$SESSION)?>"> Results each time<?php
					?></td><?php
				?></tr><?php
			?></table><?php
			?><div class="save"><span class="saveResponse" id="rowConfig_saveResponse">Changes were applied</span><?php
		?></div><?php
		?><div class="save" style="width:350px;"><?php
			?><input class="stdBtn" id="applyRowConfigChanges" onClick="sendAjaxForm('rowConfigFrm','ajax/saveRowConfig.php','restartMainTable','');" type="button" value="Apply Changes and Close &#9658;"> <?php
			/*?><input class="stdBtn" onClick="closeLastForm();" type="button" value="Cancel"><?php*/
		?></div><?php
	?></form><?php
?></div><?php
storeSession($SESSION);
?>