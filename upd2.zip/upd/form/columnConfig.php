<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);
$program=getFilter('program','filter',0,$SESSION);
$coe=getFilter('coe','filter',0,$SESSION);
$msn=getFilter('msn','filter',0,$SESSION);

$review=array('ca'=>'CA',/*'responsible'=>'Responsible',*/'review'=>'Review','cat'=>'Criteria List','evd'=>'Evidence List','action'=>'Action','rid'=>'RID'); //JFM 02_12_13

?>OK|||<div id="columnConfigContainer"style="text-align:center;width:960px;"><?php
	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo">Configure Columns</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="locationSideContainer"><?php
		?><div style="float:left;">Program</div><?php
		?><div style="float:right;"><?php
			$programList=allowedSimpleObject('program','program',$SESSION,'c_');
			drawddList('cfcDdProgram',$programList,$program,'','resetSideSelection(\'cfc\');',0);
		?></div><?php
		?><div style="clear:both;height:3px;width:100%;"></div><?php
		?><div style="float:left;">CoE</div><?php
		?><div style="float:right;"><?php
			$coeList=allowedSimpleObject('coe','coe',$SESSION,'c_');
			drawddList('cfcDdCoe',$coeList,$coe,'','resetSideSelection(\'cfc\');',0);
		?></div><?php
	?></div><?php

	?><div class="sideList"id="reviewList"style="top:110px;"><?php
		foreach($review as $k=>&$v){
			?><div class="sideElement"id="cfColElement_<?=$k?>"onClick="openSideElement('<?=$k?>','cfc');"><?=utf8_encode($v)?></div><?php
		}
	?></div><?php
	
	?><div class="sideDetailsContainer"id="columnConfigSideContainer"><?php
		?><div class="sideContainerEmpty">Select an Element from the list.</div><?php

	?></div><?php
?></div><?php
storeSession($SESSION);
?>