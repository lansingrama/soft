<?php
/*
	To download video file in help page
	Sprint3 - Additional Task and download option
	Videos has been added
	Version: 4.3
	Fixed By: Infosys Limited
*/
       
$img = "archive/".$_REQUEST['img'];
//$url_file = "http://localhost:8080/ART/Local_ART/design_reviews/dr_report/".$img;
$url_file = "http://de0-vsiaas-993.eu.airbus.corp/1V55/dr_report/".$img;
// get the file size and send the http headers
$size = filesize($url_file);
header('Content-Type: application/octet-stream');
header('Content-Length: '.$size);  
$headers  = get_headers($url_file, 1);
header('Content-Length: '.($headers['Content-Length']));
header('Content-Disposition: attachment; filename="'.basename($url_file).'"');
header('Content-Transfer-Encoding: binary');
// open the file in binary read-only mode
// display the error messages if the file can´t be opened
$file = @ fopen($url_file, 'rb');
if ($file) {
// stream the file and exit the script when complete
fpassthru($file);
exit;
}
?> 
