<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$hideRemove=false;

if($GET['object']==$SESSION['object']['criteria_status_id'] || $GET['object']==$SESSION['object']['action_id']) //JFM 28_04_14 - 30_10_14
{
	$checkIfYourTheOnlyPersonInTheValidationLoopSoYouCantRemoveYourselfQry=SqlLi('SELECT * FROM dr_validation_loop_structure 
																						WHERE applicability='.$GET['applicability'].' 
																						AND object='.$GET['object'].'
																						AND validation_loop_structure_step!=0
																						AND validator_removed=0
																						ORDER BY validation_loop_structure_step DESC');

	if(!empty($checkIfYourTheOnlyPersonInTheValidationLoopSoYouCantRemoveYourselfQry))
	{
		if(count($checkIfYourTheOnlyPersonInTheValidationLoopSoYouCantRemoveYourselfQry)<2) $hideRemove=true;
	}
}


$hoverValidate=	'<b>Validate</b><br />- Approve this item.<br />- This will then be passed to the next validator for approval, shown at the top of the window.<br />- If you are the last validator the changes will be finalised in the database.';
$hoverForward=  '<b>Forward To...</b><br />- Forward this item.<br />- If you believe a person should be part of this items validation process who is not already included.<br />- Check Never ask me again to be removed from the loop after forwarding.';
$hoverRemove=	'<b>Remove me from the loop</b><br />- Removes you from the validation loop.<br />- If you do not wish to be part of this items validation process.<br />- A comment is required for this option.';
$hoverReject=	'<b>Reject</b><br />- Rejects this item.<br />- If you do not believe this item is of a satisfactory standard, reject the item and send it back to the originator for correction.<br />- A comment is required for this option.';
$hoverAll=$hoverValidate.'<br /><br />'.$hoverForward.'<br /><br />'.$hoverRemove.'<br /><br />'.$hoverReject;


?><div id="decisionContainer"style="text-align:center; width:960px;"><?php
	?><div class="criteriaCreateBody" style="margin-top:0px;"><?php
		?><form action="#" enctype="multipart/form-data" id="decisionForm" name="decisionForm" method="post"style="display:inline;"><?php
			?><input id="validationLoopID" name="validationLoopID" style="display:none;" value="<?=$maxValidationLoopID?>" disabled /><?php
			?><input id="validationLoopStructureStep" name="validationLoopStructureStep" style="display:none;" value="<?=$maxValidationLoopStructureStep?>" disabled /><?php
			?><input id="object" name="object" style="display:none;" value="<?=$GET['object']?>" disabled /><?php
			?><input id="applicability" name="applicability" style="display:none;" value="<?=$GET['applicability']?>" disabled /><?php
			if(!empty($GET['extra_comments']))
			{
				?><input id="extra_comments" name="extra_comments" style="display:none;" value="VALIDATED BY <?=utf8_encode($SESSION['user']['name'])?>,<?=utf8_encode($SESSION['user']['surname'])?> ON BEHALF OF VALIDATOR: " disabled /><?php
			}

			if($GET['object']==$SESSION['object']['criteria_status_id'])
			{
				?><input id="msn" name="msn" style="display:none;" value="<?=$GET['msn']?>" disabled /><?php
				?><input id="review_profile" name="review_profile" style="display:none;" value="<?=$GET['review_profile']?>" disabled /><?php
				?><input id="ca" name="ca" style="display:none;" value="<?=$GET['ca']?>" disabled /><?php
				?><input id="review_criteria_id" name="review_criteria_id" style="display:none;" value="<?=$GET['review_criteria_id']?>" disabled /><?php
			}
			
			?><table class="criteriaTable" id="decisionTable" style="width:100%;" cellpadding="5" cellspacing="0"><?php
			
				?><tr class="tableGroup"><?php
					?><td colspan="5">Decision</td><?php
				?></tr><?php
				
				?><tr class="infoRow"><?php
					?><td class="paramDef" width="20%" rowspan="2">Decision:<div id="decisionResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
					?><td width="20%"><input type="radio" name="decisionRadio" onclick="$('neverAgain').style.visibility='hidden'; $('neverAgainCheck').checked=false; $('forwardName').value='';" value="validate">Validate</td><?php
					?><td width="20%"><input type="radio" name="decisionRadio" onclick="$('neverAgain').style.visibility='visible';" value="forward">Forward To...</td><?php
					?><td width="20%"><input type="radio" name="decisionRadio" onclick="$('neverAgain').style.visibility='hidden'; $('neverAgainCheck').checked=false; $('forwardName').value='';" value="remove" <?=($hideRemove)?'disabled':''?>>Remove me from the loop</td><?php
					?><td width="20%"><input type="radio" name="decisionRadio" onclick="$('neverAgain').style.visibility='hidden'; $('neverAgainCheck').checked=false; $('forwardName').value='';" value="reject">Reject</td><?php
				?></tr><?php
				
				?><tr class="infoRow"><?php
					?><td></td><?php
					?><td width="20%"><?php
						?><div id="neverAgain" style="visibility:hidden"><?php
							?><div class="suggestion" id="forwardNameSpan"style="width:175px;"></div><?php
							?><input class="textareaWhite" id="forwardName" name="forwardName" onFocus="loadUserSuggestion(this,'forwardNameSpan','forwardName','','suggestionID0');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php	
							?><br /><input type="checkbox" name="neverAgainCheck" id="neverAgainCheck" />Never ask me again.<?php
						?></div><?php
					?></td><?php
					?><td colspan="2"></td><?php
				?></tr><?php
				
				?><tr class="infoRow"><?php
					?><td class="paramDef" width="20%">Comments:<div id="decisionCommentsResponse" style="visibility:hidden;" >&zwnj;</div></td><?php
					?><td colspan="4"><textarea class="textareaWhite" style="width:99%;" rows="5" id="decisionComments" name="decisionComments"></textarea></td><?php
				?></tr><?php	

				?><tr class="infoRow"><?php
					?><td colspan="5" align="right"><img style="padding-left:25px; cursor:pointer;" id="help" onMouseOut="nd();" onMouseOver="overlib('<?=$hoverAll?>', ABOVE, CAPTION,'Decision Help');"src="../common/img/xhelp.png"></td><?php
				?></tr><?php		
							
			?></table><?php
						
			?><div class="save"><?php
				?><span class="saveResponse"id="decision_saveResponse">Changes were applied</span><?php
				?><input class="stdBtn" id="validateDecisionSubmit" onClick="if(validateDecision('<?=utf8_encode($SESSION['user']['name'])?>','<?=utf8_encode($SESSION['user']['surname'])?>')){this.disabled=true; this.value='Please Wait...'; sendAjaxForm('decisionForm','ajax/saveDecision.php','putInDiv','decision_saveResponse','POST',true); <?=empty($GET['extra_comments'])?'clock(); clock(); sideValidation('.$GET['object'].');':'closeLastForm();'?>}"type="button"value="Submit &#9658;"><?php //JFM 30_10_14
			?></div><?php
			
		?></form><?php
	?></div><?php
?></div><?php

storeSession($SESSION);
?>