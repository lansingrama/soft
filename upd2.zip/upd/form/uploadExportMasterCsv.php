<?php
require_once('../support/header.php');
require_once('../support/form.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);

?>OK|||<div id="uploadCsvContainer"style="text-align:center;"style="width:380px;"><?php

	formTitle(380,'Upload Master Criteria','uploadCsvContainer');

	?><div class="sp"></div><?php
        	?><form action="support/uploadMasterCsvPreCheck.php" enctype="multipart/form-data" id="uploadFileFrm" method="post" target="resultIFrame"><?php

		?><input name="type" type="hidden" value="<?=$GET['type']?>"><?php
		?><div class="prompt"><?php
			?><input class="stdBtn" id="uploadedFile" type="file" name="uploadedFile" size="31"> <?php			
			?><input class="stdBtn" type="submit" name="submit" value="Upload CSV &#9658;">&nbsp;<?php
		?></div><?php

	?></form><?php

?></div>