<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
$lastChangeLogId=$_GET['last_change_log_id'];
$changeLogQry=SqlLi('SELECT cl.change_log_id,cl.change_log_tstamp,clt.change_log_type_out,cl.change_log
						FROM c_change_log AS cl
							INNER JOIN c_tool AS t ON t.tool_id=cl.tool
							INNER JOIN c_change_log_type AS clt ON clt.change_log_type_id=cl.change_log_type
						WHERE t.code="DR"
						ORDER BY cl.change_log_tstamp DESC');
?>OK|||<div id="logContainer"style="text-align:center;width:960px;"><?php
	?><div class="formHeader"><?php //JFM 25_06_14
		?><div class="formHeaderInfo">Change Log</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php
	?><div class="sp"></div><?php
	?><div class="wideFormTable" id="reviewCriteriaList"><?php
		?><table class="criteriaTable"id="logTable"style="width:960px;" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup"><?php
			?><tr class="tableGroup"><td style="width:124px;">Date</td><td>Log Type</td><td>Event</td></tr><?php
			?></tr><?php
			if(is_array($changeLogQry)){
				foreach($changeLogQry as &$changeLog){//#E5E5E5
					$g=($lastChangeLogId!='' && $changeLog['change_log_id']>$lastChangeLogId)?' bgcolor="#FFFBCC"':'';
					?><tr<?=$g?>><?php
						?><td nowrap><?=$changeLog['change_log_tstamp']?></td><?php
						?><td nowrap><?=$changeLog['change_log_type_out']?></td><?php
						?><td><?=$changeLog['change_log']?></td><?php
					?></tr><?php
				}
			}
		?></table><?php
	?></div><?php
storeSession($SESSION);
?>