<?php //JFM 13_05_16
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$GET = cleanArray($_GET);

$included=1;

$areaList=allowedSimpleObject('area','area',$SESSION,'c_');
$currentArea = getFilter('area','filter',0,$SESSION);

?>OK|||<div id="structureContainer"><?php

	?><div class="formHeader"><?php
		?><div class="formHeaderInfo">Area Management - <?=$areaList[$currentArea]?></div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php

	?><div class="sideDetailsContainer" style="left: 10px; top: 60px;" id="sideAreaManagementContainer"><?php

		if(!empty($currentArea))
		{
			require_once('../ajax/editAreaManagement.php');
		}

	?></div><?php
?></div><?php
storeSession($SESSION);
?>