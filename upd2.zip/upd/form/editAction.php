<?php
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

session_start();
$SESSION=$_SESSION;
$msn=getFilter('msn','filter',0,$SESSION);

foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);
$status=array('r','a','g');

$action=SqlQ('SELECT ac.criteria,ac.rid,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_status,ac.action_holder,ac.action_holder_name,ac.action_validator,ac.action_validator_name,
					rd.rid_code,rd.rid_title,rd.rid_status,rd.rid_holder,rd.rid_holder_name,rd.rid_creation,rd.rid_completion,
					CONCAT(uah.surname,", ",uah.name) AS action_holder_txt,CONCAT(uav.surname,", ",uav.name) AS action_validator_txt,CONCAT(urh.surname,", ",urh.name) AS rid_holder_txt
				FROM dr_action AS ac
					LEFT JOIN dr_rid AS rd ON ac.rid=rd.rid_id
					LEFT JOIN c_user AS uah ON uah.user_id=ac.action_holder
					LEFT JOIN c_user AS uav ON uav.user_id=ac.action_validator
					LEFT JOIN c_user AS urh ON urh.user_id=rd.rid_holder
				WHERE ac.action_id="'.$GET['action'].'"
				LIMIT 1');
$action=utf8enc($action);

$applicability=SqlSLi('SELECT ca FROM dr_action_applicability WHERE action="'.$GET['action'].'"','ca');

$wp=SqlQ('SELECT wp FROM c_cawp WHERE c_cawp.msn="'.$msn.'" AND ca="'.$applicability[0].'"');

$ca=SqlAsArr('SELECT ca.ca_id,ca.ca
			FROM c_ca AS ca
				INNER JOIN c_cawp AS cawp ON ca.ca_id=cawp.ca
			WHERE cawp.msn="'.$msn.'" AND cawp.wp="'.$wp['wp'].'"
			ORDER BY ca ASC','ca_id','ca');

$ridList=SqlAsLi('SELECT r.rid_id,r.rid_code,r.rid_title
					FROM dr_rid AS r
						INNER JOIN dr_action AS a ON r.rid_id=a.rid
					WHERE a.msn="'.$msn.'" AND a.criteria="'.$action['criteria'].'"','rid_id');

$activeActionStatus=pictureStatus($action['action_status']);
$activeRidStatus=pictureStatus($action['rid_status']);

?>OK|||<div id="editActionContainer"style="text-align:center;width:960px;"><?php
	?><div class="formStdContainer"><?php
		?><div class="xDiv" style="text-align:right;"><img alt="Close this Window" onClick="closeForm('editActionContainer');"src="../common/img/x.png"style="cursor:pointer;"></div><?php
		?><div class="formHeaderInfo">Edit Action <?=$action['action_code']?></div><?php
	?></div><?php
	?><div class="sp"></div><?php
	?><div class="formStdContainer"><?php
		?><form action="#"enctype="multipart/form-data"id="actionFrm"method="post"style="display:inline;"><?php
			?><input id="msn"name="msn"type="hidden"value="<?=$msn?>"><?php
			?><input id="wp"name="wp"type="hidden"value="<?=$wp['wp']?>"><?php
			?><input id="criteria"name="criteria"type="hidden"value="<?=$action['criteria']?>"><?php
			?><input id="action_id"name="action_id"type="hidden"value="<?=$GET['action']?>"><?php
			?><input id="action_status"name="action_status"type="hidden" value="<?=$status[$action['action_status']]?>"><?php
			?><input id="applicable_ca"name="applicable_ca"type="hidden"value="<?=implode(',',array_keys($ca))?>"><?php
			?><input id="action_holder"name="action_holder"type="hidden"value="<?=$action['action_holder']?>"><?php
			?><input id="action_validator"name="action_validator"type="hidden"value="<?=$action['action_validator']?>"><?php
			/*?><input id="rid_id"name="rid_id"type="hidden"value="<?=$action['rid']?>"><?php*/
			?><input id="rid_status"name="rid_status"type="hidden"value="<?=$status[$action['rid_status']]?>"><?php
			?><input id="rid_holder"name="rid_holder"type="hidden"value="<?=$action['rid_holder']?>"><?php
			
			?><div class="reviewCaList"><?php
				?><div class="tableTitle">Applicability:</div><?php
				?><table class="criteriaTable"style="width:140px;"><?php
					?><tr class="tableGroup"><?php
						?><td align="center"><input checked onClick="this.checked=true;selectAll('applicable_ca');" type="checkbox"></td><?php
						?><td style="width:100%;">CA</td><?php
					?></tr><?php
						/*?><tr class="infoRow"><?php
							?><td colspan="2"><input class="stdBtn"type="button"value="Select All"></td><?php
						?></tr><?php				*/
					foreach($ca as $k=>$v){
						?><tr class="infoRow"><?php
							?><td class="chkList"><input id="applicable_ca_<?=$k?>"name="applicable_ca_<?=$k?>"<?php if(in_array($k,$applicability))echo'checked '?>type="checkbox"></td><?php
							?><td><?=$v?></td><?php
						?></tr><?php
					}
				?></table><?php
			?></div><?php
	
			?><div class="leftInfoBox" style="width:800px"><?php
				?><div class="tableTitle">Action Information:</div><?php
				?><table class="criteriaTable" style="width:800px;"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Main Information</td><?php
						?><td colspan="2">Notes</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:55px;">Status</td><?php
						?><td style="width:175px;"><?php
							?><img id="actionStatus_r"onMouseOver="setStatusFocus(this,'action_status')"src="../common/img/r<?=$activeActionStatus[0]?>30Off.jpg"style="cursor:pointer;"><span style="cursor:default;padding-right:10px;"></span><?php
							?><img id="actionStatus_a"onMouseOver="setStatusFocus(this,'action_status')"src="../common/img/a<?=$activeActionStatus[1]?>30Off.jpg"style="cursor:pointer;"><span style="cursor:default;padding-right:10px;"></span><?php
							?><img id="actionStatus_g"onMouseOver="setStatusFocus(this,'action_status')"src="../common/img/g<?=$activeActionStatus[2]?>30Off.jpg"style="cursor:pointer;"><?php
						?></td><?php
						?><td class="paramDef"rowspan="3"style="width:55px;">Description</td><?php
						?><td rowspan="3"style="width:515px;"><textarea cols="81"id="action_description"name="action_description"onMouseOver="setInputFocus(this);"rows="7"style="overflow-x:hidden;"><?=$action['action_description']?></textarea></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Dates</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Creation</td><?php
						?><td><?php
							drawDate('action_creation','creationDateCal',$action['action_creation'],false);
						?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Completion</td><?php
						?><td><?php
							drawDate('action_completion','completionDateCal',$review['action_completion'],false);
						?></td><?php
						?><td class="paramDef"rowspan="4">Remarks</td><?php
						?><td rowspan="4"><textarea cols="81"id="action_remark"name="action_remark"onMouseOver="setInputFocus(this);"rows="8"style="overflow-x:hidden;"><?=$action['action_remark']?></textarea></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Responsibles</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Holder</td><?php
						drawUserField('suggestion_action_holder','action_holder_name','action_holder',$action['action_holder_txt'],$action['action_holder_name']);
						/*?><td><?php
							?><div class="suggestion"id="suggestion_action_holder"style="width:159px;"></div><input class="formInput"id="action_holder_name"name="action_holder_name"onFocus="loadUserSuggestion(this,'suggestion_action_holder','action_holder','')"onMouseOver="setInputFocus(this,'suggestion_action_holder','action_holder','');"size="28"type="text"value="<?=($action['action_holder_txt'])?$action['action_holder_txt']:$action['action_holder_name']?>"><?php
						?></td><?php*/
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Validator</td><?php
						drawUserField('suggestion_action_validator','action_validator_name','action_validator',$action['action_validator_txt'],$action['action_validator_name']);
						/*?><td><?php
							?><div class="suggestion"id="suggestion_action_validator"style="width:159px;"></div><input class="formInput"id="action_validator_name"name="action_validator_name"onFocus="loadUserSuggestion(this,'suggestion_action_validator','action_validator','')"onMouseOver="setInputFocus(this,'suggestion_action_validator','action_validator','');"size="28"type="text"value="<?=($action['action_validator_txt'])?$action['action_validator_txt']:$action['action_validator_name']?>"><?php
						?></td><?php*/
					?></tr><?php
				?></table><?php
		?></div><?php
		?><div class="leftInfoBox" style="margin-top:50px;width:800px"><?php
			?><div class="tableTitle"><div class="disabledRid"id="disabledRid"<?php if($action['rid']!=0){?>style="display:none;"<?php }?>></div>RID:</div><?php
			?><?php
				?><table class="criteriaTable" style="width:800px;"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="4">RID Code</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:55px;">Code</td><?php
						?><td colspan="3"><?php
							?><select disabled id="rid"name="rid"onChange="changeRidSelect(this,'<?=$wp['wp']?>','<?=$action['criteria']?>');" style="width:697px;"><?php
								?><option value="0">No RID</option><?php
								?><option value="new">New RID...</option><?php
								foreach($ridList as $k=>$v){?><option<?php if($action['rid']==$k)echo' selected'?> value="<?=$k?>"><?=$v['rid_code'],': ',stripslashes(substr($v['rid_title'],0,80)),'...'?></option><?php }
							?></select><?php
						?></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Main Information</td><?php
						?><td colspan="2">Notes</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:55px;">Status</td><?php
						?><td style="width:175px;"><?php
							?><img id="ridStatus_r"onMouseOver="setStatusFocus(this,'rid_status')"src="../common/img/r<?=$activeRidStatus[0]?>30Off.jpg"style="cursor:pointer;"><span style="cursor:default;padding-right:10px;"></span><?php
							?><img id="ridStatus_a"onMouseOver="setStatusFocus(this,'rid_status')"src="../common/img/a<?=$activeRidStatus[1]?>30Off.jpg"style="cursor:pointer;"><span style="cursor:default;padding-right:10px;"></span><?php
							?><img id="ridStatus_g"onMouseOver="setStatusFocus(this,'rid_status')"src="../common/img/g<?=$activeRidStatus[2]?>30Off.jpg"style="cursor:pointer;"><?php
						?></td><?php
						?><td class="paramDef"rowspan="6"style="width:55px;">Title</td><?php
						?><td rowspan="6"style="width:515px;"><textarea cols="81"id="rid_title"name="rid_title"onMouseOver="setInputFocus(this);"rows="12"style="overflow-x:hidden;"><?=$action['rid_title']?></textarea></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Dates</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Creation</td><?php
						?><td><?php
							drawDate('rid_creation','ridCreationDateCal',$action['rid_creation'],false);
						?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Completion</td><?php
						?><td><?php
							drawDate('rid_completion','ridCompletionDateCal',$action['rid_completion'],false);
						?></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Responsibles</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Holder</td><?php
						drawUserField('suggestion_rid_holder','rid_holder_name','rid_holder',$action['rid_holder_txt'],$action['rid_holder_name']);
						/*?><td><?php
							?><input class="formInput"id="rid_holder"name="rid_holder"onMouseOver="setInputFocus(this);"size="28"type="text"value="<?=($action['rid_holder_txt'])?$action['rid_holder_txt']:$action['rid_holder_name']?>"><?php
						?></td><?php*/
					?></tr><?php
				?></table><?php
				?><div class="save"><span class="saveResponse"id="action_saveResponse">Changes were applied</span><input class="stdBtn"onClick="sendAjaxForm('actionFrm','ajax/saveAction.php','updateData','action_saveResponse');"type="button"value="Apply Changes"></div><?php
			?></div><?php
		?></form><?php
	?></div><?php
	?><div class="sp"></div><?php
?>