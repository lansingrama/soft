<?php
require_once('../support/header.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

/*$formAction=array('a0Report'=>'support/uploadA0Report.php',
					'caPicture'=>'support/uploadCaWpPicture.php');*/

$formAction=($GET['type']=='a0Report')?'support/uploadA0Report.php':'support/uploadFile.php';

//$headerRepetition=(getFilter(''))?:;
?>OK|||<div id="uploadFileContainer"style="text-align:center;"style="width:380px;"><?php
	formTitle(380,'Upload '.$GET['title'],'uploadFileContainer');
	?><div class="sp"></div><?php
	//echo'Type: ',$GET['type'];
	?><form action="<?=$formAction?>"enctype="multipart/form-data"id="uploadFileFrm"method="post"target="hiFr"><?php
	/*?><form action="<?=$formAction?>"enctype="multipart/form-data"id="uploadFileFrm"method="post"><?php*/
		switch($GET['type']){
			case 'caPicture':
				?><input name="target"type="hidden"value="<?=$GET['target']?>"><?php
				?><input name="target_id"type="hidden"value="<?=$GET['target_id']?>"><?php
			break;
			case 'changeScreenshot':
				?><input name="change_id"type="hidden"value="<?=$GET['change_id']?>"><?php
			break;
		}
		?><input name="type"type="hidden"value="<?=$GET['type']?>"><?php
		?><div class="prompt"><?php
			if($GET['type']=='changeScreenshot'){
				?><table class="criteriaTable" style="width:370px;"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="2">Screenshot Details</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">File</td><?php
						?><td><input class="stdBtn"id="uploadedFile"type="file"name="uploadedFile"size="28"></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">Description</td><?php
						?><td><textarea class="formInput"cols="51"id="change_screenshot_description"name="change_screenshot_description"onMouseOver="setInputFocus(this);"rows="7"style="overflow-x:hidden;"><?=$change['change_description']?></textarea></td><?php
					?></tr><?php
				?></table><?php
				?><div class="save"><?php
					?><input class="stdBtn"id="loadFileBtn" onClick="$('uploadFileFrm').submit();closeLastForm();"type="button"value="Load file"><?php
				?></div><?php
			}else{
				?><input class="stdBtn"id="uploadedFile"type="file"name="uploadedFile"size="31"> <?php
				?><input class="stdBtn"id="loadFileBtn" onClick="$('uploadFileFrm').submit();closeLastForm();"type="button"value="Load file">&nbsp;<?php
			}
			/*?><img id="loadingFileImg"src="../common/img/loadingImg.php"width="16"height="16"style="display:none;"> <?php*/
		?></div><?php
	?></form><?php
?></div>