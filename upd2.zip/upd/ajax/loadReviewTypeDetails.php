<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
storeSession($SESSION);
echo 'OK|||',implode('&&&',SqlSLi('SELECT CONCAT(review_type_id,"%%%",review_type,"%%%",review_type_description,"%%%",review_type_code) AS r FROM dr_review_type','r'))?>