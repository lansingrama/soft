<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

$invalidName=$GET['element_txt'];

$review=allowedReviews($SESSION,'edit','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION));
$perimeter=perimeterPermission($SESSION,'view');

/* JFM 04_09_13
$invalidActionRidName=SqlLi('SELECT DISTINCT act.action_id,act.action_code,act.action_description,act.action_holder_name,act.action_validator_name,
								rgr.review_group_id,
								rid.rid_id,rid.rid_code,rid.rid_title,rid.rid_holder_name
							FROM dr_action AS act
								INNER JOIN dr_review_criteria		AS rcr	ON act.criteria=rcr.review_criteria_id
								INNER JOIN dr_review_group			AS rgr	ON rcr.review_group=rgr.review_group_id
								INNER JOIN dr_action_applicability	AS aap	ON act.action_id=aap.action
								INNER JOIN c_ca						AS c	ON aap.ca=c.ca_id
								LEFT JOIN dr_rid					AS rid	ON (rid.rid_id=act.rid AND rid.rid_holder!=0 AND rid.rid_holder_name="'.$invalidName.'")
							WHERE rgr.review_profile IN('.implode(',',array_keys($review)).')
								AND c.perimeter IN('.implode(',',array_keys($perimeter)).')
								AND(
									(act.action_holder=0 AND act.action_holder_name="'.$invalidName.'")
										OR (act.action_validator=0 AND act.action_validator_name="'.$invalidName.'")
								)');*/
								
$invalidActionRidName=SqlLi('SELECT DISTINCT act.action_id,act.action_code,act.action_description,act.action_holder_name,act.action_validator_name,
								rgr.group_id,
								rid.rid_id,rid.rid_code,rid.rid_title,rid.rid_holder_name
							FROM dr_action AS act
								INNER JOIN dr_review_criterion		AS rcr	ON act.criteria=rcr.review_criterion_id
								INNER JOIN dr_review_group			AS rgr	ON rcr.review_group=rgr.group_id
								INNER JOIN dr_review_profile		AS rp	ON rgr.review_type=rp.review_type
								INNER JOIN dr_action_applicability	AS aap	ON act.action_id=aap.action
								INNER JOIN c_ca						AS c	ON aap.ca=c.ca_id
								LEFT JOIN dr_rid					AS rid	ON (rid.rid_id=act.rid AND rid.rid_holder!=0 AND rid.rid_holder_name="'.$invalidName.'")
							WHERE rp.review_profile_id IN('.implode(',',array_keys($review)).')
								AND c.perimeter IN('.implode(',',array_keys($perimeter)).')
								AND(
									(act.action_holder=0 AND act.action_holder_name="'.$invalidName.'")
										OR (act.action_validator=0 AND act.action_validator_name="'.$invalidName.'")
								)');

$invalidRidHolder=array();

if(is_array($invalidActionRidName)){
	foreach($invalidActionRidName as $i){
		if($i['rid_holder_name']==$invalidName){
			$invalidRidHolder[]=array('rid_id'=>$i['rid_id'],'rid_code'=>$i['rid_code'],'rid_title'=>$i['rid_title'],'rid_holder_name'=>$i['rid_holder_name']);
		}
	}
}

?>OK|||<div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;"><?php
	echo 'Actions / RIDs of ',$invalidName;
?></div><?php
?><div style="position:relative;height:50px;"></div><?php
if(is_array($invalidActionRidName)){
	?><form action="#"enctype="multipart/form-data"id="invalidNameFrm"method="post"style="display:inline;"><?php
		?><input name="invalid_name"type="hidden"value="<?=$invalidName?>"><?php
		?><div class="elementDetailsContainer"><?php
			?><input checked id="valid_user_source_existing"name="valid_user_source"onClick="changeUserSource()"type="radio"value="existing"> Correct the Actions / RIDs below with the following user: <?php
				drawddList('ddCorrectUser',similarName($invalidName,$SESSION),'',175);
			?><br><input id="valid_user_source_new"name="valid_user_source"onClick="changeUserSource()"type="radio"value="new"> Create a new user<?php
		?></div><?php
		?><div class="elementDetailsContainer"id="newValidUser"onClick="validateUser();"onKeyUp="validateUser();"style="display:none;z-index:-10;"><?php
			?><div class="elementDetailsContainer"><?php
				?><div class="sp" style="height:30px;"></div><?php
				?><div class="elementInfo"><?php
					?><table class="criteriaTable"style="width:703px;"><?php
						?><tr class="tableGroup"><?php
							?><td style=" width:191px;">New User</td><td style="width:483px;"></td><?php
						?></tr><?php
						drawStdField('First Name','name','',110);
						drawStdField('Second Name','surname','',110);
						drawStdField('Email','email','',110);
					?></table><?php
				?></div><?php
			?></div><?php
		?></div><?php
		
		if(count($invalidRidHolder)!=0){
			?><div class="sp"></div><?php
			?><div class="elementDetailsContainer"><?php
				?><div class="elementInfo"><?php
					?><div class="tableTitle">RIDs with incorrect Holder:</div><?php
							?><table class="criteriaTable" style="width:703px;"><?php
								?><tr class="tableGroup prmRow"><?php
									?><td></td><td>Code</td><td>Description</td><td>Holder</td><?php
								?></tr><?php
								foreach($invalidRidHolder as $i){
									?><tr><?php
										?><td><input checked name="chk_rid_<?=$i['rid_id']?>"type="checkbox"value="1"></td><?php
										?><td><?=$i['rid_code']?></td><?php
										?><td><?=$i['rid_title']?></td><?php
										?><td id="rid_holder_name_<?=$i['rid_id']?>"><span style="color:#FF0000 "><?=$i['rid_holder_name']?></span></td><?php
									?></tr><?php
								}
							?></table><?php
				?></div><?php
			?></div><?php
		}
		
		if(is_array($invalidActionRidName)){
			?><div class="sp"></div><?php
			?><div class="elementDetailsContainer"><?php
				?><div class="elementInfo"><?php
					?><div class="tableTitle">Actions with incorrect Holder or Validator:</div><?php
							?><table class="criteriaTable" style="width:703px;"><?php
								?><tr class="tableGroup prmRow"><?php
									?><td></td><td>Code</td><td>Description</td><td>Holder</td><td>Validator</td><?php
								?></tr><?php
								foreach($invalidActionRidName as $i){
									?><tr><?php
										?><td><input checked name="chk_action_<?=$i['action_id']?>"type="checkbox"value="1"></td><?php
										?><td><?=$i['action_code']?></td><?php
										?><td><?=$i['action_description']?></td><?php
										?><td id="action_holder_name_<?=$i['action_id']?>"><?php
											if($i['action_holder_name']==$invalidName){
												?><span style="color:#FF0000 "><?=$i['action_holder_name']?></span><?php
											}else{
												echo $i['action_holder_name'];
											}
										?></td><?php
										?><td id="action_validator_name_<?=$i['action_id']?>"><?php
											if($i['action_validator_name']==$invalidName){
												?><span style="color:#FF0000 "><?=$i['action_validator_name']?></span><?php
											}else{
												echo $i['action_validator_name'];
											}
										?></td><?php
									?></tr><?php
								}
							?></table><?php
				?></div><?php
			?></div><?php
		
			?><div class="sp"></div><?php
			?><div class="elementDetailsContainer"><?php
				?><div class="save"><span class="saveResponse"id="correct_user_saveResponse">Changes were applied</span><input class="stdBtn"id="correctInvalidUser"onClick="sendAjaxForm('invalidNameFrm','ajax/saveCorrectUser.php','updateData','correct_user_saveResponse','',false);loadUserList();"type="button"value="Apply Changes"></div><?php
			?></div><?php
		}
	?></form><?php
}else{
	echo 'No Actions / RIDs found for ',$invalidName,' that need to be corrected.';
}
?><div style="position:relative;height:150px;"></div><?php
storeSession($SESSION);
?>