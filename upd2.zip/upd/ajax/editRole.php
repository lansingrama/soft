<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);
$responsibles=getResponsibles($GET['element'],$SESSION);
//$SESSION['responsibles'] = $responsibles;
$currentArea = getFilter('area','filter',0,$SESSION);
$role_sql = SqlLi('SELECT role.responsible_role_id as rid, role.responsible_role as role FROM dr_role_assigned_area as ass_role JOIN dr_responsible_role as role ON ass_role.responsible_role_id = role.responsible_role_id WHERE area = '.$currentArea);

?>OK|||<div class="formStdContainer"><?php
	?><div class="formHeader"><?php
		?><div class="formHeaderInfo">Edit Role</div><?php
		if(!empty($GET['reviewCa']) && !empty($GET['reviewProfile']) && $GET['reviewCa'] != "" && $GET['reviewProfile'] != "")
			{
				?><div class="xDiv" onclick="closeLastForm();openForm('../ajax/responsible','element=<?=$GET['reviewProfile']?>&reviewProfile=<?=$GET['reviewProfile']?>&reviewCa=<?=$GET['reviewCa']?>',false,'GET');">&#9668; Back</div><?php
		
			}
			else{
		?><div class="xDiv" onclick="closeLastForm();openForm('../ajax/responsible','element=<?=$GET['element']?>',false,'GET');">&#9668; Back</div><?php
			}?></div><?php
	?><div class="leftInfoBox" style="width:790px; margin-top:70px;"><?php
		?><form action="#" enctype="multipart/form-data" id="saverole" method="post" style="display:inline;"><?php
			?><input id="reviewId" name="reviewId" type="hidden" value="<?=$GET['element']?>"><?php
            ?><input id="editId" name="editId" type="hidden" value="<?=$GET['edit']?>"><?php
			?><input id="reviewProfile" name="reviewProfile" type="hidden" value="<?=$GET['reviewProfile']?>"><?php
			?><input id="reviewCa" name="reviewCa" type="hidden" value="<?=$GET['reviewCa']?>"><?php
            /*?><div class="save"><input class="stdBtn" onClick="sendAjaxForm('saverole','ajax/saveRole.php','saveRole','');closeLastForm();openForm('../ajax/responsible','element=<?=$GET['element']?>',false,'GET');" type="button" value="Apply Changes &#9658;"></div><?php*/
			/**
			US #19.1 - Change Workflow
			Bug fix for View/Edit responsible button should be enabled
			Fixed By - Infosys Limited
			Version - 4.3
			*/
			if(!empty($GET['reviewCa']) && !empty($GET['reviewProfile']) && $GET['reviewCa'] != "" && $GET['reviewProfile'] != "")
			{
			?><div class="save"><input class="stdBtn" type="button" onClick="sendAjaxForm('saverole','ajax/saveRole.php','saveRole','');closeLastForm();openForm('../ajax/responsible','element=<?=$GET['reviewProfile']?>&reviewProfile=<?=$GET['reviewProfile']?>&reviewCa=<?=$GET['reviewCa']?>',false,'GET');closeLastForm();openForm('../ajax/responsible','element=<?=$GET['reviewProfile']?>&reviewProfile=<?=$GET['reviewProfile']?>&reviewCa=<?=$GET['reviewCa']?>',false,'GET');" value="Apply Changes &#9658;"></div><?php
			}
			else{
				?><div class="save"><input class="stdBtn" type="button" onClick="sendAjaxForm('saverole','ajax/saveRole.php','saveRole','');closeLastForm();openForm('../ajax/responsible','element=<?=$GET['element']?>',false,'GET');closeLastForm();openForm('../ajax/responsible','element=<?=$GET['element']?>',false,'GET');" value="Apply Changes &#9658;"></div><?php
		
			}
			// End of US -19.1
			?><table class="criteriaTable" id="responsibleTable" name="responsibleTable" cellpadding="5" cellspacing="0"><?php
				?><tr class="tableGroup"><?php
					?><td>Role</td><?php
					?><td>Responsible</td><?php
				?></tr><?php
				?><tr id="rowResponsible"><?php
                        ?><td width="35%" height="18px;" valign="top"><?php
                            ?><select id="roleinputID" name="roleinputID" class="showRole" style="min-width: 100%;"><?php   
                                foreach($role_sql as $row){
                                    if ($GET['role'] == $row['role']) {?>
                                        <option <?php echo 'selected'?>><?php echo $row['role']; ?></option>
                                    <?php }
                                    else {?>
                                        <option><?php echo $row['role']; ?></option> 
                                    <?php }
                                }
                            ?></select><?php
                        ?></td><?php
				        ?><td width="35%" height="18px;" valign="top"><?php
					    ?><div class="suggestion"id="responsibledivID"style="width:159px;"></div><?php
					    ?><input autocomplete="off" class="textareaWhite" id="responsibleinputID" name="responsibleinputID" value="<?=$GET['resposible']?>" onFocus="loadUserSuggestion(this,'responsibledivID','responsibleinputID','','responsiblesuggestionID');" onKeyPress="return avoidSendForm(event,'user');" size="28"type="text"><?php
                        ?></td><?php
				?></tr><?php
                ?><br /><?php
			?></table><?php
		?></form><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>