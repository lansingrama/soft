<?php
/*
 * To DELETE Level1, Level2 and Level3 - US#110 (Possibility to delete Review type, L1, L2 and L3 from Structure Management)
 * Created by : Infosys Limited
 * Version : 4.3
 */
require_once('../support/header.php');
require_once('../../support.php');
require_once('../support/mail.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$POST = cleanArray($_GET);
if ($POST['program']) {
    SqlLQ('UPDATE c_program SET program_hidden=1 WHERE program_id="'.$POST['program'].'"');
	$rpExists = SqlLQ('SELECT program FROM dr_review_profile WHERE program="'.$POST['program'].'"');
    if(!empty($rpExists)) {
        SqlLQ('UPDATE dr_review_profile SET rp_hidden=1 WHERE program="'.$POST['program'].'"');
    } 
} else if ($POST['msn']) {
    SqlLQ('UPDATE c_msn SET msn_hidden=1 WHERE msn_id="'.$POST['msn'].'"');
} else if ($POST['coe']) {
    SqlLQ('UPDATE c_coe SET coe_hidden=1 WHERE coe_id="'.$POST['coe'].'"');
}
echo 'OK|||';
?>
