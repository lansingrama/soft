<?php
if($included!=1){
	require_once('../support/header.php');
	require_once('../security/checkExpiredSession.php');
	require_once('../../support.php');
	$review=addslashes($_GET['review']);
}

$program=SqlAsArr('SELECT review_profile_id,
						CONCAT(p.program,", ",c.coe) AS review_location
					FROM c_program AS p
						INNER JOIN dr_review_profile AS r ON p.program_id=r.program
						INNER JOIN c_coe AS c ON r.coe=c.coe_id
					WHERE r.review_type="'.$review.'"
					','review_profile_id','review_location');

if($included!=1){
	require_once('../support/form.php');
	$answer='';
	$firstItem=0;
	generateSimpleResponse($answer,$firstItem,$program);
	echo'OK|||',$answer;
}
storeSession($SESSION);

?>