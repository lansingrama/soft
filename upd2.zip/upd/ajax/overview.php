<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

$allowedProgramList=allowedSimpleObject('program','program',$SESSION,'c_','area != (select area_id FROM c_area WHERE area="Playground")','view','ASC');

$selectedProgramId=getFilter('program','filter',0,$SESSION);
$selectedProgram='';

$sortedProgramList=Array();

foreach ($allowedProgramList as $programId => $programName) 
{
	if(!in_array($programName, $sortedProgramList)) $sortedProgramList[] = $programName;
	if($selectedProgramId==$programId) $selectedProgram=$programName;
}

?>OK|||overview&&&<?php

?><div id="overview"style="position:fixed; right:0; left:210px; top:90px; bottom:0;text-align:center; overflow:auto;"><?php

?><div style="font-size:24px;"><?php

	?><select class="programDropDownSelect" id="programName" name="programName" onchange="containerDiv='inTheMiddle';ajaxRequest('ajax/overviewCalculate.php?program='+this.value,'putInDiv',false,'GET');"><?php
		?><option value="Nothing" disabled="disabled" selected="selected">Select a Value</option><?php
		foreach ($sortedProgramList as $uselessKey => $programName) 
		{
			?><option value="<?=$programName?>" <?=($selectedProgram==$programName)?'selected="selected"':''?>><?=$programName?></option><?php
		}
	?></select><?php

	?> Programme All Areas & CoEs<?php

?></div><?php

?><div id="inTheMiddle"></div><?php

?></div><?php

echo '&&&'.$selectedProgram;


storeSession($SESSION);

?>