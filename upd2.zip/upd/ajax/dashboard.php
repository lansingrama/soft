<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

if(!getFilter('program','filter',0,$SESSION) || !getFilter('coe','filter',0,$SESSION) || !getFilter('msn','filter',0,$SESSION)) //JFM 28_10_15
{
	?>OK|||no_program_coe_msn<?php
}
else
{
	$reviewTypesAllowed=allowedReviews($SESSION, 'view', 'program='.getFilter('program','filter',0,$SESSION));
	//$reviewTypesAllowed=allowedSimpleObject('review_profile','review_type',$SESSION,'dr_','program='.getFilter('program','filter',0,$SESSION)); //JFM 15_09_15

	$allQry1=array();
	$allQry2=array();

	if(!empty($reviewTypesAllowed))
	{
		//JFM 09_04_14 - JFM 14_04_15
		SqlLQ('SET SESSION group_concat_max_len=1000000');

                // Added program_id, coe_hidden & review_hidden flag to check if the Level and review is active - US#110
		$allQry1=SqlLi('SELECT DISTINCT
									act.action_id,act.action_status,
									YEARWEEK(act.action_completion,1) AS week_number_planned,
									YEARWEEK(act.action_closure,1) AS week_number,
									rid.rid_id,rid.rid_status,
									YEARWEEK(rid.rid_completion,1) AS rid_week_number_planned,
									YEARWEEK(rid.rid_closure,1) AS rid_week_number,
									coe.coe, coe.coe_id, cmn.msn, rt.review_type, rt.review_type_id, rp.review_profile_id,
									per.perimeter, per.perimeter_id,
									dep.siglum, dep.department_id,
									GROUP_CONCAT(DISTINCT ca.ca_id,\'---\',ca.ca) as ca_id,
									GROUP_CONCAT(DISTINCT log.log_date,\'---\',log.old_value,\'---\',log.new_value ORDER BY log.log_date ASC) AS action_history,
									GROUP_CONCAT(DISTINCT log2.log_date,\'---\',log2.old_value,\'---\',log2.new_value ORDER BY log2.log_date ASC) AS rid_history
								FROM dr_action 			AS act 
									INNER JOIN c_msn					AS cmn 	ON 	cmn.msn_id=act.msn
									INNER JOIN dr_action_applicability	AS app 	ON 	act.action_id=app.action
									INNER JOIN c_ca 					AS ca  	ON 	app.ca=ca.ca_id
									INNER JOIN c_coe 					AS coe 	ON 	ca.coe=coe.coe_id
									INNER JOIN dr_review_criterion		AS rc 	ON 	act.criteria=rc.review_criterion_id
									INNER JOIN dr_review_group 			AS rg 	ON 	rc.review_group=rg.group_id
									INNER JOIN dr_review_type 			AS rt 	ON 	rg.review_type=rt.review_type_id
									INNER JOIN c_perimeter 				AS per 	ON 	per.perimeter_id=ca.perimeter 
									INNER JOIN dr_review_profile		AS rp   ON 	rp.program=cmn.program
																				AND rp.coe=coe.coe_id
																				AND rp.review_type=rt.review_type_id
									INNER JOIN c_cawp					AS cw	ON 	ca.ca_id=cw.ca
																				AND cmn.msn_id=cw.msn
									LEFT  JOIN dr_log 					AS log  ON  log.applicability=act.action_id
																				AND log.object='.$SESSION['object']['action_status'].'
									LEFT  JOIN dr_rid					AS rid 	ON 	act.rid=rid.rid_id
									LEFT  JOIN dr_log 					AS log2 ON  log2.applicability=rid.rid_id
																				AND log2.object='.$SESSION['object']['rid_status'].'
									LEFT  JOIN c_user 					AS uah 	ON  uah.user_id=act.action_holder
									LEFT  JOIN c_department 			AS dep 	ON  dep.department_id = uah.department
								WHERE 	cmn.program='.getFilter('program','filter',0,$SESSION).'
								AND 	rt.area='.getFilter('area','filter',0,$SESSION).'
								AND 	rt.review_type_id IN ('.implode(',', $reviewTypesAllowed).')
                                                                AND rt.review_type_hidden=0
                                                                AND coe.coe_hidden=0
                                                                AND cmn.msn_hidden=0
								GROUP BY act.action_id
								ORDER BY log.log_date ASC');

		$allQry2=SqlLi('SELECT DISTINCT
									act.action_id,act.action_status,
									YEARWEEK(act.action_completion,1) AS week_number_planned,
									YEARWEEK(act.action_closure,1) AS week_number,
									coe.coe, coe.coe_id, cmn.msn, rt.review_type, rt.review_type_id, rp.review_profile_id,
									per.perimeter, per.perimeter_id,
									dep.siglum, dep.department_id,
									GROUP_CONCAT(DISTINCT ca.ca_id,\'---\',ca.ca) as ca_id,
									GROUP_CONCAT(DISTINCT log.log_date,\'---\',log.old_value,\'---\',log.new_value ORDER BY log.log_date ASC) AS action_history								FROM dr_action 			AS act 
									INNER JOIN c_msn					AS cmn 	ON 	cmn.msn_id=act.msn
									INNER JOIN dr_action_applicability	AS app 	ON 	act.action_id=app.action
									INNER JOIN c_ca 					AS ca  	ON 	app.ca=ca.ca_id
									INNER JOIN c_coe 					AS coe 	ON 	ca.coe=coe.coe_id
									INNER JOIN dr_review 				AS r 	ON 	act.review=r.review_id
									INNER JOIN dr_review_profile		AS rp   ON 	rp.program=cmn.program
																				AND rp.coe=coe.coe_id
																				AND r.review_profile=rp.review_profile_id
									INNER JOIN dr_review_type 			AS rt 	ON 	rp.review_type=rt.review_type_id

									INNER JOIN c_cawp					AS cw	ON 	ca.ca_id=cw.ca
																				AND cmn.msn_id=cw.msn
									INNER JOIN c_perimeter 				AS per 	ON 	per.perimeter_id=ca.perimeter 
									LEFT  JOIN dr_log 					AS log  ON  log.applicability=act.action_id
																				AND log.object='.$SESSION['object']['action_status'].'
									LEFT  JOIN c_user 					AS uah 	ON  uah.user_id=act.action_holder
									LEFT  JOIN c_department 			AS dep 	ON  dep.department_id = uah.department
								WHERE cmn.program='.getFilter('program','filter',0,$SESSION).'
								AND 	rt.area='.getFilter('area','filter',0,$SESSION).'
								AND 	rt.review_type_id IN ('.implode(',', $reviewTypesAllowed).')
                                                                AND rt.review_type_hidden=0
                                                                AND coe.coe_hidden=0
                                                                AND cmn.msn_hidden=0
								GROUP BY act.action_id 
								ORDER BY log.log_date ASC');

		SqlLQ('SET SESSION group_concat_max_len=1024');

		$allCoEs=SqlLi('SELECT coe, coe_id FROM c_coe WHERE area='.getFilter('area','filter',0,$SESSION).' AND coe_hidden=0 ORDER BY coe_id ASC');
		$allMSNs=SqlLi('SELECT msn, msn_id FROM c_msn WHERE program='.getFilter('program','filter',0,$SESSION).' AND msn_hidden=0 ORDER BY msn ASC');
		$allPERs=SqlLi('SELECT perimeter AS per, perimeter_id FROM c_perimeter WHERE program='.getFilter('program','filter',0,$SESSION).' ORDER BY perimeter ASC'); //JFM 14_04_15
                //print_r($allPERs);
		$allDeps=SqlLi('SELECT siglum, department_id FROM c_department ORDER BY siglum ASC'); //JFM 14_04_15
		$allReviews=SqlLi('SELECT review_type, review_type_id FROM dr_review_type WHERE area='.getFilter('area','filter',0,$SESSION).' AND review_type_id IN ('.implode(',', $reviewTypesAllowed).') ORDER BY review_type ASC');
		$program=SqlQ('SELECT program FROM c_program WHERE program_id='.getFilter('program','filter',0,$SESSION).' AND program_hidden=0 AND area='.getFilter('area','filter',0,$SESSION));
		$area=SqlQ('SELECT area FROM c_area WHERE area_id='.getFilter('area','filter',0,$SESSION));

	}

	$allQry=array();

	if(!empty($allQry1) && !empty($allQry2)) $allQry=array_merge($allQry1, $allQry2);
	else if (!empty($allQry1)) $allQry=$allQry1;
	else if (!empty($allQry2)) $allQry=$allQry2;

	$allowedCoeList=allowedSimpleObject('coe','coe',$SESSION,'c_','','view','ASC');
	$allowedPerList=allowedSimpleObject('perimeter','perimeter',$SESSION,'c_','','view','ASC');
	//$reviewProfileList=allowedSimpleObject('review_profile','review_type',$SESSION,'dr_','program='.getFilter('program','filter',0,$SESSION));
	$reviewProfileList=allowedReviews($SESSION, 'view', 'program='.getFilter('program','filter',0,$SESSION));

	$perimeterShownQuickFix=array();

	$doNotDisplayTotalActionsOrRids=false;

	$countEverything=Array();
	$usedRIDs=Array();

	$graphBurnDown=array();
	$graphBurnDownTotals=array();
	$burnDownWeeks=array();
	$burnDownActual=array();
	$burnDownPredicted=array();
	$burnDownGreen=array();

	$RIDgraphBurnDown=array();
	$RIDgraphBurnDownTotals=array();
	$RIDburnDownWeeks=array();
	$RIDburnDownActual=array();
	$RIDburnDownPredicted=array();
	$RIDburnDownGreen=array();

	if(is_array($allQry))
	{		
		foreach($allQry as $q=>$z)
		{
			if(in_array($z['coe'],$allowedCoeList) && in_array($z['review_type_id'],$reviewProfileList))
			{
				if(empty($z['siglum'])) $z['siglum'] = 'None';
				$countEverything['all_action']['all_action']['all_action']++;
				$countEverything['all_action']['action_status'][$z['action_status']]++;
				$countEverything['all_action']['per'][$z['perimeter']]['review_type'][$z['review_type']]['all']++; //JFM 14_04_15
				$countEverything['all_action']['per'][$z['perimeter']]['review_type'][$z['review_type']]['action_status'][$z['action_status']]++; //JFM 14_04_15
				//$countEverything['all_action']['per'][$z['perimeter']]['dep'][$z['siglum']]['all']++; //JFM 14_04_15
				//$countEverything['all_action']['per'][$z['perimeter']]['dep'][$z['siglum']]['action_status'][$z['action_status']]++;//JFM 14_04_15
				$countEverything['all_action']['coe'][$z['coe']]['all']++;
				$countEverything['all_action']['coe'][$z['coe']]['action_status'][$z['action_status']]++;
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['all']++;
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['action_status'][$z['action_status']]++;
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['all']++;
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['action_status'][$z['action_status']]['all']++;

				$allCaInfo=explode(',',$z['ca_id']);			

				foreach($allCaInfo as $y)
				{
					$allCaInfoSplit=explode("---",$y);
					$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['ca_id']=$allCaInfoSplit[0];
					$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['ca_name']=$allCaInfoSplit[1];
					$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['all']++;
					$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['action_status'][$z['action_status']]['all']++;
				}

				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['action_status'][$z['action_status']]['ca_id'][$z['ca_id']]=$z['ca_id'];
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['review_profile']=$z['review_profile_id'];
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['review_type_id']=$z['review_type_id'];

				if($z['rid_id'] && !in_array($z['rid_id'], $usedRIDs)) 
				{
					$countEverything['all_rid']['all_rid']['all_rid']++;
					$countEverything['all_rid']['rid_status'][$z['rid_status']]++;
					$countEverything['all_rid']['per'][$z['perimeter']]['review_type'][$z['review_type']]['all']++; //JFM 14_04_15
					$countEverything['all_rid']['per'][$z['perimeter']]['review_type'][$z['review_type']]['rid_status'][$z['rid_status']]++; //JFM 14_04_15
					$countEverything['all_rid']['coe'][$z['coe']]['all']++;
					$countEverything['all_rid']['coe'][$z['coe']]['rid_status'][$z['rid_status']]++;
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['all']++;
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['rid_status'][$z['rid_status']]++;
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['all']++;
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['rid_status'][$z['rid_status']]['all']++;
					
					$allCaInfo=explode(',',$z['ca_id']);			

					foreach($allCaInfo as $y)
					{
						$allCaInfoSplit=explode("---",$y);
						$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['ca_id']=$allCaInfoSplit[0];
						$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['ca_name']=$allCaInfoSplit[1];
						$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['all']++;
						$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['rid_status'][$z['rid_status']]['all']++;
					}

					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['rid_status'][$z['rid_status']]['ca_id'][$z['ca_id']]=$z['ca_id'];
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['review_profile']=$z['review_profile_id'];
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['review_type_id']=$z['review_type_id'];

					array_push($usedRIDs,$z['rid_id']);
				}

				//For Action burn down
				if(!empty($z['week_number'])) 
				{
					if($z['action_status']==3)
					{
						$graphBurnDown['All Review Types'][$z['perimeter']][$z['week_number']]['week_number']=$z['week_number'];
						$graphBurnDown['All Review Types'][$z['perimeter']][$z['week_number']]['total_validated']++;
						$graphBurnDownTotals['All Review Types'][$z['perimeter']]['total_validated_all']++;

						$graphBurnDown[$z['review_type']][$z['perimeter']][$z['week_number']]['week_number']=$z['week_number'];
						$graphBurnDown[$z['review_type']][$z['perimeter']][$z['week_number']]['total_validated']++;
						$graphBurnDownTotals[$z['review_type']][$z['perimeter']]['total_validated_all']++;
					}
				}
				if(!empty($z['week_number_planned'])) 
				{
					$graphBurnDown['All Review Types'][$z['perimeter']][$z['week_number_planned']]['week_number']=$z['week_number_planned'];
					$graphBurnDown['All Review Types'][$z['perimeter']][$z['week_number_planned']]['total_planned']++;
					$graphBurnDownTotals['All Review Types'][$z['perimeter']]['total_planned_all']++;

					$graphBurnDown[$z['review_type']][$z['perimeter']][$z['week_number_planned']]['week_number']=$z['week_number_planned'];
					$graphBurnDown[$z['review_type']][$z['perimeter']][$z['week_number_planned']]['total_planned']++;
					$graphBurnDownTotals[$z['review_type']][$z['perimeter']]['total_planned_all']++;
				}	

				$actionsHistory=explode(',',$z['action_history']);

				if(!empty($actionsHistory))
				{
					$alreadyCalledWeekNumber = array();

					foreach($actionsHistory as $actionsHistoryInfo)
					{
						$actionsHistoryInfoSplit=explode("---",$actionsHistoryInfo);

						$weekNumber = date("YW", strtotime($actionsHistoryInfoSplit[0]));

						if($actionsHistoryInfoSplit[2] == 2)
						{
							$graphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['week_number']=$weekNumber;
							$graphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['total_green']++;

							$graphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['week_number']=$weekNumber;
							$graphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['total_green']++;
						}
						if($actionsHistoryInfoSplit[1] == 2)
						{
							$graphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['week_number']=$weekNumber;

							if(empty($graphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['total_green']))
								$graphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['total_green']=0;

							$graphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['total_green']--;

							$graphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['week_number']=$weekNumber;

							if(empty($graphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['total_green']))
								$graphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['total_green']=0;

							$graphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['total_green']--;
						}
					}
				}


				//For RID burn down
				if(!empty($z['rid_week_number'])) 
				{
					if($z['rid_status']==3)
					{
						$RIDgraphBurnDown['All Review Types'][$z['perimeter']][$z['rid_week_number']]['rid_week_number']=$z['rid_week_number'];
						$RIDgraphBurnDown['All Review Types'][$z['perimeter']][$z['rid_week_number']]['total_validated']++;
						$RIDgraphBurnDownTotals['All Review Types'][$z['perimeter']]['total_validated_all']++;

						$RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$z['rid_week_number']]['rid_week_number']=$z['rid_week_number'];
						$RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$z['rid_week_number']]['total_validated']++;
						$RIDgraphBurnDownTotals[$z['review_type']][$z['perimeter']]['total_validated_all']++;
					}
				}
				if(!empty($z['rid_week_number_planned'])) 
				{
					$RIDgraphBurnDown['All Review Types'][$z['perimeter']][$z['rid_week_number_planned']]['rid_week_number']=$z['rid_week_number_planned'];
					$RIDgraphBurnDown['All Review Types'][$z['perimeter']][$z['rid_week_number_planned']]['total_planned']++;
					$RIDgraphBurnDownTotals['All Review Types'][$z['perimeter']]['total_planned_all']++;

					$RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$z['rid_week_number_planned']]['rid_week_number']=$z['rid_week_number_planned'];
					$RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$z['rid_week_number_planned']]['total_planned']++;
					$RIDgraphBurnDownTotals[$z['review_type']][$z['perimeter']]['total_planned_all']++;
				}	

				$ridHistory=explode(',',$z['rid_history']);

				if(!empty($ridHistory))
				{
					$alreadyCalledWeekNumber = array();

					foreach($ridHistory as $ridHistoryInfo)
					{
						$ridHistoryInfoSplit=explode("---",$ridHistoryInfo);

						$weekNumber = date("YW", strtotime($ridHistoryInfoSplit[0]));

						if($ridHistoryInfoSplit[2] == 2)
						{
							$RIDgraphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['rid_week_number']=$weekNumber;
							$RIDgraphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['total_green']++;

							$RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['rid_week_number']=$weekNumber;
							$RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['total_green']++;
						}
						if($ridHistoryInfoSplit[1] == 2)
						{
							$RIDgraphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['rid_week_number']=$weekNumber;

							if(empty($RIDgraphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['total_green']))
								$RIDgraphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['total_green']=0;

							$RIDgraphBurnDown['All Review Types'][$z['perimeter']][$weekNumber]['total_green']--;

							$RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['rid_week_number']=$weekNumber;

							if(empty($RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['total_green']))
								$RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['total_green']=0;

							$RIDgraphBurnDown[$z['review_type']][$z['perimeter']][$weekNumber]['total_green']--;
						}
					}
				}

			}
			else if($doNotDisplayTotalActionsOrRids==false) $doNotDisplayTotalActionsOrRids=true;
		}
	}

	//echo $graphBurnDownTotals['All Review Types'][$z['perimeter']]['total_green_all'];
	//print_r($graphBurnDown['FCR']['Pylon']);

	//ACTION BURN DOWN
	foreach ($graphBurnDown as $reviewType => $perimeterArray)
	{
		foreach ($perimeterArray as $perimeterItem => $arrayPoop) 
		{
			ksort($graphBurnDown[$reviewType][$perimeterItem]);
			reset($graphBurnDown[$reviewType][$perimeterItem]);
			$firstKey=key($graphBurnDown[$reviewType][$perimeterItem]);
			end($graphBurnDown[$reviewType][$perimeterItem]);
			$lastKey=key($graphBurnDown[$reviewType][$perimeterItem]);

			for ($i=$firstKey; $i < $lastKey; $i++) 
			{
				if(substr($i, -2)==53) $i+=48;

				if(empty($graphBurnDown[$reviewType][$perimeterItem][$i])) 
				{
					$graphBurnDown[$reviewType][$perimeterItem][$i]['week_number']=$i;
					$graphBurnDown[$reviewType][$perimeterItem][$i]['total_validated']=0;
					$graphBurnDown[$reviewType][$perimeterItem][$i]['total_planned']=0;
					$graphBurnDown[$reviewType][$perimeterItem][$i]['total_green']=0;
				}
			}

			ksort($graphBurnDown[$reviewType][$perimeterItem]);

			$totalValidated=0;
			$totalPlanned=0;
			$totalGreen=0;

			foreach ($graphBurnDown[$reviewType][$perimeterItem] as $week => $details) 
			{
				if(date('YW') >= $week)
				{
					$totalValidated+=$graphBurnDown[$reviewType][$perimeterItem][$week]['total_validated'];
					$graphBurnDown[$reviewType][$perimeterItem][$week]['total_validated_in_order']=$totalValidated;
					$totalGreen+=$graphBurnDown[$reviewType][$perimeterItem][$week]['total_green'];
					$graphBurnDown[$reviewType][$perimeterItem][$week]['total_green_in_order']=$totalGreen;
				}
				else 
				{
					$graphBurnDown[$reviewType][$perimeterItem][$week]['total_validated_in_order']=0;
					$graphBurnDown[$reviewType][$perimeterItem][$week]['total_green_in_order']=0;
				}

				$totalPlanned+=$graphBurnDown[$reviewType][$perimeterItem][$week]['total_planned'];
				$graphBurnDown[$reviewType][$perimeterItem][$week]['total_planned_in_order']=$totalPlanned;
			}

			//This is so the burn down XLSX download works correctly.
			foreach ($graphBurnDown[$reviewType][$perimeterItem] as $week => $details) 
			{
				$burnDownWeeks[$reviewType][$perimeterItem][] = substr($details['week_number'], -2);
				$burnDownActual[$reviewType][$perimeterItem][] =  $details['total_validated_in_order'];
				$burnDownPredicted[$reviewType][$perimeterItem][] = $details['total_planned_in_order'];
				$burnDownGreen[$reviewType][$perimeterItem][] = $details['total_green_in_order'];
			}
		}
	}

	//print_r($RIDgraphBurnDown);

	//RID BURN DOWN
	foreach ($RIDgraphBurnDown as $reviewType => $perimeterArray)
	{
		foreach ($perimeterArray as $perimeterItem => $arrayPoop) 
		{
			ksort($RIDgraphBurnDown[$reviewType][$perimeterItem]);
			reset($RIDgraphBurnDown[$reviewType][$perimeterItem]);
			$firstKey=key($RIDgraphBurnDown[$reviewType][$perimeterItem]);
			end($RIDgraphBurnDown[$reviewType][$perimeterItem]);
			$lastKey=key($RIDgraphBurnDown[$reviewType][$perimeterItem]);

			for ($i=$firstKey; $i < $lastKey; $i++) 
			{
				if(substr($i, -2)==53) $i+=48;

				if(empty($RIDgraphBurnDown[$reviewType][$perimeterItem][$i])) 
				{
					$RIDgraphBurnDown[$reviewType][$perimeterItem][$i]['week_number']=$i;
					$RIDgraphBurnDown[$reviewType][$perimeterItem][$i]['total_validated']=0;
					$RIDgraphBurnDown[$reviewType][$perimeterItem][$i]['total_planned']=0;
					$RIDgraphBurnDown[$reviewType][$perimeterItem][$i]['total_green']=0;
				}
			}

			ksort($RIDgraphBurnDown[$reviewType][$perimeterItem]);

			$totalValidated=0;
			$totalPlanned=0;
			$totalGreen=0;

			foreach ($RIDgraphBurnDown[$reviewType][$perimeterItem] as $week => $details) 
			{
				if(date('YW') >= $week)
				{
					$totalValidated+=$RIDgraphBurnDown[$reviewType][$perimeterItem][$week]['total_validated'];
					$RIDgraphBurnDown[$reviewType][$perimeterItem][$week]['total_validated_in_order']=$totalValidated;
					$totalGreen+=$RIDgraphBurnDown[$reviewType][$perimeterItem][$week]['total_green'];
					$RIDgraphBurnDown[$reviewType][$perimeterItem][$week]['total_green_in_order']=$totalGreen;
				}
				else 
				{
					$RIDgraphBurnDown[$reviewType][$perimeterItem][$week]['total_validated_in_order']=0;
					$RIDgraphBurnDown[$reviewType][$perimeterItem][$week]['total_green_in_order']=0;
				}

				$totalPlanned+=$RIDgraphBurnDown[$reviewType][$perimeterItem][$week]['total_planned'];
				$RIDgraphBurnDown[$reviewType][$perimeterItem][$week]['total_planned_in_order']=$totalPlanned;
			}

			//This is so the burn down XLSX download works correctly.
			foreach ($RIDgraphBurnDown[$reviewType][$perimeterItem] as $week => $details) 
			{
				$RIDburnDownWeeks[$reviewType][$perimeterItem][] = substr($details['week_number'], -2);
				$RIDburnDownActual[$reviewType][$perimeterItem][] =  $details['total_validated_in_order'];
				$RIDburnDownPredicted[$reviewType][$perimeterItem][] = $details['total_planned_in_order'];
				$RIDburnDownGreen[$reviewType][$perimeterItem][] = $details['total_green_in_order'];
			}
		}
	}

	$answer='';

	?>OK|||dashboard_view&&&<?php

	$actionRidArray=Array('action','rid');
	$color=Array('#ef343f','#f8d707','#81c341','#0088cf');

	?><div class="formHeader" style="position:fixed; top:90px; right:10px; left:210px;"><?php
		?><div class="formHeaderInfo" style="top:6px;">Action & RID Dashboard for <?=$program['program']?> -> <?=$area['area']?></div><?php
		?><div class="xDiv" style="top:0px; right:0px;"><?php

			?><ul class="top-level"><?php

				//BURN UP
				//--------------------------------------------------------------------------------

				?><li onMouseOver="$('burn_up_small').src='../common/img/burn_up_small_blue.png';" onMouseOut="$('burn_up_small').src='../common/img/burn_up_small.png';"><?php
					?><img id="burn_up_small" src="../common/img/burn_up_small.png" /> Burn Up<?php

					?><ul class="second-level"><?php
						foreach ($graphBurnDown as $reviewType => $perimeterArray)
						{
							?><li><?php
								?><?=$reviewType?><?php

								?><ul class="third-level"><?php
									foreach ($perimeterArray as $perimeterItem => $array) 
									{
										if(in_array($perimeterItem,$allowedPerList))
										{
											$biggestBarBurnDown=($graphBurnDownTotals[$reviewType][$perimeterItem]['total_planned_all'] > $graphBurnDownTotals[$reviewType][$perimeterItem]['total_validated_all'])? $graphBurnDownTotals[$reviewType][$perimeterItem]['total_planned_all'] : $graphBurnDownTotals[$reviewType][$perimeterItem]['total_validated_all'];

											if(getFilter('graph','filter','burn_up_'.$reviewType.'_'.$perimeterItem.'_check',$SESSION)) $answer.='&&&burn_up_'.$reviewType.'_'.$perimeterItem.'---'.json_encode($graphBurnDown[$reviewType][$perimeterItem]).'---0---0---0---0---0---0---0---0---0---burn_up---'.$biggestBarBurnDown.'---'.count($graphBurnDown[$reviewType][$perimeterItem]).'---graphHolderBurnDown---'.$perimeterItem.' - '.$reviewType.' Burn Up---'.implode(',', $burnDownWeeks[$reviewType][$perimeterItem]).'%%%'.implode(',', $burnDownActual[$reviewType][$perimeterItem]).'%%%'.implode(',', $burnDownPredicted[$reviewType][$perimeterItem]).'%%%'.implode(',', $burnDownGreen[$reviewType][$perimeterItem]);

											?><li onclick="ajaxRequest('ajax/setGraph.php?value=1&applicability=burn_up_<?=$reviewType?>_<?=$perimeterItem?>_check','restartMainTable',true,'GET');"><?php
												?><?=$perimeterItem?><?php
											?></li><?php
											
											/*?><form id="test" action="support/graphsDownloadBurndown.php" encType="multipart/form-data" method="post"><?php
												?><input name="title" id="title" type="hidden" value="<?=$perimeterItem?> - <?=$reviewType?> Burn Up"/><?php
												?><input name="cw" id="cw" type="hidden" value="<?=implode(',', $burnDownWeeks[$reviewType][$perimeterItem])?>"/><?php
												?><input name="actual" id="actual" type="hidden" value="<?=implode(',', $burnDownActual[$reviewType][$perimeterItem])?>"/><?php
												?><input name="predicted" id="predicted" type="hidden" value="<?=implode(',', $burnDownPredicted[$reviewType][$perimeterItem])?>"/><?php
												?><input name="green" id="green" type="hidden" value="<?=implode(',', $burnDownGreen[$reviewType][$perimeterItem])?>"/><?php
												?><input name="max" id="max" type="hidden" value="<?=$biggestBarBurnDown?>"/><?php
												?><input class="stdBtn" type="submit" style="width:145px" value="Save As Excel (.xlsx) &#9658;"/><?php
											?></form></td><?php*/
										}
									}
								?></ul><?php
							?></li><?php
						}

					?></ul><?php

				?></li><?php

				//PIE CHARTS
				//--------------------------------------------------------------------------------

				?><li onMouseOver="$('pie_small').src='../common/img/pie_small_blue.png';" onMouseOut="$('pie_small').src='../common/img/pie_small.png';"><?php
					?><img id="pie_small" src="../common/img/pie_small.png" /> Pie Charts<?php
					?><ul class="second-level"><?php
						if(!$doNotDisplayTotalActionsOrRids)
						{
							?><li onclick="ajaxRequest('ajax/setGraph.php?value=1&applicability=total_action_check','restartMainTable',true,'GET');">All Actions</li><?php
							?><li style="border-bottom:solid 1px #FFFFFF;" onclick="ajaxRequest('ajax/setGraph.php?value=1&applicability=total_rid_check','restartMainTable',true,'GET');">All RIDs</li><?php

							foreach ($actionRidArray as $item) 
							{
								$graphMeArray=Array('Total '.$item.'s',$countEverything['all_'.$item]['all_'.$item]['all_'.$item],$countEverything['all_'.$item][$item.'_status'][0],$countEverything['all_'.$item][$item.'_status'][1],$countEverything['all_'.$item][$item.'_status'][2],$countEverything['all_'.$item][$item.'_status'][3]);
								if(getFilter('graph','filter','total_'.$item.'_check',$SESSION)) $answer.='&&&total_'.$item.'---'.implode(',',$graphMeArray).'---'.$item.'---msn---coe---msn---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);
							}
						}
						if(!empty($allCoEs))
						{
							foreach($allCoEs as $q=>$z)
							{
								if(in_array($z['coe'],$allowedCoeList))
								{
									?><li><?php
										?><?=$z['coe']?><?php

										?><ul class="third-level"><?php
											?><li onclick="ajaxRequest('ajax/setGraph.php?value=1&applicability=total_action_<?=$z['coe_id']?>_check','restartMainTable',true,'GET');">All Actions</li><?php
											?><li style="border-bottom:solid 1px #FFFFFF;" onclick="ajaxRequest('ajax/setGraph.php?value=1&applicability=total_rid_<?=$z['coe_id']?>_check','restartMainTable',true,'GET');">All RIDs</li><?php
											if(!empty($allMSNs))
											{
												foreach($allMSNs as $j=>$k)
												{
													?><li><?php
														?><?=$k['msn']?><?php

														?><ul class="third-level"><?php
															?><li onclick="ajaxRequest('ajax/setGraph.php?value=1&applicability=total_action_<?=$z['coe_id']?>_<?=$k['msn_id']?>_check','restartMainTable',true,'GET');">All Actions</li><?php
															?><li style="border-bottom:solid 1px #FFFFFF;" onclick="ajaxRequest('ajax/setGraph.php?value=1&applicability=total_rid_<?=$z['coe_id']?>_<?=$k['msn_id']?>_check','restartMainTable',true,'GET');">All RIDs</li><?php

															if(!empty($allReviews))
															{
																foreach($allReviews as $o=>$p)
																{
																	if(!empty($countEverything['all_action']['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all']))
																	{
																		?><li><?php
																			echo $p['review_type'];

																			?><ul class="third-level"><?php
																				?><li onclick="ajaxRequest('ajax/setGraph.php?value=1&applicability=total_action_<?=$z['coe_id']?>_<?=$k['msn_id']?>_<?=$p['review_type']?>_check','restartMainTable',true,'GET');">All Actions</li><?php
																				?><li style="border-bottom:solid 1px #FFFFFF;" onclick="ajaxRequest('ajax/setGraph.php?value=1&applicability=total_rid_<?=$z['coe_id']?>_<?=$k['msn_id']?>_<?=$p['review_type']?>_check','restartMainTable',true,'GET');">All RIDs</li><?php
																				?><li onclick="caGraphSelectionOverlib('action',<?=getFilter('program','filter',0,$SESSION)?>,<?=$z['coe_id']?>,<?=$k['msn_id']?>,<?=$p['review_type_id']?>);">Select Individual</li><?php
																			?></ul><?php

																		?></li><?php

																		foreach ($actionRidArray as $item) 
																		{
																			$graphMeArray=Array($z['coe'].' '.$k['msn'].'\n'.$p['review_type'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][0]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][1]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][2]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][3]['all']);
																			if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'---'.implode(',',$graphMeArray).'---'.$item.'---'.$k['msn'].'---'.$z['coe_id'].'---'.$k['msn_id'].'---'.$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['review_profile'].'---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);


																			if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id']))
																			{
																				foreach($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'] as $x=>$y)
																				{
																					if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_'.$y['ca_id'].'_check',$SESSION)) 
																					{
																						$graphMeArray=Array($z['coe'].' '.$k['msn'].'\n'.$p['review_type'].' '.str_replace('&', 'and', $y['ca_name']).' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][0]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][1]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][2]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][3]['all']);
																						$answer.='&&&total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_'.$y['ca_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---'.$k['msn'].'---'.$z['coe_id'].'---'.$k['msn_id'].'---'.$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['review_profile'].'---'.$y['ca_id'].'---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);
																					}
																				}
																			}

																			foreach($allPERs as $l=>$m) //JFM 04_08_15
																			{
																				if(in_array($m['per'],$allowedPerList))
																				{
																					if(getFilter('graph','filter','total_'.$item.'_per_'.$m['perimeter_id'].'_'.$p['review_type'].'_check',$SESSION) && !in_array('total_'.$item.'_per_'.$m['perimeter_id'].'_'.$p['review_type'].'_check', $perimeterShownQuickFix))
																					{
																						$graphMeArray=Array($m['per'].' '.$p['review_type'].' '.$item.'s',$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']]['all'],$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']][$item.'_status'][0],$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']][$item.'_status'][1],$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']][$item.'_status'][2],$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']][$item.'_status'][3]);											
																						$answer.='&&&total_'.$item.'_per_'.$m['perimeter_id'].'_'.$p['review_type'].'---'.implode(',',$graphMeArray).'---'.$item.'---msn---coe---msn---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);
																						$perimeterShownQuickFix[] = 'total_'.$item.'_per_'.$m['perimeter_id'].'_'.$p['review_type'].'_check';
																					}
																				}
																			}
																		}
																	}
																}
															}

														?></ul><?php

														foreach ($actionRidArray as $item) 
														{
															$graphMeArray=Array($z['coe'].' '.$k['msn'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][0],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][1],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][2],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][3]);
															if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---'.$k['msn'].'---'.$z['coe_id'].'---'.$k['msn_id'].'---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);
														}
													?></li><?php
												}
											}

										?></ul><?php

									?></li><?php

									foreach ($actionRidArray as $item) 
									{
										$graphMeArray=Array($z['coe'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['all'],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][0],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][1],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][2],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][3]);								
										if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_'.$z['coe_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---msn---'.$z['coe_id'].'---msn---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);
									}
								}
							}
						}
					?></ul><?php
				?></li><?php
			?></ul><?php
		?></div><?php

		if(empty($answer))
		{
			?><div style="float:right; background-color:none; margin:50px 150px 0 0; color:#004f6b;"><?php
				?><div style="display:inline; font-size:60px; color:#f47922;">&#10138;</div><?php
				?><div style="display:inline; float:left;  margin-top:50px;">Nothing selected!<br /><span style="font-size:12px;">Select a graph from the drop down menu.</span></div><?php
			?></div><?php
		}

	?></div><?php

	?><div id="graphs" style="padding-right:10px; padding-top: 50px; height:100%; text-align:center;"><?php
			
		?><div style="clear:both; padding-top:25px;"><?php

			?><div id="graphHolder" name="graphHolder" width="75%" align="left"></div><?php
			/*?><div id="downloadGraphHolder" name="downloadGraphHolder" width="75%" align="left"></div><?php*/
			//JFM 19_07_16
			?><div id="graphHolderBurnDown" name="graphHolderBurnDown" width="75%" align="left" style="margin-top:25px; margin-left:50px;"></div><?php


			/*?><div class="sp"></div><?php

			?><div class="formHeader" style="position:relative;"><?php
				?><div class="formHeaderInfo" style="top:6px;">Burn Up</div><?php
			?></div><?php

			?><table id="graph_table_<?=$item?>" class="criteriaTable" cellspacing="0" cellpadding="5"><?php
				?><tr><?php

				$i=0;

				foreach ($graphBurnDown as $reviewType => $perimeterArray)
				{
					foreach ($perimeterArray as $perimeterItem => $array) 
					{
						if(in_array($perimeterItem,$allowedPerList))
						{
							if($i == 5)
							{
								?></tr><tr><?php
								$i=0;
							}
							$i++;
							$biggestBarBurnDown=($graphBurnDownTotals[$reviewType][$perimeterItem]['total_planned_all'] > $graphBurnDownTotals[$reviewType][$perimeterItem]['total_validated_all'])? $graphBurnDownTotals[$reviewType][$perimeterItem]['total_planned_all'] : $graphBurnDownTotals[$reviewType][$perimeterItem]['total_validated_all'];
							?><td><input class="stdBtn"  onClick='graphOnClickCa=1; graphOnClickReviewProfile=2; graphThis("poop_<?=$reviewType?>_<?=$perimeterItem?>", <?php echo json_encode($graphBurnDown[$reviewType][$perimeterItem]); ?>, "burnDown", <?=$biggestBarBurnDown?>, <?=count($graphBurnDown[$reviewType][$perimeterItem])?>, "graphHolderBurnDown", "<?=$perimeterItem?> - <?=$reviewType?> Burn Up");' type="button" value="<?=$perimeterItem?> - <?=$reviewType?> &#9658;"/><br /><?php
							
							?><form id="test" action="support/graphsDownloadBurndown.php" encType="multipart/form-data" method="post"><?php
								?><input name="title" id="title" type="hidden" value="<?=$perimeterItem?> - <?=$reviewType?> Burn Up"/><?php
								?><input name="cw" id="cw" type="hidden" value="<?=implode(',', $burnDownWeeks[$reviewType][$perimeterItem])?>"/><?php
								?><input name="actual" id="actual" type="hidden" value="<?=implode(',', $burnDownActual[$reviewType][$perimeterItem])?>"/><?php
								?><input name="predicted" id="predicted" type="hidden" value="<?=implode(',', $burnDownPredicted[$reviewType][$perimeterItem])?>"/><?php
								?><input name="green" id="green" type="hidden" value="<?=implode(',', $burnDownGreen[$reviewType][$perimeterItem])?>"/><?php
								?><input name="max" id="max" type="hidden" value="<?=$biggestBarBurnDown?>"/><?php
								?><input class="stdBtn" type="submit" style="width:145px" value="Save As Excel (.xlsx) &#9658;"/><?php
							?></form></td><?php
						}
					}
				}

				?></tr><?php
			?></table><?php

			//RID
			?><table id="graph_table_<?=$item?>" class="criteriaTable" cellspacing="0" cellpadding="5"><?php
				?><tr><?php

				$i=0;

				foreach ($RIDgraphBurnDown as $reviewType => $perimeterArray)
				{
					foreach ($perimeterArray as $perimeterItem => $array) 
					{
						if(in_array($perimeterItem,$allowedPerList))
						{
							if($i == 5)
							{
								?></tr><tr><?php
								$i=0;
							}
							$i++;
							$biggestBarBurnDown=($RIDgraphBurnDownTotals[$reviewType][$perimeterItem]['total_planned_all'] > $RIDgraphBurnDownTotals[$reviewType][$perimeterItem]['total_validated_all'])? $RIDgraphBurnDownTotals[$reviewType][$perimeterItem]['total_planned_all'] : $RIDgraphBurnDownTotals[$reviewType][$perimeterItem]['total_validated_all'];
							?><td>RID<input class="stdBtn"  onClick='graphOnClickCa=1; graphOnClickReviewProfile=2; graphThis("poop_<?=$reviewType?>_<?=$perimeterItem?>", <?php echo json_encode($RIDgraphBurnDown[$reviewType][$perimeterItem]); ?>, "burnDown", <?=$biggestBarBurnDown?>, <?=count($RIDgraphBurnDown[$reviewType][$perimeterItem])?>, "graphHolderBurnDown", "<?=$perimeterItem?> - <?=$reviewType?> Burn Up");' type="button" value="<?=$perimeterItem?> - <?=$reviewType?> &#9658;"/><br /><?php
							
							?><form id="test" action="support/graphsDownloadBurndown.php" encType="multipart/form-data" method="post"><?php
								?><input name="title" id="title" type="hidden" value="<?=$perimeterItem?> - <?=$reviewType?> Burn Up"/><?php
								?><input name="cw" id="cw" type="hidden" value="<?=implode(',', $RIDburnDownWeeks[$reviewType][$perimeterItem])?>"/><?php
								?><input name="actual" id="actual" type="hidden" value="<?=implode(',', $RIDburnDownActual[$reviewType][$perimeterItem])?>"/><?php
								?><input name="predicted" id="predicted" type="hidden" value="<?=implode(',', $RIDburnDownPredicted[$reviewType][$perimeterItem])?>"/><?php
								?><input name="green" id="green" type="hidden" value="<?=implode(',', $RIDburnDownGreen[$reviewType][$perimeterItem])?>"/><?php
								?><input name="max" id="max" type="hidden" value="<?=$biggestBarBurnDown?>"/><?php
								?><input class="stdBtn" type="submit" style="width:145px" value="Save As Excel (.xlsx) &#9658;"/><?php
							?></form></td><?php
						}
					}
				}

				?></tr><?php
			?></table><?php*/

			/*?><div class="sp"></div><?php

			?><div class="formHeader" style="position:relative;"><?php
				?><div class="formHeaderInfo" style="top:6px;">Pie Charts</div><?php
			?></div><br /><?php

			$actionRidArray=Array('action','rid');
			$color=Array('#ef343f','#f8d707','#81c341','#0088cf'); //JFM 27_03_14
			//$graphMeArray=Array(title,total,red,yellow,green);

			foreach($actionRidArray as $item)
			{
				?><table id="graph_table_<?=$item?>" class="criteriaTable" cellspacing="0" cellpadding="5"><?php

					//
					// TOTAL TOP
					//
					if(!$doNotDisplayTotalActionsOrRids)
					{
						?><tr class="tableGroup"><?php
							?><td colspan="<?=count($allCoEs)*count($allMSNs)?>" style="text-align:center;"><?php
								?>Total <?=$item?>s<?php
								?><br /><?php

								?><?=$countEverything['all_'.$item]['all_'.$item]['all_'.$item]?><?php
								?><br /><?php

								?><div style="background-color:#FFFFFF;"><?php
									?><div style="display:inline; color:<?=$color[0]?>;"><?=$countEverything['all_'.$item][$item.'_status'][0]?></div> <?php
									?><div style="display:inline; color:<?=$color[1]?>;"><?=$countEverything['all_'.$item][$item.'_status'][1]?></div> <?php
									?><div style="display:inline; color:<?=$color[2]?>;"><?=$countEverything['all_'.$item][$item.'_status'][2]?></div> <?php
									?><div style="display:inline; color:<?=$color[3]?>;"><?=$countEverything['all_'.$item][$item.'_status'][3]?></div> <?php
								?></div><?php
								?><br /><?php

								$graphMeArray=Array('Total '.$item.'s',$countEverything['all_'.$item]['all_'.$item]['all_'.$item],$countEverything['all_'.$item][$item.'_status'][0],$countEverything['all_'.$item][$item.'_status'][1],$countEverything['all_'.$item][$item.'_status'][2],$countEverything['all_'.$item][$item.'_status'][3]);
								
								//JFM 18_03_14
								?><input id="total_<?=$item?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_check',$SESSION))echo' checked="checked"'?>/><?php
								if(getFilter('graph','filter','total_'.$item.'_check',$SESSION)) $answer.='&&&total_'.$item.'---'.implode(',',$graphMeArray).'---'.$item.'---msn---coe---msn---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);

							?></td><?php
						?></tr><?php
					}
					else
					{
						?><tr class="tableGroup"><?php
							?><td colspan="<?=count($allCoEs)*count($allMSNs)?>" style="text-align:center;"><?php
								?><?=$item?>s<?php
							?></td></tr><?php
					}

					//
					// COE's
					//
					if(!empty($allCoEs))
					{
						?><tr><?php
							foreach($allCoEs as $q=>$z)
							{
								if(in_array($z['coe'],$allowedCoeList))
								{
									?><td colspan="<?=count($allMSNs)?>" width="<?=100/count($allCoEs)?>%" align="centre"><?php
										echo $z['coe'];
										?><br /><?php

										if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['all'])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['all'];
										else echo '0';

										?><br /><?php

										for ($i=0; $i < 4; $i++) 
										{ 
											?><font style="color:<?=$color[$i]?>;"><?php

											if(!empty($countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][$i])) echo $countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][$i].' ';
											else echo '0 ';

											?></font><?php
										}

										?><br /><?php

										$graphMeArray=Array($z['coe'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['all'],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][0],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][1],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][2],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][3]);
										
										//JFM 18_03_14
										?><input id="total_<?=$item?>_<?=$z['coe_id']?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_check',$SESSION))echo' checked="checked"'?>/><?php
										if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_'.$z['coe_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---msn---'.$z['coe_id'].'---msn---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);

									?></td><?php
								}
							}
						?></tr><?php
					}

					//
					// MSN's
					//
					if(!empty($allCoEs) && !empty($allMSNs))
					{
						?><tr><?php
							foreach($allCoEs as $q=>$z)
							{
								if(in_array($z['coe'],$allowedCoeList))
								{
									foreach($allMSNs as $j=>$k)
									{
										?><td nowrap="nowarp" align="centre"  width="<?=100/(count($allCoEs)*count($allMSNs))?>%" onClick="expandGraphTableReview('graph_table_<?=$item?>','graphs_<?=$item?>_coe_msn_<?=$q?>_<?=$j?>');"><?php
											echo 'MSN: '.$k['msn'];
											?><br /><?php

											if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['all'])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['all'];
											else echo '0';

											?><br /><?php
											for ($i=0; $i < 4; $i++) 
											{ 
												?><font style="color:<?=$color[$i]?>;"><?php

												if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][$i])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][$i].' ';
												else echo '0 ';

												?></font><?php
											}

											$graphMeArray=Array($z['coe'].' MSN '.$k['msn'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][0],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][1],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][2],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][3]);
											
											//JFM 18_03_14
											?><input id="total_<?=$item?>_<?=$z['coe_id']?>_<?=$k['msn_id']?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_check',$SESSION))echo' checked="checked"'?>/><?php
											if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---'.$k['msn'].'---'.$z['coe_id'].'---'.$k['msn_id'].'---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);

										?></td><?php
									}
								}
							}
						?></tr><?php
					}

					//
					// REVIEW TYPES's
					//
					if(!empty($allCoEs) && !empty($allMSNs) && !empty($allReviews))
					{
						foreach($allCoEs as $q=>$z)
						{
							if(in_array($z['coe'],$allowedCoeList))
							{
								foreach($allMSNs as $j=>$k)
								{
									$reviewsDisplayedCount=0;

									?><tr id="graphs_<?=$item?>_coe_msn_<?=$q?>_<?=$j?>" class="tableGroup" style="display:none"><?php
										?><td colspan="<?=count($allCoEs)*count($allMSNs)?>"><?php
											?><?=$z['coe']?> - MSN <?=$k['msn']?> - Reviews:<?php
										?></td><?php
									?></tr><?php

									?><tr id="graphs_<?=$item?>_coe_msn_<?=$q?>_<?=$j?>" style="display:none"><?php

									foreach($allReviews as $o=>$p)
									{
										?><td align="centre" bgcolor="<?=!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all'])?'C3CDDC':''?>" onclick="caGraphSelectionOverlib('<?=$item?>',<?=getFilter('program','filter',0,$SESSION)?>,<?=$z['coe_id']?>,<?=$k['msn_id']?>,<?=$p['review_type_id']?>);"><?php
											echo $p['review_type'];
											?><br /><?php

											if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all'])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all'];
											else echo '0';

											?><br /><?php

											for ($i=0; $i < 4; $i++) 
											{ 

													?><font style="color:<?=$color[$i]?>;"><?php
												// JFM 12_01_16 }

												if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][$i]['all'])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][$i]['all'].' ';
												else echo '0 ';

												?></font><?php
											}

											//JFM 24_03_14
											$graphMeArray=Array($z['coe'].' MSN '.$k['msn'].'\n'.$p['review_type'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][0]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][1]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][2]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][3]['all']);

											?><input id="total_<?=$item?>_<?=$z['coe_id']?>_<?=$k['msn_id']?>_<?=$p['review_type']?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_check',$SESSION))echo' checked="checked"'?>/><?php
											if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'---'.implode(',',$graphMeArray).'---'.$item.'---'.$k['msn'].'---'.$z['coe_id'].'---'.$k['msn_id'].'---'.$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['review_profile'].'---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);


										?></td><?php

										$reviewsDisplayedCount++;

										if($reviewsDisplayedCount == (count($allCoEs)*count($allMSNs)))
										{
											?></tr><?php
											?><tr id="graphs_<?=$item?>_coe_msn_<?=$q?>_<?=$j?>" style="display:none"><?php
											$reviewsDisplayedCount=0;
										}

										if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id']))
										{
											foreach($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'] as $x=>$y)
											{
												if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_'.$y['ca_id'].'_check',$SESSION)) 
												{
													$graphMeArray=Array($z['coe'].' MSN '.$k['msn'].'\n'.$p['review_type'].' '.str_replace('&', 'and', $y['ca_name']).' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][0]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][1]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][2]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][3]['all']);
													$answer.='&&&total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_'.$y['ca_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---'.$k['msn'].'---'.$z['coe_id'].'---'.$k['msn_id'].'---'.$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['review_profile'].'---'.$y['ca_id'].'---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);
												}
											}
										}

										foreach($allPERs as $l=>$m) //JFM 04_08_15
										{
											if(in_array($m['per'],$allowedPerList))
											{
												if(getFilter('graph','filter','total_'.$item.'_per_'.$m['perimeter_id'].'_'.$p['review_type'].'_check',$SESSION) && !in_array('total_'.$item.'_per_'.$m['perimeter_id'].'_'.$p['review_type'].'_check', $perimeterShownQuickFix))
												{
													$graphMeArray=Array($m['per'].' '.$p['review_type'].' '.$item.'s',$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']]['all'],$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']][$item.'_status'][0],$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']][$item.'_status'][1],$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']][$item.'_status'][2],$countEverything['all_'.$item]['per'][$m['per']]['review_type'][$p['review_type']][$item.'_status'][3]);											
													$answer.='&&&total_'.$item.'_per_'.$m['perimeter_id'].'_'.$p['review_type'].'---'.implode(',',$graphMeArray).'---'.$item.'---msn---coe---msn---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);
													$perimeterShownQuickFix[] = 'total_'.$item.'_per_'.$m['perimeter_id'].'_'.$p['review_type'].'_check';
												}
											}
										}

									}

									?></tr><?php
								}
							}
						}
					}

				?></table><?php

				?><div class="sp"></div><?php
			}*/

			/*foreach ($actionRidArray as $item) 
			{
				?><table id="graph_table_<?=$item?>" class="criteriaTable" cellspacing="0" cellpadding="5"><?php

				//
				// TOTAL TOP
				//
				if(!$doNotDisplayTotalActionsOrRids)
				{
					?><tr class="tableGroup"><?php
						?><td colspan="<?=count($allCoEs)*count($allMSNs)?>" style="text-align:center;"><?php
							?>Total <?=$item?>s<?php
							?><br /><?php

							?><?=$countEverything['all_'.$item]['all_'.$item]['all_'.$item]?><?php
							?><br /><?php

							?><div style="background-color:#FFFFFF;"><?php
								?><div style="display:inline; color:<?=$color[0]?>;"><?=$countEverything['all_'.$item][$item.'_status'][0]?></div> <?php
								?><div style="display:inline; color:<?=$color[1]?>;"><?=$countEverything['all_'.$item][$item.'_status'][1]?></div> <?php
								?><div style="display:inline; color:<?=$color[2]?>;"><?=$countEverything['all_'.$item][$item.'_status'][2]?></div> <?php
								?><div style="display:inline; color:<?=$color[3]?>;"><?=$countEverything['all_'.$item][$item.'_status'][3]?></div> <?php
							?></div><?php
							?><br /><?php

							$graphMeArray=Array('Total '.$item.'s',$countEverything['all_'.$item]['all_'.$item]['all_'.$item],$countEverything['all_'.$item][$item.'_status'][0],$countEverything['all_'.$item][$item.'_status'][1],$countEverything['all_'.$item][$item.'_status'][2],$countEverything['all_'.$item][$item.'_status'][3]);
							
							//JFM 18_03_14
							?><input id="total_<?=$item?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_check',$SESSION))echo' checked="checked"'?>/><?php
							if(getFilter('graph','filter','total_'.$item.'_check',$SESSION)) $answer.='&&&total_'.$item.'---'.implode(',',$graphMeArray).'---'.$item.'---msn---coe---msn---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);

						?></td><?php
					?></tr><?php
				}
				//
				// PERIMETER'S - JFM 14_04_15
				//
				?><tr><?php
					foreach($allPERs as $q=>$z)
					{
						if(in_array($z['per'],$allowedPerList))
						{
							?><td colspan="<?=count($allDeps)?>" width="<?=100/count($allPERs)?>%" align="centre"><?php
								echo $z['per'];
								?><br /><?php

								if(!empty($countEverything['all_'.$item]['per'][$z['per']]['all'])) echo $countEverything['all_'.$item]['per'][$z['per']]['all'];
								else echo '0';

								?><br /><?php

								for ($i=0; $i < 4; $i++) 
								{ 
									?><font style="color:<?=$color[$i]?>;"><?php

									if(!empty($countEverything['all_'.$item]['per'][$z['per']][$item.'_status'][$i])) echo $countEverything['all_'.$item]['per'][$z['per']][$item.'_status'][$i].' ';
									else echo '0 ';

									?></font><?php
								}

								?><br /><?php

								$graphMeArray=Array($z['per'].' '.$item.'s',$countEverything['all_'.$item]['per'][$z['per']]['all'],$countEverything['all_'.$item]['per'][$z['per']][$item.'_status'][0],$countEverything['all_'.$item]['per'][$z['per']][$item.'_status'][1],$countEverything['all_'.$item]['per'][$z['per']][$item.'_status'][2],$countEverything['all_'.$item]['per'][$z['per']][$item.'_status'][3]);
								
								//JFM 18_03_14
								?><input id="total_<?=$item?>_per_<?=$z['perimeter_id']?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_per_'.$z['perimeter_id'].'_check',$SESSION))echo' checked="checked"'?>/><?php
								if(getFilter('graph','filter','total_'.$item.'_per_'.$z['perimeter_id'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_per_'.$z['perimeter_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---msn---coe---msn---0---0---'.getFilter('area','filter',0,$SESSION).'---'.getFilter('program','filter',0,$SESSION);

							?></td><?php
						}
					}
				?></tr><?php

				//
				// DEPARTMENT'S
				//
				?><tr><?php
					foreach($allPERs as $q=>$z)
					{
						if(in_array($z['per'],$allowedPerList))
						{
							foreach($allDeps as $j=>$k)
							{
								if(!empty($countEverything['all_'.$item]['per'][$z['per']]['dep'][$k['siglum']]['all']))
								{
									?><td nowrap="nowarp" align="centre"><?php
										echo 'DEP: '.$k['siglum'];
										?><br /><?php

										if(!empty($countEverything['all_'.$item]['per'][$z['per']]['dep'][$k['siglum']]['all'])) echo $countEverything['all_'.$item]['per'][$z['per']]['dep'][$k['siglum']]['all'];
										else echo '0';

										?><br /><?php
										for ($i=0; $i < 4; $i++) 
										{ 
											?><font style="color:<?=$color[$i]?>;"><?php

											if(!empty($countEverything['all_'.$item]['per'][$z['per']]['dep'][$k['siglum']][$item.'_status'][$i])) echo $countEverything['all_'.$item]['per'][$z['per']]['dep'][$k['siglum']][$item.'_status'][$i].' ';
											else echo '0 ';

											?></font><?php
										}
									?></td><?php
								}
							}
						}
					}
				?></tr><?php
			}*/

			/*?><div class="sp"></div><?php

			//JFM 21_02_14
			?><input class="stdBtn" id="3dxmlContainerDisplay" onClick="load3dxml();" type="button" value="Show 3DXML"><?php
			?><div id="3dxmlContainer" align="center"></div><?php*/

			/* This is to take a screen - Not yet done. However possible in the future.
			$cropArray=Array('x' => 100,'y' => 100,'width' => 100,'height' => 100);
			$im=imagegrabscreen();
			$imCrop=imagecrop($im,$cropArray);
			imagepng($imCrop, '../output/test.png');
			imagedestroy($im);
			imagedestroy($imCrop);*/

		?></div><?php

	?></div><?php

	echo $answer;
}

storeSession($SESSION);

?>