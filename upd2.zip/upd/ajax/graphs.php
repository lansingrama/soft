<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

if(!getFilter('program','filter',0,$SESSION) || !getFilter('coe','filter',0,$SESSION))
{
	?>OK|||no_program_coe_msn<?php
}
else
{
	//JFM 09_04_14
	$allQry1=SqlLi('SELECT DISTINCT
								act.action_id,act.action_status,
								rid.rid_id,rid.rid_status,
								coe.coe, coe.coe_id, cmn.msn, rt.review_type, rt.review_type_id, rp.review_profile_id,
								GROUP_CONCAT(ca.ca_id,\'---\',ca.ca) as ca_id
							FROM dr_action 			AS act 
								INNER JOIN c_msn					AS cmn 	ON 	cmn.msn_id=act.msn
								INNER JOIN dr_action_applicability	AS app 	ON 	act.action_id=app.action
								INNER JOIN c_ca 					AS ca  	ON 	app.ca=ca.ca_id
								INNER JOIN c_coe 					AS coe 	ON 	ca.coe=coe.coe_id
								INNER JOIN dr_review_criterion		AS rc 	ON 	act.criteria=rc.review_criterion_id
								INNER JOIN dr_review_group 			AS rg 	ON 	rc.review_group=rg.group_id
								INNER JOIN dr_review_type 			AS rt 	ON 	rg.review_type=rt.review_type_id
								INNER JOIN dr_review_profile		AS rp   ON 	rp.program=cmn.program
																			AND rp.coe=coe.coe_id
																			AND rp.review_type=rt.review_type_id
								INNER JOIN c_cawp					AS cw	ON 	ca.ca_id=cw.ca
																			AND cmn.msn_id=cw.msn
								LEFT  JOIN dr_rid					AS rid 	ON 	act.rid=rid.rid_id
							WHERE cmn.program='.getFilter('program','filter',0,$SESSION).'
							GROUP BY act.action_id');

	$allQry2=SqlLi('SELECT DISTINCT
								act.action_id,act.action_status,
								rid.rid_id,rid.rid_status,
								coe.coe, coe.coe_id, cmn.msn, rt.review_type, rt.review_type_id, rp.review_profile_id,
								GROUP_CONCAT(ca.ca_id,\'---\',ca.ca) as ca_id
							FROM dr_action 			AS act 
								INNER JOIN c_msn					AS cmn 	ON 	cmn.msn_id=act.msn
								INNER JOIN dr_action_applicability	AS app 	ON 	act.action_id=app.action
								INNER JOIN c_ca 					AS ca  	ON 	app.ca=ca.ca_id
								INNER JOIN c_coe 					AS coe 	ON 	ca.coe=coe.coe_id
								INNER JOIN dr_review 				AS r 	ON 	act.review=r.review_id
								INNER JOIN dr_review_profile		AS rp   ON 	rp.program=cmn.program
																			AND rp.coe=coe.coe_id
																			AND r.review_profile=rp.review_profile_id
								INNER JOIN dr_review_type 			AS rt 	ON 	rp.review_type=rt.review_type_id

								INNER JOIN c_cawp					AS cw	ON 	ca.ca_id=cw.ca
																			AND cmn.msn_id=cw.msn
								LEFT  JOIN dr_rid					AS rid 	ON 	act.rid=rid.rid_id
							WHERE cmn.program='.getFilter('program','filter',0,$SESSION).'
							GROUP BY act.action_id');

	$allQry=array();

	if(!empty($allQry1) && !empty($allQry2)) $allQry=array_merge($allQry1, $allQry2);
	else if (!empty($allQry1)) $allQry=$allQry1;
	else if (!empty($allQry2)) $allQry=$allQry2;
	else echo 'Nothing to select!';

	$allCoEs=SqlLi('SELECT coe, coe_id FROM c_coe ORDER BY coe_id ASC');
	$allMSNs=SqlLi('SELECT msn, msn_id FROM c_msn WHERE program='.getFilter('program','filter',0,$SESSION).' ORDER BY msn ASC');
	$allReviews=SqlLi('SELECT review_type, review_type_id FROM dr_review_type ORDER BY review_type ASC');
	$program=SqlQ('SELECT program FROM c_program WHERE program_id='.getFilter('program','filter',0,$SESSION));

	$allowedCoeList=allowedSimpleObject('coe','coe',$SESSION,'c_','','view','ASC');
	$reviewProfileList=allowedSimpleObject('review_profile','review_type',$SESSION,'dr_','program='.getFilter('program','filter',0,$SESSION));

	$doNotDisplayTotalActionsOrRids=false;

	$countEverything=Array();
	$usedRIDs=Array();

	if(is_array($allQry))
	{		
		foreach($allQry as $q=>$z)
		{

			if(in_array($z['coe'],$allowedCoeList) && in_array($z['review_type_id'],$reviewProfileList))
			{
				$countEverything['all_action']['all_action']['all_action']++;
				$countEverything['all_action']['action_status'][$z['action_status']]++;
				$countEverything['all_action']['coe'][$z['coe']]['all']++;
				$countEverything['all_action']['coe'][$z['coe']]['action_status'][$z['action_status']]++;
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['all']++;
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['action_status'][$z['action_status']]++;
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['all']++;
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['action_status'][$z['action_status']]['all']++;

				$allCaInfo=explode(',',$z['ca_id']);			

				foreach($allCaInfo as $y)
				{
					$allCaInfoSplit=explode("---",$y);
					$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['ca_id']=$allCaInfoSplit[0];
					$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['ca_name']=$allCaInfoSplit[1];
					$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['all']++;
					$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['action_status'][$z['action_status']]['all']++;
				}

				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['action_status'][$z['action_status']]['ca_id'][$z['ca_id']]=$z['ca_id'];
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['review_profile']=$z['review_profile_id'];
				$countEverything['all_action']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['review_type_id']=$z['review_type_id'];

				if($z['rid_id'] && !in_array($z['rid_id'], $usedRIDs)) 
				{
					$countEverything['all_rid']['all_rid']['all_rid']++;
					$countEverything['all_rid']['rid_status'][$z['rid_status']]++;
					$countEverything['all_rid']['coe'][$z['coe']]['all']++;
					$countEverything['all_rid']['coe'][$z['coe']]['rid_status'][$z['rid_status']]++;
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['all']++;
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['rid_status'][$z['rid_status']]++;
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['all']++;
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['rid_status'][$z['rid_status']]['all']++;
					
					$allCaInfo=explode(',',$z['ca_id']);			

					foreach($allCaInfo as $y)
					{
						$allCaInfoSplit=explode("---",$y);
						$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['ca_id']=$allCaInfoSplit[0];
						$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['ca_name']=$allCaInfoSplit[1];
						$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['all']++;
						$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['ca_id'][$allCaInfoSplit[0]]['rid_status'][$z['rid_status']]['all']++;
					}

					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['rid_status'][$z['rid_status']]['ca_id'][$z['ca_id']]=$z['ca_id'];
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['review_profile']=$z['review_profile_id'];
					$countEverything['all_rid']['coe'][$z['coe']]['msn'][$z['msn']]['review_type'][$z['review_type']]['review_type_id']=$z['review_type_id'];

					array_push($usedRIDs,$z['rid_id']);
				}
			}
			else if($doNotDisplayTotalActionsOrRids==false) $doNotDisplayTotalActionsOrRids=true;
		}
	}

	$answer='';

	?>OK|||dashboard_view&&&<?php

	?><div id="graphs"style="padding-right:10px;"><?php

		?><div><?php

			?><div id="graphHolder" name="graphHolder" width="75%"></div><?php
			?><div id="downloadGraphHolder" name="downloadGraphHolder" width="75%"></div><?php

			?><div class="sp"></div><?php
			?><div class="sp"></div><?php

			$actionRidArray=Array('action','rid');
			$color=Array('#900','#b8b000','#060','#609dc9'); //JFM 27_03_14
			//$graphMeArray=Array(title,total,red,yellow,green);

			foreach($actionRidArray as $item)
			{
				?><table id="graph_table_<?=$item?>" style="border-style:solid; border-width:1px; border-color:black; width:95%"><?php

					//
					// TOTAL TOP
					//
					if(!$doNotDisplayTotalActionsOrRids)
					{
						?><tr><?php
							?><td colspan="<?=count($allCoEs)*count($allMSNs)?>" style="background-color:#C3CDDC; color:#565C6A; font-weight:bold;"><?php
								?>Total <?=$item?>s<?php
								?><br /><?php

								?><?=$countEverything['all_'.$item]['all_'.$item]['all_'.$item]?><?php
								?><br /><?php

								?><font style="color:<?=$color[0]?>;"><?=$countEverything['all_'.$item][$item.'_status'][0]?></font> <?php
								?><font style="color:<?=$color[1]?>;"><?=$countEverything['all_'.$item][$item.'_status'][1]?></font> <?php
								?><font style="color:<?=$color[2]?>;"><?=$countEverything['all_'.$item][$item.'_status'][2]?></font> <?php
								?><font style="color:<?=$color[3]?>;"><?=$countEverything['all_'.$item][$item.'_status'][3]?></font> <?php

								?><br /><?php

								$graphMeArray=Array('Total '.$item.'s',$countEverything['all_'.$item]['all_'.$item]['all_'.$item],$countEverything['all_'.$item][$item.'_status'][0],$countEverything['all_'.$item][$item.'_status'][1],$countEverything['all_'.$item][$item.'_status'][2],$countEverything['all_'.$item][$item.'_status'][3]);
								/*JFM 18_03_14 ?><input class="stdBtn" id="displayActionGraph" onClick='graphThis("total_<?=$item?>", <?php echo json_encode($graphMeArray); ?>);' type="button" value="Graph"><?php*/
								
								//JFM 18_03_14
								?><input id="total_<?=$item?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_check',$SESSION))echo' checked="checked"'?>/><?php
								if(getFilter('graph','filter','total_'.$item.'_check',$SESSION)) $answer.='&&&total_'.$item.'---'.implode(',',$graphMeArray).'---'.$item.'---msn---coe---msn---0---0';

							?></td><?php
						?></tr><?php
					}

					//
					// COE's
					//
					?><tr><?php
						foreach($allCoEs as $q=>$z)
						{
							if(in_array($z['coe'],$allowedCoeList))
							{
								?><td colspan="<?=count($allMSNs)?>" width="<?=100/count($allCoEs)?>%" align="centre" bgcolor="E5E5E5" style="color:#565C6A; font-weight:bold;"><?php
									echo $z['coe'];
									?><br /><?php

									if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['all'])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['all'];
									else echo '0';

									?><br /><?php

									for ($i=0; $i < 4; $i++) 
									{ 
										?><font style="color:<?=$color[$i]?>;"><?php

										if(!empty($countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][$i])) echo $countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][$i].' ';
										else echo '0 ';

										?></font><?php
									}

									?><br /><?php

									$graphMeArray=Array($z['coe'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['all'],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][0],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][1],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][2],$countEverything['all_'.$item]['coe'][$z['coe']][$item.'_status'][3]);
									/*JFM 18_03_14?><input class="stdBtn" id="displayActionGraph" onClick='graphThis("total_<?=$item?>_<?=$z['coe_id']?>", <?php echo json_encode($graphMeArray); ?>);' type="button" value="Graph"><?php*/
									
									//JFM 18_03_14
									?><input id="total_<?=$item?>_<?=$z['coe_id']?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_check',$SESSION))echo' checked="checked"'?>/><?php
									if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_'.$z['coe_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---msn---'.$z['coe_id'].'---msn---0---0';

								?></td><?php
							}
						}
					?></tr><?php

					//
					// MSN's
					//
					?><tr><?php
						foreach($allCoEs as $q=>$z)
						{
							if(in_array($z['coe'],$allowedCoeList))
							{
								foreach($allMSNs as $j=>$k)
								{
									?><td align="centre"  width="<?=100/(count($allCoEs)*count($allMSNs))?>%" bgcolor="E5E5E5" style="color:#565C6A; font-weight:bold; cursor:pointer;" onClick="expandGraphTableReview('graph_table_<?=$item?>','graphs_<?=$item?>_coe_msn_<?=$q?>_<?=$j?>');"><?php
										echo 'MSN: '.$k['msn'];
										?><br /><?php

										if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['all'])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['all'];
										else echo '0';

										?><br /><?php
										for ($i=0; $i < 4; $i++) 
										{ 
											?><font style="color:<?=$color[$i]?>;"><?php

											if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][$i])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][$i].' ';
											else echo '0 ';

											?></font><?php
										}

										$graphMeArray=Array($z['coe'].' MSN '.$k['msn'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][0],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][1],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][2],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']][$item.'_status'][3]);
										
										//JFM 18_03_14
										?><input id="total_<?=$item?>_<?=$z['coe_id']?>_<?=$k['msn_id']?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_check',$SESSION))echo' checked="checked"'?>/><?php
										if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---'.$k['msn'].'---'.$z['coe_id'].'---'.$k['msn_id'].'---0---0';

									?></td><?php
								}
							}
						}
					?></tr><?php

					//
					// REVIEW TYPES's
					//
					foreach($allCoEs as $q=>$z)
					{
						if(in_array($z['coe'],$allowedCoeList))
						{
							foreach($allMSNs as $j=>$k)
							{
								$reviewsDisplayedCount=0;

								?><tr id="graphs_<?=$item?>_coe_msn_<?=$q?>_<?=$j?>" style="display:none"><?php
									?><td colspan="<?=count($allCoEs)*count($allMSNs)?>" style="background-color:#C3CDDC; color:#565C6A; font-weight:bold;"><?php
										?><?=$z['coe']?> - MSN <?=$k['msn']?> - Reviews:<?php
									?></td><?php
								?></tr><?php

								?><tr id="graphs_<?=$item?>_coe_msn_<?=$q?>_<?=$j?>" style="display:none"><?php

								foreach($allReviews as $o=>$p)
								{
									?><td align="centre" bgcolor="<?=!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all'])?'C3CDDC':'E5E5E5'?>" style="color:#565C6A; font-weight:bold;" onclick="caGraphSelectionOverlib('<?=$item?>',<?=getFilter('program','filter',0,$SESSION)?>,<?=$z['coe_id']?>,<?=$k['msn_id']?>,<?=$p['review_type_id']?>);"><?php
										echo $p['review_type'];
										?><br /><?php

										if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all'])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all'];
										else echo '0';

										?><br /><?php

										for ($i=0; $i < 4; $i++) 
										{ 
											if($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][$i]['ca_id'])
											{
												$ca=implode(',',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][$i]['ca_id']);
												$review_profile=$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['review_profile'];
												/*
												* US #054
												* Version :2.0
												* Fixed by : Infosys Limited 
												* pie chart condittion
												*/
												?><font class="graphFont" style="color:<?=$color[$i]?>; cursor:pointer;" onclick="changeDropDownWhenGraphOptionSelected(<?=$z['coe_id']?>,<?=$k['msn_id']?>); openForm('list','list_name=<?=$item?>&<?=$item?>_status=<?=$i?>&msn=<?=$k['msn']?>&coe=<?=$z['coe_id']?>&ca=<?=$ca?>&review_profile=<?=$review_profile?>&iNeedThisSoItWorks=coe&piediagram=1',false,'GET');"><?php //JFM 11_03_13																	 
											
												/*prevSel('msnSel','coe',<?=$z['coe_id']?>,'msn',attachDdValue('program','programSel')+attachDdValue('coe','coeSel')); prevSel('','msn',<?=$k['msn_id']?>,'','&show=1');*/
											}
											else
											{
												?><font style="color:<?=$color[$i]?>;"><?php
											}

											if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][$i]['all'])) echo $countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][$i]['all'].' ';
											else echo '0 ';

											?></font><?php
										}

										//JFM 24_03_14
										$graphMeArray=Array($z['coe'].' MSN '.$k['msn'].'\n'.$p['review_type'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][0]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][1]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][2]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']][$item.'_status'][3]['all']);

										?><input id="total_<?=$item?>_<?=$z['coe_id']?>_<?=$k['msn_id']?>_<?=$p['review_type']?>_check" onclick="checkChange(this,'graph');" type="checkbox" value="1" <?php if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_check',$SESSION))echo' checked="checked"'?>/><?php
										if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_check',$SESSION)) $answer.='&&&total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'---'.implode(',',$graphMeArray).'---'.$item.'---'.$k['msn'].'---'.$z['coe_id'].'---'.$k['msn_id'].'---'.$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['review_profile'].'---0';


									?></td><?php

									$reviewsDisplayedCount++;

									if($reviewsDisplayedCount == (count($allCoEs)*count($allMSNs)))
									{
										?></tr><?php
										?><tr id="graphs_<?=$item?>_coe_msn_<?=$q?>_<?=$j?>" style="display:none"><?php
										$reviewsDisplayedCount=0;
									}

									if(!empty($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id']))
									{
										foreach($countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'] as $x=>$y)
										{
											if(getFilter('graph','filter','total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_'.$y['ca_id'].'_check',$SESSION)) 
											{
												$graphMeArray=Array($z['coe'].' MSN '.$k['msn'].'\n'.$p['review_type'].' '.$y['ca_name'].' '.$item.'s',$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][0]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][1]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][2]['all'],$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['ca_id'][$x][$item.'_status'][3]['all']);
												$answer.='&&&total_'.$item.'_'.$z['coe_id'].'_'.$k['msn_id'].'_'.$p['review_type'].'_'.$y['ca_id'].'---'.implode(',',$graphMeArray).'---'.$item.'---'.$k['msn'].'---'.$z['coe_id'].'---'.$k['msn_id'].'---'.$countEverything['all_'.$item]['coe'][$z['coe']]['msn'][$k['msn']]['review_type'][$p['review_type']]['review_profile'].'---'.$y['ca_id'];
											}
										}
									}
								}

								?></tr><?php
							}
						}
					}

				?></table><?php

				?><div class="sp"></div><?php
			}

			/*?><div class="sp"></div><?php

			//JFM 21_02_14
			?><input class="stdBtn" id="3dxmlContainerDisplay" onClick="load3dxml();" type="button" value="Show 3DXML"><?php
			?><div id="3dxmlContainer" align="center"></div><?php*/

			/* This is to take a screen - Not yet done. However possible in the future.
			$cropArray=Array('x' => 100,'y' => 100,'width' => 100,'height' => 100);
			$im=imagegrabscreen();
			$imCrop=imagecrop($im,$cropArray);
			imagepng($imCrop, '../output/test.png');
			imagedestroy($im);
			imagedestroy($imCrop);*/
		?></div><?php

	?></div><?php

	echo $answer;
}

storeSession($SESSION);

?>