<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

if($included!=1) $POST=cleanArray($_POST);

	
$review=SqlLi('SELECT rgh.review_group_description, rg.group_id
					FROM dr_review_group_history		AS rgh
						INNER JOIN dr_review_group		AS rg ON rgh.review_group=rg.group_id
						INNER JOIN dr_review_profile	AS rp ON rg.review_type=rp.review_type
					WHERE rp.review_profile_id="'.$POST['review_profile'].'"
					AND rgh.review_group_valid_to="0000-00-00 00:00:00"
					ORDER BY rgh.review_group_position');			
					
if($included!=1)
{
	echo'OK|||';
}

?><div style="border-bottom: #565c6a 1px solid; margin-left:10px; margin-right: 5px; padding-bottom:10px;"><strong>Criteria Groups:</strong></div><?php
if(is_array($review))
{
	?><div class="sideElement" id="catElement_0" onClick="openSideElement('0','cat','empty&list_name=cat&review_profile=<?=$POST['review_profile']?>&reviewTypeName=<?=$POST['reviewTypeName']?>&reviewID=<?=$POST['reviewID']?>&table_cache_id=<?=$POST['table_cache_id']?>&removeTableCache=<?=$POST['table_cache_id']?>');">All Groups</div><?php //JFM 14_11_13	
	
	foreach($review as $k)
	{
		if(strlen($k['review_group_description']) > 25) $description = substr($k['review_group_description'],0,22).'...';
		else $description=$k['review_group_description'];

		?><div class="sideElement" id="catElement_<?=$k['group_id']?>" onClick="openSideElement('<?=$k['group_id']?>','cat','empty&list_name=cat&review_profile=<?=$POST['review_profile']?>&reviewTypeName=<?=$POST['reviewTypeName']?>&groupID=<?=$k['group_id']?>&reviewID=<?=$POST['reviewID']?>&table_cache_id=<?=$POST['table_cache_id']?>&removeTableCache=<?=$POST['table_cache_id']?>');"
			<?php if(strlen($k['review_group_description'])>25){?> onMouseOut="nd();"onMouseOver="overlib('<?=htmlentities(utf8_decode($k['review_group_description']))?>');"<?php }
		?>><?=$description?></div><?php
	}
}
else
{
	?><div class="sideElementEmpty"id="reviewElement_noResults"style="display:block;">No Results</div><?php 
}


storeSession($SESSION);
?>