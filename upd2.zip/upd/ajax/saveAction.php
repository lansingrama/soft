<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');
require_once('../support/mail.php'); //JFM 28_10_15

$statusNumber=array('r'=>0,'a'=>1,'g'=>2,'x'=>3,0=>0,1=>1,2=>2,3=>3); //JFM 27_03_14
$POST=cleanArray($_POST);

if($POST['validationCheck']==1) //JFM 30_10_14
{
	if($POST['start_validation']==1)
	{
		$POST['action_status']='g';
		
		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ('.$SESSION['object']['action_id'].','.$POST['action_id'].',"'.$POST['action_holder'].'",0)');
				
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
				VALUES ('.$SESSION['object']['action_id'].','.$POST['action_id'].',"'.$POST['action_holder'].'",0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="originated"),SYSDATE())');

		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ('.$SESSION['object']['action_id'].','.$POST['action_id'].','.$POST['action_validator'].',1)');

		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
				VALUES ('.$SESSION['object']['action_id'].','.$POST['action_id'].','.$POST['action_validator'].',1,SYSDATE())');
				
		$email=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$POST['action_validator']);
		$actionCode=SqlQ('SELECT action_code FROM dr_action WHERE action_id='.$POST['action_id']);

		$headers="MIME-Version: 1.0\r\n";
		$headers.="Content-type: text/html; charset=utf-8\r\n";
		$headers.="From: Airbus No Reply <noreply@airbus.com>\r\n"; 
		$headers.="Reply-To: noreply@airbus.com\r\n"; 
		$headers.="Return-path: noreply@airbus.com\r\n";
		$headers.="Cc: \r\n";
		$headers.="Bcc: \r\n";

		$mailBody='
					<html>
					<head>
						<title>Action Validation</title>
					</head>
					<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
						<div style="width: 100%; height: 300px; cellSpacing=0; cellPadding=5; border=0;">
						<table align="center">
						  <tr>
							<td style="background-color:#6f95ab;color:#FFFFFF;font-family:Verdana,Arial,Helvetica,sans-serif;font-size:11px;font-weight:normal;padding-left:10px;">
								Action Validation
							</td>	
						</tr>
						<tr>
							<td style="border-width:0px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; padding-left:10px;">
								<strong>Dear '.$email['name'].' '.$email['surname'].',</strong><br>
								<p>
								This is an automatic email to inform you a action requires your validation.<br><br>
								This action is for <strong>'.$actionCode['action_code'].'.</strong> 
								</p>
								Click the link below to login and validate the action:<br>
								<a https://myhosting1.airbus.corp/app075/dr_report/index.php">
								https://myhosting1.airbus.corp/app075/dr_report/index.php</a><br><br>
								Please, do not reply to this message.<br>
								<br><br><br>
								Best regards,<br><br>
								Airbus Review Tool Team.
							</td>
						  </tr>
						</table>
					</div>
					</body>
					</html>';

		if($email['allow_emails']!=1) mail($email['email'],'Action Validation Required - Airbus Review Tool',$mailBody,$headers);
			
	}
	else if($POST['modifying']==1)
	{
		SqlLQ('UPDATE dr_validation_loop
				SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="modified"),
				action_taken_on=SYSDATE()
				WHERE object="'.$SESSION['object']['action_id'].'"
				AND applicability="'.$POST['action_id'].'"
				AND validator='.$POST['action_holder'].'
				AND action_taken=0');
		
		SqlLQ('DELETE FROM dr_validation_loop_structure WHERE object='.$SESSION['object']['action_id'].' AND applicability='.$POST['action_id']);

		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ('.$SESSION['object']['action_id'].','.$POST['action_id'].',"'.$POST['action_holder'].'",0)');

		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ('.$SESSION['object']['action_id'].','.$POST['action_id'].','.$POST['action_validator'].',1)');

		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
				VALUES ('.$SESSION['object']['action_id'].','.$POST['action_id'].','.$POST['action_validator'].',1,SYSDATE())');

		$email=SqlQ('SELECT email, name, surname, allow_emails FROM c_user WHERE user_id='.$POST['action_validator']);
		$actionCode=SqlQ('SELECT action_code FROM dr_action WHERE action_id='.$POST['action_id']);

		$headers="MIME-Version: 1.0\r\n";
		$headers.="Content-type: text/html; charset=utf-8\r\n";
		$headers.="From: Airbus No Reply <noreply@airbus.com>\r\n"; 
		$headers.="Reply-To: noreply@airbus.com\r\n"; 
		$headers.="Return-path: noreply@airbus.com\r\n";
		$headers.="Cc: \r\n";
		$headers.="Bcc: \r\n";

		$mailBody='
					<html>
					<head>
						<title>Action Validation</title>
					</head>
					<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
						<div style="width: 100%; height: 300px; cellSpacing=0; cellPadding=5; border=0;">
						<table align="center">
						  <tr>
							<td style="background-color:#6f95ab;color:#FFFFFF;font-family:Verdana,Arial,Helvetica,sans-serif;font-size:11px;font-weight:normal;padding-left:10px;">
								Action Validation
							</td>	
						</tr>
						<tr>
							<td style="border-width:0px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; padding-left:10px;">
								<strong>Dear '.$email['name'].' '.$email['surname'].',</strong><br>
								<p>
								This is an automatic email to inform you a action requires your validation.<br><br>
								This action is for <strong>'.$actionCode['action_code'].'.</strong> 
								</p>
								Click the link below to login and validate the action:<br>
								<a https://myhosting1.airbus.corp/app075/dr_report/index.php">
								https://myhosting1.airbus.corp/app075/dr_report/index.php</a><br><br>
								Please, do not reply to this message.<br>
								<br><br><br>
								Best regards,<br><br>
								Airbus Review Tool Team.
							</td>
						  </tr>
						</table>
					</div>
					</body>
					</html>';

		if($email['allow_emails']!=1) mail($email['email'],'Action Validation Required - Airbus Review Tool',$mailBody,$headers);

	}
	else 
	{
		$alreadyInValidationLoop=SqlQ('SELECT count(*) AS count FROM dr_validation_loop WHERE applicability="'.$POST['action_id'].'" AND object='.$SESSION['object']['action_id']);
		
		if($alreadyInValidationLoop['count']=="0") $POST['action_status']='a';
	}
}

$newActionFlag = false; //JFM 28_10_15

$POST['rid_status']=$statusNumber[$POST['rid_status']];
$POST['action_status']=$statusNumber[$POST['action_status']];

$actionQry=formToQuery($POST,$SESSION['table']['action']['action'],$SESSION);

if($POST['action_id']!='new') $action=SqlQ('SELECT * FROM dr_action WHERE action_id="'.$POST['action_id'].'"');

if($POST['rid']!='new') $rid=SqlQ('SELECT * FROM dr_rid WHERE rid_id="'.$POST['rid'].'"');

if(!$action['action_id'])
{
	$newActionFlag = true; //JFM 28_10_15

	if($POST['criteria']==0) //JFM 09_04_14
	{
		$POST['action_code']=newCode($POST['wp'],$POST['review_id'],$SESSION,'action','review');
		SqlLQ('INSERT INTO dr_action (msn,review,action_code,action_creation) VALUES ("'.$POST['msn'].'","'.$POST['review_id'].'","'.$POST['action_code'].'",SYSDATE())');
	}
	else
	{
		$POST['action_code']=newCode($POST['wp'],$POST['criteria'],$SESSION,'action');
		SqlLQ('INSERT INTO dr_action (msn,criteria,action_code,action_creation) VALUES ("'.$POST['msn'].'","'.$POST['criteria'].'","'.$POST['action_code'].'",SYSDATE())');
	}
	$action=SqlQ('SELECT * FROM dr_action WHERE action_code="'.$POST['action_code'].'"');
	createLog('dr_log','action_id','create',$action['action_id'],'','',$SESSION);
}

$actionUpdateString=getFormUpdate($actionQry,$action,'action','action',$action['action_id'],$SESSION,array('action_code','wp'));

//JFM 24_03_14
if($POST['action_holder']=='undefined' && $POST['action_holder_name']!='') 
{
	$actionUpdateString[]='action_holder=0';
	$actionUpdateString[]='action_holder_name="'.$POST['action_holder_name'].'"';
}
if($POST['action_validator']=='undefined' && $POST['action_validator_name']!='') 
{
	$actionUpdateString[]='action_validator=0';
	$actionUpdateString[]='action_validator_name="'.$POST['action_validator_name'].'"';
}

$actionUpdateString[]='validation_loop='.$POST['validationCheck']; //JFM 30_10_14

if(!empty($actionUpdateString))
{
	if($actionQry['action_status']==2 || $actionQry['action_status']==3)
	{
		$actionUpdateString[]='action_closure=SYSDATE()';
		$POST['action_closure']=date("y-m-d");
	}
	else
	{
		$actionUpdateString[]='action_closure=0000-00-00';
		$POST['action_closure']=date("y-m-d");
	}
	SqlLQ('UPDATE dr_action SET '.implode(',',$actionUpdateString).' WHERE action_id="'.$action['action_id'].'"');

	if($POST['action_holder']!='undefined' && $newActionFlag)
	{
		$user=SqlQ('SELECT name, surname, email FROM c_user WHERE user_id='.$POST['action_holder']);

		if(!empty($user))
		{
			$object='Action';
			$whatDone='Assigned to You';
			$message='This is an automatic email to inform you that you are the holder for a new action.<br><br>
							The action code is: <strong>'.$POST['action_code'].'</strong><br><br>
							The action description is: <strong>'.$POST['action_description'].'.</strong><br><br>
							This action must be completed by: <strong>'.((!empty($POST['action_completion']))?$POST['action_completion'] : 'No Date Set').'</strong>';

			$doSomething='view your action';
			$subject='New Action Assigned to You - Airbus Review Tool';
			sendThemMailings($object, $whatDone, $message, $doSomething, $subject, $user['email'], $user['name'], $user['surname']);
		}
	}

}

foreach($POST as $k=>$v)
{
	if(substr($k,0,14)=='applicable_ca_')
	{
		//echo $k,',';
		$applicabilityId=explode('_',$k);
		if($applicabilityId[2]!='')
		{
			$applicability[$applicabilityId[2]]=$v;
		}
	}
}

if(!empty($applicability)) updateActionApplicability($applicableCa,$action['action_id'],$applicability); //JFM 30_10_14

if(!$POST['rid']==0)
{
	if(empty($POST['rid_showstopper'])) $POST['rid_showstopper']=0;
	if(empty($POST['rid_action_plan'])) $POST['rid_action_plan']=0;
	if(empty($POST['rid_change_note'])) $POST['rid_change_note']=0;
	
	$ridQry=formToQuery($POST,$SESSION['table']['rid']['rid'],$SESSION);
	if($rid['rid_id']=='' || $rid['rid_id']=='n')
	{
		$newRidCode=newCode($POST['wp'],$POST['criteria'],$SESSION,'rid');
		//JFM 02_12_13	- JFM 06_02_14 - JFM 30_10_14
		SqlLQ('INSERT INTO dr_rid 
					(criteria,rid_code,rid_title,rid_status,rid_holder,rid_holder_name,rid_creation,rid_completion,rid_showstopper,rid_action_plan, rid_change_note,rid_validator,rid_validator_name)
				VALUES
					("'.$POST['criteria'].'","'.$newRidCode.'","'.$POST['rid_title'].'","'.$POST['rid_status'].'","'.$POST['rid_holder'].'","'.$POST['rid_holder_name'].'",SYSDATE(),"'.$POST['rid_completion'].'","'.$POST['rid_showstopper'].'","'.$POST['rid_action_plan'].'","'.$POST['rid_change_note'].'","'.$POST['rid_validator'].'","'.$POST['rid_validator_name'].'")');
		$rid=SqlQ('SELECT * FROM dr_rid WHERE rid_code="'.$newRidCode.'"');
		createLog('dr_log','rid_id','create',$action['rid_id'],'','',$SESSION);
		SqlLQ('UPDATE dr_action SET rid="'.$rid['rid_id'].'" WHERE action_id="'.$action['action_id'].'"');
	}
	else
	{
		$ridUpdateString=getFormUpdate($ridQry,$rid,'rid','rid',$rid['rid_id'],$SESSION,array('rid_code','action_code'));
	}

	if($POST['rid_holder']=='undefined' && $POST['rid_holder_name']!='') 
	{
		$ridUpdateString[]='rid_holder=0';
		$ridUpdateString[]='rid_holder_name="'.$POST['rid_holder_name'].'"';
	}
	if($POST['rid_validator']=='undefined' && $POST['rid_validator_name']!='') //JFM 31_10_14
	{
		$ridUpdateString[]='rid_validator=0';
		$ridUpdateString[]='rid_validator_name="'.$POST['rid_validator_name'].'"';
	}
	
	if(!empty($ridUpdateString))
	{
		if($ridQry['rid_status']==2 || $ridQry['rid_status']==3)
		{
			$ridUpdateString[]='rid_closure=SYSDATE()';
			$POST['rid_closure']=date("y-m-d");
		}
		else
		{
			$ridUpdateString[]='rid_closure=0000-00-00';
			$POST['rid_closure']=date("y-m-d");
		}
		SqlLQ('UPDATE dr_rid SET '.implode(',',$ridUpdateString).' WHERE rid_id="'.$rid['rid_id'].'"');
	}
}
	
$reviewProfile=array();

if($POST['criteria']==0)
{
	$reviewProfile=SqlQ('SELECT r.review_profile AS review_profile_id
							FROM dr_review AS r
							WHERE r.review_id='.$POST['review_id']);
}		
else
{	
	/*
	* US #054
	* Version :2.0
	* Fixed by : Infosys Limited 
	* pie chart condittion
	*/
	$pro_id = getFilter('program','filter',0,$SESSION);
	$coe_id = getFilter('coe','filter',0,$SESSION);
	if (!empty($pro_id) && !empty($coe_id)) {
		$reviewProfile=SqlQ('SELECT rp.review_profile_id
							FROM dr_review_profile AS rp
								INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
								INNER JOIN dr_review_group AS rg ON rg.review_type=rt.review_type_id
								INNER JOIN dr_review_criterion AS rc ON rc.review_group=rg.group_id
							WHERE rc.review_criterion_id='.$POST['criteria'].'
							AND rp.program='.getFilter('program','filter',0,$SESSION).'
							AND rp.coe='.getFilter('coe','filter',0,$SESSION));
	}
}

$ridCount=array();

//JFM 09_04_14
$actionQry=mysql_query('SELECT 
							ap.ca,rp.review_profile_id,
							ac.action_id,ac.action_status,
							rd.rid_id,rd.rid_status
						FROM dr_action_applicability 		AS ap
							INNER JOIN dr_action 			AS ac ON ap.action=ac.action_id
							LEFT  JOIN dr_rid				AS rd ON ac.rid=rd.rid_id
							LEFT  JOIN dr_review_criterion 	AS cr ON ac.criteria=cr.review_criterion_id
							LEFT  JOIN dr_review_group 		AS gr ON cr.review_group=gr.group_id
							LEFT  JOIN dr_review 			AS r  ON r.review_id=ac.review
							INNER JOIN dr_review_profile	AS rp ON rp.review_type=gr.review_type
																  OR rp.review_profile_id=r.review_profile
							INNER JOIN c_cawp				AS cw ON ap.ca=cw.ca
						WHERE cw.wp="'.$POST['wp'].'"
							AND rp.review_profile_id="'.$reviewProfile['review_profile_id'].'"
							AND cw.msn="'.$POST['msn'].'"
							AND ac.msn="'.$POST['msn'].'"',$p12) or die(mysql_error());
		


while($a=mysql_fetch_assoc($actionQry)){
	$actionCount[$a['ca']][$a['action_status']]++;
	if($a['rid_status']!='')$ridBinary[$a['ca']][$a['rid_status']][$a['rid_id']]=1;
}

if(is_array($ridBinary)){
	foreach($ridBinary as $caId=>&$ridPerCa){
		$ridCount[$caId][0]=count($ridPerCa[0]);
		$ridCount[$caId][1]=count($ridPerCa[1]);
		$ridCount[$caId][2]=count($ridPerCa[2]);
		$ridCount[$caId][3]=count($ridPerCa[3]); //JFM 27_03_14
	}
}

$answer='';
$firstItem=0;

if($action){
	$actionLocation='_'.$action['action_id'];
	$action=SqlQ('SELECT a.*,
						r.rid_id,r.rid_code AS rid
					FROM dr_action AS a
						LEFT JOIN dr_rid as r ON a.rid=r.rid_id
			WHERE a.action_id="'.$action['action_id'].'"');
	generateSaveResponse($answer,$firstItem,$SESSION['table']['action']['action'],$POST,$action,$actionLocation,array('wp'));
	$answer.='&&&action_holder_'.$action['action_id'].'%%%text%%%'.$POST['action_holder_name'];
	$answer.='&&&action_validator_'.$action['action_id'].'%%%text%%%'.$POST['action_validator_name'];
}

if($rid){
	$ridLocation='_'.$action['rid_id'];
	$rid=SqlQ('SELECT * FROM dr_rid WHERE rid_id="'.$rid['rid_id'].'"');
	generateSaveResponse($answer,$firstItem,$SESSION['table']['rid']['rid'],$POST,$rid,$ridLocation);
	$answer.='&&&rid_holder_'.$action['rid_id'].'%%%text%%%'.$POST['rid_holder_name'];
}

if(is_array($actionCount)){
	foreach($actionCount as $caId=>$actionDetails){
		if($firstItem!=0)$answer.='&&&';
		else $firstItem=1;
		$answer.='review_red_action_'.$caId.'_'.$reviewProfile['review_profile_id'].'%%%action%%%'.$actionDetails[0];
		$answer.='&&&review_amber_action_'.$caId.'_'.$reviewProfile['review_profile_id'].'%%%action%%%'.$actionDetails[1];
		$answer.='&&&review_green_action_'.$caId.'_'.$reviewProfile['review_profile_id'].'%%%action%%%'.$actionDetails[2];
		$answer.='&&&review_blue_action_'.$caId.'_'.$reviewProfile['review_profile_id'].'%%%action%%%'.$actionDetails[3]; //JFM 27_03_14
	}
}

if(is_array($ridCount)){
	foreach($ridCount as $caId=>&$ridDetails){
		if($firstItem!=0)$answer.='&&&';
		else $firstItem=1;
		$answer.='review_red_rid_'.$caId.'_'.$reviewProfile['review_profile_id'].'%%%action%%%'.$ridDetails[0];
		$answer.='&&&review_amber_rid_'.$caId.'_'.$reviewProfile['review_profile_id'].'%%%action%%%'.$ridDetails[1];
		$answer.='&&&review_green_rid_'.$caId.'_'.$reviewProfile['review_profile_id'].'%%%action%%%'.$ridDetails[2];
		$answer.='&&&review_blue_rid_'.$caId.'_'.$reviewProfile['review_profile_id'].'%%%action%%%'.$ridDetails[3]; //JFM 27_03_14
	}
}


if($POST['criteria_ca'])
{
	$criteriaAction=array();
					
	if($POST['criteria']==0)
	{
		$criteriaAction=SqlQ('SELECT SUM(IF(a.action_status=0,1,0)) AS criteria_red_action,SUM(IF(a.action_status=1,1,0)) AS criteria_amber_action,SUM(IF(a.action_status=2,1,0)) AS criteria_green_action,SUM(IF(a.action_status=3,1,0)) AS criteria_blue_action
								FROM dr_review AS r
									INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
									LEFT JOIN (
										SELECT act.review,act.action_id,act.action_status
										FROM dr_action AS act 
											INNER JOIN dr_action_applicability AS app ON act.action_id=app.action
										WHERE act.msn="'.$POST['msn'].'"
											AND app.ca="'.$POST['criteria_ca'].'"
									) AS a ON r.review_id=a.review
								WHERE rp.review_profile_id="'.$reviewProfile['review_profile_id'].'"
									AND r.review_id="'.$POST['review_id'].'"
								GROUP BY r.review_id');
	}
	else
	{
		$criteriaAction=SqlQ('SELECT SUM(IF(a.action_status=0,1,0)) AS criteria_red_action,SUM(IF(a.action_status=1,1,0)) AS criteria_amber_action,SUM(IF(a.action_status=2,1,0)) AS criteria_green_action,SUM(IF(a.action_status=3,1,0)) AS criteria_blue_action
								FROM dr_review_criterion AS cr
									INNER JOIN dr_review_group AS gr ON cr.review_group=gr.group_id
									INNER JOIN dr_review_type AS rt ON rt.review_type_id=gr.review_type
									INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id
									LEFT JOIN (
										SELECT act.criteria,act.action_id,act.action_status
										FROM dr_action AS act 
											INNER JOIN dr_action_applicability AS app ON act.action_id=app.action
										WHERE act.msn="'.$POST['msn'].'"
											AND app.ca="'.$POST['criteria_ca'].'"
									) AS a ON cr.review_criterion_id=a.criteria
								WHERE rp.review_profile_id="'.$reviewProfile['review_profile_id'].'"
									AND cr.review_criterion_id="'.$POST['criteria'].'"
								GROUP BY cr.review_criterion_id');
	}		
					
	$answer.='&&&criteria_red_action_'.$POST['criteria_ca'].'_'.$POST['criteria'].'%%%action%%%'.$criteriaAction['criteria_red_action'].
				'&&&criteria_amber_action_'.$POST['criteria_ca'].'_'.$POST['criteria'].'%%%action%%%'.$criteriaAction['criteria_amber_action'].
				'&&&criteria_green_action_'.$POST['criteria_ca'].'_'.$POST['criteria'].'%%%action%%%'.$criteriaAction['criteria_green_action'].
				'&&&criteria_blue_action_'.$POST['criteria_ca'].'_'.$POST['criteria'].'%%%action%%%'.$criteriaAction['criteria_blue_action']. //JFM 27_03_14
				'&&&criteria_total_action_'.$POST['criteria_ca'].'_'.$POST['criteria'].'%%%action%%%'.($criteriaAction['criteria_red_action']+$criteriaAction['criteria_amber_action']+$criteriaAction['criteria_green_action']+$criteriaAction['criteria_blue_action']); //JFM 27_03_14
}

$answer.='&&&action_id%%%user%%%'.$action['action_id'].
			'&&&action_code%%%user%%%'.$POST['action_code'].
			'&&&formActionTitle%%%text%%%Edit Action '.$POST['action_code'];

//file_put_contents('../img/ca/data.txt', $answer); //JFM 31_10_14

echo 'OK|||'.$answer;
storeSession($SESSION);
?>