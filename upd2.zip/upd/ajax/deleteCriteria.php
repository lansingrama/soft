<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

$answer='';
if($GET['flag'] == 'toggle'){ 
    $answer = toggleIncludeAll($GET['review_profile'],$GET['group_id'],$GET['review_id'], $GET['flag']);
    
}
else{
    if($GET['review_id']=='M')
    {
            //Update the master list.
            $getReviewType=SqlQ('SELECT review_type FROM dr_review_profile WHERE review_profile_id= "'.$GET['reviewProfile'].'"');
            $included=SqlLi('SELECT 1
					FROM dr_review_master AS rm
						INNER JOIN dr_review_master_history AS rmh ON rm.review_master_id=rmh.review_master
					WHERE rm.criterion='.$GET['criteria'].'
					AND rm.review_type='.$getReviewType['review_type'].'
					AND review_master_valid_to="0000-00-00 00:00:00"');
							
            if(!empty($included))
            {
                    $getReviewMasterId=SqlQ('SELECT review_master_id FROM dr_review_master WHERE review_type="'.$getReviewType['review_type'].'" AND criterion='.$GET['criteria']);
                    SqlLQ('UPDATE dr_review_master_history SET review_master_valid_to=SYSDATE() WHERE review_master="'.$getReviewMasterId['review_master_id'].'" AND review_master_valid_to="0000-00-00 00:00:00"'); //JFM 03_12_13
		
                    $criteriaPosition=SqlLi('SELECT criterion_validity_id
										FROM dr_review_criterion_history
										WHERE criterion='.$GET['criteria'].'
										AND criterion_valid_to="0000-00-00 00:00:00"'); //JFM 30_10_14

                    $answer=$criteriaPosition[0]['criterion_validity_id'].'&&&NO';
            }
            else
            {	
                    $lastReviewMasterId=SqlQ('SELECT review_master_id AS "LAST_INSERT_ID()" FROM dr_review_master WHERE review_type="'.$getReviewType['review_type'].'" AND criterion='.$GET['criteria']); //JFM 03_12_13
                    if(empty($lastReviewMasterId))
                    {
                            SqlLQ('INSERT INTO dr_review_master (review_type, criterion) VALUES ("'.$getReviewType['review_type'].'","'.$GET['criteria'].'")');
                            $lastReviewMasterId=SqlQ('SELECT LAST_INSERT_ID()');
                    }
                    SqlLQ('INSERT INTO dr_review_master_history (review_master,  review_master_valid_from) VALUES ("'.$lastReviewMasterId['LAST_INSERT_ID()'].'",SYSDATE())');
		
                    $criteriaPosition=SqlLi('SELECT criterion_validity_id
										FROM dr_review_criterion_history
										WHERE criterion='.$GET['criteria'].'
										AND criterion_valid_to="0000-00-00 00:00:00"'); //JFM 30_10_14

                    $answer=$criteriaPosition[0]['criterion_validity_id'].'&&&YES';
            }
    }
    else
    {
            if($GET['delete']==1) //Removed from main review panel.
            {
                    SqlLQ('DELETE FROM dr_review_configuration WHERE review="'.$GET['review_id'].'" AND criterion='.$GET['criteria']);
                    $answer='criteriaRow-'.$GET['review_group'].'-'.$GET['criteria'];
            }
            else if($GET['delete']==2) //Toggled from catalogue.
            {
                    $included=SqlLi('SELECT 1
						FROM dr_review_configuration
						WHERE criterion='.$GET['criteria'].'
						AND review='.$GET['review_id']);
								
                    if(!empty($included))
                    {
                            $criteriaPosition=SqlLi('SELECT criterion_validity_id
										FROM dr_review_criterion_history
										WHERE criterion='.$GET['criteria'].'
										AND criterion_valid_to="0000-00-00 00:00:00"'); //JFM 30_10_14

                            SqlLQ('DELETE FROM dr_review_configuration WHERE review="'.$GET['review_id'].'" AND criterion='.$GET['criteria']);
                            $answer=$criteriaPosition[0]['criterion_validity_id'].'&&&NO'; //JFM 30_10_14
                    }
                    else
                    {
                            $criteriaPosition=SqlLi('SELECT criterion_position, criterion_validity_id
										FROM dr_review_criterion_history
										WHERE criterion='.$GET['criteria'].'
										AND criterion_valid_to="0000-00-00 00:00:00"');
                       
                            SqlLQ('INSERT INTO dr_review_configuration (review, criterion, position, disabled) VALUES ("'.$GET['review_id'].'","'.$GET['criteria'].'","'.$criteriaPosition[0]['criterion_position'].'",0)');
                            $answer=$criteriaPosition[0]['criterion_validity_id'].'&&&YES'; //JFM 30_10_14
                    }
            }
            //JFM 11_03_14
            else if($GET['delete']==3) //Move criteria up from main review panel.
            {
                    $oldPosition=SqlQ('SELECT position FROM dr_review_configuration WHERE review="'.$GET['review_id'].'" AND criterion='.$GET['criteria']);
                    if($oldPosition['position']==$GET['positionAbove']) $oldPosition['position'] = $oldPosition['position']+1;
                    SqlLQ('UPDATE dr_review_configuration SET position='.$GET['positionAbove'].' WHERE review="'.$GET['review_id'].'" AND criterion='.$GET['criteria']);
                    SqlLQ('UPDATE dr_review_configuration SET position='.$oldPosition['position'].' WHERE review="'.$GET['review_id'].'" AND criterion='.$GET['previousCriteria']);
            }
            else //Set at N/A from main review panel.
            {
                    $disabledState=SqlQ('SELECT disabled FROM dr_review_configuration WHERE review="'.$GET['review_id'].'" AND criterion='.$GET['criteria']);
		
                    if($disabledState['disabled']) SqlLQ('UPDATE dr_review_configuration SET disabled=0 WHERE review="'.$GET['review_id'].'" AND criterion='.$GET['criteria']);
                    else SqlLQ('UPDATE dr_review_configuration SET disabled=1 WHERE review="'.$GET['review_id'].'" AND criterion='.$GET['criteria']);
            }
    }
}

/*if($GET['table_cache_id']) 
{
	removeCache($GET['table_cache_id']);
	unset($SESSION['table_result_count'][$GET['table_cache_id']]);
}*/

//JFM 28_10_13
/*if(checkPermission('dr_review_profile_general','delete',0,'check',$SESSION)==1 && $GET['group']!='' && $GET['group']!=0){
	$reviewId=SqlQ('SELECT review_profile FROM dr_review_group WHERE review_group_id="'.$GET['group'].'"');
	$GET['review']=$reviewId['review_profile'];
	
	if($GET['criteria']==0 || $GET['criteria']==''){
		$criteria=SqlSLi('SELECT review_criteria_id FROM dr_review_criteria WHERE review_group="'.$GET['group'].'"','review_criteria_id');
		$GET['criteria']=implode('","',$criteria);
		SqlLQ('DELETE FROM dr_review_group WHERE review_group_id="'.$GET['group'].'"');
	}
	SqlLQ('DELETE FROM dr_criteria_status WHERE review_criteria IN ("'.$GET['criteria'].'")');
	
	$action=SqlSLi('SELECT action_id FROM dr_action WHERE criteria IN ("'.$GET['criteria'].'")','action_id');
	if(count($action)>0){
		SqlLQ('DELETE FROM dr_action_applicability WHERE action IN ("'.implode('","',$action).'")');
		SqlLQ('DELETE FROM dr_action WHERE criteria IN ("'.$GET['criteria'].'")');
	}
	SqlLQ('DELETE FROM dr_review_criteria WHERE review_criteria_id IN ("'.$GET['criteria'].'")');


	require_once('criteriaList.php');
}*/

/**
 * Function to toggle include all criteria
 * @param String $reviewProfile
 * @param String $groupId
 * @param String $reviewId
 * @param String $flag
 */
function toggleIncludeAll($reviewProfile,$groupId,$reviewId, $flag) {
    
    $query = 'SELECT  rch.criterion, rch.criterion_user_id';

    $query .= ' FROM dr_review_criterion_history AS rch
							INNER JOIN dr_review_criterion 					AS rc	ON	rc.review_criterion_id=rch.criterion
							INNER JOIN dr_review_group 						AS rg	ON	rg.group_id=rc.review_group
							INNER JOIN dr_review_profile					AS rp	ON	rp.review_type=rg.review_type
							LEFT  JOIN dr_criterion_group 					AS cg	ON	rc.criterion_group=cg.criterion_group_id
							LEFT  JOIN dr_review_criterion_applicability	AS rca	ON	rc.review_criterion_id=rca.criterion';




    if ($reviewId)
        $query .= ' LEFT  JOIN (
                    SELECT * FROM dr_review_master AS rm 
                                INNER JOIN dr_review_master_history AS rmh 	ON rm.review_master_id=rmh.review_master
                                                                                                                        AND rmh.review_master_valid_to="0000-00-00 00:00:00"
                )
                AS rm	ON	rm.review_type=rp.review_type
                                AND rm.criterion=rc.review_criterion_id';

    $query .= ' WHERE rch.criterion_valid_to="0000-00-00 00:00:00"';

    if (!empty($reviewProfile)) {
        /**
         * Fix for : Bug-7
         * Version :4.2
         * Fixed by : Infosys Limited 
         * Criteria group and criteria id  in Master list management display in lexicon sorted
         */
        if (!empty($groupId))
            $query .= ' AND review_profile_id=' . $reviewProfile . ' AND group_id=' . $groupId . ' GROUP BY rch.criterion_validity_id ORDER BY rch.criterion_user_id ASC';
        else
            $query .= ' AND review_profile_id=' . $reviewProfile . ' GROUP BY rch.criterion_validity_id ORDER BY rch.criterion_user_id ASC';
    }
    else {
        $query = $query . ' GROUP BY rch.criterion_validity_id ORDER BY rch.criterion_user_id ASC';
    }
    $rawData = SqlLi($query);
    $cirterionList = array();
    foreach ($rawData as $column => $value) {
        array_push($cirterionList, $value['criterion']);
    }
    $answerTmp = array();
    if($reviewId == 'M') { 
        for ($i = 0; $i < count($cirterionList); $i++) {
            //var_dump($reviewProfile);exit;
            $getReviewType = SqlQ('SELECT review_type FROM dr_review_profile WHERE review_profile_id= "' . $reviewProfile . '"');
            //154
            $included = SqlLi('SELECT 1
					FROM dr_review_master AS rm
						INNER JOIN dr_review_master_history AS rmh ON rm.review_master_id=rmh.review_master
					WHERE rm.criterion=' . $cirterionList[$i] . '
					AND rm.review_type=' . $getReviewType['review_type'] . '
					AND review_master_valid_to="0000-00-00 00:00:00"');


            if (!empty($included)) { 

                $getReviewMasterId = SqlQ('SELECT review_master_id FROM dr_review_master WHERE review_type="' . $getReviewType['review_type'] . '" AND criterion=' . $cirterionList[$i]);
                SqlLQ('UPDATE dr_review_master_history SET review_master_valid_to=SYSDATE() WHERE review_master="' . $getReviewMasterId['review_master_id'] . '" AND review_master_valid_to="0000-00-00 00:00:00"'); //JFM 03_12_13

                $criteriaPosition = SqlLi('SELECT criterion_validity_id
										FROM dr_review_criterion_history
										WHERE criterion=' . $cirterionList[$i] . '
										AND criterion_valid_to="0000-00-00 00:00:00"'); //JFM 30_10_14

                $answer = $criteriaPosition[0]['criterion_validity_id'] . '&&&NO';
                //var_dump($answer);
                $answerTmp[] = $answer;
            } else {
                //var_dump("not included");
                $lastReviewMasterId = SqlQ('SELECT review_master_id AS "LAST_INSERT_ID()" FROM dr_review_master WHERE review_type="' . $getReviewType['review_type'] . '" AND criterion=' . $cirterionList[$i]); //JFM 03_12_13
                if (empty($lastReviewMasterId)) {
                    SqlLQ('INSERT INTO dr_review_master (review_type, criterion) VALUES ("' . $getReviewType['review_type'] . '","' . $cirterionList[$i] . '")');
                    $lastReviewMasterId = SqlQ('SELECT LAST_INSERT_ID()');
                }
                SqlLQ('INSERT INTO dr_review_master_history (review_master,  review_master_valid_from) VALUES ("' . $lastReviewMasterId['LAST_INSERT_ID()'] . '",SYSDATE())');

                $criteriaPosition = SqlLi('SELECT criterion_validity_id
										FROM dr_review_criterion_history
										WHERE criterion=' . $cirterionList[$i] . '
										AND criterion_valid_to="0000-00-00 00:00:00"'); //JFM 30_10_14

                $answer = $criteriaPosition[0]['criterion_validity_id'] . '&&&YES';
                //var_dump($answer);
                 $answerTmp[] = $answer;
            }
        }
    }
    return implode(",", $answerTmp);
}

echo 'OK|||'.$answer;
storeSession($SESSION);
?>