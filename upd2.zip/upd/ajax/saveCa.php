<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST);

$POST['progress_trend'] = $POST['progress_trend'].'_'.$POST['progress_trend_colour'];

$caArr=explode(',',$POST['ca']);

$caTable = $SESSION['table']['review_planning']['ca'];

//JFM 08_06_16
$caTable['assembly']['table']='dr_ca_status';
$caTable['assembly']['type']='date';
$caTable['kodd']['table']='dr_ca_status';
$caTable['kodd']['type']='date';
$caTable['odd']['table']='dr_ca_status';
$caTable['odd']['type']='date';
$caTable['id']['table']='dr_ca_status';
$caTable['id']['type']='date';
$caTable['assembly_done']['table']='dr_ca_status';
$caTable['assembly_done']['type']='boolean';
$caTable['kodd_done']['table']='dr_ca_status';
$caTable['kodd_done']['type']='boolean';
$caTable['sourcing']['table']='dr_ca_status';
$caTable['sourcing']['type']='text';

$qry=formToQuery($POST,$caTable,$SESSION);

$caStatusMlt=SqlAsLi('SELECT ca.ca_id,ca.perimeter,ca.ca_description,ca.caa,
								wp.wp_id,wp.wp_description,
								st.ca_status_id,st.assembly,st.assembly_done,st.kodd,st.kodd_done, st.odd, st.id, st.progress_trend, st.sourcing
							FROM c_ca AS ca
								INNER JOIN c_cawp AS cw ON ca.ca_id=cw.ca
								INNER JOIN c_wp AS wp ON cw.wp=wp.wp_id
								INNER JOIN dr_ca_status AS st ON ca.ca_id=st.ca
							WHERE ca.ca_id IN('.$POST['ca'].')
								AND cw.msn="'.getFilter('msn','filter',0,$SESSION).'"
								AND st.msn="'.getFilter('msn','filter',0,$SESSION).'"','ca_id');

if(is_array($caStatusMlt))
{
	foreach($caStatusMlt as $caStatusCa=>&$caStatusDetails)
	{
		$existingCa[]=$caStatusCa;
		$caStatusId[$caStatusCa]=$caStatusDetails['ca_status_id'];
	}
}

foreach($caArr as &$c)
{
	if(!is_array($existingCa) || !in_array($c,$existingCa))
	{ //JFM 13_12_13
		SqlLQ('INSERT INTO dr_ca_status (ca,msn) VALUES ("'.$c.'","'.getFilter('msn','filter',0,$SESSION).'")');
		$caStatus=SqlQ('SELECT ca_status_id,assembly,assembly_done,kodd,kodd_done FROM dr_ca_status WHERE ca="'.$c.'" AND msn="'.getFilter('msn','filter',0,$SESSION).'"');
	}
	else $caStatus['ca_status_id']=$caStatusId[$c];

	$updateArray=getFormUpdate($qry,$caStatusMlt[$c],'review_planning','ca',$c,$SESSION,array('ca','wp','perimeter','ca_description','wp_description','caa'));
	if(!empty($updateArray))
	{
		SqlLQ('UPDATE dr_ca_status SET '.implode(',',$updateArray).' WHERE ca_status_id="'.$caStatus['ca_status_id'].'"');
	}

	$updateArray=getFormUpdate($qry,$caStatusMlt[$c],'review_planning','ca',$c,$SESSION,array('ca','wp','wp_description','assembly','assembly_done','fai','kodd','kodd_done','odd','id','progress_trend','sourcing'),array('perimeter'=>'id'));
	if(!empty($updateArray))
	{
		SqlLQ('UPDATE c_ca SET '.implode(',',$updateArray).' WHERE ca_id="'.$c.'"');
	}
	$updateArray=getFormUpdate($qry,$caStatusMlt[$c],'review_planning','ca',$c,$SESSION,array('ca','wp','perimeter','ca_description','assembly','assembly_done','fai','kodd_done','kodd','caa','odd','id','progress_trend','sourcing'));
	if(!empty($updateArray))
	{
		SqlLQ('UPDATE c_wp SET '.implode(',',$updateArray).' WHERE wp_id="'.$caStatusMlt[$c]['wp_id'].'"');
	}
}


if($POST['wp_description']!='mixed') SqlLQ('UPDATE c_wp SET wp_description="'.$POST['wp_description'].'" WHERE wp_id IN('.$POST['wp'].')');

$caStatus=SqlLi('SELECT c.ca_id,c.ca,c.ca_description,c.caa,c.ca_image_file,s.assembly,s.assembly_done,s.kodd,s.kodd_done,p.perimeter_id,p.perimeter,w.wp_id,w.wp,w.wp_description, s.odd, s.id, s.progress_trend
				FROM c_ca 					AS c
					INNER JOIN dr_ca_status AS s  ON c.ca_id=s.ca
					INNER JOIN c_perimeter 	AS p  ON c.perimeter=p.perimeter_id
					INNER JOIN c_cawp 		AS cw ON c.ca_id=cw.ca
					INNER JOIN c_wp 		AS w  ON cw.wp=w.wp_id
				WHERE c.ca_id IN ('.$POST['ca'].')
					AND s.msn="'.getFilter('msn','filter',0,$SESSION).'"
					AND cw.msn="'.getFilter('msn','filter',0,$SESSION).'"');


$answer='';

if($caStatus)
{
	$firstItem=0;
	foreach($caStatus as &$c)
	{
		$addLocation='_'.$c['ca_id'];
		generateSaveResponse($answer,$firstItem,$caTable,$POST,$c,$addLocation,array('ca','wp'));
	}
}

echo 'OK|||'.$answer;
storeSession($SESSION);
?>