<?php
if($included!=1){
	require_once('../support/header.php');
	require_once('../security/checkExpiredSession.php');
}
require_once('../support/revMan.php');

foreach($SESSION['table']['action']['action'] as $columnName=>$columnDetails){
	$SESSION['filter'][$SESSION['object'][$columnName]]=$SESSION['filter'][$SESSION['object'][$columnName]][$SESSION['user_action']['hide']];
}
//JFM TODO - CRIT
$actionQry=mysql_query('SELECT ac.action_id,ac.msn,ac.criteria,ac.action_code,ac.action_description,ac.action_remark,ac.action_creation,ac.action_completion,ac.action_status,ac.action_holder,ac.action_holder_name,ac.action_validator,ac.action_validator_name,
					GROUP_CONCAT(ca.ca ORDER BY ca.ca ASC SEPARATOR ", "),
					rd.rid_code,
					CONCAT(u1.surname,", ",u1.name) AS action_holder_txt,CONCAT(u2.surname,", ",u2.name) AS action_validator_txt
				FROM dr_action							AS ac
					INNER JOIN dr_action_applicability	AS ap ON ap.action=ac.action_id
					INNER JOIN c_ca						AS ca ON ap.ca=ca.ca_id
					INNER JOIN dr_review_criteria		AS cr ON ac.criteria=cr.review_criteria_id
					INNER JOIN dr_review_group			AS gr ON cr.review_group=gr.review_group_id
					LEFT JOIN dr_rid					AS rd ON ac.rid=rd.rid_id
					LEFT JOIN c_user					AS u1 ON ac.action_holder=u1.user_id
					LEFT JOIN c_user					AS u2 ON ac.action_validator=u2.user_id
				GROUP BY ac.action_id',$p12) or die(mysql_error());

while($a=mysql_fetch_assoc($actionQry)){
	foreach($a as $k=>$v){
		$action[$a['action_id']][$k]=$v;
	}
	
}
?>