<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

SqlLQ('DELETE FROM dr_user_filter WHERE object='.$SESSION['object']['last_login'].' AND user='.$SESSION['user']['user_id']);

echo 'OK|||';

storeSession($SESSION);

?>