<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes(utf8_decode($v));
$permissionObject=array(
	'program'=>		'c_program_general',
	'coe'=>			'c_coe_general',
	'perimeter'=>	'c_perimeter_general',
	'msn'=>			'c_msn_general',
	'cawp'=>		'c_ca_general',
	'responsible'=>	'dr_responsible_configuration_general'
);
if(checkPermission($permissionObject[$GET['objectTxt']],'delete',0,'check',$SESSION)==1){
	switch($GET['objectTxt']){
		case 'program':
			
		break;
		case 'coe':
			
		break;
		case 'perimeter':
			
		break;
		case 'msn':
			
		break;
		case 'cawp':
			
		break;
		case 'responsible':
			
		break;
	}
}else echo 'no_rights';
storeSession($SESSION);
?>