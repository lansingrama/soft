<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

$ca=SqlLi('SELECT w.wp,c.ca_id,c.ca
			FROM c_wp AS w
				INNER JOIN c_cawp AS cw ON w.wp_id=cw.wp
				INNER JOIN c_ca AS c ON cw.ca=c.ca_id
			WHERE w.wp_id="'.$GET['wp'].'"
				AND cw.msn="'.getFilter('msn','filter',0,$SESSION).'"');

$answer='';
if(is_array($ca)){
	foreach($ca as $c){
		if($answer!=''){
			?>&&&<?php
		}else{
			?>OK|||<?php
		}
		?>action_applicability_table%%%row%%%<?php
		?><table><?php
			?><tr class="infoRow"><?php
				?><td class="chkList"><input id="applicable_ca_<?=$c['ca_id']?>"name="applicable_ca_<?=$c['ca_id']?>"type="checkbox"></td><?php
				?><td><?=$c['wp']?></td><?php
				?><td><?=$c['ca']?></td><?php
			?></tr><?php
		?></table><?php
	}
}
storeSession($SESSION);
?>