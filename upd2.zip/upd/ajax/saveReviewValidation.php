<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST);

//print_r($POST);

//
// If forcing review validation.
//
if($POST['force'] == 1)
{
	$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id']; //JFM 12_01_16

	$chID=$POST['reviewID'];

	SqlLQ('DELETE FROM dr_validation_loop_structure WHERE object=(SELECT object_id FROM c_object WHERE object="review_id") AND applicability="'.$chID.'"');

	if($POST['forceComments']=='')
	{
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
					VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$chID.'",'.$viewAsUserId.',0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="validated"),SYSDATE())');
	}
	else
	{
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on, validator_comment) 
					VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$chID.'",'.$viewAsUserId.',0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="validated"),SYSDATE(),"'.$POST['forceComments'].'")');
	}

	SqlLQ('UPDATE dr_review  
			SET validation_date=SYSDATE(),
				validation_complete=2
			WHERE review_id='.$chID);
}

//
// If cancelling review validation.
//
else if($POST['cancel'] == 1)
{
	SqlLQ('DELETE FROM dr_review_configuration
			WHERE review='.$POST['reviewID']);
	
	//JFM 18_03_14
	//SqlLQ('DELETE FROM dr_review
	//		WHERE review_id='.$POST['reviewID']);
		
	//JFM 18_03_14
	//SqlLQ('DELETE FROM dr_review_applicability
	//		WHERE review='.$POST['reviewID']);

	//JFM 18_03_14 - JFM 19_07_16
	SqlLQ('UPDATE dr_review
			SET validation_complete=-1, inherited = 0
			WHERE review_id='.$POST['reviewID']);
			
	SqlLQ('UPDATE dr_validation_loop
			SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="cancelled"),
			action_taken_on=SYSDATE()
			WHERE validation_loop_id='.$POST['maxValidationLoopID']);
}

else if($POST['makeApplicable'] == 1)  //JFM 02_10_14
{
	//JFM 19_07_16
	$validationComplete=SqlQ('SELECT review_status, validation_complete FROM dr_review WHERE review_id ='.$POST['reviewID']);

	if($validationComplete['validation_complete'] == 2)
	{
		SqlLQ('UPDATE dr_review SET review_status=4, validation_complete=-2	WHERE review_id='.$POST['reviewID']);
	}
	else if($validationComplete['validation_complete'] == -2)
	{
		SqlLQ('UPDATE dr_review SET review_status=0, validation_complete=2 WHERE review_id='.$POST['reviewID']);
	}
	else
	{	
		SqlLQ('UPDATE dr_review
			SET validation_complete=-1,
			review_status=0,
			remark=""
			WHERE review_id='.$POST['reviewID']);
	}
}

else
{
	$validationArray=array();
	
	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundValidation=strpos($arrayName,"elephantTigerBeehive");
		if($foundValidation===0 && $arrayValue!='') array_push($validationArray,$arrayValue);
	}
	
	$chID=$POST['reviewID'];

	if($POST['modify']!=1)
	{		
		SqlLQ('DELETE FROM dr_validation_loop_structure WHERE object=(SELECT object_id FROM c_object WHERE object="review_id") AND applicability="'.$chID.'"'); //JFM 18_03_14

		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$chID.'","'.$SESSION['user']['user_id'].'",0)');
				
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
				VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$chID.'","'.$SESSION['user']['user_id'].'",0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="originated"),SYSDATE())');				
	}
	else //JFM 03_12_13
	{		
		SqlLQ('DELETE FROM dr_validation_loop_structure WHERE object=(SELECT object_id FROM c_object WHERE object="review_id") AND applicability="'.$chID.'"');
		
		SqlLQ('UPDATE dr_validation_loop
				SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="modified"),
				action_taken_on=SYSDATE()
				WHERE object=(SELECT object_id FROM c_object WHERE object="review_id")
				AND applicability="'.$chID.'"
				AND validator='.$SESSION['user']['user_id'].'
				AND action_taken=0');
		
		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$chID.'","'.$SESSION['user']['user_id'].'",0)');
	}
	
	$i=1;

	$fullName='';
	$email='';
			
	foreach($validationArray as $validationUsed)
	{
		$nameSplit=explode(", ",$validationUsed);

		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$chID.'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.')');
		
		if($i==1)
		{
			SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
					VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$chID.'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.',SYSDATE())');
			
			$fullName=$nameSplit[1].' '.$nameSplit[0];
			$email=SqlQ('SELECT email, allow_emails FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"');
		}
				
		$i++;
	}

	SqlLQ('UPDATE dr_review SET validation_complete=1 WHERE review_id='.$POST['reviewID']);

	$reviewInfo=SqlLi('SELECT rt.review_type, ca.ca, coe.coe, p.program
						FROM dr_review_type AS rt
							INNER JOIN dr_review_profile AS rp ON rp.review_type=rt.review_type_id
							INNER JOIN dr_review AS r ON r.review_profile=rp.review_profile_id
							INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id
							INNER JOIN c_ca AS ca ON ca.ca_id=ra.ca
							INNER JOIN c_program AS p ON p.program_id=rp.program
							INNER JOIN c_coe AS coe ON coe.coe_id=rp.coe
						WHERE review_id ='.$POST['reviewID']);

	$caString='';
	$caStringShort='';
	foreach($reviewInfo as $l=>$m) $caString=$caString.$m['ca'].',';
	$caString=rtrim($caString, ",");

	$headers="MIME-Version: 1.0\r\n";
	$headers.="Content-type: text/html; charset=utf-8\r\n";
	$headers.="From: Airbus No Reply <noreply@airbus.com>\r\n"; 
	$headers.="Reply-To: noreply@airbus.com\r\n"; 
	$headers.="Return-path: noreply@airbus.com\r\n";
	$headers.="Cc: \r\n";
	$headers.="Bcc: \r\n";

	$mailBody='
	<html>
	<head>
		<title>Review Validation</title>
	</head>
	<body style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px">
		<div style="width: 100%; height: 300px; cellSpacing=0; cellPadding=5; border=0;">
		<table align="center">
		  <tr>
			<td style="background-color:#6f95ab;color:#FFFFFF;font-family:Verdana,Arial,Helvetica,sans-serif;font-size:11px;font-weight:normal;padding-left:10px;">
				Review Checklist Validation
			</td>	
		</tr>
		<tr>
			<td style="border-width:0px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; padding-left:10px;">
				<strong>Dear '.$fullName.',</strong><br>
				<p>
				This is an automatic email to inform you a review checklist requires your validation.<br><br>
				This review checklist is a <strong>'.$reviewInfo[0]['program'].' - '.$reviewInfo[0]['coe'].' - '.$reviewInfo[0]['review_type'].' for CA(s) - '.$caString.'</strong> 
				</p>
				Click the link below to login and validate the review checklist:<br>
				<a http://art-int.eu.airbus.corp/1V55">
				http://art-int.eu.airbus.corp/1V55</a><br><br>
				Please, do not reply to this message.<br>
				<br><br><br>
				Best regards,<br><br>
				Airbus Review Tool Team.
			</td>
		  </tr>
		</table>
	</div>
	</body>
	</html>';
	
	if($email['allow_emails']!=1) mail($email['email'],'Airbus Review Tool - Review Checklist Validation',$mailBody,$headers);
}


//
// If editing an existing review.
//
/*else if($POST['modify']==1)
{
	$validationLoopStructure=SqlLi('SELECT * FROM dr_validation_loop_structure WHERE applicability='.$POST['reviewID'].' AND object=(SELECT object_id FROM c_object WHERE object="review_id") ORDER BY validation_loop_structure_step ASC');
		
	SqlLQ('UPDATE dr_validation_loop
			SET action_taken=(SELECT user_action_id FROM c_user_action WHERE user_action="modified"),
			action_taken_on=SYSDATE(),
			validator_comment="Modified."
			WHERE validation_loop_id='.$POST['maxValidationLoopID']);
	
	if(!empty($validationLoopStructure[1]['validation_loop_structure_step']))
	{
		$q=1;
		
		foreach($validationLoopStructure as $k=>$v)
		{
			if($validationLoopStructure[$q]['validator_removed']!=1)
			{
				break;
			}
			else
			{
				$q++;
			}
		}
		
		SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
				VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$POST['reviewID'].'",'.$validationLoopStructure[$q]['validator'].','.$validationLoopStructure[$q]['validation_loop_structure_step'].',SYSDATE())');
	
	}
}

//
// If defining a brand new review.
//
else
{
	//
	// Add all entered names into the validation loop.
	// -------------------------------------------------------------------------------------------------------------------------------------------------------
	
	$validationArray=array();

	foreach ($POST as $arrayName=>$arrayValue)
	{
		$foundValidation=strpos($arrayName,"elephantTigerBeehive");
		if($foundValidation===0 && $arrayValue!='') array_push($validationArray,$arrayValue);
	}

	SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
			VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$POST['reviewID'].'","'.$SESSION['user']['user_id'].'",0)');
			
	SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on, action_taken, action_taken_on) 
			VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$POST['reviewID'].'","'.$SESSION['user']['user_id'].'",0,SYSDATE(),(SELECT user_action_id FROM c_user_action WHERE user_action="originated"),SYSDATE())');

	SqlLQ('UPDATE dr_review SET validation_complete=1 WHERE review_id='.$POST['reviewID']);
			
	$i=1;
			
	foreach($validationArray as $validationUsed)
	{
		$nameSplit=explode(", ",$validationUsed);

		SqlLQ('INSERT INTO dr_validation_loop_structure (object, applicability, validator, validation_loop_structure_step) 
				VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$POST['reviewID'].'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.')');
		
		if($i==1)
		{
			SqlLQ('INSERT INTO dr_validation_loop (object, applicability, validator, validation_loop_step, received_on) 
					VALUES ((SELECT object_id FROM c_object WHERE object="review_id"),"'.$POST['reviewID'].'",(SELECT user_id FROM c_user WHERE name="'.$nameSplit[1].'" AND surname="'.$nameSplit[0].'"),'.$i.',SYSDATE())');
		}
				
		$i++;
	}
}*/

echo 'OK|||';
storeSession($SESSION);
?>