<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');

foreach($_GET as $k=>$v){
	$GET[$k]=addslashes($v);
}

if($GET['program']==''){
	$GET['program']=getFilter('program','filter',0,$SESSION);
}

if($GET['coe']==''){
	$GET['coe']=getFilter('coe','filter',0,$SESSION);
}

$doNotHide = array('criteria_status','review_status','review_red_action','review_amber_action','review_green_action','review_blue_action',
					'review_red_rid','review_amber_rid','review_green_rid','review_blue_rid');

foreach($SESSION['table']['review_planning']['review'] as $columnName=>$columnDetails)
{
	if(!in_array($columnName, $doNotHide) && $GET['expand_criteria']!=1 && $GET['hide']==1)
	{
		modifyFilter($columnName,'hide',$GET['review'],$GET['hide'],$SESSION,1);
	}
	else if($columnName!='criteria_status' && ($GET['expand_criteria']!=1 && $GET['hide']==0))
	{
		modifyFilter($columnName,'hide',$GET['review'],$GET['hide'],$SESSION,1);
	}
}

echo 'OK|||';

storeSession($SESSION);
/*?>OK|||<?php */?>