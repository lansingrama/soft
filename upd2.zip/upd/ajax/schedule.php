<?php
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

$POST=cleanArray($_POST);
$reviewTypesSession=getFilter('review_type_filter','filter',0,$SESSION);

if(!getFilter('area','filter',0,$SESSION) || !getFilter('program','filter',0,$SESSION) || !getFilter('msn','filter',0,$SESSION) || !getFilter('coe','filter',0,$SESSION))
{
	?>OK|||no_program_coe_msn<?php
}
else
{
	$reviewTypesAllowed=allowedSimpleObject('review_profile','review_type',$SESSION,'dr_','program='.getFilter('program','filter',0,$SESSION).' AND coe='.getFilter('coe','filter',0,$SESSION));
	$perimetersAllowed =allowedSimpleObject('perimeter','perimeter',$SESSION,'c_','program='.getFilter('program','filter',0,$SESSION));

	if(!empty($reviewTypesAllowed) && !empty($perimetersAllowed))
	{
                // Added review_type_hidden flag to check if the Level is active - US#110
		$reviewTypeQry=SqlLi('SELECT DISTINCT rt.review_type_id, rt.review_type
								FROM dr_review_type				AS rt
								INNER JOIN dr_review_profile	AS rp 	ON  rp.review_type=rt.review_type_id
								INNER JOIN c_perimeter			AS pe 	ON 	pe.program=rp.program
								WHERE rt.area='.getFilter('area','filter',0,$SESSION).'
								AND rp.program='.getFilter('program','filter',0,$SESSION).'
								AND rp.coe='.getFilter('coe','filter',0,$SESSION).'
								AND rt.review_type_id IN ('.implode(',', $reviewTypesAllowed).')
								AND pe.perimeter IN ("'.implode('","', $perimetersAllowed).'")
                                                                AND rt.review_type_hidden=0
								ORDER BY rt.review_type ASC');

		$numberOfReviews=count($reviewTypeQry);

		if(!empty($reviewTypesSession))
		{
			$reviewTypesSession=rtrim($reviewTypesSession, ',');
			$reviewTypeAsArray=explode(',', $reviewTypesSession);

			$months=array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
			$quaters=array('Q1','Q2','Q3','Q4');
			$databaseDates=array('planned','review_date');
			$caWpCompiledQry=array();
			$caInfoInANiceArraySoSidebarWorksCorrectly=array();
			$includedYears=array();
			$bgColor='#E5E5E5';
			$maxYear=0;
			//JFM 19_07_16
			$caFilter  = $SESSION['filter'][$SESSION['object']['ca']][$SESSION['user_action']['filter']][0];
			$wpFilter  = $SESSION['filter'][$SESSION['object']['wp']][$SESSION['user_action']['filter']][0];
			$perFilter = $SESSION['filter'][$SESSION['object']['perimeter']][$SESSION['user_action']['filter']][0];

			$where = "";

			//JFM 19_07_16
			if(!empty($caFilter))
				$where.="AND c.ca LIKE '%".$caFilter."%' ";
			if(!empty($wpFilter))
				$where.="AND w.wp LIKE '%".$wpFilter."%' ";
			if(!empty($perFilter))
				$where.="AND prm.perimeter LIKE '%".$perFilter."%' ";


			$caWpQry=SqlLi('SELECT DISTINCT c.ca_id,
											c.ca,
											prm.perimeter_id,
											cw.cawp_id,cw.cawp_disabled AS element_disabled,
											w.wp_id, w.wp, 
											r.planned, 
											r.review_date,
											r.review_done,
											r.review_status,
											rp.review_profile_id
								FROM c_ca 							AS c
								INNER JOIN c_perimeter				AS prm	ON  c.perimeter=prm.perimeter_id
								INNER JOIN c_cawp					AS cw	ON  c.ca_id=cw.ca
								INNER JOIN c_wp						AS w	ON  cw.wp=w.wp_id
								INNER JOIN c_program				AS pro 	ON  pro.program_id=c.program
								INNER JOIN dr_review_profile 		AS rp 	ON  rp.program=c.program
																			AND rp.coe=c.coe
								INNER JOIN dr_review_type 			AS rt 	ON  rt.review_type_id=rp.review_type
																			AND rt.area=pro.area
								LEFT  JOIN dr_review_applicability	AS ra 	ON  ra.ca=c.ca_id
								LEFT  JOIN dr_review 				AS r 	ON  r.review_id=ra.review
																			AND r.review_profile=rp.review_profile_id
																			AND r.msn=cw.msn
							WHERE pro.area='.getFilter('area','filter',0,$SESSION).'
							AND c.program='.getFilter('program','filter',0,$SESSION).'
							AND c.coe='.getFilter('coe','filter',0,$SESSION).'
							AND cw.msn='.getFilter('msn','filter',0,$SESSION).'
							AND rt.review_type_id IN ('.$reviewTypesSession.')
							AND cw.cawp_disabled=0
                                                        AND rt.review_type_hidden=0
							'.$where.'
							ORDER BY w.wp ASC, r.review_date ASC, r.planned ASC');


			if(is_array($caWpQry))
			{		
				foreach($caWpQry as $caWpcolumnName=>$caWpcolumnContents)
				{
					foreach ($databaseDates as $dateColumn) 
					{
						if(empty($caWpcolumnContents[$dateColumn]) || $caWpcolumnContents[$dateColumn]=='0000-00-00') $caWpcolumnContents[$dateColumn]='Not Set';
						else 
						{
							$currentYear=substr($caWpcolumnContents[$dateColumn], 0,4);
							if($maxYear < $currentYear) $maxYear=$currentYear;
							if(!in_array($currentYear, $includedYears)) array_push($includedYears, $currentYear);
						}
					}

					$caWpCompiledQry[$caWpcolumnContents['wp_id'].'___'.$caWpcolumnContents['wp']][$caWpcolumnContents['ca_id'].'___'.$caWpcolumnContents['ca']]=$caWpcolumnContents;
					$caInfoInANiceArraySoSidebarWorksCorrectly[$caWpcolumnContents['ca_id']]=array('ca_id'=>$caWpcolumnContents['ca_id'],'ca'=>$caWpcolumnContents['wp'].' - '.$caWpcolumnContents['ca']);
				}

				$tableCacheId=newTableCacheId($SESSION);
					
				storeCache('csv',$tableCacheId,$caInfoInANiceArraySoSidebarWorksCorrectly);
			}

			asort($includedYears);
		}
	}

	?>OK|||trl&&&<?php

	?><span style="text-align:left; float:left; padding-bottom:10px;">*Note: filters applied on the <i>Main Table</i> tab are also applied to the schedule.</span><?php

	if(!empty($reviewTypesSession) && !empty($reviewTypesAllowed) && !empty($perimetersAllowed))
	{
		?><table id="trl_table_<?=$item?>" class="criteriaTable" cellspacing="0" cellpadding="5"><?php
			?><tr class="tableGroup"><?php
				?><td colspan="1" rowspan="2" style="text-align:center;"><?php
					echo 'WP';
				?></td><?php
				?><td colspan="1" rowspan="2" style="text-align:center;"><?php
					echo 'Not Set';
				?></td><?php

				foreach ($includedYears as $year) 
				{
					$colspan=4;
					if(date('Y')==$year) $colspan=12;

					?><td colspan="<?=$colspan?>" style="text-align:center"><?php
						echo $year;
					?></td><?php
				}
			?></tr><?php
			?><tr class="tableGroup"><?php
				foreach ($includedYears as $year) 
				{
					if(date('Y')==$year)
					{
						foreach ($months as $month) 
						{
							?><td style="text-align:center;"><?php
								echo $month;
							?></td><?php
						}
					}
					else
					{
						foreach ($quaters as $quater) 
						{
							?><td style="text-align:center;"><?php
								echo $quater;
							?></td><?php
						}
					}
				}
			?></tr><?php

			foreach ($caWpCompiledQry as $wpId => $wpContents) 
			{
				$wpIdSplit=explode('___', $wpId);
				?><tr><?php

					?><td><?=$wpIdSplit[1]?></td><?php

					?><td><?php
						foreach ($wpContents as $caId => $caContents) 
						{
							$caIdSplit=explode('___', $caId);
							if($caContents['planned']=='Not Set' && $caContents['review_date']=='Not Set')
							{
								?><div style="cursor:pointer;" onclick="openReviewForm('<?=$caContents['review_profile_id']?>','ca');openSideElement('<?=$caIdSplit[0]?>','rev');"><?=$caIdSplit[1]?></div><?php
							}
						}
					?></td><?php

					foreach ($includedYears as $year) 
					{
						if(date('Y')==$year)
						{
							foreach ($months as $month)
							{
								?><td id="<?=$year?>_<?=$month?>" bgcolor="<?=(date('M')==$month)?'#F3E6A2':''?>"><?php
									foreach ($wpContents as $caId => $caContents) 
									{
										$useThisDate='planned';

										if($caContents['review_date']!='Not Set') $useThisDate='review_date';

										if($caContents[$useThisDate]=='Not Set' || $year!=substr($caContents[$useThisDate], 0,4)) continue;

										$caIdSplit=explode('___', $caId);
										$hoverMsg='WP: '.$wpIdSplit[1].'<br />CA: '.$caIdSplit[1].'<br />Date: '.substr($caContents[$useThisDate], 8,2).'/'.substr($caContents[$useThisDate], 5,2).'/'.substr($caContents[$useThisDate], 0,4);
										
										if($caContents[$useThisDate]!='Not Set') $caContents[$useThisDate]=$months[ltrim(substr($caContents[$useThisDate], 5,2),'0')-1];
										
										if($caContents[$useThisDate]==$month) 
										{	
											$image='x30t';
											if($useThisDate=='planned') $image='x30tt';
											if($caContents['review_done']==1)
											{
												if($caContents['review_status']==0) 		$image='r30t';
												else if($caContents['review_status']==1) 	$image='a30t';
												else if($caContents['review_status']==2) 	$image='g30t';
											}

											$margin=14;
											$caIdSplit[1]=substr($caIdSplit[1], 0,2);

											for ($i=0; $i < strlen($caIdSplit[1]); $i++) 
											{ 
												$margin+=5;
											}
											?><div style="display:inline; cursor:pointer; float:left;" onclick="openReviewForm('<?=$caContents['review_profile_id']?>','ca');openSideElement('<?=$caIdSplit[0]?>','rev');" onMouseOut="nd();" onMouseOver="overlib('<?=$hoverMsg?>', RIGHT, ABOVE);"><?php
												?><div style="position:relative; top:29px; color:white; text-align:center;"><?php
													?><b><?=$caIdSplit[1]?></b><?php
												?></div><?php
												?><img id="t_review_status_<?=$caIdSplit[0]?>_<?=$caContents['review_profile_id']?>" src="../common/img/<?=$image?>.png"><?php
											?></div><?php
										}	
									}
								?></td><?php
							}
						}
						else
						{
							foreach ($quaters as $quater)
							{
								?><td id="<?=$year?>_<?=$quater?>"><?php
									foreach ($wpContents as $caId => $caContents) 
									{
										$useThisDate='planned';

										if($caContents['review_date']!='Not Set') $useThisDate='review_date';

										if($caContents[$useThisDate]=='Not Set' || $year!=substr($caContents[$useThisDate], 0,4)) continue;

										$caIdSplit=explode('___', $caId);
										$hoverMsg='WP: '.$wpIdSplit[1].'<br />CA: '.$caIdSplit[1].'<br />Date: '.substr($caContents[$useThisDate], 8,2).'/'.substr($caContents[$useThisDate], 5,2).'/'.substr($caContents[$useThisDate], 0,4);

										$month=ltrim(substr($caContents[$useThisDate], 5,2),'0');

										if 		($month < 4) 	$caContents[$useThisDate]='Q1';
										else if ($month < 7) 	$caContents[$useThisDate]='Q2';
										else if ($month < 10)	$caContents[$useThisDate]='Q3';
										else 					$caContents[$useThisDate]='Q4';
								
										if($caContents[$useThisDate]==$quater) 
										{	
											$image='x30t';
											if($useThisDate=='planned') $image='x30tt';
											if($caContents['review_done']==1)
											{
												if($caContents['review_status']==0) 		$image='r30t';
												else if($caContents['review_status']==1)	$image='a30t';
												else if($caContents['review_status']==2) 	$image='g30t';
											}

											$margin=14;
											$caIdSplit[1]=substr($caIdSplit[1], 0,2);

											for ($i=0; $i < strlen($caIdSplit[1]); $i++) 
											{ 
												$margin+=5;
											}

											?><div style="display:inline; cursor:pointer; float:left;" onclick="openReviewForm('<?=$caContents['review_profile_id']?>','ca');openSideElement('<?=$caIdSplit[0]?>','rev');" onMouseOut="nd();" onMouseOver="overlib('<?=$hoverMsg?>', RIGHT, ABOVE);"><?php
												?><div style="position:relative; top:29px; color:white; text-align:center;"><?php
													?><b><?=$caIdSplit[1]?></b><?php
												?></div><?php
												?><img id="t_review_status_<?=$caIdSplit[0]?>_<?=$caContents['review_profile_id']?>" src="../common/img/<?=$image?>.png"><?php
											?></div><?php
										}	
									}
								?></td><?php
							}
						}
					}

				?></tr><?php
			}

		?></table><?php

		?><div class="sp"></div><?php 

		?><table class="criteriaTable" align="left" style="text-align:left;" cellpadding="5" cellspacing="0"><?php
			?><tr class="tableGroup"><td colspan="4">Key:</td></tr><?php
			?><tr><td>This Month</td>	<td width="30px;" height="30px;" bgcolor="#F3E6A2">		</td><td>Red Status</td>	<td width="40px;"><img src="../common/img/r30t.png">	</td></tr><?php
			?><tr><td>Forecast</td>		<td width="40px;"><img src="../common/img/x30tt.png">	</td><td>Amber Status</td>	<td width="40px;"><img src="../common/img/a30t.png">	</td></tr><?php
			?><tr><td>Planned</td>		<td width="40px;"><img src="../common/img/x30t.png">	</td><td>Green Status</td>	<td width="40px;"><img src="../common/img/g30t.png">	</td></tr><?php
		?></table><?php
	}
	else if(empty($reviewTypeQry))
	{
		?>You do not have permission to view any review types and/or perimeters in this program.<?php
	}


	if(!empty($reviewTypeQry))
	{
		$i=0;

		?><form action="#" enctype="multipart/form-data" id="reviewTypeTableForm" name="reviewTypeTableForm" method="post" style="display:inline;"><?php
			?><table class="criteriaTable" align="left" style="text-align:left; margin-left:50px; clear:none;" cellspacing="0" cellpadding="5"><?php
				?><tr class="tableGroup"><td colspan="5">Review Types:</td></tr><?php
				?><tr><?php
					foreach($reviewTypeQry as $reviewTypeColumnName=>$reviewTypeColumnContents)
					{
                                                /***
                                                 * Fix for : Bug-4
                                                 * Version :4.1
                                                 * Fixed by : Infosys Limited
                                                 * Display the reviews type which contains less than 12 characters
                                                 */
                                                //if(strlen($reviewTypeColumnContents['review_type']) > 4) continue;
                                                if(strlen($reviewTypeColumnContents['review_type']) > 20) continue;
                                                 /*End of modifictaion for Bug- 4*/

						$checked=false;
						if(!empty($reviewTypesSession))
						{
							if(in_array($reviewTypeColumnContents['review_type_id'], $reviewTypeAsArray)) $checked=true;
						}

						?><td><input type="checkbox" id="review_type_<?=$reviewTypeColumnContents['review_type_id']?>" <?=($checked)?'checked="checked"':''?>><?=$reviewTypeColumnContents['review_type']?></td><?php
						$i++;
						if($i>4)
						{
							?></tr><?php
							?><tr><?php
							$i=0;
						}
					}
				?></tr><?php
				?><tr><td colspan="5"><input type="button" class="stdBtn" value="Submit &#9658;" onclick="restartMainTable('review_type');"></td></tr><?php
			?></table><?php
		?></form><?php
	}

	?><input id="mainTableCacheId"type="hidden"value="<?=$tableCacheId?>"><?php
}
storeSession($SESSION);

?>