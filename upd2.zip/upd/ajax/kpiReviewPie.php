<?php
/*
 * #094-Improvement: Measure DR effectiveness
 * To get piechart data
 * Version: 4.4
 * Created by: Infosys Limited
 */
require_once('../support/form.php');
require_once('../support/header.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
	
$POST = cleanArray($_GET);
$kpiArr = json_decode( html_entity_decode( stripslashes ($POST['kpiData'] ) ) );

$area = array();
$program = array();
$coe = array();
$msn = array();

foreach($kpiArr as $kpiDetails) {
    if(!empty($kpiDetails)) {
        array_push($area,$kpiDetails->area);
        array_push($program,$kpiDetails->program);
        array_push($coe,$kpiDetails->coe);
        array_push($msn,$kpiDetails->msn);
    }    
}
$area = implode(',', array_unique($area));
$program = implode(',', $program);
$coe = implode(',', $coe);
$msn = implode(',', $msn);

$programArr = explode(',', $program);
$coeArr = explode(',', $coe);
$msnArr = explode(',', $msn);

// To remove the duplicates in Program, coe and msn
$program = implode(',', array_unique($programArr));
$coe = implode(',', array_unique($coeArr));
$msn = implode(',', array_unique($msnArr));
		
if ($program && $coe) {
$ca = SqlSLi('SELECT ca_id FROM c_ca 
		WHERE program IN (' . $program . ')
		AND coe IN (' . $coe . ')', 'ca_id');
$ca = implode(',', $ca);

$reviewProfileQry = SqlSLi('SELECT review_profile_id FROM dr_review_profile 
                WHERE program IN (' . $program . ')
                AND coe IN (' . $coe . ') AND rp_hidden=0', 'review_profile_id');
$reviewProfile = implode(',', $reviewProfileQry);
}		

if ($msn) {
	$specificFilter[] = 'r.msn IN(' . $msn . ')';
}

if ($ca) {
	$specificFilter[] = 'ra.ca IN('. $ca .')';
}

if ($reviewProfile) {
	$specificFilter[] = 'r.review_profile IN(' . $reviewProfile . ')';
}
if (!empty($POST['from'])) {
    $specificFilter[] = 'r.planned > "' . $POST['from'] . ' 00:00:00"';
}
if (!empty($POST['to'])) {
    $specificFilter[] = 'r.planned < "' . $POST['to'] . ' 23:59:59"';
}
if(count($specificFilter)>0){
	$qryFilter = '  WHERE '.implode(' AND ',$specificFilter);
}

$reviewList = SqlLi('SELECT r.review_id, r.review_status
					FROM dr_review AS r 
                    INNER JOIN dr_review_applicability AS ra ON ra.review=r.review_id 
                    INNER JOIN dr_review_profile AS rp ON r.review_profile=rp.review_profile_id
                    INNER JOIN dr_review_type AS rt ON rp.review_type=rt.review_type_id
                    INNER JOIN c_ca as ca ON ra.ca=ca.ca_id
                    INNER JOIN c_cawp						AS cw	ON ca.ca_id=cw.ca
                    INNER JOIN c_msn						AS m	ON (cw.msn=m.msn_id AND r.msn=m.msn_id)
                    INNER JOIN c_wp							AS wp	ON cw.wp=wp.wp_id
                    INNER JOIN c_msn as msn ON r.msn=msn.msn_id
                    INNER JOIN c_perimeter AS per ON ca.perimeter=per.perimeter_id
                    INNER JOIN c_program AS pro ON ca.program=pro.program_id
                    INNER JOIN c_coe AS coe ON ca.coe=coe.coe_id
                    INNER JOIN c_area AS area ON coe.area=area.area_id
					'.$qryFilter.'
					AND r.planned > "0000-00-00"');

		 
if(!empty($reviewList))
{
	foreach ($reviewList as $review) 
	{
		$involvement='';
		$reviewTotal['total']++;

		switch ($review['review_status']) 
		{
			case 0:
				$reviewTotal['red']++;
			break;
			case 1:
				$reviewTotal['amber']++;
			break;
			case 2:
				$reviewTotal['green']++;
			break;
			case 3:
				$reviewTotal['blue']++;
			break;
		} 
	}
}

$graphMeArray=Array('Reviews Count',$reviewTotal['total'],$reviewTotal['red'],$reviewTotal['amber'],$reviewTotal['green'],$reviewTotal['blue']);
$answer='&&&my_actions---'.implode(',',$graphMeArray);

echo $answer;


?>
