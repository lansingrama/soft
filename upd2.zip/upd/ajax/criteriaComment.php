<?php
//require_once('../../support.php');
require_once('../support/header.php');

$p12=mysql_connect('127.0.0.1','sa-1v55-app-i','art_mysql_1V55') or trigger_error(mysql_error(),E_USER_ERROR);
mysql_select_db('1V55',$p12);
$commentQry=mysql_query('SELECT criteria_comments FROM dr_criteria_status WHERE criteria_status_id="'.$_GET['c'].'" LIMIT 1',$p12) or die(mysql_error());
$comment=mysql_fetch_assoc($commentQry);
echo 'OK|||',str_replace(array('\r','\n','\r\n',chr(10),chr(13)),'<br>',utf8_encode(stripslashes($comment['criteria_comments'])))?>