<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

$POST=cleanArray($_POST);

if($POST['change_remark_id']!='' && $POST['change_id']!=''){
	
	if($POST['change_remark_id']=='new'){
		$viewAsUserId=($SESSION['user']['view_as']!='')?$SESSION['user']['view_as']:$SESSION['user']['user_id'];
		
		SqlLQ('INSERT INTO dr_change_remark (`change`,change_remark_by,change_remark_date,change_remark)
					VALUES("'.$POST['change_id'].'","'.$viewAsUserId.'",NOW(),"'.$POST['change_remark'].'")');
	}else{
		SqlLQ('UPDATE dr_change_remark SET change_remark="'.$POST['change_remark'].'" WHERE change_remark_id="'.$POST['change_remark_id'].'"');
	}
	
	$changeRemark=SqlSLi('SELECT CONCAT(chr.change_remark_by,"***",u.name," ",u.surname,"***",chr.change_remark_date,"***",chr.change_remark) AS change_remark
							FROM dr_change_remark AS chr
								INNER JOIN c_user AS u		ON chr.change_remark_by=u.user_id
							WHERE chr.change="'.$POST['change_id'].'"
							ORDER BY chr.change_remark_date DESC','change_remark');
	if($changeRemark){
		$changeRemark=utf8enc($changeRemark);
		echo 'OK|||change_remark_'.$POST['change_id'].'%%%history%%%'.implode('###',$changeRemark);
	}else{
		?>OK|||error|||Invalid ID<?php
	}
}else{
	?>OK|||error|||Missing ID<?php
}
storeSession($SESSION);
?>