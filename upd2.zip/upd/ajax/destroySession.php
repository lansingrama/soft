<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');

destroySession();
?>OK|||