<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);
//foreach($_GET as $k=>$v)$GET[$k]=addslashes($v);
$status=array('r','a','g');
$program=getFilter('program','filter',0,$SESSION);
$validExtension=array('jpg','gif','png','bmp');


$GET['ca']=defineReviewCa($GET['element'],$GET['target'],$SESSION);

$multipleCa=(stristr($GET['ca'],','))?1:0;

//JFM 19_07_16
$caMlt=SqlLi('SELECT c.ca_id,c.ca,c.ca_description,c.caa,c.ca_image_file,
					p.perimeter_id,p.perimeter,
					w.wp_id,w.wp,w.wp_description,w.wp_image_file,
					s.assembly,s.assembly_done,s.kodd,s.kodd_done, s.odd, s.id, s.progress_trend, s.sourcing
				FROM c_ca 						AS c
					INNER JOIN	c_perimeter 	AS p 	ON c.perimeter=p.perimeter_id
					INNER JOIN	c_cawp 			AS cw	ON c.ca_id=cw.ca
					INNER JOIN	c_wp 			AS w 	ON cw.wp=w.wp_id
					LEFT JOIN	dr_ca_status	AS s	ON (s.ca=c.ca_id
															AND s.msn="'.getFilter('msn','filter',0,$SESSION).'")
				WHERE c.ca_id IN ('.$GET['ca'].')
					AND cw.msn="'.getFilter('msn','filter',0,$SESSION).'"');

if(is_array($caMlt[0]))
{
	foreach($caMlt[0] as $k=>$v)
	{
		$caCombined[$k]=combinedResult($caMlt,$k,$SESSION['table']['review_planning']['ca'][$k]['type'],$SESSION);
	}
	if($caCombined['wp_id']!='m')
	{
		$caInWp=SqlSLi('SELECT ca FROM c_cawp WHERE msn="'.getFilter('msn','filter',0,$SESSION).'" AND wp="'.$caCombined['wp_id'].'" ORDER BY ca ASC','ca');
		$caArray=explode(',',$GET['ca']);
		sort($caArray);
		$caCount=count($caInWp);
		$uniqueWpSelected=1;
		for($i=0;$i<$caCount;$i++)
		{
			if($caInWp[$i]!=$caArray[$i])
			{
				$uniqueWpSelected=0;
			}
		}
	}
}

if($uniqueWpSelected==1)
{
	$target='wp';
	$targetId=$caCombined['wp_id'];
}
else
{
	$target='ca';
	$targetId=$GET['ca'];
}

foreach($caMlt as $c)
{
	$cawp[]=array('ca'=>$c['ca'],'wp'=>$c['wp']);
	$wpMlt[]=$c['wp_id'];
}

$wp=implode(',',array_unique($wpMlt));

$perimeter=SqlAsArr('SELECT perimeter_id,perimeter FROM c_perimeter WHERE program="'.$program.'"','perimeter_id','perimeter');

$imagePath='';

if(!$multipleCa || $uniqueWpSelected==1)
{
	$imageFile=($uniqueWpSelected==1)?$caCombined['wp_image_file']:$caCombined['ca_image_file'];
	if($imagePath=='' && $imageFile!='' && file_exists('../img/'.$target.'/'.$imageFile))
	{
		$imagePath='img/'.$target.'/'.$imageFile;
	}
	
	
	if($imagePath!='')
	{
		$imageProperty=getimagesize('../'.$imagePath);
		if($imageProperty[0]>$imageProperty[1])$imageSize='width="270"';
		else $imageSize='height="220"';
	}
}

$editableCa=checkEditableCa($GET['ca'],$SESSION);
/*
	US109-General Information not editable by supplier
	Identifying particular review type access 
	Fixed By - Infosys Limited
	Version: V 4.5
	CA details page should be Non-editable 
*/
$userReviewEditCheck = 1;
if ((checkPermission('superadmin','superadmin',0,'check',$SESSION) != 1)) {
	$obj = 'review_profile_id';
	$object = SqlQ('SELECT object_id FROM c_object WHERE object = "'.$obj.'"');
	$userReviewEditCheckqry = SqlQ('SELECT active FROM c_permission WHERE object = '.$object['object_id'].' AND applicability = '.$GET['rpid'].' AND action = 2 AND user = '.$SESSION['user']['user_id'].'');
	$userReviewEditCheck = $userReviewEditCheckqry['active'];
}
/* End for US109 */
//$colours = array("#BBBCBC", "#EF343F", "#F8D707", "#81C341", "#0088CF"); //JFM 19_07_16
$colours = array("#BBBCBC", "#EF343F", "#F8D707", "#81C341"); //JFM 19_07_16

?>OK|||<?php
?><div style="width:798px;"><?php
	?><div class="formHeader"><?php
		?><div class="formHeaderInfo"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Details</div><?php
		?><div class="xDiv" onclick="closeLastForm();">&#9668; Back</div><?php
	?></div><?php

	?><div class="formStdContainer" style="margin: 0 auto; margin-top:70px;"><?php

		?><div class="reviewCaList" style="overflow:auto;height:288px;"><?php
			?><table class="criteriaTable"style="width:134px;" cellpadding="5" cellspacing="0"><?php
				?><tr class="tableGroup"><?php
					?><td><?=$SESSION['table']['review_planning']['ca']['ca']['title']?></td><?php
					?><td><?=$SESSION['table']['review_planning']['ca']['wp']['title']?></td><?php
				?></tr><?php
				foreach($caMlt as $c){
					?><tr class="infoRow"><?php
						?><td><?=$c['ca']?></td><?php
						?><td><?=$c['wp']?></td><?php
					?></tr><?php
				}
			?></table><?php
		?></div><?php
	
		?><div class="leftInfoBox"style="width:638px;"><?php
			?><form action="#"enctype="multipart/form-data"id="caFrm"method="post"style="display:inline;"><?php
				?><input id="ca"name="ca"type="hidden"value="<?=$GET['ca']?>"><?php
				?><input id="wp"name="wp"type="hidden"value="<?=$wp?>"><?php
				?><table class="criteriaTable" style="width:638px;" cellpadding="5" cellspacing="0"><?php
					?><tr class="tableGroup"><?php
						?><td colspan="5">Dates</td><?php
						?><td colspan="2">Performed</td><?php
						?><td colspan="2" style="width:270px;">Picture</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef" style="width:100px;">Assembly Start</td><?php
						?><td colspan="4" style="width:120px;"><?php drawDate('assembly','assemblyCal',$caCombined['assembly'],false,$editableCa)?></td><?php
						?><td colspan="2" nowrap><?php drawRadio('assembly_done',$caCombined['assembly_done'],$editableCa)?></td><?php
						?><td><?php if((!$multipleCa || $uniqueWpSelected==1) && $editableCa==1){?><input class="popUpBtn"id="caPicture"onClick="popUpOpt('cap',['<?=$target?>','<?=$targetId?>']);"type="button"value="&#8801;"><div class="popUpMenu"id="popUpCaPic"></div><?php }?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">KODD</td><?php
						?><td colspan="4"><?php drawDate('kodd','koddCal',$caCombined['kodd'],false,$editableCa)?></td><?php
						?><td colspan="2" nowrap><?php drawRadio('kodd_done',$caCombined['kodd_done'],$editableCa)?></td><?php
						?><td align="center" rowspan="7" valign="middle"><?php
							$noImgTxt=($multipleCa && $uniqueWpSelected!=1)?'Multiple CAs':'Image Not Found';
							if($imagePath){
								?><img id="caWpImg"<?=$imageSize?>src="<?=$imagePath?>"><div class="inf"id="inf"style="display:none;"><?=$noImgTxt?></div><?php
							}else{
								?><img id="caWpImg"style="display:none;"><div class="inf"id="inf"><?=$noImgTxt?></div><?php
							}
						?></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">ODD</td><?php
						?><td colspan="4"><?php drawDate('odd','oddCal',$caCombined['odd'],false,$editableCa)?></td><?php
						?><td colspan="2" nowrap></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef">ID</td><?php
						?><td colspan="4"><?php drawDate('id','idCal',$caCombined['id'],false,$editableCa)?></td><?php
						?><td colspan="2" nowrap></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="7">Other Information</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef"><?=$SESSION['table']['review_planning']['ca']['perimeter']['title']?></td><?php
						?><td colspan="6"><?php
							?><select id="perimeter"name="perimeter"<?php if($editableCa!=1){?>readonly<?php }?>><?php
								if($caCombined['perimeter_id']=='m'){?><option selected value="m">Mixed</option><?php }
								foreach($perimeter as $k=>&$v){?><option<?php if($caCombined['perimeter_id']==$k)echo' selected'?> value="<?=$k?>"><?=$v?></option><?php }
							?></select><?php
						?></td><?php
					?></tr><?php

					//JFM 19_07_16
					?><tr class="infoRow"><?php
						?><td class="paramDef">Sourcing</td><?php
						?><td colspan="7"><?php
							?><input class="textareaWhite" id="sourcing" name="sourcing"<?php if($editableCa!=1){?>readonly <?php }?>size="30"type="text"value="<?=$caCombined['sourcing']?>"><?php
						?></td><?php
					?></tr><?php


					?><tr class="infoRow"><?php 
																																				//JFM TODO: Make this pretty 
						?><td rowspan="4" class="paramDef"><?=$SESSION['table']['review_planning']['ca']['progress_trend']['title']?><span style="font-size:8px;"><br /><br />(Arrow - Tendency)<br />(Colour - Current Status)</span></td><?php
						if($editableCa==1)
						{
							for ($i=0; $i < 6; $i++) 
							{ 
								?><td align="center"><input type="radio" name="progress_trend" value="<?=$i?>" <?=(substr($caCombined['progress_trend'],0,1)==$i)?'checked':''?>></td><?php
							}
						}
					?></tr><?php

					?><tr class="infoRow"><?php
						?><td></td><?php
						for ($i=1; $i < 6; $i++) 
						{ 
							?><td align="center"><img src="../common/img/t20<?=$i?>.png"></td><?php
						}
					?></tr><?php

					?><tr class="infoRow"><?php //JFM 19_07_16
						foreach ($colours as $colour) 
						{
							?><td style="background-color:<?=$colour?>"></td><?php
						}
					?></tr><?php

					?><tr class="infoRow"><?php //JFM 19_07_16
						if($editableCa==1)
						{
							for ($i=0; $i < 4; $i++) 
							{ 
								?><td align="center"><input type="radio" name="progress_trend_colour" value="<?=$i?>" <?=(substr($caCombined['progress_trend'],2,1)==$i)?'checked':''?>></td><?php
							}
						}
					?></tr><?php

					?><tr class="infoRow"><?php
						?><td class="paramDef">Conf. &amp; Att. Acc.</td><?php
						?><td colspan="7"><?php
							?><input class="textareaWhite"id="caa"name="caa"<?php if($editableCa!=1){?>readonly <?php }?>size="30"type="text"value="<?=$caCombined['caa']?>"><?php
						?></td><?php
					?></tr><?php
					?><tr class="tableGroup"><?php
						?><td colspan="7">Notes</td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef"style="width:110px;"><?=$SESSION['table']['review_planning']['ca']['ca']['title']?> Description</td><?php
						?><td colspan="7"><textarea class="textareaWhite"cols="30"id="ca_description"name="ca_description"<?php if($editableCa!=1){?>readonly <?php }?>rows="5"style="overflow-x:hidden;"><?=$caCombined['ca_description']?></textarea></td><?php
					?></tr><?php
					?><tr class="infoRow"><?php
						?><td class="paramDef"><?=$SESSION['table']['review_planning']['ca']['wp']['title']?> Description</td><?php
						?><td colspan="7"><textarea class="textareaWhite"cols="30"id="wp_description"name="wp_description"<?php if($editableCa!=1){?>readonly <?php }?>rows="4"style="overflow-x:hidden;"><?=$caCombined['wp_description']?></textarea></td><?php
					?></tr><?php
			?></table><?php
			/*
				US109-General Information not editable by supplier
				CA details page should be Non-editable
				Fixed By - Infosys Limited
				Version: V 4.5 
			*/
				if($editableCa==1){ if ($userReviewEditCheck == 1) {?><div class="save"><span class="saveResponse"id="ca_saveResponse">Changes were applied</span><input class="stdBtn"onClick="sendAjaxForm('caFrm','ajax/saveCa.php','updateData','ca_saveResponse');"type="button"value="Apply Changes &#9658;"></div><?php }}
			/* End for US109 */
			?></form><?php
		?></div><?php
	?></div><?php
?></div><?php
storeSession($SESSION);
?>