<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/header.php');
require_once('../support/localSupport.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes(utf8_decode(str_replace(array('|||','&&&','%%%','###'),'_',$v)));

$modifiedField=array();

$modifiedField=hideAllReviewColumns($GET['review'],$GET['hide'],$SESSION);

storeSession($SESSION);

echo 'OK|||'.implode('&&&',$modifiedField);?>