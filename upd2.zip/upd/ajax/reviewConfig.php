<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/localSupport.php');
require_once('../support/form.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);
$reviewProfile=$GET['element'];
$GET['objectTxt']='review';
$GET['applicability']=$reviewProfile;
$included=1;

$type=SqlQ('SELECT rt.review_type,rt.review_type_description,rt.review_type_code
				FROM dr_review_type AS rt
					INNER JOIN dr_review_profile AS rp ON rt.review_type_id=rp.review_type
				WHERE rp.review_profile_id="'.$reviewProfile.'"');
$type=utf8enc($type);


?>OK|||<?php
?><div class="formHeaderInfo"id="userDetailsTitle"style="position:relative;"><?php
	/*JFM 11_11_13 ?><input class="popUpBtn"onClick="popUpOpt('ttl',['rvm','<?=$reviewProfile?>','<?=$type['review_type']?>']);"type="button"value="..."><?php
	?><div class="popUpMenu"id="popUpTtlDiv_rvm"></div>&nbsp;<?php*/
	?><div id="reviewConfigTitle" style="display:inline;"><?php
		echo $type['review_type'];
		?> Review<?php
	?></div><?php
?></div><?php

/* JFM 11_11_13
?><div style="position:relative;height:50px;"></div><?php

require_once('../form/editStructure.php');*/

?><div class="sp"></div><?php

?><div class="elementInfo"id="reviewCriteriaManagementList"style="width:703px;"><?php
	include('criteriaList.php');
?></div><?php
?><div class="sp"></div><?php
storeSession($SESSION);
?>