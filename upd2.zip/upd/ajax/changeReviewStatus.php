<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');

foreach($_GET as $k=>&$v)$GET[$k]=addslashes($v);

$status=array('r'=>0,'a'=>1,'g'=>2,'x'=>3); //JFM 27_03_14

//JFM 22_10_13 Replaced with below $review=SqlQ('SELECT review_id FROM dr_review WHERE ca=\''.$GET['ca'].'\' AND msn=\''.$GET['msn'].'\' AND review_profile=\''.$GET['review'].'\'');
$review=SqlQ('SELECT r.review_id 
				FROM dr_review as r
					INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
				WHERE ra.ca=\''.$GET['ca'].'\' 
				AND msn=\''.$GET['msn'].'\' 
				AND review_profile=\''.$GET['review'].'\'');

if(!$review['review_id']){
	/* JFM 22_10_13
	SqlLQ('INSERT INTO dr_review (ca,msn,review_profile) VALUES (\''.$GET['ca'].'\',\''.$GET['msn'].'\',\''.$GET['review'].'\')');
	$review=SqlQ('SELECT review_id FROM dr_review WHERE ca=\''.$GET['ca'].'\' AND msn=\''.$GET['msn'].'\' AND review_profile=\''.$GET['review'].'\'');*/
	
	SqlLQ('INSERT INTO dr_review (msn,review_profile) VALUES (\''.$GET['msn'].'\',\''.$GET['review'].'\')');
	$reviewID=SqlQ('SELECT LAST_INSERT_ID() AS reviewID');
	SqlLQ('INSERT INTO dr_review_applicability (review,ca) VALUES (\''.$reviewID['reviewID'].'\',\''.$GET['ca'].'\')');
	$review=SqlQ('SELECT r.review_id 
					FROM dr_review as r
						INNER JOIN dr_review_applicability AS ra ON r.review_id=ra.review
					WHERE ra.ca=\''.$GET['ca'].'\' 
					AND msn=\''.$GET['msn'].'\' 
					AND review_profile=\''.$GET['review'].'\'');
}

SqlLQ('UPDATE dr_review SET review_status="'.$status[$GET['status']].'" WHERE review_id="'.$review['review_id'].'"');

echo 'OK|||criteriaStatus_'.$GET['status'].'%%%img%%%../common/img/'.$GET['status'].'30.png';
storeSession($SESSION);
?>