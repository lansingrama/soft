<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

$GET=cleanArray($_GET);

switch($GET['element']){
	case 'action':
		
		/* JFM 11_11_13
		$reviewProfile=SqlQ('SELECT rgr.review_profile
								FROM dr_review_group AS rgr
									INNER JOIN dr_review_criteria AS rcr ON rgr.review_group_id=rcr.review_group
									INNER JOIN dr_action AS act ON rcr.review_criteria_id=act.criteria
								WHERE act.action_id="'.$GET['id'].'"');*/
								
		//JFM 28_10_15
		$reviewProfile=SqlQ('SELECT rp.review_profile_id
								FROM dr_review_profile AS rp
									INNER JOIN dr_review_type AS rt ON rt.review_type_id=rp.review_type
									INNER JOIN dr_review_group AS rg ON rg.review_type=rt.review_type_id
									INNER JOIN dr_review_criterion AS rc ON rg.group_id=rc.review_group
									INNER JOIN dr_action AS act ON rc.review_criterion_id=act.criteria
									INNER JOIN dr_action_applicability AS app ON app.action=act.action_id
									INNER JOIN c_ca AS ca ON ca.ca_id=app.ca
															AND rp.program=ca.program
															AND rp.coe=ca.coe
								WHERE act.action_id="'.$GET['id'].'"');

		if(empty($reviewProfile)) //JFM 28_10_15
		{
			$reviewProfile=SqlQ('SELECT r.review_profile AS review_profile_id
								FROM dr_review AS r
									INNER JOIN dr_action AS act ON act.review=r.review_id
								WHERE act.action_id="'.$GET['id'].'"');
		}
		
		
		
		if($reviewProfile!='')
		{
			if(checkPermission('review_profile_id','delete',$reviewProfile['review_profile_id'],'check',$SESSION)==1 || checkPermission('dr_review_profile_general','delete',0,'check',$SESSION)==1)
			{
				$caApplicability=SqlSLi('SELECT ca FROM dr_action_applicability WHERE action="'.$GET['id'].'"','ca');
				$actionAditionalInfo=SqlQ('SELECT criteria,action_status FROM dr_action WHERE action_id="'.$GET['id'].'"');
				SqlLQ('DELETE FROM dr_action_applicability WHERE action="'.$GET['id'].'"');
				SqlLQ('DELETE FROM dr_action WHERE action_id="'.$GET['id'].'"');
				?>OK|||<?php
				echo $GET['id'],'&&&',$reviewProfile['review_profile_id'],'&&&',$actionAditionalInfo['criteria'],'&&&',$actionAditionalInfo['action_status'],'&&&';
				if(is_array($caApplicability)){
					echo implode(',',$caApplicability);
				}
			}
			else
			{
				?>OK|||no_rights<?php
			}
		}
		else
		{
			?>OK|||no_review_found<?php
		}
	break;
}
storeSession($SESSION);
?>