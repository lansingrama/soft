<?php

if($included!=1){
	require_once('../support/header.php');
	require_once('../security/checkExpiredSession.php');
	require_once('../../support.php');

	$GET=$_GET;
	$mainTableCacheId=addslashes($GET['main_table_cache_id']);
	$target=addslashes($GET['target']);
}

$tableCache=loadCache('csv',$mainTableCacheId);

if(is_array($tableCache)){
	switch($target){
		case 'ca':
			foreach($tableCache as $caId=>$caDetails){
				if($caDetails['element_disabled']!=1){
					$element[$caDetails['ca_id']]=$caDetails['ca'];
				}
			}
		break;
		case 'wp':
			foreach($tableCache as $caId=>$caDetails){
				if($caDetails['element_disabled']!=1){
					$element[$caDetails['wp_id']]=$caDetails['wp'];
				}
			}
		break;
	}
}


if($included!=1){
	echo'OK|||';
}

if(is_array($element)){
	foreach($element as $elementId=>$elementName){
		?><div class="sideElement"id="reviewCaWpElement_<?=$elementId?>"onClick="openSideElement('<?=$elementId?>','rev');"><?=utf8_encode($elementName)?></div><?php
	}
	?><div class="sideElementEmpty"id="reviewCaWpNotFound">Not Found</div><?php
}else{
	?><div class="sideElementEmpty"id="reviewCaWpElement_noResults"style="display:block;">No Results</div><?php
}
storeSession($SESSION);
?>