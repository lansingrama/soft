<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../support/form.php');
require_once('../support/localSupport.php');
require_once('../../common/php/common.php');

foreach($_POST as $k=>&$v)$POST[$k]=addslashes(utf8_decode(str_replace(array('|||','&&&','%%%','###'),'_',$v)));

//print_r($POST);

if($POST['existingReviewType']=='new'){
	if($POST['newReviewType']==''){
		$serverResponse='invalidInput';
	}elseif(SqlQ('SELECT review_type_id FROM dr_review_type WHERE review_type="'.$POST['newReviewType'].'"')){
		$serverResponse='exists';
	}else{
		SqlLQ('INSERT INTO dr_review_type (review_type) VALUES ("'.$POST['newReviewType'].'")');
		$reviewTypeId=SqlQ('SELECT review_type_id FROM dr_review_type WHERE review_type="'.$POST['newReviewType'].'"');
	}
}else{
	if(SqlQ('SELECT review_profile_id FROM dr_review_profile WHERE program="'.$POST['program'].'" AND coe="'.$POST['coe'].'" AND review_type="'.$POST['existingReviewType'].'"')){
		$serverResponse='reviewProfileExists';
	}else{
		$reviewTypeId=SqlQ('SELECT review_type_id FROM dr_review_type WHERE review_type_id="'.$POST['existingReviewType'].'"');
	}
}

if($reviewTypeId['review_type_id']){
	SqlLQ('INSERT INTO dr_review_profile (program,coe,review_type) VALUES ("'.$POST['program'].'","'.$POST['coe'].'","'.$reviewTypeId['review_type_id'].'")');
	$reviewProfileId=SqlQ('SELECT review_profile_id FROM dr_review_profile WHERE program="'.$POST['program'].'" AND coe="'.$POST['coe'].'" AND review_type="'.$reviewTypeId['review_type_id'].'"');
	if($POST['review_profile_copy_source']!=''){
		repairReviewPosition($POST['review_profile_copy_source']);
		SqlLQ('INSERT
				INTO dr_review_group
					(review_profile,group_description,group_position)
					SELECT "'.$reviewProfileId['review_profile_id'].'",group_description,group_position
					FROM dr_review_group
					WHERE review_profile="'.$POST['review_profile_copy_source'].'"');//JFM TODO - CRIT
		SqlLQ('INSERT
				INTO dr_review_criteria
					(review_group,criteria_description,reference,criteria_position)
					SELECT g2.review_group_id,c.criteria_description,c.reference,c.criteria_position
					FROM dr_review_criteria AS c
						INNER JOIN dr_review_group AS g1 ON c.review_group=g1.review_group_id,
						dr_review_group AS g2
					WHERE g1.review_profile="'.$POST['review_profile_copy_source'].'"
						AND g2.review_profile="'.$reviewProfileId['review_profile_id'].'"
						AND g1.group_description=g2.group_description
						AND g1.group_position=g2.group_position');
		if($POST['copyReviewConfig']==1){
			$revConfigProfile=SqlLi('SELECT review_configuration_profile_id,review_profile,review_configuration_profile FROM dr_review_configuration_profile');
			foreach($revConfigProfile as &$r){
				SqlLQ('INSERT
						INTO dr_review_configuration_profile
							(review_profile,review_configuration_profile)
						VALUES ("'.$reviewProfileId['review_profile_id'].'","'.$r['review_configuration_profile'].'")');
				$reviewConfigProfileId=SqlQ('SELECT review_configuration_profile_id
										FROM dr_review_configuration_profile
										WHERE review_profile="'.$reviewProfileId['review_profile_id'].'" AND review_configuration_profile="'.$r['review_configuration_profile'].'"');
				SqlLQ('INSERT
						INTO dr_review_configuration
							(review_configuration_profile,criteria,review_configuration)
							SELECT "'.$reviewConfigProfileId['review_configuration_profile_id'].'",c2.criteria_description,rc.review_configuration
								FROM dr_review_criteria AS c1
									INNER JOIN dr_review_configuration AS rc,
									dr_review_criteria AS c2
									INNER JOIN dr_review_group AS rg ON c2.review_group=rg.review_group_id
								WHERE rc.review_configuration_profile="'.$POST['review_profile_copy_source'].'"
									AND c1.criteria_description=c2.criteria_description
									AND c1.reference=c2.reference
									AND c1.criteria_position=c2.criteria_position
									AND rg.review_profile="'.$reviewProfileId['review_profile_id'].'"');
			}
		}
	}else{	
		SqlLQ('INSERT INTO dr_review_group (review_profile,group_description,group_position) VALUES ("'.$reviewProfileId['review_profile_id'].'","New Group","1")');
		$reviewGroupId=SQlQ('SELECT review_group_id FROM dr_review_group WHERE review_profile="'.$reviewProfileId['review_profile_id'].'" AND group_description="New Group" AND group_position="1"');
		SqlLQ('INSERT INTO dr_review_criteria (review_group,criteria_description,criteria_position) VALUES ("'.$reviewGroupId['review_group_id'].'","New Criteria","1")');
		$serverResponse=$reviewTypeId['review_type_id'];
	}
}

?>OK|||<?=$serverResponse?>