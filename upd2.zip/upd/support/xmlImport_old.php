<?php
//A0 Report Versions
//==================
//
// 0: (2009-09) First Version
// 1: (2010-10) CA / WP Applicability
// 2: (2012-09) First Version of Design Reviews + DQRP Tools together


//$startTime=microtime();
/*include('../database.php');
include('../support.php');
include('phpCommon.php');*/
require_once('header.php');
require_once('localSupport.php');
session_start();

//header("Content-Type: text/html; charset=utf-8");

function actionCheckerLauncher_(&$actLoc,&$MSN,&$prog,&$revT,&$ca,&$wp,$criteria,&$statA,&$caLock,&$actQry,&$actAppArr,&$caArr,&$actRevTArr,&$rid,&$ridInserted){
	if($actLoc['act_reference']){
		checkAction($actLoc,$MSN,$prog,$revT,$ca,$wp,$criteria,$statA,$caLock,$actQry,$actAppArr,$caArr,$actRevTArr,$rid,$ridInserted);
	}elseif($actLoc){
		foreach($actLoc as &$action){
			checkAction($action,$MSN,$prog,$revT,$ca,$wp,$criteria,$statA,$caLock,$actQry,$actAppArr,$caArr,$actRevTArr,$rid,$ridInserted);
		}
	}
}
function actionCheckerLauncher($actionLocation,&$a0Config){
	if($actionLocation['act_reference']){
		checkAction($actionLocation,$a0Config);
	}elseif($actionLocation){
		foreach($actionLocation as &$action)
			checkAction($action,$a0Config);
	}	
}
function arrayNormalized($oldArray){
	foreach($oldArray as $field=>&$value){
		if(is_array($value))$newArray[$field]=($value['body']['p']['span'] && is_array($value['body']['p']['span']))?$value['body']['p']['span']['_value']:$value['body']['p']['_value'];
		else $newArray[$field]=$value;
	}
	if($newArray['actionholder']!=''){
		$newArray['actionholder']=str_replace(array('\r\n','\n\r','\n','\r','
'),'',$newArray['actionholder']);
	}
	return $newArray;
}

function checkAction_($action,&$MSN,&$prog,&$revT,&$ca,&$wp,$crId,&$statA,&$caLock,&$actQry,&$actAppArr,&$caArr,&$actRevTArr,$rid,&$ridInserted){
	if(!is_array($action['actiondescription'])){
		$actRevT=$actRevTArr[$revT];
		$actDeleted=false;
		$actStat=$statA[$action['act_status']];
		$actData=array();
		$actData=arrayNormalized($action);
		if($action['WPCAApp']){	// Means it's a document extracted after October 2010
			if(!is_array($action['WPCAApp']))$newActApp[]=$action['WPCAApp'];
			elseif(is_array($action['WPCAApp']['value']))foreach($action['WPCAApp']['value'] as &$a)$newActApp[]=$a;
			else $newActApp[]=$action['WPCAApp']['value'];
		}else $newActApp[]=($ca!='')?$ca:$wp;	// Support for old documents (before October 2010)
		foreach($newActApp as &$naa)$caValidity[$naa]=1;
		$sameDescrPos='';
		$foundAct=0;
		if($action['act_reference']!='new')
			$actExists=sqlQ('SELECT Action_Number FROM report_action_list WHERE Action_Number="'.$action['act_reference'].'"');
		if($action['act_reference']=='new' || $actExists['Action_Number']==''){
			$sameDescrArr=SqlLi("SELECT DISTINCT Action_Number,Action_Holder FROM report_action_list WHERE Description='$actData[actiondescription]' AND MSN='$MSN' AND prog='$prog' AND revT='$actRevT' AND crit='$crId'");
			if(is_array($sameDescrArr)){
				foreach($sameDescrArr as $k=>&$v){
					if(is_array($actAppArr[$crId][$v['Action_Number']]))
						foreach($actAppArr[$crId][$v['Action_Number']] as &$acva){
							if(in_array($acva,$caArr) && $foundAct==0){
								$sameDescrPos=$k;
								$foundAct=1;
							}
						}
				}
				if($foundAct==1){
					$actHoldQry=($actData[actionholder]!=$sameDescrArr[$sameDescrPos]['Action_Holder'])?",Action_Holder='$actData[actionholder]',Action_Holder_Email=''":'';
					$existingActNum=$sameDescrArr[$sameDescrPos]['Action_Number'];
				}
			}
			if($foundAct==0){
				$actCaWp=(count($newActApp)>1)?$wp:$newActApp[0];
				$actNum=genActNum($MSN,$prog,$actRevT,$actCaWp);
				SqlLQ("INSERT INTO report_action_list (Entry_Date,MSN,prog,revT,crit,Action_Number,Description,Creation_Date,Completion_Date,actStat,Action_Holder)VALUES(NOW(),'$MSN','$prog','$actRevT','$crId','$actNum','$actData[actiondescription]','$actData[actioncreationdate]','$actData[actionduedate]','$actStat','$actData[actionholder]')");
				$existingActNum=$actNum;
			}
		}
		$oldActNum=($existingActNum!='')?$existingActNum:$action['act_reference'];
		if(($action['act_reference']!='new' || $foundAct==1) && $actExists['Action_Number']!='')
			SqlLQ("UPDATE report_action_list SET Creation_Date='$actData[actioncreationdate]',Completion_Date='$actData[actionduedate]',actStat='$actStat'$actHoldQry WHERE Action_Number='$oldActNum'");
		
		// VVV CA Applicability Update VVV
		$cawpList=SqlSLi("SELECT ca FROM cawp WHERE wp='$wp'",'ca','p12');
		$cawpList[]=$wp;
		$actApp=($newActApp[0]==$wp)?'wp':'ca';

		if($revT=='FDA for Electric')$revT='FDA El';
		
		$actCaWpApp=SqlBool("SELECT cawp FROM report_actapp WHERE actNum='$oldActNum'",'cawp');
		if($actApp=='wp'){
			if($actCaWpApp[$wp]!=1){
				if(count($actCaWpApp)>0)SqlLQ("DELETE FROM report_actapp WHERE actNum='$oldActNum'");
				SqlLQ("INSERT INTO report_actapp (prog,revT,msn,crit,actNum,cawp)VALUES('$prog','$revT','$MSN','$crId','$oldActNum','$wp')");
			}
		}else{
			foreach($cawpList as &$c){
				if($actCaWpApp[$c] && !$caValidity[$c])$arrToDel[]=$c;
				elseif(!$actCaWpApp[$c] && $caValidity[$c])$arrToAdd[]="('$prog','$revT','$MSN','$crId','$oldActNum','$c')";
			}
			if(is_array($arrToDel))SqlLQ("DELETE FROM report_actapp WHERE actNum='$oldActNum' AND cawp='".implode("' OR cawp='",$arrToDel)."'");
			if(is_array($arrToAdd))SqlLQ("INSERT INTO report_actapp (prog,revT,msn,crit,actNum,cawp)VALUES".implode(",",$arrToAdd));	
		}
		
		// VVV RID Update VVV
		if(!is_array($rid['ridtitle']) && !is_array($rid['rid_creation_date']) && !is_array($rid['ridholder']) && !is_array($rid['rid_completion_date'])){
			if($ridInserted[$rid['ridid']]!=1){
				if($rid['ridid']!=''){
					$ridId=$rid['ridid'];
					updateRid($rid,$rid['ridid']);
					$ridInserted[$rid['ridid']]=1;
				}else{
					$sameDescrRid=SqlQ('SELECT r.rid_id 
						FROM report_rid AS r 
						INNER JOIN report_action_list AS a ON r.rid_id=a.rid
						WHERE r.rid_title="'.$rid['ridtitle'].'" AND a.MSN="'.$MSN.'" AND a.prog="'.$prog.'" AND a.revT="'.$actRevT.'" AND a.crit="'.$crId.'"');
					if($sameDescrRid){
						$ridId=$sameDescrRid['rid_id'];
						updateRid($rid,$ridId);
						$ridInserted[$ridId]=1;
					}else{
						$ridCode=newActionNumber($prog,$revT,$MSN,$wp,'rid');
						$ridHolderId=(!is_array($rid['ridholderid']))?$rid['ridholderid']:getUserId($rid['ridholder']);
						SqlLQ('INSERT INTO report_rid (rid_code,rid_title,rid_status,rid_holder,rid_creation_date,rid_completion_date) VALUES ("'.$ridCode.'","'.$rid['ridtitle'].'","'.$rid['ridstatus'].'","'.$ridHolderId.'","'.$rid['rid_creation_date'].'","'.$rid['rid_completion_date'].'")');
						$lastRidIdQry=SqlQ('SELECT rid_id FROM report_rid ORDER BY rid_id DESC LIMIT 1');
						$ridId=$lastRidIdQry['rid_id'];
					}
					$ridInserted[$ridId]=1;
				}
				if($ridId=='')$ridId=0;
				SqlLQ('UPDATE report_action_list SET rid="'.$ridId.'" WHERE Action_Number="'.$oldActNum.'"');
			}
		}
	}
}
function checkAction($actionRaw,&$a0Config){
	if(!is_array($actionRaw['actiondescription'])){
		if($a0Config['a0_version']==''){
			$a0Config['a0_version']=($action['WPCAApp'])?1:0;
		}
		$action=arrayNormalized($actionRaw);
		if($a0Config['a0_version']>0){
			if(!is_array($action['WPCAApp'])){
				$actionApplicability[]=$action['WPCAApp'];
			}elseif(is_array($action['WPCAApp']['value'])){
				foreach($action['WPCAApp']['value'] as &$a){
					$actionApplicability[]=$a;
				}
			}else $actionApplicability[]=$action['WPCAApp']['value'];
		}else $actionApplicability[]=$a0Config['ca'];
		if($a0Config['a0_version']<2){
			
		}
	}
}
function checkCriteria_($criteria,&$MSN,&$prog,&$revT,&$ca,&$wp,&$crPreset,&$crStat,&$statA,&$crStatPos,&$caLock,&$actsInserted,&$actRevTArr,&$actQry,&$actAppArr,&$caArr,&$ridInserted){
	$actRevT=$actRevTArr[$revT];
	$criteriaNorm=arrayNormalized($criteria);
	if($crStat[$crStatPos[$criteriaNorm['crId']]])foreach($crStat[$crStatPos[$criteriaNorm['crId']]] as $f=>&$v)$crStatDb[$f]=$v;
	$crPr=$actRevTArr[$crPreset[$criteriaNorm['crId']]];
	$crStXML=$statA[$criteriaNorm['status']];
	if(!$crStatDb && ($criteriaNorm['status']!=0 || $criteriaNorm['action_by']!='' || $criteriaNorm['comment']!=''))
		SqlLQ("INSERT INTO report_crstat (preset,MSN,ca,crId,status,focpoint,comments) VALUES ('$crPr','$MSN','$ca','$criteriaNorm[crId]','$crStXML','$criteriaNorm[action_by]','$criteriaNorm[comment]')");
	elseif(($crStatDb['status']!=$crStXML || $crStatDb['focpoint']!=$criteriaNorm['action_by'] || $crStatDb['comments']!=$criteriaNorm['comment']) && ($crStXML!=0 || $criteriaNorm['action_by']!='' || $criteriaNorm['comment']!=''))
		SqlLQ("UPDATE report_crstat SET status='$crStXML',focpoint='$criteriaNorm[action_by]',comments='$criteriaNorm[comment]' WHERE MSN='$MSN' AND ca='$ca' AND crId='$criteriaNorm[crId]'");
	elseif($crStatDb && ($crStatDb['focpoint']=='' && $crStatDb['comments']=='' && $crStXML==0))
		SqlLQ("DELETE FROM report_crstat WHERE MSN='$MSN' AND ca='$ca' AND crId='$criteriaNorm[crId]'");
	if($actsInserted==false){
		if($criteria['rid']['ridcode'] || is_array($criteria['rid']['ridcode'])){
			actionCheckerLauncher($criteria['rid']['action'],$MSN,$prog,$revT,$ca,$wp,$criteria['crId'],$statA,$caLock,$actQry,$actAppArr,$caArr,$actRevTArr,$criteria['rid'],$ridInserted);
		}elseif($criteria['rid'][0]['ridcode'] || is_array($criteria['rid'][0]['ridcode'])){
			foreach($criteria['rid'] as &$rid)
				actionCheckerLauncher($rid['action'],$MSN,$prog,$revT,$ca,$wp,$criteria['crId'],$statA,$caLock,$actQry,$actAppArr,$caArr,$actRevTArr,$rid,$ridInserted);
		}else{
			$emptyRid=array();
			actionCheckerLauncher($criteria['action'],$MSN,$prog,$revT,$ca,$wp,$criteria['crId'],$statA,$caLock,$actQry,$actAppArr,$caArr,$actRevTArr,$emptyRid,$ridInserted);
		}
	}
}

function checkCriteria($criteriaRaw,&$a0Config){
	$criteria=arrayNormalized($criteriaRaw);
	
	if($criteria['crId']!=''){
		if(!is_array($a0Config['old_criteria_id'])){
			$a0Config['old_criteria_id']=SqlAsArr('SELECT review_criteria_id,old_id
															FROM dr_review_criteria AS c
																INNER JOIN dr_review_group AS g ON c.review_group=g.review_group_id
															WHERE g.review_profile='.$a0Config['review_profile'],'old_id','review_criteria_id');
		}
		$criteria['criteria_id']=$a0Config['old_criteria_id'][$criteria['crId']];
	}
	
	if(is_array($a0Config['db_criteria_status'][$a0Config['ca']])){
		SqlLQ('UPDATE dr_criteria_status SET criteria_status="'.$criteria['status'].'",criteria_focal_point="'.$criteria['action_by'].'",criteria_comments="'.$criteria['comment'].'"
					WHERE msn="'.$a0Config['msn'].'" AND ca="'.$a0Config['ca'].'" AND review_criteria="'.$criteria['criteria_id'].'"');
	}else{
		SqlLQ('INSERT INTO dr_criteria_status (msn,ca,review_criteria,criteria_status,criteria_focal_point,criteria_comments)
					VALUES ("'.$a0Config['msn'].'","'.$a0Config['ca'].'","'.$criteria['criteria_id'].'","'.$criteria['status'].'","'.$criteria['action_by'].'","'.$criteria['comment'].'")');
	}
	if($a0Config['actions_inserted']==0){
		$rid=$criteria['rid'];
		if($rid['ridcode'] || is_array($rid['ridcode'])){
			actionCheckerLauncher($rid['action'],$a0Config);
		}elseif($rid[0]['ridcode'] || is_array($rid[0]['ridcode'])){
			foreach($criteria['rid'] as &$r){
				actionCheckerLauncher($r['action'],$a0Config);
			}
		}else{
			$emptyRid=array();
			ctionCheckerLauncher($criteria['action'],$a0Config);
		}
	}
}

function xmlError($errorCase){
	header('Location: report.php?xml_error='.$errorCase);
	exit();
}
function dom_to_array($root){
	$result=array();
	if ($root->hasAttributes()){
		$attrs=$root->attributes;
		foreach($attrs as $i=>&$attr)$result[$attr->name]=utf8_decode(addslashes(trim($attr->value)));
	}
	$children=$root->childNodes;
	if ($children->length==1){
		$child=$children->item(0);
		if ($child->nodeType==XML_TEXT_NODE){
			$result['_value']=$child->nodeValue;
			if(count($result)==1)return utf8_decode(addslashes(trim($result['_value'])));
			else return utf8_decode(addslashes(trim($result)));
		}
	}
	$group=array();
	for($i=0;$i<$children->length;$i++){
		$child=$children->item($i);
		if (!isset($result[$child->nodeName]))
			$result[$child->nodeName]=dom_to_array($child);
		else{
			if (!isset($group[$child->nodeName])){
				$tmp=$result[$child->nodeName];
				$result[$child->nodeName]=array($tmp);
				$group[$child->nodeName]=1;
			}
			$result[$child->nodeName][]=dom_to_array($child);
		}
	}
	return $result;
}
function genActNum($MSN,$prog,$actRevT,$ca){
	$actRevTArr=array('CR (MAT-A)'=>'CR','PDR'=>'PDR','CDR'=>'CDR','FDA'=>'FDA','FHC'=>'FHC','FDA El'=>'FEL','FDA for Electric'=>'FEL','FEL'=>'FEL','Delta FDA/SDA'=>'DFS','PDR NEO'=>'PDN','PDR NEO FUS'=>'PNF','MG5'=>'MG5','MG5 NSDW'=>'M5N');
	$progCode=array('A400M'=>'M','A350'=>'W','A380'=>'L','SA/LR'=>'F','SA_P2F'=>'E');
	$Std_MSN=substr('000',0,4-strlen($MSN)).$MSN;
	$actList=SqlSLi("SELECT Action_Number FROM report_action_list WHERE MSN='$MSN' AND prog='$prog' AND revT='$actRevT'",'Action_Number');
	$actMax=0;
	foreach($actList as $a){
		$actSplit=split('-',$a);
		$actNum=end($actSplit);
		if(stristr($a,$ca))if($actNum>$actMax)$actMax=$actNum;
	}
	$actMax++;
	$Action_Number=$progCode[$prog].'-'.$actRevTArr[$actRevT].'-'.$Std_MSN.'-'.$ca.'-'.str_pad($actMax,3,'0',STR_PAD_LEFT);
	return $Action_Number;
}
function getXmlValue($field,$newValue,$oldValue){
	if($newValue!=''){
		$xmlValue=$newValue;
	}else{
		$q=SqlQ('SELECT '.$field.'_id FROM c_'.$field.' WHERE '.$field.'="'.$oldValue.'"');
		$xmlValue=$q['msn_id'];
	}
	if($xmlValue=='')xmlError('no_'.$field);
	else return $xmlValue;
	 
}
function updateRid($rid,$ridId){
	$ridHolderId=(!is_array($rid['ridholderid']) && $rid['ridholderid']!='')?$rid['ridholderid']:getUserId($rid['ridholder']);
	SqlLQ('UPDATE report_rid SET rid_title="'.$rid['ridtitle'].'",rid_status="'.$rid['ridstatus'].'",rid_holder="'.$ridHolderId.'",rid_creation_date="'.$rid['rid_creation_date'].'",rid_completion_date="'.$rid['rid_completion_date'].'" WHERE rid_id="'.$ridId.'"');
}

$SESSION=$_SESSION;
$statA=array(0,2,1);
$responsibleCompatibility=array(
	1=>array(1=>'desLead',2=>'desResp',3=>'desQua'),
	2=>array(1=>'spcConf',2=>'spcStrs',3=>'spcProg'),
	3=>array(1=>'manLead',2=>'manResp',3=>'manQua'),
	4=>array(1=>'',2=>'',3=>'',4=>'',5=>'',6=>'',7=>''));

//$MSN=$SESSION['MSN'];
//$issueArray=array('A','B','C','D','E','F','G','H','J','K','L','M','N','P','Q','R','S','T','U','V','W','Y','Z');

//$usr=$SESSION['User'];

$file=$_FILES['csvFile'];
if($file['error'] == UPLOAD_ERR_OK && end(explode(".", $file['name']))=='xml'){
	$fileData=file_get_contents($file['tmp_name']);
	$root=new DOMDocument();
	$root->load($file['tmp_name']);
	$fileArray=dom_to_array($root);
	
	$mainInfo=$fileArray['A0Report']['part'];
	
	$a0Version=$mainInfo['a0_version'];
	$xmlKey=$mainInfo['key'];
	
	$program=getXmlValue('program',$mainInfo['program_id'],$mainInfo['program']);
	$coe=getXmlValue('coe',$mainInfo['coe'],'Fuselage/Cabin');
	$msn=getXmlValue('msn',$mainInfo['msn_id'],$mainInfo['MSN']);
	
	$wpTxt=($mainInfo['inWp'])?$mainInfo['inWp']:$mainInfo['wp'];
	$wp=getXmlValue('wp',$mainInfo['wp_id'],$wpTxt);
	
	//VVV CA VVV
	if($mainInfo['ca_id']!=''){
		$caString=$mainInfo['ca_id'];
	}else{
		$caTxt=($mainInfo['inCa'])?$mainInfo['inCa']:$mainInfo['ca'];
		$caQry=SqlQ('SELECT GROUP_CONCAT(ca_id SEPARATOR ",") AS ca_string FROM c_ca WHERE ca IN("'.str_replace(',','","',str_replace(' ','',$caTxt)).'")');
		$caString=$caQry['ca_string'];
	}
	if($reviewProfile=='')xmlError('no_ca');
	else $caArray=explode(',',$caString);
	
	//VVV Review Profile VVV
	if($mainInfo['review_profile']!=''){
		$reviewProfile=$mainInfo['review_profile'];
	}else{
		$reviewProfileTxt=($mainInfo['inType'])?$mainInfo['inType']:$mainInfo['type'];
		$reviewProfileQry=SqlQ('SELECT review_profile_id FROM dr_review_profile WHERE program='.$program.' AND coe='.$coe.' AND review_type="'.$reviewProfileTxt.'"');
		$reviewProfile=$reviewProfileQry['review_profile_id'];
	}
	if($reviewProfile=='')xmlError('no_review_profile');
	
	$a0Config=array('a0_version'=>$a0Version,'program'=>$program,'coe'=>$coe,'msn'=>$msn,'wp'=>$wp,'review_profile'=>$reviewProfile);
	
	/*$qry=mysql_query("SELECT crit,actNum,cawp FROM report_actapp WHERE prog='$SESSION[prog]' AND revT='$revT' AND msn='$MSN'",$mh1) or die(mysql_error());
	while($r=mysql_fetch_assoc($qry))
		$actAppArr[$r['crit']][$r['actNum']][]=$r['cawp'];*/
	
	$validKey=sqlQ('SELECT dr_a0_report_id,object,a0_report_upload_done
					FROM dr_a0_report
					WHERE msn='.$msn.'
						AND review_profile='.$reviewProfile.'
						AND xml_lock="'.$mainInfo['key'].'"
						AND user='.$SESSION['user']['user_id'].'
					ORDER BY a0_report_creation DESC
					LIMIT 1');
						
	if(($validKey=='' || $validKey['a0_report_upload_done']==1) && checkPermission('superadmin','superadmin',0,'check',$SESSION)==0)xmlError('no_rights');
	
	if($validKey!='')createLog('dr_log','a0_report_id','upload',$validKey['dr_a0_report_id'],'','',$SESSION);
	
	$review=SqlAsLi('SELECT review_id,ca,review_done,review_status FROM dr_review WHERE ca IN('.$caString.') AND msn='.$msn.' AND review_profile='.$reviewProfile,'ca');
	
	$a0Config['db_criteria_status']=SqlBDAsLi('SELECT ca,review_criteria,criteria_status,criteria_focal_point,criteria_comments FROM dr_criteria_status WHERE msn='.$msn.' AND ca IN('.$caString.')','ca','review_criteria',0,0);
	
	$a0Config['actions_inserted']=0;
	
	foreach($caArray as &$ca){
		
		$a0Config['ca']=$ca;
		
		if($review[$ca]['review_done']!=1 || $review[$ca]['review_status']!=$mainInfo['ovStat']){
			if($review[$ca]['review_id']==''){
				SqlLQ('INSERT INTO dr_review (ca,msn,review_profile,review_done,review_status) VALUES ('.$ca.','.$msn.','.$reviewProfile.',1,'.$mainInfo['ovStat'].')');
			}else
				SqlLQ('UPDATE dr_review SET review_done=1,review_status='.$mainInfo['ovStat'].' WHERE review_id='.$review[$ca]['review_id']);
			}
		}
	
		if($validKey!='')SqlLQ('UPDATE dr_a0_report SET a0_report_upload=NOW(),a0_report_upload_done,user=0 WHERE a0_report_id="'.$validKey['a0_report_id'].'"');
		
		$responsible=getResponsibles($program,$SESSION,1,$ca,'',1);

		foreach($responsibleCompatibility as $group=>&$c){
			foreach($c as $position=>&$respRole){
				if($respRole!='' && $mainInfo[$respRole]!=''){
					$respName=$mainInfo[$respRole];
				}elseif($mainInfo['responsiblegroup_'.$group]['responsible_'.$group.'_'.$position]['name']!=''){
					$respName=$mainInfo['responsiblegroup_'.$group]['responsible_'.$group.'_'.$position]['name'];
				}
				
				if($respName!=addslashes($responsible['name'][$group][$position])){
					if($responsible['id'][$group][$position]){
						SqlLQ('UPDATE dr_responsible SET responsible="'.$respName.'" WHERE responsible_id="'.$responsible['id'][$group][$position].'"','p12');
					}else{
						SqlLQ('INSERT INTO dr_responsible (ca,responsible_configuration,responsible) VALUES ("'.$ca.'","'.$responsible['config'][$group][$position].'","'.$respName.'")','p12');
					}
				}
			}
		}
		
		$a0Topic=$fileArray['A0Report']['topic-list']['topic'];
		
		if($a0Topic['name']!=''){
			if($a0Topic['case']['crId']!=''){
				checkCriteria($a0Topic['case'],$a0Config);
			}else{
				foreach($a0Topic['case'] as &$criteria){
					checkCriteria($criteria,$a0Config);
				}
			}
		}else foreach($a0Topic as &$crGroup){
			if($crGroup['case']['crId']!=''){
				checkCriteria($crGroup['case'],$a0Config);
			}else{
				foreach($crGroup['case'] as &$criteria){
					checkCriteria($criteria,$a0Config);
				}
			}
		}
		
		$a0Config['actions_inserted']=1;
	}
	
	
	
	
	
	
	
	
	$actsInserted=false;
	$ridInserted=array();
	if($caLock['type']=='wp')$caArr[]=$caLock['ca'];
	foreach($caArr as &$ca){
		SqlLQ("DELETE FROM report_xml_lock WHERE prog='$prog' AND revT='$actRevT' AND MSN='$MSN' AND (ca='$caLock[ca]'$addqry) AND user='$usr'");
		
		$offRef=$mainInfo['offRef'];
		$ovStat=$mainInfo['ovStat'];
		$newIssue=($mainInfo['issue'])?(int)in_array($mainInfo['issue'],$issueArray):'A';
		$newIssue--;
		getCaStat($SESSION,$prog,$MSN,$ca,$ovStat,'',$caLock['type']);

		
		$responsible=getResponsibles($SESSION['progId'],$ca,$p12);
		
		foreach($responsibleCompatibility as $group=>&$c){
			foreach($c as $position=>&$respRole){
				if($respRole!='' && $mainInfo[$respRole]!=''){
					$respName=$mainInfo[$respRole];
				}elseif($mainInfo['responsiblegroup_'.$group]['responsible_'.$group.'_'.$position]['name']!=''){
					$respName=$mainInfo['responsiblegroup_'.$group]['responsible_'.$group.'_'.$position]['name'];
				}
				
				if($respName!=addslashes($responsible['name'][$group][$position])){
					if($responsible['id'][$group][$position]){
						SqlLQ('UPDATE dr_responsible SET responsible="'.$respName.'" WHERE responsible_id="'.$responsible['id'][$group][$position].'"','p12');
					}else{
						SqlLQ('INSERT INTO dr_responsible (ca_name,responsible_configuration,responsible) VALUES ("'.$ca.'","'.$responsible['config'][$group][$position].'","'.$respName.'")','p12');
					}
				}
			}
		}
		
		$xmlUpExists=SqlQ("SELECT issue FROM report_xmlup WHERE prog='$prog' AND revT='$actRevT' AND MSN='$MSN' AND ca='$ca'");
		if($xmlUpExists)SqlLQ("UPDATE report_xmlup SET ref='$offRef',issue='$newIssue' WHERE prog='$prog' AND revT='$actRevT' AND MSN='$MSN' AND ca='$ca'");
		else SqlLQ("INSERT INTO report_xmlup (prog,revT,MSN,ca,ref,issue,issueDate) VALUES ('$prog','$actRevT',$MSN,'$ca','$offRef','$newIssue',NOW())");
		
		$qry=mysql_query("SELECT crId,status,focpoint,comments FROM report_crstat WHERE (preset='$actRevT' OR preset='') AND MSN='$MSN' AND ca='$ca'", $mh1) or die(mysql_error());
		$crStat=array();
		$crStatPos=array();
		$i=0;
		while($row=mysql_fetch_assoc($qry)){
			$crStatPos[$row['crId']]=$i;
			foreach($row as $f=>&$v)$crStat[$i][$f]=$v;
			$i++;
		}
		$crPreset=SqlAsArr("SELECT md5Id,preset FROM report_dyn_inhalt WHERE preset='$revT' OR preset=''",'md5Id','preset');
		
		if($fileArray['A0Report']['topic-list']['topic']['name']!=''){
			if($fileArray['A0Report']['topic-list']['topic']['case']['crId']!='')
				checkCriteria($fileArray['A0Report']['topic-list']['topic']['case'],$MSN,$prog,$revT,$ca,$wp,$crPreset,$crStat,$statA,$crStatPos,$caLock,$actsInserted,$actRevTArr,$actQry,$actAppArr,$caArr,$ridInserted);
			else foreach($fileArray['A0Report']['topic-list']['topic']['case'] as &$criteria)
				checkCriteria($criteria,$MSN,$prog,$revT,$ca,$wp,$crPreset,$crStat,$statA,$crStatPos,$caLock,$actsInserted,$actRevTArr,$actQry,$actAppArr,$caArr,$ridInserted);
		}else foreach($fileArray['A0Report']['topic-list']['topic'] as &$crGroup){
			if($crGroup['case']['crId']!='')
				checkCriteria($crGroup['case'],$MSN,$prog,$revT,$ca,$wp,$crPreset,$crStat,$statA,$crStatPos,$caLock,$actsInserted,$actRevTArr,$actQry,$actAppArr,$caArr,$ridInserted);
			else foreach($crGroup['case'] as &$criteria)
				checkCriteria($criteria,$MSN,$prog,$revT,$ca,$wp,$crPreset,$crStat,$statA,$crStatPos,$caLock,$actsInserted,$actRevTArr,$actQry,$actAppArr,$caArr,$ridInserted);
		}
		$actsInserted=true;
	}
	
	$Log='prog: '.$prog.' revT: '.$revT.' MSN: '.$MSN.' ca: '.$ca.' wp: '.$MSN.' wp: '.$MSN;
	$Type='XML Uploaded';
	Create_Log($Log,$Type);
	
	header("Location: report.php");
}else die('Cannot upload.Error:'.$file['error']);
//echo(microtime()-$startTime)*1000,' ms to process'?>