<?php
function download($type,$file,$name){
	header('Cache-Control: max-age=60');
	switch($type){
		case 'xml':
			header('Content-type: application/xml; charset=UTF-8');
		break;
		default:
			header('Content-type: application/octet-stream');
		break;
	}
	header('Content-Disposition: attachment; filename='.urldecode($name));
	readfile($file);
}?>