<?php
require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('form.php');

$GET=cleanArray($_GET);

if($GET['update']=="dr_action")
{
	$actionQryForLog=SqlQ('SELECT * FROM dr_action WHERE action_id="'.$GET['id'].'"');
	$fakeLogArrayNew = array();
	$fakeLogArrayNew[$GET['set']] = $GET['new_value'];

	$actionUpdateString=getFormUpdate($fakeLogArrayNew,$actionQryForLog,'action','action',$actionQryForLog['action_id'],$SESSION,array('action_code','wp'));
}

SqlLQ('UPDATE '.$GET['update'].' SET '.$GET['set'].' = "'.$GET['new_value'].'" WHERE '.$GET['type'].' = '.$GET['id']);

$answer=$GET['update'].'_'.$GET['id'];

storeSession($SESSION);
echo 'OK|||'.$answer;
?>