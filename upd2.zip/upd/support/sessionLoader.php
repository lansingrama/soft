<?php
if(!is_array($_SESSION))
{
	session_start();
}
if($sessionLoaded!=1 && ($SESSION['user'] || $_SESSION['user']))
{
	$user=($SESSION['user'])?$SESSION['user']:$_SESSION['user'];
	$viewAs=($user['view_as']=='')?$user['user_id']:$user['view_as'];
	$_SESSION=array();
	$SESSION=array();
	$SESSION['user']=$user;
	
	$SESSION['object_table']=SqlAsArr('SELECT table_id,table_name FROM c_table WHERE table_name<>""','table_name','table_id');
	$SESSION['object']=SqlAsArr('SELECT object_id,object FROM c_object WHERE object<>""','object','object_id');
	$SESSION['user_action']=SqlAsArr('SELECT user_action_id,user_action FROM c_user_action WHERE user_action<>""','user_action','user_action_id');
	if($SESSION['tool_id']=='')
	{
		$toolId=SqlQ('SELECT tool_id FROM c_tool WHERE code="DR"');
		$SESSION['tool_id']=$toolId['tool_id'];
	}
	
	$qry=mysql_query('SELECT object,action,applicability FROM c_permission WHERE user='.$viewAs.' AND tool='.$SESSION['tool_id'].' AND active=1',$p12) or die(mysql_error());
	while($p=mysql_fetch_assoc($qry))
	{
		$SESSION['permission'][$p['object']][$p['action']][$p['applicability']]=1;
	}
	
	$qry=mysql_query('SELECT object,action,applicability,filter_value FROM dr_user_filter WHERE user='.$viewAs,$p12) or die(mysql_error());
	while($f=mysql_fetch_assoc($qry))
	{
		$SESSION['filter'][$f['object']][$f['action']][$f['applicability']]=$f['filter_value'];
	}
	
	$qry=mysql_query('SELECT p.review_profile_id,t.review_type
						FROM dr_review_profile AS p
							INNER JOIN dr_review_type AS t ON p.review_type=t.review_type_id
					',$p12) or die(mysql_error());
	while($rt=mysql_fetch_assoc($qry))
	{
		$SESSION['review_type'][$rt['review_profile_id']]=$rt['review_type'];
	}


	$currentArea = 0; //JFM 13_05_16
	if(getFilter('area','filter',0,$SESSION)!='')
		$currentArea = getFilter('area','filter',0,$SESSION); //JFM 13_05_16

	$qry=mysql_query('SELECT * FROM dr_allowed_status WHERE area = '.$currentArea
						,$p12) or die(mysql_error()); //JFM 13_05_16

	while($rt=mysql_fetch_assoc($qry)) //JFM 13_05_16
	{
		$SESSION['disabled_statues'][$rt['object']][$rt['status']] = $rt['disabled'];
	}
	
	$qry=mysql_query('SELECT 
							c.column_id,
							c.column_position,
							drt.table_name,
							ts.table_section,
							o1.object			AS column_name,
							ct.table_name		AS column_source,	ct.table_short_name,
							ctype.column_type,
							c.column_title,							c.column_filter_title,c.column_size,c.no_wrap,c.no_status_allowed, c.applicability_needed,
							o2.object			AS date_done,
							o3.object			AS txt_format,
							o4.object			AS additional_info,
							o5.object			AS linked_date,
							dct.title 			AS area_column_title,
							dct.position 		AS area_column_position
						FROM dr_column						AS c
							LEFT JOIN dr_table_section		AS ts		ON c.table_section		=ts.table_section_id
							LEFT JOIN dr_table				AS drt		ON ts.table_source		=drt.table_id
							LEFT JOIN c_object				AS o1		ON c.column_name		=o1.object_id
							LEFT JOIN c_table				AS ct		ON o1.source			=ct.table_id
							LEFT JOIN dr_column_type		AS ctype	ON c.column_type		=ctype.column_type_id
							LEFT JOIN c_object				AS o2		ON c.date_done			=o2.object_id
							LEFT JOIN c_object				AS o3		ON c.txt_format			=o3.object_id
							LEFT JOIN c_object				AS o4		ON c.additional_info	=o4.object_id
							LEFT JOIN c_object				AS o5		ON c.linked_date		=o5.object_id
							LEFT JOIN dr_column_translation AS dct 		ON c.column_id 			=dct.column_
																		AND dct.area 			='.$currentArea.'

						ORDER BY area_column_position, c.column_position ASC
					',$p12) or die(mysql_error());

	while($c=mysql_fetch_assoc($qry))
	{
		$t['table']=$c['column_source'];
		if($c['column_id'])				$t['column_id']				=	$c['column_id']; 			//JFM 13_05_16
		if($c['column_position'])		$t['column_position']		=	$c['column_position']; 		//JFM 13_05_16
		if($c['table_short_name'])		$t['table_short_name']		=	$c['table_short_name'];
		if($c['column_type'])			$t['type']					=	$c['column_type'];
		if($c['column_title'])			$t['title']					=	$c['column_title'];
		if($c['column_title'])			$t['default_title']			=	$c['column_title'];			//JFM 13_05_16
		if($c['area_column_title'])		$t['title']					=	$c['area_column_title'];	//JFM 13_05_16
		if($c['column_filter_title'])	$t['filter']				=	$c['column_filter_title'];
		if($c['date_done'])				$t['done']					=	$c['date_done'];
		if($c['txt_format'])			$t['txt_format']			=	$c['txt_format'];
		if($c['additional_info'])		$t['additional_info']		=	$c['additional_info'];
		if($c['no_wrap'])				$t['no_wrap']				=	$c['no_wrap'];
		if($c['column_size'])			$t['column_size']			=	$c['column_size'];
		if($c['linked_date'])			$t['linked_date']			=	$c['linked_date'];
		if($c['no_status_allowed'])		$t['no_status_allowed']		=	$c['no_status_allowed'];
		if($c['applicability_needed'])	$t['applicability_needed']	=	$c['applicability_needed']; // JFM 16_09_13
		
		$SESSION['table'][$c['table_name']][$c['table_section']][$c['column_name']]=$t;
		unset($t);
	}
	
	$qry=mysql_query('SELECT user_id,name,surname,email FROM c_user',$p12) or die(mysql_error());
	while($u=mysql_fetch_assoc($qry))
	{
		$name=$u['name'];
		$surname=$u['surname'];
		$email=$u['email'];
		$SESSION['user_list'][$u['user_id']]=$name.' '.$surname;
		$SESSION['user_email'][$u['user_id']]=$email;//JFM 02_10_14
	}
	
	$SESSION['mixed_value']=array('date'=>'****-**-**','id'=>'m','status'=>4,'text'=>'mixed',''=>'m');
	
	/* JFM 28_10_15
	setStandardValue('max_results','view',0,100,$SESSION,1); 
	setStandardValue('repeat_header','view',0,0,$SESSION,1); 
	setStandardValue('header_frequency','view',0,23,$SESSION,1);
	setStandardValue('disabled_ca','view',0,1,$SESSION,1);*/
	
	if(getFilter('max_results','view',0,$SESSION)=='') 		modifyFilter('max_results','view',0,100,$SESSION,1);
	if(getFilter('repeat_header','view',0,$SESSION)=='') 	modifyFilter('repeat_header','view',0,0,$SESSION,1);
	if(getFilter('header_frequency','view',0,$SESSION)=='') modifyFilter('header_frequency','view',0,23,$SESSION,1);
	if(getFilter('disabled_ca','view',0,$SESSION)=='') 		modifyFilter('disabled_ca','view',0,1,$SESSION,1);
	
	if(getFilter('program','filter',0,$SESSION)!='' && 
		(checkPermission('program_id','view',getFilter('program','filter',0,$SESSION),'check',$SESSION)!=1 || 
			checkPermission('coe_id','view',getFilter('coe','filter',0,$SESSION),'check',$SESSION)!=1)
		)
	{
		modifyFilter('program','filter',0,'',$SESSION,1);
		modifyFilter('coe','filter',0,'',$SESSION,1);
	}
	
	if(getFilter('coe','filter',0,$SESSION)!='' && 
		checkPermission('coe_id','view',getFilter('coe','filter',0,$SESSION),'check',$SESSION)!=1)
	{
		modifyFilter('coe','filter',0,'',$SESSION,1);
	}	
	
	/* JFM 15_09_15
	if(getFilter('last_change_log_displayed','view',0,$SESSION)=='')
	{
		$allowedProgram=allowedSimpleObject('program','program',$SESSION,'c_');
		$allowedCoe=allowedSimpleObject('coe','coe',$SESSION,'c_');
		 
		if(is_array($allowedProgram))
		{
			foreach($allowedProgram as $programId=>$program)
			{
				hideAllResponsible(1,$SESSION,$programId);
			}
			if(is_array($allowedCoe))
			{
				foreach($allowedCoe as $coeId=>$coe)
				{
					$reviewProfileList=allowedReviews($SESSION,'view','program='.$programId.' AND coe='.$coeId);
					if(is_array($reviewProfileList))
					{
						if(count($reviewProfileList)==1)
						{
							modifyFilter('criteria_status','hide',key($reviewProfileList),1,$SESSION,1);
						}
						else
						{
							foreach($reviewProfileList as $reviewId=>$review)
							{
								hideAllReviewColumns($reviewId,1,$SESSION);
							}
						}
					}
				}
			}
		}
	}*/
	
	$sessionLoaded=1;
	
	file_put_contents(dirname(__FILE__).'/../session/'.session_id().'.session',serialize($SESSION));	
}?>