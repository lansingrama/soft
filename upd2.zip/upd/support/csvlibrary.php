<?php

require_once('../security/checkExpiredSession.php');
require_once('../../support.php');
require_once('../../common/php/common.php');
require_once('../../common/php/zip.lib.php');
require_once('localSupport.php');
require_once('form.php');
require_once ('../../common/php/PHPExcel1/Classes/PHPExcel.php');
require_once ('../../common/php/PHPExcel1/Classes/PHPExcel/IOFactory.php');

$POST = cleanArray($_POST);
function formatValueForXML($string)
{
return utf8_encode(str_replace("&#8230;", "",str_replace(">", "&gt;",str_replace("<", "&lt;",str_replace("&", "&amp;", $string)))));
        
}
//SETUP IDS
//---------------------------------------------------
$area = SqlQ('SELECT area FROM c_area WHERE area_id=' . getFilter('area', 'filter', 0, $SESSION));
$program = implode(',', $POST['program']);
$coe = implode(',', $POST['coe']);
$msn = implode(',', $POST['msn']);
$reviewType = implode(',', $POST['review_type']);
$ca = implode(',', $POST['ca']);
$msn = implode(',', $POST['msn']);

$statusColourMap = array(0 => 'ef787f', 1 => 'f8e463', 2 => '92c362', 3 => '68accf');
$statusWordMap = array(0 => 'RED', 1 => 'AMBER', 2 => 'GREEN', 3 => 'BLUE'); 
$wingdingsMap = array(0 => ' ', 1 => 'i', 2 => 'm', 3 => 'g', 4 => 'k', 5 => 'h');
$progressColourMap = array(0 => '000000', 1 => 'ef343f', 2 => 'f8d707', 3 => '81c341', 4 => '008cf');
$border_style = array('borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000000'),)));
$caNames = SqlSLi('SELECT ca FROM c_ca WHERE ca_id IN (' . $ca . ')', 'ca');
$allCaNames = formatValueForXML(implode(',', $caNames));

$reviewProfileQry = SqlSLi('SELECT review_profile_id FROM dr_review_profile 
					WHERE program IN (' . $program . ')
					AND coe IN (' . $coe . ')
					AND review_type IN (' . $reviewType . ')', 'review_profile_id');

$reviewProfile = implode(',', $reviewProfileQry);

//CALCULATE REVIEW
//---------------------------------------------------

$where = array();

if (!empty($POST['from']))
    $where[] = 'AND r.review_date > "' . $POST['from'] . ' 00:00:00"';
if (!empty($POST['to']))
    $where[] = 'AND r.review_date < "' . $POST['to'] . ' 23:59:59"';

$reviewID = SqlLi('SELECT r.review_id, r.review_done, r.validation_date, r.continuous_assessment, r.review_status, r.review_date,
						msn.msn, 
						coe.coe, 
						pro.program, 
						rt.review_type, 
						ca.ca, 
						per.perimeter,
						act.action_id, act.action_status, act.action_code, act.action_description, act.action_remark, act.action_completion, act.action_holder_name, act.action_validator_name,
						CONCAT(u1.name," ",u1.surname) AS action_holder_txt, CONCAT(u2.name," ",u2.surname) AS action_validator_txt,				
						act2.action_id AS action_id_2, 
						act2.action_status AS action_status_2, 
						act2.action_code AS action_code_2, 
						act2.action_description AS action_description_2, 
						act2.action_remark AS action_remark_2, 
						act2.action_completion AS action_completion_2, 
						act2.action_holder_name AS action_holder_name_2, 
						act2.action_validator_name AS action_validator_name_2,
						CONCAT(u4.name," ",u4.surname) AS action_holder_txt_2, CONCAT(u5.name," ",u5.surname) AS action_validator_txt_2,				
						rsk.risk_id, rsk.risk_status, rsk.risk_code, rsk.risk_description, rsk.risk_action, rsk.risk_remarks, rsk.risk_holder_name, rsk.severity, rsk.occurrence, rsk.detection,
						CONCAT(u3.name," ",u3.surname) AS risk_holder_txt,
						cas.odd, cas.id, cas.progress_trend, cas.sourcing
						FROM dr_review AS r
							INNER JOIN dr_review_applicability 		AS ra 	ON 	r.review_id=ra.review
							INNER JOIN c_ca 						AS ca 	ON 	ca.ca_id=ra.ca
							INNER JOIN c_perimeter 					AS per 	ON 	per.perimeter_id=ca.perimeter
							INNER JOIN dr_review_profile 			AS rp 	ON 	r.review_profile=rp.review_profile_id
							INNER JOIN c_coe 						AS coe 	ON 	coe.coe_id=rp.coe
							INNER JOIN c_program 					AS pro 	ON 	pro.program_id=rp.program
							INNER JOIN c_msn 						AS msn 	ON 	msn.msn_id=r.msn
							INNER JOIN dr_review_type 				AS rt 	ON 	rt.review_type_id=rp.review_type
							INNER JOIN dr_action_applicability 		AS aa 	ON 	aa.ca=ca.ca_id
							INNER JOIN dr_review_group 				AS grp  ON grp.review_type = rt.review_type_id 
							INNER JOIN dr_review_criterion 			AS crit ON crit.review_group=grp.group_id 
							LEFT JOIN dr_action 					AS act  ON act.action_id = aa.action 
																			AND act.msn = msn.msn_id 
																			AND act.criteria=crit.review_criterion_id
							LEFT JOIN dr_action 					AS act2 ON  act2.review = r.review_id
							LEFT JOIN c_user 						AS u1 	ON 	u1.user_id=act.action_holder
							LEFT JOIN c_user 						AS u2 	ON  u2.user_id=act.action_validator
							LEFT JOIN c_user 						AS u4 	ON 	u4.user_id=act2.action_holder
							LEFT JOIN c_user 						AS u5 	ON  u5.user_id=act2.action_validator
							LEFT JOIN dr_risk 						AS rsk 	ON  rsk.ca=ca.ca_id
							LEFT JOIN c_user 						AS u3 	ON  u3.user_id=rsk.risk_holder
							LEFT JOIN dr_ca_status 					AS cas 	ON 	cas.ca=ca.ca_id
						WHERE rp.review_profile_id IN (' . $reviewProfile . ')
						AND ra.ca IN (' . $ca . ')
						AND r.msn IN (' . $msn . ')
						AND r.validation_complete = 2
						AND r.review_done = 1
						' . implode(' ', $where) . '
						ORDER BY rp.review_profile_order, pro.program, coe.coe, msn.msn, ca.ca, act.action_code');

$reviewTypeNames = array();
$reviewBetterFormatted = array();
$alreadyAddedActions = array();
$alreadyAddedRisks = array();
$reviewIdsArray = array();


$priorityMap = array('Low' => 1, 'Medium' => 2, 'High' => 3);

if (!empty($reviewID)) {
    foreach ($reviewID as $q => $z) {
        $reviewIdsArray[] = $z['review_id'];

        if ($z['odd'] == "0000-00-00")
            $z['odd'] = 'Not Set';
        if ($z['id'] == "0000-00-00")
            $z['id'] = 'Not Set';

        $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['odd']['odd'] = $z['odd'];
        $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['id']['id'] = $z['id'];
        $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend'] = $z['progress_trend'];

        $reviewTypeNames[$z['review_type']] ++;

        $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['status'] = $z['review_status'];
        $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['date'] = $z['review_date'];
        
        if ($z['action_status'] != '' && isset($z['action_status']) && !in_array($z['action_id'], $alreadyAddedActions)) {
            $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total']['action_total'] ++;
            $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total'] ++;

            if ($z['action_status'] < 2) {
                $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total_ongoing']['action_total_ongoing'] ++;
                $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total_ongoing'] ++;
            }

            if (isset($z['action_holder_txt']))
                $actionHolder = $z['action_holder_txt'];
            else
                $actionHolder = $z['action_holder_name'];

            if (isset($z['action_validator_txt']))
                $actionValidator = $z['action_validator_txt'];
            else
                $actionValidator = $z['action_validator_name'];

            $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_' . $z['action_status']].=$z['action_code'] . '---' . $z['action_description'] . '---' . $z['action_remark'] . '---' . $z['action_completion'] . '---' . $actionHolder . '---' . $actionValidator . '-!-';
            $alreadyAddedActions[] = $z['action_id'];
        }

        if ($z['action_status_2'] != '' && isset($z['action_status_2']) && !in_array($z['action_id_2'], $alreadyAddedActions)) {
            $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total']['action_total'] ++;
            $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total'] ++;

            if ($z['action_status_2'] < 2) {
                $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['action_total_ongoing']['action_total_ongoing'] ++;
                $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_total_ongoing'] ++;
            }

            if (isset($z['action_holder_txt_2']))
                $actionHolder = $z['action_holder_txt_2'];
            else
                $actionHolder = $z['action_holder_name_2'];

            if (isset($z['action_validator_txt_2']))
                $actionValidator = $z['action_validator_txt_2'];
            else
                $actionValidator = $z['action_validator_name_2'];

            $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['action_' . $z['action_status_2']].=$z['action_code_2'] . '---' . $z['action_description_2'] . '---' . $z['action_remark_2'] . '---' . $z['action_completion_2'] . '---' . $actionHolder . '---' . $actionValidator . '-!-';
            $alreadyAddedActions[] = $z['action_id_2'];
        }

        if ($z['risk_status'] != '' && isset($z['risk_status']) && !in_array($z['risk_id'], $alreadyAddedRisks)) {
            $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total'] ++;

            if ($z['risk_status'] < 2)
                $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing'] ++;

            if (isset($z['risk_holder_txt']))
                $riskHolder = $z['risk_holder_txt'];
            else
                $riskHolder = $z['risk_holder_name'];

            $rpn = $z['severity'] * $z['occurrence'] * $z['detection'];

            $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_' . $z['risk_status']].=$z['risk_code'] . '---' . $z['risk_description'] . '---' . $z['risk_action'] . '---' . $z['risk_remarks'] . '---' . $rpn . '---' . $riskHolder . '-!-';

            $alreadyAddedRisks[] = $z['risk_id'];
        }
    }

    $reviewIdsArray = array_unique($reviewIdsArray);
}

foreach ($reviewIdsArray as $reviewId) {

    $dofAnnoying = SqlLi('SELECT DISTINCT r.review_id, rch.criterion, rch.criterion_moc, cs.criteria_status,
						msn.msn, 
						coe.coe, 
						pro.program, 
						rt.review_type, 
						ca.ca, 
						per.perimeter
						FROM dr_review AS r
						INNER JOIN dr_review_applicability 		AS ra 	ON  ra.review = r.review_id
						INNER JOIN c_ca 						AS ca 	ON  ca.ca_id = ra.ca
						INNER JOIN dr_review_profile 			AS rp 	ON  rp.review_profile_id = r.review_profile
						INNER JOIN c_coe 						AS coe 	ON  coe.coe_id = rp.coe
						INNER JOIN c_program 					AS pro 	ON  pro.program_id = rp.program
						INNER JOIN dr_review_type 				AS rt 	ON  rt.review_type_id = rp.review_type
						INNER JOIN c_msn 						AS msn  ON  msn.msn_id = r.msn
						INNER JOIN c_perimeter 					AS per 	ON  per.perimeter_id=ca.perimeter
						INNER JOIN dr_review_configuration 		AS rc 	ON  rc.review = r.review_id
						INNER JOIN dr_review_criterion_history 	AS rch 	ON  rch.criterion = rc.criterion
						LEFT  JOIN dr_criteria_status 			AS cs 	ON  cs.review_criteria = rc.criterion
																		AND cs.msn = r.msn
																		AND cs.ca = ca.ca_id
						WHERE r.review_id = ' . $reviewId . '
						AND rch.criterion_valid_from <= r.validation_date
						AND rch.criterion_valid_from != "0000-00-00 00:00:00"');
    foreach ($dofAnnoying as $k => $z) {
        


        $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['total']+=$priorityMap[$z['criterion_moc']];

        if ($z['criteria_status'] != '' && isset($z['criteria_status']) && $z['criteria_status'] > 0 && $z['criteria_status'] < 4)
            $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$z['review_type']]['assessment']+=$priorityMap[$z['criterion_moc']];
    }
}
$slideTitle = 'Airbus Review Tool - Report Generation for ' . formatValueForXML($area['area']) . ' - CW' . date('W / Y');

$objPHPExcel = new PHPExcel();
//$objDrawing = new PHPExcel_Worksheet_Drawing();
//$objDrawing1 = new PHPExcel_Worksheet_Drawing();

$objPHPExcel->getActiveSheet()
                            ->getStyle('A1')
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');

$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A1:D1');

$objPHPExcel->getActiveSheet()->getStyle('A1:D1')->applyFromArray($border_style);
$objPHPExcel->getActiveSheet()->setCellValue('A1',$slideTitle);
$headerStuff = array();

foreach ($reviewTypeNames as $reviewTypeSingle => $value) {
    
    array_push($headerStuff, $reviewTypeSingle);
}
$objPHPExcel->getActiveSheet()
                            ->getStyle('A3:I3')
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');

$objPHPExcel->getActiveSheet()->getStyle('A3:I3')->applyFromArray($border_style);
$objPHPExcel->getActiveSheet()->setCellValue('A3', 'Programme');
$objPHPExcel->getActiveSheet()->setCellValue('B3', 'CoE');
$objPHPExcel->getActiveSheet()->setCellValue('C3', 'HoV');
$objPHPExcel->getActiveSheet()->setCellValue('D3', 'Product');
$objPHPExcel->getActiveSheet()->setCellValue('E3', 'Supplier');
$objPHPExcel->getActiveSheet()->setCellValue('F3', 'Sourcing');
$objPHPExcel->getActiveSheet()->setCellValue('G3', 'ODD');
$objPHPExcel->getActiveSheet()->setCellValue('H3', 'ID');
$objPHPExcel->getActiveSheet()->setCellValue('I3', 'Overall Status');
$length = count($headerStuff);
$k = 'J';
$n = 3;
foreach ($headerStuff as $header1) {
    $objPHPExcel->getActiveSheet()
                            ->getStyle($k.$n)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
    $objPHPExcel->getActiveSheet()->getStyle($k . $n)->applyFromArray($border_style);
    $objPHPExcel->getActiveSheet()->setCellValue($k . $n, $header1);
    $k++;
}
$alreadyAdded = array();
$m = 5;
if (!empty($reviewID)) {

    foreach ($reviewID as $q => $z) {
        if (empty($alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']])) {
            $alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']] = 1;
            $rreview_id = $z['review_id'];
            $rreview_done = $z['review_done'];
            $rvalidation_date = $z['validation_date'];
            $rcontinuous_assesment = $z['continuous_assessment'];
            $rreview_status = $z['review_status'];
            $reviewdate = $z['review_date'];
            $rmsn = $z['msn'];
            $rcoe = $z['coe'];

            $rprogram = $z['program'];
            $rreview_type = $z['review_type'];
            $rca = $z['ca'];
            $rperimeter = $z['perimeter'];
            $rsourcing = $z['sourcing'];
            $rodd = $z['odd'];
            $rid = $z['id'];
                                
				
				
            $objPHPExcel->getActiveSheet()->getStyle("A$m:I$m")->applyFromArray($border_style);
            $objPHPExcel->getActiveSheet()->setCellValue('A' . $m, $rprogram);
            
            $objPHPExcel->getActiveSheet()->setCellValue('B' . $m, $rcoe);
            $objPHPExcel->getActiveSheet()->setCellValue('C' . $m, $rmsn);
           
            $objPHPExcel->getActiveSheet()->setCellValue('D' . $m, $rca);
           
            $objPHPExcel->getActiveSheet()->setCellValue('E' . $m, $rperimeter);
            
            if(isset($z['sourcing']))
            {
                
                $objPHPExcel->getActiveSheet()->setCellValue('F' . $m, $rsourcing);
            
            }
            else
            {
		
                $objPHPExcel->getActiveSheet()
                        ->getStyle('F' . $m)
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setRGB('FFFFFF');
            }
            if(isset($z['odd']) && $z['odd'] != "0000-00-00")
            {
			
                
                $objPHPExcel->getActiveSheet()->setCellValue('G' . $m, $rodd);
            }
            else
            {
                
                
                $objPHPExcel->getActiveSheet()
                        ->getStyle('G' . $m)
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setRGB('FFFFFF');
            
            }
            
            if(isset($z['id']) && $z['id'] != "0000-00-00")
            {
			
                $objPHPExcel->getActiveSheet()->setCellValue('H' . $m, $rid);		
            }
            else
            {
                
                $objPHPExcel->getActiveSheet()
                        ->getStyle('H' . $m)
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setRGB('FFFFFF');
            }
           
           
            if (isset($z['progress_trend'])) {

                

		$progressTrendArray = split('_', $z['progress_trend']);
		$objPHPExcel->getActiveSheet()
	   		    ->getStyle("I$m")
           		    ->getFont()
	    		    ->setBold(true)
	    		    ->setName('Wingdings 3')
            		    ->setSize(13)
            		    ->getColor()->setRGB($progressColourMap[$progressTrendArray[1]]);
		$objPHPExcel->getActiveSheet()->setCellValue("I$m", $wingdingsMap[$progressTrendArray[0]]);

                
                
               // $progressTrendKey = array_key_exists($z['progress_trend'],$progress_map);
               // if($progressTrendKey)
               // {
                   // $progressTrendValue = $progress_map[$z['progress_trend']];
                    
		    //$objDrawing = new PHPExcel_Worksheet_Drawing();

		    //$objDrawing->setPath("../../common/img/$progressTrendValue.png");
                    
                    //$objDrawing->setCoordinates('I'.$m);
                    
                    //$objDrawing->setHeight(19);
                    
                    //$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
		    //unset($objDrawing);
                   
                //}
                
               
              
            } else {
                      $objPHPExcel->getActiveSheet()
                        ->getStyle("I$m")
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setRGB('FFFFFF');
            }
            $p = 'J';

            foreach ($reviewTypeNames as $reviewTypeSingle => $value) {
                $reviewStatus = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle]['status'];
                
                $criteriaStatusTotal = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];

                if (isset($criteriaStatusTotal['total']) && isset($criteriaStatusTotal['assessment'])) {
                   
                    if ($criteriaStatusTotal['total'] != 0) {
                        $overallTotalPercentage = number_format((float) (($criteriaStatusTotal['assessment'] / $criteriaStatusTotal['total']) * 100), 2, '.', '');
                        $objPHPExcel->getActiveSheet()->getRowDimension($m)->setRowHeight($overallTotalPercentage);
                        

                     $objPHPExcel->getActiveSheet()->getStyle("$p$m")->applyFromArray($border_style);
                        $color1 = $statusColourMap[$reviewStatus];
                        
                        $objPHPExcel->getActiveSheet()
                                ->getStyle($p . $m)
                                ->getFill()
                                ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                                ->getStartColor()
                                ->setRGB($color1);
                                
                       
                    } else if (isset($reviewStatus)) {
                        $objPHPExcel->getActiveSheet()->getStyle("$p$m")->applyFromArray($border_style);
                        $color3 = $statusColourMap[$reviewStatus];
                        
                        $objPHPExcel->getActiveSheet()
                                ->getStyle($p . $m)
                                ->getFill()
                                ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                                ->getStartColor()
                                ->setRGB($color3);
                                
                    } else {
                        $objPHPExcel->getActiveSheet()->getStyle("$p$m")->applyFromArray($border_style);
                        
                        $objPHPExcel->getActiveSheet()
                                ->getStyle($p . $m)
                                ->getFill()
                                ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                                ->getStartColor()
                                ->setRGB('FFFFFF');
                                
                    }
                } else if (isset($reviewStatus)) {
                    $objPHPExcel->getActiveSheet()->getStyle("$p$m")->applyFromArray($border_style);
                    $colour2 = $statusColourMap[$reviewStatus];
                   
                    $objPHPExcel->getActiveSheet()
                            ->getStyle($p . $m)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB($colour2);
                           
                } else {
                    $objPHPExcel->getActiveSheet()->getStyle("$p$m")->applyFromArray($border_style);
                    $objPHPExcel->getActiveSheet()
                            ->getStyle($p . $m)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('FFFFFF');
                            
                }





                $p++;
            }$m++;
        }
    }
}

//Second sheets 
$alreadyAdded = array();
$a = 1;

if (!empty($reviewID)) {
    foreach ($reviewID as $q => $z) {
       
        if (empty($alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']])) {
            $alreadyAdded[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']] = 1;

            $slideTitle = $z['program'] . '-' . $z['coe'] . '-' . $z['msn'] . '-' . $z['perimeter'] . '-' . $z['ca'];
            $objPHPExcel->createSheet();
            $objPHPExcel->setActiveSheetIndex($a);
            $objPHPExcel->getActiveSheet()->mergeCells('A1:D1');
            $objPHPExcel->getActiveSheet()->getStyle("A1:D1")->applyFromArray($border_style);
            $objPHPExcel->getActiveSheet()
                            ->getStyle('A1')
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
            $objPHPExcel->getActiveSheet()->setCellValue('A1', $slideTitle);
            $objPHPExcel->getActiveSheet()->mergeCells('A3:D3');
            $objPHPExcel->getActiveSheet()->getStyle("A3:D3")->applyFromArray($border_style);
            $objPHPExcel->getActiveSheet()
                        ->getStyle('A3:D3')
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setRGB('d3d3d3');
                        
            $objPHPExcel->getActiveSheet()->setCellValue('A3', 'GeneralInformation');
             $objPHPExcel->getActiveSheet()->getStyle('A4:E4')->applyFromArray($border_style);
            $objPHPExcel->getActiveSheet()
                        ->getStyle('A4:E4')
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setRGB('d3d3d3');
                        
            $objPHPExcel->getActiveSheet()->setCellValue('A4', 'ODD');
            
            $objPHPExcel->getActiveSheet()->setCellValue('B4', 'ID');
            
            $objPHPExcel->getActiveSheet()->setCellValue('C4', 'OverallStatus');
            
            $objPHPExcel->getActiveSheet()->setCellValue('D4', 'NumberOfRisks');
            
            $objPHPExcel->getActiveSheet()->setCellValue('E4', 'OpenRisks');
            
            if (isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['odd']['odd'])) {
                
                $rODD = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['odd']['odd'];
            } else {
                $rODD = ' ';
            }

            if (isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['id']['id'])) {
                
                $rID = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['id']['id'];
            } else {
                $rID = ' ';
            }

          

            if (isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total'])) {
                $rnumber_of_risks = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total'];
            } else {
                $rnumber_of_risks = 0;
            }

            if (isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing'])) {
                $rnumber_of_open_risks = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks']['risk_total_ongoing'];
            } else {
                $rnumber_of_open_risks = 0;
            }
            $objPHPExcel->getActiveSheet()->getStyle("A5:E5")->applyFromArray($border_style);
            $objPHPExcel->getActiveSheet()->setCellValue('A5', $rODD);
            
            $objPHPExcel->getActiveSheet()->setCellValue('B5', $rID);
            if(isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend']))
			{
                        $progressTrendArray = split('_', $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend']);
			$objPHPExcel->getActiveSheet()
	   			    ->getStyle("C5")
           			    ->getFont()
	   			    ->setBold(true)
	   			    ->setName('Wingdings 3')
           			    ->setSize(13)
           			    ->getColor()->setRGB($progressColourMap[$progressTrendArray[1]]);
$objPHPExcel->getActiveSheet()->setCellValue("C5", $wingdingsMap[$progressTrendArray[0]]);
                            //$progressTrendKey = array_key_exists($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend'],$progress_map);
                           //  if($progressTrendKey){
                           // $progressTrendValue = $progress_map[$reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['progress_trend']['progress_trend']];
                           //$objDrawing1 = new PHPExcel_Worksheet_Drawing(); 
                            //$objDrawing1->setPath("../../common/img/$progressTrendValue.png");
                    
                            // $objDrawing1->setCoordinates('C5');
                    
                            //$objDrawing1->setHeight(19);
                    
                             //$objDrawing1->setWorksheet($objPHPExcel->getActiveSheet());
			// unset($objDrawing1);	}	
                            
			}
			else
                        {
                            $objPHPExcel->getActiveSheet()
                        ->getStyle('C5')
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setRGB('FFFFFF');
                        }
            
            
            $objPHPExcel->getActiveSheet()->setCellValue('D5', $rnumber_of_risks);
            
            $objPHPExcel->getActiveSheet()->setCellValue('E5', $rnumber_of_open_risks);

            $objPHPExcel->getActiveSheet()->mergeCells('A7:D7');
            $objPHPExcel->getActiveSheet()->getStyle('A7:D7')->applyFromArray($border_style);
            $objPHPExcel->getActiveSheet()
                        ->getStyle('A7:D7')
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setRGB('d3d3d3');
            $objPHPExcel->getActiveSheet()->getStyle('A8:D8')->applyFromArray($border_style);         
            $objPHPExcel->getActiveSheet()
                        ->getStyle('A8:D8')
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setRGB('d3d3d3');
                       
            $objPHPExcel->getActiveSheet()->setCellValue('A7', 'ReviewInformation');
            $objPHPExcel->getActiveSheet()->setCellValue('A8', 'ReviewType');
            $objPHPExcel->getActiveSheet()->setCellValue('B8', 'Status&DegreeofFulfilment');
            $objPHPExcel->getActiveSheet()->setCellValue('C8', 'NumberOfActions');
            $objPHPExcel->getActiveSheet()->setCellValue('D8', 'Open Actions');
            $review_type = array();
            $l = 9;
            $b = 'A';
            foreach ($reviewTypeNames as $reviewTypeSingle => $value) {
                
                $objPHPExcel->getActiveSheet()->getStyle("$b$l")->applyFromArray($border_style);
                $objPHPExcel->getActiveSheet()->setCellValue($b . $l, $reviewTypeSingle);
                $l++;
            }
            $l1 = 9;
            $b1 = 'B';
            $b2 = 'C';
            $b3 = 'D';
            foreach ($reviewTypeNames as $reviewTypeSingle => $value) {
                $review_typer = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];
                $reviewStatus = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle]['status'];
                $criteriaStatusTotal = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];


                

                if (isset($criteriaStatusTotal['total']) && isset($criteriaStatusTotal['assessment'])) {
                    
                    if ($criteriaStatusTotal['total'] != 0) {
                        
                        $overallTotalPercentage = number_format((float) (($criteriaStatusTotal['assessment'] / $criteriaStatusTotal['total']) * 100), 2, '.', '');
                        $objPHPExcel->getActiveSheet()->getRowDimension($m)->setRowHeight($overallTotalPercentage);
                        $colorw1 = $statusColourMap[$reviewStatus];
                        $objPHPExcel->getActiveSheet()->getStyle("$b1$l1")->applyFromArray($border_style);
                        
                        $objPHPExcel->getActiveSheet()
                                ->getStyle($b1 . $l1)
                                ->getFill()
                                ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                                ->getStartColor()
                                ->setRGB($colorw1);
                                
                        $status1 = $statusWordMap[$reviewStatus];
                        $objPHPExcel->getActiveSheet()->setCellValue($b1 . $l1, $status1);
                        
                    } else if (isset($reviewStatus)) {
                        $objPHPExcel->getActiveSheet()->getStyle("$b1$l1")->applyFromArray($border_style);
                        
                        $colorw2 = $statusColourMap[$reviewStatus];
                        $status2 = $statusWordMap[$reviewStatus];
                  
                        $objPHPExcel->getActiveSheet()
                                ->getStyle($b1 . $l1)
                                ->getFill()
                                ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                                ->getStartColor()
                                ->setRGB($colorw2);
                               
                        $objPHPExcel->getActiveSheet()->setCellValue($b1 . $l1, $status2);
                    } else {
                        $objPHPExcel->getActiveSheet()->getStyle("$b1$l1")->applyFromArray($border_style);
                        
                        $objPHPExcel->getActiveSheet()
                                ->getStyle($b1 . $l1)
                                ->getFill()
                                ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                                ->getStartColor()
                                ->setRGB('FFFFFF');
                                
                        $objPHPExcel->getActiveSheet()->setCellValue($b1 . $l1, 'NotPerformed');
                    }
                } else if (isset($reviewStatus)) {
                    $objPHPExcel->getActiveSheet()->getStyle("$b1$l1")->applyFromArray($border_style);
                    $colourw3 = $statusColourMap[$reviewStatus];
                    $status3 = $statusWordMap[$reviewStatus];
                    
                    $objPHPExcel->getActiveSheet()
                            ->getStyle($b1 . $l1)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB($colourw3);
                           
                    $objPHPExcel->getActiveSheet()->setCellValue($b1 . $l1, $status3);
                } else {
                    $objPHPExcel->getActiveSheet()->getStyle("$b1$l1")->applyFromArray($border_style);
                    
                   
                    $objPHPExcel->getActiveSheet()
                            ->getStyle($b1 . $l1)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('FFFFFF');
                           
                    $objPHPExcel->getActiveSheet()->setCellValue($b1 . $l1, 'NotPerformed');
                }


                if (isset($criteriaStatusTotal['action_total'])) {
                    $number_of_actions = $criteriaStatusTotal['action_total'];
                } else {
                    $number_of_actions = 0;
                }
                $objPHPExcel->getActiveSheet()->getStyle("$b2$l1")->applyFromArray($border_style);
                $objPHPExcel->getActiveSheet()->setCellValue($b2 . $l1, $number_of_actions);
                if (isset($criteriaStatusTotal['action_total_ongoing'])) {
                    $Open_actions = $criteriaStatusTotal['action_total_ongoing'];
                } else {
                    $Open_actions = 0;
                }
                $objPHPExcel->getActiveSheet()->getStyle("$b3$l1")->applyFromArray($border_style);
                $objPHPExcel->getActiveSheet()->setCellValue($b3 . $l1, $Open_actions);


 

                $l1++;

                
            }







            $a++;
        }
        //Open risks
        $h = $l1 + 1;
        $letter1 = 'A';
        $letter2 = 'D';
       
        $objPHPExcel->getActiveSheet()->getStyle("A$h")->applyFromArray($border_style);
                    $objPHPExcel->getActiveSheet()
                            ->getStyle('A' . $h)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
                            
        
        $objPHPExcel->getActiveSheet()->setCellValue('A' . $h, 'OpenRisks');
        $last = $h + 1;
 
        $objPHPExcel->getActiveSheet()
                            ->getStyle('A' . $last)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
                            
        
         $objPHPExcel->getActiveSheet()->getStyle("A$last:F$last")->applyFromArray($border_style); 
        $objPHPExcel->getActiveSheet()->setCellValue('A' . $last, 'Status&Code');
        $objPHPExcel->getActiveSheet()
                            ->getStyle('B' . $last)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
                          
          
        $objPHPExcel->getActiveSheet()->setCellValue('B' . $last, 'Description');
        $objPHPExcel->getActiveSheet()
                            ->getStyle('C' . $last)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
                            
        
        $objPHPExcel->getActiveSheet()->setCellValue('C' . $last, 'Action');
        $objPHPExcel->getActiveSheet()
                            ->getStyle('D' . $last)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
                         
       
        $objPHPExcel->getActiveSheet()
                            ->getStyle('E' . $last)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
                           
        
        $objPHPExcel->getActiveSheet()->setCellValue('E' . $last, 'RPN');
        $objPHPExcel->getActiveSheet()
                            ->getStyle('F' . $last)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
                           
        
        $objPHPExcel->getActiveSheet()->setCellValue('F' . $last, 'Holder'); 
        
        $risk_id = $last + 1;
        $r = 'B';

        foreach ($statusColourMap as $statusNumber => $colour) {
            
            if (isset($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks'])) {
                
              
                foreach ($reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']]['risks'] as $riskStatusKey => $value) {

                    if ($riskStatusKey == 'risk_' . $statusNumber) {

                        $splitRisks = split('-!-', $value);

                        for ($i = 0; $i < count($splitRisks); $i++) {
                            if ($splitRisks[$i] != '' && isset($splitRisks[$i])) {
                               $splitRisksColumns = split('---', $splitRisks[$i]);
                     
                                $objPHPExcel->getActiveSheet()->getStyle("A$risk_id:F$risk_id")->applyFromArray($border_style);
                                $objPHPExcel->getActiveSheet()
                            ->getStyle('A'.$risk_id)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB($colour);
                                $objPHPExcel->getActiveSheet()->setCellValue('A' . $risk_id, $statusWordMap[$statusNumber]."\n".$splitRisksColumns[0]);

                               
                                
                                $objPHPExcel->getActiveSheet()->setCellValue('B' . $risk_id, $splitRisksColumns[1]);
                                
                                $objPHPExcel->getActiveSheet()->setCellValue('C' . $risk_id, $splitRisksColumns[2]);
                               
                                $objPHPExcel->getActiveSheet()->setCellValue('D' . $risk_id, $splitRisksColumns[3]);
                             
                                $objPHPExcel->getActiveSheet()->setCellValue('E' . $risk_id, $splitRisksColumns[4]);
                               
                                $objPHPExcel->getActiveSheet()->setCellValue('F' . $risk_id, $splitRisksColumns[5]);
                                $risk_id++;
                            }
                            
                        }
                    }
                    
                }
            }
            
        }
/*         * *********       * ******************* *******Code for reviewInformation**************** ***********************************   */
        
        //Actions
       $Actions_id=$risk_id+1;
         $objPHPExcel->getActiveSheet()->getStyle("A$Actions_id")->applyFromArray($border_style);
                    $objPHPExcel->getActiveSheet()
                            ->getStyle('A'.$Actions_id)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$Actions_id,"OpenActions");
        $action_id1=$Actions_id+1;
        
                    $objPHPExcel->getActiveSheet()
                            ->getStyle('A'.$action_id1)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
        $objPHPExcel->getActiveSheet()->getStyle("A$action_id1:F$action_id1")->applyFromArray($border_style);
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$action_id1,"Status&Code");
        
        $objPHPExcel->getActiveSheet()->setCellValue('B'.$action_id1,"Description");
        $objPHPExcel->getActiveSheet()
                            ->getStyle('B'.$action_id1)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
       
                    $objPHPExcel->getActiveSheet()
                            ->getStyle('C'.$action_id1)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$action_id1,"Remark");
        
                    $objPHPExcel->getActiveSheet()
                            ->getStyle('D'.$action_id1)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
        $objPHPExcel->getActiveSheet()->setCellValue('D'.$action_id1,"CompleteBy");
        
                    $objPHPExcel->getActiveSheet()
                            ->getStyle('E'.$action_id1)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
        $objPHPExcel->getActiveSheet()->setCellValue('E'.$action_id1,"Holder");
       
                    $objPHPExcel->getActiveSheet()
                            ->getStyle('F'.$action_id1)
                            ->getFill()
                            ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setRGB('d3d3d3');
        $objPHPExcel->getActiveSheet()->setCellValue('F'.$action_id1,"Validator");
        $action_id2=$action_id1+1;
        foreach ($statusColourMap as $statusNumber => $colour) 
			{
				
					foreach ($reviewTypeNames as $reviewTypeSingle => $value) 
					{
						$actionTotalsShort = $reviewBetterFormatted[$z['program']][$z['coe']][$z['msn']][$z['perimeter']][$z['ca']][$reviewTypeSingle];

						if(isset($actionTotalsShort['action_'.$statusNumber]))
						{
							$splitActions = split('-!-', $actionTotalsShort['action_'.$statusNumber]);

							for ($i=0; $i < count($splitActions); $i++) 
							{
								if($splitActions[$i] != '' && isset($splitActions[$i]))
								{
									

									$splitActionColumns = split('---', $splitActions[$i]);
                                                                         $objPHPExcel->getActiveSheet()->getStyle("A$action_id2:F$action_id2")->applyFromArray($border_style);
                                                                        $objPHPExcel->getActiveSheet()
                                                                                     ->getStyle('A'.$action_id2)
                                                                                     ->getFill()
                                                                                       ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                                                                                      ->getStartColor()
                                                                                          ->setRGB($colour);
                                                                        $objPHPExcel->getActiveSheet()->setCellValue('A' . $action_id2, $statusWordMap[$statusNumber]."\n".$splitActionColumns[0]);
									
                                                                        $objPHPExcel->getActiveSheet()->setCellValue('B'.$action_id2, $splitActionColumns[1]);
                                                                        
                                                                        $objPHPExcel->getActiveSheet()->setCellValue('C'.$action_id2, $splitActionColumns[2]);
                                                                        
                                                                        $objPHPExcel->getActiveSheet()->setCellValue('D'.$action_id2, $splitActionColumns[3]);
                                                                       
                                                                        $objPHPExcel->getActiveSheet()->setCellValue('E'.$action_id2, $splitActionColumns[4]);
                                                                      
                                                                        $objPHPExcel->getActiveSheet()->setCellValue('F'.$action_id2, $splitActionColumns[5]);
									$action_id2++;

									
								}
							}
						}
					}
				
			}

        
        /*********CODE FOR ACTION**************************/

        
    }
}



$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save(str_replace('.php', '.xls',__FILE__));
chmod('csvlibrary.xls',0777);
$filename="art_excel_extract_".date('Y_m_d_H_i_s');
$objWriter->save('../output/'.$filename.'.xls');
$objPHPExcel->disconnectWorksheets();
unset($objWriter,$objPHPExcel);
echo 'OK|||'.$filename;

?>
