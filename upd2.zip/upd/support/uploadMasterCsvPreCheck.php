<?php
/*
 * Fix for: Improvement-2(minor)
 * Criteria upload (Suggested by ICT)
 * Version: 4.2
 * Fixed By: Infosys Limited
 */

require_once('../support/header.php');
require_once('../security/checkExpiredSession.php');
require_once('../support/localSupport.php');
require_once('../../support.php');
require_once('../../common/php/common.php');

if (isset($_POST["submit"]) ) {
    if (isset($_FILES["uploadedFile"])) {
        if ($_FILES["uploadedFile"]["error"] > 0) {
            echo "Return Code: " . $_FILES["uploadedFile"]["error"] . "<br />";
        }
        else
        {
            move_uploaded_file($_FILES["uploadedFile"]["tmp_name"], "../uploadCsv/" . $_FILES["uploadedFile"]["name"]);
            
            if(($fileHandle = fopen("../uploadCsv/" . $_FILES["uploadedFile"]["name"], "r")) !== FALSE) {
                $csvIds = SqlQ('SELECT csv_report_id, csv_report_creation
					FROM dr_csv_report
					WHERE review_id='.$SESSION['list_cat']['review_profile'].
                                        ' ORDER BY csv_report_id DESC');
                
                $rawData = criteriaList($SESSION, '', '', 1);
                
                ?><html><head><?php
                    ?><script language="javascript" type="text/javascript" src="../js/overlib.js"><!-- overLIB (c) Erik Bosrup --></script><?php
                    ?><script language="javascript" type="text/javascript" src="../../common/js/common.js"></script><?php
                    ?><script language="javascript" type="text/javascript" src="../js/home.js"></script><?php
                    ?><script language="javascript" type="text/javascript" src="../js/ajax.js"></script><?php
                    ?><link rel="stylesheet" href="../main.css" media="screen" type="text/css"><?php
                    ?></head><?php

                    ?><body style="background-color:#ffffff; text-align:left;"><?php
                            
                createLog('dr_log','csv_report_id','upload',$csvIds['csv_report_id'],'','',$SESSION);
                
                ?><div class="tableTitle" style="padding-top:20px;">This CSV Report was generated on: <b><?=$csvIds['csv_report_creation']?></b></div><?php
                ?><div class="tableTitle" style="padding-top:20px;">Discrepancies:</div><?php

                ?><table class="criteriaTable" cellspacing="0" cellpadding="10"><?php
                ?><tr class="tableGroup"><?php
                    ?><td>Criterion User ID</td><?php
                    ?><td>Item</td><?php
                    ?><td>Value In ART</td><?php
                    ?><td>Value In CSV</td><?php
                    ?><td>Time Modified in ART</td><?php
                    ?><td>Exact Time Modified In ART</td><?php
                    /*?><td>Modified In ART By</td><?php*/
                ?></tr><?php
                ?><script type="text/javascript">
                    var removeArray = [];
                    var criterion_validity_id = [];
                </script><?php
                
                $counter = 0;
                $csvArray = array();
                $invalidValues = array();
                while (($data = fgetcsv($fileHandle, 1024, ";")) !== FALSE) {
                    $counter++;
                    if ($counter != 1) {
                        $criterion_validity_id = trim($data[0]);
                        $criterion_id = trim($data[1]);
                        $review_group = trim($data[2]);
                        $criterion_user_id = trim($data[3]);
                        $criterion_name = trim($data[4]);
                        $criterion_description = trim($data[5]);
                        $criterion_showstopper = trim($data[6]);
                        $criterion_moc = trim($data[7]);                 
                        $review_group_description = trim($data[8]);
                        $review_group_position = trim($data[9]);
                        $grams_reference = trim($data[10]);
                        $criterion_valid_from = trim($data[11]);
                        $criterion_included = trim($data[12]);
                        $criterion_valid = trim($data[13]);
                        $validator = ($SESSION['user']['surname'].','.$SESSION['user']['name']);
                        $validatorSplit = explode(',', $validator);
                        $action = strtolower(trim($data[14]));                    
                        
                        // To modify the existing criteria
                        if ($action == 'modify' && $criterion_valid_from != "0000-00-00 00:00:00") {
                            
                            // To validate the values entered in CSV
                            $invalidRefArray = columnValidation($action, $criterion_user_id, $criterion_moc, $criterion_showstopper, $review_group_position, $grams_reference);
                            array_push($invalidValues, $invalidRefArray);
                            
                            if(!$invalidRefArray) {
                                // To select the Old values from DB
                                foreach($rawData as $q=>$z) {
                                    if($z['criterion_validity_id'] == $criterion_validity_id) {
                                        $criteriaList_old = array();
                                        $criteriaList_old['criterion_user_id'] = $z['criterion_user_id'];
                                        $criteriaList_old['criterion_name'] = $z['criterion_name'];
                                        $criteriaList_old['criterion_description'] = $z['criterion_description'];
                                        $criteriaList_old['criterion_showstopper'] = $z['criterion_showstopper'];
                                        $criteriaList_old['criterion_moc'] = $z['criterion_moc'];
                                        $criteriaList_old['review_group_description'] = $z['review_group_description'];
                                        $criteriaList_old['review_group_position'] = $z['review_group_position'];
                                        $criteriaList_old['grams_reference'] = $z['grams_reference'];
                                    }
                                }
                                
                                $criteriaList_new = array();
                                $criteriaList_new['criterion_user_id'] = $criterion_user_id;
                                $criteriaList_new['criterion_name'] = $criterion_name;
                                $criteriaList_new['criterion_description'] = $criterion_description;
                                $criteriaList_new['criterion_showstopper'] = $criterion_showstopper;
                                $criteriaList_new['criterion_moc'] = $criterion_moc;
                                $criteriaList_new['review_group_description'] = $review_group_description;
                                $criteriaList_new['review_group_position'] = $review_group_position;
                                $criteriaList_new['grams_reference'] = $grams_reference;

                                $suppressedQueryArray = array();
                                $totalSuppressedQueries = 0;
                                $csvReportCreation = $csvIds['csv_report_creation'];
                                $criteria_validated_on = SqlQ('SELECT action_taken_on FROM dr_validation_loop 
                                    WHERE applicability = '.$criterion_validity_id.' 
                                    ORDER BY action_taken_on DESC 
                                    LIMIT 1');
                            
                                discrepancyCheck('criteria', $csvIds['csv_report_id'], $criteria_validated_on['action_taken_on'], $criteriaList_old, $criteriaList_new, 'Discripancies in CSV');
                            
                                if(!empty($suppressedQueryArray))
                                {
                                    foreach ($suppressedQueryArray as $number => $value)
                                    {
                                        if(!empty($value['time_difference']))
                                        {
                                            $items = array();
                                            $oldValues = array();
                                            $newValues = array();
                                            ?><tr><?php
                                                    ?><td><?=$criteriaList_old['criterion_user_id']?></td><?php
                                                    foreach($value['old_value'] as $column=>$columnValue) {
                                                        array_push($items,$column);
                                                    }
                                                    ?><td><?=implode(',', $items)?></td><?php
                                                    foreach($value['old_value'] as $column=>$columnValue) {                                                    
                                                        array_push($oldValues,$columnValue);
                                                    }
                                                    ?><td><?=implode(',', $oldValues)?></td><?php
                                                    foreach($value['new_value'] as $column=>$columnValue) {
                                                        array_push($newValues,$columnValue);
                                                    }
                                                    ?><td><?=implode(',', $newValues)?></td><?php
                                                    ?><td><?=$value['time_difference']?></td><?php
                                                    ?><td><?=$value['latest_log_date']?></td><?php
                                                
                                                    $criteriaList_new['criterion_validity_id'] = $criterion_validity_id;
                                                    $criteriaList_new['criterion_id'] = $criterion_id;
                                                    $criteriaList_new['review_group'] = $review_group;
                                                    array_push($csvArray, $criteriaList_new);
                                                                                                        
                                                    ?><td id="csv_<?=$criterion_validity_id?>"><input type="button" class="stdBtn" id="<?=$criterion_validity_id?>" value="Keep the value in ART &#9658;" onclick="removeArray.push(<?=$criterion_validity_id?>); this.disabled=true; this.value='Done!';"></td><?php
                                                    ?><script type="text/javascript">criterion_validity_id.push(<?=$criterion_validity_id?>)</script><?php
                                            ?></tr><?php                                        
                                        }
                                    }
                                }
                                else
                                {
                                    ?><tr class="infoRow"><td colspan="7" style="color:#bbbcbc; text-align:center;">No discrepancies found!</td></tr><?php
                                    updateDatabase($SESSION, $criterion_user_id, $criterion_name, $criterion_description, $criterion_showstopper, $criterion_moc, $review_group_description, $review_group_position, $grams_reference, $criterion_validity_id, $criterion_id, $review_group, $validatorSplit);
                                }
                            }                            
                        }
                        // To create new criteria
                        else if($action == 'add') {
                            $invalidRefArray = columnValidation($action, $criterion_user_id, $criterion_moc, $criterion_showstopper, $review_group_position, $grams_reference);
                            array_push($invalidValues, $invalidRefArray);
                            if(!$invalidRefArray) {
                                createCriteria($SESSION, $criterion_user_id, $criterion_name, $criterion_description, $criterion_showstopper, $criterion_moc, $review_group_description, $review_group_position, $grams_reference);
                            }
                        }
                        // To delete the criteria
                        else if($action == 'delete') {
                            SqlLQ('UPDATE dr_review_criterion_history SET criterion_hidden = 1 WHERE criterion_validity_id=' . $criterion_validity_id);
                        }
                        else if($action != "")
                        {
                            $invalidAction = columnValidation($action, $criterion_user_id);
                            array_push($invalidValues, $invalidAction);
                        }                            
                    }
                }

                ?><tr><?php
                ?><script type="text/javascript">
                    var csvArray = <?php echo json_encode($csvArray, true); ?>
                </script>
                    <td id="csv_update"><input type="button" id="importCSV" class="stdBtn" value="Import Value from CSV to ART &#9658;" onclick="this.disabled=true;
                        ajaxRequestExecutePost('uploadMasterCsvUpdateConfirm.php','updateCsvReport',false,'POST',csvArray,criterion_validity_id,removeArray);"></td><?php 
                ?></tr><?php
                ?></table><?php
                ?><br /><br /><?php                
                
                if(!empty($invalidValues) && is_array($invalidValues)) {
                    echo "The below value(s) are invalid. <br /><br />";
                    ?><table class="criteriaTable" cellspacing="0" cellpadding="10"><?php
                        ?><tr class="tableGroup"><?php
                            ?><td>Criterion User ID</td><?php
                            ?><td>Item</td><?php
                            ?><td>Value Entered</td><?php
                        ?></tr><?php
                    
                        foreach($invalidValues as $user_id=>$column) {
                            foreach($column as $columnName => $columnValue) {
                                foreach($columnValue as $item => $value) {
                                    ?><tr><?php
                                        ?><td><?=$columnName?></td><?php
                                        ?><td><?=$item?></td><?php
                                        ?><td style="color: red;"><?=$value?></td><?php
                                    ?></tr><?php 
                                }                            
                            }
                        }
                }
            }
            ?></html><?php
            fclose($fileHandle);
        }
    } else {
            echo 'No file selected';
    }
}

/*
 * Function to Create new criteria from CSV
 * @param Object $SESSION
 * @param String $criterion_user_id
 * @param String $criterion_name
 * @param String $criterion_description
 * @param Integer $criterion_showstopper
 * @param String $criterion_moc
 * @param String $review_group_description
 * @param Integer $review_group_position
 * @param String $grams_reference
 */
function createCriteria($SESSION, $criterion_user_id, $criterion_name, $criterion_description, $criterion_showstopper, $criterion_moc, $review_group_description, $review_group_position,$grams_reference) {
    // To fetch the Group ID from the Database
    $reviewGroupID = SqlQ('SELECT rg.group_id
            FROM dr_review_group_history AS rgh
                INNER JOIN dr_review_group 	AS rg ON rgh.review_group=rg.group_id
                INNER JOIN dr_review_profile AS rp ON rg.review_type=rp.review_type
            WHERE rp.review_profile_id="'.$SESSION['list_cat']['review_profile'].'"
            AND rgh.review_group_description = "' . $review_group_description . '" AND rgh.review_group_valid_to="0000-00-00 00:00:00"');

    if($reviewGroupID) {
        $criterionPosition=SqlQ('SELECT MAX(criterion_position) AS critpos
            FROM dr_review_criterion_history AS rch
                INNER JOIN dr_review_criterion AS rc ON rc.review_criterion_id=rch.criterion
            WHERE rc.review_group='.$reviewGroupID['group_id']);

        SqlLQ('INSERT INTO dr_criterion_group (criterion_group_reference) VALUES ("Default")');
    } else {
        $review_type = SqlQ('SELECT review_type FROM dr_review_profile WHERE review_profile_id='. $SESSION['list_cat']['review_profile']);

        SqlLQ('INSERT INTO dr_review_group (review_type) VALUES ("'.$review_type['review_type'].'")');
        $reviewGroupID = SqlQ('SELECT LAST_INSERT_ID() AS group_id');
        
        SqlLQ('INSERT INTO dr_review_group_history (review_group, review_group_description, review_group_position, review_group_valid_from) VALUES ("'.$reviewGroupID['group_id'].'","'.$review_group_description.'","'.($review_group_position+1).'",SYSDATE())');
    }                  

    $criterionGroupID=SqlQ('SELECT LAST_INSERT_ID() AS criterionGroupID');

    SqlLQ('INSERT INTO dr_review_criterion (review_group, criterion_group) VALUES ('.$reviewGroupID['group_id'].', '.$criterionGroupID['criterionGroupID'].')');

    $criterionID=SqlQ('SELECT LAST_INSERT_ID() AS criterionID');

    SqlLQ('INSERT INTO dr_review_criterion_history (criterion,	criterion_user_id, criterion_name, criterion_description, criterion_position, criterion_showstopper, criterion_moc) VALUES 
        ("'.$criterionID['criterionID'].'","'.$criterion_user_id.'","'.$criterion_name.'","'.$criterion_description.'","'.($criterionPosition['critpos']+1).'","'.$criterion_showstopper.'","'.$criterion_moc.'")');

    $criterionHistoryID=SqlQ('SELECT LAST_INSERT_ID() AS criterionHistoryID');

    $grams_ref_array = explode(', ', $grams_reference);
    
    for($i=0; $i<count($grams_ref_array); $i++) {
        $gramsId = SqlQ('SELECT grams_id FROM c_grams WHERE grams_reference="' . $grams_ref_array[$i] . '" ORDER BY grams_id DESC LIMIT 1');

        if($gramsId) {
            SqlQ('INSERT INTO dr_review_criterion_applicability (criterion, applicability, object) 
                VALUES ('.$criterionID['criterionID'].','.$gramsId['grams_id'].',(SELECT object_id FROM c_object WHERE object="grams_id"))');
        }
    }
    
    // To force validate the Criteria
    forceValidateCriteria($SESSION, $criterionHistoryID['criterionHistoryID'], $criterionID['criterionID']);
}

/*
 * To check the discripancies in CSV report
 * @param string $type
 * @param integer $id
 * @param array $oldValueArray
 * @param array $newValueArray
 * @param string $message
 */
function discrepancyCheck($type, $id, $criteria_validated_on, $oldValueArray, $newValueArray, $message) {
    
    global $suppressedQueryArray, $totalSuppressedQueries, $csvReportCreation;
    
    if(array_diff_assoc($oldValueArray,$newValueArray)) {
        
        $log=SqlQ('SELECT l.log_date AS latest_log_date, u.name, u.surname
                    FROM dr_log AS l
                    LEFT JOIN c_user AS u ON u.user_id=l.user
                    WHERE l.applicability="'.$id.'"
                    ORDER BY log_id DESC');

        if($log['latest_log_date'] != '' && strtotime($log['latest_log_date']) > strtotime($csvReportCreation))
        {
            $time =  floor((strtotime($log['latest_log_date']) - strtotime($csvReportCreation))/(60*60*24));
            $period = ' Days';
            if ($time == 0)
            {
                    $time = floor((strtotime($log['latest_log_date']) - strtotime($csvReportCreation))/(60*60));
                    $period = ' Hours';
            }
            if ($time == 0) 
            {
                    $time = floor((strtotime($log['latest_log_date']) - strtotime($csvReportCreation))/(60));
                    $period = ' Minutes';
            }			

            $suppressedQueryArray[$totalSuppressedQueries]['time_difference']	= 'Modified ~'.$time.$period.' after CSV Report Generated';
            $suppressedQueryArray[$totalSuppressedQueries]['message']		= $log['object_description'].' - '.$something['action_code'];
            $suppressedQueryArray[$totalSuppressedQueries]['latest_log_date']	= $log['latest_log_date'];
            $suppressedQueryArray[$totalSuppressedQueries]['name']		= $log['name'].' '.$log['surname'];
            $suppressedQueryArray[$totalSuppressedQueries]['update']		= 'dr_review';
            $suppressedQueryArray[$totalSuppressedQueries]['type']		= $type;
            $suppressedQueryArray[$totalSuppressedQueries]['id']		= $id;
            $suppressedQueryArray[$totalSuppressedQueries]['old_value']	= array_diff_assoc($oldValueArray,$newValueArray);
            $suppressedQueryArray[$totalSuppressedQueries]['new_value']	= array_diff_assoc($newValueArray,$oldValueArray);
            $suppressedQueryArray[$totalSuppressedQueries]['set'] 		= $message;
            $totalSuppressedQueries++;
        }
    }
}

storeSession($SESSION);
?>