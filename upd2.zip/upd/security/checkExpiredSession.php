<?php
require_once(dirname(__FILE__).'/../../support.php');

function throwUserToIndex(){
	if(isset($_GET['rand']) || (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')){
		?>_!exit!_<?php
	}else{
		$invalidUrl=array('/var/www_1V55/','\\','');
		$validUrl=array('http://art-int.eu.airbus.corp/1V55','/','http://127.0.0.1');
		header("Location: ".str_replace($invalidUrl,$validUrl,dirname(__FILE__))."/../index.php");
	}
	exit();
}

if($SESSION['tool_id']=='' || $SESSION['user']['user_id']==''){
	session_start();
	$sessionFilePath=dirname(__FILE__).'/../session/'.session_id().'.session';
	if(file_exists($sessionFilePath)){
		$start=microtime(true);
		$SESSION=unserialize(file_get_contents($sessionFilePath));
		$end=microtime(true);
	}else{
		throwUserToIndex();
	}
}
if(empty($SESSION['tool_id']) || empty($SESSION['user']['user_id'])){
	throwUserToIndex();
}
?>