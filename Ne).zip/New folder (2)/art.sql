-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2019 at 01:14 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `art`
--

-- --------------------------------------------------------

--
-- Table structure for table `dr_assessment_questions`
--

CREATE TABLE IF NOT EXISTS `dr_assessment_questions` (
  `question_id` int(11) NOT NULL,
  `question_name` longtext NOT NULL,
  `question_hidden` int(10) DEFAULT '0',
  `admin_modifier_id` int(11) DEFAULT '0',
  `area_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dr_assessment_questions`
--

INSERT INTO `dr_assessment_questions` (`question_id`, `question_name`, `question_hidden`, `admin_modifier_id`, `area_id`) VALUES
(1, 'Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?Is there any action is pending?', 0, 0, 0),
(2, 'How may actions are completed?', 0, 0, 0),
(3, 'How many persons are currently logged in?', 0, 0, 0),
(4, 'How many reviews are currently Pending?', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dr_question_response`
--

CREATE TABLE IF NOT EXISTS `dr_question_response` (
`answer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `question_response` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `review_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dr_question_response`
--

INSERT INTO `dr_question_response` (`answer_id`, `user_id`, `question_id`, `question_response`, `review_id`, `area_id`) VALUES
(1, 1485, 1, 'no', 0, 0),
(2, 1485, 2, 'no', 0, 0),
(3, 1485, 3, 'no', 0, 0),
(4, 1485, 4, 'no', 0, 0),
(5, 1485, 1, 'yes', 0, 0),
(6, 1485, 2, 'yes', 0, 0),
(7, 1485, 3, 'yes', 0, 0),
(8, 1485, 4, 'yes', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dr_assessment_questions`
--
ALTER TABLE `dr_assessment_questions`
 ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `dr_question_response`
--
ALTER TABLE `dr_question_response`
 ADD PRIMARY KEY (`answer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dr_question_response`
--
ALTER TABLE `dr_question_response`
MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
